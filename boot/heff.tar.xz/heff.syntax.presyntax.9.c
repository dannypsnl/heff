// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_CAnnLam 19336
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkBinding 51651
#define TAG_MkSegment 38079
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define LBL_args 9498020
#define LBL_bound 295286168
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_head 9693863
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_names__muts__loop__sp__depth__giving__bound[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving, LBL_bound};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1322732838x2002428036_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1322732838x2002428036_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s423413976x1387178348_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s423413976x1387178348_24dps_24cpr(V, V, V);
HeffT3 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackLet(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackLet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackLet_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackMatch(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackMatch_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackMatch_clo;
V g_heff_2esyntax_2epresyntax_2egivenTy(V, V, V);
V g_heff_2esyntax_2epresyntax_2egivenTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivenTy_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2epackPat(V, V);
V g_heff_2esyntax_2epresyntax_2epackPat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackPat_clo;
V g_heff_2esyntax_2epresyntax_2epackTy(V, V);
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackTy_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2erunArgs(V, V);
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s169345181x1621877738_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatSpineOf(V v_p_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(v_p_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_head__args, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatSpineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackPat_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackPat_str1, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackPat_str2, 6, "MkPair");
Clo g_heff_2esyntax_2epresyntax_2epackPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epackPat_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epackPat(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackPat_str0)}), heff_dup(v_sp_240)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
    }
    case TAG_Cons: {
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2epackPat(v_sp_240, v_x22_243));
      V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
      V v_ps_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_248});
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackPat_str1)}), heff_dup(v_sp_240)});
      V v_x1_2411 = ({ V a_0 = v_t_2410; V a_1 = v_ps_249; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_t_2410, 2); r_; });
      V v_t_2414;
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_At: {
        V v_s_2413 = heff_field(v_x1_2411, 1);
        heff_take_n(v_x1_2411, 2ULL, 2);
        v_t_2414 = v_s_2413;
        break;
      }
      default: heff_nomatch(v_x1_2411);
      }
      V v_t_2415 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2414, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackPat_str2), heff_dup(v_sp_240), v_ps_249}), v_t_2415});
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epackPat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2epackPat(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s123414895x1258426214_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT3 v_t_247 = ({ V a_0 = v_st_240; V a_1 = v_x_245; HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s169345181x1621877738_24cpr(a_0, a_1)); heff_drop(v_st_240); r_; });
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      V v_st_2411 = v_field_248;
      V v_y_2412 = heff_tag_n(TAG_At, 2, (V[]){v_field_249, v_field_2410});
      V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_2412, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
      V t_0 = v_st_2411;
      V t_1 = v_xs_246;
      V t_2 = v_u_2414;
      v_st_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1322732838x2002428036_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkBinding: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkBinding = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2422;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2422 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2418 = v_t_2417.f[0];
                V v_field_2419 = v_t_2417.f[1];
                V v_a_2420 = v_field_2418;
                V v_a_2421 = v_field_2419;
                heff_drop(v_a_2421);
                v_a_2422 = v_a_2420;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        V v_t_2423 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkBinding, TAG_MkBinding, 2, 3ULL, (V[]){v_a_246, v_a_247}), v_a_245});
        V v_cell_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
        HeffT2 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1322732838x2002428036_24dps_24cpr(v_a_2422, v_xs_243, v_cell_2424));
        {
          V v_field_2426 = v_t_2425.f[0];
          V v_field_2427 = v_t_2425.f[1];
          V v_x_2428 = v_field_2426;
          V v__5f_2429 = v_field_2427;
          heff_drop(v__5f_2429);
          return ((HeffT2){{v_x_2428, v_cell_2424}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackLet_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackLet_str1, 6, "given#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egiveBackLet_str2, 6, "given#");
Clo g_heff_2esyntax_2epresyntax_2egiveBackLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egiveBackLet_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2egiveBackLet(V v_sp_240, V v_xs_241, V v_e_242, V v_body_243) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    V v_t_246;
    switch (heff_tag_of(v_body_243)) {
    case TAG_At: {
      V v_s_245 = heff_dup(heff_field(v_body_243, 1));
      v_t_246 = v_s_245;
      break;
    }
    default: heff_nomatch(v_body_243);
    }
    V v_t_249;
    switch (heff_tag_of(v_body_243)) {
    case TAG_At: {
      V v_s_248 = heff_dup(heff_field(v_body_243, 1));
      v_t_249 = v_s_248;
      break;
    }
    default: heff_nomatch(v_body_243);
    }
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egiveBackLet_str0)}), heff_dup(v_sp_240)});
    V v_t_2411 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_246, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2410, v_body_243}), v_t_2411});
    V v_t_2413 = ({ V rv_1 = heff_get_n(v_t_249, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_e_242, v_t_2412}), v_t_2413});
  }
  case TAG_Cons: {
    V v_xs2_2415 = heff_dup(heff_field(v_xs_241, 1));
    switch (heff_tag_of(v_xs2_2415)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_241)) {
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_xs_241, 0);
        V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 1ULL, 2);
        V v_t_2420;
        switch (heff_tag_of(v_body_243)) {
        case TAG_At: {
          V v_s_2419 = heff_dup(heff_field(v_body_243, 1));
          v_t_2420 = v_s_2419;
          break;
        }
        default: heff_nomatch(v_body_243);
        }
        V v_t_2423;
        switch (heff_tag_of(v_body_243)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_body_243, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_body_243);
        }
        V v_t_2424 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2416}), heff_dup(v_sp_240)});
        V v_t_2425 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2420, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2424, v_body_243}), v_t_2425});
        V v_t_2427 = ({ V rv_1 = heff_get_n(v_t_2423, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_e_242, v_t_2426}), v_t_2427});
      }
      default: return heff_nomatch(v_xs_241);
      }
    }
    case TAG_Cons: {
      V v_ru_24xs2_2415_24Cons = heff_take_reuse_n(v_xs2_2415, 0ULL, 2);
      V v_t_2430 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
      V v_body_2431 = ({ V a_0 = v_sp_240; V a_1 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egiveBackLet_str1), v_t_2430); V a_2 = v_xs_241; V a_3 = v_body_243; V r_ = (g_heff_2esyntax_2epresyntax_2egiveBackMatch(a_0, a_1, a_2, a_3)); heff_drop(v_body_243); r_; });
      V v_t_2434;
      switch (heff_tag_of(v_body_2431)) {
      case TAG_At: {
        V v_s_2433 = heff_dup(heff_field(v_body_2431, 1));
        v_t_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_body_2431);
      }
      V v_t_2437;
      switch (heff_tag_of(v_body_2431)) {
      case TAG_At: {
        V v_s_2436 = heff_dup(heff_field(v_body_2431, 1));
        v_t_2437 = v_s_2436;
        break;
      }
      default: heff_nomatch(v_body_2431);
      }
      V v_t_2438 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
      V v_t_2439 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2egiveBackLet_str2), v_t_2438)});
      V v_t_2440 = heff_tag_at_n(v_ru_24xs2_2415_24Cons, TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2439, heff_dup(v_sp_240)}), v_body_2431});
      V v_t_2441 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2434, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2442 = heff_tag_n(TAG_ELetIn, 2, (V[]){v_e_242, heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_t_2441})});
      V v_t_2443 = ({ V rv_1 = heff_get_n(v_t_2437, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_t_2443});
    }
    default: return heff_nomatch(v_xs2_2415);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2esyntax_2epresyntax_2egiveBackLet_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egiveBackLet(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivenTy_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivenTy_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egivenTy_str2, 14, "prelude.Either");
Clo g_heff_2esyntax_2epresyntax_2egivenTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egivenTy_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2egivenTy(V v_sp_240, V v_x2_241, V v_vars_242) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egivenTy_str0)}), heff_dup(v_sp_240)});
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egivenTy_str1)}), heff_dup(v_sp_240)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_243, v_t_245));
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2epackTy(v_sp_240, v_vars_242));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egivenTy_str2)}), v_sp_240});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249})));
  } else {
    return ({ V a_0 = v_sp_240; V a_1 = v_vars_242; V r_ = (g_heff_2esyntax_2epresyntax_2epackTy(a_0, a_1)); heff_drop(v_sp_240); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2egivenTy_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2egivenTy(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s423413976x1387178348_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_248 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_247), v_st_240));
        V v_t_249 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_a_246, v_a_247}), v_a_245});
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
        HeffT2 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eaccList_24s423413976x1387178348_24dps_24cpr(v_a_248, v_xs_243, v_cell_2410));
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          V v_x_2414 = v_field_2412;
          V v__5f_2415 = v_field_2413;
          heff_drop(v__5f_2415);
          return ((HeffT2){{v_x_2414, v_cell_2410}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str0, 3, "run");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str1, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2erunArgs_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2erunArgs(V v_h_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_242 = heff_field(v_h_240, 0);
    V v_ru_24h_240_24At = heff_take_reuse_n(v_h_240, 1ULL, 2);
    switch (heff_tag_of(v_h1_242)) {
    case TAG_EVar: {
      V v_f_244 = heff_field(v_h1_242, 0);
      V v_ru_24h1_242_24EVar = heff_take_reuse_n(v_h1_242, 1ULL, 1);
      switch (heff_tag_of(v_args_241)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24h_240_24At, 2);
        heff_drop(v_f_244);
        heff_drop_cell(v_ru_24h1_242_24EVar, 1);
        return v_args_241;
      }
      case TAG_Cons: {
        V v_args1_245 = heff_dup(heff_field(v_args_241, 0));
        V v_args2_246 = heff_dup(heff_field(v_args_241, 1));
        switch (heff_tag_of(v_args1_245)) {
        case TAG_At: {
          V v_args11_247 = heff_field(v_args1_245, 0);
          V v_dsp_248 = heff_field(v_args1_245, 1);
          V v_ru_24args1_245_24At = heff_take_reuse_n(v_args1_245, 3ULL, 2);
          switch (heff_tag_of(v_args11_247)) {
          case TAG_EVar: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENotationVar: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETag: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EInt: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EFloat: {
            heff_take_nf(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EString: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EBinary: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ERune: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWord: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EApp: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EProject: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENamed: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EPi: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELam: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EAnn: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESpec: {
            heff_take_n(v_args11_247, 0ULL, 4);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESig: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESum: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EStruct: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EUpdate: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EMatch: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELetIn: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EDo: {
            V v_ss_2445 = heff_field(v_args11_247, 0);
            V v_ru_24args11_247_24EDo = heff_take_reuse_n(v_args11_247, 1ULL, 1);
            switch (heff_tag_of(v_args2_246)) {
            case TAG_Nil: {
              heff_drop_tag(v_args_241, 2);
              if (heff_strEq_c(v_f_244, ((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str0))) {
                V v_sp_2446 = heff_dup(v_dsp_248);
                V v_stmts_2447 = v_ss_2445;
                V v_x1_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_2447)));
                V v_x2_2467;
                switch (heff_tag_of(v_x1_2448)) {
                case TAG_Nil: {
                  heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                  heff_drop(v_sp_2446);
                  heff_drop(v_stmts_2447);
                  v_x2_2467 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2449 = heff_field(v_x1_2448, 0);
                  heff_take_n(v_x1_2448, 1ULL, 2);
                  switch (heff_tag_of(v_x_2449)) {
                  case TAG_At: {
                    V v_it11_2451 = heff_field(v_x_2449, 0);
                    heff_take_n(v_x_2449, 1ULL, 2);
                    switch (heff_tag_of(v_it11_2451)) {
                    case TAG_StmtBind: {
                      heff_take_n(v_it11_2451, 0ULL, 3);
                      heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                      heff_drop(v_sp_2446);
                      heff_drop(v_stmts_2447);
                      v_x2_2467 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_StmtLet: {
                      heff_take_n(v_it11_2451, 0ULL, 2);
                      heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                      heff_drop(v_sp_2446);
                      heff_drop(v_stmts_2447);
                      v_x2_2467 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_StmtExpr: {
                      heff_take_n(v_it11_2451, 0ULL, 1);
                      V v_t_2459 = heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eidNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_sp_2446, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
                      V v_t_2460 = ({ V a_0 = v_t_2459; V a_1 = v_stmts_2447; V a_2 = NTAG(TAG_EndValue); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_stmts_2447); r_; });
                      v_x2_2467 = heff_tag_at_n(v_ru_24h1_242_24EVar, TAG_Just, 1, (V[]){v_t_2460});
                      break;
                    }
                    case TAG_StmtLetMut: {
                      heff_take_n(v_it11_2451, 0ULL, 3);
                      heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                      heff_drop(v_sp_2446);
                      heff_drop(v_stmts_2447);
                      v_x2_2467 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_StmtLetElse: {
                      heff_take_n(v_it11_2451, 0ULL, 3);
                      heff_drop_cell(v_ru_24h1_242_24EVar, 1);
                      heff_drop(v_sp_2446);
                      heff_drop(v_stmts_2447);
                      v_x2_2467 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_it11_2451);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x_2449);
                  }
                  break;
                }
                default: heff_nomatch(v_x1_2448);
                }
                V v_t_2469;
                switch (heff_tag_of(v_x2_2467)) {
                case TAG_Nothing: {
                  v_t_2469 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24args11_247_24EDo, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str1)}), v_dsp_248});
                  break;
                }
                case TAG_Just: {
                  V v_x_2468 = heff_field(v_x2_2467, 0);
                  heff_take_n(v_x2_2467, 1ULL, 1);
                  heff_drop_cell(v_ru_24h_240_24At, 2);
                  heff_drop(v_dsp_248);
                  heff_drop_cell(v_ru_24args11_247_24EDo, 1);
                  v_t_2469 = v_x_2468;
                  break;
                }
                default: heff_nomatch(v_x2_2467);
                }
                return heff_tag_at_n(v_ru_24args1_245_24At, TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
              } else {
                heff_drop_cell(v_ru_24args11_247_24EDo, 1);
                V v_t_2470 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_242_24EVar, TAG_EDo, 1, (V[]){v_ss_2445}), v_dsp_248});
                return heff_tag_at_n(v_ru_24args1_245_24At, TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
              }
            }
            case TAG_Cons: {
              heff_take_n(v_args2_246, 0ULL, 2);
              heff_drop_cell(v_ru_24h_240_24At, 2);
              heff_drop(v_f_244);
              heff_drop_cell(v_ru_24h1_242_24EVar, 1);
              heff_drop(v_dsp_248);
              heff_drop_cell(v_ru_24args1_245_24At, 2);
              heff_drop(v_ss_2445);
              heff_drop_cell(v_ru_24args11_247_24EDo, 1);
              return v_args_241;
            }
            default: return heff_nomatch(v_args2_246);
            }
          }
          case TAG_ELocal: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EInvalid: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EAssign: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWhile: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EFor: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EIfThen: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EBreak: {
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EContinue: {
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EReturn: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENest: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELazy: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETuple: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETry: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWith: {
            heff_take_n(v_args11_247, 0ULL, 4);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWithBound: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop_cell(v_ru_24h1_242_24EVar, 1);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          default: return heff_nomatch(v_args11_247);
          }
        }
        default: return heff_nomatch(v_args1_245);
        }
      }
      default: return heff_nomatch(v_args_241);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENotationVar: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETag: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EInt: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EFloat: {
      heff_take_nf(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EString: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EBinary: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ERune: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWord: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EApp: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EProject: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENamed: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EPi: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELam: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EAnn: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_242, 0ULL, 4);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESig: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESum: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EStruct: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EUpdate: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELetIn: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EDo: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELocal: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EInvalid: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EAssign: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWhile: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EFor: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EIfThen: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EReturn: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENest: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELazy: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETuple: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETry: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWith: {
      heff_take_n(v_h1_242, 0ULL, 4);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWithBound: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    default: return heff_nomatch(v_h1_242);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2erunArgs(a[0], a[1]);
}

HeffT3 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IsInferable: {
    V v_b_245 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_IAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_b_245}), v_sp_244}});
  }
  case TAG_IsCheckable: {
    V v_t_2416;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_247 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2410;
      switch (heff_tag_of(v_i_247)) {
      case TAG_At: {
        V v_s_249 = heff_dup(heff_field(v_i_247, 1));
        v_t_2410 = v_s_249;
        break;
      }
      default: heff_nomatch(v_i_247);
      }
      v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2411 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2416 = v_c_2411;
      break;
    }
    case TAG_IsType: {
      V v_t_2412 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_t_2412)) {
      case TAG_At: {
        V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2416}), v_sp_244}});
  }
  case TAG_IsType: {
    V v_t_2427;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_2418 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2421;
      switch (heff_tag_of(v_i_2418)) {
      case TAG_At: {
        V v_s_2420 = heff_dup(heff_field(v_i_2418, 1));
        v_t_2421 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_i_2418);
      }
      v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_2418}), v_t_2421});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2422 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2427 = v_c_2422;
      break;
    }
    case TAG_IsType: {
      V v_t_2423 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_t_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_t_2423, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_t_2423);
      }
      v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2423}), v_t_2426});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2427}), v_sp_244}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x4_243)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str3, 0, "");

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_size_243 = heff_field(v_x1_240, 2);
    V v_little_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_EVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EImplicitVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENotationVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        V v_v_2414 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          V v_x1_2415 = heff_dup(v_size_243);
          V v_little_2416 = heff_dup(v_little_244);
          V v_v_2417 = heff_dup(v_v_2414);
          switch (heff_tag_of(v_x1_2415)) {
          case TAG_SizeDefault: {
            V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
            V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
            V v_t_2420 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
            V v_t_2421 = heff_intAdd(heff_intMod(v_v_2417, v_t_2418), v_t_2419);
            V v_b_2422 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_box_word((((int64_t)8ULL) / ((int64_t)8ULL))), heff_intMod(v_t_2421, v_t_2420), ((V)&g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str0)));
            V v_t_2423;
            if ((heff_dup(v_little_2416) == NTAG(TAG_True))) {
              heff_drop(v_little_2416);
              v_t_2423 = ({ V a_0 = v_b_2422; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str1); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2422); r_; });
            } else {
              heff_drop(v_little_2416);
              v_t_2423 = v_b_2422;
            }
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2423}});
          }
          case TAG_SizeNumber: {
            V v_n_2424 = heff_field(v_x1_2415, 0);
            heff_take_n(v_x1_2415, 1ULL, 1);
            if ((heff_unbox_word(heff_intMod_lent(v_n_2424, MK_INT(8LL), 2)) == ((int64_t)0ULL))) {
              V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_2424)));
              V v_t_2426 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_2424)));
              V v_t_2427 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_2424)));
              V v_t_2428 = heff_intAdd(heff_intMod(v_v_2417, v_t_2425), v_t_2426);
              V v_b_2429 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv(v_n_2424, MK_INT(8LL)), heff_intMod(v_t_2428, v_t_2427), ((V)&g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str2)));
              V v_t_2430;
              if ((heff_dup(v_little_2416) == NTAG(TAG_True))) {
                heff_drop(v_little_2416);
                v_t_2430 = ({ V a_0 = v_b_2429; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr_str3); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2429); r_; });
              } else {
                heff_drop(v_little_2416);
                v_t_2430 = v_b_2429;
              }
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2430}});
            } else {
              heff_drop(v_little_2416);
              heff_drop(v_v_2417);
              heff_drop(v_n_2424);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_SizeName: {
            heff_take_n(v_x1_2415, 0ULL, 3);
            heff_drop(v_little_2416);
            heff_drop(v_v_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2415)}});
          }
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2434 = heff_field(v_x12_242, 0);
          if (heff_intEq_c_lent(v_x121_2434, MK_INT(8LL), 2)) {
            V v_t_2435 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_v_2414)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2435}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EFloat: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EString: {
        V v_s_2437 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_size_243)) {
          case TAG_SizeDefault: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_s_2437)}});
          }
          case TAG_SizeNumber: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SizeName: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_size_243)}});
          }
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EBinary: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERune: {
        V v_c_2444 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2445 = heff_field(v_x12_242, 0);
          if (heff_intEq_c_lent(v_x121_2445, MK_INT(8LL), 2)) {
            V v_t_2446 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_c_2444)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2446}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EWord: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProject: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENamed: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPi: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAnn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESpec: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESig: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESum: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStruct: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EUpdate: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELetIn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EDo: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELocal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInvalid: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAssign: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWhile: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFor: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EIfThen: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBreak: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EContinue: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EReturn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENest: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELazy: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETuple: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETry: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWith: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWithBound: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x111_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esizeTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esizeTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2esizeTerm(V v_x1_240, V v_x2_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x2_241}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_243}), v_sp_242});
  }
  case TAG_SizeNumber: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_x2_241);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){v_m_244}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_245}), v_sp_242});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    heff_drop(v_x2_241);
    if (heff_intEq_c_lent(v_x13_248, MK_INT(1LL), 2)) {
      heff_drop(v_sp_242);
      heff_drop(v_x13_248);
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), v_xsp_247});
    } else {
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esizeTerm_str0)}), heff_dup(v_sp_242)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2412}), heff_dup(v_sp_242)});
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x13_248}), heff_dup(v_sp_242)});
      V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2414}), heff_dup(v_sp_242)});
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2415}), heff_dup(v_sp_242)});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      V v_t_2418 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_242)})});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_242});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2esizeTerm(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_IAnn: {
    V v_c_242 = heff_field(v_n_241, 0);
    V v_t_243 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IAnn = heff_take_reuse_n(v_n_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_c_242)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_c_242, 0);
      V v_sp_245 = heff_field(v_c_242, 1);
      heff_take_n(v_c_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_243, 0);
      V v_sp_248 = heff_field(v_t_243, 1);
      V v_ru_24t_243_24At = heff_take_reuse_n(v_t_243, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_243_24At, v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IAnn, TAG_IAnn, 2, (V[]){v_t_246, v_t_249}), v_sp_240});
  }
  case TAG_IInvalid: {
    V v_code_2410 = heff_field(v_n_241, 0);
    V v_why_2411 = heff_field(v_n_241, 1);
    V v_note_2412 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24IInvalid = heff_take_reuse_n(v_n_241, 7ULL, 3);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24n_241_24IInvalid, TAG_IInvalid, 3, 7ULL, (V[]){v_code_2410, v_why_2411, v_note_2412}), v_sp_240});
  }
  default: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2414 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(a[0], a[1]);
}