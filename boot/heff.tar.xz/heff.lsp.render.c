// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_line 9817275
#define LBL_off 319465
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
static uint32_t shape_line__off__col[] = {LBL_line, LBL_off, LBL_col};
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2efirstLines(V, V, V, V, V);
V g_heff_2elsp_2erender_2efirstLines_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2efirstLines_clo;
V g_heff_2elsp_2erender_2einsideLine(V, V, V, V, V);
V g_heff_2elsp_2erender_2einsideLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2einsideLine_clo;
V g_heff_2elsp_2erender_2einsideRange(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2einsideRange_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2einsideRange_clo;
V g_heff_2elsp_2erender_2einsideRange_24dps(V, V, V, V, V, V, V);
V g_heff_2elsp_2erender_2einsideRange_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2einsideRange_24dps_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineStartFrom(V, V, V);
V g_heff_2elsp_2erender_2elineStartFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineStartFrom_clo;
V g_heff_2elsp_2erender_2elineText(V, V);
V g_heff_2elsp_2erender_2elineText_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineText_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2eoneLineIn(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2erender_2eoneLineIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eoneLineIn_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2elsp_2erender_2erepeated_24acc(V, V, V);
V g_heff_2elsp_2erender_2erepeated_24acc_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_24acc_clo;
V g_heff_2elsp_2erender_2espanLines(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2espanLines_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2espanLines_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
HEFF_LIT(g_heff_2elsp_2erender_2elineColAt_24cpr_str0, 1, "\012");

HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V v_src_240, V v_i_241, V v_l_242, V v_start_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_start_243), v_i_241, MK_INT(0LL)));
    V v_f_246 = heff_intSub_lent(v_i_241, v_start_243, 2);
    return ((HeffT3){{v_l_242, v_f_246, v_t_245}});
  }
  case TAG_Just: {
    V v_nl_247 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24Just = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    if (heff_intLe_c_lent(v_i_241, v_nl_247, 0)) {
      heff_drop(v_nl_247);
      heff_drop_cell(v_ru_24x5_244_24Just, 1);
      V v_t_248 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, heff_dup(v_start_243), v_i_241, MK_INT(0LL)));
      V v_f_249 = heff_intSub_lent(v_i_241, v_start_243, 2);
      return ((HeffT3){{v_l_242, v_f_249, v_t_248}});
    } else {
      heff_drop(v_start_243);
      V v_j_2410 = heff_strFind_lent(((V)&g_heff_2elsp_2erender_2elineColAt_24cpr_str0), v_src_240, heff_intAdd_lent(v_nl_247, MK_INT(1LL), 2), 5);
      V v_t_2411;
      if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
        heff_drop_cell(v_ru_24x5_244_24Just, 1);
        heff_drop(v_j_2410);
        v_t_2411 = NTAG(TAG_Nothing);
      } else {
        v_t_2411 = heff_tag_at_n(v_ru_24x5_244_24Just, TAG_Just, 1, (V[]){v_j_2410});
      }
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_nl_247, MK_INT(1LL));
      V t_4 = v_t_2411;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x5_244)}});
  }
}
Clo g_heff_2elsp_2erender_2elineColAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2elineColAt_entry, 5, 0};

V g_heff_2elsp_2erender_2elineColAt(V v_src_240, V v_i_241, V v_l_242, V v_start_243, V v_x5_244) {
top: ;
  HeffT3 v_t_245 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_240, v_i_241, v_l_242, v_start_243, v_x5_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    return heff_rec_n(3, shape_line__off__col, (V[]){v_field_246, v_field_247, v_field_248});
  }
}
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2elsp_2erender_2elineColAt(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2erender_2enumDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2enumDigits_entry, 1, 0};

V g_heff_2elsp_2erender_2enumDigits(V v_x_240) {
top: ;
  if (heff_intLt_c_lent(v_x_240, MK_INT(10LL), 2)) {
    heff_drop(v_x_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2elsp_2erender_2enumDigits(heff_intDiv(v_x_240, MK_INT(10LL))));
    return heff_intAdd(MK_INT(1LL), v_t_241);
  }
}
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2enumDigits(a[0]);
}
HEFF_LIT(g_heff_2elsp_2erender_2erepeated_str0, 0, "");
Clo g_heff_2elsp_2erender_2erepeated_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2erepeated_entry, 2, 0};

V g_heff_2elsp_2erender_2erepeated(V v_k_240, V v_c_241) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    heff_drop(v_c_241);
    return ((V)&g_heff_2elsp_2erender_2erepeated_str0);
  } else {
    V v_s_242 = heff_dup(v_c_241);
    return ({ V a_0 = heff_intSub(v_k_240, MK_INT(1LL)); V a_1 = v_c_241; V a_2 = v_s_242; V r_ = (g_heff_2elsp_2erender_2erepeated_24acc(a_0, a_1, a_2)); heff_drop(v_c_241); r_; });
  }
}
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2erepeated(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2erender_2erepeated_24acc_str0, 0, "");
Clo g_heff_2elsp_2erender_2erepeated_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2erepeated_24acc_entry, 3, 0};

V g_heff_2elsp_2erender_2erepeated_24acc(V v_k_240, V v_c_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return heff_strAppend(v_acc_242, ((V)&g_heff_2elsp_2erender_2erepeated_24acc_str0));
  } else {
    V v_s_243 = heff_strAppend(v_acc_242, heff_dup(v_c_241));
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_c_241;
    V t_2 = v_s_243;
    v_k_240 = t_0;
    v_c_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2erender_2erepeated_24acc_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2erender_2erepeated_24acc(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2elineStartFrom_str0, 1, "\012");
Clo g_heff_2elsp_2erender_2elineStartFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2elineStartFrom_entry, 3, 0};

V g_heff_2elsp_2erender_2elineStartFrom(V v_src_240, V v_l_241, V v_start_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2elsp_2erender_2elineStartFrom_str0), v_src_240, v_start_242, 5);
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_l_241);
    heff_drop(v_j_243);
    return heff_strLength_lent(v_src_240, 0);
  } else {
    if (heff_intEq_c_lent(v_l_241, MK_INT(1LL), 2)) {
      heff_drop(v_l_241);
      return heff_intAdd(v_j_243, MK_INT(1LL));
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_l_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_j_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_l_241 = t_1;
      v_start_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2elsp_2erender_2elineStartFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2elineStartFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2elineText_str0, 1, "\012");
Clo g_heff_2elsp_2erender_2elineText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2elineText_entry, 2, 0};

V g_heff_2elsp_2erender_2elineText(V v_src_240, V v_l_241) {
top: ;
  V v_t_242;
  if (heff_intEq_c_lent(v_l_241, MK_INT(0LL), 2)) {
    v_t_242 = MK_INT(0LL);
  } else {
    v_t_242 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_240, heff_dup(v_l_241), MK_INT(0LL)));
  }
  V v_start_243;
  if (heff_intEq_c_lent(v_l_241, MK_INT(0LL), 2)) {
    heff_drop(v_l_241);
    v_start_243 = MK_INT(0LL);
  } else {
    v_start_243 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_240, v_l_241, MK_INT(0LL)));
  }
  V v_j_244 = heff_strFind_lent(((V)&g_heff_2elsp_2erender_2elineText_str0), v_src_240, v_start_243, 5);
  V v_t_245;
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    v_t_245 = heff_strLength_lent(v_src_240, 0);
  } else {
    v_t_245 = v_j_244;
  }
  return heff_strSlice_lent(v_src_240, v_t_242, v_t_245, 6);
}
V g_heff_2elsp_2erender_2elineText_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2elineText(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str1, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str2, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str3, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str4, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str5, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str6, 1, "|");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str7, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str8, 1, "|");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str9, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2einsideLine_str10, 1, " ");
Clo g_heff_2elsp_2erender_2einsideLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2einsideLine_entry, 5, 0};

V g_heff_2elsp_2erender_2einsideLine(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244) {
top: ;
  V v_t_245 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd_lent(v_l_244, MK_INT(1LL), 2)));
  V v_t_246 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(v_w_243, v_t_245), ((V)&g_heff_2elsp_2erender_2einsideLine_str0)));
  V v_t_247 = heff_intShow(heff_intAdd_lent(v_l_244, MK_INT(1LL), 2));
  V v_s_248 = heff_strAppend(heff_strAppend(v_t_247, v_t_246), ((V)&g_heff_2elsp_2erender_2einsideLine_str1));
  V v_t_249;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2einsideLine_str2), v_s_248), ((V)&g_heff_2elsp_2erender_2einsideLine_str3));
  } else {
    v_t_249 = v_s_248;
  }
  V v_t_2411;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2einsideLine_str4), v_code_241), ((V)&g_heff_2elsp_2erender_2einsideLine_str5));
    v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2erender_2einsideLine_str6)), ((V)&g_heff_2elsp_2erender_2einsideLine_str7));
  } else {
    heff_drop(v_code_241);
    v_t_2411 = ((V)&g_heff_2elsp_2erender_2einsideLine_str8);
  }
  V v_t_2412 = (g_heff_2elsp_2erender_2elineText(v_src_242, v_l_244));
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2erender_2einsideLine_str9)), v_t_2411);
  return heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2erender_2einsideLine_str10)), v_t_2412);
}
V g_heff_2elsp_2erender_2einsideLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2elsp_2erender_2einsideLine(a0, a[1], a2, a[3], a[4]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2elsp_2erender_2einsideRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2einsideRange_entry, 6, 0};

V g_heff_2elsp_2erender_2einsideRange(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244, V v_le_245) {
top: ;
  if (heff_intLt_c_lent(v_le_245, v_l_244, 0)) {
    heff_drop(v_code_241);
    heff_drop(v_w_243);
    heff_drop(v_l_244);
    heff_drop(v_le_245);
    return NTAG(TAG_Nil);
  } else {
    V v_t_246 = (g_heff_2elsp_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), v_src_242, heff_dup(v_w_243), heff_dup(v_l_244)));
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = ({ V a_0 = v_color_240; V a_1 = v_code_241; V a_2 = v_src_242; V a_3 = v_w_243; V a_4 = heff_intAdd(v_l_244, MK_INT(1LL)); V a_5 = v_le_245; V a_6 = v_cell_247; V r_ = (g_heff_2elsp_2erender_2einsideRange_24dps(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_code_241); heff_drop(v_w_243); heff_drop(v_le_245); r_; });
    heff_drop(v_u_248);
    return v_cell_247;
  }
}
V g_heff_2elsp_2erender_2einsideRange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2elsp_2erender_2einsideRange(a0, a[1], a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2elsp_2erender_2einsideRange_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2einsideRange_24dps_entry, 7, 0};

V g_heff_2elsp_2erender_2einsideRange_24dps(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244, V v_le_245, V v_d_246) {
top: ;
  if (heff_intLt_c_lent(v_le_245, v_l_244, 0)) {
    heff_drop(v_l_244);
    return heff_setField(heff_dup(v_d_246), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_247 = (g_heff_2elsp_2erender_2einsideLine(v_color_240, heff_dup(v_code_241), v_src_242, heff_dup(v_w_243), heff_dup(v_l_244)));
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_246, MK_INT(1LL), v_cell_248);
    V t_0 = v_color_240;
    V t_1 = v_code_241;
    V t_2 = v_src_242;
    V t_3 = v_w_243;
    V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
    V t_5 = v_le_245;
    V t_6 = v_u_249;
    v_color_240 = t_0;
    v_code_241 = t_1;
    v_src_242 = t_2;
    v_w_243 = t_3;
    v_l_244 = t_4;
    v_le_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
}
V g_heff_2elsp_2erender_2einsideRange_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a5 = a[5]; V a6 = a[6]; V r = g_heff_2elsp_2erender_2einsideRange_24dps(a0, a1, a2, a3, a[4], a5, a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a5); heff_drop(a6); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str1, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str2, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str3, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str4, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str5, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str6, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str7, 1, "/");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str8, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str9, 1, "/");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str10, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str11, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str12, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str13, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str14, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str15, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str16, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str17, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str18, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str19, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str20, 1, "_");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str21, 1, "^");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str22, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str23, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str24, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str25, 3, "   ");
HEFF_LIT(g_heff_2elsp_2erender_2efirstLines_str26, 2, "  ");
Clo g_heff_2elsp_2erender_2efirstLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2efirstLines_entry, 5, 0};

V g_heff_2elsp_2erender_2efirstLines(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_s_244) {
top: ;
  V v_src_245 = heff_dup(v_src_242);
  V v_s_246 = heff_dup(v_s_244);
  V v_line_247 = heff_take_field(v_s_246, 0);
  V v_off_248 = heff_get_n(v_s_246, 1, 3);
  V v_l_249 = heff_dup(v_line_247);
  V v_t_2410;
  if (heff_intEq_c_lent(v_l_249, MK_INT(0LL), 2)) {
    heff_drop(v_l_249);
    v_t_2410 = MK_INT(0LL);
  } else {
    v_t_2410 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_245, v_l_249, MK_INT(0LL)));
  }
  V v_l_2411 = v_line_247;
  V v_t_2412;
  if (heff_intEq_c_lent(v_l_2411, MK_INT(0LL), 2)) {
    heff_drop(v_l_2411);
    v_t_2412 = MK_INT(0LL);
  } else {
    v_t_2412 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_245, v_l_2411, MK_INT(0LL)));
  }
  V v_s_2413 = heff_strSlice(v_src_245, v_t_2410, heff_intAdd(v_t_2412, v_off_248));
  V v_t_2414 = (g_prelude_2eskipSpaces(v_s_2413, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_s_2413, 0)) - ((int64_t)1ULL));
  V v_t_2416 = (g_prelude_2eskipSpaces(v_s_2413, heff_box_word(v_t_2415), MK_INT(-1LL)));
  V v_t_2417 = heff_strSlice(v_s_2413, v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
  if (heff_strEq_c(v_t_2417, ((V)&g_heff_2elsp_2erender_2efirstLines_str0))) {
    V v_l_2418 = heff_dup(heff_rfield(v_s_244, 0));
    V v_t_2419 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd_lent(v_l_2418, MK_INT(1LL), 2)));
    V v_t_2420 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(v_w_243, v_t_2419), ((V)&g_heff_2elsp_2erender_2efirstLines_str1)));
    V v_t_2421 = heff_intShow(heff_intAdd(v_l_2418, MK_INT(1LL)));
    V v_s_2422 = heff_strAppend(heff_strAppend(v_t_2421, v_t_2420), ((V)&g_heff_2elsp_2erender_2efirstLines_str2));
    V v_t_2423;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str3), v_s_2422), ((V)&g_heff_2elsp_2erender_2efirstLines_str4));
    } else {
      v_t_2423 = v_s_2422;
    }
    V v_t_2425;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str5), v_code_241), ((V)&g_heff_2elsp_2erender_2efirstLines_str6));
      v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2elsp_2erender_2efirstLines_str7)), ((V)&g_heff_2elsp_2erender_2efirstLines_str8));
    } else {
      heff_drop(v_code_241);
      v_t_2425 = ((V)&g_heff_2elsp_2erender_2efirstLines_str9);
    }
    V v_t_2426 = ({ V a_0 = v_src_242; V a_1 = heff_get_n(v_s_244, 0, 3); V r_ = (g_heff_2elsp_2erender_2elineText(a_0, a_1)); heff_drop(v_src_242); r_; });
    V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2elsp_2erender_2efirstLines_str10)), v_t_2425);
    V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2elsp_2erender_2efirstLines_str11)), v_t_2426);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
  } else {
    V v_l_2429 = heff_dup(heff_rfield(v_s_244, 0));
    V v_t_2430 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd_lent(v_l_2429, MK_INT(1LL), 2)));
    V v_t_2431 = (g_heff_2elsp_2erender_2erepeated(heff_intSub_lent(v_w_243, v_t_2430, 2), ((V)&g_heff_2elsp_2erender_2efirstLines_str12)));
    V v_t_2432 = heff_intShow(heff_intAdd(v_l_2429, MK_INT(1LL)));
    V v_s_2433 = heff_strAppend(heff_strAppend(v_t_2432, v_t_2431), ((V)&g_heff_2elsp_2erender_2efirstLines_str13));
    V v_t_2434;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str14), v_s_2433), ((V)&g_heff_2elsp_2erender_2efirstLines_str15));
    } else {
      v_t_2434 = v_s_2433;
    }
    V v_t_2435 = ({ V a_0 = v_src_242; V a_1 = heff_take_field(v_s_244, 0); V r_ = (g_heff_2elsp_2erender_2elineText(a_0, a_1)); heff_drop(v_src_242); r_; });
    V v_t_2436 = (g_heff_2elsp_2erender_2erepeated(v_w_243, ((V)&g_heff_2elsp_2erender_2efirstLines_str16)));
    V v_s_2437 = heff_strAppend(v_t_2436, ((V)&g_heff_2elsp_2erender_2efirstLines_str17));
    V v_t_2438;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str18), v_s_2437), ((V)&g_heff_2elsp_2erender_2efirstLines_str19));
    } else {
      v_t_2438 = v_s_2437;
    }
    V v_t_2439 = heff_intAdd(heff_get_n(v_s_244, 2, 3), MK_INT(1LL));
    V v_t_2440 = (g_heff_2elsp_2erender_2erepeated(v_t_2439, ((V)&g_heff_2elsp_2erender_2efirstLines_str20)));
    V v_s_2441 = heff_strAppend(v_t_2440, ((V)&g_heff_2elsp_2erender_2efirstLines_str21));
    V v_t_2443;
    if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
      V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2efirstLines_str22), v_code_241), ((V)&g_heff_2elsp_2erender_2efirstLines_str23));
      v_t_2443 = heff_strAppend(heff_strAppend(v_t_2442, v_s_2441), ((V)&g_heff_2elsp_2erender_2efirstLines_str24));
    } else {
      heff_drop(v_code_241);
      v_t_2443 = v_s_2441;
    }
    V v_t_2444 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2elsp_2erender_2efirstLines_str25)), v_t_2435);
    V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2elsp_2erender_2efirstLines_str26)), v_t_2443);
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, v_t_2446});
  }
}
V g_heff_2elsp_2erender_2efirstLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2erender_2efirstLines(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str1, 3, "...");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str2, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str3, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str4, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str5, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str6, 1, "|");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str7, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str8, 1, "|");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str9, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str10, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str11, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str12, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str13, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str14, 1, "_");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str15, 1, "|");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str16, 1, "^");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str17, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str18, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str19, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str20, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2erender_2espanLines_str22, 1, "\012");
Clo g_heff_2elsp_2erender_2espanLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2espanLines_entry, 6, 0};

V g_heff_2elsp_2erender_2espanLines(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_s_244, V v_e_245) {
top: ;
  V v_line_246 = heff_take_field(v_e_245, 0);
  V v_col_247 = heff_get_n(v_e_245, 2, 3);
  V v_t_248 = (g_heff_2elsp_2erender_2efirstLines(v_color_240, heff_dup(v_code_241), heff_dup(v_src_242), heff_dup(v_w_243), heff_dup(v_s_244)));
  V v_color_249 = heff_dup(v_color_240);
  V v_code_2410 = heff_dup(v_code_241);
  V v_src_2411 = heff_dup(v_src_242);
  V v_w_2412 = heff_dup(v_w_243);
  V v_ls_2413 = heff_get_n(v_s_244, 0, 3);
  V v_le_2414 = heff_dup(v_line_246);
  V v_t_2415 = heff_intAdd(heff_intSub_lent(v_le_2414, v_ls_2413, 0), MK_INT(1LL));
  V v_t_2428;
  if (heff_intLt_c(MK_INT(6LL), v_t_2415)) {
    V v_t_2416 = (g_heff_2elsp_2erender_2einsideLine(v_color_249, heff_dup(v_code_2410), v_src_2411, heff_dup(v_w_2412), heff_intAdd(v_ls_2413, MK_INT(1LL))));
    V v_color_2417 = heff_dup(v_color_249);
    V v_code_2418 = heff_dup(v_code_2410);
    V v_w_2419 = heff_dup(v_w_2412);
    V v_t_2420 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(v_w_2419, MK_INT(1LL)), ((V)&g_heff_2elsp_2erender_2espanLines_str0)));
    V v_s_2421 = heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str1), v_t_2420);
    V v_t_2422;
    if ((heff_dup(v_color_2417) == NTAG(TAG_True))) {
      v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str2), v_s_2421), ((V)&g_heff_2elsp_2erender_2espanLines_str3));
    } else {
      v_t_2422 = v_s_2421;
    }
    V v_t_2424;
    if ((heff_dup(v_color_2417) == NTAG(TAG_True))) {
      heff_drop(v_color_2417);
      V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str4), v_code_2418), ((V)&g_heff_2elsp_2erender_2espanLines_str5));
      v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2elsp_2erender_2espanLines_str6)), ((V)&g_heff_2elsp_2erender_2espanLines_str7));
    } else {
      heff_drop(v_color_2417);
      heff_drop(v_code_2418);
      v_t_2424 = ((V)&g_heff_2elsp_2erender_2espanLines_str8);
    }
    V v_t_2425 = ({ V a_0 = v_color_249; V a_1 = v_code_2410; V a_2 = v_src_2411; V a_3 = v_w_2412; V a_4 = heff_intSub(v_le_2414, MK_INT(1LL)); V r_ = (g_heff_2elsp_2erender_2einsideLine(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_color_249); heff_drop(v_src_2411); r_; });
    V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2elsp_2erender_2espanLines_str9)), v_t_2424);
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2427})});
  } else {
    v_t_2428 = ({ V a_0 = v_color_249; V a_1 = v_code_2410; V a_2 = v_src_2411; V a_3 = v_w_2412; V a_4 = heff_intAdd(v_ls_2413, MK_INT(1LL)); V a_5 = heff_intSub(v_le_2414, MK_INT(1LL)); V r_ = (g_heff_2elsp_2erender_2einsideRange(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_color_249); heff_drop(v_src_2411); r_; });
  }
  V v_t_2429 = ({ V a_0 = v_color_240; V a_1 = heff_dup(v_code_241); V a_2 = v_src_242; V a_3 = heff_dup(v_w_243); V a_4 = v_line_246; V r_ = (g_heff_2elsp_2erender_2einsideLine(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_242); r_; });
  V v_t_2430 = (g_heff_2elsp_2erender_2erepeated(v_w_243, ((V)&g_heff_2elsp_2erender_2espanLines_str10)));
  V v_s_2431 = heff_strAppend(v_t_2430, ((V)&g_heff_2elsp_2erender_2espanLines_str11));
  V v_t_2432;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str12), v_s_2431), ((V)&g_heff_2elsp_2erender_2espanLines_str13));
  } else {
    v_t_2432 = v_s_2431;
  }
  V v_t_2433 = (g_heff_2elsp_2erender_2erepeated(heff_intAdd(v_col_247, MK_INT(1LL)), ((V)&g_heff_2elsp_2erender_2espanLines_str14)));
  V v_s_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str15), v_t_2433), ((V)&g_heff_2elsp_2erender_2espanLines_str16));
  V v_t_2436;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    heff_drop(v_color_240);
    V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2espanLines_str17), v_code_241), ((V)&g_heff_2elsp_2erender_2espanLines_str18));
    v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, v_s_2434), ((V)&g_heff_2elsp_2erender_2espanLines_str19));
  } else {
    heff_drop(v_color_240);
    heff_drop(v_code_241);
    v_t_2436 = v_s_2434;
  }
  V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2elsp_2erender_2espanLines_str20)), v_t_2436);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
  V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2438})));
  V v_x2_2440 = (g_prelude_2e_2b_2b(v_t_248, v_t_2439));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_Nil: {
    return ((V)&g_heff_2elsp_2erender_2espanLines_str21);
  }
  case TAG_Cons: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_xs_2442 = heff_field(v_x2_2440, 1);
    heff_take_n(v_x2_2440, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2elsp_2erender_2espanLines_str22); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2elsp_2erender_2espanLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2espanLines(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str0, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str1, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str2, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str3, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str4, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str5, 2, " |");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str6, 4, "\033[2m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str7, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str8, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str9, 1, "^");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str10, 2, "\033[");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str11, 1, "m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str12, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str13, 1, " ");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str14, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2eoneLineIn_str15, 1, " ");
Clo g_heff_2elsp_2erender_2eoneLineIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2eoneLineIn_entry, 8, 0};

V g_heff_2elsp_2erender_2eoneLineIn(V v_color_240, V v_code_241, V v_src_242, V v_w_243, V v_l_244, V v_ls_245, V v_b_246, V v_e_247) {
top: ;
  V v_t_248 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd_lent(v_l_244, MK_INT(1LL), 2)));
  V v_t_249 = (g_heff_2elsp_2erender_2erepeated(heff_intSub_lent(v_w_243, v_t_248, 2), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str0)));
  V v_t_2410 = heff_intShow(heff_intAdd_lent(v_l_244, MK_INT(1LL), 2));
  V v_s_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_t_249), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str1));
  V v_t_2412;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str2), v_s_2411), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str3));
  } else {
    v_t_2412 = v_s_2411;
  }
  V v_t_2413 = (g_heff_2elsp_2erender_2elineText(v_src_242, heff_dup(v_l_244)));
  V v_t_2414 = (g_heff_2elsp_2erender_2enumDigits(heff_intAdd_lent(v_l_244, MK_INT(1LL), 2)));
  V v_t_2415 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(v_w_243, v_t_2414), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str4)));
  V v_t_2416 = heff_intShow(heff_intAdd(v_l_244, MK_INT(1LL)));
  V v_s_2417 = heff_strAppend(heff_strAppend(v_t_2416, v_t_2415), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str5));
  V v_t_2418;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str6), v_s_2417), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str7));
  } else {
    v_t_2418 = v_s_2417;
  }
  V v_t_2419 = (g_heff_2eutil_2erune_2erunesGo(v_src_242, v_ls_245, v_b_246, MK_INT(0LL)));
  V v_t_2420 = (g_heff_2elsp_2erender_2erepeated(v_t_2419, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str8)));
  V v_y_2421 = (g_heff_2eutil_2erune_2erunesGo(v_src_242, v_b_246, v_e_247, MK_INT(0LL)));
  V v_t_2422;
  if (heff_intLe_c_lent(MK_INT(1LL), v_y_2421, 1)) {
    v_t_2422 = v_y_2421;
  } else {
    heff_drop(v_y_2421);
    v_t_2422 = MK_INT(1LL);
  }
  V v_s_2423 = (g_heff_2elsp_2erender_2erepeated(v_t_2422, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str9)));
  V v_t_2425;
  if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2erender_2eoneLineIn_str10), v_code_241), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str11));
    v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, v_s_2423), ((V)&g_heff_2elsp_2erender_2eoneLineIn_str12));
  } else {
    heff_drop(v_code_241);
    v_t_2425 = v_s_2423;
  }
  V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str13)), v_t_2413);
  V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str14)), v_t_2418);
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2elsp_2erender_2eoneLineIn_str15)), v_t_2420);
  return heff_strAppend(v_t_2428, v_t_2425);
}
V g_heff_2elsp_2erender_2eoneLineIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a7 = a[7]; V r = g_heff_2elsp_2erender_2eoneLineIn(a0, a[1], a2, a[3], a[4], a[5], a[6], a7); heff_drop(a0); heff_drop(a2); heff_drop(a7); return r;
}
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str0, 5, "error");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str1, 7, "warning");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str2, 5, "debug");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str3, 1, "E");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str4, 1, "W");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str5, 1, "D");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str6, 1, "0");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str7, 1, "[");
HEFF_LIT(g_heff_2elsp_2erender_2eprtCode_str8, 1, "]");
Clo g_heff_2elsp_2erender_2eprtCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2eprtCode_entry, 1, 0};

V g_heff_2elsp_2erender_2eprtCode(V v_d_240) {
top: ;
  V v_severity_241 = heff_take_field(v_d_240, 1);
  V v_code_242 = heff_get_n(v_d_240, 0, 5);
  V v_t_243 = heff_dup(v_severity_241);
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SError: {
    v_t_244 = ((V)&g_heff_2elsp_2erender_2eprtCode_str0);
    break;
  }
  case TAG_SWarning: {
    v_t_244 = ((V)&g_heff_2elsp_2erender_2eprtCode_str1);
    break;
  }
  case TAG_SDebug: {
    v_t_244 = ((V)&g_heff_2elsp_2erender_2eprtCode_str2);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = v_severity_241;
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_SError: {
    v_t_246 = ((V)&g_heff_2elsp_2erender_2eprtCode_str3);
    break;
  }
  case TAG_SWarning: {
    v_t_246 = ((V)&g_heff_2elsp_2erender_2eprtCode_str4);
    break;
  }
  case TAG_SDebug: {
    v_t_246 = ((V)&g_heff_2elsp_2erender_2eprtCode_str5);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_247 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(v_code_242)));
  V v_t_248 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_247), ((V)&g_heff_2elsp_2erender_2eprtCode_str6)));
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_246, v_t_248), heff_intShow(v_code_242));
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2elsp_2erender_2eprtCode_str7)), v_t_249);
  return heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2erender_2eprtCode_str8));
}
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2erender_2eprtCode(a[0]);
}
HEFF_LIT(g_heff_2elsp_2erender_2ediagWhere_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2ediagWhere_str1, 1, "\012");
HEFF_LIT(g_heff_2elsp_2erender_2ediagWhere_str2, 1, ":");
HEFF_LIT(g_heff_2elsp_2erender_2ediagWhere_str3, 1, ":");
Clo g_heff_2elsp_2erender_2ediagWhere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2erender_2ediagWhere_entry, 3, 0};

V g_heff_2elsp_2erender_2ediagWhere(V v_path_240, V v_src_241, V v_d_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2elsp_2erender_2ediagWhere_str0), v_src_241, MK_INT(0LL), 5);
  V v_t_244;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_244 = NTAG(TAG_Nothing);
  } else {
    v_t_244 = heff_tag_n(TAG_Just, 1, (V[]){v_j_243});
  }
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_d_242, 3)), 0, 2);
  HeffT3 v_t_246 = ({ V a_0 = v_src_241; V a_1 = v_t_245; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_244; HeffT3 r_ = (g_heff_2elsp_2erender_2elineColAt_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_245); r_; });
  {
    V v_field_247 = v_t_246.f[0];
    heff_drop(v_t_246.f[1]);
    heff_drop(v_t_246.f[2]);
    V v_j_2410 = heff_strFind_lent(((V)&g_heff_2elsp_2erender_2ediagWhere_str1), v_src_241, MK_INT(0LL), 5);
    V v_t_2411;
    if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
      heff_drop(v_j_2410);
      v_t_2411 = NTAG(TAG_Nothing);
    } else {
      v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2410});
    }
    V v_t_2412 = heff_get_n(heff_get_n(v_d_242, 3, 5), 0, 2);
    HeffT3 v_t_2413 = ({ V a_0 = v_src_241; V a_1 = v_t_2412; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_2411; HeffT3 r_ = (g_heff_2elsp_2erender_2elineColAt_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2412); r_; });
    {
      V v_field_2416 = v_t_2413.f[2];
      heff_drop(v_t_2413.f[0]);
      heff_drop(v_t_2413.f[1]);
      V v_t_2417 = heff_intShow(heff_intAdd(v_field_247, MK_INT(1LL)));
      V v_t_2418 = heff_strAppend(heff_strAppend(v_path_240, ((V)&g_heff_2elsp_2erender_2ediagWhere_str2)), v_t_2417);
      V v_t_2419 = heff_intShow(heff_intAdd(v_field_2416, MK_INT(1LL)));
      return heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2elsp_2erender_2ediagWhere_str3)), v_t_2419);
    }
  }
}
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2erender_2ediagWhere(a[0], a1, a[2]); heff_drop(a1); return r;
}