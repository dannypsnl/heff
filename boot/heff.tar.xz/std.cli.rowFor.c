// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2ecli_2ecellOf(V, V, V, V, V, V);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2erowFor_2enextGo_240(V, V, V, V, V, V);
V g_std_2ecli_2erowFor_2enextGo_240_entry(V self, V *a);
extern Clo g_std_2ecli_2erowFor_2enextGo_240_clo;
V g_std_2ecli_2erowFor_2enextGo_240_24dps(V, V, V, V, V, V, V);
V g_std_2ecli_2erowFor_2enextGo_240_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2erowFor_2enextGo_240_24dps_clo;
Clo g_std_2ecli_2erowFor_2enextGo_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2erowFor_2enextGo_240_entry, 6, 0};

V g_std_2ecli_2erowFor_2enextGo_240(V v_a_240, V v_c_241, V v_x2_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_up_246 = heff_field(v_x2_242, 0);
    V v_ups_247 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_246), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_t_249 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_246), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2411 = ({ V a_0 = v_a_240; V a_1 = v_c_241; V a_2 = v_ups_247; V a_3 = v_up_246; V a_4 = v_t_249; V a_5 = heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))); V a_6 = v_cell_2410; V r_ = (g_std_2ecli_2erowFor_2enextGo_240_24dps(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_241); r_; });
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_std_2ecli_2erowFor_2enextGo_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2erowFor_2enextGo_240(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2erowFor_2enextGo_240_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2erowFor_2enextGo_240_24dps_entry, 7, 0};

V g_std_2ecli_2erowFor_2enextGo_240_24dps(V v_a_240, V v_c_241, V v_x2_242, V v_diag_243, V v_left_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return heff_setField(heff_dup(v_d_246), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_up_247 = heff_field(v_x2_242, 0);
    V v_ups_248 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_249 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_247), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_t_2410 = (g_std_2ecli_2ecellOf(v_a_240, heff_dup(v_c_241), heff_dup(v_up_247), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_246, MK_INT(1LL), v_cell_2411);
    V t_0 = v_a_240;
    V t_1 = v_c_241;
    V t_2 = v_ups_248;
    V t_3 = v_up_247;
    V t_4 = v_t_2410;
    V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
    V t_6 = v_u_2412;
    v_a_240 = t_0;
    v_c_241 = t_1;
    v_x2_242 = t_2;
    v_diag_243 = t_3;
    v_left_244 = t_4;
    v_i_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_std_2ecli_2erowFor_2enextGo_240_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a6 = a[6]; V r = g_std_2ecli_2erowFor_2enextGo_240_24dps(a0, a1, a[2], a[3], a[4], a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a6); return r;
}