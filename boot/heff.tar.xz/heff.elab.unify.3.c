// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_failed 665164648
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_mel__mty__msp[] = {LBL_mel, LBL_mty, LBL_msp};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2eappendL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo;
V g_heff_2eelab_2eunify_2eappendL_24tok2(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24tok2_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps(V, V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
HeffT3 g_heff_2eelab_2eunify_2emetasK_24cpr(V);
V g_heff_2eelab_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTermF_clo;
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_clo;
V g_heff_2eelab_2eunify_2enewMetaIn(V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaIn_clo;
V g_heff_2eelab_2eunify_2enominalBody(V);
V g_heff_2eelab_2eunify_2enominalBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enominalBody_clo;
HeffT2 g_heff_2eelab_2eunify_2enth_24cpr(V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_clo;
V g_heff_2eelab_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_clo;
V g_heff_2eelab_2eunify_2esubstTermF_24generate0(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_24generate0_clo;
V g_heff_2eelab_2eunify_2esubstTermF_24generate1(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_24generate1_clo;
V g_heff_2eelab_2eunify_2esubstTermF_24map0(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_24map0_clo;
V g_heff_2eelab_2eunify_2esubstTermF_24map1(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_24map1_clo;
V g_heff_2eelab_2eunify_2esubstTyFields_24dps(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_24dps_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate2(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate2_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24map2(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map2_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = ({ V a_0 = heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))); V a_1 = v_f_241; V a_2 = v_xs_244; V a_3 = v_cell_246; V r_ = (g_heff_2eelab_2eunify_2emapWithIndexL_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_f_241); r_; });
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2eappendL_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eunify_2eappendL_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam4(V self, V *args);

HeffT3 g_heff_2eelab_2eunify_2emetasK_24cpr(V v_mc_240) {
top: ;
  return ((HeffT3){{heff_clo_n(g_heff_2eelab_2eunify_2emetasK_24cpr_lam0, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_24cpr_lam1, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_24cpr_lam4, 3, 1, (V[]){v_mc_240})}});
}
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam0(V self, V *args) {
  V v_depth_241 = args[0];
  V v_len_242 = args[1];
  V v_v_243 = args[2];
  V v_mc_240 = heff_env(self)[0];
  V v_t_244 = (g_heff_2eelab_2eunify_2emetasK(heff_dup(v_mc_240)));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_depth_241; V a_3 = v_len_242; V a_4 = v_v_243; V r_ = (g_heff_2eelab_2eunify_2emetasTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam3(V self, V *args) {
  V v_u_2435 = args[0];
  V v_dom_2425 = heff_env(self)[0];
  heff_drop(v_u_2435);
  heff_clo_take(self, 1);
  return v_dom_2425;
}
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam2(V self, V *args) {
  V v_u_2434 = args[0];
  V v_len_2414 = heff_env(self)[0];
  V v_dom_2425 = heff_env(self)[1];
  heff_drop(v_u_2434);
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_2414}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_24cpr_lam3, 1, 1, (V[]){v_dom_2425}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam1(V self, V *args) {
  V v_depth_245 = args[0];
  V v_len_246 = args[1];
  V v_t_247 = args[2];
  V v_mc_240 = heff_env(self)[0];
  HeffT3 v_t_248 = (g_heff_2eelab_2eunify_2emetasK_24cpr(heff_dup(v_mc_240)));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    heff_drop(v_t_248.f[2]);
    heff_clo_take(self, 1);
    V v_mc_2412 = v_mc_240;
    V v_depth_2413 = v_depth_245;
    V v_len_2414 = v_len_246;
    V v_t0_2415 = v_t_247;
    if (heff_intLe_c_lent(v_depth_2413, MK_INT(0LL), 2)) {
      heff_drop(v_field_249);
      heff_drop(v_field_2410);
      heff_drop(v_mc_2412);
      heff_drop(v_depth_2413);
      heff_drop(v_len_2414);
      heff_drop(v_t0_2415);
      return NTAG(TAG_Nil);
    } else {
      V v_t_2416 = ({ V a_0 = v_mc_2412; V a_1 = v_t0_2415; V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_mc_2412); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_VU: {
        heff_take_n(v_t_2416, 0ULL, 1);
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        heff_drop(v_depth_2413);
        heff_drop(v_len_2414);
        return NTAG(TAG_Nil);
      }
      case TAG_VDecode: {
        V v_el_2422 = heff_field(v_t_2416, 4);
        heff_take_n(v_t_2416, 16ULL, 5);
        heff_drop(v_field_2410);
        V v_t_2423 = heff_tr(heff_call(v_el_2422, 1, (V[]){NTAG(TAG_MkUnit)}));
        V f_ = v_field_249;
        args[0] = v_depth_2413;
        args[1] = v_len_2414;
        args[2] = v_t_2423;
        if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 3, args);
      }
      case TAG_VFunction: {
        V v_dom_2425 = heff_field(v_t_2416, 1);
        V v_cod_2426 = heff_field(v_t_2416, 2);
        heff_take_n(v_t_2416, 6ULL, 6);
        heff_drop(v_field_249);
        V v_t_2430 = heff_tr(heff_call(heff_dup(v_field_2410), 3, (V[]){heff_intSub_lent(v_depth_2413, MK_INT(1LL), 2), heff_dup(v_len_2414), heff_dup(v_dom_2425)}));
        V v_x1_2437;
        switch (heff_tag_of(v_cod_2426)) {
        case TAG_MkClo: {
          V v_vs_2432 = heff_field(v_cod_2426, 1);
          V v_body_2433 = heff_field(v_cod_2426, 2);
          heff_take_n(v_cod_2426, 6ULL, 3);
          v_x1_2437 = heff_tr(heff_call(v_body_2433, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2432, heff_clo_n(g_heff_2eelab_2eunify_2emetasK_24cpr_lam2, 1, 2, (V[]){heff_dup(v_len_2414), v_dom_2425})})}));
          break;
        }
        case TAG_CloConst: {
          V v_body_2436 = heff_field(v_cod_2426, 0);
          heff_take_n(v_cod_2426, 1ULL, 1);
          heff_drop(v_dom_2425);
          v_x1_2437 = v_body_2436;
          break;
        }
        default: heff_nomatch(v_cod_2426);
        }
        V v_t_2441;
        switch (heff_tag_of(v_x1_2437)) {
        case TAG_Nom: {
          V v_x_2438 = heff_field(v_x1_2437, 0);
          heff_take_n(v_x1_2437, 1ULL, 1);
          v_t_2441 = v_x_2438;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2437, 0ULL, 1);
          v_t_2441 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2440 = heff_field(v_x1_2437, 0);
          heff_take_n(v_x1_2437, 1ULL, 1);
          v_t_2441 = v_x_2440;
          break;
        }
        default: heff_nomatch(v_x1_2437);
        }
        V v_t_2442 = heff_tr(heff_call(v_field_2410, 3, (V[]){heff_intSub(v_depth_2413, MK_INT(1LL)), heff_intAdd(v_len_2414, MK_INT(1LL)), v_t_2441}));
        return (g_heff_2eelab_2eunify_2eappendL(v_t_2430, v_t_2442));
      }
      case TAG_VRecord: {
        heff_take_n(v_t_2416, 0ULL, 4);
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        heff_drop(v_depth_2413);
        heff_drop(v_len_2414);
        return NTAG(TAG_Nil);
      }
      case TAG_VSum: {
        heff_take_n(v_t_2416, 0ULL, 1);
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        heff_drop(v_depth_2413);
        heff_drop(v_len_2414);
        return NTAG(TAG_Nil);
      }
      case TAG_VPrimInt: {
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        heff_drop(v_depth_2413);
        heff_drop(v_len_2414);
        return NTAG(TAG_Nil);
      }
      case TAG_VPrimFloat: {
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        heff_drop(v_depth_2413);
        heff_drop(v_len_2414);
        return NTAG(TAG_Nil);
      }
      case TAG_VPrimString: {
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        heff_drop(v_depth_2413);
        heff_drop(v_len_2414);
        return NTAG(TAG_Nil);
      }
      case TAG_VPrimRune: {
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        heff_drop(v_depth_2413);
        heff_drop(v_len_2414);
        return NTAG(TAG_Nil);
      }
      case TAG_VPrimArray: {
        V v_a_2448 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        heff_drop(v_field_249);
        V f_ = v_field_2410;
        args[0] = heff_intSub(v_depth_2413, MK_INT(1LL));
        args[1] = v_len_2414;
        args[2] = v_a_2448;
        if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 3, args);
      }
      case TAG_VFixed: {
        heff_take_n(v_t_2416, 0ULL, 1);
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        heff_drop(v_depth_2413);
        heff_drop(v_len_2414);
        return NTAG(TAG_Nil);
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
  }
}
V g_heff_2eelab_2eunify_2emetasK_24cpr_lam4(V self, V *args) {
  V v_depth_2450 = args[0];
  V v_len_2451 = args[1];
  V v_sp_2452 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT3 v_t_2453 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_mc_240));
  {
    V v_field_2454 = v_t_2453.f[0];
    V v_field_2456 = v_t_2453.f[2];
    heff_drop(v_t_2453.f[1]);
    V v_depth_2457 = v_depth_2450;
    V v_len_2458 = v_len_2451;
    V v_x5_2459 = v_sp_2452;
    switch (heff_tag_of(v_x5_2459)) {
    case TAG_SpId: {
      heff_drop(v_field_2454);
      heff_drop(v_field_2456);
      heff_drop(v_depth_2457);
      heff_drop(v_len_2458);
      return NTAG(TAG_Nil);
    }
    case TAG_SpApp: {
      V v_sp_2460 = heff_field(v_x5_2459, 0);
      V v_a_2461 = heff_field(v_x5_2459, 1);
      V v_ru_24x5_2459_24SpApp = heff_take_reuse_n(v_x5_2459, 3ULL, 2);
      V v_t_2462 = heff_tr(heff_call(v_field_2456, 3, (V[]){heff_dup(v_depth_2457), heff_dup(v_len_2458), v_sp_2460}));
      V v_t_2463 = heff_tr(heff_call(v_field_2454, 3, (V[]){heff_intSub(v_depth_2457, MK_INT(1LL)), v_len_2458, v_a_2461}));
      return (g_heff_2eelab_2eunify_2eappendL_24tok2(v_ru_24x5_2459_24SpApp, v_t_2462, v_t_2463));
    }
    case TAG_SpProj: {
      V v_sp_2464 = heff_field(v_x5_2459, 0);
      heff_take_n(v_x5_2459, 1ULL, 2);
      heff_drop(v_field_2454);
      V f_ = v_field_2456;
      args[0] = v_depth_2457;
      args[1] = v_len_2458;
      args[2] = v_sp_2464;
      if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 3, args);
    }
    case TAG_SpSpec: {
      V v_sp_2466 = heff_field(v_x5_2459, 0);
      V v_a_2468 = heff_field(v_x5_2459, 2);
      heff_take_n(v_x5_2459, 5ULL, 3);
      V v_t_2469 = heff_tr(heff_call(v_field_2456, 3, (V[]){heff_dup(v_depth_2457), heff_dup(v_len_2458), v_sp_2466}));
      V v_t_2470 = heff_tr(heff_call(v_field_2454, 3, (V[]){heff_intSub(v_depth_2457, MK_INT(1LL)), v_len_2458, v_a_2468}));
      return (g_heff_2eelab_2eunify_2eappendL(v_t_2469, v_t_2470));
    }
    default: return heff_nomatch(v_x5_2459);
    }
  }
}
Clo g_heff_2eelab_2eunify_2emetasK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasK_entry, 1, 0};

V g_heff_2eelab_2eunify_2emetasK(V v_mc_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_mc_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    return heff_rec_n(3, shape_mel__mty__msp, (V[]){v_field_242, v_field_243, v_field_244});
  }
}
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emetasK(a[0]);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esubstTermF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args); static Clo g_heff_2eelab_2eunify_2esubstTermF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_lam3, 1, 0};
Clo g_heff_2eelab_2eunify_2esubstTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SLocal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    if (heff_intLt_c_lent(v_i_244, v_d_242, 0)) {
      heff_drop(v_d_242);
      return heff_tag_re_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, 1ULL, (V[]){v_i_244});
    } else {
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
      V v_t_246 = heff_intSub(heff_intSub(v_t_245, MK_INT(1LL)), heff_intSub_lent(v_i_244, v_d_242, 0));
      HeffT2 v_t_247 = (g_heff_2eelab_2eunify_2enth_24cpr(v_idxs_241, v_t_246));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_i_244);
          V v_j_2410 = v_field_249;
          return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){heff_intAdd(v_j_2410, v_d_242)});
        } else {
          heff_drop(v_d_242);
          heff_drop(v_field_249);
          return heff_tag_re_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, 1ULL, (V[]){v_i_244});
        }
      }
    }
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SCode: {
    V v_ty_2412 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2412}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_2413});
  }
  case TAG_SApp: {
    V v_f_2414 = heff_field(v_t_243, 0);
    V v_a_2415 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_f_2414}));
    V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_a_2415}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2416, v_t_2417});
  }
  case TAG_SLam: {
    V v_dd_2418 = heff_field(v_t_243, 0);
    V v_t2_2419 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2419)) {
    case TAG_MkAbs: {
      V v_x_2420 = heff_field(v_t2_2419, 0);
      V v_b_2421 = heff_field(v_t2_2419, 1);
      V v_ru_24t2_2419_24MkAbs = heff_take_reuse_n(v_t2_2419, 3ULL, 2);
      V v_t_2422 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2418}));
      V v_t_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2421}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2422, heff_tag_re_n(v_ru_24t2_2419_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2420, v_t_2423})});
    }
    case TAG_AbsConst: {
      V v_b_2424 = heff_field(v_t2_2419, 0);
      V v_ru_24t2_2419_24AbsConst = heff_take_reuse_n(v_t2_2419, 1ULL, 1);
      V v_t_2425 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2418}));
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2424}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2425, heff_tag_at_n(v_ru_24t2_2419_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2426})});
    }
    default: return heff_nomatch(v_t2_2419);
    }
  }
  case TAG_SCons: {
    V v_dct_2427 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_xs_2429 = heff_take_field(v_dct_2427, 2);
    V v_t_2432 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2429, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam0, 1, 2, (V[]){v_xs_2429, v_f_2428}));
    V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_dct_2427, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2433});
  }
  case TAG_SProj: {
    V v_e_2434 = heff_field(v_t_243, 0);
    V v_l_2435 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2434}));
    return heff_tag_re_n(v_ru_24t_243_24SProj, TAG_SProj, 2, 2ULL, (V[]){v_t_2436, v_l_2435});
  }
  case TAG_STag: {
    V v_x_2437 = heff_field(v_t_243, 0);
    V v_argv_2438 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_f_2439 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_t_2442 = heff_arrayGenerate(heff_arrayLength_lent(v_argv_2438, 0), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam1, 1, 2, (V[]){v_argv_2438, v_f_2439}));
    return heff_tag_re_n(v_ru_24t_243_24STag, TAG_STag, 2, 1ULL, (V[]){v_x_2437, v_t_2442});
  }
  case TAG_SMatch: {
    V v_e_2443 = heff_field(v_t_243, 0);
    V v_cs_2444 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2443}));
    V v_xs_2446 = heff_take_field(v_cs_2444, 2);
    V v_m_2447 = heff_arrayLength_lent(v_xs_2446, 0);
    V v_t_2456;
    if ((heff_peek_word(v_m_2447) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_d_242);
      heff_drop(v_xs_2446);
      v_t_2456 = heff_arrayGenerate(v_m_2447, ((V)&g_heff_2eelab_2eunify_2esubstTermF_lam2_clo));
    } else {
      V v_p_2449 = heff_arrayIndex_lent(v_xs_2446, MK_INT(0LL), 2);
      V v_y_2454;
      switch (heff_tag_of(v_p_2449)) {
      case TAG_MkPair: {
        V v_xs_2450 = heff_field(v_p_2449, 0);
        V v_b_2451 = heff_field(v_p_2449, 1);
        V v_ru_24p_2449_24MkPair = heff_take_reuse_n(v_p_2449, 3ULL, 2);
        V v_t_2452 = heff_intAdd_lent(v_d_242, heff_arrayLength_lent(v_xs_2450, 0), 2);
        V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){v_t_2452, v_b_2451}));
        v_y_2454 = heff_tag_re_n(v_ru_24p_2449_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_2450, v_t_2453});
        break;
      }
      default: heff_nomatch(v_p_2449);
      }
      V v_t_2455 = heff_arrayKeepsAs_lent(v_xs_2446, v_y_2454, 0);
      if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
        heff_drop(v_m_2447);
        heff_drop(v_t_2455);
        v_t_2456 = ({ V a_0 = v_r_240; V a_1 = v_d_242; V a_2 = MK_INT(1LL); V a_3 = heff_arraySet(v_xs_2446, MK_INT(0LL), v_y_2454); V r_ = (g_heff_2eelab_2eunify_2esubstTermF_24map0(a_0, a_1, a_2, a_3)); heff_drop_rec(v_r_240, 2); heff_drop(v_d_242); r_; });
      } else {
        heff_drop(v_t_2455);
        v_t_2456 = ({ V a_0 = v_xs_2446; V a_1 = v_r_240; V a_2 = v_d_242; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_2447, v_y_2454); V r_ = (g_heff_2eelab_2eunify_2esubstTermF_24generate0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_2446); heff_drop_rec(v_r_240, 2); heff_drop(v_d_242); r_; });
      }
    }
    V v_t_2457 = ({ V rv_2 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_cs_2444, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2445, v_t_2457});
  }
  case TAG_SSpecialize: {
    V v_e_2458 = heff_field(v_t_243, 0);
    V v_l_2459 = heff_field(v_t_243, 1);
    V v_v_2460 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2458}));
    V v_t_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_v_2460}));
    return heff_tag_re_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, 2ULL, (V[]){v_t_2461, v_l_2459, v_t_2462});
  }
  case TAG_SIs: {
    V v_e_2463 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2463}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2464});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2465 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2465}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2466});
  }
  case TAG_SFix: {
    V v_dd_2467 = heff_field(v_t_243, 0);
    V v_t2_2468 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2468)) {
    case TAG_MkAbs: {
      V v_x_2469 = heff_field(v_t2_2468, 0);
      V v_b_2470 = heff_field(v_t2_2468, 1);
      V v_ru_24t2_2468_24MkAbs = heff_take_reuse_n(v_t2_2468, 3ULL, 2);
      V v_t_2471 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2467}));
      V v_t_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2470}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2471, heff_tag_re_n(v_ru_24t2_2468_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2469, v_t_2472})});
    }
    case TAG_AbsConst: {
      V v_b_2473 = heff_field(v_t2_2468, 0);
      V v_ru_24t2_2468_24AbsConst = heff_take_reuse_n(v_t2_2468, 1ULL, 1);
      V v_t_2474 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2467}));
      V v_t_2475 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2473}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2474, heff_tag_at_n(v_ru_24t2_2468_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2475})});
    }
    default: return heff_nomatch(v_t2_2468);
    }
  }
  case TAG_SImplicit: {
    V v_x_2476 = heff_field(v_t_243, 0);
    V v_e_2477 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2477}));
    return heff_tag_re_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, 1ULL, (V[]){v_x_2476, v_t_2478});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2480 = heff_field(v_t_243, 0);
    V v_ix_2481 = heff_field(v_t_243, 1);
    V v_ty_2482 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_m_2483 = heff_arrayLength_lent(v_ix_2481, 0);
    V v_t_2494;
    if ((heff_peek_word(v_m_2483) <= ((int64_t)0ULL))) {
      heff_drop(v_ix_2481);
      v_t_2494 = heff_arrayGenerate(v_m_2483, ((V)&g_heff_2eelab_2eunify_2esubstTermF_lam3_clo));
    } else {
      V v_i_2485 = heff_arrayIndex_lent(v_ix_2481, MK_INT(0LL), 2);
      V v_y_2492;
      if (heff_intLt_c_lent(v_i_2485, v_d_242, 0)) {
        v_y_2492 = v_i_2485;
      } else {
        V v_t_2486 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
        V v_t_2487 = heff_intSub(heff_intSub(v_t_2486, MK_INT(1LL)), heff_intSub_lent(v_i_2485, v_d_242, 0));
        HeffT2 v_t_2488 = (g_heff_2eelab_2eunify_2enth_24cpr(v_idxs_241, v_t_2487));
        {
          V v_field_2490 = v_t_2488.f[1];
          int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
          if ((v_tag_2489 == ((int64_t)0ULL))) {
            heff_drop(v_i_2485);
            V v_j_2491 = v_field_2490;
            v_y_2492 = heff_intAdd_lent(v_j_2491, v_d_242, 1);
          } else {
            heff_drop(v_field_2490);
            v_y_2492 = v_i_2485;
          }
        }
      }
      V v_t_2493 = heff_arrayKeepsAs_lent(v_ix_2481, v_y_2492, 0);
      if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
        heff_drop(v_m_2483);
        heff_drop(v_t_2493);
        v_t_2494 = (g_heff_2eelab_2eunify_2esubstTermF_24map1(v_d_242, v_idxs_241, MK_INT(1LL), heff_arraySet(v_ix_2481, MK_INT(0LL), v_y_2492)));
      } else {
        heff_drop(v_t_2493);
        v_t_2494 = ({ V a_0 = v_ix_2481; V a_1 = v_d_242; V a_2 = v_idxs_241; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_2483, v_y_2492); V r_ = (g_heff_2eelab_2eunify_2esubstTermF_24generate1(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ix_2481); r_; });
      }
    }
    V v_t_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2482}));
    return heff_tag_re_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, 1ULL, (V[]){v_m_2480, v_t_2494, v_t_2495});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTermF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_f_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  V f_ = v_f_2428;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args) {
  V v_i_2440 = args[0];
  V v_argv_2438 = heff_env(self)[0];
  V v_f_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_arrayIndex(v_argv_2438, v_i_2440);
  V f_ = v_f_2439;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args) {
  V v_u_2448 = args[0];
  heff_drop(v_u_2448);
  return heff_abandon();
}
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args) {
  V v_u_2484 = args[0];
  heff_drop(v_u_2484);
  return heff_abandon();
}
Clo g_heff_2eelab_2eunify_2esubstTermF_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_24map0_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTermF_24map0(V v_r_240, V v_d_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if ((((int64_t)0ULL) <= v_i_242)) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_p_244 = heff_arrayIndexIn_lent(v_a_243, heff_box_word(v_i_242), 2);
      V v_t_249;
      switch (heff_tag_of(v_p_244)) {
      case TAG_MkPair: {
        V v_xs_245 = heff_field(v_p_244, 0);
        V v_b_246 = heff_field(v_p_244, 1);
        V v_ru_24p_244_24MkPair = heff_take_reuse_n(v_p_244, 3ULL, 2);
        V v_t_247 = heff_intAdd_lent(v_d_241, heff_arrayLength_lent(v_xs_245, 0), 2);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){v_t_247, v_b_246}));
        v_t_249 = heff_tag_re_n(v_ru_24p_244_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_245, v_t_248});
        break;
      }
      default: heff_nomatch(v_p_244);
      }
      V t_0 = v_r_240;
      V t_1 = v_d_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_249);
      v_r_240 = t_0;
      v_d_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_p_244 = heff_arrayIndex_lent(v_a_243, heff_box_word(v_i_242), 2);
    V v_t_249;
    switch (heff_tag_of(v_p_244)) {
    case TAG_MkPair: {
      V v_xs_245 = heff_field(v_p_244, 0);
      V v_b_246 = heff_field(v_p_244, 1);
      V v_ru_24p_244_24MkPair = heff_take_reuse_n(v_p_244, 3ULL, 2);
      V v_t_247 = heff_intAdd_lent(v_d_241, heff_arrayLength_lent(v_xs_245, 0), 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){v_t_247, v_b_246}));
      v_t_249 = heff_tag_re_n(v_ru_24p_244_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_245, v_t_248});
      break;
    }
    default: heff_nomatch(v_p_244);
    }
    V t_0 = v_r_240;
    V t_1 = v_d_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_249);
    v_r_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_24map0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTermF_24map0(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2esubstTyFields_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry, 5, 0};

V g_heff_2eelab_2eunify_2esubstTyFields_24dps(V v_r_240, V v_d_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_ty_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_intAdd_lent(v_d_241, v_i_242, 0), v_ty_245}));
    V v_cell_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_248);
    V t_0 = v_r_240;
    V t_1 = v_d_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_rest_246;
    V t_4 = v_u_249;
    v_r_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTyFields_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2eunify_2esubstTyFields_24dps(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam0, 1, 0};
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam1, 1, 0};
Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_entry, 4, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3(V v_xs_240, V v_r_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_xs_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_m_245 = heff_arrayLength_lent(v_xs_244, 0);
      V v_t_2410;
      if ((heff_peek_word(v_m_245) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_244);
        v_t_2410 = heff_arrayGenerate(v_m_245, ((V)&g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam0_clo));
      } else {
        V v_t_247 = heff_arrayIndex_lent(v_xs_244, MK_INT(0LL), 2);
        V v_y_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 1)), 1, (V[]){v_t_247}));
        V v_t_249 = heff_arrayKeepsAs_lent(v_xs_244, v_y_248, 0);
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_m_245);
          heff_drop(v_t_249);
          v_t_2410 = (g_heff_2eelab_2eunify_2ezonkTypeF_24map2(v_r_241, MK_INT(1LL), heff_arraySet(v_xs_244, MK_INT(0LL), v_y_248)));
        } else {
          heff_drop(v_t_249);
          v_t_2410 = ({ V a_0 = v_r_241; V a_1 = v_xs_244; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_245, v_y_248); V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_244); r_; });
        }
      }
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_2410);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_xs_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_m_245 = heff_arrayLength_lent(v_xs_244, 0);
    V v_t_2410;
    if ((heff_peek_word(v_m_245) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_244);
      v_t_2410 = heff_arrayGenerate(v_m_245, ((V)&g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam1_clo));
    } else {
      V v_t_247 = heff_arrayIndex_lent(v_xs_244, MK_INT(0LL), 2);
      V v_y_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 1)), 1, (V[]){v_t_247}));
      V v_t_249 = heff_arrayKeepsAs_lent(v_xs_244, v_y_248, 0);
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_m_245);
        heff_drop(v_t_249);
        v_t_2410 = (g_heff_2eelab_2eunify_2ezonkTypeF_24map2(v_r_241, MK_INT(1LL), heff_arraySet(v_xs_244, MK_INT(0LL), v_y_248)));
      } else {
        heff_drop(v_t_249);
        v_t_2410 = ({ V a_0 = v_r_241; V a_1 = v_xs_244; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_245, v_y_248); V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_244); r_; });
      }
    }
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_2410);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTypeF_24generate3(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam0(V self, V *args) {
  V v_u_246 = args[0];
  heff_drop(v_u_246);
  return heff_abandon();
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_lam1(V self, V *args) {
  V v_u_246 = args[0];
  heff_drop(v_u_246);
  return heff_abandon();
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24PVar = heff_take_reuse_n(v_a_244, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          V v_a_247 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          if (heff_intEq_c(v_a_246, v_a_247)) {
            v_t_249 = heff_tag_at_n(v_ru_24a_244_24PVar, TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          } else {
            heff_drop_cell(v_ru_24a_244_24PVar, 1);
            v_t_249 = NTAG(TAG_Nothing);
          }
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_246);
          heff_drop_cell(v_ru_24a_244_24PVar, 1);
          v_t_249 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          heff_take_n(v_a_245, 0ULL, 1);
          v_t_249 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PSelf: {
          v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_xs_243, v_cell_2410));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_243}), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_u_246;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2eunify_2enominalBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enominalBody_entry, 1, 0};

V g_heff_2eelab_2eunify_2enominalBody(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_t_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_SU: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SDecode: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SFunction: {
      heff_take_n(v_t_243, 0ULL, 5);
      return NTAG(TAG_False);
    }
    case TAG_SRecord: {
      heff_take_n(v_t_243, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SFixed: {
      heff_take_n(v_t_243, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    V v_b_2421 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_b_2421)) {
    case TAG_MkAbs: {
      V v_b_2423 = heff_field(v_b_2421, 1);
      heff_take_n(v_b_2421, 2ULL, 2);
      v_t_2425 = v_b_2423;
      break;
    }
    case TAG_AbsConst: {
      V v_b_2424 = heff_field(v_b_2421, 0);
      heff_take_n(v_b_2421, 1ULL, 1);
      v_t_2425 = v_b_2424;
      break;
    }
    default: heff_nomatch(v_b_2421);
    }
    V t_0 = v_t_2425;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2enominalBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enominalBody(a[0]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_247 = heff_field(v_x6_244, 0);
    V v_l_248 = heff_field(v_x6_244, 1);
    V v_f_249 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_2410 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_pr_242, 2), heff_rfield(v_pr_242, 0), heff_rfield(v_pr_242, 1)));
    V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_2412 = heff_intAdd(heff_take_field(v_pr_242, 1), MK_INT(1LL));
    V v_pr_2413 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_2411, v_t_2412, v_t_2410});
    V v_t_2414 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2416 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2414, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2418 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam1, 1, 1, (V[]){v_v_2416})})}));
    V v_t_2425;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nom: {
      V v_a_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_a_2419}));
      break;
    }
    case TAG_Describe: {
      V v_a_2420 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_a_2420}));
      break;
    }
    case TAG_Become: {
      V v_a_2421 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_a_2421});
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    return heff_tail(v_t_2425, 2, (V[]){v_z_245, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam4, 1, 2, (V[]){v_z_246, v_x_247})});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_t_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_a_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2428}));
      break;
    }
    case TAG_Describe: {
      V v_a_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2429}));
      break;
    }
    case TAG_Become: {
      V v_a_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam5, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_tail(v_t_2434, 2, (V[]){v_z_245, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam7, 1, 1, (V[]){v_z_246})});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam0(V self, V *args) {
  V v_u_2415 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_drop(v_u_2415);
  heff_clo_take(self, 1);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  V v_v_2416 = heff_env(self)[0];
  heff_drop(v_u_2417);
  heff_clo_take(self, 1);
  return v_v_2416;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2413 = heff_env(self)[2];
  V v_a_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(v_g_240, v_m_241, v_pr_2413, v_a_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam3, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_247, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(v_g_240, v_m_241, v_pr_242, v_a_2430, v_hd_2431, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam6, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s1826149764x1118856917_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam0, 1, 0};
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_entry, 5, 0};

V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(V v_entry_240, V v_arity_241, V v_ty_242, V v_hd_243, V v_k_244) {
top: ;
  V v_malg_245 = heff_take_field(v_hd_243, 2);
  V v_bind_246 = heff_get_n(v_hd_243, 1, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(v_bind_246), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam1, 1, 6, (V[]){v_entry_240, v_arity_241, v_ty_242, v_malg_245, v_bind_246, v_k_244})});
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 4, 9);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  heff_drop(v_x_2417);
  heff_clo_take(self, 2);
  V f_ = v_k_244;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_246 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_t_2415 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  heff_clo_take(self, 4);
  V v_t_2416 = heff_tr(heff_call(v_malg_245, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})}));
  V f_ = v_bind_246;
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam3, 1, 2, (V[]){v_k_244, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_entry_240 = heff_env(self)[0];
  V v_arity_241 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_malg_245 = heff_env(self)[3];
  V v_bind_246 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2enewMetaIn_clo), 3, (V[]){v_entry_240, v_arity_241, v_ty_242}));
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(v_bind_246);
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_lam2, 1, 4, (V[]){v_malg_245, v_bind_246, v_k_244, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_str0, 5, "solve");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_str1, 1, "\?");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_str3, 5, ") := ");
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry, 4, 0};

V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V v_m_240, V v_stx_241, V v_hd_242, V v_k_243) {
top: ;
  V v_malg_244 = heff_take_field(v_hd_242, 2);
  V v_bind_245 = heff_get_n(v_hd_242, 1, 3);
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam0, 1, 2, (V[]){v_m_240, v_stx_241})})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(v_malg_244), 1, (V[]){v_t_2422}));
  return heff_tail(heff_dup(v_bind_245), 2, (V[]){v_t_2423, heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam2, 1, 3, (V[]){v_malg_244, v_bind_245, v_k_243})});
}
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam1(V self, V *args) {
  V v_u_2413 = args[0];
  V v_c_246 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  V v_m_240 = heff_env(self)[2];
  V v_name_2412 = heff_env(self)[3];
  heff_drop(v_u_2413);
  heff_clo_take(self, 4);
  HeffT2 v_t_2414 = ({ V b_0 = heff_get_n(v_c_246, 3, 9); HeffT2 r_ = (g_heff_2eelab_2eunify_2ezonker_24cpr(b_0)); heff_drop(b_0); r_; });
  {
    V v_field_2415 = v_t_2414.f[0];
    heff_drop(v_t_2414.f[1]);
    V v_e_2417 = heff_tr(heff_call(v_field_2415, 1, (V[]){v_stx_241}));
    V v_t_2418 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_2417));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_str1), heff_intShow(v_m_240));
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_str2)), v_name_2412);
    return heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_str3)), v_t_2418);
  }
}
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_c_246, 3), v_m_240));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_e_2410 = v_field_249;
      V v_span_2411 = heff_take_field(v_e_2410, 5);
      V v_name_2412 = heff_get_n(v_e_2410, 4, 6);
      heff_clo_take(self, 2);
      V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_span_2411, ((V)&g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_str0), heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam1, 1, 4, (V[]){heff_dup(v_c_246), v_stx_241, v_m_240, v_name_2412})}), heff_dup(heff_rfield(v_c_246, 6))});
      return ({ V rv_6 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_c_246, 447ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
    } else {
      heff_drop(self);
      heff_drop(v_field_249);
      return v_c_246;
    }
  }
}
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_malg_244 = heff_env(self)[0];
  V v_bind_245 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_t_2425 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2424, NTAG(TAG_MkUnit)});
  heff_clo_take(self, 3);
  V v_t_2426 = heff_tr(heff_call(v_malg_244, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})}));
  V f_ = v_bind_245;
  heff_room[0] = v_t_2426;
  heff_room[1] = v_k_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_entry, 8, 0};

V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    heff_drop(v_z_246);
    return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eelab_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411), heff_dup(v_z_246), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam0, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_z_246, v_z_247})));
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_drop(v_u_2416);
  heff_clo_take(self, 1);
  return v_ty_2411;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam2(V self, V *args) {
  V v_u_2418 = args[0];
  V v_v_2417 = heff_env(self)[0];
  heff_drop(v_u_2418);
  heff_clo_take(self, 1);
  return v_v_2417;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  V v_z_247 = heff_env(self)[8];
  V v_t_2415 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), heff_dup(v_i_243));
  heff_clo_take(self, 9);
  V v_v_2417 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_2415}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam1, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  return (g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam2, 1, 1, (V[]){v_v_2417})}), v_rest_249, v_z_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_lam3, 1, 2, (V[]){v_z_247, v_x_2414})));
}
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_entry, 6, 0};

V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(V v_tok_240, V v_cs_241, V v_l_242, V v_r_243, V v_hd_244, V v_k_245) {
top: ;
  V v_malg_246 = heff_take_field(v_hd_244, 2);
  V v_bind_247 = heff_get_n(v_hd_244, 1, 3);
  V v_t_2411 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_lam0, 1, 3, (V[]){v_cs_241, v_l_242, v_r_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_247), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_lam1, 1, 3, (V[]){v_malg_246, v_bind_247, v_k_245})});
}
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_l_242 = heff_env(self)[1];
  V v_r_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_rec_n(4, shape_shape__left__right__failed, (V[]){v_cs_241, v_l_242, v_r_243, NTAG(TAG_False)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_take_field(v_c_248, 5)});
  return ({ V rv_5 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_c_248, 479ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_malg_246 = heff_env(self)[0];
  V v_bind_247 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_t_2414 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tr(heff_call(v_malg_246, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})}));
  V f_ = v_bind_247;
  heff_room[0] = v_t_2415;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry, 6, 0};

V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(V v_tok_240, V v_m_241, V v_sol_242, V v_stx_243, V v_hd_244, V v_k_245) {
top: ;
  V v_malg_246 = heff_take_field(v_hd_244, 2);
  V v_bind_247 = heff_get_n(v_hd_244, 1, 3);
  V v_t_2415 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_lam0, 1, 3, (V[]){heff_dup(v_m_241), v_sol_242, v_stx_243})})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(v_malg_246), 1, (V[]){v_t_2415}));
  return heff_tail(heff_dup(v_bind_247), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_lam1, 1, 3, (V[]){v_malg_246, v_bind_247, v_k_245})});
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_sol_242 = heff_env(self)[1];
  V v_stx_243 = heff_env(self)[2];
  HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_c_248, 3), v_m_241));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_e_2412 = v_field_2411;
      heff_clo_take(self, 3);
      V v_t_2413 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_sol_242}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_stx_243}); V rr_ = heff_rec_reuse_nf(v_e_2412, 57ULL, 6, shape_ty__sol__solStx__arity__name__span, 4035u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_mc_2414 = ({ V a_0 = heff_take_field(v_c_248, 3); V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_m_241); heff_drop_rec(v_t_2413, 6); r_; });
      return ({ V rv_3 = v_mc_2414; V rr_ = heff_rec_reuse_nf(v_c_248, 503ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(self);
      heff_drop(v_field_2411);
      return v_c_248;
    }
  }
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_malg_246 = heff_env(self)[0];
  V v_bind_247 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_t_2418 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tr(heff_call(v_malg_246, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})}));
  V f_ = v_bind_247;
  heff_room[0] = v_t_2419;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}