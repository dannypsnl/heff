// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIs 29577
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9006
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_ret 322331
#define LBL_selfKey 62480824
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2ecatMaybes_24dps(V, V);
V g_heff_2eelab_2eunify_2ecatMaybes_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_24dps_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eeqPatArgs(V, V);
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo;
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
HeffT3 g_heff_2eelab_2eunify_2emetasK_24cpr(V);
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_clo;
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_clo;
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_clo;
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V, V, V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_clo;
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_clo;
V g_heff_2eelab_2eunify_2espineRev(V);
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2espineRev_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
HeffT2 g_heff_2eelab_2eunify_2esubstOf_24cpr(V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo;
V g_heff_2eelab_2eunify_2etypeApplied(V, V, V, V);
V g_heff_2eelab_2eunify_2etypeApplied_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etypeApplied_clo;
V g_heff_2eelab_2eunify_2euAlg(V, V);
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euAlg_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_clo;
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_clo;
V g_heff_2eelab_2eunify_2euH_get(void);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_clo;
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24generate2(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate2_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate0(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate0_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24map1(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map1_clo;
V g_heff_2eelab_2evalue_2eappTy(V, V);
V g_heff_2eelab_2evalue_2eappTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eappTy_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1278499411x1393297768(V, V);
V g_list_2efoldl_24s1278499411x1393297768_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1278499411x1393297768_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2ecatMaybes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ecatMaybes_entry, 1, 0};

V g_heff_2eelab_2eunify_2ecatMaybes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eunify_2ecatMaybes_24dps(v_xs_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ecatMaybes(a[0]);
}
Clo g_heff_2eelab_2eunify_2esubstOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2esubstOf(V v_idxs_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2eunify_2esubstOf_24cpr(v_idxs_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_el__ty, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2esubstOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_24generate2_entry, 4, 0};

V g_heff_2eelab_2eunify_2ezonkTermF_24generate2(V v_xs_240, V v_r_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_p_244 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_242));
      V v_t_248;
      switch (heff_tag_of(v_p_244)) {
      case TAG_MkPair: {
        V v_xs_245 = heff_field(v_p_244, 0);
        V v_b_246 = heff_field(v_p_244, 1);
        V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 1, (V[]){heff_dup(v_b_246)}));
        v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_245), v_t_247});
        break;
      }
      default: heff_nomatch(v_p_244);
      }
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_248);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_p_244 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_242));
    V v_t_248;
    switch (heff_tag_of(v_p_244)) {
    case TAG_MkPair: {
      V v_xs_245 = heff_field(v_p_244, 0);
      V v_b_246 = heff_field(v_p_244, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 1, (V[]){heff_dup(v_b_246)}));
      v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_245), v_t_247});
      break;
    }
    default: heff_nomatch(v_p_244);
    }
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_248);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_24generate2_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTermF_24generate2(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_24generate0_entry, 4, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF_24generate0(V v_r_240, V v_xs_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_241, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_xs_241, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_t_244}));
      V t_0 = v_r_240;
      V t_1 = v_xs_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_245);
      v_r_240 = t_0;
      v_xs_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_xs_241, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_t_244}));
    V t_0 = v_r_240;
    V t_1 = v_xs_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_245);
    v_r_240 = t_0;
    v_xs_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTypeF_24generate0(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_24map1_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF_24map1(V v_r_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_243}));
      V t_0 = v_r_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_243}));
    V t_0 = v_r_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24map1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2ezonkTypeF_24map1(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2etypeApplied_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2etypeApplied_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etypeApplied_entry, 4, 0};

V g_heff_2eelab_2eunify_2etypeApplied(V v_mc_240, V v_m_241, V v_x3_242, V v_ty_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_ty_243;
  }
  case TAG_Cons: {
    V v_arg_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_t_246 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, heff_dup(v_ty_243)));
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_246)));
    V v_t_2434;
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_247, 0ULL, 4);
      v_t_2434 = (g_heff_2eelab_2evalue_2eappTy(v_t_246, heff_clo_n(g_heff_2eelab_2eunify_2etypeApplied_lam0, 1, 3, (V[]){heff_dup(v_mc_240), v_ty_243, heff_dup(v_arg_244)})));
      break;
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_LikeInt: {
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_LikeFloat: {
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_LikeString: {
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_LikeRune: {
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    case TAG_NoRules: {
      heff_drop(v_ty_243);
      v_t_2434 = v_t_246;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V t_0 = v_mc_240;
    V t_1 = v_m_241;
    V t_2 = v_rest_245;
    V t_3 = v_t_2434;
    v_mc_240 = t_0;
    v_m_241 = t_1;
    v_x3_242 = t_2;
    v_ty_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2etypeApplied_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eunify_2etypeApplied(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2eunify_2etypeApplied_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_mc_240 = heff_env(self)[0];
  V v_ty_243 = heff_env(self)[1];
  V v_arg_244 = heff_env(self)[2];
  heff_drop(v_u_2413);
  heff_clo_take(self, 3);
  V v_t_2414 = ({ V a_0 = v_mc_240; V a_1 = v_ty_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_mc_240); r_; });
  V v_t_2415 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2414)));
  V v_t_2427;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2418 = heff_field(v_t_2415, 1);
    heff_take_n(v_t_2415, 2ULL, 4);
    heff_drop(v_t_2414);
    v_t_2427 = v_dom_2418;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2415, 0ULL, 3);
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_LikeInt: {
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_LikeString: {
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_LikeRune: {
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2427 = v_t_2414;
    break;
  }
  case TAG_NoRules: {
    v_t_2427 = v_t_2414;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V f_ = v_arg_244;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2eunify_2espineRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2espineRev_entry, 1, 0};

V g_heff_2eelab_2eunify_2espineRev(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_SpId);
  }
  case TAG_Cons: {
    V v_a_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2eunify_2espineRev(v_rest_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_SpApp, 2, (V[]){v_t_243, v_a_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2espineRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2espineRev(a[0]);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam1, 3, 0};

static V g_heff_2eelab_2eunify_2euH_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euH_st;
static V g_heff_2eelab_2eunify_2euH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2eelab_2eunify_2euH_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euH_lam1_clo), ((V)&g_heff_2eelab_2eunify_2euAlg_clo)});
}
V g_heff_2eelab_2eunify_2euH_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euH_st)) return g_heff_2eelab_2eunify_2euH_val;
  return heff_global(&g_heff_2eelab_2eunify_2euH_val, &g_heff_2eelab_2eunify_2euH_st, g_heff_2eelab_2eunify_2euH_init);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_c_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_c_241});
}
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_c_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_c_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Left = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_re_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_246_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry, 3, 0};

V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(V v_ms_240, V v_hd_241, V v_k_242) {
top: ;
  V v_malg_243 = heff_take_field(v_hd_241, 2);
  V v_bind_244 = heff_get_n(v_hd_241, 1, 3);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam0, 1, 1, (V[]){heff_dup(v_ms_240)})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(v_bind_244), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam1, 1, 3, (V[]){v_malg_243, v_bind_244, v_k_242})});
}
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_ms_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_246 = ({ V a_0 = heff_take_field(v_c_245, 2); V a_1 = v_ms_240; V r_ = (g_list_2efoldl_24s1278499411x1393297768(a_0, a_1)); heff_drop(v_ms_240); r_; });
  return ({ V rv_2 = v_ps_246; V rr_ = heff_rec_reuse_nf(v_c_245, 507ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 262095u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  heff_clo_take(self, 3);
  V v_t_2411 = heff_tr(heff_call(v_malg_243, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})}));
  V f_ = v_bind_244;
  heff_room[0] = v_t_2411;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry, 5, 0};

V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V v_m_240, V v_sol_241, V v_stx_242, V v_hd_243, V v_k_244) {
top: ;
  V v_malg_245 = heff_take_field(v_hd_243, 2);
  V v_bind_246 = heff_get_n(v_hd_243, 1, 3);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam0, 1, 3, (V[]){heff_dup(v_m_240), v_sol_241, v_stx_242})})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2414}));
  return heff_tail(heff_dup(v_bind_246), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam1, 1, 3, (V[]){v_malg_245, v_bind_246, v_k_244})});
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_sol_241 = heff_env(self)[1];
  V v_stx_242 = heff_env(self)[2];
  HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_c_247, 3), v_m_240));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_e_2411 = v_field_2410;
      heff_clo_take(self, 3);
      V v_t_2412 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_sol_241}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_stx_242}); V rr_ = heff_rec_reuse_nf(v_e_2411, 57ULL, 6, shape_ty__sol__solStx__arity__name__span, 4035u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_mc_2413 = ({ V a_0 = heff_take_field(v_c_247, 3); V a_1 = v_m_240; V a_2 = v_t_2412; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_m_240); heff_drop_rec(v_t_2412, 6); r_; });
      return ({ V rv_3 = v_mc_2413; V rr_ = heff_rec_reuse_nf(v_c_247, 503ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(self);
      heff_drop(v_field_2410);
      return v_c_247;
    }
  }
}
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_246 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_t_2417 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tr(heff_call(v_malg_245, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})}));
  V f_ = v_bind_246;
  heff_room[0] = v_t_2418;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam1, 1, 8, (V[]){v_hd_246, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_k_247, v_self_245})});
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 9);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get_n(v_c_2412, 7, 9);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_drop(v_x_2446);
  heff_clo_take(self, 1);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_args_2422 = heff_env(self)[0];
  V v_args_27_2437 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2422));
  heff_clo_take(self, 6);
  V v_t_2443 = (g_heff_2eelab_2eunify_2ezipL(v_args_2422, v_args_27_2437));
  V v_t_2444 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214(MK_INT(0LL), v_t_2443));
  V v_t_2445 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2444));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(v_g_240, heff_dup(v_m_242), v_m_242, v_x_2441, v_t_2442, v_t_2445, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam5, 1, 1, (V[]){v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6(V self, V *args) {
  V v_c_2448 = args[0];
  return heff_get_n(v_c_2448, 3, 9);
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2452 = ({ V a_0 = v_x_2451; V a_1 = v_m_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_x_2451); heff_drop(v_m_242); r_; });
  {
    V v_field_2454 = v_t_2452.f[1];
    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
    if ((v_tag_2453 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_246, 3);
      V v_e_2455 = v_field_2454;
      V f_ = v_k_2447;
      args[0] = v_e_2455;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2454);
      V v_t_2456 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2457}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2458;
      heff_room[1] = v_k_2447;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_self_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT2 v_t_2416 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_x_2415, v_x_2411, v_sp_243));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_items_2419 = v_field_2418;
      V v_t_2420 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2419)));
      V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2420); r_; });
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        V v_args_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2419));
        switch (heff_tag_of(v_rhs_244)) {
        case TAG_VNeu: {
          V v_v1_2423 = heff_dup(heff_field(v_rhs_244, 0));
          V v_sp_2424 = heff_dup(heff_field(v_rhs_244, 1));
          switch (heff_tag_of(v_v1_2423)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2423, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2424);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2423, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2424);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HMeta: {
            V v_m_2430 = heff_field(v_v1_2423, 0);
            V v_ru_24v1_2423_24HMeta = heff_take_reuse_n(v_v1_2423, 1ULL, 1);
            if (heff_intEq_c_lent(v_m_2430, v_m_242, 1)) {
              HeffT2 v_t_2431 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_2424; HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2415); heff_drop(v_x_2411); r_; });
              {
                V v_field_2433 = v_t_2431.f[1];
                int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
                if ((v_tag_2432 == ((int64_t)0ULL))) {
                  V v_items_2434 = v_field_2433;
                  V v_t_2435 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2434)));
                  V v_t_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2435); r_; });
                  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
                    heff_drop(v_t_2436);
                    V v_args_27_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2434));
                    V v_t_2438 = (g_heff_2eelab_2eunify_2eeqPatArgs(v_args_27_2437, v_args_2422));
                    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
                      heff_drop_tag(v_rhs_244, 5);
                      heff_drop(v_g_240);
                      heff_drop(v_cs_241);
                      heff_drop(v_m_242);
                      heff_drop_rec(v_hd_246, 3);
                      heff_drop(v_self_245);
                      heff_drop(v_args_2422);
                      heff_drop_cell(v_ru_24v1_2423_24HMeta, 1);
                      heff_drop(v_args_27_2437);
                      heff_drop(v_t_2438);
                      V f_ = v_k_247;
                      args[0] = NTAG(TAG_MkUnit);
                      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                      return heff_tail(f_, 1, args);
                    } else {
                      heff_drop(v_t_2438);
                      V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_27_2437));
                      V v_t_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2422));
                      if (heff_intEq_c(v_t_2439, v_t_2440)) {
                        heff_drop_tag(v_rhs_244, 5);
                        heff_drop(v_cs_241);
                        heff_drop(v_self_245);
                        V v_k_2447 = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam4, 1, 6, (V[]){v_args_2422, v_args_27_2437, v_g_240, heff_dup(v_m_242), heff_dup(v_hd_246), v_k_247});
                        V v_t_2449 = heff_tag_at_n(v_ru_24v1_2423_24HMeta, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam6_clo)})});
                        V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2449}));
                        V f_ = heff_dup(heff_rfield(v_hd_246, 1));
                        heff_room[0] = v_t_2450;
                        heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam7, 1, 3, (V[]){v_m_242, v_k_2447, v_hd_246});
                        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                      } else {
                        heff_drop(v_g_240);
                        heff_drop(v_m_242);
                        heff_drop(v_args_2422);
                        heff_drop(v_args_27_2437);
                        return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(v_ru_24v1_2423_24HMeta, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                      }
                    }
                  } else {
                    heff_drop(v_g_240);
                    heff_drop(v_m_242);
                    heff_drop(v_args_2422);
                    heff_drop(v_items_2434);
                    heff_drop(v_t_2436);
                    return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(v_ru_24v1_2423_24HMeta, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                  }
                } else {
                  heff_drop(v_g_240);
                  heff_drop(v_m_242);
                  heff_drop(v_args_2422);
                  heff_drop(v_field_2433);
                  return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(v_ru_24v1_2423_24HMeta, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                }
              }
            } else {
              heff_drop(v_x_2415);
              heff_drop(v_x_2411);
              heff_drop(v_self_245);
              heff_drop(v_sp_2424);
              heff_drop_cell(v_ru_24v1_2423_24HMeta, 1);
              return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
            }
          }
          case TAG_HError: {
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2424);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
          }
          default: return heff_nomatch(v_v1_2423);
          }
        }
        case TAG_VCode: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VLam: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VCons: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VOpaque: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
        }
        default: return heff_nomatch(v_rhs_244);
        }
      } else {
        heff_drop(v_x_2415);
        heff_drop(v_x_2411);
        heff_drop(v_g_240);
        heff_drop(v_m_242);
        heff_drop(v_items_2419);
        heff_drop(v_t_2421);
        return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
      }
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_g_240);
      heff_drop(v_m_242);
      heff_drop(v_field_2418);
      return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_self_245 = heff_env(self)[7];
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_hd_246, v_k_247, v_self_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam21(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam20(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam19(V self, V *args);
Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_entry, 6, 0};

V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0_clo);
  } else {
    heff_drop(v_t_2418);
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2eelab_2econversion_2eeqHead(v_h_242, v_h_27_244));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1_clo);
        } else {
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam2, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
        }
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam3, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam4, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam5, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2455 = heff_field(v_sp_243, 0);
      V v_v_2456 = heff_field(v_sp_243, 1);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam6, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpApp: {
        V v_sq_27_2463 = heff_field(v_sp_27_245, 0);
        V v_v_27_2464 = heff_field(v_sp_27_245, 1);
        V v_c_2465 = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(v_g_240, v_cs_241, v_h_242, v_sq_2455, v_h_27_244, v_sq_27_2463));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam7, 2, 5, (V[]){v_c_2465, heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_v_2456), heff_dup(v_v_27_2464)});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam9, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam10, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2486 = heff_field(v_sp_243, 0);
      V v_x_2487 = heff_field(v_sp_243, 1);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam11, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam12, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpProj: {
        V v_sq_27_24102 = heff_field(v_sp_27_245, 0);
        V v_x_27_24103 = heff_field(v_sp_27_245, 1);
        V v_c_24104 = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(v_g_240, v_cs_241, v_h_242, v_sq_2486, v_h_27_244, v_sq_27_24102));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam13, 2, 8, (V[]){v_c_24104, heff_dup(v_x_2487), heff_dup(v_x_27_24103), heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam15, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24119 = heff_field(v_sp_243, 0);
      V v_x_24120 = heff_field(v_sp_243, 1);
      V v_v_24121 = heff_field(v_sp_243, 2);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam16, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam17, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam18, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpSpec: {
        V v_sq_27_24144 = heff_field(v_sp_27_245, 0);
        V v_x_27_24145 = heff_field(v_sp_27_245, 1);
        V v_v_27_24146 = heff_field(v_sp_27_245, 2);
        V v_c_24147 = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(v_g_240, v_cs_241, v_h_242, v_sq_24119, v_h_27_244, v_sq_27_24144));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam19, 2, 11, (V[]){v_c_24147, heff_dup(v_x_24120), heff_dup(v_x_27_24145), heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_v_24121), heff_dup(v_v_27_24146), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(a0, a1, a2, a3, a4, a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2426 = heff_take_field(v_hd_2424, 2);
  V v_bind_2427 = heff_get_n(v_hd_2424, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2428 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2429 = heff_tr(heff_call(v_malg_2426, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
  V f_ = v_bind_2427;
  args[0] = v_t_2429;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam3(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2434 = heff_take_field(v_hd_2432, 2);
  V v_bind_2435 = heff_get_n(v_hd_2432, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2436 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2437 = heff_tr(heff_call(v_malg_2434, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  V f_ = v_bind_2435;
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam4(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2442 = heff_take_field(v_hd_2440, 2);
  V v_bind_2443 = heff_get_n(v_hd_2440, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2444 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2445 = heff_tr(heff_call(v_malg_2442, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})}));
  V f_ = v_bind_2443;
  args[0] = v_t_2445;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam5(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2451 = heff_take_field(v_hd_2449, 2);
  V v_bind_2452 = heff_get_n(v_hd_2449, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2453 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2454 = heff_tr(heff_call(v_malg_2451, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})}));
  V f_ = v_bind_2452;
  args[0] = v_t_2454;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam6(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2459 = heff_take_field(v_hd_2457, 2);
  V v_bind_2460 = heff_get_n(v_hd_2457, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2461 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2462 = heff_tr(heff_call(v_malg_2459, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})}));
  V f_ = v_bind_2460;
  args[0] = v_t_2462;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam8(V self, V *args) {
  V v_x_2468 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2456 = heff_env(self)[2];
  V v_v_27_2464 = heff_env(self)[3];
  V v_hd_2466 = heff_env(self)[4];
  V v_k_2467 = heff_env(self)[5];
  heff_drop(v_x_2468);
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(v_g_240, v_cs_241, v_v_2456, v_v_27_2464, v_hd_2466, v_k_2467));
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam7(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2456 = heff_env(self)[3];
  V v_v_27_2464 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2465;
  args[0] = heff_dup(v_hd_2466);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2456, v_v_27_2464, v_hd_2466, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam9(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k2_2472 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2473 = heff_take_field(v_hd_2471, 2);
  V v_bind_2474 = heff_get_n(v_hd_2471, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2475 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2476 = heff_tr(heff_call(v_malg_2473, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})}));
  V f_ = v_bind_2474;
  args[0] = v_t_2476;
  args[1] = v_k2_2472;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam10(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k2_2481 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2482 = heff_take_field(v_hd_2480, 2);
  V v_bind_2483 = heff_get_n(v_hd_2480, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2484 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2485 = heff_tr(heff_call(v_malg_2482, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})}));
  V f_ = v_bind_2483;
  args[0] = v_t_2485;
  args[1] = v_k2_2481;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam11(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k2_2489 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2490 = heff_take_field(v_hd_2488, 2);
  V v_bind_2491 = heff_get_n(v_hd_2488, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2492 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2493 = heff_tr(heff_call(v_malg_2490, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})}));
  V f_ = v_bind_2491;
  args[0] = v_t_2493;
  args[1] = v_k2_2489;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam12(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k2_2497 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2498 = heff_take_field(v_hd_2496, 2);
  V v_bind_2499 = heff_get_n(v_hd_2496, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24100 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24101 = heff_tr(heff_call(v_malg_2498, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})}));
  V f_ = v_bind_2499;
  args[0] = v_t_24101;
  args[1] = v_k2_2497;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam14(V self, V *args) {
  V v_x_24107 = args[0];
  V v_x_2487 = heff_env(self)[0];
  V v_x_27_24103 = heff_env(self)[1];
  V v_k_24106 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_24105 = heff_env(self)[8];
  heff_drop(v_x_24107);
  heff_clo_take(self, 9);
  if (heff_strEq_c(v_x_2487, v_x_27_24103)) {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop_rec(v_hd_24105, 3);
    V f_ = v_k_24106;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_24108 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_24109 = heff_tr(heff_call(heff_take_field(v_hd_24105, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})}));
    V f_ = heff_get_n(v_hd_24105, 1, 3);
    heff_room[0] = v_t_24109;
    heff_room[1] = v_k_24106;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam13(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k_24106 = args[1];
  V v_c_24104 = heff_env(self)[0];
  V v_x_2487 = heff_env(self)[1];
  V v_x_27_24103 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_24104;
  args[0] = heff_dup(v_hd_24105);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam14, 1, 9, (V[]){v_x_2487, v_x_27_24103, v_k_24106, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24105});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam15(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k2_24114 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_24115 = heff_take_field(v_hd_24113, 2);
  V v_bind_24116 = heff_get_n(v_hd_24113, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24117 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24118 = heff_tr(heff_call(v_malg_24115, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24117})}));
  V f_ = v_bind_24116;
  args[0] = v_t_24118;
  args[1] = v_k2_24114;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam16(V self, V *args) {
  V v_hd_24122 = args[0];
  V v_k2_24123 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_24124 = heff_take_field(v_hd_24122, 2);
  V v_bind_24125 = heff_get_n(v_hd_24122, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24126 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24127 = heff_tr(heff_call(v_malg_24124, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24126})}));
  V f_ = v_bind_24125;
  args[0] = v_t_24127;
  args[1] = v_k2_24123;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam17(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k2_24131 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_24132 = heff_take_field(v_hd_24130, 2);
  V v_bind_24133 = heff_get_n(v_hd_24130, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24134 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24135 = heff_tr(heff_call(v_malg_24132, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24134})}));
  V f_ = v_bind_24133;
  args[0] = v_t_24135;
  args[1] = v_k2_24131;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam18(V self, V *args) {
  V v_hd_24138 = args[0];
  V v_k2_24139 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_24140 = heff_take_field(v_hd_24138, 2);
  V v_bind_24141 = heff_get_n(v_hd_24138, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24142 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24143 = heff_tr(heff_call(v_malg_24140, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24142})}));
  V f_ = v_bind_24141;
  args[0] = v_t_24143;
  args[1] = v_k2_24139;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam21(V self, V *args) {
  V v_x_24153 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_24121 = heff_env(self)[2];
  V v_v_27_24146 = heff_env(self)[3];
  V v_hd_24148 = heff_env(self)[4];
  V v_k_24149 = heff_env(self)[5];
  heff_drop(v_x_24153);
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(v_g_240, v_cs_241, v_v_24121, v_v_27_24146, v_hd_24148, v_k_24149));
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam20(V self, V *args) {
  V v_x_24150 = args[0];
  V v_x_24120 = heff_env(self)[0];
  V v_x_27_24145 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_v_24121 = heff_env(self)[4];
  V v_v_27_24146 = heff_env(self)[5];
  V v_hd_24148 = heff_env(self)[6];
  V v_k_24149 = heff_env(self)[7];
  V v_h_242 = heff_env(self)[8];
  V v_sp_243 = heff_env(self)[9];
  V v_h_27_244 = heff_env(self)[10];
  V v_sp_27_245 = heff_env(self)[11];
  heff_drop(v_x_24150);
  heff_clo_take(self, 12);
  if (heff_strEq_c(v_x_24120, v_x_27_24145)) {
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    return (g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(v_g_240, v_cs_241, v_v_24121, v_v_27_24146, v_hd_24148, v_k_24149));
  } else {
    V v_t_24151 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_24152 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24148, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24151})}));
    V f_ = heff_dup(heff_rfield(v_hd_24148, 1));
    heff_room[0] = v_t_24152;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam21, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24121, v_v_27_24146, v_hd_24148, v_k_24149});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam19(V self, V *args) {
  V v_hd_24148 = args[0];
  V v_k_24149 = args[1];
  V v_c_24147 = heff_env(self)[0];
  V v_x_24120 = heff_env(self)[1];
  V v_x_27_24145 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_v_24121 = heff_env(self)[5];
  V v_v_27_24146 = heff_env(self)[6];
  V v_h_242 = heff_env(self)[7];
  V v_sp_243 = heff_env(self)[8];
  V v_h_27_244 = heff_env(self)[9];
  V v_sp_27_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_24147;
  args[0] = heff_dup(v_hd_24148);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_lam20, 1, 12, (V[]){v_x_24120, v_x_27_24145, v_g_240, v_cs_241, v_v_24121, v_v_27_24146, v_hd_24148, v_k_24149, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(V v_g_240, V v_cs_241, V v_a_242, V v_b_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_246 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_247 = heff_dup(heff_field(v_b_243, 0));
      switch (heff_tag_of(v_u_246)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        case TAG_LargeU: {
          V v_t_248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_249, v_z_245});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          V v_t_2410 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_2411 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2411, v_z_245});
        }
        case TAG_LargeU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      default: return heff_nomatch(v_u_246);
      }
    }
    default: {
      heff_drop(v_u_246);
      V v_t_2412 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2413 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2413, v_z_245});
    }
    }
  }
  case TAG_VDecode: {
    V v_h_2414 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2415 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VDecode: {
      V v_h_27_2419 = heff_field(v_b_243, 0);
      V v_sp_27_2420 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      V v_t_2424 = ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_h_2414; V a_3 = v_sp_2415; V a_4 = v_h_27_2419; V a_5 = v_sp_27_2420; V r_ = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_g_240); heff_drop_rec(v_cs_241, 2); heff_drop(v_h_2414); heff_drop(v_sp_2415); heff_drop(v_h_27_2419); heff_drop(v_sp_27_2420); r_; });
      return heff_tail(v_t_2424, 2, (V[]){v_z_244, v_z_245});
    }
    default: {
      heff_drop(v_g_240);
      heff_drop(v_h_2414);
      heff_drop(v_sp_2415);
      V v_t_2425 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2426, v_z_245});
    }
    }
  }
  case TAG_VFunction: {
    V v_level_2427 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2428 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2429 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2430 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VFunction: {
      V v_level_27_2433 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_2434 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_2435 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_2436 = heff_dup(heff_field(v_b_243, 3));
      V v_t_2439 = ({ V a_0 = v_level_2427; V a_1 = v_level_27_2433; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2427); heff_drop(v_level_27_2433); r_; });
      V v_t_2440;
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop(v_t_2439);
        switch (heff_tag_of(v_implicit_2430)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_2436)) {
          case TAG_Expl: {
            v_t_2440 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_2436);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_2436)) {
          case TAG_Expl: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_2440 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_2436);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_2436)) {
          case TAG_Expl: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_2440 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_2436);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2430);
        }
      } else {
        heff_drop(v_implicit_2430);
        heff_drop(v_implicit_27_2436);
        heff_drop(v_t_2439);
        v_t_2440 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop_tag(v_a_242, 6);
        heff_drop_tag(v_b_243, 6);
        heff_drop(v_t_2440);
        HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2428), v_dom_27_2434, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam0, 1, 7, (V[]){v_cs_241, v_dom_2428, v_cod_2429, v_cod_27_2435, v_g_240, v_z_244, v_z_245}));
      } else {
        heff_drop(v_g_240);
        heff_drop(v_dom_2428);
        heff_drop(v_cod_2429);
        heff_drop(v_dom_27_2434);
        heff_drop(v_cod_27_2435);
        heff_drop(v_t_2440);
        V v_t_2473 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        V v_t_2474 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})}));
        return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2474, v_z_245});
      }
    }
    default: {
      heff_drop(v_g_240);
      heff_drop(v_level_2427);
      heff_drop(v_dom_2428);
      heff_drop(v_cod_2429);
      heff_drop(v_implicit_2430);
      V v_t_2475 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2476 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2476, v_z_245});
    }
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_2481 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_2482 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2482, v_z_245});
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_2484 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_2485 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2485, v_z_245});
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: {
      V v_t_2486 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2487 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2487, v_z_245});
    }
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: {
      V v_t_2488 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2489 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2489, v_z_245});
    }
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: {
      V v_t_2490 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2491 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2491, v_z_245});
    }
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24111;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24111 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    if ((heff_dup(v_t_24111) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24111);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24111);
      V v_t_24112 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24113 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24113, v_z_245});
    }
  }
  case TAG_VPrimArray: {
    V v_x_24114 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VPrimArray: {
      V v_y_24115 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(v_g_240, v_cs_241, v_x_24114, v_y_24115, v_z_244, v_z_245);
    }
    default: {
      heff_drop(v_g_240);
      heff_drop(v_x_24114);
      V v_t_24116 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24117 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24116})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24117, v_z_245});
    }
    }
  }
  case TAG_VFixed: {
    V v_w_24118 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24119 = ({ V a_0 = v_w_24118; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24118); r_; });
    if ((heff_dup(v_t_24119) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24119);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24119);
      V v_t_24120 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24121 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24120})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24121, v_z_245});
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam1(V self, V *args) {
  V v_u_2443 = args[0];
  V v_dom_2428 = heff_env(self)[0];
  heff_drop(v_u_2443);
  heff_clo_take(self, 1);
  return v_dom_2428;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam2(V self, V *args) {
  V v_w_2456 = args[0];
  V v_v_2444 = heff_env(self)[0];
  heff_drop(v_w_2456);
  heff_clo_take(self, 1);
  return v_v_2444;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam3(V self, V *args) {
  V v_w_2466 = args[0];
  V v_v_2444 = heff_env(self)[0];
  heff_drop(v_w_2466);
  heff_clo_take(self, 1);
  return v_v_2444;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam0(V self, V *args) {
  V v_x_2441 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2428 = heff_env(self)[1];
  V v_cod_2429 = heff_env(self)[2];
  V v_cod_27_2435 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  heff_clo_take(self, 7);
  V v_v_2444 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2442, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam1, 1, 1, (V[]){v_dom_2428}), NTAG(TAG_Nothing)));
  V v_t_2449;
  switch (heff_tag_of(v_cod_2429)) {
  case TAG_MkClo: {
    V v_n_2445 = heff_dup(heff_field(v_cod_2429, 0));
    v_t_2449 = v_n_2445;
    break;
  }
  case TAG_CloConst: {
    v_t_2449 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_str0);
    break;
  }
  default: heff_nomatch(v_cod_2429);
  }
  V v_t_2450 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, heff_take_field(v_cs_241, 1)});
  V v_cs_2452 = ({ V rv_0 = v_t_2450; V rv_1 = v_t_2451; V rr_ = heff_rec_reuse_nf(v_cs_241, 0ULL, 2, shape_len__names, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_x1_2458;
  switch (heff_tag_of(v_cod_2429)) {
  case TAG_MkClo: {
    V v_vs_2454 = heff_field(v_cod_2429, 1);
    V v_body_2455 = heff_field(v_cod_2429, 2);
    heff_take_n(v_cod_2429, 6ULL, 3);
    v_x1_2458 = heff_tr(heff_call(v_body_2455, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2454, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam2, 1, 1, (V[]){heff_dup(v_v_2444)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2457 = heff_field(v_cod_2429, 0);
    heff_take_n(v_cod_2429, 1ULL, 1);
    v_x1_2458 = v_body_2457;
    break;
  }
  default: heff_nomatch(v_cod_2429);
  }
  V v_a_2462;
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nom: {
    V v_x_2459 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    v_a_2462 = v_x_2459;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    v_a_2462 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    v_a_2462 = v_x_2461;
    break;
  }
  default: heff_nomatch(v_x1_2458);
  }
  V v_x1_2468;
  switch (heff_tag_of(v_cod_27_2435)) {
  case TAG_MkClo: {
    V v_vs_2464 = heff_field(v_cod_27_2435, 1);
    V v_body_2465 = heff_field(v_cod_27_2435, 2);
    heff_take_n(v_cod_27_2435, 6ULL, 3);
    v_x1_2468 = heff_tr(heff_call(v_body_2465, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2464, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_lam3, 1, 1, (V[]){v_v_2444})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2467 = heff_field(v_cod_27_2435, 0);
    heff_take_n(v_cod_27_2435, 1ULL, 1);
    heff_drop(v_v_2444);
    v_x1_2468 = v_body_2467;
    break;
  }
  default: heff_nomatch(v_cod_27_2435);
  }
  V v_b_2472;
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_Nom: {
    V v_x_2469 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_b_2472 = v_x_2469;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2468, 0ULL, 1);
    v_b_2472 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2471 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_b_2472 = v_x_2471;
    break;
  }
  default: heff_nomatch(v_x1_2468);
  }
  return (g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(v_g_240, v_cs_2452, v_a_2462, v_b_2472, v_z_244, v_z_245));
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_247 = heff_field(v_x6_244, 0);
    V v_l_248 = heff_field(v_x6_244, 1);
    V v_f_249 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_2410 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_pr_242, 2), heff_rfield(v_pr_242, 0), heff_rfield(v_pr_242, 1)));
    V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_2412 = heff_intAdd(heff_take_field(v_pr_242, 1), MK_INT(1LL));
    V v_pr_2413 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_2411, v_t_2412, v_t_2410});
    V v_t_2414 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2416 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2414, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2418 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam1, 1, 1, (V[]){v_v_2416})})}));
    V v_t_2425;
    switch (heff_tag_of(v_v_2418)) {
    case TAG_Nom: {
      V v_v_2419 = heff_field(v_v_2418, 0);
      heff_take_n(v_v_2418, 1ULL, 1);
      v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_v_2419}));
      break;
    }
    case TAG_Describe: {
      V v_v_2420 = heff_field(v_v_2418, 0);
      heff_take_n(v_v_2418, 1ULL, 1);
      v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_v_2420}));
      break;
    }
    case TAG_Become: {
      V v_v_2421 = heff_field(v_v_2418, 0);
      heff_take_n(v_v_2418, 1ULL, 1);
      v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_v_2421});
      break;
    }
    default: heff_nomatch(v_v_2418);
    }
    return heff_tail(v_t_2425, 2, (V[]){v_z_245, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam4, 1, 2, (V[]){v_z_246, v_x_247})});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_t_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_v_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2428}));
      break;
    }
    case TAG_Describe: {
      V v_v_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2429}));
      break;
    }
    case TAG_Become: {
      V v_v_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam5, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_tail(v_t_2434, 2, (V[]){v_z_245, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam7, 1, 1, (V[]){v_z_246})});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam0(V self, V *args) {
  V v_u_2415 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_drop(v_u_2415);
  heff_clo_take(self, 1);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  V v_v_2416 = heff_env(self)[0];
  heff_drop(v_u_2417);
  heff_clo_take(self, 1);
  return v_v_2416;
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2413 = heff_env(self)[2];
  V v_v_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_2413, v_v_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam3, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_247, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_242, v_v_2430, v_hd_2431, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam6, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam0, 1, 1, (V[]){v_t0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam1, 1, 5, (V[]){v_k_245, v_m_241, v_hd_244, v_g_240, v_pr_242})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_t0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_sp_2412; V a_4 = v_x_2421; V r_ = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_240); heff_drop(v_m_241); heff_drop(v_pr_242); heff_drop(v_x_2421); r_; });
  V f_ = v_t_2422;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam4, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2424 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  V v_implicit_2427 = heff_env(self)[3];
  V v_dflt_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2424, v_x_2430, v_x_2431, v_implicit_2427, v_dflt_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2425 = heff_env(self)[3];
  V v_cod_2426 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2424 = heff_env(self)[7];
  V v_implicit_2427 = heff_env(self)[8];
  V v_dflt_2428 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(v_g_240, v_m_241, v_pr_242, v_dom_2425, v_cod_2426, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam6, 1, 5, (V[]){v_k_245, v_level_2424, v_x_2430, v_implicit_2427, v_dflt_2428})));
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_fieldTypes_2434 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2432 = heff_env(self)[2];
  V v_defaults_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2438 = ({ V rv_2 = heff_arrayFromList(v_x_2437); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2434, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2432, v_t_2438, v_defaults_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam9(V self, V *args) {
  V v_a_2446 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_t_2447 = heff_tr(heff_call(v_a_2446, 1, (V[]){NTAG(TAG_MkUnit)}));
  heff_clo_take(self, 3);
  V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_m_241;
  heff_room[2] = v_pr_242;
  heff_room[3] = v_t_2447;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam11(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_2444 = heff_env(self)[0];
  V v_k_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2444, heff_arrayFromList(v_x_2451)});
  V f_ = v_k_2450;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam10(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_c_2448 = heff_env(self)[0];
  V v_k_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2448;
  args[0] = v_hd_2449;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam11, 1, 2, (V[]){v_k_2444, v_k_2450});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam8(V self, V *args) {
  V v_p_2443 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  switch (heff_tag_of(v_p_2443)) {
  case TAG_MkPair: {
    V v_k_2444 = heff_field(v_p_2443, 0);
    V v_args_2445 = heff_field(v_p_2443, 1);
    heff_take_n(v_p_2443, 3ULL, 2);
    heff_clo_take(self, 3);
    V v_c_2448 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam9, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2445)));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam10, 2, 2, (V[]){v_c_2448, v_k_2444});
  }
  default: return heff_nomatch(v_p_2443);
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam12(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_t_2455 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2454)));
  V v_t_2456 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2454));
  V v_t_2457 = (g_list_2emap_24s1173914895x100384474(v_x_2454));
  V v_t_2458 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2455), v_t_2456, heff_arrayFromList(v_t_2457)});
  V v_x_2459 = heff_tag_n(TAG_SSum, 1, (V[]){v_t_2458});
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam13(V self, V *args) {
  V v_x_2461 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2461});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    V v_u_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_pr_242);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SU, 1, (V[]){v_u_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_sp_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_HMeta: {
      V v_m_27_2416 = heff_field(v_it1_2411, 0);
      V v_ru_24it1_2411_24HMeta = heff_take_reuse_n(v_it1_2411, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2416, v_m_241, 0)) {
        heff_clo_take(self, 5);
        heff_drop(v_m_241);
        heff_drop(v_g_240);
        heff_drop(v_pr_242);
        heff_drop(v_sp_2412);
        heff_drop(v_m_27_2416);
        V v_t_2417 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2418 = heff_tag_at_n(v_ru_24it1_2411_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
        V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2418}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2419;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2411_24HMeta, 1);
        heff_clo_take(self, 5);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(v_g_240, v_m_241, v_pr_242, v_m_27_2416, v_sp_2412, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam2, 1, 1, (V[]){v_k_245})));
      }
    }
    default: {
      heff_clo_take(self, 5);
      return (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2411, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245})));
    }
    }
  }
  case TAG_VFunction: {
    V v_level_2424 = heff_field(v_x_249, 0);
    V v_dom_2425 = heff_field(v_x_249, 1);
    V v_cod_2426 = heff_field(v_x_249, 2);
    V v_implicit_2427 = heff_field(v_x_249, 3);
    V v_dflt_2428 = heff_field(v_x_249, 4);
    heff_take_n(v_x_249, 31ULL, 6);
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2425), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam5, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2425, v_cod_2426, v_hd_244, v_k_245, v_level_2424, v_implicit_2427, v_dflt_2428})));
  }
  case TAG_VRecord: {
    V v_level_2432 = heff_field(v_x_249, 0);
    V v_capture_2433 = heff_field(v_x_249, 1);
    V v_fieldTypes_2434 = heff_field(v_x_249, 2);
    V v_defaults_2435 = heff_field(v_x_249, 3);
    heff_take_n(v_x_249, 15ULL, 4);
    V v_t_2436 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2434, 2)));
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2eunify_2erenameRecordFields_24s353070585x1329207051(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2433, v_t_2436, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam7, 1, 4, (V[]){v_fieldTypes_2434, v_k_245, v_level_2432, v_defaults_2435})));
  }
  case TAG_VSum: {
    V v_vs_2439 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_keys_2440 = heff_take_field(v_vs_2439, 0);
    V v_values_2441 = heff_get_n(v_vs_2439, 2, 3);
    V v_t_2442 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2440), heff_arrayToList(v_values_2441)));
    heff_clo_take(self, 5);
    V v_t_2453 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2442));
    V f_ = v_t_2453;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam12, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_pr_242);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_pr_242);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_pr_242);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimRune: {
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_pr_242);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimRune);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2460 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, v_pr_242, v_a_2460, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_lam13, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2462 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_pr_242);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2462});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
HEFF_LIT(g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_str0, 1, "x");
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_entry, 8, 0};

V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489(V v_g_240, V v_cs_241, V v_x4_242, V v_cb_243, V v_a_244, V v_b_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_VNeu: {
    V v_h_248 = heff_field(v_x4_242, 0);
    V v_sp_249 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 5);
    switch (heff_tag_of(v_cb_243)) {
    case TAG_VNeu: {
      V v_h_27_2413 = heff_field(v_cb_243, 0);
      V v_sp_27_2414 = heff_field(v_cb_243, 1);
      heff_take_n(v_cb_243, 3ULL, 5);
      heff_drop(v_a_244);
      heff_drop(v_b_245);
      V v_t_2418 = ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_h_248; V a_3 = v_sp_249; V a_4 = v_h_27_2413; V a_5 = v_sp_27_2414; V r_ = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_g_240); heff_drop_rec(v_cs_241, 2); heff_drop(v_h_248); heff_drop(v_sp_249); heff_drop(v_h_27_2413); heff_drop(v_sp_27_2414); r_; });
      return heff_tail(v_t_2418, 2, (V[]){v_z_246, v_z_247});
    }
    case TAG_VCode: {
      V v_ru_24cb_243_24VCode = heff_take_reuse_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_h_248);
      heff_drop(v_sp_249);
      V v_t_2420 = heff_tag_at_n(v_ru_24cb_243_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2421 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2421, v_z_247});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_243, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_h_248);
      heff_drop(v_sp_249);
      V v_t_2424 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2425 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2425, v_z_247});
    }
    case TAG_VCons: {
      V v_ru_24cb_243_24VCons = heff_take_reuse_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_h_248);
      heff_drop(v_sp_249);
      V v_t_2427 = heff_tag_at_n(v_ru_24cb_243_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2428 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2428, v_z_247});
    }
    case TAG_VOpaque: {
      heff_drop(v_g_240);
      heff_drop(v_h_248);
      heff_drop(v_sp_249);
      V v_t_2429 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2430 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2430, v_z_247});
    }
    default: return heff_nomatch(v_cb_243);
    }
  }
  case TAG_VCode: {
    V v_t_2431 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24VCode = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    switch (heff_tag_of(v_cb_243)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_243, 0ULL, 5);
      heff_drop(v_g_240);
      heff_drop(v_t_2431);
      V v_t_2437 = heff_tag_at_n(v_ru_24x4_242_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2438 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2438, v_z_247});
    }
    case TAG_VCode: {
      V v_t_27_2439 = heff_field(v_cb_243, 0);
      heff_take_n(v_cb_243, 1ULL, 1);
      heff_drop(v_a_244);
      heff_drop(v_b_245);
      heff_drop_cell(v_ru_24x4_242_24VCode, 1);
      return (g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(v_g_240, v_cs_241, v_t_2431, v_t_27_2439, v_z_246, v_z_247));
    }
    case TAG_VLam: {
      heff_take_n(v_cb_243, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_t_2431);
      V v_t_2442 = heff_tag_at_n(v_ru_24x4_242_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2443 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2443, v_z_247});
    }
    case TAG_VCons: {
      heff_take_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_t_2431);
      V v_t_2445 = heff_tag_at_n(v_ru_24x4_242_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2446 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2446, v_z_247});
    }
    case TAG_VOpaque: {
      heff_drop(v_g_240);
      heff_drop(v_t_2431);
      V v_t_2447 = heff_tag_at_n(v_ru_24x4_242_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2448 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2448, v_z_247});
    }
    default: return heff_nomatch(v_cb_243);
    }
  }
  case TAG_VLam: {
    V v_d_2449 = heff_field(v_x4_242, 0);
    V v_c_2450 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24VLam = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_cb_243)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_243, 0ULL, 5);
      heff_drop(v_g_240);
      heff_drop(v_d_2449);
      heff_drop(v_c_2450);
      heff_drop_cell(v_ru_24x4_242_24VLam, 2);
      V v_t_2456 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2457 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2457, v_z_247});
    }
    case TAG_VCode: {
      V v_ru_24cb_243_24VCode = heff_take_reuse_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_d_2449);
      heff_drop(v_c_2450);
      heff_drop_cell(v_ru_24x4_242_24VLam, 2);
      V v_t_2459 = heff_tag_at_n(v_ru_24cb_243_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2460 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2460, v_z_247});
    }
    case TAG_VLam: {
      V v_c_27_2462 = heff_field(v_cb_243, 1);
      heff_take_n(v_cb_243, 2ULL, 2);
      heff_drop(v_a_244);
      heff_drop(v_b_245);
      V v_t_2463 = heff_tr(heff_call(v_d_2449, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2464 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2463)));
      V v_a_2476;
      switch (heff_tag_of(v_t_2464)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_2467 = heff_field(v_t_2464, 1);
        heff_take_n(v_t_2464, 2ULL, 4);
        heff_drop(v_t_2463);
        v_a_2476 = v_dom_2467;
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_2464, 0ULL, 3);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeInt: {
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeFloat: {
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeString: {
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeRune: {
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_NoRules: {
        v_a_2476 = v_t_2463;
        break;
      }
      default: heff_nomatch(v_t_2464);
      }
      V v_t_2477 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
      V v_v_2479 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2477, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam0, 1, 1, (V[]){v_a_2476}), NTAG(TAG_Nothing)));
      V v_t_2484;
      switch (heff_tag_of(v_c_2450)) {
      case TAG_MkClo: {
        V v_n_2480 = heff_dup(heff_field(v_c_2450, 0));
        v_t_2484 = v_n_2480;
        break;
      }
      case TAG_CloConst: {
        v_t_2484 = ((V)&g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_str0);
        break;
      }
      default: heff_nomatch(v_c_2450);
      }
      V v_t_2485 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
      V v_t_2486 = heff_tag_at_n(v_ru_24x4_242_24VLam, TAG_Cons, 2, (V[]){v_t_2484, heff_dup(heff_rfield(v_cs_241, 1))});
      V v_cs_2487 = ({ V rv_0 = v_t_2485; V rv_1 = v_t_2486; V rr_ = heff_rec_reuse_nf(v_cs_241, 0ULL, 2, shape_len__names, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x1_2493;
      switch (heff_tag_of(v_c_2450)) {
      case TAG_MkClo: {
        V v_vs_2489 = heff_field(v_c_2450, 1);
        V v_body_2490 = heff_field(v_c_2450, 2);
        heff_take_n(v_c_2450, 6ULL, 3);
        v_x1_2493 = heff_tr(heff_call(v_body_2490, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2489, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam1, 1, 1, (V[]){heff_dup(v_v_2479)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2492 = heff_field(v_c_2450, 0);
        heff_take_n(v_c_2450, 1ULL, 1);
        v_x1_2493 = v_body_2492;
        break;
      }
      default: heff_nomatch(v_c_2450);
      }
      V v_a_2497;
      switch (heff_tag_of(v_x1_2493)) {
      case TAG_Nom: {
        V v_x_2494 = heff_field(v_x1_2493, 0);
        heff_take_n(v_x1_2493, 1ULL, 1);
        v_a_2497 = v_x_2494;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2493, 0ULL, 1);
        v_a_2497 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2496 = heff_field(v_x1_2493, 0);
        heff_take_n(v_x1_2493, 1ULL, 1);
        v_a_2497 = v_x_2496;
        break;
      }
      default: heff_nomatch(v_x1_2493);
      }
      V v_x1_24103;
      switch (heff_tag_of(v_c_27_2462)) {
      case TAG_MkClo: {
        V v_vs_2499 = heff_field(v_c_27_2462, 1);
        V v_body_24100 = heff_field(v_c_27_2462, 2);
        heff_take_n(v_c_27_2462, 6ULL, 3);
        v_x1_24103 = heff_tr(heff_call(v_body_24100, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2499, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam2, 1, 1, (V[]){v_v_2479})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24102 = heff_field(v_c_27_2462, 0);
        heff_take_n(v_c_27_2462, 1ULL, 1);
        heff_drop(v_v_2479);
        v_x1_24103 = v_body_24102;
        break;
      }
      default: heff_nomatch(v_c_27_2462);
      }
      V v_b_24107;
      switch (heff_tag_of(v_x1_24103)) {
      case TAG_Nom: {
        V v_x_24104 = heff_field(v_x1_24103, 0);
        heff_take_n(v_x1_24103, 1ULL, 1);
        v_b_24107 = v_x_24104;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24103, 0ULL, 1);
        v_b_24107 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24106 = heff_field(v_x1_24103, 0);
        heff_take_n(v_x1_24103, 1ULL, 1);
        v_b_24107 = v_x_24106;
        break;
      }
      default: heff_nomatch(v_x1_24103);
      }
      return (g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(v_g_240, v_cs_2487, v_a_2497, v_b_24107, v_z_246, v_z_247));
    }
    case TAG_VCons: {
      V v_ru_24cb_243_24VCons = heff_take_reuse_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_d_2449);
      heff_drop(v_c_2450);
      heff_drop_cell(v_ru_24x4_242_24VLam, 2);
      V v_t_24109 = heff_tag_at_n(v_ru_24cb_243_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24110 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24110, v_z_247});
    }
    case TAG_VOpaque: {
      heff_drop(v_g_240);
      heff_drop(v_d_2449);
      heff_drop(v_c_2450);
      heff_drop_cell(v_ru_24x4_242_24VLam, 2);
      V v_t_24111 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24112 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24111})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24112, v_z_247});
    }
    default: return heff_nomatch(v_cb_243);
    }
  }
  case TAG_VCons: {
    V v_d_24113 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24VCons = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    switch (heff_tag_of(v_cb_243)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_243, 0ULL, 5);
      heff_drop(v_g_240);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24119 = heff_tag_at_n(v_ru_24x4_242_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24120 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24119})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24120, v_z_247});
    }
    case TAG_VCode: {
      heff_take_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24122 = heff_tag_at_n(v_ru_24x4_242_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24123 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24123, v_z_247});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_243, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24126 = heff_tag_at_n(v_ru_24x4_242_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24127 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24126})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24127, v_z_247});
    }
    case TAG_VCons: {
      V v_d_27_24128 = heff_field(v_cb_243, 0);
      heff_take_n(v_cb_243, 1ULL, 1);
      heff_drop(v_a_244);
      heff_drop(v_b_245);
      heff_drop_cell(v_ru_24x4_242_24VCons, 1);
      V v_t_24129 = heff_arrayToList(heff_get_n(v_d_24113, 2, 3));
      V v_t_24130 = heff_arrayToList(heff_get_n(v_d_27_24128, 2, 3));
      V v_t_24131 = (g_heff_2eelab_2eunify_2ezipL(v_t_24129, v_t_24130));
      return ({ V a_0 = v_t_24131; V a_1 = heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam3, 1, 2, (V[]){v_g_240, v_cs_241}); V a_2 = v_z_246; V a_3 = v_z_247; V r_ = (g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(a_0, a_1, a_2, a_3)); heff_drop(v_t_24131); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_g_240);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24143 = heff_tag_at_n(v_ru_24x4_242_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24144 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24144, v_z_247});
    }
    default: return heff_nomatch(v_cb_243);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_g_240);
    heff_drop_rec(v_cs_241, 2);
    heff_drop(v_cb_243);
    heff_drop(v_a_244);
    heff_drop(v_b_245);
    heff_drop_rec(v_z_246, 3);
    return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam0(V self, V *args) {
  V v_u_2478 = args[0];
  V v_a_2476 = heff_env(self)[0];
  heff_drop(v_u_2478);
  heff_clo_take(self, 1);
  return v_a_2476;
}
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam1(V self, V *args) {
  V v_w_2491 = args[0];
  V v_v_2479 = heff_env(self)[0];
  heff_drop(v_w_2491);
  heff_clo_take(self, 1);
  return v_v_2479;
}
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam2(V self, V *args) {
  V v_w_24101 = args[0];
  V v_v_2479 = heff_env(self)[0];
  heff_drop(v_w_24101);
  heff_clo_take(self, 1);
  return v_v_2479;
}
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_lam3(V self, V *args) {
  V v_p_24132 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  switch (heff_tag_of(v_p_24132)) {
  case TAG_MkPair: {
    V v_x_24133 = heff_field(v_p_24132, 0);
    V v_y_24134 = heff_field(v_p_24132, 1);
    heff_take_n(v_p_24132, 3ULL, 2);
    V v_a_24138;
    switch (heff_tag_of(v_x_24133)) {
    case TAG_Nom: {
      V v_x_24135 = heff_field(v_x_24133, 0);
      heff_take_n(v_x_24133, 1ULL, 1);
      v_a_24138 = v_x_24135;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x_24133, 0ULL, 1);
      v_a_24138 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24137 = heff_field(v_x_24133, 0);
      heff_take_n(v_x_24133, 1ULL, 1);
      v_a_24138 = v_x_24137;
      break;
    }
    default: heff_nomatch(v_x_24133);
    }
    V v_b_24142;
    switch (heff_tag_of(v_y_24134)) {
    case TAG_Nom: {
      V v_x_24139 = heff_field(v_y_24134, 0);
      heff_take_n(v_y_24134, 1ULL, 1);
      v_b_24142 = v_x_24139;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_y_24134, 0ULL, 1);
      v_b_24142 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24141 = heff_field(v_y_24134, 0);
      heff_take_n(v_y_24134, 1ULL, 1);
      v_b_24142 = v_x_24141;
      break;
    }
    default: heff_nomatch(v_y_24134);
    }
    heff_clo_take(self, 2);
    V f_ = ((V)&g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_clo);
    heff_room[0] = v_g_240;
    heff_room[1] = v_cs_241;
    heff_room[2] = v_a_24138;
    heff_room[3] = v_b_24142;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_p_24132);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam11(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam11, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_entry, 7, 0};

V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_248 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_249 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s868530262x539343671(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_pr_2410 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_get_n(v_cs_241, 0, 2), v_t_247, v_t_249});
  V v_k_2411 = heff_dup(heff_rfield(v_z_245, 0));
  V v_t_2413 = heff_tr(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(heff_dup(v_g_240), heff_dup(v_m_242), v_pr_2410, v_rhs_244, heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam0, 1, 1, (V[]){v_k_2411})));
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam1, 1, 1, (V[]){heff_dup(v_z_245)})})});
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2454}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2455, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam7, 1, 5, (V[]){v_z_246, v_args_243, v_g_240, v_m_242, v_z_245})});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_s_2414 = heff_env(self)[0];
  V v_malg_2420 = heff_take_field(v_hd_2418, 2);
  V v_bind_2421 = heff_get_n(v_hd_2418, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2414})});
  V v_t_2423 = heff_tr(heff_call(v_malg_2420, 1, (V[]){v_t_2422}));
  V f_ = v_bind_2421;
  args[0] = v_t_2423;
  args[1] = v_k2_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_s_2414 = heff_env(self)[0];
  V v_malg_2429 = heff_take_field(v_hd_2427, 2);
  V v_bind_2430 = heff_get_n(v_hd_2427, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2414})});
  V v_t_2432 = heff_tr(heff_call(v_malg_2429, 1, (V[]){v_t_2431}));
  V f_ = v_bind_2430;
  args[0] = v_t_2432;
  args[1] = v_k2_2428;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam4(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k2_2439 = args[1];
  V v_s_2414 = heff_env(self)[0];
  V v_malg_2440 = heff_take_field(v_hd_2438, 2);
  V v_bind_2441 = heff_get_n(v_hd_2438, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2414})});
  V v_t_2443 = heff_tr(heff_call(v_malg_2440, 1, (V[]){v_t_2442}));
  V f_ = v_bind_2441;
  args[0] = v_t_2443;
  args[1] = v_k2_2439;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_s_2414 = heff_env(self)[0];
  V v_malg_2449 = heff_take_field(v_hd_2447, 2);
  V v_bind_2450 = heff_get_n(v_hd_2447, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2414})});
  V v_t_2452 = heff_tr(heff_call(v_malg_2449, 1, (V[]){v_t_2451}));
  V f_ = v_bind_2450;
  args[0] = v_t_2452;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_t_2453;
  switch (heff_tag_of(v_s_2414)) {
  case TAG_UnequalTys: {
    v_t_2453 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam2, 2, 1, (V[]){v_s_2414});
    break;
  }
  case TAG_UnequalEls: {
    v_t_2453 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam3, 2, 1, (V[]){v_s_2414});
    break;
  }
  case TAG_UnequalNeus: {
    v_t_2453 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam4, 2, 1, (V[]){v_s_2414});
    break;
  }
  case TAG_MentionsError: {
    v_t_2453 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam5_clo);
    break;
  }
  case TAG_Escapes: {
    v_t_2453 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam6, 2, 1, (V[]){v_s_2414});
    break;
  }
  default: heff_nomatch(v_s_2414);
  }
  heff_clo_take(self, 1);
  V f_ = v_t_2453;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_get_n(v_z_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam9(V self, V *args) {
  V v_c_2466 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2467 = ({ V b_0 = heff_get_n(v_c_2466, 2, 9); V a_1 = v_m_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_m_242); r_; });
  {
    V v_field_2469 = v_t_2467.f[1];
    int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2468 == ((int64_t)0ULL)) && ({ V v_x_2470 = heff_dup(v_field_2469); int c_ = 1; heff_drop(v_x_2470); c_; })));
    heff_drop(v_field_2469);
    return v_ret_24bool;
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam11(V self, V *args) {
  V v_c_2474 = args[0];
  return heff_get_n(v_c_2474, 3, 9);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam13(V self, V *args) {
  V v_x_2483 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2459 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_drop(v_x_2483);
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_m_242, v_t_2459, v_z_245, v_z_246));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam12(V self, V *args) {
  V v_x_2477 = args[0];
  V v_v_2464 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2459 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  HeffT3 v_t_2478 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2477));
  {
    V v_field_2479 = v_t_2478.f[0];
    heff_drop(v_t_2478.f[1]);
    heff_drop(v_t_2478.f[2]);
    heff_clo_take(self, 5);
    V v_t_2482 = heff_tr(heff_call(v_field_2479, 3, (V[]){MK_INT(20LL), MK_INT(0LL), v_v_2464}));
    return ({ V a_0 = v_t_2482; V a_1 = heff_dup(v_z_245); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam13, 1, 4, (V[]){v_m_242, v_t_2459, v_z_245, v_z_246}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2482); r_; });
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam10(V self, V *args) {
  V v_x_2473 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_v_2464 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2459 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  if ((heff_dup(v_x_2473) == NTAG(TAG_True))) {
    heff_drop(v_x_2473);
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam11_clo)})});
    V v_t_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2475}));
    heff_clo_take(self, 5);
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2476;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam12, 1, 5, (V[]){v_v_2464, v_z_245, v_m_242, v_t_2459, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2473);
    heff_clo_take(self, 5);
    heff_drop(v_v_2464);
    return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_m_242, v_t_2459, v_z_245, v_z_246));
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_v_2464 = heff_env(self)[2];
  V v_t_2459 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_drop(v_x_2465);
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam9, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2471}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2472;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam10, 1, 5, (V[]){v_z_245, v_v_2464, v_m_242, v_t_2459, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2456)) {
  case TAG_Nothing: {
    heff_clo_take(self, 5);
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop_rec(v_z_245, 3);
    V f_ = v_z_246;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2457 = heff_field(v_x_2456, 0);
    V v_ru_24x_2456_24Just = heff_take_reuse_n(v_x_2456, 1ULL, 1);
    heff_clo_take(self, 5);
    V v_t_2458 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2459 = (g_heff_2eelab_2eunify_2elamsU(v_t_2458, v_body_2457));
    V v_x1_2460 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = heff_dup(v_t_2459); V a_3 = NTAG(TAG_LNil); V r_ = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); r_; });
    V v_v_2464;
    switch (heff_tag_of(v_x1_2460)) {
    case TAG_Nom: {
      V v_x_2461 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      v_v_2464 = v_x_2461;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2460, 0ULL, 1);
      v_v_2464 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2463 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      v_v_2464 = v_x_2463;
      break;
    }
    default: heff_nomatch(v_x1_2460);
    }
    return ({ V a_0 = v_ru_24x_2456_24Just; V a_1 = v_m_242; V a_2 = heff_dup(v_v_2464); V a_3 = heff_dup(v_t_2459); V a_4 = heff_dup(v_z_245); V a_5 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133_lam8, 1, 5, (V[]){heff_dup(v_m_242), v_z_245, v_v_2464, v_t_2459, v_z_246}); V r_ = (g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_m_242); r_; });
  }
  default: return heff_nomatch(v_x_2456);
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam1, 1, 8, (V[]){v_hd_246, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_k_247, v_self_245})});
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 9);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get_n(v_c_2412, 7, 9);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_drop(v_x_2446);
  heff_clo_take(self, 1);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_args_2422 = heff_env(self)[0];
  V v_args_27_2437 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2422));
  heff_clo_take(self, 6);
  V v_t_2443 = (g_heff_2eelab_2eunify_2ezipL(v_args_2422, v_args_27_2437));
  V v_t_2444 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214(MK_INT(0LL), v_t_2443));
  V v_t_2445 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2444));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(v_g_240, heff_dup(v_m_242), v_m_242, v_x_2441, v_t_2442, v_t_2445, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam5, 1, 1, (V[]){v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6(V self, V *args) {
  V v_c_2448 = args[0];
  return heff_get_n(v_c_2448, 3, 9);
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2452 = ({ V a_0 = v_x_2451; V a_1 = v_m_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_x_2451); heff_drop(v_m_242); r_; });
  {
    V v_field_2454 = v_t_2452.f[1];
    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
    if ((v_tag_2453 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_246, 3);
      V v_e_2455 = v_field_2454;
      V f_ = v_k_2447;
      args[0] = v_e_2455;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2454);
      V v_t_2456 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2457}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2458;
      heff_room[1] = v_k_2447;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_self_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT2 v_t_2416 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_x_2415, v_x_2411, v_sp_243));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_items_2419 = v_field_2418;
      V v_t_2420 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2419)));
      V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2420); r_; });
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        V v_args_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2419));
        switch (heff_tag_of(v_rhs_244)) {
        case TAG_VNeu: {
          V v_v1_2423 = heff_dup(heff_field(v_rhs_244, 0));
          V v_sp_2424 = heff_dup(heff_field(v_rhs_244, 1));
          switch (heff_tag_of(v_v1_2423)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2423, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2424);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2423, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2424);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HMeta: {
            V v_m_2430 = heff_field(v_v1_2423, 0);
            V v_ru_24v1_2423_24HMeta = heff_take_reuse_n(v_v1_2423, 1ULL, 1);
            if (heff_intEq_c_lent(v_m_2430, v_m_242, 1)) {
              HeffT2 v_t_2431 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_2424; HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2415); heff_drop(v_x_2411); r_; });
              {
                V v_field_2433 = v_t_2431.f[1];
                int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
                if ((v_tag_2432 == ((int64_t)0ULL))) {
                  V v_items_2434 = v_field_2433;
                  V v_t_2435 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2434)));
                  V v_t_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2435); r_; });
                  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
                    heff_drop(v_t_2436);
                    V v_args_27_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2434));
                    V v_t_2438 = (g_heff_2eelab_2eunify_2eeqPatArgs(v_args_27_2437, v_args_2422));
                    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
                      heff_drop_tag(v_rhs_244, 5);
                      heff_drop(v_g_240);
                      heff_drop(v_cs_241);
                      heff_drop(v_m_242);
                      heff_drop_rec(v_hd_246, 3);
                      heff_drop(v_self_245);
                      heff_drop(v_args_2422);
                      heff_drop_cell(v_ru_24v1_2423_24HMeta, 1);
                      heff_drop(v_args_27_2437);
                      heff_drop(v_t_2438);
                      V f_ = v_k_247;
                      args[0] = NTAG(TAG_MkUnit);
                      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                      return heff_tail(f_, 1, args);
                    } else {
                      heff_drop(v_t_2438);
                      V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_27_2437));
                      V v_t_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2422));
                      if (heff_intEq_c(v_t_2439, v_t_2440)) {
                        heff_drop_tag(v_rhs_244, 5);
                        heff_drop(v_cs_241);
                        heff_drop(v_self_245);
                        V v_k_2447 = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam4, 1, 6, (V[]){v_args_2422, v_args_27_2437, v_g_240, heff_dup(v_m_242), heff_dup(v_hd_246), v_k_247});
                        V v_t_2449 = heff_tag_at_n(v_ru_24v1_2423_24HMeta, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam6_clo)})});
                        V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2449}));
                        V f_ = heff_dup(heff_rfield(v_hd_246, 1));
                        heff_room[0] = v_t_2450;
                        heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam7, 1, 3, (V[]){v_m_242, v_k_2447, v_hd_246});
                        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                      } else {
                        heff_drop(v_g_240);
                        heff_drop(v_m_242);
                        heff_drop(v_args_2422);
                        heff_drop(v_args_27_2437);
                        return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(v_ru_24v1_2423_24HMeta, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                      }
                    }
                  } else {
                    heff_drop(v_g_240);
                    heff_drop(v_m_242);
                    heff_drop(v_args_2422);
                    heff_drop(v_items_2434);
                    heff_drop(v_t_2436);
                    return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(v_ru_24v1_2423_24HMeta, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                  }
                } else {
                  heff_drop(v_g_240);
                  heff_drop(v_m_242);
                  heff_drop(v_args_2422);
                  heff_drop(v_field_2433);
                  return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253_24tok1(v_ru_24v1_2423_24HMeta, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                }
              }
            } else {
              heff_drop(v_x_2415);
              heff_drop(v_x_2411);
              heff_drop(v_self_245);
              heff_drop(v_sp_2424);
              heff_drop_cell(v_ru_24v1_2423_24HMeta, 1);
              return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
            }
          }
          case TAG_HError: {
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2424);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
          }
          default: return heff_nomatch(v_v1_2423);
          }
        }
        case TAG_VCode: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VLam: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VCons: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VOpaque: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1923555125x965136133(v_g_240, v_cs_241, v_m_242, v_args_2422, v_rhs_244, v_hd_246, v_k_247));
        }
        default: return heff_nomatch(v_rhs_244);
        }
      } else {
        heff_drop(v_x_2415);
        heff_drop(v_x_2411);
        heff_drop(v_g_240);
        heff_drop(v_m_242);
        heff_drop(v_items_2419);
        heff_drop(v_t_2421);
        return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
      }
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_g_240);
      heff_drop(v_m_242);
      heff_drop(v_field_2418);
      return (g_heff_2eelab_2eunify_2epostponeU_24s1708305327x2039053253(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_self_245 = heff_env(self)[7];
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
  heff_clo_take(self, 8);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_hd_246, v_k_247, v_self_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}