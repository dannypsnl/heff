// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Attempt 14217
#define TAG_Await 41810
#define TAG_Collected 38917
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_IsTerminal 53507
#define TAG_Log 24016
#define TAG_MkKid 64674
#define TAG_MkTask 37714
#define TAG_NoInput 41055
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Start 63542
#define TAG_UriPath 39251
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_going 299892244
#define LBL_group 299987609
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_output 941629484
#define LBL_parent 951717845
#define LBL_ret 322331
#define LBL_task 10048076
#define LBL_timeout 1065429926
#define LBL_total 311908190
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_next__going[] = {LBL_next, LBL_going};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_co_2eop_24s1673054648x994021533(V, V, V);
V g_co_2eop_24s1673054648x994021533_entry(V self, V *a);
extern Clo g_co_2eop_24s1673054648x994021533_clo;
V g_co_2eop_24s2022167152x294629972(V, V, V);
V g_co_2eop_24s2022167152x294629972_entry(V self, V *a);
extern Clo g_co_2eop_24s2022167152x294629972_clo;
V g_co_2eop_24s582347324x1305505939(V, V, V, V);
V g_co_2eop_24s582347324x1305505939_entry(V self, V *a);
extern Clo g_co_2eop_24s582347324x1305505939_clo;
V g_list_2ekeepIf_24s2085003797x1793382462(V, V);
V g_list_2ekeepIf_24s2085003797x1793382462_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2085003797x1793382462_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1832335087x1608171547(V, V, V, V);
V g_list_2emap_24f1832335087x1608171547_entry(V self, V *a);
extern Clo g_list_2emap_24f1832335087x1608171547_clo;
V g_list_2emap_24s2021078391x832341393(V, V, V);
V g_list_2emap_24s2021078391x832341393_entry(V self, V *a);
extern Clo g_list_2emap_24s2021078391x832341393_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eprogress_2ecountOf(V, V);
V g_std_2eprogress_2ecountOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2ecountOf_clo;
V g_std_2eprogress_2edrawTop(V, V);
V g_std_2eprogress_2edrawTop_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawTop_clo;
V g_std_2eprogress_2edrawUnder(V, V, V);
V g_std_2eprogress_2edrawUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawUnder_clo;
V g_std_2eprogress_2edrawing_24s2036895247x359356247_get(void);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614(V, V);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawnOp_24s53832845x1992189614_clo;
V g_std_2eprogress_2ekidsUnder(V, V, V);
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_clo;
V g_std_2eprogress_2ekidsUnder_24dps(V, V, V, V);
V g_std_2eprogress_2ekidsUnder_24dps_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_24dps_clo;
V g_std_2eprogress_2eparentOf(V, V);
V g_std_2eprogress_2eparentOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2eparentOf_clo;
V g_std_2eprogress_2eprogress_get(void);
V g_std_2eprogress_2eroot_get(void);
V g_std_2eprogress_2eshown_24s583895038x1291295401(V, V, V, V);
V g_std_2eprogress_2eshown_24s583895038x1291295401_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s583895038x1291295401_clo;
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_get(void);
HEFF_TAG_LIT(g_std_2eprogress_2eroot_lit0, TAG_MkTask, 1, MK_INT(0LL));

static V g_std_2eprogress_2eroot_val;
static HEFF_ONCE g_std_2eprogress_2eroot_st;
static V g_std_2eprogress_2eroot_init(void) {
  return ((V)&g_std_2eprogress_2eroot_lit0);
}
V g_std_2eprogress_2eroot_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eroot_st)) return g_std_2eprogress_2eroot_val;
  return heff_global(&g_std_2eprogress_2eroot_val, &g_std_2eprogress_2eroot_st, g_std_2eprogress_2eroot_init);
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args);
V g_std_2eprogress_2eprogress_lam2(V self, V *args);
V g_std_2eprogress_2eprogress_lam0(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam0, 3, 0};
V g_std_2eprogress_2eprogress_lam3(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam3, 4, 0};

static V g_std_2eprogress_2eprogress_val;
static HEFF_ONCE g_std_2eprogress_2eprogress_st;
static V g_std_2eprogress_2eprogress_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eprogress_2eprogress_lam0_clo), ((V)&g_std_2eprogress_2eprogress_lam3_clo)});
}
V g_std_2eprogress_2eprogress_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eprogress_st)) return g_std_2eprogress_2eprogress_val;
  return heff_global(&g_std_2eprogress_2eprogress_val, &g_std_2eprogress_2eprogress_st, g_std_2eprogress_2eprogress_init);
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args) {
  V v_t_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_t_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam2(V self, V *args) {
  V v_r_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tr(heff_call(v_k_2418, 1, (V[]){v_r_2419}));
  V f_ = v_g_241;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Start: {
    V v_parent_243 = heff_field(v_p_242, 0);
    V v_name_244 = heff_field(v_p_242, 1);
    V v_total_245 = heff_field(v_p_242, 2);
    V v_k_246 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Start = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_re_n(v_ru_24p_242_24Start, TAG_Start, 4, 7ULL, (V[]){v_parent_243, v_name_244, v_total_245, heff_clo_n(g_std_2eprogress_2eprogress_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
  }
  case TAG_Complete: {
    V v_t_249 = heff_field(v_p_242, 0);
    V v_x_2410 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Complete = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
    return heff_tag_re_n(v_ru_24p_242_24Complete, TAG_Complete, 2, 1ULL, (V[]){v_t_249, v_t_2411});
  }
  case TAG_End: {
    V v_t_2412 = heff_field(v_p_242, 0);
    V v_x_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24End = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2414 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2413}));
    return heff_tag_re_n(v_ru_24p_242_24End, TAG_End, 2, 1ULL, (V[]){v_t_2412, v_t_2414});
  }
  case TAG_RunUnder: {
    V v_t_2415 = heff_field(v_p_242, 0);
    V v_cmd_2416 = heff_field(v_p_242, 1);
    V v_argv_2417 = heff_field(v_p_242, 2);
    V v_k_2418 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24RunUnder = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_re_n(v_ru_24p_242_24RunUnder, TAG_RunUnder, 4, 7ULL, (V[]){v_t_2415, v_cmd_2416, v_argv_2417, heff_clo_n(g_std_2eprogress_2eprogress_lam2, 1, 2, (V[]){v_k_2418, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eprogress_2eprogress_lam3(V self, V *args) {
  V v_m_2421 = args[0];
  V v_n_2422 = args[1];
  V v_nt_2423 = args[2];
  V v_p_2424 = args[3];
  heff_drop(v_m_2421);
  heff_drop(v_n_2422);
  heff_drop(v_nt_2423);
  return v_p_2424;
}
HEFF_LIT(g_std_2eprogress_2ecountOf_str0, 0, "");
HEFF_LIT(g_std_2eprogress_2ecountOf_str1, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str2, 1, "/");
HEFF_LIT(g_std_2eprogress_2ecountOf_str3, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str4, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str5, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str6, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str7, 1, "/");
HEFF_LIT(g_std_2eprogress_2ecountOf_str8, 2, "] ");
Clo g_std_2eprogress_2ecountOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ecountOf_entry, 2, 0};

V g_std_2eprogress_2ecountOf(V v_done_240, V v_total_241) {
top: ;
  if (heff_intEq_c_lent(v_done_240, MK_INT(0LL), 2)) {
    if (heff_intEq_c_lent(v_total_241, MK_INT(0LL), 2)) {
      heff_drop(v_done_240);
      heff_drop(v_total_241);
      return ((V)&g_std_2eprogress_2ecountOf_str0);
    } else {
      V v_t_242 = heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str1), heff_intShow(v_done_240));
      V v_t_243 = heff_strAppend(heff_strAppend(v_t_242, ((V)&g_std_2eprogress_2ecountOf_str2)), heff_intShow(v_total_241));
      return heff_strAppend(v_t_243, ((V)&g_std_2eprogress_2ecountOf_str3));
    }
  } else {
    if (heff_intEq_c_lent(v_total_241, MK_INT(0LL), 2)) {
      heff_drop(v_total_241);
      V v_t_244 = heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str4), heff_intShow(v_done_240));
      return heff_strAppend(v_t_244, ((V)&g_std_2eprogress_2ecountOf_str5));
    } else {
      V v_t_245 = heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str6), heff_intShow(v_done_240));
      V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_std_2eprogress_2ecountOf_str7)), heff_intShow(v_total_241));
      return heff_strAppend(v_t_246, ((V)&g_std_2eprogress_2ecountOf_str8));
    }
  }
}
V g_std_2eprogress_2ecountOf_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ecountOf(a[0], a[1]);
}
HEFF_LIT(g_std_2eprogress_2edrawUnder_str0, 7, "\342\224\224\342\224\200 ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str1, 7, "\342\224\234\342\224\200 ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str2, 3, "   ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str3, 5, "\342\224\202  ");
Clo g_std_2eprogress_2edrawUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawUnder_entry, 3, 0};

V g_std_2eprogress_2edrawUnder(V v_every_240, V v_prefix_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_prefix_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_done_245 = heff_take_field(v_t_243, 3);
    V v_total_246 = heff_take_field(v_t_243, 4);
    V v_task_247 = heff_take_field(v_t_243, 0);
    V v_name_248 = heff_get_n(v_t_243, 2, 5);
    V v_t_2411;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_std_2eprogress_2edrawUnder_str0);
      break;
    }
    case TAG_Cons: {
      v_t_2411 = ((V)&g_std_2eprogress_2edrawUnder_str1);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_2412 = (g_std_2eprogress_2ecountOf(v_done_245, v_total_246));
    V v_t_2415;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_std_2eprogress_2edrawUnder_str2);
      break;
    }
    case TAG_Cons: {
      v_t_2415 = ((V)&g_std_2eprogress_2edrawUnder_str3);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_2416 = ({ V a_0 = v_task_247; V a_1 = heff_dup(v_every_240); V r_ = (g_list_2ekeepIf_24s2085003797x1793382462(a_0, a_1)); heff_drop(v_task_247); r_; });
    V v_t_2417 = (g_std_2eprogress_2edrawUnder(v_every_240, heff_strAppend(heff_dup(v_prefix_241), v_t_2415), v_t_2416));
    V v_t_2418 = (g_std_2eprogress_2edrawUnder(v_every_240, heff_dup(v_prefix_241), v_rest_244));
    V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2418));
    V v_t_2420 = heff_strAppend(heff_strAppend(v_prefix_241, v_t_2411), heff_strAppend(v_t_2412, v_name_248));
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2420, v_t_2419});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2edrawUnder_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eprogress_2edrawUnder(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2eprogress_2edrawTop_str0, 0, "");
Clo g_std_2eprogress_2edrawTop_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawTop_entry, 2, 0};

V g_std_2eprogress_2edrawTop(V v_every_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_done_244 = heff_take_field(v_t_242, 3);
    V v_total_245 = heff_take_field(v_t_242, 4);
    V v_task_246 = heff_take_field(v_t_242, 0);
    V v_name_247 = heff_get_n(v_t_242, 2, 5);
    V v_t_248 = (g_std_2eprogress_2ecountOf(v_done_244, v_total_245));
    V v_t_249 = ({ V a_0 = v_task_246; V a_1 = heff_dup(v_every_240); V r_ = (g_list_2ekeepIf_24s2085003797x1793382462(a_0, a_1)); heff_drop(v_task_246); r_; });
    V v_t_2410 = (g_std_2eprogress_2edrawUnder(v_every_240, ((V)&g_std_2eprogress_2edrawTop_str0), v_t_249));
    V v_t_2411 = (g_std_2eprogress_2edrawTop(v_every_240, v_rest_243));
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, v_name_247), v_t_2412});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawTop_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eprogress_2edrawTop(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eprogress_2ekidsUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_entry, 3, 0};

V g_std_2eprogress_2ekidsUnder(V v_t_240, V v_box_24i_241, V v_x3_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkKid: {
      V v_name_245 = heff_field(v_x31_243, 0);
      V v_done_246 = heff_field(v_x31_243, 1);
      V v_total_247 = heff_field(v_x31_243, 2);
      V v_parent_248 = heff_field(v_x31_243, 3);
      heff_take_n(v_x31_243, 15ULL, 4);
      V v_t_249;
      if ((v_i_241 == ((int64_t)0ULL))) {
        v_t_249 = heff_dup(v_t_240);
      } else {
        if ((v_i_241 == ((int64_t)255ULL))) {
          v_t_249 = heff_dup(v_t_240);
        } else {
          v_t_249 = heff_box_word((((int64_t)-1ULL) - v_i_241));
        }
      }
      V v_t_2410;
      if (heff_intEq_c_lent(v_parent_248, MK_INT(0LL), 2)) {
        heff_drop(v_parent_248);
        v_t_2410 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_parent_248, MK_INT(255LL), 2)) {
          heff_drop(v_parent_248);
          v_t_2410 = heff_dup(v_t_240);
        } else {
          v_t_2410 = heff_intSub(MK_INT(-1LL), v_parent_248);
        }
      }
      V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_task__parent__name__done__total, (V[]){v_t_249, v_t_2410, v_name_245, v_done_246, v_total_247}), heff_hole()});
      V v_u_2412 = ({ V a_0 = v_t_240; V a_1 = heff_box_word((v_i_241 + ((int64_t)1ULL))); V a_2 = v_rest_244; V a_3 = v_cell_2411; V r_ = (g_std_2eprogress_2ekidsUnder_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_t_240); r_; });
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ekidsUnder(a[0], a[1], a[2]);
}
Clo g_std_2eprogress_2ekidsUnder_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_24dps_entry, 4, 0};

V g_std_2eprogress_2ekidsUnder_24dps(V v_t_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkKid: {
      V v_name_246 = heff_field(v_x31_244, 0);
      V v_done_247 = heff_field(v_x31_244, 1);
      V v_total_248 = heff_field(v_x31_244, 2);
      V v_parent_249 = heff_field(v_x31_244, 3);
      heff_take_n(v_x31_244, 15ULL, 4);
      V v_t_2410;
      if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
        v_t_2410 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_i_241, MK_INT(255LL), 2)) {
          v_t_2410 = heff_dup(v_t_240);
        } else {
          v_t_2410 = heff_intSub_lent(MK_INT(-1LL), v_i_241, 1);
        }
      }
      V v_t_2411;
      if (heff_intEq_c_lent(v_parent_249, MK_INT(0LL), 2)) {
        heff_drop(v_parent_249);
        v_t_2411 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_parent_249, MK_INT(255LL), 2)) {
          heff_drop(v_parent_249);
          v_t_2411 = heff_dup(v_t_240);
        } else {
          v_t_2411 = heff_intSub(MK_INT(-1LL), v_parent_249);
        }
      }
      V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_task__parent__name__done__total, (V[]){v_t_2410, v_t_2411, v_name_246, v_done_247, v_total_248}), heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2412);
      V t_0 = v_t_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_rest_245;
      V t_3 = v_u_2413;
      v_t_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_std_2eprogress_2ekidsUnder_24dps(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_std_2eprogress_2eparentOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eparentOf_entry, 2, 0};

V g_std_2eprogress_2eparentOf(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_task_244 = heff_dup(heff_rfield(v_t_242, 0));
    V v_parent_245 = heff_dup(heff_rfield(v_t_242, 1));
    if (heff_intEq_c_lent(v_task_244, v_i_240, 1)) {
      return v_parent_245;
    } else {
      heff_drop(v_parent_245);
      V t_0 = v_i_240;
      V t_1 = v_rest_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2eparentOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2eprogress_2eparentOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_str0, 0, "");
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam1(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam0(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam3(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam2(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam5(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam4(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam8(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam7(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam9(V self, V *args); static Clo g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam9, 1, 0};
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam11(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam10(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam6(V self, V *args);
Clo g_std_2eprogress_2edrawnOp_24s53832845x1992189614_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s53832845x1992189614_entry, 2, 0};

V g_std_2eprogress_2edrawnOp_24s53832845x1992189614(V v_ts_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Start: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_name_243 = heff_field(v_x2_241, 1);
    V v_total_244 = heff_field(v_x2_241, 2);
    V v_k_245 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkTask: {
      V v_p_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24MkTask = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_247 = heff_rec_n(5, shape_task__parent__name__done__total, (V[]){heff_dup(heff_rfield(v_ts_240, 0)), v_p_246, v_name_243, MK_INT(0LL), v_total_244});
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_t_249 = (g_prelude_2e_2b_2b(heff_take_field(v_ts_240, 1), v_t_248));
      V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_ts_240, 0)), MK_INT(1LL));
      V v_ts_2411 = heff_rec_n(2, shape_next__going, (V[]){v_t_2410, v_t_249});
      V v_t_2412 = heff_tag_at_n(v_ru_24x21_242_24MkTask, TAG_MkTask, 1, (V[]){heff_get_n(v_ts_240, 0, 2)});
      V v_x_2413 = heff_tr(heff_call(v_k_245, 1, (V[]){v_t_2412}));
      V v_ts_2414 = heff_dup(heff_rfield(v_ts_2411, 1));
      V v_t_2415 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2414)));
      V v_ls_2416 = ({ V a_0 = v_ts_2414; V a_1 = v_t_2415; V r_ = (g_std_2eprogress_2edrawTop(a_0, a_1)); heff_drop(v_ts_2414); r_; });
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam0, 2, 3, (V[]){v_ls_2416, v_ts_2411, v_x_2413});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_Complete: {
    V v_x21_2423 = heff_field(v_x2_241, 0);
    V v_x_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2423)) {
    case TAG_MkTask: {
      V v_i_2425 = heff_field(v_x21_2423, 0);
      heff_take_n(v_x21_2423, 1ULL, 1);
      V v_t_2426 = (g_list_2emap_24s2021078391x832341393(v_i_2425, MK_INT(1LL), heff_take_field(v_ts_240, 1)));
      V v_ts_2427 = ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_ts_240, 1ULL, 2, shape_next__going, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_ts_2428 = heff_dup(heff_rfield(v_ts_2427, 1));
      V v_t_2429 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2428)));
      V v_ls_2430 = ({ V a_0 = v_ts_2428; V a_1 = v_t_2429; V r_ = (g_std_2eprogress_2edrawTop(a_0, a_1)); heff_drop(v_ts_2428); r_; });
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam2, 2, 3, (V[]){v_ls_2430, v_ts_2427, v_x_2424});
    }
    default: return heff_nomatch(v_x21_2423);
    }
  }
  case TAG_End: {
    V v_x21_2437 = heff_field(v_x2_241, 0);
    V v_x_2438 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2437)) {
    case TAG_MkTask: {
      V v_i_2439 = heff_field(v_x21_2437, 0);
      heff_take_n(v_x21_2437, 1ULL, 1);
      V v_i_2440 = (g_std_2eprogress_2eparentOf(v_i_2439, heff_rfield(v_ts_240, 1)));
      V v_t_2441 = ({ V a_0 = v_i_2440; V a_1 = MK_INT(1LL); V a_2 = v_i_2439; V a_3 = heff_take_field(v_ts_240, 1); V r_ = (g_list_2emap_24f1832335087x1608171547(a_0, a_1, a_2, a_3)); heff_drop(v_i_2440); heff_drop(v_i_2439); r_; });
      V v_ts_2442 = ({ V rv_1 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_ts_240, 1ULL, 2, shape_next__going, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_ts_2443 = heff_dup(heff_rfield(v_ts_2442, 1));
      V v_t_2444 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2443)));
      V v_ls_2445 = ({ V a_0 = v_ts_2443; V a_1 = v_t_2444; V r_ = (g_std_2eprogress_2edrawTop(a_0, a_1)); heff_drop(v_ts_2443); r_; });
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam4, 2, 3, (V[]){v_ls_2445, v_ts_2442, v_x_2438});
    }
    default: return heff_nomatch(v_x21_2437);
    }
  }
  case TAG_RunUnder: {
    V v_x21_2452 = heff_field(v_x2_241, 0);
    V v_cmd_2453 = heff_field(v_x2_241, 1);
    V v_argv_2454 = heff_field(v_x2_241, 2);
    V v_k_2455 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_2452)) {
    case TAG_MkTask: {
      V v_i_2456 = heff_field(v_x21_2452, 0);
      heff_take_n(v_x21_2452, 1ULL, 1);
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam6, 2, 5, (V[]){v_cmd_2453, v_argv_2454, v_ts_240, v_i_2456, v_k_2455});
    }
    default: return heff_nomatch(v_x21_2452);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawnOp_24s53832845x1992189614(a[0], a[1]);
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_ts_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_drop(v_x_2422);
  heff_clo_take(self, 3);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2411, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_ls_2416 = heff_env(self)[0];
  V v_ts_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2416, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s2022167152x294629972(v_t_2421, v_hd_2417, heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam1, 1, 3, (V[]){v_k_2418, v_ts_2411, v_x_2413})));
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2432 = heff_env(self)[0];
  V v_ts_2427 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  heff_drop(v_x_2436);
  heff_clo_take(self, 3);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2427, v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam2(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_ls_2430 = heff_env(self)[0];
  V v_ts_2427 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2430, NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s2022167152x294629972(v_t_2435, v_hd_2431, heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam3, 1, 3, (V[]){v_k_2432, v_ts_2427, v_x_2424})));
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam5(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_2447 = heff_env(self)[0];
  V v_ts_2442 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  heff_drop(v_x_2451);
  heff_clo_take(self, 3);
  V f_ = v_k_2447;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2442, v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam4(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_ls_2445 = heff_env(self)[0];
  V v_ts_2442 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2448 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2445, NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s2022167152x294629972(v_t_2450, v_hd_2446, heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam5, 1, 3, (V[]){v_k_2447, v_ts_2442, v_x_2438})));
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam8(V self, V *args) {
  V v_s_2463 = args[0];
  V v_i_2456 = heff_env(self)[0];
  V v_r_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = v_i_2456;
  V v_x2_2465 = v_r_2461;
  V v_s_2466 = v_s_2463;
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkKid: {
    V v_name_2467 = heff_field(v_x2_2465, 0);
    V v_done_2468 = heff_field(v_x2_2465, 1);
    V v_total_2469 = heff_field(v_x2_2465, 2);
    heff_take_n(v_x2_2465, 7ULL, 4);
    if (heff_intEq_c(heff_dup(heff_rfield(v_s_2466, 0)), v_t_2464)) {
      V v_t_2471;
      if (heff_strEq_c_lent(v_name_2467, ((V)&g_std_2eprogress_2edrawnOp_24s53832845x1992189614_str0), 2)) {
        heff_drop(v_name_2467);
        v_t_2471 = heff_dup(heff_rfield(v_s_2466, 2));
      } else {
        v_t_2471 = v_name_2467;
      }
      V v_t_2473;
      if ((heff_intEq_c_lent(v_total_2469, MK_INT(0LL), 2) && heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_2466, 4))))) {
        V v_y_2472 = heff_dup(heff_rfield(v_s_2466, 4));
        if (heff_intLe_c_lent(v_done_2468, v_y_2472, 0)) {
          heff_drop(v_y_2472);
          v_t_2473 = v_done_2468;
        } else {
          heff_drop(v_done_2468);
          v_t_2473 = v_y_2472;
        }
      } else {
        v_t_2473 = v_done_2468;
      }
      V v_t_2474;
      if (heff_intEq_c_lent(v_total_2469, MK_INT(0LL), 2)) {
        heff_drop(v_total_2469);
        v_t_2474 = heff_dup(heff_rfield(v_s_2466, 4));
      } else {
        v_t_2474 = v_total_2469;
      }
      return ({ V rv_2 = v_t_2471; V rv_3 = v_t_2473; V rv_4 = v_t_2474; V rr_ = heff_rec_reuse_nf(v_s_2466, 3ULL, 5, shape_task__parent__name__done__total, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      heff_drop(v_name_2467);
      heff_drop(v_done_2468);
      heff_drop(v_total_2469);
      return v_s_2466;
    }
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam7(V self, V *args) {
  V v_kids_2459 = args[0];
  V v_ts_240 = heff_env(self)[0];
  V v_i_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ts_2460 = heff_get_n(v_ts_240, 1, 2);
  V v_ts_2477;
  switch (heff_tag_of(v_kids_2459)) {
  case TAG_Nil: {
    heff_drop(v_i_2456);
    v_ts_2477 = v_ts_2460;
    break;
  }
  case TAG_Cons: {
    V v_r_2461 = heff_field(v_kids_2459, 0);
    V v_kids_2462 = heff_field(v_kids_2459, 1);
    V v_ru_24kids_2459_24Cons = heff_take_reuse_n(v_kids_2459, 3ULL, 2);
    V v_t_2475 = (g_list_2emap_24tok2(v_ru_24kids_2459_24Cons, heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam8, 1, 2, (V[]){heff_dup(v_i_2456), v_r_2461}), v_ts_2460));
    V v_t_2476 = (g_std_2eprogress_2ekidsUnder(v_i_2456, MK_INT(1LL), v_kids_2462));
    v_ts_2477 = (g_prelude_2e_2b_2b(v_t_2475, v_t_2476));
    break;
  }
  default: heff_nomatch(v_kids_2459);
  }
  V v_t_2478 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2477)));
  return ({ V a_0 = v_ts_2477; V a_1 = v_t_2478; V r_ = (g_std_2eprogress_2edrawTop(a_0, a_1)); heff_drop(v_ts_2477); r_; });
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam9(V self, V *args) {
  V v_r_2479 = args[0];
  return v_r_2479;
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam11(V self, V *args) {
  V v_x_2490 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_x_2483 = heff_env(self)[2];
  heff_drop(v_x_2490);
  heff_clo_take(self, 3);
  V f_ = v_k_2458;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_240, v_x_2483});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam10(V self, V *args) {
  V v_x_2482 = args[0];
  V v_k_2455 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_hd_2457 = heff_env(self)[2];
  V v_k_2458 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2483 = heff_tr(heff_call(v_k_2455, 1, (V[]){v_x_2482}));
  V v_ts_2484 = heff_dup(heff_rfield(v_ts_240, 1));
  V v_t_2485 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2484)));
  V v_ls_2486 = ({ V a_0 = v_ts_2484; V a_1 = v_t_2485; V r_ = (g_std_2eprogress_2edrawTop(a_0, a_1)); heff_drop(v_ts_2484); r_; });
  V v_t_2487 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2486, NTAG(TAG_MkUnit)});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  return (g_co_2eop_24s2022167152x294629972(v_t_2489, v_hd_2457, heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam11, 1, 3, (V[]){v_k_2458, v_ts_240, v_x_2483})));
}
V g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam6(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_cmd_2453 = heff_env(self)[0];
  V v_argv_2454 = heff_env(self)[1];
  V v_ts_240 = heff_env(self)[2];
  V v_i_2456 = heff_env(self)[3];
  V v_k_2455 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ShowRun, 4, (V[]){v_cmd_2453, v_argv_2454, heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam7, 1, 2, (V[]){heff_dup(v_ts_240), v_i_2456}), ((V)&g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam9_clo)})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  return (g_co_2eop_24s2022167152x294629972(heff_tag_n(TAG_InL, 1, (V[]){v_t_2481}), heff_dup(v_hd_2457), heff_clo_n(g_std_2eprogress_2edrawnOp_24s53832845x1992189614_lam10, 1, 4, (V[]){v_k_2455, v_ts_240, v_hd_2457, v_k_2458})));
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam0(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s2036895247x359356247_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s2036895247x359356247_lam0, 4, 0};
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam3(V self, V *args);
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam2(V self, V *args);
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam1(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s2036895247x359356247_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s2036895247x359356247_lam1, 3, 0};
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam8(V self, V *args);
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam7(V self, V *args);
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam6(V self, V *args);
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam5(V self, V *args);
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam9(V self, V *args);
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam4(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s2036895247x359356247_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s2036895247x359356247_lam4, 2, 0};

static V g_std_2eprogress_2edrawing_24s2036895247x359356247_val;
static HEFF_ONCE g_std_2eprogress_2edrawing_24s2036895247x359356247_st;
static V g_std_2eprogress_2edrawing_24s2036895247x359356247_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2edrawing_24s2036895247x359356247_lam0_clo), ((V)&g_std_2eprogress_2edrawing_24s2036895247x359356247_lam1_clo), ((V)&g_std_2eprogress_2edrawing_24s2036895247x359356247_lam4_clo)});
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2edrawing_24s2036895247x359356247_st)) return g_std_2eprogress_2edrawing_24s2036895247x359356247_val;
  return heff_global(&g_std_2eprogress_2edrawing_24s2036895247x359356247_val, &g_std_2eprogress_2edrawing_24s2036895247x359356247_st, g_std_2eprogress_2edrawing_24s2036895247x359356247_init);
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_ts_241 = args[1];
  V v_hd_242 = args[2];
  V v_k_243 = args[3];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_241, v_x_240});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_y_2412 = heff_dup(heff_field(v_x_2410, 1));
    v_t_2413 = v_y_2412;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  heff_room[0] = v_t_2413;
  heff_room[1] = v_t_2416;
  heff_room[2] = v_hd_248;
  heff_room[3] = v_k_249;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s2036895247x359356247_lam3, 1, 3, (V[]){v_k_245, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam1(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_ts_246 = args[2];
  V v_c_247 = heff_tr(heff_call(v_m_244, 1, (V[]){v_ts_246}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s2036895247x359356247_lam2, 2, 2, (V[]){v_c_247, v_k_245});
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2448 = heff_env(self)[0];
  V v_t_2452;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_MkPair: {
    V v_y_2451 = heff_field(v_x_2449, 1);
    heff_take_n(v_x_2449, 2ULL, 2);
    v_t_2452 = v_y_2451;
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  heff_clo_take(self, 1);
  V f_ = v_k_2448;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam7(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2446;
  args[0] = v_hd_2447;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s2036895247x359356247_lam8, 1, 1, (V[]){v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam6(V self, V *args) {
  V v_c_2444 = args[0];
  V v_k_2445 = args[1];
  V v_ts_2418 = heff_env(self)[0];
  V v_use_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2446 = heff_tr(heff_call(v_c_2444, 1, (V[]){v_ts_2418}));
  V f_ = v_use_2443;
  args[0] = heff_clo_n(g_std_2eprogress_2edrawing_24s2036895247x359356247_lam7, 2, 1, (V[]){v_c_2446});
  args[1] = v_k_2445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam5(V self, V *args) {
  V v_use_2443 = args[0];
  V v_b_2442 = heff_env(self)[0];
  V v_ts_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2442;
  args[0] = heff_clo_n(g_std_2eprogress_2edrawing_24s2036895247x359356247_lam6, 2, 2, (V[]){v_ts_2418, v_use_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam9(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_2465 = args[1];
  V v_k_2466 = args[2];
  V v_ts_2418 = heff_env(self)[0];
  heff_drop(v_hd_2465);
  heff_clo_take(self, 1);
  V f_ = v_k_2466;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2418, v_x_2464});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s2036895247x359356247_lam4(V self, V *args) {
  V v_p_2417 = args[0];
  V v_ts_2418 = args[1];
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_o_2419 = heff_field(v_p_2417, 0);
    heff_take_n(v_p_2417, 1ULL, 1);
    return (g_std_2eprogress_2edrawnOp_24s53832845x1992189614(v_ts_2418, v_o_2419));
  }
  case TAG_InR: {
    V v_q_2420 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2463;
    switch (heff_tag_of(v_q_2420)) {
    case TAG_InL: {
      V v_x_2421 = heff_field(v_q_2420, 0);
      V v_ru_24q_2420_24InL = heff_take_reuse_n(v_q_2420, 1ULL, 1);
      V v_t_2461;
      switch (heff_tag_of(v_x_2421)) {
      case TAG_InL: {
        V v_x_2422 = heff_field(v_x_2421, 0);
        V v_ru_24x_2421_24InL = heff_take_reuse_n(v_x_2421, 1ULL, 1);
        V v_t_2459;
        switch (heff_tag_of(v_x_2422)) {
        case TAG_InL: {
          V v_x_2423 = heff_field(v_x_2422, 0);
          V v_ru_24x_2422_24InL = heff_take_reuse_n(v_x_2422, 1ULL, 1);
          V v_t_2457;
          switch (heff_tag_of(v_x_2423)) {
          case TAG_InL: {
            V v_x_2424 = heff_field(v_x_2423, 0);
            V v_ru_24x_2423_24InL = heff_take_reuse_n(v_x_2423, 1ULL, 1);
            V v_t_2455;
            switch (heff_tag_of(v_x_2424)) {
            case TAG_InL: {
              V v_x_2425 = heff_field(v_x_2424, 0);
              heff_take_n(v_x_2424, 1ULL, 1);
              heff_drop_cell(v_ru_24p_2417_24InR, 1);
              heff_drop_cell(v_ru_24x_2423_24InL, 1);
              v_t_2455 = heff_tag_at_n(v_ru_24q_2420_24InL, TAG_InL, 1, (V[]){v_x_2425});
              break;
            }
            case TAG_InR: {
              V v_y_2426 = heff_field(v_x_2424, 0);
              heff_take_n(v_x_2424, 1ULL, 1);
              heff_drop_cell(v_ru_24q_2420_24InL, 1);
              V v_t_2454;
              switch (heff_tag_of(v_y_2426)) {
              case TAG_Await: {
                V v_t_2427 = heff_field(v_y_2426, 0);
                V v_k_2428 = heff_field(v_y_2426, 1);
                V v_ru_24y_2426_24Await = heff_take_reuse_n(v_y_2426, 3ULL, 2);
                heff_drop_cell(v_ru_24x_2423_24InL, 1);
                v_t_2454 = heff_tag_re_n(v_ru_24y_2426_24Await, TAG_Await, 2, 3ULL, (V[]){v_t_2427, v_k_2428});
                break;
              }
              case TAG_Send: {
                V v_s_2429 = heff_field(v_y_2426, 0);
                V v_x_2430 = heff_field(v_y_2426, 1);
                V v_ru_24y_2426_24Send = heff_take_reuse_n(v_y_2426, 3ULL, 2);
                heff_drop_cell(v_ru_24x_2423_24InL, 1);
                v_t_2454 = heff_tag_re_n(v_ru_24y_2426_24Send, TAG_Send, 2, 3ULL, (V[]){v_s_2429, v_x_2430});
                break;
              }
              case TAG_Log: {
                V v_s_2431 = heff_field(v_y_2426, 0);
                V v_x_2432 = heff_field(v_y_2426, 1);
                V v_ru_24y_2426_24Log = heff_take_reuse_n(v_y_2426, 3ULL, 2);
                heff_drop_cell(v_ru_24x_2423_24InL, 1);
                v_t_2454 = heff_tag_re_n(v_ru_24y_2426_24Log, TAG_Log, 2, 3ULL, (V[]){v_s_2431, v_x_2432});
                break;
              }
              case TAG_Now: {
                V v_k_2433 = heff_field(v_y_2426, 0);
                heff_take_n(v_y_2426, 1ULL, 1);
                v_t_2454 = heff_tag_at_n(v_ru_24x_2423_24InL, TAG_Now, 1, (V[]){v_k_2433});
                break;
              }
              case TAG_ProjectFiles: {
                V v_r_2434 = heff_field(v_y_2426, 0);
                V v_k_2435 = heff_field(v_y_2426, 1);
                V v_ru_24y_2426_24ProjectFiles = heff_take_reuse_n(v_y_2426, 3ULL, 2);
                heff_drop_cell(v_ru_24x_2423_24InL, 1);
                v_t_2454 = heff_tag_re_n(v_ru_24y_2426_24ProjectFiles, TAG_ProjectFiles, 2, 3ULL, (V[]){v_r_2434, v_k_2435});
                break;
              }
              case TAG_UriPath: {
                V v_u_2436 = heff_field(v_y_2426, 0);
                V v_k_2437 = heff_field(v_y_2426, 1);
                V v_ru_24y_2426_24UriPath = heff_take_reuse_n(v_y_2426, 3ULL, 2);
                heff_drop_cell(v_ru_24x_2423_24InL, 1);
                v_t_2454 = heff_tag_re_n(v_ru_24y_2426_24UriPath, TAG_UriPath, 2, 3ULL, (V[]){v_u_2436, v_k_2437});
                break;
              }
              case TAG_PathUri: {
                V v_p_2438 = heff_field(v_y_2426, 0);
                V v_k_2439 = heff_field(v_y_2426, 1);
                V v_ru_24y_2426_24PathUri = heff_take_reuse_n(v_y_2426, 3ULL, 2);
                heff_drop_cell(v_ru_24x_2423_24InL, 1);
                v_t_2454 = heff_tag_re_n(v_ru_24y_2426_24PathUri, TAG_PathUri, 2, 3ULL, (V[]){v_p_2438, v_k_2439});
                break;
              }
              case TAG_AbsPath: {
                V v_p_2440 = heff_field(v_y_2426, 0);
                V v_k_2441 = heff_field(v_y_2426, 1);
                V v_ru_24y_2426_24AbsPath = heff_take_reuse_n(v_y_2426, 3ULL, 2);
                heff_drop_cell(v_ru_24x_2423_24InL, 1);
                v_t_2454 = heff_tag_re_n(v_ru_24y_2426_24AbsPath, TAG_AbsPath, 2, 3ULL, (V[]){v_p_2440, v_k_2441});
                break;
              }
              case TAG_Attempt: {
                V v_b_2442 = heff_field(v_y_2426, 0);
                heff_take_n(v_y_2426, 1ULL, 1);
                v_t_2454 = heff_tag_at_n(v_ru_24x_2423_24InL, TAG_Attempt, 1, (V[]){heff_clo_n(g_std_2eprogress_2edrawing_24s2036895247x359356247_lam5, 1, 2, (V[]){v_b_2442, heff_dup(v_ts_2418)})});
                break;
              }
              case TAG_Quit: {
                V v_c_2453 = heff_field(v_y_2426, 0);
                heff_take_n(v_y_2426, 1ULL, 1);
                v_t_2454 = heff_tag_at_n(v_ru_24x_2423_24InL, TAG_Quit, 1, (V[]){v_c_2453});
                break;
              }
              default: heff_nomatch(v_y_2426);
              }
              v_t_2455 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2454});
              break;
            }
            default: heff_nomatch(v_x_2424);
            }
            v_t_2457 = heff_tag_at_n(v_ru_24x_2421_24InL, TAG_InL, 1, (V[]){v_t_2455});
            break;
          }
          case TAG_InR: {
            V v_y_2456 = heff_field(v_x_2423, 0);
            heff_take_n(v_x_2423, 1ULL, 1);
            heff_drop_cell(v_ru_24q_2420_24InL, 1);
            heff_drop_cell(v_ru_24x_2421_24InL, 1);
            v_t_2457 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_y_2456});
            break;
          }
          default: heff_nomatch(v_x_2423);
          }
          v_t_2459 = heff_tag_at_n(v_ru_24x_2422_24InL, TAG_InL, 1, (V[]){v_t_2457});
          break;
        }
        case TAG_InR: {
          V v_y_2458 = heff_field(v_x_2422, 0);
          heff_take_n(v_x_2422, 1ULL, 1);
          heff_drop_cell(v_ru_24q_2420_24InL, 1);
          heff_drop_cell(v_ru_24x_2421_24InL, 1);
          v_t_2459 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_y_2458});
          break;
        }
        default: heff_nomatch(v_x_2422);
        }
        v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2459});
        break;
      }
      case TAG_InR: {
        V v_y_2460 = heff_field(v_x_2421, 0);
        heff_take_n(v_x_2421, 1ULL, 1);
        heff_drop_cell(v_ru_24q_2420_24InL, 1);
        v_t_2461 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_y_2460});
        break;
      }
      default: heff_nomatch(v_x_2421);
      }
      v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2461});
      break;
    }
    case TAG_InR: {
      V v_y_2462 = heff_field(v_q_2420, 0);
      heff_take_n(v_q_2420, 1ULL, 1);
      v_t_2463 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_y_2462});
      break;
    }
    default: heff_nomatch(v_q_2420);
    }
    V f_ = ((V)&g_co_2eop_24s582347324x1305505939_clo);
    args[0] = v_t_2463;
    args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s2036895247x359356247_lam9, 3, 1, (V[]){v_ts_2418});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_p_2417);
  }
}
HEFF_LIT(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_str0, 0, "");
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam0(V self, V *args); static Clo g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam0, 3, 0};
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam2(V self, V *args);
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam1(V self, V *args); static Clo g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam1, 4, 0};
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam4(V self, V *args);
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam5(V self, V *args);
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam6(V self, V *args);
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam8(V self, V *args); static Clo g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam8, 1, 0};
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam9(V self, V *args);
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam7(V self, V *args);
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam3(V self, V *args); static Clo g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam3, 1, 0};

static V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_val;
static HEFF_ONCE g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_st;
static V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam0_clo), ((V)&g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam1_clo), ((V)&g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam3_clo)});
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_st)) return g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_val;
  return heff_global(&g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_val, &g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_st, g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_init);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = v_x_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = v_x_247;
  heff_room[1] = v_hd_245;
  heff_room[2] = v_k_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam1(V self, V *args) {
  V v_m_243 = args[0];
  V v_k_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_m_243;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam2, 1, 3, (V[]){v_k_244, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  heff_drop(v_hd_2416);
  heff_clo_take(self, 1);
  V f_ = v_k_2417;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_drop(v_hd_2420);
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_x_2423 = heff_env(self)[0];
  heff_drop(v_hd_2424);
  heff_clo_take(self, 1);
  V f_ = v_k_2425;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam8(V self, V *args) {
  V v_r_2433 = args[0];
  return v_r_2433;
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2439 = heff_tr(heff_call(v_k_2429, 1, (V[]){v_x_2438}));
  V f_ = v_k_2431;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam7(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_cmd_2427 = heff_env(self)[0];
  V v_argv_2428 = heff_env(self)[1];
  V v_k_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_cmd_2427, v_argv_2428, ((V)&g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_str0), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2432, ((V)&g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam8_clo)})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s2022167152x294629972(heff_tag_n(TAG_InL, 1, (V[]){v_t_2437}), v_hd_2430, heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam9, 1, 2, (V[]){v_k_2429, v_k_2431})));
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam3(V self, V *args) {
  V v_p_248 = args[0];
  switch (heff_tag_of(v_p_248)) {
  case TAG_InL: {
    V v_t_249 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 1);
    V v_x1_2410 = v_t_249;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Start: {
      V v_k_2414 = heff_field(v_x1_2410, 3);
      heff_take_n(v_x1_2410, 8ULL, 4);
      V v_x_2415 = heff_tr(heff_call(v_k_2414, 1, (V[]){heff_dup(g_std_2eprogress_2eroot_get())}));
      return heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam4, 2, 1, (V[]){v_x_2415});
    }
    case TAG_Complete: {
      V v_x_2419 = heff_field(v_x1_2410, 1);
      heff_take_n(v_x1_2410, 2ULL, 2);
      return heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam5, 2, 1, (V[]){v_x_2419});
    }
    case TAG_End: {
      V v_x_2423 = heff_field(v_x1_2410, 1);
      heff_take_n(v_x1_2410, 2ULL, 2);
      return heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam6, 2, 1, (V[]){v_x_2423});
    }
    case TAG_RunUnder: {
      V v_cmd_2427 = heff_field(v_x1_2410, 1);
      V v_argv_2428 = heff_field(v_x1_2410, 2);
      V v_k_2429 = heff_field(v_x1_2410, 3);
      heff_take_n(v_x1_2410, 14ULL, 4);
      return heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_lam7, 2, 3, (V[]){v_cmd_2427, v_argv_2428, v_k_2429});
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  case TAG_InR: {
    V v_q_2440 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 1);
    V f_ = ((V)&g_co_2eop_24s1673054648x994021533_clo);
    args[0] = v_q_2440;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_p_248);
  }
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam0(V self, V *args); static Clo g_std_2eprogress_2eshown_24s583895038x1291295401_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s583895038x1291295401_lam0, 1, 0};
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam2(V self, V *args); static Clo g_std_2eprogress_2eshown_24s583895038x1291295401_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s583895038x1291295401_lam2, 4, 0};
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam4(V self, V *args);
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam3(V self, V *args);
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam5(V self, V *args); static Clo g_std_2eprogress_2eshown_24s583895038x1291295401_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s583895038x1291295401_lam5, 3, 0};
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam1(V self, V *args);
Clo g_std_2eprogress_2eshown_24s583895038x1291295401_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s583895038x1291295401_entry, 4, 0};

V g_std_2eprogress_2eshown_24s583895038x1291295401(V v_c_240, V v_hd_241, V v_k_242, V v_z_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_IsTerminal, 1, (V[]){((V)&g_std_2eprogress_2eshown_24s583895038x1291295401_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_2425 = heff_tr(g_co_2eop_24s2022167152x294629972(heff_tag_n(TAG_InL, 1, (V[]){v_t_246}), heff_dup(v_hd_241), heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_lam1, 1, 3, (V[]){v_c_240, v_hd_241, v_k_242})));
  return heff_tail(v_t_2425, 1, (V[]){v_z_243});
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2eshown_24s583895038x1291295401(a[0], a[1], a[2], a[3]);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam0(V self, V *args) {
  V v_b_244 = args[0];
  return v_b_244;
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_ts_2410 = args[1];
  V v_hd_2411 = args[2];
  V v_k_2412 = args[3];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2410, v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_drop(v_x_2418);
  V v_t_2421;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkPair: {
    V v_y_2420 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 2ULL, 2);
    v_t_2421 = v_y_2420;
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_242;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_t_2415 = heff_tag_n(TAG_ShowLines, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s2022167152x294629972(v_t_2417, v_hd_241, heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_lam4, 1, 2, (V[]){v_x_2414, v_k_242})));
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2423 = args[1];
  V v_k_2424 = args[2];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s583895038x1291295401_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
    heff_drop(v_x_247);
    V v_t_248 = heff_rec_n(2, shape_next__going, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
    heff_clo_take(self, 3);
    V v_c_2413 = heff_tr(heff_call(v_c_240, 3, (V[]){heff_dup(g_std_2eprogress_2edrawing_24s2036895247x359356247_get()), ((V)&g_std_2eprogress_2eshown_24s583895038x1291295401_lam2_clo), v_t_248}));
    V f_ = v_c_2413;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_std_2eprogress_2eshown_24s583895038x1291295401_lam3, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_247);
    heff_clo_take(self, 3);
    V f_ = v_c_240;
    heff_room[0] = heff_dup(g_std_2eprogress_2eshown_24s583895038x1291295401_24rec0_get());
    heff_room[1] = ((V)&g_std_2eprogress_2eshown_24s583895038x1291295401_lam5_clo);
    heff_room[2] = v_hd_241;
    heff_room[3] = v_k_242;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}