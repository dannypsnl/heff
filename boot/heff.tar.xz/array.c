// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_array_2eempty_get(void);
V g_array_2eempty_lam0(V self, V *args); static Clo g_array_2eempty_lam0_clo = {{0x80000000u, K_CLO, 0}, g_array_2eempty_lam0, 1, 0};

static V g_array_2eempty_val;
static HEFF_ONCE g_array_2eempty_st;
static V g_array_2eempty_init(void) {
  return heff_arrayGenerate(MK_INT(0LL), ((V)&g_array_2eempty_lam0_clo));
}
V g_array_2eempty_get(void) {
  if (HEFF_DONE(g_array_2eempty_st)) return g_array_2eempty_val;
  return heff_global(&g_array_2eempty_val, &g_array_2eempty_st, g_array_2eempty_init);
}
V g_array_2eempty_lam0(V self, V *args) {
  V v_x_240 = args[0];
  heff_drop(v_x_240);
  return heff_abandon();
}