// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayIndex 31774
#define TAG_ArrayLength 32493
#define TAG_BytesAt 9508
#define TAG_BytesEq 9629
#define TAG_BytesFind 30348
#define TAG_BytesHasAt 63051
#define TAG_BytesIntAt 64296
#define TAG_BytesLength 9005
#define TAG_BytesSlice 56752
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FloatOfDecimal 61587
#define TAG_MkArm 55352
#define TAG_SetField 47531
#define TAG_StrByteAt 5424
#define TAG_StrCompare 35677
#define TAG_StrEq 12955
#define TAG_StrEqRange 52111
#define TAG_StrFind 15860
#define TAG_StrHash 2387
#define TAG_StrHashRange 56513
#define TAG_StrLength 43075
#define TAG_StrLt 13175
#define TAG_StrRuneAt 38304
#define TAG_StrRuneDecode 45427
#define TAG_StrRuneWidth 48503
#define TAG_StrSlice 780
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_params 951713969
static uint32_t shape_key__params__body[] = {LBL_key, LBL_params, LBL_body};
V g_heff_2ecompile_2eborrow_2eanyW(V, V);
V g_heff_2ecompile_2eborrow_2eanyW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eanyW_clo;
V g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012(V, V);
V g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012_clo;
V g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935(V, V);
V g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935_clo;
V g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224(V, V);
V g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_clo;
V g_heff_2ecompile_2eborrow_2eborDef(V, V);
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborDef_clo;
V g_heff_2ecompile_2eborrow_2eborFix(V, V, V);
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborFix_clo;
V g_heff_2ecompile_2eborrow_2ebuildsHere(V, V);
V g_heff_2ecompile_2eborrow_2ebuildsHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ebuildsHere_clo;
V g_heff_2ecompile_2eborrow_2elentVars(V, V, V);
V g_heff_2ecompile_2eborrow_2elentVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2elentVars_clo;
V g_heff_2ecompile_2eborrow_2eloopLent(V, V, V, V);
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eloopLent_clo;
V g_heff_2ecompile_2eborrow_2eloopOn(V, V, V);
V g_heff_2ecompile_2eborrow_2eloopOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eloopOn_clo;
V g_heff_2ecompile_2eborrow_2ematchOn(V, V);
V g_heff_2ecompile_2eborrow_2ematchOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ematchOn_clo;
V g_heff_2ecompile_2eborrow_2eonlyLent(V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo;
V g_heff_2ecompile_2eborrow_2eonlyLentCond(V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLentCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLentCond_clo;
V g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0(V, V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0_clo;
V g_heff_2ecompile_2eborrow_2epeeks(V, V, V, V, V);
V g_heff_2ecompile_2eborrow_2epeeks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2epeeks_clo;
V g_heff_2ecompile_2eborrow_2ereusesHere(V, V);
V g_heff_2ecompile_2eborrow_2ereusesHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ereusesHere_clo;
V g_heff_2ecompile_2eborrow_2esteps(V, V);
V g_heff_2ecompile_2eborrow_2esteps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2esteps_clo;
V g_heff_2ecompile_2eborrow_2etaggedArg(V, V, V, V);
V g_heff_2ecompile_2eborrow_2etaggedArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2etaggedArg_clo;
HeffT3 g_heff_2ecompile_2eir_2eboolArms_24cpr(V);
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1021595733x1528955560(V, V);
V g_list_2eany_24s1021595733x1528955560_entry(V self, V *a);
extern Clo g_list_2eany_24s1021595733x1528955560_clo;
V g_list_2eany_24s1760441014x1099436736(V, V);
V g_list_2eany_24s1760441014x1099436736_entry(V self, V *a);
extern Clo g_list_2eany_24s1760441014x1099436736_clo;
V g_list_2eany_24s361779565x1527579812(V);
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a);
extern Clo g_list_2eany_24s361779565x1527579812_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1922461191x750914054(V, V, V, V);
V g_list_2efoldl_24f1922461191x750914054_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1922461191x750914054_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1416922510x485352908(V, V);
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1416922510x485352908_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s498754754x815116558(V, V, V, V, V, V);
V g_list_2ekeepIf_24s498754754x815116558_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s498754754x815116558_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2eborrow_2eonlyLentCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eonlyLentCond_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eonlyLentCond(V v_go_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CTrue: {
    return NTAG(TAG_True);
  }
  case TAG_CFalse: {
    return NTAG(TAG_True);
  }
  case TAG_CRel: {
    V v_q_243 = heff_field(v_x3_242, 0);
    V v_a_244 = heff_field(v_x3_242, 1);
    V v_b_245 = heff_field(v_x3_242, 2);
    V v_t_246 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0(v_p_241, v_q_243, heff_dup(v_go_240), heff_dup(v_a_244)));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return (g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0(v_p_241, v_q_243, heff_dup(v_go_240), heff_dup(v_b_245)));
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  case TAG_CTest: {
    V v_e_247 = heff_field(v_x3_242, 0);
    V v_t_2447;
    switch (heff_tag_of(v_e_247)) {
    case TAG_EVar: {
      V v_x_248 = heff_field(v_e_247, 0);
      v_t_2447 = heff_bool(heff_strEq_c_lent(v_p_241, v_x_248, 0));
      break;
    }
    case TAG_EGlobal: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_247);
    }
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_t_2447);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2447);
      return heff_tail(heff_dup(v_go_240), 1, (V[]){heff_dup(v_e_247)});
    }
  }
  case TAG_CNot: {
    V v_c_2448 = heff_field(v_x3_242, 0);
    V t_0 = v_go_240;
    V t_1 = v_p_241;
    V t_2 = v_c_2448;
    v_go_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2449 = heff_field(v_x3_242, 0);
    V v_b_2450 = heff_field(v_x3_242, 1);
    V v_c_2451 = heff_field(v_x3_242, 2);
    V v_t_2452 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLentCond(v_go_240, v_p_241, v_a_2449));
    if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
      heff_drop(v_t_2452);
      V v_t_2453 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLentCond(v_go_240, v_p_241, v_b_2450));
      if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
        heff_drop(v_t_2453);
        V t_0 = v_go_240;
        V t_1 = v_p_241;
        V t_2 = v_c_2451;
        v_go_240 = t_0;
        v_p_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2453);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_2452);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLentCond_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eborrow_2eonlyLentCond(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam2(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam3(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam4(V self, V *args);
V g_heff_2ecompile_2eborrow_2eonlyLent_lam5(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eonlyLent_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eonlyLent(V v_bor_240, V v_p_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_p_241, v_x_243, 0));
    return v_ret_24bool;
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x3_242, 1);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_b_246;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x3_242, 0);
    V v_args_248 = heff_field(v_x3_242, 1);
    V v_p_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}));
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_p_249), 1, (V[]){heff_dup(v_f_247)}));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      return ({ V a_0 = v_p_249; V a_1 = v_args_248; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_p_249); r_; });
    } else {
      heff_drop(v_p_249);
      heff_drop(v_t_2410);
      return NTAG(TAG_False);
    }
  }
  case TAG_ELet: {
    V v_a_2412 = heff_field(v_x3_242, 1);
    V v_b_2413 = heff_field(v_x3_242, 2);
    V v_t_2414 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_a_2412));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_2413;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x3_242, 0);
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam0, 1, 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}); V a_1 = v_fs_2415; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
  }
  case TAG_EProj: {
    V v_e_2421 = heff_field(v_x3_242, 0);
    V t_0 = v_bor_240;
    V t_1 = v_p_241;
    V t_2 = v_e_2421;
    v_bor_240 = t_0;
    v_p_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2426 = heff_field(v_x3_242, 1);
    V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}));
    return ({ V a_0 = v_t_2428; V a_1 = v_args_2426; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2428); r_; });
  }
  case TAG_EMatch: {
    V v_s_2429 = heff_field(v_x3_242, 0);
    V v_arms_2430 = heff_field(v_x3_242, 1);
    V v_t_2470;
    switch (heff_tag_of(v_s_2429)) {
    case TAG_EVar: {
      V v_x_2431 = heff_field(v_s_2429, 0);
      v_t_2470 = heff_bool(heff_strEq_c_lent(v_p_241, v_x_2431, 0));
      break;
    }
    case TAG_EGlobal: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2470 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2429);
    }
    if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
      heff_drop(v_t_2470);
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam1, 1, 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}); V a_1 = v_arms_2430; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_t_2470);
      V v_t_2476 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_s_2429));
      if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
        heff_drop(v_t_2476);
        return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam2, 1, 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}); V a_1 = v_arms_2430; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_t_2476);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_x31_2483 = heff_field(v_x3_242, 0);
    V v_x32_2484 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_2483)) {
    case TAG_SetField: {
      switch (heff_tag_of(v_x32_2484)) {
      case TAG_Nil: {
        return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam3, 1, 3, (V[]){heff_dup(v_p_241), heff_dup(v_x31_2483), heff_dup(v_bor_240)}); V a_1 = v_x32_2484; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
      }
      case TAG_Cons: {
        V v_d_24126 = heff_field(v_x32_2484, 0);
        V v_rest_24127 = heff_field(v_x32_2484, 1);
        V v_t_24167;
        switch (heff_tag_of(v_d_24126)) {
        case TAG_EVar: {
          V v_x_24128 = heff_field(v_d_24126, 0);
          v_t_24167 = heff_bool(heff_strEq_c_lent(v_p_241, v_x_24128, 0));
          break;
        }
        case TAG_EGlobal: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_ELam: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EApp: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_ELet: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_ERecord: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EProj: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EMatch: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrim: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrimCall: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_ECall: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EFloat: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EStr: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EBytes: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EFixed: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EFloat32: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EAbandon: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EBool: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_ESet: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EValues: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        case TAG_EFix: {
          v_t_24167 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_d_24126);
        }
        if ((heff_dup(v_t_24167) == NTAG(TAG_True))) {
          heff_drop(v_t_24167);
          V v_t_24168 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}));
          return ({ V a_0 = v_t_24168; V a_1 = v_rest_24127; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24168); r_; });
        } else {
          heff_drop(v_t_24167);
          V v_t_24169 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_d_24126));
          if ((heff_dup(v_t_24169) == NTAG(TAG_True))) {
            heff_drop(v_t_24169);
            V v_t_24170 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}));
            return ({ V a_0 = v_t_24170; V a_1 = v_rest_24127; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24170); r_; });
          } else {
            heff_drop(v_t_24169);
            return NTAG(TAG_False);
          }
        }
      }
      default: return heff_nomatch(v_x32_2484);
      }
    }
    default: {
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam4, 1, 3, (V[]){heff_dup(v_p_241), heff_dup(v_x31_2483), heff_dup(v_bor_240)}); V a_1 = v_x32_2484; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
    }
    }
  }
  case TAG_ECall: {
    V v_g_24212 = heff_field(v_x3_242, 0);
    V v_args_24213 = heff_field(v_x3_242, 1);
    V v_t_24214 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_24213));
    V v_t_24215 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_24214, MK_INT(1LL))));
    V v_t_24216 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_args_24213), v_t_24215));
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eonlyLent_lam5, 1, 3, (V[]){heff_dup(v_p_241), heff_dup(v_bor_240), heff_dup(v_g_24212)}); V a_1 = v_t_24216; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24216); r_; });
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    V v_c_24276 = heff_field(v_x3_242, 0);
    V v_t_24277 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}));
    return ({ V a_0 = v_t_24277; V a_1 = v_p_241; V a_2 = v_c_24276; V r_ = (g_heff_2ecompile_2eborrow_2eonlyLentCond(a_0, a_1, a_2)); heff_drop(v_t_24277); r_; });
  }
  case TAG_ESet: {
    V v_a_24279 = heff_field(v_x3_242, 1);
    V v_b_24280 = heff_field(v_x3_242, 2);
    V v_t_24281 = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(v_bor_240, v_p_241, v_a_24279));
    if ((heff_dup(v_t_24281) == NTAG(TAG_True))) {
      heff_drop(v_t_24281);
      V t_0 = v_bor_240;
      V t_1 = v_p_241;
      V t_2 = v_b_24280;
      v_bor_240 = t_0;
      v_p_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_24281);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_24282 = heff_field(v_x3_242, 0);
    V v_t_24283 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eonlyLent_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_p_241)}));
    return ({ V a_0 = v_t_24283; V a_1 = v_es_24282; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_24283); r_; });
  }
  case TAG_EFix: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eborrow_2eonlyLent(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_t_2420;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 2ULL, 2);
    v_t_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  heff_clo_take(self, 2);
  return ({ V a_0 = v_bor_240; V a_1 = v_p_241; V a_2 = v_t_2420; V r_ = (g_heff_2ecompile_2eborrow_2eonlyLent(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_p_241); heff_drop(v_t_2420); r_; });
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam1(V self, V *args) {
  V v_a_2471 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_t_2475;
  switch (heff_tag_of(v_a_2471)) {
  case TAG_MkArm: {
    V v_b_2474 = heff_field(v_a_2471, 2);
    heff_take_n(v_a_2471, 4ULL, 3);
    v_t_2475 = v_b_2474;
    break;
  }
  default: heff_nomatch(v_a_2471);
  }
  heff_clo_take(self, 2);
  return ({ V a_0 = v_bor_240; V a_1 = v_p_241; V a_2 = v_t_2475; V r_ = (g_heff_2ecompile_2eborrow_2eonlyLent(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_p_241); heff_drop(v_t_2475); r_; });
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam2(V self, V *args) {
  V v_a_2477 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_t_2481;
  switch (heff_tag_of(v_a_2477)) {
  case TAG_MkArm: {
    V v_b_2480 = heff_field(v_a_2477, 2);
    heff_take_n(v_a_2477, 4ULL, 3);
    v_t_2481 = v_b_2480;
    break;
  }
  default: heff_nomatch(v_a_2477);
  }
  heff_clo_take(self, 2);
  return ({ V a_0 = v_bor_240; V a_1 = v_p_241; V a_2 = v_t_2481; V r_ = (g_heff_2ecompile_2eborrow_2eonlyLent(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_p_241); heff_drop(v_t_2481); r_; });
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam3(V self, V *args) {
  V v_a_2485 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_x31_2483 = heff_env(self)[1];
  V v_bor_240 = heff_env(self)[2];
  V v_t_24125;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_a_2485)) {
  case TAG_EVar: {
    V v_x_2486 = heff_dup(heff_field(v_a_2485, 0));
    if (heff_strEq_c_lent(v_p_241, v_x_2486, 2)) {
      switch (heff_tag_of(v_x31_2483)) {
      case TAG_ArrayLength: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_ArrayIndex: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrLength: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrSlice: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrEq: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrLt: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrCompare: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrFind: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrByteAt: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneAt: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneWidth: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesLength: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesAt: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesSlice: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesEq: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesIntAt: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesHasAt: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesFind: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_FloatOfDecimal: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrHash: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrHashRange: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrEqRange: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneDecode: {
        v_t_24125 = NTAG(TAG_True);
        break;
      }
      default: {
        heff_drop(v_x31_2483);
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      }
    } else {
      heff_drop(v_x31_2483);
      v_t_24125 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EGlobal: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_drop(v_x31_2483);
    v_t_24125 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_2485);
  }
  if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
    heff_drop(v_a_2485);
    heff_drop(v_p_241);
    heff_drop(v_bor_240);
    heff_drop(v_t_24125);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_24125);
    return ({ V a_0 = v_bor_240; V a_1 = v_p_241; V a_2 = v_a_2485; V r_ = (g_heff_2ecompile_2eborrow_2eonlyLent(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_p_241); heff_drop(v_a_2485); r_; });
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam4(V self, V *args) {
  V v_a_24171 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_x31_2483 = heff_env(self)[1];
  V v_bor_240 = heff_env(self)[2];
  V v_t_24211;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_a_24171)) {
  case TAG_EVar: {
    V v_x_24172 = heff_dup(heff_field(v_a_24171, 0));
    if (heff_strEq_c_lent(v_p_241, v_x_24172, 2)) {
      switch (heff_tag_of(v_x31_2483)) {
      case TAG_ArrayLength: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_ArrayIndex: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrLength: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrSlice: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrEq: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrLt: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrCompare: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrFind: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrByteAt: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneAt: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneWidth: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesLength: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesAt: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesSlice: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesEq: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesIntAt: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesHasAt: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesFind: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_FloatOfDecimal: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrHash: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrHashRange: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrEqRange: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneDecode: {
        v_t_24211 = NTAG(TAG_True);
        break;
      }
      default: {
        heff_drop(v_x31_2483);
        v_t_24211 = NTAG(TAG_False);
        break;
      }
      }
    } else {
      heff_drop(v_x31_2483);
      v_t_24211 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EGlobal: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_drop(v_x31_2483);
    v_t_24211 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_24171);
  }
  if ((heff_dup(v_t_24211) == NTAG(TAG_True))) {
    heff_drop(v_a_24171);
    heff_drop(v_p_241);
    heff_drop(v_bor_240);
    heff_drop(v_t_24211);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_24211);
    return ({ V a_0 = v_bor_240; V a_1 = v_p_241; V a_2 = v_a_24171; V r_ = (g_heff_2ecompile_2eborrow_2eonlyLent(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_p_241); heff_drop(v_a_24171); r_; });
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLent_lam5(V self, V *args) {
  V v_pr_24217 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_bor_240 = heff_env(self)[1];
  V v_g_24212 = heff_env(self)[2];
  V v_t_24220;
  switch (heff_tag_of(v_pr_24217)) {
  case TAG_MkPair: {
    V v_x_24218 = heff_dup(heff_field(v_pr_24217, 0));
    v_t_24220 = v_x_24218;
    break;
  }
  default: heff_nomatch(v_pr_24217);
  }
  V v_t_24265;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_t_24220)) {
  case TAG_EVar: {
    V v_x_24221 = heff_field(v_t_24220, 0);
    heff_take_n(v_t_24220, 1ULL, 1);
    if (heff_strEq_c_lent(v_p_241, v_x_24221, 2)) {
      HeffT2 v_t_24222 = ({ V a_0 = v_bor_240; V a_1 = v_g_24212; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_24212); r_; });
      {
        V v_field_24224 = v_t_24222.f[1];
        int64_t v_tag_24223 = ((int64_t)v_t_24222.f[0]);
        V v_t_24226;
        if ((v_tag_24223 == ((int64_t)0ULL))) {
          V v_x_24225 = v_field_24224;
          v_t_24226 = v_x_24225;
        } else {
          heff_drop(v_field_24224);
          v_t_24226 = NTAG(TAG_Nil);
        }
        v_t_24265 = ({ V a_0 = v_pr_24217; V a_1 = v_t_24226; V r_ = (g_list_2eany_24s1760441014x1099436736(a_0, a_1)); heff_drop(v_t_24226); r_; });
      }
    } else {
      heff_drop(v_g_24212);
      v_t_24265 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_t_24220, 0ULL, 2);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_24220, 0ULL, 2);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_24220, 0ULL, 3);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_24220, 0ULL, 2);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_24220, 0ULL, 4);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_24220, 0ULL, 3);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_24220, 0ULL, 2);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_24220, 0ULL, 2);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_24220, 0ULL, 2);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_24220, 0ULL, 2);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_t_24220, 0ULL, 3);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_t_24220, 0ULL, 1);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_24220, 0ULL, 2);
    heff_drop(v_g_24212);
    v_t_24265 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_24220);
  }
  if ((heff_dup(v_t_24265) == NTAG(TAG_True))) {
    heff_drop(v_pr_24217);
    heff_drop(v_p_241);
    heff_drop(v_bor_240);
    heff_drop(v_t_24265);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_24265);
    V v_t_24268;
    switch (heff_tag_of(v_pr_24217)) {
    case TAG_MkPair: {
      V v_x_24266 = heff_field(v_pr_24217, 0);
      heff_take_n(v_pr_24217, 1ULL, 2);
      v_t_24268 = v_x_24266;
      break;
    }
    default: heff_nomatch(v_pr_24217);
    }
    return ({ V a_0 = v_bor_240; V a_1 = v_p_241; V a_2 = v_t_24268; V r_ = (g_heff_2ecompile_2eborrow_2eonlyLent(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_p_241); heff_drop(v_t_24268); r_; });
  }
}
Clo g_heff_2ecompile_2eborrow_2eanyW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eanyW_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eanyW(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_e_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_e_242);
      heff_drop(v_rest_243);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, v_rest_243));
      V t_0 = v_f_240;
      V t_1 = v_t_245;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eanyW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2eanyW(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eborrow_2ebuildsHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ebuildsHere_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ebuildsHere(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_x2_241, 0);
    V v_args_2418 = heff_field(v_x2_241, 1);
    V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2418));
    V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_t_2420, v_n_240, 0) && ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2417, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2417, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)));
    heff_drop(v_n_240);
    heff_drop(v_t_2420);
    return v_ret_24bool;
  }
  case TAG_EMatch: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_n_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ebuildsHere_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2ebuildsHere(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2ebuildsHere(heff_dup(v_lit_240), v_e_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_e_242);
      heff_drop(v_rest_243);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, v_rest_243));
      V t_0 = v_lit_240;
      V t_1 = v_t_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eborrow_2ereusesHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ereusesHere_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ereusesHere(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2420 = heff_field(v_x2_241, 0);
    V v_arms_2421 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_s_2420)) {
    case TAG_EVar: {
      V v_x_2422 = heff_field(v_s_2420, 0);
      if (heff_strEq_c_lent(v_p_240, v_x_2422, 0)) {
        return (g_list_2eany_24s361779565x1527579812(v_arms_2421));
      } else {
        return NTAG(TAG_False);
      }
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_s_2420);
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ereusesHere_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2ereusesHere(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2ereusesHere(v_lit_240, v_e_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_e_242);
      heff_drop(v_rest_243);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, v_rest_243));
      V t_0 = v_lit_240;
      V t_1 = v_t_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eborrow_2ematchOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2ematchOn_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2ematchOn(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2420 = heff_field(v_x2_241, 0);
    V v_arms_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_s_2420)) {
    case TAG_EVar: {
      V v_x_2422 = heff_field(v_s_2420, 0);
      heff_take_n(v_s_2420, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_240, v_x_2422, 2)) {
        HeffT3 v_t_2423 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(v_arms_2421));
        {
          V v_field_2425 = v_t_2423.f[1];
          V v_field_2426 = v_t_2423.f[2];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          V v_ret_24bool = heff_bool(((v_tag_2424 == ((int64_t)0ULL)) ? ({ V v_x11_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_field_2425), heff_dup(v_field_2426)}); int c_ = 0; heff_drop(v_x11_2427); c_; }) : 1));
          heff_drop(v_field_2425);
          heff_drop(v_field_2426);
          return v_ret_24bool;
        }
      } else {
        heff_drop(v_arms_2421);
        return NTAG(TAG_False);
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_take_n(v_s_2420, 0ULL, 2);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_take_n(v_s_2420, 0ULL, 2);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_s_2420, 0ULL, 3);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_s_2420, 0ULL, 2);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_s_2420, 0ULL, 4);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_s_2420, 0ULL, 3);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_s_2420, 0ULL, 2);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_s_2420, 0ULL, 2);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_s_2420, 0ULL, 2);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_nf(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_s_2420, 0ULL, 2);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_take_n(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_take_n(v_s_2420, 0ULL, 3);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_take_n(v_s_2420, 0ULL, 1);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_s_2420, 0ULL, 2);
      heff_drop(v_arms_2421);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_s_2420);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2ematchOn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2ematchOn(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2ematchOn(v_lit_240, heff_dup(v_e_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_e_242);
      heff_drop(v_rest_243);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, v_rest_243));
      V t_0 = v_lit_240;
      V t_1 = v_t_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eborrow_2etaggedArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2etaggedArg_entry, 4, 0};

V g_heff_2ecompile_2eborrow_2etaggedArg(V v_b_240, V v_x_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x3_242, 0);
    V v_ps_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_a_246 = heff_field(v_x4_243, 0);
      V v_rest_247 = heff_field(v_x4_243, 1);
      V v_t_2449;
      switch (heff_tag_of(v_a_246)) {
      case TAG_EVar: {
        V v_x_248 = heff_field(v_a_246, 0);
        if (heff_strEq_c_lent(v_x_241, v_x_248, 0)) {
          V v_t_249 = (g_heff_2ecompile_2eborrow_2ematchOn(v_p_244, heff_dup(v_b_240)));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2449 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_249);
            V v_t_2410 = (g_heff_2ecompile_2eir_2epartsOnto(heff_dup(v_b_240), NTAG(TAG_Nil)));
            v_t_2449 = (g_heff_2ecompile_2eborrow_2eanyW_24s1994179528x1103961935(v_p_244, v_t_2410));
          }
        } else {
          v_t_2449 = NTAG(TAG_False);
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_t_2449);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2449);
        V t_0 = v_b_240;
        V t_1 = v_x_241;
        V t_2 = v_ps_245;
        V t_3 = v_rest_247;
        v_b_240 = t_0;
        v_x_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2etaggedArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eborrow_2etaggedArg(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eborrow_2eloopOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eloopOn_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eloopOn(V v_lp_240, V v_x_241, V v_x3_242) {
top: ;
  V v_key_243 = heff_take_field(v_lp_240, 0);
  V v_body_244 = heff_take_field(v_lp_240, 2);
  V v_params_245 = heff_get_n(v_lp_240, 1, 3);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_g_2429 = heff_field(v_x3_242, 0);
    V v_args_2430 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_g_2429, v_key_243, 2)) {
      return ({ V a_0 = v_body_244; V a_1 = v_x_241; V a_2 = v_params_245; V a_3 = v_args_2430; V r_ = (g_heff_2ecompile_2eborrow_2etaggedArg(a_0, a_1, a_2, a_3)); heff_drop(v_body_244); heff_drop(v_params_245); r_; });
    } else {
      heff_drop(v_body_244);
      heff_drop(v_params_245);
      return NTAG(TAG_False);
    }
  }
  case TAG_EInt: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_243);
    heff_drop(v_body_244);
    heff_drop(v_params_245);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2eloopOn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eborrow_2eloopOn(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eborrow_2epeeks_lam0(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2epeeks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2epeeks_entry, 5, 0};

V g_heff_2ecompile_2eborrow_2epeeks(V v_lp_240, V v_ds_241, V v_x_242, V v_x4_243, V v_b_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_x41_2426 = heff_field(v_x4_243, 0);
    V v_x42_2427 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_2426)) {
    case TAG_ArrayIndex: {
      switch (heff_tag_of(v_x42_2427)) {
      case TAG_Nil: {
        heff_drop(v_lp_240);
        heff_drop(v_b_244);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_a_2428 = heff_field(v_x42_2427, 0);
        switch (heff_tag_of(v_a_2428)) {
        case TAG_EVar: {
          V v_x_2430 = heff_field(v_a_2428, 0);
          V v_t_2431 = (g_list_2eany_24s1006624359x760861690(v_x_2430, v_ds_241));
          if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
            heff_drop(v_t_2431);
            V v_t_2432 = (g_heff_2ecompile_2eborrow_2ematchOn(v_x_242, heff_dup(v_b_244)));
            if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
              heff_drop(v_lp_240);
              heff_drop(v_b_244);
              heff_drop(v_t_2432);
              return NTAG(TAG_True);
            } else {
              heff_drop(v_t_2432);
              V v_t_2433 = (g_heff_2ecompile_2eborrow_2eloopOn(heff_dup(v_lp_240), v_x_242, v_b_244));
              if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
                heff_drop(v_lp_240);
                heff_drop(v_b_244);
                heff_drop(v_t_2433);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_t_2433);
                V v_t_2434 = (g_heff_2ecompile_2eir_2epartsOnto(v_b_244, NTAG(TAG_Nil)));
                return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2epeeks_lam0, 1, 2, (V[]){heff_dup(v_x_242), v_lp_240}); V a_1 = v_t_2434; V r_ = (g_heff_2ecompile_2eborrow_2eanyW(b_0, a_1)); heff_drop(b_0); r_; });
              }
            }
          } else {
            heff_drop(v_lp_240);
            heff_drop(v_b_244);
            heff_drop(v_t_2431);
            return NTAG(TAG_False);
          }
        }
        case TAG_EGlobal: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_ELam: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EApp: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_ELet: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_ERecord: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EProj: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_ETag: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EMatch: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EPrim: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EPrimCall: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_ECall: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EInt: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EFloat: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EStr: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EBytes: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EFixed: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EFloat32: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EAbandon: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EBool: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_ESet: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EValues: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        case TAG_EFix: {
          heff_drop(v_lp_240);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_a_2428);
        }
      }
      default: return heff_nomatch(v_x42_2427);
      }
    }
    case TAG_SetField: {
      heff_drop(v_lp_240);
      heff_drop(v_b_244);
      switch (heff_tag_of(v_x42_2427)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_d_2475 = heff_field(v_x42_2427, 0);
        switch (heff_tag_of(v_d_2475)) {
        case TAG_EVar: {
          V v_x_2477 = heff_field(v_d_2475, 0);
          return (g_list_2eany_24s1006624359x760861690(v_x_2477, v_ds_241));
        }
        case TAG_EGlobal: {
          return NTAG(TAG_False);
        }
        case TAG_ELam: {
          return NTAG(TAG_False);
        }
        case TAG_EApp: {
          return NTAG(TAG_False);
        }
        case TAG_ELet: {
          return NTAG(TAG_False);
        }
        case TAG_ERecord: {
          return NTAG(TAG_False);
        }
        case TAG_EProj: {
          return NTAG(TAG_False);
        }
        case TAG_ETag: {
          return NTAG(TAG_False);
        }
        case TAG_EMatch: {
          return NTAG(TAG_False);
        }
        case TAG_EPrim: {
          return NTAG(TAG_False);
        }
        case TAG_EPrimCall: {
          return NTAG(TAG_False);
        }
        case TAG_ECall: {
          return NTAG(TAG_False);
        }
        case TAG_EInt: {
          return NTAG(TAG_False);
        }
        case TAG_EFloat: {
          return NTAG(TAG_False);
        }
        case TAG_EStr: {
          return NTAG(TAG_False);
        }
        case TAG_EBytes: {
          return NTAG(TAG_False);
        }
        case TAG_EFixed: {
          return NTAG(TAG_False);
        }
        case TAG_EFloat32: {
          return NTAG(TAG_False);
        }
        case TAG_EAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_EBool: {
          return NTAG(TAG_False);
        }
        case TAG_ESet: {
          return NTAG(TAG_False);
        }
        case TAG_EValues: {
          return NTAG(TAG_False);
        }
        case TAG_EFix: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_d_2475);
        }
      }
      default: return heff_nomatch(v_x42_2427);
      }
    }
    default: {
      heff_drop(v_lp_240);
      heff_drop(v_b_244);
      return NTAG(TAG_False);
    }
    }
  }
  case TAG_ECall: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_lp_240);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eborrow_2epeeks_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eborrow_2epeeks(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eborrow_2epeeks_lam0(V self, V *args) {
  V v_e_2435 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_lp_240 = heff_env(self)[1];
  V v_t_2436 = (g_heff_2ecompile_2eborrow_2ematchOn(v_x_242, heff_dup(v_e_2435)));
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_e_2435);
    heff_drop(self);
    heff_drop(v_t_2436);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2436);
    heff_clo_take(self, 2);
    return ({ V a_0 = v_lp_240; V a_1 = v_x_242; V a_2 = v_e_2435; V r_ = (g_heff_2ecompile_2eborrow_2eloopOn(a_0, a_1, a_2)); heff_drop(v_x_242); heff_drop(v_e_2435); r_; });
  }
}
V g_heff_2ecompile_2eborrow_2elentVars_lam0(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2elentVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2elentVars_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2elentVars(V v_lp_240, V v_ds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_x3_242, 0);
    V v_a_2410 = heff_field(v_x3_242, 1);
    V v_b_2411 = heff_field(v_x3_242, 2);
    V v_t_2412 = (g_heff_2ecompile_2eborrow_2elentVars(v_lp_240, heff_dup(v_ds_241), v_a_2410));
    V v_t_2413 = (g_heff_2ecompile_2eborrow_2epeeks(heff_dup(v_lp_240), v_ds_241, v_x_249, v_a_2410, heff_dup(v_b_2411)));
    V v_t_2415;
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      V v_t_2414 = (g_heff_2ecompile_2eborrow_2elentVars(v_lp_240, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_249), v_ds_241}), v_b_2411));
      v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_249), v_t_2414});
    } else {
      heff_drop(v_t_2413);
      v_t_2415 = (g_heff_2ecompile_2eborrow_2elentVars(v_lp_240, v_ds_241, v_b_2411));
    }
    return (g_prelude_2e_2b_2b(v_t_2412, v_t_2415));
  }
  case TAG_ERecord: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_x3_242, 0);
    V v_arms_2426 = heff_field(v_x3_242, 1);
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2426)));
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2elentVars_lam0, 2, 3, (V[]){heff_dup(v_s_2425), v_ds_241, heff_dup(v_lp_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2427; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2427); r_; });
  }
  case TAG_EPrim: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    V v_a_24103 = heff_field(v_x3_242, 1);
    V v_b_24104 = heff_field(v_x3_242, 2);
    V v_t_24105 = (g_heff_2ecompile_2eborrow_2elentVars(v_lp_240, heff_dup(v_ds_241), v_a_24103));
    V v_t_24106 = (g_heff_2ecompile_2eborrow_2elentVars(v_lp_240, v_ds_241, v_b_24104));
    return (g_prelude_2e_2b_2b(v_t_24105, v_t_24106));
  }
  case TAG_EValues: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_drop(v_ds_241);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eborrow_2elentVars_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eborrow_2elentVars(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eborrow_2elentVars_lam0(V self, V *args) {
  V v_acc_2428 = args[0];
  V v_x_2429 = args[1];
  V v_s_2425 = heff_env(self)[0];
  V v_ds_241 = heff_env(self)[1];
  V v_lp_240 = heff_env(self)[2];
  V v_t_2469;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_s_2425)) {
  case TAG_EVar: {
    V v_x_2430 = heff_field(v_s_2425, 0);
    heff_take_n(v_s_2425, 1ULL, 1);
    v_t_2469 = ({ V a_0 = v_x_2430; V a_1 = v_ds_241; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_2430); r_; });
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_s_2425, 0ULL, 2);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_s_2425, 0ULL, 2);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_s_2425, 0ULL, 3);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_s_2425, 0ULL, 2);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_s_2425, 0ULL, 4);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_s_2425, 0ULL, 3);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_s_2425, 0ULL, 2);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_s_2425, 0ULL, 2);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_s_2425, 0ULL, 2);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_s_2425, 0ULL, 2);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_s_2425, 0ULL, 3);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_s_2425, 0ULL, 1);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_s_2425, 0ULL, 2);
    v_t_2469 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_s_2425);
  }
  V v_t_2488;
  if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
    heff_drop(v_t_2469);
    V v_t_2473;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_MkArm: {
      V v_vs_2471 = heff_dup(heff_field(v_x_2429, 1));
      v_t_2473 = v_vs_2471;
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    V v_t_2477;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_MkArm: {
      V v_vs_2475 = heff_dup(heff_field(v_x_2429, 1));
      v_t_2477 = v_vs_2475;
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    V v_t_2478 = (g_prelude_2e_2b_2b(v_t_2477, v_ds_241));
    V v_t_2482;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_MkArm: {
      V v_b_2481 = heff_field(v_x_2429, 2);
      heff_take_n(v_x_2429, 4ULL, 3);
      v_t_2482 = v_b_2481;
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    V v_t_2483 = ({ V a_0 = v_lp_240; V a_1 = v_t_2478; V a_2 = v_t_2482; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(a_0, a_1, a_2)); heff_drop(v_lp_240); heff_drop(v_t_2482); r_; });
    v_t_2488 = (g_prelude_2e_2b_2b(v_t_2473, v_t_2483));
  } else {
    heff_drop(v_t_2469);
    V v_t_2487;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_MkArm: {
      V v_b_2486 = heff_field(v_x_2429, 2);
      heff_take_n(v_x_2429, 4ULL, 3);
      v_t_2487 = v_b_2486;
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    v_t_2488 = ({ V a_0 = v_lp_240; V a_1 = v_ds_241; V a_2 = v_t_2487; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(a_0, a_1, a_2)); heff_drop(v_lp_240); heff_drop(v_t_2487); r_; });
  }
  return (g_prelude_2e_2b_2b(v_t_2488, v_acc_2428));
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eloopLent_lam1(V self, V *args);
V g_heff_2ecompile_2eborrow_2eloopLent_lam2(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eloopLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eloopLent_entry, 4, 0};

V g_heff_2ecompile_2eborrow_2eloopLent(V v_key_240, V v_i_241, V v_ds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x4_243, 0);
    V v_args_249 = heff_field(v_x4_243, 1);
    V v_p_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}));
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_p_2410), 1, (V[]){heff_dup(v_f_248)}));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      return ({ V a_0 = v_p_2410; V a_1 = v_args_249; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_p_2410); r_; });
    } else {
      heff_drop(v_p_2410);
      heff_drop(v_t_2411);
      return NTAG(TAG_False);
    }
  }
  case TAG_ELet: {
    V v_a_2413 = heff_field(v_x4_243, 1);
    V v_b_2414 = heff_field(v_x4_243, 2);
    V v_t_2415 = (g_heff_2ecompile_2eborrow_2eloopLent(v_key_240, v_i_241, v_ds_242, v_a_2413));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2414;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2415);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2416 = heff_field(v_x4_243, 0);
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam0, 1, 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_fs_2416; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
  }
  case TAG_EProj: {
    V v_e_2422 = heff_field(v_x4_243, 0);
    V t_0 = v_key_240;
    V t_1 = v_i_241;
    V t_2 = v_ds_242;
    V t_3 = v_e_2422;
    v_key_240 = t_0;
    v_i_241 = t_1;
    v_ds_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2427 = heff_field(v_x4_243, 1);
    V v_t_2429 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}));
    return ({ V a_0 = v_t_2429; V a_1 = v_args_2427; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2429); r_; });
  }
  case TAG_EMatch: {
    V v_s_2430 = heff_field(v_x4_243, 0);
    V v_arms_2431 = heff_field(v_x4_243, 1);
    V v_t_2432 = (g_heff_2ecompile_2eborrow_2eloopLent(v_key_240, v_i_241, v_ds_242, v_s_2430));
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_t_2432);
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam1, 1, 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_arms_2431; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_t_2432);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_args_2440 = heff_field(v_x4_243, 1);
    V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}));
    return ({ V a_0 = v_t_2441; V a_1 = v_args_2440; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2441); r_; });
  }
  case TAG_ECall: {
    V v_g_2442 = heff_field(v_x4_243, 0);
    V v_args_2443 = heff_field(v_x4_243, 1);
    if (!heff_strEq_c_lent(v_g_2442, v_key_240, 0)) {
      V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}));
      return ({ V a_0 = v_t_2444; V a_1 = v_args_2443; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2444); r_; });
    } else {
      V v_t_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2443));
      V v_t_2446 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2445, MK_INT(1LL))));
      V v_t_2447 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_args_2443), v_t_2446));
      V v_t_2466 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eloopLent_lam2, 1, 2, (V[]){heff_dup(v_i_241), heff_dup(v_ds_242)}); V a_1 = v_t_2447; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2447); r_; });
      if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
        heff_drop(v_t_2466);
        V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}));
        return ({ V a_0 = v_t_2467; V a_1 = v_args_2443; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2467); r_; });
      } else {
        heff_drop(v_t_2466);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    V v_c_2475 = heff_field(v_x4_243, 0);
    V v_t_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}));
    V v_t_2477 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2475, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_2476; V a_1 = v_t_2477; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2476); heff_drop(v_t_2477); r_; });
  }
  case TAG_ESet: {
    V v_a_2479 = heff_field(v_x4_243, 1);
    V v_b_2480 = heff_field(v_x4_243, 2);
    V v_t_2481 = (g_heff_2ecompile_2eborrow_2eloopLent(v_key_240, v_i_241, v_ds_242, v_a_2479));
    if ((heff_dup(v_t_2481) == NTAG(TAG_True))) {
      heff_drop(v_t_2481);
      V t_0 = v_key_240;
      V t_1 = v_i_241;
      V t_2 = v_ds_242;
      V t_3 = v_b_2480;
      v_key_240 = t_0;
      v_i_241 = t_1;
      v_ds_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2481);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_2482 = heff_field(v_x4_243, 0);
    V v_t_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2eloopLent_clo), 3, (V[]){heff_dup(v_key_240), heff_dup(v_i_241), heff_dup(v_ds_242)}));
    return ({ V a_0 = v_t_2483; V a_1 = v_es_2482; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2483); r_; });
  }
  case TAG_EFix: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eborrow_2eloopLent(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam0(V self, V *args) {
  V v_f_2418 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_ds_242 = heff_env(self)[2];
  V v_t_2421;
  switch (heff_tag_of(v_f_2418)) {
  case TAG_MkPair: {
    V v_y_2420 = heff_field(v_f_2418, 1);
    heff_take_n(v_f_2418, 2ULL, 2);
    v_t_2421 = v_y_2420;
    break;
  }
  default: heff_nomatch(v_f_2418);
  }
  heff_clo_take(self, 3);
  return ({ V a_0 = v_key_240; V a_1 = v_i_241; V a_2 = v_ds_242; V a_3 = v_t_2421; V r_ = (g_heff_2ecompile_2eborrow_2eloopLent(a_0, a_1, a_2, a_3)); heff_drop(v_key_240); heff_drop(v_i_241); heff_drop(v_ds_242); heff_drop(v_t_2421); r_; });
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam1(V self, V *args) {
  V v_a_2433 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_ds_242 = heff_env(self)[2];
  V v_t_2437;
  switch (heff_tag_of(v_a_2433)) {
  case TAG_MkArm: {
    V v_b_2436 = heff_field(v_a_2433, 2);
    heff_take_n(v_a_2433, 4ULL, 3);
    v_t_2437 = v_b_2436;
    break;
  }
  default: heff_nomatch(v_a_2433);
  }
  heff_clo_take(self, 3);
  return ({ V a_0 = v_key_240; V a_1 = v_i_241; V a_2 = v_ds_242; V a_3 = v_t_2437; V r_ = (g_heff_2ecompile_2eborrow_2eloopLent(a_0, a_1, a_2, a_3)); heff_drop(v_key_240); heff_drop(v_i_241); heff_drop(v_ds_242); heff_drop(v_t_2437); r_; });
}
V g_heff_2ecompile_2eborrow_2eloopLent_lam2(V self, V *args) {
  V v_pr_2448 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_ds_242 = heff_env(self)[1];
  V v_t_2451;
  switch (heff_tag_of(v_pr_2448)) {
  case TAG_MkPair: {
    V v_y_2450 = heff_dup(heff_field(v_pr_2448, 1));
    v_t_2451 = v_y_2450;
    break;
  }
  default: heff_nomatch(v_pr_2448);
  }
  if (!heff_intEq_c_lent(v_t_2451, v_i_241, 0)) {
    heff_drop(v_pr_2448);
    heff_drop(self);
    heff_drop(v_t_2451);
    return NTAG(TAG_True);
  } else {
    heff_clo_take(self, 2);
    heff_drop(v_i_241);
    heff_drop(v_t_2451);
    V v_ds_2452 = v_ds_242;
    V v_a_2455;
    switch (heff_tag_of(v_pr_2448)) {
    case TAG_MkPair: {
      V v_x_2453 = heff_field(v_pr_2448, 0);
      heff_take_n(v_pr_2448, 1ULL, 2);
      v_a_2455 = v_x_2453;
      break;
    }
    default: heff_nomatch(v_pr_2448);
    }
    switch (heff_tag_of(v_a_2455)) {
    case TAG_ETag: {
      V v_a2_2457 = heff_dup(heff_field(v_a_2455, 1));
      switch (heff_tag_of(v_a2_2457)) {
      case TAG_Nil: {
        heff_drop(v_ds_2452);
        switch (heff_tag_of(v_a_2455)) {
        case TAG_ETag: {
          heff_take_n(v_a_2455, 0ULL, 3);
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_2455);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_a2_2457, 0ULL, 2);
        return ({ V a_0 = v_a_2455; V a_1 = v_ds_2452; V r_ = (g_list_2eany_24s1021595733x1528955560(a_0, a_1)); heff_drop_tag(v_a_2455, 3); heff_drop(v_ds_2452); r_; });
      }
      default: return heff_nomatch(v_a2_2457);
      }
    }
    case TAG_EInt: {
      V v_n_2464 = heff_field(v_a_2455, 0);
      heff_take_n(v_a_2455, 1ULL, 1);
      heff_drop(v_ds_2452);
      V v_ret_24bool = heff_bool((heff_intLt_c_lent(MK_INT(-1152921504606846976LL), v_n_2464, 1) && heff_intLt_c_lent(v_n_2464, MK_INT(1152921504606846976LL), 2)));
      heff_drop(v_n_2464);
      return v_ret_24bool;
    }
    case TAG_EStr: {
      heff_take_n(v_a_2455, 0ULL, 1);
      heff_drop(v_ds_2452);
      return NTAG(TAG_True);
    }
    default: {
      return ({ V a_0 = v_a_2455; V a_1 = v_ds_2452; V r_ = (g_list_2eany_24s1021595733x1528955560(a_0, a_1)); heff_drop(v_a_2455); heff_drop(v_ds_2452); r_; });
    }
    }
  }
}
V g_heff_2ecompile_2eborrow_2esteps_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2esteps_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2esteps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2esteps_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2esteps(V v_key_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_args_247 = heff_field(v_x2_241, 1);
    V v_p_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2esteps_clo), 1, (V[]){heff_dup(v_key_240)}));
    V v_t_249 = heff_tr(heff_call(heff_dup(v_p_248), 1, (V[]){heff_dup(v_f_246)}));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_p_248);
      heff_drop(v_t_249);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_249);
      return ({ V a_0 = v_p_248; V a_1 = v_args_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_p_248); r_; });
    }
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_x2_241, 1);
    V v_b_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2ecompile_2eborrow_2esteps(v_key_240, v_a_2411));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2413);
      V t_0 = v_key_240;
      V t_1 = v_b_2412;
      v_key_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x2_241, 0);
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2esteps_lam0, 1, 1, (V[]){heff_dup(v_key_240)}); V a_1 = v_fs_2414; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
  }
  case TAG_EProj: {
    V v_e_2420 = heff_field(v_x2_241, 0);
    V t_0 = v_key_240;
    V t_1 = v_e_2420;
    v_key_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2425 = heff_field(v_x2_241, 1);
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2esteps_clo), 1, (V[]){heff_dup(v_key_240)}));
    return ({ V a_0 = v_t_2427; V a_1 = v_args_2425; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2427); r_; });
  }
  case TAG_EMatch: {
    V v_s_2428 = heff_field(v_x2_241, 0);
    V v_arms_2429 = heff_field(v_x2_241, 1);
    V v_t_2430 = (g_heff_2ecompile_2eborrow_2esteps(v_key_240, v_s_2428));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2430);
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2esteps_lam1, 1, 1, (V[]){heff_dup(v_key_240)}); V a_1 = v_arms_2429; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_args_2438 = heff_field(v_x2_241, 1);
    V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2esteps_clo), 1, (V[]){heff_dup(v_key_240)}));
    return ({ V a_0 = v_t_2439; V a_1 = v_args_2438; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2439); r_; });
  }
  case TAG_ECall: {
    V v_g_2440 = heff_field(v_x2_241, 0);
    V v_args_2441 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_g_2440, v_key_240, 0)) {
      return NTAG(TAG_True);
    } else {
      V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2esteps_clo), 1, (V[]){heff_dup(v_key_240)}));
      return ({ V a_0 = v_t_2442; V a_1 = v_args_2441; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2442); r_; });
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_2450 = heff_field(v_x2_241, 0);
    V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2esteps_clo), 1, (V[]){heff_dup(v_key_240)}));
    V v_t_2452 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2450, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_2451; V a_1 = v_t_2452; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2451); heff_drop(v_t_2452); r_; });
  }
  case TAG_ESet: {
    V v_a_2454 = heff_field(v_x2_241, 1);
    V v_b_2455 = heff_field(v_x2_241, 2);
    V v_t_2456 = (g_heff_2ecompile_2eborrow_2esteps(v_key_240, v_a_2454));
    if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
      heff_drop(v_t_2456);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2456);
      V t_0 = v_key_240;
      V t_1 = v_b_2455;
      v_key_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  case TAG_EValues: {
    V v_es_2457 = heff_field(v_x2_241, 0);
    V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eborrow_2esteps_clo), 1, (V[]){heff_dup(v_key_240)}));
    return ({ V a_0 = v_t_2458; V a_1 = v_es_2457; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2458); r_; });
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eborrow_2esteps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2esteps(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eborrow_2esteps_lam0(V self, V *args) {
  V v_f_2416 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_t_2419;
  switch (heff_tag_of(v_f_2416)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_f_2416, 1);
    heff_take_n(v_f_2416, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_f_2416);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_key_240; V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2eborrow_2esteps(a_0, a_1)); heff_drop(v_key_240); heff_drop(v_t_2419); r_; });
}
V g_heff_2ecompile_2eborrow_2esteps_lam1(V self, V *args) {
  V v_a_2431 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_t_2435;
  switch (heff_tag_of(v_a_2431)) {
  case TAG_MkArm: {
    V v_b_2434 = heff_field(v_a_2431, 2);
    heff_take_n(v_a_2431, 4ULL, 3);
    v_t_2435 = v_b_2434;
    break;
  }
  default: heff_nomatch(v_a_2431);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_key_240; V a_1 = v_t_2435; V r_ = (g_heff_2ecompile_2eborrow_2esteps(a_0, a_1)); heff_drop(v_key_240); heff_drop(v_t_2435); r_; });
}
V g_heff_2ecompile_2eborrow_2eborDef_lam0(V self, V *args);
V g_heff_2ecompile_2eborrow_2eborDef_lam1(V self, V *args);
Clo g_heff_2ecompile_2eborrow_2eborDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborDef_entry, 2, 0};

V g_heff_2ecompile_2eborrow_2eborDef(V v_bor_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  V v_t_244 = v_body_242;
  switch (heff_tag_of(v_t_244)) {
  case TAG_EVar: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_t_244, 0);
    V v_b_248 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24ELam = heff_take_reuse_n(v_t_244, 3ULL, 2);
    HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_bor_240, v_key_243));
    {
      V v_field_2411 = v_t_249.f[1];
      V v_tag_2410 = heff_box_i64(((int64_t)v_t_249.f[0]));
      V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
      V v_t_2413 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2412, MK_INT(1LL))));
      V v_t_2414 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_247), v_t_2413));
      V v_t_2418 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam0, 1, 2, (V[]){v_tag_2410, v_field_2411}); V a_1 = v_t_2414; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2419 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24t_244_24ELam, v_t_2418));
      HeffT2 v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_bor_240, v_key_243));
      {
        V v_field_2422 = v_t_2420.f[1];
        V v_tag_2421 = heff_box_i64(((int64_t)v_t_2420.f[0]));
        V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
        V v_t_2424 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2423, MK_INT(1LL))));
        V v_t_2425 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_247), v_t_2424));
        V v_t_2429 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eborrow_2eborDef_lam1, 1, 2, (V[]){v_tag_2421, v_field_2422}); V a_1 = v_t_2425; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2430 = (g_list_2emap_24s1937570095x2110149801(v_t_2429));
        V v_t_2431 = ({ V b_0 = heff_rec_n(3, shape_key__params__body, (V[]){heff_dup(v_key_243), heff_dup(v_xs_247), heff_dup(v_b_248)}); V a_1 = v_t_2430; V a_2 = v_b_248; V r_ = (g_heff_2ecompile_2eborrow_2elentVars(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2431));
        HeffT2 v_t_2433 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_bor_240, v_key_243));
        {
          V v_field_2435 = v_t_2433.f[1];
          int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
          V v_t_2437;
          if ((v_tag_2434 == ((int64_t)0ULL))) {
            V v_x_2436 = v_field_2435;
            v_t_2437 = v_x_2436;
          } else {
            heff_drop(v_field_2435);
            v_t_2437 = NTAG(TAG_Nil);
          }
          V v_t_2438 = ({ V a_0 = v_bor_240; V a_1 = v_key_243; V a_2 = v_xs_247; V a_3 = v_b_248; V a_4 = v_t_2432; V a_5 = v_t_2437; V r_ = (g_list_2ekeepIf_24s498754754x815116558(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_247); heff_drop(v_b_248); heff_drop(v_t_2432); r_; });
          return ({ V a_0 = v_bor_240; V a_1 = v_key_243; V a_2 = v_t_2438; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_243); heff_drop(v_t_2438); r_; });
        }
      }
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_244, 0ULL, 4);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EFloat: {
    heff_take_nf(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EBool: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_ESet: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EValues: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_key_243);
    return v_bor_240;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eborrow_2eborDef(a[0], a[1]);
}
V g_heff_2ecompile_2eborrow_2eborDef_lam0(V self, V *args) {
  V v_p_2415 = args[0];
  V v_tag_2410 = heff_env(self)[0];
  V v_field_2411 = heff_env(self)[1];
  V v_t_2417;
  heff_clo_take(self, 2);
  if ((heff_unbox_i64(v_tag_2410) == ((int64_t)0ULL))) {
    V v_x_2416 = v_field_2411;
    v_t_2417 = v_x_2416;
  } else {
    heff_drop(v_field_2411);
    v_t_2417 = NTAG(TAG_Nil);
  }
  return ({ V a_0 = v_p_2415; V a_1 = v_t_2417; V r_ = (g_list_2eany_24s1760441014x1099436736(a_0, a_1)); heff_drop(v_p_2415); heff_drop(v_t_2417); r_; });
}
V g_heff_2ecompile_2eborrow_2eborDef_lam1(V self, V *args) {
  V v_p_2426 = args[0];
  V v_tag_2421 = heff_env(self)[0];
  V v_field_2422 = heff_env(self)[1];
  V v_t_2428;
  heff_clo_take(self, 2);
  if ((heff_unbox_i64(v_tag_2421) == ((int64_t)0ULL))) {
    V v_x_2427 = v_field_2422;
    v_t_2428 = v_x_2427;
  } else {
    heff_drop(v_field_2422);
    v_t_2428 = NTAG(TAG_Nil);
  }
  return ({ V a_0 = v_p_2426; V a_1 = v_t_2428; V r_ = (g_list_2eany_24s1760441014x1099436736(a_0, a_1)); heff_drop(v_p_2426); heff_drop(v_t_2428); r_; });
}
Clo g_heff_2ecompile_2eborrow_2eborFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eborFix_entry, 3, 0};

V g_heff_2ecompile_2eborrow_2eborFix(V v_defs_240, V v_size_241, V v_bor_242) {
top: ;
  V v_t_243 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_bor_242, NTAG(TAG_Nil)));
  V v_t_244 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_t_243; V r_ = (g_list_2efoldl_24f1922461191x750914054(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
  if (heff_intEq_c(v_t_244, v_size_241)) {
    return v_bor_242;
  } else {
    V v_t_245 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_bor_242, NTAG(TAG_Nil)));
    V v_t_246 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_t_245; V r_ = (g_list_2efoldl_24f1922461191x750914054(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
    V v_t_247 = (g_list_2efoldl_24s1416922510x485352908(v_bor_242, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_246;
    V t_2 = v_t_247;
    v_defs_240 = t_0;
    v_size_241 = t_1;
    v_bor_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eborrow_2eborFix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eborrow_2eborFix(a0, a[1], a[2]); heff_drop(a0); return r;
}