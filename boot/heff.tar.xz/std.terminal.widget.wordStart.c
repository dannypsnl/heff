// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT3 g_list_2edrop_24cpr(V, V);
V g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240(V, V);
V g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240_clo;
Clo g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240(V v_rs_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    HeffT3 v_t_242 = (g_list_2edrop_24cpr(heff_intSub_lent(v_i_241, MK_INT(1LL), 2), v_rs_240));
    {
      V v_field_244 = v_t_242.f[1];
      V v_field_245 = v_t_242.f[2];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      V v_x1_248;
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_244;
        V v_x12_247 = v_field_245;
        heff_drop(v_x12_247);
        v_x1_248 = v_x_246;
      } else {
        heff_drop(v_field_244);
        heff_drop(v_field_245);
        v_x1_248 = MK_INT(32LL);
      }
      if ((heff_runeEq_c(heff_dup(v_x1_248), MK_INT(32LL)) ? 0 : (heff_runeEq_c(heff_dup(v_x1_248), MK_INT(9LL)) ? 0 : (heff_runeEq_c(heff_dup(v_x1_248), MK_INT(10LL)) ? 0 : (heff_runeEq_c(heff_dup(v_x1_248), MK_INT(13LL)) ? 0 : (heff_runeEq_c(heff_dup(v_x1_248), MK_INT(11LL)) ? 0 : !heff_runeEq_c(heff_dup(v_x1_248), MK_INT(12LL)))))))) {
        heff_drop(v_x1_248);
        V t_0 = v_rs_240;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_rs_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_x1_248);
        return v_i_241;
      }
    }
  } else {
    return v_i_241;
  }
}
V g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240(a0, a[1]); heff_drop(a0); return r;
}