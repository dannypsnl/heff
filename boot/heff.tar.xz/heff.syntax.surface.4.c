// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_DeclareField 57313
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_IntValue 62477
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_TypeWord 10401
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_errors 652506774
#define LBL_f 320
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_held 9694204
#define LBL_id 10114
#define LBL_implicits 1321238867
#define LBL_kind 9787483
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_place 308106529
#define LBL_rest 9992347
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_sigs 10025609
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_tokens 1078955205
#define LBL_ty 10476
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_f__names__implicits[] = {LBL_f, LBL_names, LBL_implicits};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_name__span__ty__eqns__whole[] = {LBL_name, LBL_span, LBL_ty, LBL_eqns, LBL_whole};
static uint32_t shape_sigs__held__rest[] = {LBL_sigs, LBL_held, LBL_rest};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok1_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(V, V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo;
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
HeffT3 g_heff_2esyntax_2esurface_2edecimalSplit_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurface_2efirstSig_24cpr(V);
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom(V, V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_clo;
HeffT2 g_heff_2esyntax_2esurface_2efixityFrom_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(V, V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_clo;
V g_heff_2esyntax_2esurface_2egroupFrom(V, V);
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupFrom_clo;
HeffT3 g_heff_2esyntax_2esurface_2egroupFrom_24cpr(V, V);
V g_heff_2esyntax_2esurface_2egroupOfDecl(V, V);
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eknotOf(V, V);
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotOf_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V, V);
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualOut_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo;
V g_heff_2esyntax_2esurface_2epatTags(V, V);
V g_heff_2esyntax_2esurface_2epatTags_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTags_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
HeffT5 g_heff_2esyntax_2esurface_2ereadLexed_24cpr(V, V, V);
HeffT5 g_heff_2esyntax_2esurface_2ereadRun_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2erepeatedField_24cpr(V, V);
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2esetBinders(V, V);
V g_heff_2esyntax_2esurface_2esetBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetBinders_clo;
V g_heff_2esyntax_2esurface_2esetKnot(V, V);
V g_heff_2esyntax_2esurface_2esetKnot_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetKnot_clo;
V g_heff_2esyntax_2esurface_2esetPatVars(V, V);
V g_heff_2esyntax_2esurface_2esetPatVars_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetPatVars_clo;
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
V g_heff_2esyntax_2esurface_2esigBinders(V, V, V);
V g_heff_2esyntax_2esurface_2esigBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigBinders_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryFieldOne_24s1473805472x1314815828_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
HeffT2 g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eunitIn(V, V);
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitIn_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2esyntax_2esurface_2ewhereL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24rec0_get(void);
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1413159824x1120446397(V, V);
V g_list_2efoldl_24s1413159824x1120446397_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1413159824x1120446397_clo;
V g_list_2efoldl_24s415128528x640682339(V, V);
V g_list_2efoldl_24s415128528x640682339_entry(V self, V *a);
extern Clo g_list_2efoldl_24s415128528x640682339_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s2053104128x1598844325(V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2081681776x559624592(V);
V g_list_2emap_24s2081681776x559624592_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = ({ V a_0 = v_xs_243; V a_1 = v_ys_241; V a_2 = v_cell_244; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24dps(a_0, a_1, a_2)); heff_drop(v_ys_241); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_242, 1));
  V v_t_244 = (g_heff_2esyntax_2esurface_2eappendS(v_xs_240, heff_dup(heff_rfield(v_st_242, 1))));
  V v_st_245 = (g_heff_2esyntax_2esurface_2esetScope(v_t_244, v_st_242));
  V v_x1_246 = heff_tr(heff_call(v_p_241, 1, (V[]){v_st_245}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      heff_drop(v_t_243);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x11_247_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_249}), v_st_248}});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_st_2411 = (g_heff_2esyntax_2esurface_2esetScope(v_t_243, v_st_248));
      return ((HeffT2){{heff_tag_re_n(v_ru_24x11_247_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_2410}), v_st_2411}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_246)}});
  }
}
Clo g_heff_2esyntax_2esurface_2ewithScope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewithScope_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ewithScope(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_xs_240, v_p_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewithScope(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2esplitExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esplitExp_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esplitExp(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return heff_strLength_lent(v_s_240, 0);
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)69ULL)))) {
      return heff_box_word(v_i_241);
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esplitExp(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edecimalSplit_24cpr_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2edecimalSplit_24cpr_str1, 1, "+");

HeffT3 g_heff_2esyntax_2esurface_2edecimalSplit_24cpr(V v_negative_240, V v_s_241, V v_eAt_242) {
top: ;
  V v_m_243 = heff_strSlice_lent(v_s_241, MK_INT(0LL), v_eAt_242, 2);
  V v_d_244 = ({ V b_0 = heff_strSlice_lent(v_s_241, MK_INT(0LL), v_eAt_242, 2); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_247;
  if (heff_intLe_c_lent(heff_strLength_lent(v_m_243, 0), v_d_244, 1)) {
    heff_drop(v_d_244);
    v_t_247 = ({ V a_0 = v_m_243; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_m_243); r_; });
  } else {
    V v_t_245 = heff_strSlice_lent(v_m_243, heff_intAdd_lent(v_d_244, MK_INT(1LL), 2), heff_strLength_lent(v_m_243, 0), 6);
    V v_t_246 = heff_strAppend(heff_strSlice(v_m_243, MK_INT(0LL), v_d_244), v_t_245);
    v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_246); r_; });
  }
  V v_t_2412;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_241, 0), v_eAt_242, 1)) {
    v_t_2412 = MK_INT(0LL);
  } else {
    V v_ex_248 = heff_strSlice_lent(v_s_241, heff_intAdd_lent(v_eAt_242, MK_INT(1LL), 2), heff_strLength_lent(v_s_241, 0), 6);
    if (heff_strEq_c(heff_strSlice_lent(v_ex_248, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2edecimalSplit_24cpr_str0))) {
      V v_t_249 = heff_strSlice(heff_dup(v_ex_248), MK_INT(1LL), heff_strLength(v_ex_248));
      V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_249); r_; });
      v_t_2412 = heff_intSub(MK_INT(0LL), v_t_2410);
    } else {
      if (heff_strEq_c(heff_strSlice_lent(v_ex_248, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2edecimalSplit_24cpr_str1))) {
        V v_t_2411 = heff_strSlice(heff_dup(v_ex_248), MK_INT(1LL), heff_strLength(v_ex_248));
        v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_2411); r_; });
      } else {
        v_t_2412 = ({ V a_0 = v_ex_248; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_ex_248); r_; });
      }
    }
  }
  V v_m_2413 = heff_strSlice_lent(v_s_241, MK_INT(0LL), v_eAt_242, 2);
  V v_d_2414 = ({ V b_0 = heff_strSlice_lent(v_s_241, MK_INT(0LL), v_eAt_242, 6); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2416;
  if (heff_intLe_c_lent(heff_strLength_lent(v_m_2413, 0), v_d_2414, 1)) {
    heff_drop(v_m_2413);
    heff_drop(v_d_2414);
    v_t_2416 = MK_INT(0LL);
  } else {
    V v_t_2415 = heff_intSub(heff_strLength(v_m_2413), v_d_2414);
    v_t_2416 = heff_intSub(v_t_2415, MK_INT(1LL));
  }
  V v_f_2417 = heff_intSub(v_t_2412, v_t_2416);
  return ((HeffT3){{v_negative_240, v_t_247, v_f_2417}});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str2, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eboundBy_24dps(V v_pv_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_244 = heff_field(v_x2_241, 1);
    V v_t_246 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}); V a_1 = v_args_244; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_246);
  }
  case TAG_PAtom: {
    V v_t_247 = heff_field(v_x2_241, 0);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str0)) && !heff_strEq_c(heff_dup(heff_rfield(v_t_247, 1)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str1)))) {
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_247, 1)), NTAG(TAG_Nil)});
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_248);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_247, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str2))) {
        V v_t_249 = (g_list_2eany_24s565534491x447967237(v_t_247, v_pv_240));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_247, 1)), NTAG(TAG_Nil)});
          return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2410);
        } else {
          heff_drop(v_t_249);
          return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
        }
      } else {
        return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
      }
    }
  }
  case TAG_PParen: {
    V v_q_2412 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2412;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2415 = heff_field(v_x2_241, 1);
    V v_t_2419 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}); V a_1 = v_ps_2415; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2419);
  }
  case TAG_POp: {
    V v_l_2420 = heff_field(v_x2_241, 0);
    V v_q_2422 = heff_field(v_x2_241, 2);
    V v_t_2423 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2420));
    V v_t_2424 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2422));
    V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2423, v_t_2424));
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2425);
  }
  case TAG_PRec: {
    V v_fs_2427 = heff_field(v_x2_241, 1);
    V v_t_2431 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}); V a_1 = v_fs_2427; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2431);
  }
  case TAG_PField: {
    V v_q_2434 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2434;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2435 = heff_field(v_x2_241, 0);
    V v_q_2437 = heff_field(v_x2_241, 2);
    V v_cell_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2435, 1)), heff_hole()});
    V v_u_2439 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2438);
    V t_0 = v_pv_240;
    V t_1 = v_q_2437;
    V t_2 = v_u_2439;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PSeg: {
    V v_q_2440 = heff_field(v_x2_241, 0);
    V t_0 = v_pv_240;
    V t_1 = v_q_2440;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eboundBy_24dps(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_245; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_245); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args) {
  V v_q_2418 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2418; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2418); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args) {
  V v_q_2430 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2430; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2430); r_; });
}
Clo g_heff_2esyntax_2esurface_2easNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2easNameE(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ENotationVar: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return v_e_240;
    }
    case TAG_ETag: {
      V v_x_248 = heff_field(v_e1_241, 0);
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 1ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_sp_2410 = heff_field(v_e_240, 1);
        V v_ru_24e_240_24At = heff_take_reuse_n(v_e_240, 2ULL, 2);
        return heff_tag_re_n(v_ru_24e_240_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_EVar, 1, (V[]){v_x_248}), v_sp_2410});
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return v_e_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return v_e_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return v_e_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EBreak: {
      return v_e_240;
    }
    case TAG_EContinue: {
      return v_e_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return v_e_240;
    }
    case TAG_EWithBound: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return v_e_240;
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easNameE(a[0]);
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(v_xs_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS(a[0]);
}
Clo g_heff_2esyntax_2esurface_2egroupFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2egroupFrom_entry, 2, 0};

V g_heff_2esyntax_2esurface_2egroupFrom(V v_sp_240, V v_x2_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2esyntax_2esurface_2egroupFrom_24cpr(v_sp_240, v_x2_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    return heff_rec_n(3, shape_sigs__held__rest, (V[]){v_field_243, v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2egroupFrom(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EField: {
    V v_e_242 = heff_field(v_x1_240, 0);
    V v_f_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EField = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_e_242;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24EField, TAG_Cons, 2, (V[]){v_f_243, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  }
}
Clo g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return heff_dup(v_z_242);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_a_246 = (g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(v_lit_240, v_lit_241, v_z_242, v_xs_245));
    V v_t_249;
    switch (heff_tag_of(v_a_246)) {
    case TAG_At: {
      V v_a_248 = heff_dup(heff_field(v_a_246, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_a_246, NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_PatTag, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_2410})});
    V v_t_2412 = ({ V rv_0 = heff_dup(heff_rfield(v_lit_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_t_2412});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str0, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str2, 24, "a field is `name : Type`");
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EFDefault: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_eq_243 = heff_field(v_x2_241, 1);
    V v_d_244 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_242}));
    return heff_tail(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam0, 1, 1, (V[]){v_m_245}), heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam1, 2, 3, (V[]){v_r_240, v_d_244, v_eq_243})});
  }
  default: {
    V v_m_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam2, 1, 1, (V[]){v_m_2426});
  }
  }
}
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_248_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2411));
      V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2412}));
      return (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(v_ru_24x1_247_24MkPair, MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efieldL_str0), v_t_2413, v_st_249));
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args) {
  V v_e_27_2414 = args[0];
  V v_z_2415 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  V v_eq_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_m_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_244}));
  V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_z_2415}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      heff_drop(v_e_27_2414);
      heff_drop_rec(v_eq_243, 9);
      return heff_tag_re_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      V v_x_2425;
      if (heff_strEq_c(heff_get_n(v_eq_243, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldL_str1))) {
        v_x_2425 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_e_27_2414, heff_tag_n(TAG_Just, 1, (V[]){v_x_2421})));
      } else {
        heff_drop(v_x_2421);
        V v_t_2424;
        switch (heff_tag_of(v_e_27_2414)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_e_27_2414, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_e_27_2414);
        }
        v_x_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_27_2414}), v_t_2424});
      }
      return heff_tag_re_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_Right, 1, (V[]){v_x_2425}), v_st_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args) {
  V v_st_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_st_2427}));
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_MkPair: {
    V v_x11_2429 = heff_field(v_x1_2428, 0);
    V v_st_2430 = heff_field(v_x1_2428, 1);
    V v_ru_24x1_2428_24MkPair = heff_take_reuse_n(v_x1_2428, 3ULL, 2);
    switch (heff_tag_of(v_x11_2429)) {
    case TAG_Left: {
      V v_e_2431 = heff_field(v_x11_2429, 0);
      V v_ru_24x11_2429_24Left = heff_take_reuse_n(v_x11_2429, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2429_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2431}), v_st_2430});
    }
    case TAG_Right: {
      V v_x_2432 = heff_field(v_x11_2429, 0);
      V v_ru_24x11_2429_24Right = heff_take_reuse_n(v_x11_2429, 1ULL, 1);
      V v_t_2433 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2432));
      V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2433}));
      HeffT2 v_t_2435 = (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efieldL_str2), v_t_2434, v_st_2430));
      {
        V v_field_2436 = v_t_2435.f[0];
        V v_field_2437 = v_t_2435.f[1];
        V v_x11_2438 = v_field_2436;
        V v_st_2439 = v_field_2437;
        switch (heff_tag_of(v_x11_2438)) {
        case TAG_Left: {
          V v_e_2440 = heff_field(v_x11_2438, 0);
          V v_ru_24x11_2438_24Left = heff_take_reuse_n(v_x11_2438, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_2429_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2438_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2440}), v_st_2439});
        }
        case TAG_Right: {
          V v_x_2441 = heff_field(v_x11_2438, 0);
          heff_take_n(v_x11_2438, 1ULL, 1);
          V v_x_2442 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2441, NTAG(TAG_Nothing)));
          return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2429_24Right, TAG_Right, 1, (V[]){v_x_2442}), v_st_2439});
        }
        default: return heff_nomatch(v_x11_2438);
        }
      }
    }
    default: return heff_nomatch(v_x11_2429);
    }
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esettingL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esettingL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esettingL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EFSet: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_e_244 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_text_245 = heff_take_field(v_x_242, 1);
    V v_start_246 = heff_take_field(v_x_242, 3);
    V v_end_247 = heff_get_n(v_x_242, 4, 9);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_244}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam0, 1, 4, (V[]){v_m_248, v_text_245, v_start_246, v_end_247});
  }
  default: {
    V v_m_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam1, 1, 1, (V[]){v_m_2421});
  }
  }
}
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esettingL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_text_245 = heff_env(self)[1];
  V v_start_246 = heff_env(self)[2];
  V v_end_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_text_245);
      heff_drop(v_start_246);
      heff_drop(v_end_247);
      return heff_tag_re_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2411_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2418 = heff_tag_n(TAG_SetField, 3, (V[]){v_text_245, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_246), v_end_247}), v_x_2414});
      V v_t_2419 = ({ V rv_0 = v_start_246; V rr_ = heff_rec_reuse_nf(v_t_2417, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2420 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2419})});
      return heff_tag_re_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2420, v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args) {
  V v_st_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_st_2422}));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_MkPair: {
    V v_x11_2424 = heff_field(v_x1_2423, 0);
    V v_st_2425 = heff_field(v_x1_2423, 1);
    V v_ru_24x1_2423_24MkPair = heff_take_reuse_n(v_x1_2423, 3ULL, 2);
    switch (heff_tag_of(v_x11_2424)) {
    case TAG_Left: {
      V v_e_2426 = heff_field(v_x11_2424, 0);
      V v_ru_24x11_2424_24Left = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2424_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2426}), v_st_2425});
    }
    case TAG_Right: {
      V v_x_2427 = heff_field(v_x11_2424, 0);
      V v_ru_24x11_2424_24Right = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
      V v_t_2430;
      switch (heff_tag_of(v_x_2427)) {
      case TAG_At: {
        V v_s_2429 = heff_dup(heff_field(v_x_2427, 1));
        v_t_2430 = v_s_2429;
        break;
      }
      default: heff_nomatch(v_x_2427);
      }
      V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_2427}), v_t_2430});
      return heff_tag_re_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2424_24Right, TAG_Right, 1, (V[]){v_t_2431}), v_st_2425});
    }
    default: return heff_nomatch(v_x11_2424);
    }
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str1, 33, "` is named twice in one signature");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str3, 33, "` is named twice in one signature");

HeffT2 g_heff_2esyntax_2esurface_2erepeatedField_24cpr(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Left: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_245 = (g_list_2eany_24s565534491x447967237(v_x_244, v_seen_240));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_seen_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_245);
        V v_t_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str0), heff_take_field(v_x_244, 1));
        V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
        V v_f_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_246, ((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str1)), v_t_247, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
      } else {
        heff_drop(v_t_245);
        V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_244, 1, 9), v_seen_240});
        V t_0 = v_t_249;
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_Right: {
      V v_x211_2410 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      switch (heff_tag_of(v_x211_2410)) {
      case TAG_At: {
        V v_x2111_2411 = heff_field(v_x211_2410, 0);
        heff_take_n(v_x211_2410, 1ULL, 2);
        switch (heff_tag_of(v_x2111_2411)) {
        case TAG_DeclareField: {
          V v_f_2413 = heff_field(v_x2111_2411, 0);
          V v_fsp_2414 = heff_field(v_x2111_2411, 1);
          heff_take_n(v_x2111_2411, 3ULL, 4);
          V v_t_2417 = ({ V a_0 = v_f_2413; V a_1 = v_seen_240; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_seen_240); r_; });
          if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
            heff_drop(v_rest_243);
            heff_drop(v_t_2417);
            V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str2), v_f_2413), ((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str3));
            V v_f_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2418, v_fsp_2414, NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
          } else {
            heff_drop(v_f_2413);
            heff_drop(v_fsp_2414);
            heff_drop(v_t_2417);
            V t_0 = NTAG(TAG_Nil);
            V t_1 = v_rest_243;
            v_seen_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        case TAG_BadFieldDecl: {
          heff_take_n(v_x2111_2411, 0ULL, 1);
          heff_drop(v_seen_240);
          V t_0 = NTAG(TAG_Nil);
          V t_1 = v_rest_243;
          v_seen_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x2111_2411)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2epatTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatTags_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epatTags(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(v_acc_241);
    }
    case TAG_PatTag: {
      V v_tsp_246 = heff_field(v_x11_242, 1);
      V v_ps_247 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 6ULL, 3);
      V v_t_248 = ({ V a_0 = heff_dup(v_acc_241); V a_1 = v_ps_247; V r_ = (g_list_2efoldl_24s1413159824x1120446397(a_0, a_1)); heff_drop(v_ps_247); r_; });
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_tsp_246, v_t_248});
    }
    case TAG_PatOp: {
      V v_xsp_2410 = heff_field(v_x11_242, 1);
      V v_ps_2411 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 6ULL, 3);
      V v_t_2412 = ({ V a_0 = heff_dup(v_acc_241); V a_1 = v_ps_2411; V r_ = (g_list_2efoldl_24s1413159824x1120446397(a_0, a_1)); heff_drop(v_ps_2411); r_; });
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_xsp_2410, v_t_2412});
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(v_acc_241);
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(v_acc_241);
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(v_acc_241);
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(v_acc_241);
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(v_acc_241);
    }
    case TAG_PatRecord: {
      V v_fs_2418 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return ({ V a_0 = heff_dup(v_acc_241); V a_1 = v_fs_2418; V r_ = (g_list_2efoldl_24s415128528x640682339(a_0, a_1)); heff_drop(v_fs_2418); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return heff_dup(v_acc_241);
    }
    case TAG_PatAs: {
      V v_p_2422 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V t_0 = v_p_2422;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epatTags_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatTags(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str0, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str1, 1, "`");
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ealtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ealtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ealtL(V v_r_240, V v_x2_241) {
top: ;
  V v_pat_242 = heff_take_field(v_r_240, 1);
  V v_e_243 = heff_get_n(v_r_240, 0, 3);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EAlt: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_e_246 = heff_field(v_x2_241, 2);
    V v_m_247 = heff_tr(heff_call(v_pat_242, 1, (V[]){heff_dup(v_p_244)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam0, 1, 4, (V[]){v_m_247, heff_dup(v_p_244), v_e_243, heff_dup(v_e_246)});
  }
  default: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2430 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2431 = heff_take_field(v_t_2430, 3);
    V v_end_2432 = heff_get_n(v_t_2430, 4, 9);
    V v_t_2433 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str0), heff_get_n(v_t_2433, 1, 9));
    V v_msg_2435 = heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2esurface_2ealtL_str1));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam2, 1, 3, (V[]){v_msg_2435, v_start_2431, v_end_2432});
  }
  }
}
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2ealtL(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args) {
  V v_st_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_st_2416}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      heff_drop(v_x_2413);
      return heff_tag_re_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      V v_t_2424;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_x_2413, 1));
        v_t_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_2421)) {
      case TAG_At: {
        V v_s_2426 = heff_dup(heff_field(v_x_2421, 1));
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_x_2421);
      }
      V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_2413, v_x_2421}), v_t_2428});
      return heff_tag_re_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_Right, 1, (V[]){v_t_2429}), v_st_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_e_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_p_244);
      heff_drop(v_e_243);
      heff_drop(v_e_246);
      return heff_tag_re_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2410_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_p_244; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_p_244); r_; });
      V v_m_2415 = heff_tr(heff_call(v_e_243, 1, (V[]){v_e_246}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24tok2(v_ru_24x1_249_24MkPair, v_t_2414, heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam1, 1, 2, (V[]){v_m_2415, v_x_2413}), v_st_2411));
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args) {
  V v_st_2436 = args[0];
  V v_msg_2435 = heff_env(self)[0];
  V v_start_2431 = heff_env(self)[1];
  V v_end_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2435, heff_rec_n(2, shape_start__end, (V[]){v_start_2431, v_end_2432}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2437}), v_st_2436});
}
Clo g_heff_2esyntax_2esurface_2eunitIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitIn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eunitIn(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_ty_240)) {
    case TAG_SegmentInteger: {
      return MK_INT(1LL);
    }
    case TAG_SegmentBinary: {
      return MK_INT(8LL);
    }
    case TAG_SegmentBits: {
      return MK_INT(1LL);
    }
    case TAG_SegmentFloat: {
      return MK_INT(1LL);
    }
    case TAG_SegmentUtf: {
      return MK_INT(1LL);
    }
    default: return heff_nomatch(v_ty_240);
    }
  }
  case TAG_Just: {
    V v_u_243 = heff_field(v_x2_241, 0);
    return heff_dup(v_u_243);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eunitIn(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2evalueOfE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evalueOfE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evalueOfE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENotationVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETag: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInt: {
      V v_v_249 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_IntValue, 1, (V[]){heff_dup(v_v_249)});
    }
    case TAG_EFloat: {
      return NTAG(TAG_FloatValue);
    }
    case TAG_EString: {
      return NTAG(TAG_StrValue);
    }
    case TAG_EBinary: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ERune: {
      return NTAG(TAG_RuneValue);
    }
    case TAG_EWord: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EApp: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EProject: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENamed: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EPi: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELam: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAnn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESpec: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESig: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESum: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EStruct: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EMatch: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EDo: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELocal: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAssign: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWhile: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EFor: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EBreak: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EContinue: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EReturn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENest: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELazy: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETuple: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETry: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWith: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWithBound: {
      return NTAG(TAG_OtherValue);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2evalueOfE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str0, 45, "an integer's segment is of 1 to 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str2, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str3, 17, " does not fit in ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str4, 5, " bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str5, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str6, 43, "a float's segment is of 32 or 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str7, 51, "a float's size is a number, 32 or 64: `x::float-32`");

HeffT2 g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr(V v_inPat_240, V v_sp_241, V v_v_242, V v_x5_243, V v_x6_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SegmentInteger: {
    V v_inPat_246 = v_inPat_240;
    V v_sp_247 = v_sp_241;
    V v_v_248 = v_v_242;
    V v_x5_2413;
    switch (heff_tag_of(v_x6_244)) {
    case TAG_SizeDefault: {
      v_x5_2413 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_SizeNumber: {
      V v_n_249 = heff_field(v_x6_244, 0);
      V v_ru_24x6_244_24SizeNumber = heff_take_reuse_n(v_x6_244, 1ULL, 1);
      v_x5_2413 = heff_tag_at_n(v_ru_24x6_244_24SizeNumber, TAG_Just, 1, (V[]){v_n_249});
      break;
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_244, 0ULL, 3);
      v_x5_2413 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x6_244);
    }
    switch (heff_tag_of(v_x5_2413)) {
    case TAG_Nothing: {
      heff_drop(v_inPat_246);
      heff_drop(v_sp_247);
      heff_drop(v_v_248);
      V v_t_2414 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2414, v_z_245}});
    }
    case TAG_Just: {
      V v_n_2415 = heff_field(v_x5_2413, 0);
      V v_ru_24x5_2413_24Just = heff_take_reuse_n(v_x5_2413, 1ULL, 1);
      if ((heff_intLt_c_lent(v_n_2415, MK_INT(1LL), 2) || heff_intLt_c_lent(MK_INT(64LL), v_n_2415, 1))) {
        heff_drop(v_inPat_246);
        heff_drop(v_v_248);
        V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str0), heff_intShow(v_n_2415));
        V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2416, v_sp_247, NTAG(TAG_Nothing)});
        V v_f_2418 = heff_tag_at_n(v_ru_24x5_2413_24Just, TAG_Left, 1, (V[]){v_t_2417});
        return ((HeffT2){{v_f_2418, v_z_245}});
      } else {
        V v_inPat_2419 = v_inPat_246;
        V v_sp_2420 = v_sp_247;
        V v_x3_2421 = v_v_248;
        V v_n_2422 = v_n_2415;
        switch (heff_tag_of(v_x3_2421)) {
        case TAG_StrValue: {
          heff_drop(v_inPat_2419);
          heff_drop(v_sp_2420);
          heff_drop(v_n_2422);
          V v_t_2423 = heff_tag_at_n(v_ru_24x5_2413_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2423, v_z_245}});
        }
        case TAG_IntValue: {
          V v_v_2424 = heff_field(v_x3_2421, 0);
          heff_take_n(v_x3_2421, 1ULL, 1);
          if (((heff_dup(v_inPat_2419) == NTAG(TAG_True)) ? (heff_intLe_c_lent(MK_INT(0LL), v_v_2424, 1) && ({ V v_t_2453 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_2422))); int c_ = heff_intLt_c_lent(v_v_2424, v_t_2453, 0); heff_drop(v_t_2453); c_; })) : ({ V v_t_2425 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_2422) - ((int64_t)1ULL))))); int c_ = ({ V v_t_2454 = heff_intSub_lent(MK_INT(0LL), v_t_2425, 1); int c_ = (heff_intLe_c_lent(v_t_2454, v_v_2424, 0) && ({ V v_t_2455 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_2422))); int c_ = heff_intLt_c_lent(v_v_2424, v_t_2455, 0); heff_drop(v_t_2455); c_; })); heff_drop(v_t_2454); c_; }); heff_drop(v_t_2425); c_; }))) {
            heff_drop(v_inPat_2419);
            heff_drop(v_sp_2420);
            heff_drop(v_n_2422);
            heff_drop(v_v_2424);
            V v_t_2426 = heff_tag_at_n(v_ru_24x5_2413_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
            return ((HeffT2){{v_t_2426, v_z_245}});
          } else {
            V v_t_2427;
            if (!(heff_dup(v_inPat_2419) == NTAG(TAG_True))) {
              heff_drop(v_inPat_2419);
              v_t_2427 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str1);
            } else {
              heff_drop(v_inPat_2419);
              v_t_2427 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str2);
            }
            V v_t_2428 = heff_strAppend(heff_intShow(v_v_2424), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str3));
            V v_t_2429 = heff_strAppend(v_t_2428, heff_intShow(v_n_2422));
            V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str4)), v_t_2427);
            V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2430, v_sp_2420, NTAG(TAG_Nothing)});
            V v_f_2432 = heff_tag_at_n(v_ru_24x5_2413_24Just, TAG_Left, 1, (V[]){v_t_2431});
            return ((HeffT2){{v_f_2432, v_z_245}});
          }
        }
        case TAG_FloatValue: {
          heff_drop(v_inPat_2419);
          heff_drop(v_sp_2420);
          heff_drop(v_n_2422);
          V v_t_2433 = heff_tag_at_n(v_ru_24x5_2413_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2433, v_z_245}});
        }
        case TAG_RuneValue: {
          heff_drop(v_inPat_2419);
          heff_drop(v_sp_2420);
          heff_drop(v_n_2422);
          V v_t_2434 = heff_tag_at_n(v_ru_24x5_2413_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2434, v_z_245}});
        }
        case TAG_OtherValue: {
          heff_drop(v_inPat_2419);
          heff_drop(v_sp_2420);
          heff_drop(v_n_2422);
          V v_t_2435 = heff_tag_at_n(v_ru_24x5_2413_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2435, v_z_245}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2421)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_2413)}});
    }
  }
  case TAG_SegmentBinary: {
    heff_drop(v_inPat_240);
    heff_drop(v_x6_244);
    switch (heff_tag_of(v_v_242)) {
    case TAG_StrValue: {
      heff_drop(v_sp_241);
      V v_t_2436 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2436, v_z_245}});
    }
    default: {
      heff_drop(v_v_242);
      if (!((((int64_t)8ULL) % ((int64_t)8ULL)) == ((int64_t)0ULL))) {
        V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str5), v_sp_241, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2437}), v_z_245}});
      } else {
        heff_drop(v_sp_241);
        V v_t_2438 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        return ((HeffT2){{v_t_2438, v_z_245}});
      }
    }
    }
  }
  case TAG_SegmentBits: {
    heff_drop(v_inPat_240);
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_x6_244);
    V v_t_2439 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return ((HeffT2){{v_t_2439, v_z_245}});
  }
  case TAG_SegmentFloat: {
    heff_drop(v_inPat_240);
    heff_drop(v_v_242);
    switch (heff_tag_of(v_x6_244)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      V v_t_2440 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2440, v_z_245}});
    }
    case TAG_SizeNumber: {
      V v_x61_2441 = heff_field(v_x6_244, 0);
      V v_ru_24x6_244_24SizeNumber = heff_take_reuse_n(v_x6_244, 1ULL, 1);
      if (heff_intEq_c_lent(v_x61_2441, MK_INT(64LL), 2)) {
        heff_drop(v_sp_241);
        heff_drop(v_x61_2441);
        V v_t_2442 = heff_tag_at_n(v_ru_24x6_244_24SizeNumber, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        return ((HeffT2){{v_t_2442, v_z_245}});
      } else {
        if (heff_intEq_c_lent(v_x61_2441, MK_INT(32LL), 2)) {
          heff_drop(v_sp_241);
          heff_drop(v_x61_2441);
          V v_t_2443 = heff_tag_at_n(v_ru_24x6_244_24SizeNumber, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2443, v_z_245}});
        } else {
          V v_t_2444 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str6), heff_intShow(v_x61_2441));
          V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2444, v_sp_241, NTAG(TAG_Nothing)});
          V v_f_2446 = heff_tag_at_n(v_ru_24x6_244_24SizeNumber, TAG_Left, 1, (V[]){v_t_2445});
          return ((HeffT2){{v_f_2446, v_z_245}});
        }
      }
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_244, 0ULL, 3);
      V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr_str7), v_sp_241, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2450}), v_z_245}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x6_244)}});
    }
  }
  case TAG_SegmentUtf: {
    V v_ru_24x5_243_24SegmentUtf = heff_take_reuse_n(v_x5_243, 0ULL, 1);
    heff_drop(v_inPat_240);
    heff_drop(v_sp_241);
    heff_drop(v_v_242);
    heff_drop(v_x6_244);
    V v_t_2452 = heff_tag_at_n(v_ru_24x5_243_24SegmentUtf, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return ((HeffT2){{v_t_2452, v_z_245}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x5_243)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str0, 77, "a segment of a binary pattern holds a name, `_`, a number, a string or a rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str1, 101, "only the last segment takes what is left: say this one's size, `x::binary-size(n)`, `x::bits-size(n)`");
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V v_r_240, V v_last_241, V v_sp_242, V v_p_243) {
top: ;
  V v_x2_244 = (g_heff_2esyntax_2esurface_2esegmentValue(v_p_243));
  return heff_tail(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0, 1, 2, (V[]){v_x2_244, heff_dup(v_sp_242)}), heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1, 2, 4, (V[]){v_r_240, v_p_243, v_sp_242, heff_dup(v_last_241)})});
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_x2_244 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  if ((heff_dup(v_x2_244) == NTAG(TAG_True))) {
    heff_drop(self);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_p_245});
  } else {
    heff_clo_take(self, 2);
    heff_drop(v_x2_244);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str0), v_sp_242, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_247}), v_p_245});
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_z_249 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_last_241 = heff_env(self)[3];
  heff_drop(v_u_248);
  heff_clo_take(self, 4);
  V v_m_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_243}));
  V v_x1_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_249}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_last_241);
      return heff_tag_re_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2412_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_inPat_2416 = NTAG(TAG_True);
      V v_sp_2417 = heff_dup(v_sp_242);
      V v_e_2418 = heff_dup(v_x_2415);
      V v_v_2438;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_x11_2419 = heff_field(v_x_2415, 0);
        heff_take_n(v_x_2415, 1ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_PatVar: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2419, 0ULL, 3);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2419, 0ULL, 3);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatInt: {
          V v_v_2428 = heff_field(v_x11_2419, 0);
          V v_ru_24x11_2419_24PatInt = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
          v_v_2438 = heff_tag_at_n(v_ru_24x11_2419_24PatInt, TAG_IntValue, 1, (V[]){v_v_2428});
          break;
        }
        case TAG_PatFloat: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_FloatValue);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_StrValue);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_RuneValue);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2419, 0ULL, 3);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        default: heff_nomatch(v_x11_2419);
        }
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      V v_st_2439 = v_st_2413;
      V v_t_2441;
      switch (heff_tag_of(v_v_2438)) {
      case TAG_StrValue: {
        v_t_2441 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2441 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2441 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2441 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2441 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_2438);
      }
      HeffT2 v_t_2442 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_2417), heff_dup(v_v_2438), v_t_2441, v_st_2439));
      {
        V v_field_2443 = v_t_2442.f[0];
        V v_field_2444 = v_t_2442.f[1];
        V v_x11_2445 = v_field_2443;
        V v_st_2446 = v_field_2444;
        V v_x1_2462;
        switch (heff_tag_of(v_x11_2445)) {
        case TAG_Left: {
          V v_e_2447 = heff_field(v_x11_2445, 0);
          V v_ru_24x11_2445_24Left = heff_take_reuse_n(v_x11_2445, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          heff_drop(v_sp_2417);
          heff_drop(v_e_2418);
          heff_drop(v_v_2438);
          v_x1_2462 = heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2445_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2447}), v_st_2446});
          break;
        }
        case TAG_Right: {
          V v_ru_24x11_2445_24Right = heff_take_reuse_n(v_x11_2445, 0ULL, 1);
          V v_t_2450;
          switch (heff_tag_of(v_v_2438)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2445_24Right, 1);
            v_t_2450 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_drop_cell(v_ru_24x11_2445_24Right, 1);
            v_t_2450 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2445_24Right, 1);
            v_t_2450 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2450 = heff_tag_at_n(v_ru_24x11_2445_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2445_24Right, 1);
            v_t_2450 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_2438);
          }
          HeffT2 v_t_2451 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr(v_inPat_2416, heff_dup(v_sp_2417), heff_dup(v_v_2438), v_t_2450, NTAG(TAG_SizeDefault), v_st_2446));
          {
            V v_field_2452 = v_t_2451.f[0];
            V v_field_2453 = v_t_2451.f[1];
            V v_x11_2454 = v_field_2452;
            V v_st_2455 = v_field_2453;
            switch (heff_tag_of(v_x11_2454)) {
            case TAG_Left: {
              V v_e_2456 = heff_field(v_x11_2454, 0);
              V v_ru_24x11_2454_24Left = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
              heff_drop_cell(v_ru_24x11_2412_24Right, 1);
              heff_drop(v_sp_2417);
              heff_drop(v_e_2418);
              heff_drop(v_v_2438);
              v_x1_2462 = heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2454_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2456}), v_st_2455});
              break;
            }
            case TAG_Right: {
              V v_ru_24x11_2454_24Right = heff_take_reuse_n(v_x11_2454, 0ULL, 1);
              V v_t_2459;
              switch (heff_tag_of(v_v_2438)) {
              case TAG_StrValue: {
                heff_drop_cell(v_ru_24x11_2454_24Right, 1);
                v_t_2459 = NTAG(TAG_SegmentBinary);
                break;
              }
              case TAG_IntValue: {
                heff_take_n(v_v_2438, 0ULL, 1);
                heff_drop_cell(v_ru_24x11_2454_24Right, 1);
                v_t_2459 = NTAG(TAG_SegmentInteger);
                break;
              }
              case TAG_FloatValue: {
                heff_drop_cell(v_ru_24x11_2454_24Right, 1);
                v_t_2459 = NTAG(TAG_SegmentFloat);
                break;
              }
              case TAG_RuneValue: {
                v_t_2459 = heff_tag_at_n(v_ru_24x11_2454_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                break;
              }
              case TAG_OtherValue: {
                heff_drop_cell(v_ru_24x11_2454_24Right, 1);
                v_t_2459 = NTAG(TAG_SegmentInteger);
                break;
              }
              default: heff_nomatch(v_v_2438);
              }
              V v_t_2460 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_2418, v_t_2459, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
              V v_t_2461 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2460, v_sp_2417})});
              v_x1_2462 = heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2461, v_st_2455});
              break;
            }
            default: heff_nomatch(v_x11_2454);
            }
          }
          break;
        }
        default: heff_nomatch(v_x11_2445);
        }
        switch (heff_tag_of(v_x1_2462)) {
        case TAG_MkPair: {
          V v_x11_2463 = heff_field(v_x1_2462, 0);
          V v_st_2464 = heff_field(v_x1_2462, 1);
          V v_ru_24x1_2462_24MkPair = heff_take_reuse_n(v_x1_2462, 3ULL, 2);
          switch (heff_tag_of(v_x11_2463)) {
          case TAG_Left: {
            V v_e_2465 = heff_field(v_x11_2463, 0);
            V v_ru_24x11_2463_24Left = heff_take_reuse_n(v_x11_2463, 1ULL, 1);
            heff_drop(v_sp_242);
            heff_drop(v_last_241);
            return heff_tag_re_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2463_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2465}), v_st_2464});
          }
          case TAG_Right: {
            V v_x_2466 = heff_field(v_x11_2463, 0);
            V v_ru_24x11_2463_24Right = heff_take_reuse_n(v_x11_2463, 1ULL, 1);
            if (!(heff_dup(v_last_241) == NTAG(TAG_True))) {
              heff_drop(v_last_241);
              V v_t_2469;
              switch (heff_tag_of(v_x_2466)) {
              case TAG_At: {
                V v_x_2467 = heff_dup(heff_field(v_x_2466, 0));
                v_t_2469 = v_x_2467;
                break;
              }
              default: heff_nomatch(v_x_2466);
              }
              V v_t_2470 = ({ V a_0 = v_t_2469; V r_ = (g_heff_2esyntax_2esurface_2etakesRest(a_0)); heff_drop(v_t_2469); r_; });
              if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
                heff_drop(v_x_2466);
                heff_drop_cell(v_ru_24x11_2463_24Right, 1);
                heff_drop(v_t_2470);
                V v_t_2471 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str1), v_sp_242, NTAG(TAG_Nothing)});
                return heff_tag_re_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2471}), v_st_2464});
              } else {
                heff_drop(v_sp_242);
                heff_drop(v_t_2470);
                return heff_tag_re_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2463_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_2466}), v_st_2464});
              }
            } else {
              heff_drop(v_sp_242);
              heff_drop(v_last_241);
              return heff_tag_re_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2463_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_2466}), v_st_2464});
            }
          }
          default: return heff_nomatch(v_x11_2463);
          }
        }
        default: return heff_nomatch(v_x1_2462);
        }
      }
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
Clo g_heff_2esyntax_2esurface_2esigBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esigBinders_entry, 3, 0};

V g_heff_2esyntax_2esurface_2esigBinders(V v_ty_240, V v_s_241, V v_n_242) {
top: ;
  V v_names_243 = (g_heff_2esyntax_2esurface_2epiBinders(heff_dup(v_ty_240)));
  V v_implicits_244 = (g_heff_2esyntax_2esurface_2epiImplicits(v_ty_240));
  V v_b_245 = heff_rec_n(3, shape_f__names__implicits, (V[]){heff_get_n(v_n_242, 0, 2), v_names_243, v_implicits_244});
  HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_s_241, 3), heff_rfield(v_b_245, 0)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_t_2410;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_248);
      v_t_2410 = NTAG(TAG_Nil);
    }
    V v_t_2411 = ({ V a_0 = heff_dup(heff_rfield(v_s_241, 3)); V b_1 = heff_dup(heff_rfield(v_b_245, 0)); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_245, v_t_2410}); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, b_1, b_2)); heff_drop(b_1); heff_drop(b_2); r_; });
    return (g_heff_2esyntax_2esurface_2esetBinders(v_t_2411, v_s_241));
  }
}
V g_heff_2esyntax_2esurface_2esigBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esigBinders(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_x_241, 2)), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V v_r_240, V v_names_241, V v_pats_242, V v_rhs_243, V v_w_244, V v_st_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_names_241));
  {
    V v_field_247 = v_t_246.f[0];
    heff_drop(v_t_246.f[1]);
    V v_f_249 = v_field_247;
    HeffT2 v_t_2410 = ({ V a_0 = heff_rfield(v_st_245, 3); V a_1 = v_f_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_249); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      V v_t_2414;
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2412;
        v_t_2414 = v_x_2413;
      } else {
        heff_drop(v_field_2412);
        v_t_2414 = NTAG(TAG_Nil);
      }
      V v_t_2415 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2414));
      V v_st_2416 = (g_heff_2esyntax_2esurface_2esetPatVars(v_t_2415, v_st_245));
      V v_t_2417 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(v_r_240, 1)), heff_dup(v_pats_242)));
      V v_x1_2418 = heff_tr(heff_call(v_t_2417, 1, (V[]){v_st_2416}));
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          V v_ru_24x11_2419_24Left = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop(v_pats_242);
          heff_drop(v_rhs_243);
          heff_drop(v_t_2414);
          heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2421}), v_st_2420}});
        }
        case TAG_Right: {
          V v_x_2422 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          V v_st_2423 = (g_heff_2esyntax_2esurface_2esetPatVars(NTAG(TAG_Nil), v_st_2420));
          V v_t_2424 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2414));
          V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2424}));
          V v_t_2426 = ({ V a_0 = v_t_2425; V a_1 = v_pats_242; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_t_2425); heff_drop(v_pats_242); r_; });
          V v_t_2427 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_t_2414); r_; });
          V v_t_2428 = (g_heff_2esyntax_2esurface_2eappendS_24tok2(v_ru_24x1_2418_24MkPair, v_t_2426, v_t_2427));
          V v_m_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_243}));
          return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2428, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0, 1, 5, (V[]){v_m_2429, heff_dup(v_w_244), v_r_240, heff_dup(v_names_241), v_x_2422}), v_st_2423));
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2419)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2418)}});
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1(V self, V *args) {
  V v_st_2436 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2435}), v_st_2436});
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2(V self, V *args) {
  V v_rhs_27_2441 = args[0];
  V v_z_2442 = args[1];
  V v_names_241 = heff_env(self)[0];
  V v_x_2422 = heff_env(self)[1];
  HeffT2 v_t_2443 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_names_241));
  {
    V v_field_2444 = v_t_2443.f[0];
    heff_drop(v_t_2443.f[1]);
    HeffT2 v_t_2446 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_names_241));
    {
      V v_field_2447 = v_t_2446.f[0];
      heff_drop(v_t_2446.f[1]);
      HeffT2 v_t_2449 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_names_241));
      {
        V v_field_2451 = v_t_2449.f[1];
        heff_drop(v_t_2449.f[0]);
        V v_t_2454;
        heff_clo_take(self, 2);
        switch (heff_tag_of(v_names_241)) {
        case TAG_Nil: {
          v_t_2454 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          V v_t_2452 = heff_dup(heff_field(v_names_241, 0));
          v_t_2454 = heff_get_n(v_t_2452, 3, 9);
          break;
        }
        default: heff_nomatch(v_names_241);
        }
        V v_t_2457;
        switch (heff_tag_of(v_rhs_27_2441)) {
        case TAG_At: {
          V v_s_2456 = heff_dup(heff_field(v_rhs_27_2441, 1));
          v_t_2457 = v_s_2456;
          break;
        }
        default: heff_nomatch(v_rhs_27_2441);
        }
        V v_t_2460;
        switch (heff_tag_of(v_names_241)) {
        case TAG_Nil: {
          v_t_2460 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          V v_t_2458 = heff_field(v_names_241, 0);
          heff_take_n(v_names_241, 1ULL, 2);
          v_t_2460 = heff_get_n(v_t_2458, 3, 9);
          break;
        }
        default: heff_nomatch(v_names_241);
        }
        V v_t_2463;
        switch (heff_tag_of(v_rhs_27_2441)) {
        case TAG_At: {
          V v_s_2462 = heff_dup(heff_field(v_rhs_27_2441, 1));
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_rhs_27_2441);
        }
        V v_t_2464 = ({ V rv_0 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_t_2457, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_field_2447, v_field_2451, v_x_2422, v_rhs_27_2441}), v_t_2464});
        V v_t_2466 = ({ V rv_0 = v_t_2460; V rr_ = heff_rec_reuse_nf(v_t_2463, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_x_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Eqn, 3, (V[]){v_field_2444, v_t_2465, v_t_2466}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2467}), v_z_2442});
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0(V self, V *args) {
  V v_st_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_w_244 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_names_241 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_st_2430}));
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_MkPair: {
    V v_x11_2432 = heff_field(v_x1_2431, 0);
    V v_st_2433 = heff_field(v_x1_2431, 1);
    V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_Left: {
      V v_e_2434 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Left = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      heff_drop(v_w_244);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_names_241);
      heff_drop(v_x_2422);
      return heff_tag_re_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2432_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2434}), v_st_2433});
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_x11_2432, 0);
      heff_take_n(v_x11_2432, 1ULL, 1);
      V v_t_2440;
      switch (heff_tag_of(v_w_244)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 3);
        v_t_2440 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1, 1, 1, (V[]){v_x_2435});
        break;
      }
      case TAG_Just: {
        V v_it1_2437 = heff_field(v_w_244, 0);
        heff_take_n(v_w_244, 1ULL, 1);
        switch (heff_tag_of(v_it1_2437)) {
        case TAG_MkPair: {
          V v_kw_2438 = heff_field(v_it1_2437, 0);
          V v_ds_2439 = heff_field(v_it1_2437, 1);
          heff_take_n(v_it1_2437, 3ULL, 2);
          v_t_2440 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_clo), 4, (V[]){v_r_240, v_kw_2438, v_ds_2439, v_x_2435}));
          break;
        }
        default: heff_nomatch(v_it1_2437);
        }
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_2431_24MkPair, v_t_2440, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2, 2, 2, (V[]){v_names_241, v_x_2422}), v_st_2433));
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eparamOf(V v_p_240, V v_z_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(v_p_240));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_q_245 = v_field_244;
      V v_ty_246 = heff_take_field(v_q_245, 2);
      V v_name_247 = heff_take_field(v_q_245, 0);
      V v_span_248 = heff_get_n(v_q_245, 1, 3);
      V v_t_249 = heff_dup(v_ty_246);
      V v_t_2412;
      switch (heff_tag_of(v_t_249)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_t_249, 1);
        heff_take_n(v_t_249, 2ULL, 2);
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V v_t_2413 = ({ V rv_0 = heff_dup(heff_rfield(v_span_248, 0)); V rr_ = heff_rec_reuse_nf(v_t_2412, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_name_247, v_span_248, v_ty_246}), v_t_2413});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2414}), v_z_241});
    } else {
      heff_drop(v_field_244);
      V v_t_2417;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_p_240, 1);
        v_t_2417 = heff_dup(v_s_2416);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_str0), v_t_2417, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_z_241});
    }
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eparamOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamL(V v_r_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2eatomOf_24cpr(v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_r_240);
      heff_drop(v_e_241);
      V v_x_245 = v_field_244;
      V v_text_246 = heff_take_field(v_x_245, 1);
      V v_start_247 = heff_take_field(v_x_245, 3);
      V v_end_248 = heff_get_n(v_x_245, 4, 9);
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_lam0, 1, 3, (V[]){v_start_247, v_end_248, v_text_246});
    } else {
      heff_drop(v_field_244);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf(v_r_240, v_e_241);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_start_247 = heff_env(self)[0];
  V v_end_248 = heff_env(self)[1];
  V v_text_246 = heff_env(self)[2];
  V v_t_2410 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_247), heff_dup(v_end_248)})});
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_text_246, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_247), heff_dup(v_end_248)}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_249});
}
Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Sig: {
      V v_f_245 = heff_field(v_x11_242, 1);
      V v_fsp_246 = heff_field(v_x11_242, 2);
      V v_ty_247 = heff_field(v_x11_242, 3);
      V v_sp_248 = heff_field(v_x11_242, 4);
      heff_take_n(v_x11_242, 30ULL, 5);
      V v_start_249 = heff_take_field(v_sp_248, 0);
      V v_end_2410 = heff_take_field(v_sp_248, 1);
      HeffT2 v_t_2411 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_245, heff_dup(v_rest_243)));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_es_2414 = v_field_2413;
          V v_end_2415 = heff_take_field(v_es_2414, 1);
          V v_eqns_2416 = heff_get_n(v_es_2414, 0, 2);
          V v_a_2417 = v_start_249;
          V v_a_2418 = v_end_2410;
          V v_b_2419 = v_end_2415;
          V v_t_2420;
          if (heff_intLt_c_lent(v_a_2418, v_b_2419, 0)) {
            heff_drop(v_a_2418);
            v_t_2420 = v_b_2419;
          } else {
            heff_drop(v_b_2419);
            v_t_2420 = v_a_2418;
          }
          V v_t_2421 = heff_rec_n(5, shape_name__span__ty__eqns__whole, (V[]){v_f_245, v_fsp_246, v_ty_247, v_eqns_2416, ({ V rv_0 = v_a_2417; V rv_1 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_sp_248, 0ULL, 2, shape_start__end, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; })});
          V v_cell_2422 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2421}), heff_hole()});
          V v_u_2423 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2422);
          V t_0 = v_rest_243;
          V t_1 = v_u_2423;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_f_245);
          heff_drop(v_fsp_246);
          heff_drop(v_ty_247);
          heff_drop_rec(v_sp_248, 2);
          heff_drop(v_start_249);
          heff_drop(v_end_2410);
          heff_drop(v_field_2413);
          V t_0 = v_rest_243;
          V t_1 = v_d_241;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
      }
    }
    case TAG_Eqn: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Whole: {
      V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_242}), heff_hole()});
      V v_u_2429 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2428);
      V t_0 = v_rest_243;
      V t_1 = v_u_2429;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Doc: {
      V v_cell_2431 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_242}), heff_hole()});
      V v_u_2432 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2431);
      V t_0 = v_rest_243;
      V t_1 = v_u_2432;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2emutualDefs_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str0, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str1, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str2, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str3, 70, "a `mutual` block holds definitions, each a signature and its equations");

HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V v_r_240, V v_kw_241, V v_ds_242, V v_z_243) {
top: ;
  V v_end_244 = heff_take_field(v_kw_241, 4);
  V v_start_245 = heff_get_n(v_kw_241, 3, 9);
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2efirstSig_24cpr(v_ds_242));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_f1_249 = v_field_248;
      HeffT2 v_t_2410 = ({ V a_0 = v_r_240; V b_1 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str0), heff_dup(v_f1_249)); V a_2 = heff_dup(v_ds_242); V a_3 = v_z_243; HeffT2 r_ = (g_heff_2esyntax_2esurface_2emutualItems_24cpr(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x11_2413 = v_field_2411;
        V v_st_2414 = v_field_2412;
        switch (heff_tag_of(v_x11_2413)) {
        case TAG_Left: {
          V v_e_2415 = heff_field(v_x11_2413, 0);
          V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
          heff_drop(v_ds_242);
          heff_drop(v_end_244);
          heff_drop(v_start_245);
          heff_drop(v_f1_249);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2415}), v_st_2414}});
        }
        case TAG_Right: {
          V v_x_2416 = heff_field(v_x11_2413, 0);
          V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
          V v_t_2417 = (g_heff_2esyntax_2esurface_2emutualDefs(heff_dup(v_x_2416)));
          V v_t_2418 = (g_list_2emap_24s2081681776x559624592(v_t_2417));
          V v_t_2419 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2418));
          switch (heff_tag_of(v_t_2419)) {
          case TAG_Nil: {
            V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_242));
            V v_e_2424;
            switch (heff_tag_of(v_x1_2420)) {
            case TAG_Nil: {
              v_e_2424 = heff_dup(v_end_244);
              break;
            }
            case TAG_Cons: {
              V v_x_2421 = heff_field(v_x1_2420, 0);
              heff_take_n(v_x1_2420, 1ULL, 2);
              V v_t_2423 = (g_heff_2esyntax_2ecst_2elastD(v_x_2421));
              v_e_2424 = heff_get_n(v_t_2423, 4, 9);
              break;
            }
            default: heff_nomatch(v_x1_2420);
            }
            V v_t_2425 = (g_heff_2esyntax_2esurface_2emutualDefs(v_x_2416));
            V v_x_2426 = (g_heff_2esyntax_2esurface_2emutualOut(heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_245), v_end_244}), heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_e_2424}), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str1), heff_dup(v_f1_249)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str2), v_f1_249), v_t_2425));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){v_x_2426}), v_st_2414}});
          }
          case TAG_Cons: {
            V v_d_2427 = heff_field(v_t_2419, 0);
            heff_take_n(v_t_2419, 1ULL, 2);
            heff_drop(v_ds_242);
            heff_drop(v_end_244);
            heff_drop(v_start_245);
            heff_drop(v_f1_249);
            heff_drop(v_x_2416);
            heff_drop_cell(v_ru_24x11_2413_24Right, 1);
            return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2427}), v_st_2414}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2419)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
        }
      }
    } else {
      heff_drop(v_r_240);
      heff_drop(v_ds_242);
      heff_drop(v_field_248);
      V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str3), heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_244}), NTAG(TAG_Nothing)});
      V v_f_2430 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2429});
      return ((HeffT2){{v_f_2430, v_z_243}});
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eedgesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eedgesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eedgesOf(V v_scope_240, V v_d_241) {
top: ;
  V v_ops_242 = heff_take_field(v_d_241, 1);
  V v_above_243 = heff_take_field(v_d_241, 2);
  V v_below_244 = heff_get_n(v_d_241, 3, 8);
  V v_t_245 = v_ops_242;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_scope_240, 2);
    heff_drop(v_above_243);
    heff_drop(v_below_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_op_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Cons = heff_take_reuse_n(v_t_245, 1ULL, 2);
    V v_t_2415 = (g_list_2emap_24tok2(v_ru_24t_245_24Cons, heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam0, 1, 2, (V[]){heff_dup(v_scope_240), heff_dup(v_op_246)}), v_above_243));
    V v_t_2416 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2415));
    V v_t_2423 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam2, 1, 1, (V[]){heff_dup(v_scope_240)}); V a_1 = v_below_244; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam4, 1, 2, (V[]){v_scope_240, v_op_246}), v_t_2423));
    V v_t_2432 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2431));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2416, v_t_2432);
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eedgesOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args) {
  V v_g_249 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_r_248, 1, 7); V b_1 = heff_get_n(v_g_249, 2, 5); V r_ = (g_list_2eany_24s1006624359x760861690(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args) {
  V v_r_248 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2410 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam1, 1, 1, (V[]){v_r_248}); V b_1 = heff_get_n(v_scope_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_g_2413 = v_field_2412;
      V v_t_2414 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_op_246, 1, 7), heff_get_n(v_g_2413, 0, 5)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    } else {
      heff_drop_rec(v_op_246, 7);
      heff_drop(v_field_2412);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_r_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_r_2417, 1, 7); V b_1 = heff_get_n(v_g_2418, 2, 5); V r_ = (g_list_2eany_24s1006624359x760861690(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args) {
  V v_r_2417 = args[0];
  V v_scope_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam3, 1, 1, (V[]){v_r_2417}); V b_1 = heff_get_n(v_scope_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_g_2422 = v_field_2421;
      V v_ret_24bool = heff_bool(!(heff_dup(heff_rfield(v_g_2422, 3)) == NTAG(TAG_True)));
      heff_drop_rec(v_g_2422, 5);
      return v_ret_24bool;
    } else {
      heff_drop(v_field_2421);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args) {
  V v_g_2425 = args[0];
  V v_r_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_r_2424, 1, 7); V b_1 = heff_get_n(v_g_2425, 2, 5); V r_ = (g_list_2eany_24s1006624359x760861690(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args) {
  V v_r_2424 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2426 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam5, 1, 1, (V[]){v_r_2424}); V b_1 = heff_get_n(v_scope_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    if ((v_tag_2427 == ((int64_t)0ULL))) {
      V v_g_2429 = v_field_2428;
      V v_t_2430 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_g_2429, 0, 5), heff_get_n(v_op_246, 1, 7)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
    } else {
      heff_drop_rec(v_op_246, 7);
      heff_drop(v_field_2428);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurface_2efixityFrom_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2efixityFrom_24cpr(V v_place_240, V v_imported_241, V v_decls_242) {
top: ;
  V v_t_243 = (g_list_2ekeepIf_24s2053104128x1598844325(MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(v_decls_242)));
  V v_t_245 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2efixityFrom_24cpr_lam0, 1, 1, (V[]){v_place_240}), v_t_243));
  V v_groups_246 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_245));
  V v_imported_247 = heff_dup(v_imported_241);
  V v_groups_248 = heff_take_field(v_imported_247, 0);
  V v_above_249 = heff_take_field(v_imported_247, 1);
  V v_decls_2410 = heff_dup(v_decls_242);
  V v_groups_2411 = heff_dup(v_groups_246);
  V v_t_2412 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_imported_241, 0), v_groups_246));
  V v_t_2413 = (g_heff_2esyntax_2efixity_2enubByG(v_t_2412));
  V v_t_2414 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_imported_241, 1), NTAG(TAG_Nil)));
  V v_t_2415 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2414));
  V v_t_2416 = ({ V rv_0 = v_t_2413; V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_imported_241, 0ULL, 2, shape_groups__above, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_edges_2417 = ({ V a_0 = v_t_2416; V a_1 = v_decls_242; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(a_0, a_1)); heff_drop_rec(v_t_2416, 2); heff_drop(v_decls_242); r_; });
  V v_t_2418 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(v_groups_248), heff_dup(v_groups_2411)));
  V v_t_2419 = (g_heff_2esyntax_2efixity_2enubByG(v_t_2418));
  V v_t_2420 = (g_heff_2esyntax_2efixity_2eappendF(heff_dup(v_above_249), NTAG(TAG_Nil)));
  V v_t_2421 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2420));
  V v_t_2422 = ({ V rv_0 = v_t_2419; V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_imported_247, 0ULL, 2, shape_groups__above, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2423 = (g_heff_2esyntax_2efixity_2eappendF(v_groups_248, heff_dup(v_groups_2411)));
  V v_t_2424 = (g_heff_2esyntax_2efixity_2enubByG(v_t_2423));
  V v_t_2425 = (g_heff_2esyntax_2efixity_2eappendF(v_above_249, heff_dup(v_edges_2417)));
  V v_t_2426 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2425));
  V v_t_2427 = heff_rec_n(2, shape_groups__above, (V[]){v_t_2424, v_t_2426});
  V v_t_2428 = ({ V a_0 = v_t_2422; V a_1 = v_t_2427; V a_2 = v_decls_2410; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s850037096x1439534441(a_0, a_1, a_2)); heff_drop_rec(v_t_2422, 2); heff_drop_rec(v_t_2427, 2); heff_drop(v_decls_2410); r_; });
  return ((HeffT2){{heff_rec_n(2, shape_groups__above, (V[]){v_groups_2411, v_edges_2417}), v_t_2428}});
}
V g_heff_2esyntax_2esurface_2efixityFrom_24cpr_lam0(V self, V *args) {
  V v_d_244 = args[0];
  V v_place_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2egroupOfDecl(v_place_240, v_d_244));
}

HeffT2 g_heff_2esyntax_2esurface_2etheoryFieldOne_24s1473805472x1314815828_24cpr(V v_ty_240, V v_d_241, V v_x_242, V v_st_243) {
top: ;
  V v_text_244 = heff_take_field(v_x_242, 1);
  V v_start_245 = heff_take_field(v_x_242, 3);
  V v_end_246 = heff_get_n(v_x_242, 4, 9);
  V v_x1_247 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_ty_240, v_st_243));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_d_241);
      heff_drop(v_text_244);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x11_248_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2410}), v_st_249}});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      switch (heff_tag_of(v_d_241)) {
      case TAG_Nothing: {
        V v_t_2412 = heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_text_244), heff_dup(heff_rfield(v_st_249, 1))});
        V v_st_2413 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2412, v_st_249));
        V v_t_2416;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_x_2411, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_t_2417 = heff_tag_n(TAG_DeclareField, 4, (V[]){v_text_244, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_245), v_end_246}), v_x_2411, NTAG(TAG_Nothing)});
        V v_t_2418 = ({ V rv_0 = v_start_245; V rr_ = heff_rec_reuse_nf(v_t_2416, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_f_2419 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2418})});
        return ((HeffT2){{v_f_2419, v_st_2413}});
      }
      case TAG_Just: {
        V v_x21_2420 = heff_field(v_d_241, 0);
        V v_ru_24d_241_24Just = heff_take_reuse_n(v_d_241, 1ULL, 1);
        switch (heff_tag_of(v_x21_2420)) {
        case TAG_MkPair: {
          V v_d_2422 = heff_field(v_x21_2420, 1);
          V v_ru_24x21_2420_24MkPair = heff_take_reuse_n(v_x21_2420, 2ULL, 2);
          V v_x1_2423 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_d_2422, v_st_249));
          switch (heff_tag_of(v_x1_2423)) {
          case TAG_MkPair: {
            V v_x11_2424 = heff_field(v_x1_2423, 0);
            V v_st_2425 = heff_field(v_x1_2423, 1);
            heff_take_n(v_x1_2423, 3ULL, 2);
            switch (heff_tag_of(v_x11_2424)) {
            case TAG_Left: {
              V v_e_2426 = heff_field(v_x11_2424, 0);
              V v_ru_24x11_2424_24Left = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
              heff_drop(v_text_244);
              heff_drop(v_start_245);
              heff_drop(v_end_246);
              heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
              heff_drop(v_x_2411);
              heff_drop_cell(v_ru_24x11_248_24Right, 1);
              heff_drop_cell(v_ru_24d_241_24Just, 1);
              heff_drop_cell(v_ru_24x21_2420_24MkPair, 2);
              return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2424_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2426}), v_st_2425}});
            }
            case TAG_Right: {
              V v_x_2427 = heff_field(v_x11_2424, 0);
              heff_take_n(v_x11_2424, 1ULL, 1);
              V v_t_2428 = heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_text_244), heff_dup(heff_rfield(v_st_2425, 1))});
              V v_st_2429 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2428, v_st_2425));
              V v_t_2432;
              switch (heff_tag_of(v_x_2427)) {
              case TAG_At: {
                V v_s_2431 = heff_dup(heff_field(v_x_2427, 1));
                v_t_2432 = v_s_2431;
                break;
              }
              default: heff_nomatch(v_x_2427);
              }
              V v_t_2433 = heff_tag_n(TAG_DeclareField, 4, (V[]){v_text_244, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_245), v_end_246}), v_x_2411, heff_tag_at_n(v_ru_24d_241_24Just, TAG_Just, 1, (V[]){v_x_2427})});
              V v_t_2434 = ({ V rv_0 = v_start_245; V rr_ = heff_rec_reuse_nf(v_t_2432, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              V v_f_2435 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x21_2420_24MkPair, TAG_At, 2, (V[]){v_t_2433, v_t_2434})});
              return ((HeffT2){{v_f_2435, v_st_2429}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x11_2424)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2423)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x21_2420)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_d_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(V v_k_240, V v_ds_241, V v_st_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2esurface_2eknotOf(v_k_240, v_ds_241));
  V v_st_244 = (g_heff_2esyntax_2esurface_2esetKnot(v_t_243, v_st_242));
  V v_t_245 = heff_dup(heff_rfield(v_st_244, 1));
  V v_t_246 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), v_ds_241));
  V v_x1_247 = heff_tr(heff_call(v_t_246, 1, (V[]){v_st_244}));
  V v_x11_2413;
  V v_st_2414;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    heff_take_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_t_245);
      v_x11_2413 = heff_tag_re_n(v_ru_24x11_248_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2410});
      v_st_2414 = v_st_249;
      break;
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_st_2412 = (g_heff_2esyntax_2esurface_2esetScope(v_t_245, v_st_249));
      v_x11_2413 = heff_tag_re_n(v_ru_24x11_248_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_2411});
      v_st_2414 = v_st_2412;
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_x11_2413)) {
  case TAG_Left: {
    V v_e_2415 = heff_field(v_x11_2413, 0);
    V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
    return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2415}), v_st_2414}});
  }
  case TAG_Right: {
    V v_x_2416 = heff_field(v_x11_2413, 0);
    V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
    V v_st_2417 = (g_heff_2esyntax_2esurface_2esetKnot(heff_dup(g_std_2eordmap_2eempty_get()), v_st_2414));
    V v_t_2418 = heff_dup(heff_rfield(v_st_2417, 7));
    V v_items_2419 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2416));
    V v_items_2420 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2419, NTAG(TAG_Nil)));
    V v_d_2424 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0, 2, 1, (V[]){v_t_2418}); V a_1 = heff_dup(g_heff_2esyntax_2esurface_2ewhereL_24rec0_get()); V a_2 = v_items_2420; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_items_2420); r_; });
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2424, 3, 4)));
    V v_items_2426 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2416));
    V v_items_2427 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2426, NTAG(TAG_Nil)));
    V v_t_2428 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2427));
    V v_t_2429 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2427));
    V v_t_2430 = (g_list_2emap_24s2130193383x1335133353(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2428, v_t_2429, v_items_2427));
    V v_t_2431 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2430));
    V v_t_2432 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2425, v_t_2431));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nil: {
      V v_items_2433 = ({ V a_0 = v_x_2416; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2416); r_; });
      V v_x_2434 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2433, NTAG(TAG_Nil)));
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){v_x_2434}), v_st_2417}});
    }
    case TAG_Cons: {
      V v_d_2435 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 2);
      heff_drop(v_x_2416);
      heff_drop_cell(v_ru_24x11_2413_24Right, 1);
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2435}), v_st_2417}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2432)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0(V self, V *args) {
  V v_d_2421 = args[0];
  V v_it_2422 = args[1];
  V v_t_2418 = heff_env(self)[0];
  V v_t_2423 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2421, 2)), v_it_2422));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_2418; V a_1 = v_d_2421; V a_2 = v_t_2423; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str0, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str1, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str2, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str3, 70, "a `mutual` block holds definitions, each a signature and its equations");

HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V v_kw_240, V v_ds_241, V v_z_242) {
top: ;
  V v_end_243 = heff_take_field(v_kw_240, 4);
  V v_start_244 = heff_get_n(v_kw_240, 3, 9);
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2efirstSig_24cpr(v_ds_241));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_f1_248 = v_field_247;
      HeffT2 v_t_249 = ({ V b_0 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str0), heff_dup(v_f1_248)); V a_1 = heff_dup(v_ds_241); V a_2 = v_z_242; HeffT2 r_ = (g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x11_2412 = v_field_2410;
        V v_st_2413 = v_field_2411;
        switch (heff_tag_of(v_x11_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x11_2412, 0);
          V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
          heff_drop(v_ds_241);
          heff_drop(v_end_243);
          heff_drop(v_start_244);
          heff_drop(v_f1_248);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2412_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2414}), v_st_2413}});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x11_2412, 0);
          V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
          V v_t_2416 = (g_heff_2esyntax_2esurface_2emutualDefs(heff_dup(v_x_2415)));
          V v_t_2417 = (g_list_2emap_24s2081681776x559624592(v_t_2416));
          V v_t_2418 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2417));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nil: {
            V v_x1_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
            V v_e_2423;
            switch (heff_tag_of(v_x1_2419)) {
            case TAG_Nil: {
              v_e_2423 = heff_dup(v_end_243);
              break;
            }
            case TAG_Cons: {
              V v_x_2420 = heff_field(v_x1_2419, 0);
              heff_take_n(v_x1_2419, 1ULL, 2);
              V v_t_2422 = (g_heff_2esyntax_2ecst_2elastD(v_x_2420));
              v_e_2423 = heff_get_n(v_t_2422, 4, 9);
              break;
            }
            default: heff_nomatch(v_x1_2419);
            }
            V v_t_2424 = (g_heff_2esyntax_2esurface_2emutualDefs(v_x_2415));
            V v_x_2425 = (g_heff_2esyntax_2esurface_2emutualOut(heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_244), v_end_243}), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_e_2423}), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str1), heff_dup(v_f1_248)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str2), v_f1_248), v_t_2424));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){v_x_2425}), v_st_2413}});
          }
          case TAG_Cons: {
            V v_d_2426 = heff_field(v_t_2418, 0);
            heff_take_n(v_t_2418, 1ULL, 2);
            heff_drop(v_ds_241);
            heff_drop(v_end_243);
            heff_drop(v_start_244);
            heff_drop(v_f1_248);
            heff_drop(v_x_2415);
            heff_drop_cell(v_ru_24x11_2412_24Right, 1);
            return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2426}), v_st_2413}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2418)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
        }
      }
    } else {
      heff_drop(v_ds_241);
      heff_drop(v_field_247);
      V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str3), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_243}), NTAG(TAG_Nothing)});
      V v_f_2429 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2428});
      return ((HeffT2){{v_f_2429, v_z_242}});
    }
  }
}

HeffT5 g_heff_2esyntax_2esurface_2ereadLexed_24cpr(V v_src_240, V v_o_241, V v_l_242) {
top: ;
  V v_tokens_243 = heff_take_field(v_l_242, 0);
  V v_errors_244 = heff_get_n(v_l_242, 1, 3);
  V v_ltoks_245 = heff_arrayFromList(heff_dup(v_tokens_243));
  V v_t_246 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), v_tokens_243));
  V v_toks_247 = heff_arrayFromList(v_t_246);
  V v_lexDiags_248 = (g_list_2emap_24s338694954x1326523169(v_errors_244));
  V v_t_249 = (g_heff_2esyntax_2esurface_2eprescanGo(v_ltoks_245, MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nil)));
  V v_t_2410 = ({ V a_0 = v_ltoks_245; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2efixDecls(a_0, a_1, a_2)); heff_drop(v_ltoks_245); r_; });
  V v_t_2411 = (g_heff_2esyntax_2esurface_2efixityFrom(heff_dup(heff_rfield(v_o_241, 3)), heff_dup(heff_rfield(v_o_241, 1)), v_t_2410));
  return (g_heff_2esyntax_2esurface_2ereadRun_24cpr(v_src_240, v_o_241, v_toks_247, v_lexDiags_248, v_t_249, v_t_2411));
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = ({ V a_0 = v_ys_240; V a_1 = v_xs_243; V a_2 = v_cell_245; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(a_0, a_1, a_2)); heff_drop(v_ys_240); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_s_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_s_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0), v_t_246, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1)})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = ({ V a_0 = v_ys_240; V a_1 = v_xs_243; V a_2 = v_cell_248; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(a_0, a_1, a_2)); heff_drop(v_ys_240); r_; });
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(a[0], a[1]);
}