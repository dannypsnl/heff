// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define LBL_found 298980252
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_low 316878
#define LBL_members 1180739419
#define LBL_next 9873338
#define LBL_onStack 1042445868
#define LBL_params 951713969
#define LBL_stack 311115426
static uint32_t shape_next__index__low__stack__onStack__found[] = {LBL_next, LBL_index, LBL_low, LBL_stack, LBL_onStack, LBL_found};
V g_heff_2ecompile_2ecycles_2elowered(V, V, V);
V g_heff_2ecompile_2ecycles_2elowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2elowered_clo;
HeffT2 g_heff_2ecompile_2ecycles_2epopTo_24cpr(V, V, V);
V g_heff_2ecompile_2ecycles_2eretail(V, V, V);
V g_heff_2ecompile_2ecycles_2eretail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2eretail_clo;
V g_heff_2ecompile_2ecycles_2estartWalk_get(void);
V g_heff_2ecompile_2ecycles_2estrong(V, V, V);
V g_heff_2ecompile_2ecycles_2estrong_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2estrong_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s243182857x1571262076(V, V);
V g_list_2efoldl_24s243182857x1571262076_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243182857x1571262076_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1460603830x671758883(V, V);
V g_list_2emap_24s1460603830x671758883_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_clo;
V g_list_2emap_24s1460603830x671758883_24tok1(V, V, V);
V g_list_2emap_24s1460603830x671758883_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2ecycles_2elowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2elowered_entry, 3, 0};

V g_heff_2ecompile_2ecycles_2elowered(V v_v_240, V v_n_241, V v_w_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_w_242, 2), v_v_240));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_b_247;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      v_b_247 = v_x_246;
    } else {
      heff_drop(v_field_245);
      v_b_247 = MK_INT(0LL);
    }
    V v_t_248;
    if (heff_intLt_c_lent(v_n_241, v_b_247, 0)) {
      heff_drop(v_b_247);
      v_t_248 = v_n_241;
    } else {
      heff_drop(v_n_241);
      v_t_248 = v_b_247;
    }
    V v_t_249 = ({ V a_0 = heff_take_field(v_w_242, 2); V a_1 = v_v_240; V a_2 = v_t_248; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    return ({ V rv_2 = v_t_249; V rr_ = heff_rec_reuse_nf(v_w_242, 59ULL, 6, shape_next__index__low__stack__onStack__found, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  }
}
V g_heff_2ecompile_2ecycles_2elowered_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecycles_2elowered(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2ecycles_2epopTo_24cpr(V v_v_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return ((HeffT2){{v_acc_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_243, v_v_240, 0)) {
      return ((HeffT2){{heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, v_acc_241}), v_xs_244}});
    } else {
      V t_0 = v_v_240;
      V t_1 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, v_acc_241});
      V t_2 = v_xs_244;
      v_v_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2ecycles_2estrong_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2estrong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2estrong_entry, 3, 0};

V g_heff_2ecompile_2ecycles_2estrong(V v_calls_240, V v_w_241, V v_v_242) {
top: ;
  V v_v_243 = heff_dup(v_v_242);
  V v_v_244 = heff_dup(v_v_242);
  V v_w_245 = v_w_241;
  V v_t_246 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_w_245, 1), v_v_244, heff_rfield(v_w_245, 0)));
  V v_t_247 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_w_245, 2), v_v_244, heff_rfield(v_w_245, 0)));
  V v_t_248 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_w_245, 4), v_v_244, NTAG(TAG_MkUnit)));
  HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_calls_240, v_v_242));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_t_2413;
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2411;
      v_t_2413 = v_x_2412;
    } else {
      heff_drop(v_field_2411);
      v_t_2413 = NTAG(TAG_Nil);
    }
    V v_t_2414 = heff_intAdd(heff_take_field(v_w_245, 0), MK_INT(1LL));
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_244, heff_take_field(v_w_245, 3)});
    V v_t_2416 = ({ V rv_0 = v_t_2414; V rv_1 = v_t_246; V rv_2 = v_t_247; V rv_3 = v_t_2415; V rv_4 = v_t_248; V rr_ = heff_rec_reuse_nf(v_w_245, 32ULL, 6, shape_next__index__low__stack__onStack__found, 3072u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_w_2438 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecycles_2estrong_lam0, 2, 2, (V[]){v_v_242, heff_dup(v_calls_240)}); V a_1 = v_t_2416; V a_2 = v_t_2413; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2413); r_; });
    HeffT2 v_t_2439 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_w_2438, 2), v_v_243));
    {
      V v_field_2441 = v_t_2439.f[1];
      int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
      V v_t_2443;
      if ((v_tag_2440 == ((int64_t)0ULL))) {
        V v_x_2442 = v_field_2441;
        v_t_2443 = v_x_2442;
      } else {
        heff_drop(v_field_2441);
        v_t_2443 = MK_INT(0LL);
      }
      HeffT2 v_t_2444 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_w_2438, 1), v_v_243));
      {
        V v_field_2446 = v_t_2444.f[1];
        int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
        V v_t_2448;
        if ((v_tag_2445 == ((int64_t)0ULL))) {
          V v_x_2447 = v_field_2446;
          v_t_2448 = v_x_2447;
        } else {
          heff_drop(v_field_2446);
          v_t_2448 = MK_INT(0LL);
        }
        if (heff_intEq_c(v_t_2443, v_t_2448)) {
          HeffT2 v_t_2449 = ({ V a_0 = v_v_243; V a_1 = NTAG(TAG_Nil); V a_2 = heff_take_field(v_w_2438, 3); HeffT2 r_ = (g_heff_2ecompile_2ecycles_2epopTo_24cpr(a_0, a_1, a_2)); heff_drop(v_v_243); r_; });
          {
            V v_field_2450 = v_t_2449.f[0];
            V v_field_2451 = v_t_2449.f[1];
            V v_comp_2452 = v_field_2450;
            V v_rest_2453 = v_field_2451;
            V v_t_2454 = (g_list_2efoldl_24s243182857x1571262076(heff_take_field(v_w_2438, 4), v_comp_2452));
            V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_comp_2452, heff_take_field(v_w_2438, 5)});
            return ({ V rv_3 = v_rest_2453; V rv_4 = v_t_2454; V rv_5 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_w_2438, 7ULL, 6, shape_next__index__low__stack__onStack__found, 63u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
          }
        } else {
          heff_drop(v_v_243);
          return v_w_2438;
        }
      }
    }
  }
}
V g_heff_2ecompile_2ecycles_2estrong_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecycles_2estrong(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecycles_2estrong_lam0(V self, V *args) {
  V v_w1_2417 = args[0];
  V v_g_2418 = args[1];
  V v_v_242 = heff_env(self)[0];
  V v_calls_240 = heff_env(self)[1];
  HeffT2 v_t_2419 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_w1_2417, 1), v_g_2418));
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      heff_clo_take(self, 2);
      heff_drop(v_calls_240);
      V v_x_2422 = v_field_2421;
      heff_drop(v_x_2422);
      HeffT2 v_t_2423 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_w1_2417, 4), v_g_2418));
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          V v_x_2426 = v_field_2425;
          heff_drop(v_x_2426);
          HeffT2 v_t_2427 = ({ V a_0 = heff_rfield(v_w1_2417, 1); V a_1 = v_g_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2418); r_; });
          {
            V v_field_2429 = v_t_2427.f[1];
            int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
            V v_t_2431;
            if ((v_tag_2428 == ((int64_t)0ULL))) {
              V v_x_2430 = v_field_2429;
              v_t_2431 = v_x_2430;
            } else {
              heff_drop(v_field_2429);
              v_t_2431 = MK_INT(0LL);
            }
            return ({ V a_0 = v_v_242; V a_1 = v_t_2431; V a_2 = v_w1_2417; V r_ = (g_heff_2ecompile_2ecycles_2elowered(a_0, a_1, a_2)); heff_drop(v_v_242); r_; });
          }
        } else {
          heff_drop(v_g_2418);
          heff_drop(v_v_242);
          heff_drop(v_field_2425);
          return v_w1_2417;
        }
      }
    } else {
      heff_drop(v_field_2421);
      heff_clo_take(self, 2);
      V v_w_2432 = ({ V a_0 = v_calls_240; V a_1 = v_w1_2417; V a_2 = heff_dup(v_g_2418); V r_ = (g_heff_2ecompile_2ecycles_2estrong(a_0, a_1, a_2)); heff_drop(v_calls_240); r_; });
      HeffT2 v_t_2433 = ({ V a_0 = heff_rfield(v_w_2432, 2); V a_1 = v_g_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2418); r_; });
      {
        V v_field_2435 = v_t_2433.f[1];
        int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
        V v_t_2437;
        if ((v_tag_2434 == ((int64_t)0ULL))) {
          V v_x_2436 = v_field_2435;
          v_t_2437 = v_x_2436;
        } else {
          heff_drop(v_field_2435);
          v_t_2437 = MK_INT(0LL);
        }
        return ({ V a_0 = v_v_242; V a_1 = v_t_2437; V a_2 = v_w_2432; V r_ = (g_heff_2ecompile_2ecycles_2elowered(a_0, a_1, a_2)); heff_drop(v_v_242); r_; });
      }
    }
  }
}

static V g_heff_2ecompile_2ecycles_2estartWalk_val;
static HEFF_ONCE g_heff_2ecompile_2ecycles_2estartWalk_st;
static V g_heff_2ecompile_2ecycles_2estartWalk_init(void) {
  return heff_rec_n(6, shape_next__index__low__stack__onStack__found, (V[]){MK_INT(0LL), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2ecycles_2estartWalk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ecycles_2estartWalk_st)) return g_heff_2ecompile_2ecycles_2estartWalk_val;
  return heff_global(&g_heff_2ecompile_2ecycles_2estartWalk_val, &g_heff_2ecompile_2ecycles_2estartWalk_st, g_heff_2ecompile_2ecycles_2estartWalk_init);
}
HEFF_LIT(g_heff_2ecompile_2ecycles_2eretail_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecycles_2eretail_str1, 6, "Enter$");
V g_heff_2ecompile_2ecycles_2eretail_lam0(V self, V *args);
V g_heff_2ecompile_2ecycles_2eretail_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecycles_2eretail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecycles_2eretail_entry, 3, 0};

V g_heff_2ecompile_2ecycles_2eretail(V v_c_240, V v_at_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ELam: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EApp: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ELet: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ERecord: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EProj: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ETag: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EMatch: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EPrim: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ECall: {
    V v_g_2426 = heff_field(v_e_242, 0);
    V v_args_2427 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2431 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecycles_2eretail_lam0, 1, 2, (V[]){heff_dup(v_g_2426), heff_dup(v_args_2427)}); V a_1 = heff_rfield(v_c_240, 2); V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_t_2431);
      V v_lit_2432 = v_at_241;
      V v_c_2433 = heff_dup(v_c_240);
      V v_g_2434 = v_g_2426;
      V v_args_2435 = v_args_2427;
      V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_2433, 2, 3)));
      V v_t_2442 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecycles_2eretail_lam1, 2, 3, (V[]){heff_dup(v_g_2434), v_args_2435, v_lit_2432}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2436; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2436); r_; });
      V v_t_2443 = heff_tag_n(TAG_ETag, 3, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecycles_2eretail_str1), v_g_2434), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){heff_get_n(v_c_240, 0, 3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2442})});
    } else {
      heff_drop_rec(v_c_240, 3);
      heff_drop(v_at_241);
      heff_drop(v_t_2431);
      return heff_tag_re_n(v_ru_24e_242_24ECall, TAG_ECall, 2, 3ULL, (V[]){v_g_2426, v_args_2427});
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EBool: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_ESet: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EValues: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  case TAG_EFix: {
    heff_drop_rec(v_c_240, 3);
    heff_drop(v_at_241);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2ecycles_2eretail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecycles_2eretail(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecycles_2eretail_lam0(V self, V *args) {
  V v_m_2428 = args[0];
  V v_g_2426 = heff_env(self)[0];
  V v_args_2427 = heff_env(self)[1];
  V v_key_2429 = heff_take_field(v_m_2428, 0);
  V v_params_2430 = heff_get_n(v_m_2428, 2, 4);
  V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_key_2429, v_g_2426, 0) && ({ V v_t_2458 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_2430)); int c_ = ({ V v_t_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2427)); int c_ = heff_intEq_c_lent(v_t_2458, v_t_2459, 0); heff_drop(v_t_2459); c_; }); heff_drop(v_t_2458); c_; })));
  heff_drop(self);
  heff_drop(v_key_2429);
  heff_drop(v_params_2430);
  return v_ret_24bool;
}
V g_heff_2ecompile_2ecycles_2eretail_lam1(V self, V *args) {
  V v_acc_2437 = args[0];
  V v_x_2438 = args[1];
  V v_g_2434 = heff_env(self)[0];
  V v_args_2435 = heff_env(self)[1];
  V v_lit_2432 = heff_env(self)[2];
  V v_key_2439 = heff_take_field(v_x_2438, 0);
  V v_params_2440 = heff_get_n(v_x_2438, 2, 4);
  V v_t_2441;
  heff_clo_take(self, 3);
  if (heff_strEq_c_lent(v_key_2439, v_g_2434, 2)) {
    heff_drop(v_lit_2432);
    heff_drop(v_key_2439);
    heff_drop(v_params_2440);
    v_t_2441 = v_args_2435;
  } else {
    heff_drop(v_args_2435);
    if (!heff_strEq_c_lent(v_lit_2432, v_key_2439, 0)) {
      heff_drop(v_lit_2432);
      heff_drop(v_key_2439);
      v_t_2441 = (g_list_2emap_24s1809017761x1063871171(v_params_2440));
    } else {
      heff_drop(v_lit_2432);
      heff_drop(v_key_2439);
      v_t_2441 = (g_list_2emap_24s1460603830x671758883(((V)&g_heff_2ecompile_2ecycles_2eretail_str0), v_params_2440));
    }
  }
  return (g_prelude_2e_2b_2b(v_t_2441, v_acc_2437));
}