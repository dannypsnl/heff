// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_rune_2evalidString_2evalidFrom_240(V, V);
V g_rune_2evalidString_2evalidFrom_240_entry(V self, V *a);
extern Clo g_rune_2evalidString_2evalidFrom_240_clo;
Clo g_rune_2evalidString_2evalidFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_rune_2evalidString_2evalidFrom_240_entry, 2, 0};

V g_rune_2evalidString_2evalidFrom_240(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1)) {
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    HeffT2 v_t_242 = heff_strRuneDecode_lent(v_s_240, v_i_241, 0);
    {
      V v_rune_243 = v_t_242.f[0];
      V v_width_244 = v_t_242.f[1];
      if ((heff_runeEq_c(heff_dup(v_rune_243), MK_INT(65533LL)) && ({ V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(65533LL), NTAG(TAG_Nil)}); int c_ = ({ V v_t_247 = heff_strOfRunes(heff_dup(v_t_245)); int c_ = !heff_strEq_c_lent(heff_strSlice_lent(v_s_240, v_i_241, heff_intAdd_lent(v_i_241, MK_INT(3LL), 2), 4), v_t_247, 1); heff_drop(v_t_247); c_; }); heff_drop(v_t_245); c_; }))) {
        heff_drop(v_i_241);
        heff_drop(v_rune_243);
        heff_drop(v_width_244);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_rune_243);
        V v_t_246 = heff_intAdd(v_i_241, v_width_244);
        V t_0 = v_s_240;
        V t_1 = v_t_246;
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
}
V g_rune_2evalidString_2evalidFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_rune_2evalidString_2evalidFrom_240(a0, a[1]); heff_drop(a0); return r;
}