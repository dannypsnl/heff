// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_ArrayIndexInAny 674
#define TAG_ArrayLength 32493
#define TAG_ArrayPeek 2264
#define TAG_ArrayPeekIn 6151
#define TAG_ArraySetOwned 53556
#define TAG_ArraySetOwnedIn 22211
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CDropSelf 14512
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CTakeSelf 23160
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondTrue 53113
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkCArm 24694
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_WordAdd 60179
#define LBL_array 294448755
#define LBL_arrays 537976933
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_entry 298026124
#define LBL_flat 9641024
#define LBL_index 301704428
#define LBL_indices 27765224
#define LBL_key 315609
#define LBL_lent 9813446
#define LBL_params 951713969
#define LBL_read 9991773
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_tested 1069972444
#define LBL_wrapper 1827365593
static uint32_t shape_index__array[] = {LBL_index, LBL_array};
static uint32_t shape_index__tested__read__flat[] = {LBL_index, LBL_tested, LBL_read, LBL_flat};
static uint32_t shape_indices__arrays__defs[] = {LBL_indices, LBL_arrays, LBL_defs};
static uint32_t shape_key__params__lent__entry__body__reprs__ret__wrapper[] = {LBL_key, LBL_params, LBL_lent, LBL_entry, LBL_body, LBL_reprs, LBL_ret, LBL_wrapper};
V g_heff_2ecompile_2ebounds_2eallOf(V);
V g_heff_2ecompile_2ebounds_2eallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eallOf_clo;
V g_heff_2ecompile_2ebounds_2eboundsWith(V, V, V);
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo;
V g_heff_2ecompile_2ebounds_2echeckOf(V, V);
V g_heff_2ecompile_2ebounds_2echeckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2echeckOf_clo;
V g_heff_2ecompile_2ebounds_2eelemS(V, V);
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eelemS_clo;
V g_heff_2ecompile_2ebounds_2efixSt(V, V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2efixSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2efixSt_clo;
V g_heff_2ecompile_2ebounds_2efixStmts(V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2efixStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2efixStmts_clo;
HeffT2 g_heff_2ecompile_2ebounds_2egivenTo_24cpr(V, V);
V g_heff_2ecompile_2ebounds_2elabel_get(void);
V g_heff_2ecompile_2ebounds_2elabelled(V, V);
V g_heff_2ecompile_2ebounds_2elabelled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2elabelled_clo;
V g_heff_2ecompile_2ebounds_2elabelledSt(V, V, V);
V g_heff_2ecompile_2ebounds_2elabelledSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2elabelledSt_clo;
HeffT2 g_heff_2ecompile_2ebounds_2elengthArray_24cpr(V);
V g_heff_2ecompile_2ebounds_2elengthOf(V);
V g_heff_2ecompile_2ebounds_2elengthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2elengthOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2elengthOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(V, V, V);
V g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo;
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(V, V, V, V);
V g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo;
V g_heff_2ecompile_2ebounds_2eneedAt(V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2eneedAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eneedAt_clo;
HeffT2 g_heff_2ecompile_2ebounds_2eneedAt_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2ebounds_2eneedOf_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2ebounds_2eneedsIn(V, V, V);
V g_heff_2ecompile_2ebounds_2eneedsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eneedsIn_clo;
V g_heff_2ecompile_2ebounds_2enubReads(V, V);
V g_heff_2ecompile_2ebounds_2enubReads_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2enubReads_clo;
V g_heff_2ecompile_2ebounds_2enubReads_24dps(V, V, V);
V g_heff_2ecompile_2ebounds_2enubReads_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2enubReads_24dps_clo;
HeffT2 g_heff_2ecompile_2ebounds_2erangeOf_24cpr(V, V, V);
HeffT3 g_heff_2ecompile_2ebounds_2erangeTest_24cpr(V, V);
V g_heff_2ecompile_2ebounds_2ereadsIn(V, V);
V g_heff_2ecompile_2ebounds_2ereadsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2ereadsIn_clo;
V g_heff_2ecompile_2ebounds_2esameAs(V, V, V, V);
V g_heff_2ecompile_2ebounds_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2esameAs_clo;
V g_heff_2ecompile_2ebounds_2escoped(V, V, V);
V g_heff_2ecompile_2ebounds_2escoped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2escoped_clo;
V g_heff_2ecompile_2ebounds_2estepSum(V, V);
V g_heff_2ecompile_2ebounds_2estepSum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2estepSum_clo;
V g_heff_2ecompile_2ebounds_2eunchecked(V, V, V, V);
V g_heff_2ecompile_2ebounds_2eunchecked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eunchecked_clo;
V g_heff_2ecompile_2ebounds_2evarOf(V);
V g_heff_2ecompile_2ebounds_2evarOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2evarOf_clo;
HeffT2 g_heff_2ecompile_2ebounds_2evarOf_24cpr(V);
V g_heff_2ecompile_2ebounds_2evarOf_24tok1(V, V);
V g_heff_2ecompile_2ebounds_2evarOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2evarOf_24tok1_clo;
V g_heff_2ecompile_2eowned_2ekids(V);
V g_heff_2ecompile_2eowned_2ekids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ekids_clo;
V g_heff_2ecompile_2eowned_2emapCond(V, V);
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2etested_2estep(V, V, V);
V g_heff_2ecompile_2etested_2estep_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etested_2estep_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2027973668x1165178200(V, V);
V g_list_2efoldl_24s2027973668x1165178200_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2027973668x1165178200_clo;
V g_list_2efoldl_24s323561330x1697851707(V, V);
V g_list_2efoldl_24s323561330x1697851707_entry(V self, V *a);
extern Clo g_list_2efoldl_24s323561330x1697851707_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1366776885x1474218589(V, V);
V g_list_2ekeepIf_24s1366776885x1474218589_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1366776885x1474218589_clo;
V g_list_2ekeepIf_24s708019417x1279437633(V, V);
V g_list_2ekeepIf_24s708019417x1279437633_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s708019417x1279437633_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2ebounds_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ebounds_2elabelledSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2elabelledSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2elabelledSt_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2elabelledSt(V v_go_240, V v_acc_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_CDrop: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CLet: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CDecl: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CSet: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CIf: {
    V v_a_2410 = heff_field(v_s_242, 1);
    V v_b_2411 = heff_field(v_s_242, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){v_acc_241, heff_dup(v_a_2410)}));
    return heff_tail(v_go_240, 2, (V[]){v_t_2412, heff_dup(v_b_2411)});
  }
  case TAG_CSwitch: {
    V v_arms_2414 = heff_field(v_s_242, 1);
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2elabelledSt_lam0, 2, 1, (V[]){v_go_240}); V a_1 = v_acc_241; V a_2 = v_arms_2414; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  }
  case TAG_CReturn: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CInPlace: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CRoomed: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CTail: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CLoop: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CLoopTo: {
    heff_drop(v_go_240);
    heff_drop(v_acc_241);
    return NTAG(TAG_True);
  }
  case TAG_CLabel: {
    heff_drop(v_go_240);
    heff_drop(v_acc_241);
    return NTAG(TAG_True);
  }
  case TAG_CJump: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CTakeSelf: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  case TAG_CDropSelf: {
    heff_drop(v_go_240);
    return v_acc_241;
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2ebounds_2elabelledSt_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ebounds_2elabelledSt(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ebounds_2elabelledSt_lam0(V self, V *args) {
  V v_a_2416 = args[0];
  V v_arm_2417 = args[1];
  V v_go_240 = heff_env(self)[0];
  V v_t_2426;
  switch (heff_tag_of(v_arm_2417)) {
  case TAG_MkCArm: {
    V v_body_2424 = heff_field(v_arm_2417, 6);
    heff_take_n(v_arm_2417, 64ULL, 8);
    v_t_2426 = v_body_2424;
    break;
  }
  default: heff_nomatch(v_arm_2417);
  }
  heff_clo_take(self, 1);
  V f_ = v_go_240;
  args[0] = v_a_2416;
  args[1] = v_t_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ecompile_2ebounds_2elabelled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2elabelled_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2elabelled(V v_acc_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2elabelledSt_clo), 1, (V[]){((V)&g_heff_2ecompile_2ebounds_2elabelled_clo)}));
  return ({ V a_0 = v_t_242; V a_1 = v_acc_240; V a_2 = v_ss_241; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2ecompile_2ebounds_2elabelled_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2elabelled(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2ebounds_2egivenTo_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_x_240, v_y_244, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_e_245)}});
      } else {
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2ebounds_2evarOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2evarOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2evarOf(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2evarOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ebounds_2evarOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2ebounds_2estepSum_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2estepSum_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2estepSum(V v_x_240, V v_es_241) {
top: ;
  switch (heff_tag_of(v_es_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_es1_242 = heff_field(v_es_241, 0);
    V v_es2_243 = heff_field(v_es_241, 1);
    switch (heff_tag_of(v_es1_242)) {
    case TAG_RFixU: {
      V v_es12_245 = heff_field(v_es1_242, 1);
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e_246 = heff_field(v_es2_243, 0);
        V v_es22_247 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es22_247)) {
        case TAG_Nil: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_es12_245, 1)) {
            HeffT2 v_t_248 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_246));
            {
              V v_field_2410 = v_t_248.f[1];
              int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
              if ((v_tag_249 == ((int64_t)0ULL))) {
                V v_y_2411 = v_field_2410;
                V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_2411, 0));
                heff_drop(v_y_2411);
                return v_ret_24bool;
              } else {
                heff_drop(v_field_2410);
                return NTAG(TAG_False);
              }
            }
          } else {
            return NTAG(TAG_False);
          }
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es22_247);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    default: {
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_es21_2414 = heff_field(v_es2_243, 0);
        V v_es22_2415 = heff_field(v_es2_243, 1);
        switch (heff_tag_of(v_es21_2414)) {
        case TAG_RLocal: {
          return NTAG(TAG_False);
        }
        case TAG_RDup: {
          return NTAG(TAG_False);
        }
        case TAG_RClo: {
          return NTAG(TAG_False);
        }
        case TAG_RGet: {
          return NTAG(TAG_False);
        }
        case TAG_RGetRaw: {
          return NTAG(TAG_False);
        }
        case TAG_RInt: {
          return NTAG(TAG_False);
        }
        case TAG_RFloat: {
          return NTAG(TAG_False);
        }
        case TAG_RStr: {
          return NTAG(TAG_False);
        }
        case TAG_RBytes: {
          return NTAG(TAG_False);
        }
        case TAG_RFixed: {
          return NTAG(TAG_False);
        }
        case TAG_RF32: {
          return NTAG(TAG_False);
        }
        case TAG_RNTag: {
          return NTAG(TAG_False);
        }
        case TAG_RStatic: {
          return NTAG(TAG_False);
        }
        case TAG_RTag: {
          return NTAG(TAG_False);
        }
        case TAG_RTagIn: {
          return NTAG(TAG_False);
        }
        case TAG_RRec: {
          return NTAG(TAG_False);
        }
        case TAG_RRecIn: {
          return NTAG(TAG_False);
        }
        case TAG_RField: {
          return NTAG(TAG_False);
        }
        case TAG_RDupE: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldV: {
          return NTAG(TAG_False);
        }
        case TAG_RGetN: {
          return NTAG(TAG_False);
        }
        case TAG_RFieldU: {
          return NTAG(TAG_False);
        }
        case TAG_RGetNU: {
          return NTAG(TAG_False);
        }
        case TAG_RWord: {
          return NTAG(TAG_False);
        }
        case TAG_RTakeField: {
          return NTAG(TAG_False);
        }
        case TAG_RGetLabel: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_RPrim: {
          return NTAG(TAG_False);
        }
        case TAG_RLam: {
          return NTAG(TAG_False);
        }
        case TAG_RCall: {
          return NTAG(TAG_False);
        }
        case TAG_RApply: {
          return NTAG(TAG_False);
        }
        case TAG_RBool: {
          return NTAG(TAG_False);
        }
        case TAG_RAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_RBox: {
          return NTAG(TAG_False);
        }
        case TAG_RUnbox: {
          return NTAG(TAG_False);
        }
        case TAG_RPeek: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimU: {
          return NTAG(TAG_False);
        }
        case TAG_RPrimAt: {
          return NTAG(TAG_False);
        }
        case TAG_RFixU: {
          V v_k_2499 = heff_field(v_es21_2414, 1);
          switch (heff_tag_of(v_es22_2415)) {
          case TAG_Nil: {
            if (heff_intLe_c_lent(MK_INT(0LL), v_k_2499, 1)) {
              HeffT2 v_t_24100 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_es1_242));
              {
                V v_field_24102 = v_t_24100.f[1];
                int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
                if ((v_tag_24101 == ((int64_t)0ULL))) {
                  V v_y_24103 = v_field_24102;
                  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_24103, 0));
                  heff_drop(v_y_24103);
                  return v_ret_24bool;
                } else {
                  heff_drop(v_field_24102);
                  return NTAG(TAG_False);
                }
              }
            } else {
              return NTAG(TAG_False);
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_es22_2415);
          }
        }
        case TAG_RF32U: {
          return NTAG(TAG_False);
        }
        case TAG_RF64U: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_es21_2414);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    }
  }
  default: return heff_nomatch(v_es_241);
  }
}
V g_heff_2ecompile_2ebounds_2estepSum_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2estepSum(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2ebounds_2elengthArray_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RLocal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDup: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStatic: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    V v_x11_2459 = heff_field(v_x1_240, 0);
    V v_x12_2460 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_2459)) {
    case TAG_ArrayLength: {
      switch (heff_tag_of(v_x12_2460)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_e_2461 = heff_field(v_x12_2460, 0);
        V v_x122_2462 = heff_field(v_x12_2460, 1);
        switch (heff_tag_of(v_x122_2462)) {
        case TAG_Nil: {
          HEFF_LAST return g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_2461);
        }
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x122_2462)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x12_2460)}});
      }
    }
    default: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    }
  }
  case TAG_RLam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RUnbox: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2ebounds_2elengthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2elengthOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2elengthOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2ebounds_2elengthOf_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2elengthOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ebounds_2elengthOf(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2ebounds_2erangeOf_24cpr(V v_info_240, V v_x2_241, V v_x3_242) {
top: ;
  V v_indices_243 = heff_take_field(v_info_240, 0);
  V v_defs_244 = heff_take_field(v_info_240, 2);
  V v_arrays_245 = heff_get_n(v_info_240, 1, 3);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_x3_242);
    heff_drop(v_indices_243);
    heff_drop(v_defs_244);
    heff_drop(v_arrays_245);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_i_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      heff_drop(v_indices_243);
      heff_drop(v_defs_244);
      heff_drop(v_arrays_245);
      heff_drop(v_i_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_a_247 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      V v_t_248 = ({ V a_0 = v_i_246; V a_1 = v_indices_243; V r_ = (g_heff_2ecompile_2ebounds_2eelemS(a_0, a_1)); heff_drop(v_indices_243); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_x1_2410 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0, 1, 2, (V[]){v_defs_244, v_a_247}); V a_1 = v_arrays_245; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_Nil: {
          heff_drop(v_i_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x1_2410, 0);
          heff_take_n(v_x1_2410, 1ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_index__array, (V[]){v_i_246, v_x_2411})}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2410)}});
        }
      } else {
        heff_drop(v_defs_244);
        heff_drop(v_arrays_245);
        heff_drop(v_i_246);
        heff_drop(v_a_247);
        heff_drop(v_t_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2ebounds_2erangeOf_24cpr_lam0(V self, V *args) {
  V v_b_249 = args[0];
  V v_defs_244 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_defs_244; V a_1 = NTAG(TAG_Nil); V a_2 = v_b_249; V a_3 = heff_tag_n(TAG_RLocal, 1, (V[]){v_a_247}); V r_ = (g_heff_2ecompile_2ebounds_2esameAs(a_0, a_1, a_2, a_3)); heff_drop(v_defs_244); heff_drop(v_b_249); r_; });
}
V g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2ebounds_2eneedOf_24cpr(V v_info_240, V v_env_241, V v_fl_242, V v_x4_243, V v_x5_244) {
top: ;
  V v_defs_245 = heff_take_field(v_info_240, 2);
  V v_arrays_246 = heff_get_n(v_info_240, 1, 3);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_env_241);
    heff_drop(v_fl_242);
    heff_drop(v_x5_244);
    heff_drop(v_defs_245);
    heff_drop(v_arrays_246);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_y_247 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_env_241);
      heff_drop(v_fl_242);
      heff_drop(v_defs_245);
      heff_drop(v_arrays_246);
      heff_drop(v_y_247);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_i_248 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      V v_x1_249 = (g_list_2ekeepIf_24s1366776885x1474218589(v_i_248, v_env_241));
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        heff_drop(v_fl_242);
        heff_drop(v_defs_245);
        heff_drop(v_arrays_246);
        heff_drop(v_y_247);
        heff_drop(v_i_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 2);
        V v_x1_2413 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0, 1, 2, (V[]){v_defs_245, v_y_247}); V a_1 = v_arrays_246; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
        switch (heff_tag_of(v_x1_2413)) {
        case TAG_Nil: {
          heff_drop(v_fl_242);
          heff_drop(v_i_248);
          heff_drop_rec(v_x_2410, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2414 = heff_field(v_x1_2413, 0);
          heff_take_n(v_x1_2413, 1ULL, 2);
          V v_f_2416 = heff_rec_n(4, shape_index__tested__read__flat, (V[]){v_i_248, heff_get_n(v_x_2410, 1, 2), v_x_2414, v_fl_242});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
V g_heff_2ecompile_2ebounds_2eneedOf_24cpr_lam0(V self, V *args) {
  V v_b_2412 = args[0];
  V v_defs_245 = heff_env(self)[0];
  V v_y_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_defs_245; V a_1 = NTAG(TAG_Nil); V a_2 = v_b_2412; V a_3 = heff_tag_n(TAG_RLocal, 1, (V[]){v_y_247}); V r_ = (g_heff_2ecompile_2ebounds_2esameAs(a_0, a_1, a_2, a_3)); heff_drop(v_defs_245); heff_drop(v_b_2412); r_; });
}
Clo g_heff_2ecompile_2ebounds_2eneedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eneedAt_entry, 5, 0};

V g_heff_2ecompile_2ebounds_2eneedAt(V v_info_240, V v_env_241, V v_p_242, V v_fl_243, V v_es_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(v_info_240, v_env_241, v_p_242, v_fl_243, v_es_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_247});
    } else {
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2eneedAt_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2ebounds_2eneedAt(a[0], a[1], a2, a[3], a4); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ecompile_2ebounds_2eneedsIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2eneedsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eneedsIn_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eneedsIn(V v_info_240, V v_env_241, V v_e_242) {
top: ;
  V v_info_243 = heff_dup(v_info_240);
  V v_env_244 = heff_dup(v_env_241);
  V v_e_245 = heff_dup(v_e_242);
  V v_x3_2494;
  switch (heff_tag_of(v_e_245)) {
  case TAG_RLocal: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RDup: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RClo: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RGet: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RGetRaw: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RInt: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RFloat: {
    heff_take_na(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RStr: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RBytes: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RFixed: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RF32: {
    heff_take_na(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RNTag: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RStatic: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RTag: {
    heff_take_n(v_e_245, 0ULL, 3);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RTagIn: {
    heff_take_n(v_e_245, 0ULL, 5);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RRec: {
    heff_take_n(v_e_245, 0ULL, 3);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RRecIn: {
    heff_take_n(v_e_245, 0ULL, 8);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RField: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RDupE: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RFieldV: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RGetN: {
    heff_take_n(v_e_245, 0ULL, 3);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RFieldU: {
    heff_take_n(v_e_245, 0ULL, 4);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RGetNU: {
    heff_take_n(v_e_245, 0ULL, 5);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RWord: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RTakeField: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RGetLabel: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RPrimFn: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RPrim: {
    V v_p_2464 = heff_field(v_e_245, 0);
    V v_es_2465 = heff_field(v_e_245, 1);
    heff_take_n(v_e_245, 3ULL, 2);
    v_x3_2494 = ({ V a_0 = v_info_243; V a_1 = v_env_244; V a_2 = v_p_2464; V a_3 = NTAG(TAG_Nothing); V a_4 = v_es_2465; V r_ = (g_heff_2ecompile_2ebounds_2eneedAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_p_2464); heff_drop(v_es_2465); r_; });
    break;
  }
  case TAG_RLam: {
    heff_take_n(v_e_245, 0ULL, 4);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RCall: {
    heff_take_n(v_e_245, 0ULL, 4);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RApply: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RBool: {
    heff_take_n(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RAbandon: {
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RBox: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RUnbox: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RPeek: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RPrimU: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RPrimAt: {
    V v_p_2485 = heff_field(v_e_245, 0);
    V v_r_2486 = heff_field(v_e_245, 1);
    V v_es_2487 = heff_field(v_e_245, 2);
    heff_take_n(v_e_245, 7ULL, 3);
    V v_t_2489;
    switch (heff_tag_of(v_p_2485)) {
    case TAG_ArrayIndex: {
      switch (heff_tag_of(v_r_2486)) {
      case TAG_RepV: {
        v_t_2489 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_RepFix: {
        V v_w_2488 = heff_field(v_r_2486, 0);
        V v_ru_24r_2486_24RepFix = heff_take_reuse_n(v_r_2486, 1ULL, 1);
        v_t_2489 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_re_n(v_ru_24r_2486_24RepFix, TAG_RepFix, 1, 1ULL, (V[]){v_w_2488})});
        break;
      }
      case TAG_RepF64: {
        v_t_2489 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_RepInt: {
        v_t_2489 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_r_2486);
      }
      break;
    }
    default: {
      heff_drop(v_r_2486);
      v_t_2489 = NTAG(TAG_Nothing);
      break;
    }
    }
    v_x3_2494 = ({ V a_0 = v_info_243; V a_1 = v_env_244; V a_2 = v_p_2485; V a_3 = v_t_2489; V a_4 = v_es_2487; V r_ = (g_heff_2ecompile_2ebounds_2eneedAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_p_2485); heff_drop(v_es_2487); r_; });
    break;
  }
  case TAG_RFixU: {
    heff_take_n(v_e_245, 0ULL, 2);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RF32U: {
    heff_take_na(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_RF64U: {
    heff_take_na(v_e_245, 0ULL, 1);
    heff_drop(v_info_243);
    heff_drop(v_env_244);
    v_x3_2494 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_245);
  }
  V v_t_2496;
  switch (heff_tag_of(v_x3_2494)) {
  case TAG_Nothing: {
    v_t_2496 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2495 = heff_field(v_x3_2494, 0);
    heff_take_n(v_x3_2494, 1ULL, 1);
    v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2495, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x3_2494);
  }
  V v_f_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2eneedsIn_clo), 2, (V[]){v_info_240, v_env_241}));
  V v_xs_2498 = (g_heff_2ecompile_2eowned_2ekids(v_e_242));
  V v_t_2499 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2498));
  V v_t_24103 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eneedsIn_lam0, 2, 1, (V[]){v_f_2497}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2499; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2499); r_; });
  return (g_prelude_2e_2b_2b(v_t_2496, v_t_24103));
}
V g_heff_2ecompile_2ebounds_2eneedsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eneedsIn(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ebounds_2eneedsIn_lam0(V self, V *args) {
  V v_acc_24100 = args[0];
  V v_x_24101 = args[1];
  V v_f_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_tr(heff_call(v_f_2497, 1, (V[]){v_x_24101}));
  return (g_prelude_2e_2b_2b(v_t_24102, v_acc_24100));
}
V g_heff_2ecompile_2ebounds_2enubReads_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2enubReads_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2enubReads_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2enubReads(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_249 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2enubReads_lam0, 1, 1, (V[]){heff_dup(v_r_242)}); V a_1 = v_seen_240; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_r_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_249);
      V t_0 = v_seen_240;
      V t_1 = v_rs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_249);
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_242), heff_hole()});
      V v_u_2411 = (g_heff_2ecompile_2ebounds_2enubReads_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, heff_dup(v_seen_240)}), v_rs_243, v_cell_2410));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ebounds_2enubReads_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ebounds_2enubReads(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ebounds_2enubReads_lam0(V self, V *args) {
  V v_x2_244 = args[0];
  V v_r_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_r_242)) {
  case TAG_MkPair: {
    V v_a_245 = heff_field(v_r_242, 0);
    V v_r_246 = heff_field(v_r_242, 1);
    heff_take_n(v_r_242, 3ULL, 2);
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_b_247 = heff_field(v_x2_244, 0);
      V v_s_248 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      if (heff_strEq_c(v_a_245, v_b_247)) {
        return ({ V a_0 = v_r_246; V a_1 = v_s_248; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_r_246); heff_drop(v_s_248); r_; });
      } else {
        heff_drop(v_r_246);
        heff_drop(v_s_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ecompile_2ebounds_2enubReads_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2enubReads_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2enubReads_24dps_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2enubReads_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x2_241, 0);
    V v_rs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2410 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2enubReads_24dps_lam0, 1, 1, (V[]){heff_dup(v_r_243)}); V a_1 = v_seen_240; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_r_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_2410);
      V t_0 = v_seen_240;
      V t_1 = v_rs_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_r_243), heff_hole()});
      V v_u_2412 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2411);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, v_seen_240});
      V t_1 = v_rs_244;
      V t_2 = v_u_2412;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ebounds_2enubReads_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ebounds_2enubReads_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ebounds_2enubReads_24dps_lam0(V self, V *args) {
  V v_x2_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_r_243)) {
  case TAG_MkPair: {
    V v_a_246 = heff_field(v_r_243, 0);
    V v_r_247 = heff_field(v_r_243, 1);
    heff_take_n(v_r_243, 3ULL, 2);
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_b_248 = heff_field(v_x2_245, 0);
      V v_s_249 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      if (heff_strEq_c(v_a_246, v_b_248)) {
        return ({ V a_0 = v_r_247; V a_1 = v_s_249; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_r_247); heff_drop(v_s_249); r_; });
      } else {
        heff_drop(v_r_247);
        heff_drop(v_s_249);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_r_243);
  }
}
V g_heff_2ecompile_2ebounds_2eunchecked_lam0(V self, V *args);
V g_heff_2ecompile_2ebounds_2eunchecked_lam1(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2eunchecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eunchecked_entry, 4, 0};

V g_heff_2ecompile_2ebounds_2eunchecked(V v_info_240, V v_flat_241, V v_env_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_RLocal: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RDup: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RClo: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RGet: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RGetRaw: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RInt: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RFloat: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RStr: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RBytes: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RFixed: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RF32: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RNTag: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RStatic: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RTag: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RTagIn: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RRec: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RRecIn: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RField: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RDupE: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RFieldV: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RGetN: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RFieldU: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RGetNU: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RWord: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RTakeField: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RGetLabel: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RPrimFn: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RPrim: {
    V v_p_2462 = heff_field(v_e_243, 0);
    V v_es_2463 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24RPrim = heff_take_reuse_n(v_e_243, 3ULL, 2);
    heff_drop(v_flat_241);
    HeffT2 v_t_2464 = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(v_info_240, v_env_242, v_p_2462, NTAG(TAG_Nothing), v_es_2463));
    {
      V v_field_2466 = v_t_2464.f[1];
      int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
      V v_t_2468;
      if ((v_tag_2465 == ((int64_t)0ULL))) {
        V v_x_2467 = v_field_2466;
        heff_drop(v_x_2467);
        switch (heff_tag_of(v_p_2462)) {
        case TAG_ArrayIndex: {
          v_t_2468 = NTAG(TAG_ArrayIndexIn);
          break;
        }
        case TAG_ArrayPeek: {
          v_t_2468 = NTAG(TAG_ArrayPeekIn);
          break;
        }
        case TAG_ArraySetOwned: {
          v_t_2468 = NTAG(TAG_ArraySetOwnedIn);
          break;
        }
        default: {
          v_t_2468 = v_p_2462;
          break;
        }
        }
      } else {
        heff_drop(v_field_2466);
        v_t_2468 = v_p_2462;
      }
      return heff_tag_re_n(v_ru_24e_243_24RPrim, TAG_RPrim, 2, 2ULL, (V[]){v_t_2468, v_es_2463});
    }
  }
  case TAG_RLam: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RCall: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RApply: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RBool: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RAbandon: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RBox: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RUnbox: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RPeek: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RPrimU: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RPrimAt: {
    V v_e1_2488 = heff_field(v_e_243, 0);
    V v_r_2489 = heff_field(v_e_243, 1);
    V v_es_2490 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24RPrimAt = heff_take_reuse_n(v_e_243, 7ULL, 3);
    switch (heff_tag_of(v_e1_2488)) {
    case TAG_ArrayIndexInAny: {
      heff_drop(v_env_242);
      V v_info_2491 = v_info_240;
      V v_defs_2492 = heff_take_field(v_info_2491, 2);
      V v_arrays_2493 = heff_get_n(v_info_2491, 1, 3);
      V v_flat_2494 = v_flat_241;
      V v_r_2495 = heff_dup(v_r_2489);
      V v_es_2496 = heff_dup(v_es_2490);
      V v_t_24111;
      switch (heff_tag_of(v_es_2496)) {
      case TAG_Nil: {
        heff_drop(v_defs_2492);
        heff_drop(v_arrays_2493);
        heff_drop(v_flat_2494);
        heff_drop(v_r_2495);
        v_t_24111 = NTAG(TAG_ArrayIndexInAny);
        break;
      }
      case TAG_Cons: {
        V v_a_2497 = heff_field(v_es_2496, 0);
        heff_take_n(v_es_2496, 1ULL, 2);
        HeffT2 v_t_2499 = ({ V a_0 = v_a_2497; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(a_0)); heff_drop(v_a_2497); r_; });
        {
          V v_field_24101 = v_t_2499.f[1];
          int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
          if ((v_tag_24100 == ((int64_t)0ULL))) {
            V v_y_24102 = v_field_24101;
            V v_x1_24104 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eunchecked_lam0, 1, 2, (V[]){v_defs_2492, v_y_24102}); V a_1 = v_arrays_2493; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
            switch (heff_tag_of(v_x1_24104)) {
            case TAG_Nil: {
              heff_drop(v_flat_2494);
              heff_drop(v_r_2495);
              v_t_24111 = NTAG(TAG_ArrayIndexInAny);
              break;
            }
            case TAG_Cons: {
              V v_x_24105 = heff_field(v_x1_24104, 0);
              heff_take_n(v_x1_24104, 1ULL, 2);
              V v_t_24110 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eunchecked_lam1, 1, 2, (V[]){v_x_24105, v_r_2495}); V a_1 = v_flat_2494; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_flat_2494); r_; });
              if ((heff_dup(v_t_24110) == NTAG(TAG_True))) {
                heff_drop(v_t_24110);
                v_t_24111 = NTAG(TAG_ArrayIndexIn);
              } else {
                heff_drop(v_t_24110);
                v_t_24111 = NTAG(TAG_ArrayIndexInAny);
              }
              break;
            }
            default: heff_nomatch(v_x1_24104);
            }
          } else {
            heff_drop(v_defs_2492);
            heff_drop(v_arrays_2493);
            heff_drop(v_flat_2494);
            heff_drop(v_r_2495);
            heff_drop(v_field_24101);
            v_t_24111 = NTAG(TAG_ArrayIndexInAny);
          }
        }
        break;
      }
      default: heff_nomatch(v_es_2496);
      }
      return heff_tag_re_n(v_ru_24e_243_24RPrimAt, TAG_RPrimAt, 3, 6ULL, (V[]){v_t_24111, v_r_2489, v_es_2490});
    }
    default: {
      heff_drop(v_flat_241);
      HeffT2 v_t_24112 = (g_heff_2ecompile_2ebounds_2eneedAt_24cpr(v_info_240, v_env_242, v_e1_2488, NTAG(TAG_Nothing), v_es_2490));
      {
        V v_field_24114 = v_t_24112.f[1];
        int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
        V v_t_24116;
        if ((v_tag_24113 == ((int64_t)0ULL))) {
          V v_x_24115 = v_field_24114;
          heff_drop(v_x_24115);
          switch (heff_tag_of(v_e1_2488)) {
          case TAG_ArrayIndex: {
            v_t_24116 = NTAG(TAG_ArrayIndexIn);
            break;
          }
          case TAG_ArrayPeek: {
            v_t_24116 = NTAG(TAG_ArrayPeekIn);
            break;
          }
          case TAG_ArraySetOwned: {
            v_t_24116 = NTAG(TAG_ArraySetOwnedIn);
            break;
          }
          default: {
            v_t_24116 = v_e1_2488;
            break;
          }
          }
        } else {
          heff_drop(v_field_24114);
          v_t_24116 = v_e1_2488;
        }
        return heff_tag_re_n(v_ru_24e_243_24RPrimAt, TAG_RPrimAt, 3, 6ULL, (V[]){v_t_24116, v_r_2489, v_es_2490});
      }
    }
    }
  }
  case TAG_RFixU: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RF32U: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  case TAG_RF64U: {
    heff_drop(v_info_240);
    heff_drop(v_flat_241);
    heff_drop(v_env_242);
    return v_e_243;
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2ebounds_2eunchecked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eunchecked(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ebounds_2eunchecked_lam0(V self, V *args) {
  V v_b_24103 = args[0];
  V v_defs_2492 = heff_env(self)[0];
  V v_y_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_defs_2492; V a_1 = NTAG(TAG_Nil); V a_2 = v_b_24103; V a_3 = heff_tag_n(TAG_RLocal, 1, (V[]){v_y_24102}); V r_ = (g_heff_2ecompile_2ebounds_2esameAs(a_0, a_1, a_2, a_3)); heff_drop(v_defs_2492); heff_drop(v_b_24103); r_; });
}
V g_heff_2ecompile_2ebounds_2eunchecked_lam1(V self, V *args) {
  V v_x2_24107 = args[0];
  V v_x_24105 = heff_env(self)[0];
  V v_r_2495 = heff_env(self)[1];
  switch (heff_tag_of(v_x2_24107)) {
  case TAG_MkPair: {
    V v_b_24108 = heff_field(v_x2_24107, 0);
    V v_s_24109 = heff_field(v_x2_24107, 1);
    heff_take_n(v_x2_24107, 3ULL, 2);
    heff_clo_take(self, 2);
    if (heff_strEq_c(v_x_24105, v_b_24108)) {
      return ({ V a_0 = v_r_2495; V a_1 = v_s_24109; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_r_2495); heff_drop(v_s_24109); r_; });
    } else {
      heff_drop(v_r_2495);
      heff_drop(v_s_24109);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_24107);
  }
}
HEFF_LIT(g_heff_2ecompile_2ebounds_2elabel_str0, 7, "InRange");

static V g_heff_2ecompile_2ebounds_2elabel_val;
static HEFF_ONCE g_heff_2ecompile_2ebounds_2elabel_st;
static V g_heff_2ecompile_2ebounds_2elabel_init(void) {
  return ((V)&g_heff_2ecompile_2ebounds_2elabel_str0);
}
V g_heff_2ecompile_2ebounds_2elabel_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ebounds_2elabel_st)) return g_heff_2ecompile_2ebounds_2elabel_val;
  return heff_global(&g_heff_2ecompile_2ebounds_2elabel_val, &g_heff_2ecompile_2ebounds_2elabel_st, g_heff_2ecompile_2ebounds_2elabel_init);
}
V g_heff_2ecompile_2ebounds_2efixSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2efixSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2efixSt_entry, 6, 0};

V g_heff_2ecompile_2ebounds_2efixSt(V v_go_240, V v_info_241, V v_flat_242, V v_toCopy_243, V v_env_244, V v_s_245) {
top: ;
  switch (heff_tag_of(v_s_245)) {
  case TAG_CDrop: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_flat_242);
    heff_drop(v_env_244);
    return v_s_245;
  }
  case TAG_CLet: {
    V v_x_247 = heff_field(v_s_245, 0);
    V v_e_248 = heff_field(v_s_245, 1);
    V v_ru_24s_245_24CLet = heff_take_reuse_n(v_s_245, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_249 = ({ V a_0 = v_info_241; V a_1 = v_flat_242; V a_2 = v_env_244; V a_3 = v_e_248; V r_ = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(a_0, a_1, a_2, a_3)); heff_drop(v_info_241); heff_drop(v_flat_242); heff_drop(v_env_244); r_; });
    return heff_tag_re_n(v_ru_24s_245_24CLet, TAG_CLet, 2, 1ULL, (V[]){v_x_247, v_t_249});
  }
  case TAG_CDecl: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_flat_242);
    heff_drop(v_env_244);
    return v_s_245;
  }
  case TAG_CSet: {
    V v_x_2411 = heff_field(v_s_245, 0);
    V v_e_2412 = heff_field(v_s_245, 1);
    V v_ru_24s_245_24CSet = heff_take_reuse_n(v_s_245, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2413 = ({ V a_0 = v_info_241; V a_1 = v_flat_242; V a_2 = v_env_244; V a_3 = v_e_2412; V r_ = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(a_0, a_1, a_2, a_3)); heff_drop(v_info_241); heff_drop(v_flat_242); heff_drop(v_env_244); r_; });
    return heff_tag_re_n(v_ru_24s_245_24CSet, TAG_CSet, 2, 1ULL, (V[]){v_x_2411, v_t_2413});
  }
  case TAG_CAbandon: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_flat_242);
    heff_drop(v_env_244);
    return v_s_245;
  }
  case TAG_CIf: {
    V v_c_2414 = heff_field(v_s_245, 0);
    V v_a_2415 = heff_field(v_s_245, 1);
    V v_b_2416 = heff_field(v_s_245, 2);
    V v_ru_24s_245_24CIf = heff_take_reuse_n(v_s_245, 7ULL, 3);
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){heff_dup(v_info_241), v_flat_242, heff_dup(v_env_244)}));
    V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = heff_dup(v_c_2414); V r_ = (g_heff_2ecompile_2eowned_2emapCond(a_0, a_1)); heff_drop(v_t_2417); r_; });
    HeffT3 v_t_2419 = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(v_info_241, v_c_2414));
    {
      V v_field_2421 = v_t_2419.f[1];
      V v_field_2422 = v_t_2419.f[2];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      V v_t_2425;
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_r_2423 = v_field_2421;
        V v_x212_2424 = v_field_2422;
        if ((heff_dup(v_x212_2424) == NTAG(TAG_True))) {
          heff_drop(v_x212_2424);
          v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2423, heff_dup(v_env_244)});
        } else {
          heff_drop(v_r_2423);
          heff_drop(v_x212_2424);
          v_t_2425 = heff_dup(v_env_244);
        }
      } else {
        heff_drop(v_field_2421);
        heff_drop(v_field_2422);
        v_t_2425 = heff_dup(v_env_244);
      }
      V v_t_2426 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){v_t_2425, v_a_2415}));
      HeffT3 v_t_2427 = ({ V a_0 = v_info_241; V a_1 = v_c_2414; HeffT3 r_ = (g_heff_2ecompile_2ebounds_2erangeTest_24cpr(a_0, a_1)); heff_drop(v_info_241); heff_drop(v_c_2414); r_; });
      {
        V v_field_2429 = v_t_2427.f[1];
        V v_field_2430 = v_t_2427.f[2];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        V v_t_2433;
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_r_2431 = v_field_2429;
          V v_x212_2432 = v_field_2430;
          if ((heff_dup(v_x212_2432) == NTAG(TAG_True))) {
            heff_drop(v_r_2431);
            heff_drop(v_x212_2432);
            v_t_2433 = v_env_244;
          } else {
            heff_drop(v_x212_2432);
            v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_2431, v_env_244});
          }
        } else {
          heff_drop(v_field_2429);
          heff_drop(v_field_2430);
          v_t_2433 = v_env_244;
        }
        V v_t_2434 = heff_tr(heff_call(v_go_240, 2, (V[]){v_t_2433, v_b_2416}));
        return heff_tag_at_n(v_ru_24s_245_24CIf, TAG_CIf, 3, (V[]){v_t_2418, v_t_2426, v_t_2434});
      }
    }
  }
  case TAG_CSwitch: {
    V v_e_2435 = heff_field(v_s_245, 0);
    V v_arms_2436 = heff_field(v_s_245, 1);
    V v_r_2437 = heff_field(v_s_245, 2);
    V v_ru_24s_245_24CSwitch = heff_take_reuse_n(v_s_245, 7ULL, 3);
    V v_t_2438 = ({ V a_0 = v_info_241; V a_1 = v_flat_242; V a_2 = v_env_244; V a_3 = v_e_2435; V r_ = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(a_0, a_1, a_2, a_3)); heff_drop(v_info_241); heff_drop(v_flat_242); r_; });
    V v_go_2439 = heff_tr(heff_call(v_go_240, 1, (V[]){v_env_244}));
    V v_t_2450 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2efixSt_lam0, 1, 1, (V[]){v_go_2439}), v_arms_2436));
    return heff_tag_re_n(v_ru_24s_245_24CSwitch, TAG_CSwitch, 3, 4ULL, (V[]){v_t_2438, v_t_2450, v_r_2437});
  }
  case TAG_CReturn: {
    V v_e_2451 = heff_field(v_s_245, 0);
    V v_ru_24s_245_24CReturn = heff_take_reuse_n(v_s_245, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_2452 = ({ V a_0 = v_info_241; V a_1 = v_flat_242; V a_2 = v_env_244; V a_3 = v_e_2451; V r_ = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(a_0, a_1, a_2, a_3)); heff_drop(v_info_241); heff_drop(v_flat_242); heff_drop(v_env_244); r_; });
    return heff_tag_at_n(v_ru_24s_245_24CReturn, TAG_CReturn, 1, (V[]){v_t_2452});
  }
  case TAG_CInPlace: {
    V v_f_2453 = heff_field(v_s_245, 0);
    V v_es_2454 = heff_field(v_s_245, 1);
    V v_ru_24s_245_24CInPlace = heff_take_reuse_n(v_s_245, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2455 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(v_info_241, v_flat_242, v_env_244, v_f_2453));
    V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){v_info_241, v_flat_242, v_env_244}));
    V v_t_2457 = (g_list_2emap(v_t_2456, v_es_2454));
    return heff_tag_at_n(v_ru_24s_245_24CInPlace, TAG_CInPlace, 2, (V[]){v_t_2455, v_t_2457});
  }
  case TAG_CRoomed: {
    V v_f_2458 = heff_field(v_s_245, 0);
    V v_es_2459 = heff_field(v_s_245, 1);
    V v_ru_24s_245_24CRoomed = heff_take_reuse_n(v_s_245, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2460 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(v_info_241, v_flat_242, v_env_244, v_f_2458));
    V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){v_info_241, v_flat_242, v_env_244}));
    V v_t_2462 = (g_list_2emap(v_t_2461, v_es_2459));
    return heff_tag_at_n(v_ru_24s_245_24CRoomed, TAG_CRoomed, 2, (V[]){v_t_2460, v_t_2462});
  }
  case TAG_CTail: {
    V v_f_2463 = heff_field(v_s_245, 0);
    V v_es_2464 = heff_field(v_s_245, 1);
    V v_ru_24s_245_24CTail = heff_take_reuse_n(v_s_245, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2465 = (g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779(v_info_241, v_flat_242, v_env_244, v_f_2463));
    V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){v_info_241, v_flat_242, v_env_244}));
    V v_t_2467 = (g_list_2emap(v_t_2466, v_es_2464));
    return heff_tag_at_n(v_ru_24s_245_24CTail, TAG_CTail, 2, (V[]){v_t_2465, v_t_2467});
  }
  case TAG_CLoop: {
    V v_ps_2468 = heff_field(v_s_245, 0);
    V v_es_2469 = heff_field(v_s_245, 1);
    V v_ru_24s_245_24CLoop = heff_take_reuse_n(v_s_245, 3ULL, 2);
    heff_drop(v_go_240);
    V v_t_2470 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){v_info_241, v_flat_242, v_env_244}));
    V v_es_2471 = (g_list_2emap(v_t_2470, v_es_2469));
    if ((heff_dup(v_toCopy_243) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24s_245_24CLoop, 2);
      return heff_tag_n(TAG_CLoopTo, 3, (V[]){heff_dup(g_heff_2ecompile_2ebounds_2elabel_get()), v_ps_2468, v_es_2471});
    } else {
      return heff_tag_re_n(v_ru_24s_245_24CLoop, TAG_CLoop, 2, 1ULL, (V[]){v_ps_2468, v_es_2471});
    }
  }
  case TAG_CLoopTo: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_flat_242);
    heff_drop(v_env_244);
    return v_s_245;
  }
  case TAG_CLabel: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_flat_242);
    heff_drop(v_env_244);
    return v_s_245;
  }
  case TAG_CJump: {
    V v_g_2476 = heff_field(v_s_245, 0);
    V v_w_2477 = heff_field(v_s_245, 1);
    V v_es_2478 = heff_field(v_s_245, 2);
    V v_ru_24s_245_24CJump = heff_take_reuse_n(v_s_245, 7ULL, 3);
    heff_drop(v_go_240);
    V v_t_2479 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s833355304x641265779_clo), 3, (V[]){v_info_241, v_flat_242, v_env_244}));
    V v_t_2480 = (g_list_2emap(v_t_2479, v_es_2478));
    return heff_tag_re_n(v_ru_24s_245_24CJump, TAG_CJump, 3, 3ULL, (V[]){v_g_2476, v_w_2477, v_t_2480});
  }
  case TAG_CTakeSelf: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_flat_242);
    heff_drop(v_env_244);
    return v_s_245;
  }
  case TAG_CDropSelf: {
    heff_drop(v_go_240);
    heff_drop(v_info_241);
    heff_drop(v_flat_242);
    heff_drop(v_env_244);
    return v_s_245;
  }
  default: return heff_nomatch(v_s_245);
  }
}
V g_heff_2ecompile_2ebounds_2efixSt_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ebounds_2efixSt(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2ebounds_2efixSt_lam0(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_go_2439 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkCArm: {
    V v_t_2441 = heff_field(v_x2_2440, 0);
    V v_fs_2442 = heff_field(v_x2_2440, 1);
    V v_fl_2443 = heff_field(v_x2_2440, 2);
    V v_su_2444 = heff_field(v_x2_2440, 3);
    V v_pl_2445 = heff_field(v_x2_2440, 4);
    V v_tk_2446 = heff_field(v_x2_2440, 5);
    V v_body_2447 = heff_field(v_x2_2440, 6);
    V v_lv_2448 = heff_field(v_x2_2440, 7);
    V v_ru_24x2_2440_24MkCArm = heff_take_reuse_n(v_x2_2440, 255ULL, 8);
    heff_clo_take(self, 1);
    V v_t_2449 = heff_tr(heff_call(v_go_2439, 1, (V[]){v_body_2447}));
    return heff_tag_re_n(v_ru_24x2_2440_24MkCArm, TAG_MkCArm, 8, 191ULL, (V[]){v_t_2441, v_fs_2442, v_fl_2443, v_su_2444, v_pl_2445, v_tk_2446, v_t_2449, v_lv_2448});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
Clo g_heff_2ecompile_2ebounds_2eallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eallOf_entry, 1, 0};

V g_heff_2ecompile_2ebounds_2eallOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_CondTrue);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_c_241);
    }
    case TAG_Cons: {
      V v_t_245 = (g_heff_2ecompile_2ebounds_2eallOf(v_x12_242));
      return heff_tag_n(TAG_CondIf, 3, (V[]){heff_dup(v_c_241), v_t_245, NTAG(TAG_CondFalse)});
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ebounds_2eallOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ebounds_2eallOf(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam1(V self, V *args);
V g_heff_2ecompile_2ebounds_2eboundsWith_lam0(V self, V *args);
V g_heff_2ecompile_2ebounds_2eboundsWith_lam3(V self, V *args);
V g_heff_2ecompile_2ebounds_2eboundsWith_lam2(V self, V *args);
V g_heff_2ecompile_2ebounds_2eboundsWith_lam4(V self, V *args);
V g_heff_2ecompile_2ebounds_2eboundsWith_lam5(V self, V *args);
V g_heff_2ecompile_2ebounds_2eboundsWith_lam7(V self, V *args);
V g_heff_2ecompile_2ebounds_2eboundsWith_lam6(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2eboundsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2eboundsWith_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2eboundsWith(V v_f_240, V v_ds_241, V v_ags_242) {
top: ;
  V v_f_243 = heff_dup(v_f_240);
  V v_ds_244 = heff_dup(v_ds_241);
  V v_ags_245 = heff_dup(v_ags_242);
  V v_t_248;
  switch (heff_tag_of(v_ags_245)) {
  case TAG_Nil: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_ag_246 = heff_dup(heff_field(v_ags_245, 0));
    v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_ag_246));
    break;
  }
  default: heff_nomatch(v_ags_245);
  }
  V v_t_2436 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam0, 1, 3, (V[]){v_f_243, v_ds_244, v_ags_245}); V a_1 = v_t_248; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_ds_2437 = heff_dup(v_ds_241);
  V v_ags_2438 = v_ags_242;
  V v_t_2441;
  switch (heff_tag_of(v_ags_2438)) {
  case TAG_Nil: {
    v_t_2441 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_ag_2439 = heff_dup(heff_field(v_ags_2438, 0));
    v_t_2441 = (g_list_2emap_24s1937570095x2110149801(v_ag_2439));
    break;
  }
  default: heff_nomatch(v_ags_2438);
  }
  V v_t_2452 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam2, 1, 2, (V[]){v_ds_2437, v_ags_2438}); V a_1 = v_t_2441; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_info_2453 = heff_rec_n(3, shape_indices__arrays__defs, (V[]){v_t_2436, v_t_2452, v_ds_241});
  V v_sc_2454 = (g_heff_2ecompile_2ebounds_2escoped(heff_dup(v_info_2453), NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_240, 4))));
  V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_sc_2454)));
  V v_ns_2465 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam4, 2, 1, (V[]){heff_dup(v_info_2453)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2455; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2455); r_; });
  V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_240, 3))));
  V v_owned_2467 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2466; V r_ = (g_list_2efoldl_24s2027973668x1165178200(a_0, a_1)); heff_drop(v_t_2466); r_; });
  V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ns_2465)));
  V v_t_2469 = (g_list_2efoldl_24s323561330x1697851707(NTAG(TAG_Nil), v_t_2468));
  V v_t_2470 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_sc_2454));
  V v_t_2477 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam5, 2, 1, (V[]){heff_dup(v_info_2453)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2470; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2470); r_; });
  V v_t_2478 = (g_prelude_2e_2b_2b(v_t_2469, v_t_2477));
  V v_rs_2479 = (g_heff_2ecompile_2ebounds_2enubReads(NTAG(TAG_Nil), v_t_2478));
  V v_f_2480 = v_f_240;
  V v_info_2481 = v_info_2453;
  V v_owned_2482 = heff_dup(v_owned_2467);
  V v_ns_2483 = v_ns_2465;
  V v_checked_2491 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam6, 1, 1, (V[]){v_owned_2467}); V a_1 = v_rs_2479; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_f_2492 = heff_dup(v_f_2480);
  V v_entry_2493 = heff_take_field(v_f_2492, 3);
  V v_body_2494 = heff_get_n(v_f_2492, 4, 8);
  V v_info_2495 = heff_dup(v_info_2481);
  V v_owned_2496 = heff_dup(v_owned_2482);
  V v_ns_2497 = v_ns_2483;
  V v_checked_2498 = v_checked_2491;
  V v_t_24115;
  switch (heff_tag_of(v_ns_2497)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_checked_2498)) {
    case TAG_Nil: {
      heff_drop(v_body_2494);
      heff_drop(v_info_2495);
      heff_drop(v_owned_2496);
      v_t_24115 = v_entry_2493;
      break;
    }
    case TAG_Cons: {
      V v_t_24101 = (g_heff_2ecompile_2ebounds_2echeckOf(v_ns_2497, heff_dup(v_checked_2498)));
      V v_t_24102 = (g_prelude_2e_2b_2b(v_owned_2496, v_checked_2498));
      V v_t_24103 = (g_heff_2ecompile_2ebounds_2efixStmts(v_info_2495, v_t_24102, NTAG(TAG_True), NTAG(TAG_Nil), v_body_2494));
      V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLabel, 1, (V[]){heff_dup(g_heff_2ecompile_2ebounds_2elabel_get())}), v_t_24103});
      V v_t_24105 = heff_tag_n(TAG_CIf, 3, (V[]){v_t_24101, v_t_24104, NTAG(TAG_Nil)});
      V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24105, NTAG(TAG_Nil)});
      v_t_24115 = (g_prelude_2e_2b_2b(v_entry_2493, v_t_24106));
      break;
    }
    default: heff_nomatch(v_checked_2498);
    }
    break;
  }
  case TAG_Cons: {
    V v_t_24109 = (g_heff_2ecompile_2ebounds_2echeckOf(v_ns_2497, heff_dup(v_checked_2498)));
    V v_t_24110 = (g_prelude_2e_2b_2b(v_owned_2496, v_checked_2498));
    V v_t_24111 = (g_heff_2ecompile_2ebounds_2efixStmts(v_info_2495, v_t_24110, NTAG(TAG_True), NTAG(TAG_Nil), v_body_2494));
    V v_t_24112 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLabel, 1, (V[]){heff_dup(g_heff_2ecompile_2ebounds_2elabel_get())}), v_t_24111});
    V v_t_24113 = heff_tag_n(TAG_CIf, 3, (V[]){v_t_24109, v_t_24112, NTAG(TAG_Nil)});
    V v_t_24114 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, NTAG(TAG_Nil)});
    v_t_24115 = (g_prelude_2e_2b_2b(v_entry_2493, v_t_24114));
    break;
  }
  default: heff_nomatch(v_ns_2497);
  }
  V v_t_24116 = ({ V rv_0 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_info_2481, 6ULL, 3, shape_indices__arrays__defs, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_24117 = (g_heff_2ecompile_2ebounds_2efixStmts(v_t_24116, v_owned_2482, NTAG(TAG_False), NTAG(TAG_Nil), heff_take_field(v_f_2480, 4)));
  return ({ V rv_3 = v_t_24115; V rv_4 = v_t_24117; V rr_ = heff_rec_reuse_nf(v_f_2480, 231ULL, 8, shape_key__params__lent__entry__body__reprs__ret__wrapper, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2ecompile_2ebounds_2eboundsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ebounds_2eboundsWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam1(V self, V *args) {
  V v_ag_2417 = args[0];
  V v_x_249 = heff_env(self)[0];
  HeffT2 v_t_2418 = ({ V a_0 = v_x_249; V a_1 = v_ag_2417; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2egivenTo_24cpr(a_0, a_1)); heff_drop(v_ag_2417); r_; });
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2420;
      switch (heff_tag_of(v_x_2421)) {
      case TAG_RPrimU: {
        V v_e1_2422 = heff_dup(heff_field(v_x_2421, 0));
        switch (heff_tag_of(v_e1_2422)) {
        case TAG_WordAdd: {
          switch (heff_tag_of(v_x_2421)) {
          case TAG_RPrimU: {
            V v_es_2425 = heff_field(v_x_2421, 1);
            heff_take_n(v_x_2421, 2ULL, 2);
            heff_clo_take(self, 1);
            return ({ V a_0 = v_x_249; V a_1 = v_es_2425; V r_ = (g_heff_2ecompile_2ebounds_2estepSum(a_0, a_1)); heff_drop(v_x_249); heff_drop(v_es_2425); r_; });
          }
          default: return heff_nomatch(v_x_2421);
          }
        }
        default: {
          heff_drop(v_e1_2422);
          HeffT2 v_t_2426 = ({ V a_0 = v_x_2421; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(a_0)); heff_drop_tag(v_x_2421, 2); r_; });
          {
            V v_field_2428 = v_t_2426.f[1];
            int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
            if ((v_tag_2427 == ((int64_t)0ULL))) {
              V v_y_2429 = v_field_2428;
              V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_249, v_y_2429, 0));
              heff_drop(self);
              heff_drop(v_y_2429);
              return v_ret_24bool;
            } else {
              heff_drop(self);
              heff_drop(v_field_2428);
              return NTAG(TAG_False);
            }
          }
        }
        }
      }
      default: {
        HeffT2 v_t_2430 = ({ V a_0 = v_x_2421; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(a_0)); heff_drop(v_x_2421); r_; });
        {
          V v_field_2432 = v_t_2430.f[1];
          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
          if ((v_tag_2431 == ((int64_t)0ULL))) {
            V v_y_2433 = v_field_2432;
            V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_249, v_y_2433, 0));
            heff_drop(self);
            heff_drop(v_y_2433);
            return v_ret_24bool;
          } else {
            heff_drop(self);
            heff_drop(v_field_2432);
            return NTAG(TAG_False);
          }
        }
      }
      }
    } else {
      heff_drop(self);
      heff_drop(v_field_2420);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_243 = heff_env(self)[0];
  V v_ds_244 = heff_env(self)[1];
  V v_ags_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_f_243, 5, 8); V a_1 = v_x_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_RepV: {
        heff_drop(v_x_249);
        heff_drop(v_ds_244);
        heff_drop(v_ags_245);
        return NTAG(TAG_False);
      }
      case TAG_RepFix: {
        heff_take_n(v_x_2413, 0ULL, 1);
        heff_drop(v_x_249);
        heff_drop(v_ds_244);
        heff_drop(v_ags_245);
        return NTAG(TAG_False);
      }
      case TAG_RepF64: {
        heff_drop(v_x_249);
        heff_drop(v_ds_244);
        heff_drop(v_ags_245);
        return NTAG(TAG_False);
      }
      case TAG_RepInt: {
        V v_t_2415 = (g_list_2ekeepIf_24s708019417x1279437633(v_x_249, v_ds_244));
        V v_x1_2416 = (g_list_2emap_24s1173914895x100384474(v_t_2415));
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nil: {
          return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam1, 1, 1, (V[]){v_x_249}); V a_1 = v_ags_245; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_ags_245); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2416, 0ULL, 2);
          heff_drop(v_x_249);
          heff_drop(v_ags_245);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x1_2416);
        }
      }
      default: return heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_x_249);
      heff_drop(v_ds_244);
      heff_drop(v_ags_245);
      heff_drop(v_field_2412);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam3(V self, V *args) {
  V v_ag_2445 = args[0];
  V v_b_2442 = heff_env(self)[0];
  V v_ds_2437 = heff_env(self)[1];
  HeffT2 v_t_2446 = ({ V a_0 = v_b_2442; V a_1 = v_ag_2445; HeffT2 r_ = (g_heff_2ecompile_2ebounds_2egivenTo_24cpr(a_0, a_1)); heff_drop(v_ag_2445); r_; });
  {
    V v_field_2448 = v_t_2446.f[1];
    int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
    if ((v_tag_2447 == ((int64_t)0ULL))) {
      V v_x_2449 = v_field_2448;
      heff_clo_take(self, 2);
      return ({ V a_0 = v_ds_2437; V a_1 = NTAG(TAG_Nil); V a_2 = v_b_2442; V a_3 = v_x_2449; V r_ = (g_heff_2ecompile_2ebounds_2esameAs(a_0, a_1, a_2, a_3)); heff_drop(v_ds_2437); heff_drop(v_b_2442); r_; });
    } else {
      heff_drop(self);
      heff_drop(v_field_2448);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam2(V self, V *args) {
  V v_b_2442 = args[0];
  V v_ds_2437 = heff_env(self)[0];
  V v_ags_2438 = heff_env(self)[1];
  V v_t_2443 = (g_list_2ekeepIf_24s708019417x1279437633(v_b_2442, heff_dup(v_ds_2437)));
  V v_x1_2444 = (g_list_2emap_24s1173914895x100384474(v_t_2443));
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_Nil: {
    heff_clo_take(self, 2);
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam3, 1, 2, (V[]){v_b_2442, v_ds_2437}); V a_1 = v_ags_2438; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_ags_2438); r_; });
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2444, 0ULL, 2);
    heff_drop(v_b_2442);
    heff_drop(self);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2444);
  }
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam4(V self, V *args) {
  V v_acc_2456 = args[0];
  V v_x_2457 = args[1];
  V v_info_2453 = heff_env(self)[0];
  V v_t_2460;
  switch (heff_tag_of(v_x_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_dup(heff_field(v_x_2457, 0));
    v_t_2460 = v_x_2458;
    break;
  }
  default: heff_nomatch(v_x_2457);
  }
  V v_t_2463;
  switch (heff_tag_of(v_x_2457)) {
  case TAG_MkPair: {
    V v_y_2462 = heff_field(v_x_2457, 1);
    heff_take_n(v_x_2457, 2ULL, 2);
    v_t_2463 = v_y_2462;
    break;
  }
  default: heff_nomatch(v_x_2457);
  }
  heff_clo_take(self, 1);
  V v_t_2464 = (g_heff_2ecompile_2ebounds_2eneedsIn(v_info_2453, v_t_2460, v_t_2463));
  return (g_prelude_2e_2b_2b(v_t_2464, v_acc_2456));
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam5(V self, V *args) {
  V v_acc_2471 = args[0];
  V v_x_2472 = args[1];
  V v_info_2453 = heff_env(self)[0];
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_y_2474 = heff_field(v_x_2472, 1);
    heff_take_n(v_x_2472, 2ULL, 2);
    v_t_2475 = v_y_2474;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  heff_clo_take(self, 1);
  V v_t_2476 = (g_heff_2ecompile_2ebounds_2ereadsIn(v_info_2453, v_t_2475));
  return (g_prelude_2e_2b_2b(v_t_2476, v_acc_2471));
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam7(V self, V *args) {
  V v_x2_2485 = args[0];
  V v_r_2484 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_r_2484)) {
  case TAG_MkPair: {
    V v_a_2486 = heff_field(v_r_2484, 0);
    V v_r_2487 = heff_field(v_r_2484, 1);
    heff_take_n(v_r_2484, 3ULL, 2);
    switch (heff_tag_of(v_x2_2485)) {
    case TAG_MkPair: {
      V v_b_2488 = heff_field(v_x2_2485, 0);
      V v_s_2489 = heff_field(v_x2_2485, 1);
      heff_take_n(v_x2_2485, 3ULL, 2);
      if (heff_strEq_c(v_a_2486, v_b_2488)) {
        return ({ V a_0 = v_r_2487; V a_1 = v_s_2489; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_r_2487); heff_drop(v_s_2489); r_; });
      } else {
        heff_drop(v_r_2487);
        heff_drop(v_s_2489);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_2485);
    }
  }
  default: return heff_nomatch(v_r_2484);
  }
}
V g_heff_2ecompile_2ebounds_2eboundsWith_lam6(V self, V *args) {
  V v_r_2484 = args[0];
  V v_owned_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2490 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ebounds_2eboundsWith_lam7, 1, 1, (V[]){v_r_2484}); V a_1 = v_owned_2467; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_owned_2467); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2490) == NTAG(TAG_True)));
  heff_drop(v_x1_2490);
  return v_ret_24bool;
}
V g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_lam0(V self, V *args);
V g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_lam1(V self, V *args);
Clo g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_entry, 3, 0};

V g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_RLocal: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RDup: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RClo: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RGet: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RGetRaw: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RInt: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RFloat: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RStr: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RBytes: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RFixed: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RF32: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RNTag: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RStatic: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RTag: {
    V v_t_2418 = heff_field(v_x2_242, 0);
    V v_b_2419 = heff_field(v_x2_242, 1);
    V v_es_2420 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24RTag = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_2422 = (g_list_2emap(v_t_2421, v_es_2420));
    V v_a_2423 = heff_tag_re_n(v_ru_24x2_242_24RTag, TAG_RTag, 3, 3ULL, (V[]){v_t_2418, v_b_2419, v_t_2422});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2423);
  }
  case TAG_RTagIn: {
    V v_e_2424 = heff_field(v_x2_242, 0);
    V v_t_2425 = heff_field(v_x2_242, 1);
    V v_b_2426 = heff_field(v_x2_242, 2);
    V v_sm_2427 = heff_field(v_x2_242, 3);
    V v_es_2428 = heff_field(v_x2_242, 4);
    V v_ru_24x2_242_24RTagIn = heff_take_reuse_n(v_x2_242, 31ULL, 5);
    V v_t_2429 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2424));
    V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_2431 = (g_list_2emap(v_t_2430, v_es_2428));
    V v_a_2432 = heff_tag_re_n(v_ru_24x2_242_24RTagIn, TAG_RTagIn, 5, 14ULL, (V[]){v_t_2429, v_t_2425, v_b_2426, v_sm_2427, v_t_2431});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2432);
  }
  case TAG_RRec: {
    V v_ls_2433 = heff_field(v_x2_242, 0);
    V v_b_2434 = heff_field(v_x2_242, 1);
    V v_es_2435 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24RRec = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_2437 = (g_list_2emap(v_t_2436, v_es_2435));
    V v_a_2438 = heff_tag_re_n(v_ru_24x2_242_24RRec, TAG_RRec, 3, 3ULL, (V[]){v_ls_2433, v_b_2434, v_t_2437});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2438);
  }
  case TAG_RRecIn: {
    V v_x_2439 = heff_field(v_x2_242, 0);
    V v_n_2440 = heff_field(v_x2_242, 1);
    V v_k_2441 = heff_field(v_x2_242, 2);
    V v_g_2442 = heff_field(v_x2_242, 3);
    V v_s_2443 = heff_field(v_x2_242, 4);
    V v_ls_2444 = heff_field(v_x2_242, 5);
    V v_fs_2445 = heff_field(v_x2_242, 6);
    V v_sure_2446 = heff_field(v_x2_242, 7);
    V v_ru_24x2_242_24RRecIn = heff_take_reuse_n(v_x2_242, 255ULL, 8);
    V v_t_2455 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_lam0, 1, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_fs_2445));
    V v_a_2456 = heff_tag_re_n(v_ru_24x2_242_24RRecIn, TAG_RRecIn, 8, 191ULL, (V[]){v_x_2439, v_n_2440, v_k_2441, v_g_2442, v_s_2443, v_ls_2444, v_t_2455, v_sure_2446});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2456);
  }
  case TAG_RField: {
    V v_e_2457 = heff_field(v_x2_242, 0);
    V v_i_2458 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RField = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2459 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2457));
    V v_a_2460 = heff_tag_re_n(v_ru_24x2_242_24RField, TAG_RField, 2, 2ULL, (V[]){v_t_2459, v_i_2458});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2460);
  }
  case TAG_RDupE: {
    V v_e_2461 = heff_field(v_x2_242, 0);
    V v_ru_24x2_242_24RDupE = heff_take_reuse_n(v_x2_242, 1ULL, 1);
    V v_t_2462 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2461));
    V v_a_2463 = heff_tag_at_n(v_ru_24x2_242_24RDupE, TAG_RDupE, 1, (V[]){v_t_2462});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2463);
  }
  case TAG_RFieldV: {
    V v_e_2464 = heff_field(v_x2_242, 0);
    V v_i_2465 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RFieldV = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2466 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2464));
    V v_a_2467 = heff_tag_re_n(v_ru_24x2_242_24RFieldV, TAG_RFieldV, 2, 2ULL, (V[]){v_t_2466, v_i_2465});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2467);
  }
  case TAG_RGetN: {
    V v_e_2468 = heff_field(v_x2_242, 0);
    V v_i_2469 = heff_field(v_x2_242, 1);
    V v_n_2470 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24RGetN = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_2471 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2468));
    V v_a_2472 = heff_tag_re_n(v_ru_24x2_242_24RGetN, TAG_RGetN, 3, 6ULL, (V[]){v_t_2471, v_i_2469, v_n_2470});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2472);
  }
  case TAG_RFieldU: {
    V v_r_2473 = heff_field(v_x2_242, 0);
    V v_s_2474 = heff_field(v_x2_242, 1);
    V v_e_2475 = heff_field(v_x2_242, 2);
    V v_i_2476 = heff_field(v_x2_242, 3);
    V v_ru_24x2_242_24RFieldU = heff_take_reuse_n(v_x2_242, 15ULL, 4);
    V v_t_2477 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2475));
    V v_a_2478 = heff_tag_re_n(v_ru_24x2_242_24RFieldU, TAG_RFieldU, 4, 11ULL, (V[]){v_r_2473, v_s_2474, v_t_2477, v_i_2476});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2478);
  }
  case TAG_RGetNU: {
    V v_r_2479 = heff_field(v_x2_242, 0);
    V v_s_2480 = heff_field(v_x2_242, 1);
    V v_e_2481 = heff_field(v_x2_242, 2);
    V v_i_2482 = heff_field(v_x2_242, 3);
    V v_n_2483 = heff_field(v_x2_242, 4);
    V v_ru_24x2_242_24RGetNU = heff_take_reuse_n(v_x2_242, 31ULL, 5);
    V v_t_2484 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2481));
    V v_a_2485 = heff_tag_re_n(v_ru_24x2_242_24RGetNU, TAG_RGetNU, 5, 27ULL, (V[]){v_r_2479, v_s_2480, v_t_2484, v_i_2482, v_n_2483});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2485);
  }
  case TAG_RWord: {
    V v_r_2486 = heff_field(v_x2_242, 0);
    V v_e_2487 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RWord = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2488 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2487));
    V v_a_2489 = heff_tag_re_n(v_ru_24x2_242_24RWord, TAG_RWord, 2, 1ULL, (V[]){v_r_2486, v_t_2488});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2489);
  }
  case TAG_RTakeField: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RGetLabel: {
    V v_e_2492 = heff_field(v_x2_242, 0);
    V v_l_2493 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RGetLabel = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2494 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_2492));
    V v_a_2495 = heff_tag_re_n(v_ru_24x2_242_24RGetLabel, TAG_RGetLabel, 2, 2ULL, (V[]){v_t_2494, v_l_2493});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_2495);
  }
  case TAG_RPrimFn: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RPrim: {
    V v_p_2497 = heff_field(v_x2_242, 0);
    V v_es_2498 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RPrim = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2499 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24100 = (g_list_2emap(v_t_2499, v_es_2498));
    V v_a_24101 = heff_tag_re_n(v_ru_24x2_242_24RPrim, TAG_RPrim, 2, 1ULL, (V[]){v_p_2497, v_t_24100});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24101);
  }
  case TAG_RLam: {
    V v_xs_24102 = heff_field(v_x2_242, 0);
    V v_fv_24103 = heff_field(v_x2_242, 1);
    V v_held_24104 = heff_field(v_x2_242, 2);
    V v_body_24105 = heff_field(v_x2_242, 3);
    V v_ru_24x2_242_24RLam = heff_take_reuse_n(v_x2_242, 15ULL, 4);
    V v_t_24106 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24107 = (g_list_2emap(v_t_24106, v_held_24104));
    V v_a_24108 = heff_tag_re_n(v_ru_24x2_242_24RLam, TAG_RLam, 4, 11ULL, (V[]){v_xs_24102, v_fv_24103, v_t_24107, v_body_24105});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24108);
  }
  case TAG_RCall: {
    V v_g_24109 = heff_field(v_x2_242, 0);
    V v_tr_24110 = heff_field(v_x2_242, 1);
    V v_w_24111 = heff_field(v_x2_242, 2);
    V v_args_24112 = heff_field(v_x2_242, 3);
    V v_ru_24x2_242_24RCall = heff_take_reuse_n(v_x2_242, 15ULL, 4);
    V v_f_24113 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24124 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_lam1, 1, 1, (V[]){v_f_24113}), v_args_24112));
    V v_a_24125 = heff_tag_re_n(v_ru_24x2_242_24RCall, TAG_RCall, 4, 7ULL, (V[]){v_g_24109, v_tr_24110, v_w_24111, v_t_24124});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24125);
  }
  case TAG_RApply: {
    V v_g_24126 = heff_field(v_x2_242, 0);
    V v_es_24127 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RApply = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24128 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_g_24126));
    V v_t_24129 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24130 = (g_list_2emap(v_t_24129, v_es_24127));
    V v_a_24131 = heff_tag_at_n(v_ru_24x2_242_24RApply, TAG_RApply, 2, (V[]){v_t_24128, v_t_24130});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24131);
  }
  case TAG_RBool: {
    V v_c_24132 = heff_field(v_x2_242, 0);
    V v_ru_24x2_242_24RBool = heff_take_reuse_n(v_x2_242, 1ULL, 1);
    V v_t_24133 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24134 = ({ V a_0 = v_t_24133; V a_1 = v_c_24132; V r_ = (g_heff_2ecompile_2eowned_2emapCond(a_0, a_1)); heff_drop(v_t_24133); r_; });
    V v_a_24135 = heff_tag_at_n(v_ru_24x2_242_24RBool, TAG_RBool, 1, (V[]){v_t_24134});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24135);
  }
  case TAG_RAbandon: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RBox: {
    V v_r_24136 = heff_field(v_x2_242, 0);
    V v_e_24137 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RBox = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24138 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_24137));
    V v_a_24139 = heff_tag_re_n(v_ru_24x2_242_24RBox, TAG_RBox, 2, 1ULL, (V[]){v_r_24136, v_t_24138});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24139);
  }
  case TAG_RUnbox: {
    V v_r_24140 = heff_field(v_x2_242, 0);
    V v_e_24141 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RUnbox = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24142 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_24141));
    V v_a_24143 = heff_tag_re_n(v_ru_24x2_242_24RUnbox, TAG_RUnbox, 2, 1ULL, (V[]){v_r_24140, v_t_24142});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24143);
  }
  case TAG_RPeek: {
    V v_r_24144 = heff_field(v_x2_242, 0);
    V v_e_24145 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RPeek = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24146 = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(v_lit_240, v_lit_241, v_e_24145));
    V v_a_24147 = heff_tag_re_n(v_ru_24x2_242_24RPeek, TAG_RPeek, 2, 1ULL, (V[]){v_r_24144, v_t_24146});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24147);
  }
  case TAG_RPrimU: {
    V v_p_24148 = heff_field(v_x2_242, 0);
    V v_es_24149 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24RPrimU = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_24150 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24151 = (g_list_2emap(v_t_24150, v_es_24149));
    V v_a_24152 = heff_tag_re_n(v_ru_24x2_242_24RPrimU, TAG_RPrimU, 2, 1ULL, (V[]){v_p_24148, v_t_24151});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24152);
  }
  case TAG_RPrimAt: {
    V v_p_24153 = heff_field(v_x2_242, 0);
    V v_r_24154 = heff_field(v_x2_242, 1);
    V v_es_24155 = heff_field(v_x2_242, 2);
    V v_ru_24x2_242_24RPrimAt = heff_take_reuse_n(v_x2_242, 7ULL, 3);
    V v_t_24156 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_clo), 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}));
    V v_t_24157 = (g_list_2emap(v_t_24156, v_es_24155));
    V v_a_24158 = heff_tag_re_n(v_ru_24x2_242_24RPrimAt, TAG_RPrimAt, 3, 3ULL, (V[]){v_p_24153, v_r_24154, v_t_24157});
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_a_24158);
  }
  case TAG_RFixU: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RF32U: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  case TAG_RF64U: {
    HEFF_LAST return g_heff_2ecompile_2etested_2estep(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x2_242);
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_lam0(V self, V *args) {
  V v_p_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_t_2450;
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_dup(heff_field(v_p_2447, 0));
    v_t_2450 = v_x_2448;
    break;
  }
  default: heff_nomatch(v_p_2447);
  }
  V v_t_2453;
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_y_2452 = heff_field(v_p_2447, 1);
    heff_take_n(v_p_2447, 2ULL, 2);
    v_t_2453 = v_y_2452;
    break;
  }
  default: heff_nomatch(v_p_2447);
  }
  heff_clo_take(self, 2);
  V v_t_2454 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_t_2453; V r_ = (g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447(a_0, a_1, a_2)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, v_t_2454});
}
V g_heff_2ecompile_2ebounds_2emapExp_24s722817936x1203592447_lam1(V self, V *args) {
  V v_a_24114 = args[0];
  V v_f_24113 = heff_env(self)[0];
  switch (heff_tag_of(v_a_24114)) {
  case TAG_Given: {
    V v_e_24115 = heff_field(v_a_24114, 0);
    V v_ru_24a_24114_24Given = heff_take_reuse_n(v_a_24114, 1ULL, 1);
    heff_clo_take(self, 1);
    V v_t_24116 = heff_tr(heff_call(v_f_24113, 1, (V[]){v_e_24115}));
    return heff_tag_at_n(v_ru_24a_24114_24Given, TAG_Given, 1, (V[]){v_t_24116});
  }
  case TAG_GivenU: {
    V v_r_24117 = heff_field(v_a_24114, 0);
    V v_e_24118 = heff_field(v_a_24114, 1);
    V v_ru_24a_24114_24GivenU = heff_take_reuse_n(v_a_24114, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_t_24119 = heff_tr(heff_call(v_f_24113, 1, (V[]){v_e_24118}));
    return heff_tag_re_n(v_ru_24a_24114_24GivenU, TAG_GivenU, 2, 1ULL, (V[]){v_r_24117, v_t_24119});
  }
  case TAG_LentVar: {
    heff_drop(self);
    return v_a_24114;
  }
  case TAG_LentValue: {
    V v_e_24122 = heff_field(v_a_24114, 0);
    V v_ru_24a_24114_24LentValue = heff_take_reuse_n(v_a_24114, 1ULL, 1);
    heff_clo_take(self, 1);
    V v_t_24123 = heff_tr(heff_call(v_f_24113, 1, (V[]){v_e_24122}));
    return heff_tag_at_n(v_ru_24a_24114_24LentValue, TAG_LentValue, 1, (V[]){v_t_24123});
  }
  default: return heff_nomatch(v_a_24114);
  }
}
Clo g_heff_2ecompile_2ebounds_2evarOf_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ebounds_2evarOf_24tok1_entry, 2, 0};

V g_heff_2ecompile_2ebounds_2evarOf_24tok1(V v_tok_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2ebounds_2evarOf_24cpr(v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ebounds_2evarOf_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ebounds_2evarOf_24tok1(a[0], a1); heff_drop(a1); return r;
}