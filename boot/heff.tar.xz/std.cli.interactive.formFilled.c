// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_flags 298871457
#define LBL_pos 320718
#define LBL_shape 310758331
V g_list_2emap_24s1132197644x1537385180(V, V);
V g_list_2emap_24s1132197644x1537385180_entry(V self, V *a);
extern Clo g_list_2emap_24s1132197644x1537385180_clo;
V g_list_2ezipWith_24s1926123592x638606550(V, V);
V g_list_2ezipWith_24s1926123592x638606550_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1926123592x638606550_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2ecli_2einteractive_2eformFilled_2eslots_240(V, V);
V g_std_2ecli_2einteractive_2eformFilled_2eslots_240_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformFilled_2eslots_240_clo;
V g_std_2ecli_2einteractive_2eposGiven(V, V);
V g_std_2ecli_2einteractive_2eposGiven_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eposGiven_clo;
Clo g_std_2ecli_2einteractive_2eformFilled_2eslots_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformFilled_2eslots_240_entry, 2, 0};

V g_std_2ecli_2einteractive_2eformFilled_2eslots_240(V v_e_240, V v_sp_241) {
top: ;
  V v_pos_242 = heff_take_field(v_sp_241, 0);
  V v_flags_243 = heff_get_n(v_sp_241, 1, 2);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_e_240, 2)), 1, 2);
  V v_t_245 = (g_std_2ecli_2einteractive_2eposGiven(v_t_244, v_pos_242));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_240, 2)), 1, 2);
  V v_t_247 = (g_list_2ezipWith_24s1926123592x638606550(v_t_246, v_t_245));
  V v_t_248 = heff_get_n(heff_get_n(v_e_240, 2, 3), 0, 2);
  V v_t_249 = (g_list_2emap_24s1132197644x1537385180(v_flags_243, v_t_248));
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_247, v_t_249);
}
V g_std_2ecli_2einteractive_2eformFilled_2eslots_240_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformFilled_2eslots_240(a[0], a[1]);
}