// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_list_2eany_24s225693436x2092061921(V);
V g_list_2eany_24s225693436x2092061921_entry(V self, V *a);
extern Clo g_list_2eany_24s225693436x2092061921_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      heff_take_nf(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EPi: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EMatch: {
      V v_s_2435 = heff_field(v_x11_241, 0);
      V v_alts_2436 = heff_field(v_x11_241, 1);
      V v_ru_24x11_241_24EMatch = heff_take_reuse_n(v_x11_241, 3ULL, 2);
      V v_t_2437 = heff_tag_re_n(v_ru_24x1_240_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_241_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_2435, heff_dup(v_alts_2436)}), v_x12_242});
      V v_x1_2438 = ({ V a_0 = v_t_2437; V r_ = (g_heff_2esyntax_2epresyntax_2eisControl(a_0)); heff_drop_tag(v_t_2437, 2); r_; });
      if (!(heff_dup(v_x1_2438) == NTAG(TAG_True))) {
        heff_drop(v_alts_2436);
        heff_drop(v_x1_2438);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_x1_2438);
        HEFF_LAST return g_list_2eany_24s225693436x2092061921(v_alts_2436);
      }
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EFor: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_EBreak: {
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    case TAG_ETry: {
      V v_x111_2459 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      switch (heff_tag_of(v_x111_2459)) {
      case TAG_MkTry: {
        V v_body_2461 = heff_field(v_x111_2459, 1);
        V v_c_2462 = heff_field(v_x111_2459, 2);
        heff_take_n(v_x111_2459, 6ULL, 3);
        V v_x1_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_2461));
        switch (heff_tag_of(v_x1_2463)) {
        case TAG_Nil: {
          heff_drop(v_c_2462);
          return NTAG(TAG_True);
        }
        case TAG_Cons: {
          V v_x_2464 = heff_field(v_x1_2463, 0);
          heff_take_n(v_x1_2463, 1ULL, 2);
          switch (heff_tag_of(v_x_2464)) {
          case TAG_At: {
            V v_it11_2466 = heff_field(v_x_2464, 0);
            heff_take_n(v_x_2464, 1ULL, 2);
            switch (heff_tag_of(v_it11_2466)) {
            case TAG_StmtBind: {
              heff_take_n(v_it11_2466, 0ULL, 3);
              heff_drop(v_c_2462);
              return NTAG(TAG_True);
            }
            case TAG_StmtLet: {
              heff_take_n(v_it11_2466, 0ULL, 2);
              heff_drop(v_c_2462);
              return NTAG(TAG_True);
            }
            case TAG_StmtExpr: {
              V v_e_2473 = heff_field(v_it11_2466, 0);
              heff_take_n(v_it11_2466, 1ULL, 1);
              V v_t_2474 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2473));
              if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
                heff_drop(v_c_2462);
                heff_drop(v_t_2474);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_t_2474);
                V v_t_2477;
                switch (heff_tag_of(v_c_2462)) {
                case TAG_MkCatchArm: {
                  V v_ss_2476 = heff_field(v_c_2462, 1);
                  heff_take_n(v_c_2462, 2ULL, 2);
                  v_t_2477 = v_ss_2476;
                  break;
                }
                default: heff_nomatch(v_c_2462);
                }
                V v_x1_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2477));
                switch (heff_tag_of(v_x1_2478)) {
                case TAG_Nil: {
                  return NTAG(TAG_True);
                }
                case TAG_Cons: {
                  V v_x_2479 = heff_field(v_x1_2478, 0);
                  heff_take_n(v_x1_2478, 1ULL, 2);
                  switch (heff_tag_of(v_x_2479)) {
                  case TAG_At: {
                    V v_it11_2481 = heff_field(v_x_2479, 0);
                    heff_take_n(v_x_2479, 1ULL, 2);
                    switch (heff_tag_of(v_it11_2481)) {
                    case TAG_StmtBind: {
                      heff_take_n(v_it11_2481, 0ULL, 3);
                      return NTAG(TAG_True);
                    }
                    case TAG_StmtLet: {
                      heff_take_n(v_it11_2481, 0ULL, 2);
                      return NTAG(TAG_True);
                    }
                    case TAG_StmtExpr: {
                      V v_e_2488 = heff_field(v_it11_2481, 0);
                      heff_take_n(v_it11_2481, 1ULL, 1);
                      V t_0 = v_e_2488;
                      v_x1_240 = t_0;
                      goto top;
                    }
                    case TAG_StmtLetMut: {
                      heff_take_n(v_it11_2481, 0ULL, 3);
                      return NTAG(TAG_True);
                    }
                    case TAG_StmtLetElse: {
                      heff_take_n(v_it11_2481, 0ULL, 3);
                      return NTAG(TAG_True);
                    }
                    default: return heff_nomatch(v_it11_2481);
                    }
                  }
                  default: return heff_nomatch(v_x_2479);
                  }
                }
                default: return heff_nomatch(v_x1_2478);
                }
              }
            }
            case TAG_StmtLetMut: {
              heff_take_n(v_it11_2466, 0ULL, 3);
              heff_drop(v_c_2462);
              return NTAG(TAG_True);
            }
            case TAG_StmtLetElse: {
              heff_take_n(v_it11_2466, 0ULL, 3);
              heff_drop(v_c_2462);
              return NTAG(TAG_True);
            }
            default: return heff_nomatch(v_it11_2466);
            }
          }
          default: return heff_nomatch(v_x_2464);
          }
        }
        default: return heff_nomatch(v_x1_2463);
        }
      }
      default: return heff_nomatch(v_x111_2459);
      }
    }
    case TAG_EWith: {
      V v_body_24104 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 8ULL, 4);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_x1_24105 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_24104));
      switch (heff_tag_of(v_x1_24105)) {
      case TAG_Nil: {
        return NTAG(TAG_True);
      }
      case TAG_Cons: {
        V v_x_24106 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 2);
        switch (heff_tag_of(v_x_24106)) {
        case TAG_At: {
          V v_it11_24108 = heff_field(v_x_24106, 0);
          heff_take_n(v_x_24106, 1ULL, 2);
          switch (heff_tag_of(v_it11_24108)) {
          case TAG_StmtBind: {
            heff_take_n(v_it11_24108, 0ULL, 3);
            return NTAG(TAG_True);
          }
          case TAG_StmtLet: {
            heff_take_n(v_it11_24108, 0ULL, 2);
            return NTAG(TAG_True);
          }
          case TAG_StmtExpr: {
            V v_e_24115 = heff_field(v_it11_24108, 0);
            heff_take_n(v_it11_24108, 1ULL, 1);
            V t_0 = v_e_24115;
            v_x1_240 = t_0;
            goto top;
          }
          case TAG_StmtLetMut: {
            heff_take_n(v_it11_24108, 0ULL, 3);
            return NTAG(TAG_True);
          }
          case TAG_StmtLetElse: {
            heff_take_n(v_it11_24108, 0ULL, 3);
            return NTAG(TAG_True);
          }
          default: return heff_nomatch(v_it11_24108);
          }
        }
        default: return heff_nomatch(v_x_24106);
        }
      }
      default: return heff_nomatch(v_x1_24105);
      }
    }
    case TAG_EWithBound: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(a[0]);
}