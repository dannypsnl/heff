// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_Await 41810
#define TAG_Closed 4831
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Log 24016
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_Quit 47258
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Send 26077
#define TAG_Timeout 14063
#define TAG_UriPath 39251
#define LBL_analysis 1868176469
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_lib 316671
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_text 10052084
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
V g_co_2eop_24s1525053243x1115082286(V, V, V, V, V);
V g_co_2eop_24s1525053243x1115082286_entry(V self, V *a);
extern Clo g_co_2eop_24s1525053243x1115082286_clo;
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_clo;
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(V, V);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619(V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(V);
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_clo;
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503_clo;
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2elinesFrom(V, V);
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_clo;
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787(V, V, V);
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341(V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_clo;
V g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_clo;
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
HeffT2 g_heff_2elsp_2erpc_2eeventOf_24cpr(V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s1795474228x706402294(V, V);
V g_list_2eany_24s1795474228x706402294_entry(V self, V *a);
extern Clo g_list_2eany_24s1795474228x706402294_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24s1096141254x104586789(V, V);
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1096141254x104586789_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1201185697x960477413(V, V);
V g_list_2ekeepIf_24s1201185697x960477413_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2ejtrue_lit0, TAG_JBool, 1, NTAG(TAG_True));

static V g_heff_2elsp_2elsp_2ejtrue_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejtrue_st;
static V g_heff_2elsp_2elsp_2ejtrue_init(void) {
  return ((V)&g_heff_2elsp_2elsp_2ejtrue_lit0);
}
V g_heff_2elsp_2elsp_2ejtrue_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejtrue_st)) return g_heff_2elsp_2elsp_2ejtrue_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejtrue_val, &g_heff_2elsp_2elsp_2ejtrue_st, g_heff_2elsp_2elsp_2ejtrue_init);
}
Clo g_heff_2elsp_2elsp_2espaceEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2espaceEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2espaceEnd(V v_l_240, V v_i_241) {
top: ;
  if ((heff_intLt_c_lent(v_i_241, heff_strLength_lent(v_l_240, 0), 2) && ((heff_unbox_word(heff_strByteAt_lent(v_l_240, v_i_241, 0)) == ((int64_t)32ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_l_240, v_i_241, 0)) == ((int64_t)9ULL))))) {
    V t_0 = v_l_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_l_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2espaceEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_str1, 12, "textDocument");
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam0, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam1, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam2, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam3, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam4, 1, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam5, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam6, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam7, 2, 0};
Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_entry, 1, 0};

V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_str1), v_t_241}); V a_1 = v_p_240; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_245 = v_field_244;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_JNull: {
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam0_clo);
      }
      case TAG_JBool: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam1_clo);
      }
      case TAG_JInt: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam2_clo);
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam3_clo);
      }
      case TAG_JString: {
        V v_s_2417 = heff_field(v_it1_245, 0);
        V v_ru_24it1_245_24JString = heff_take_reuse_n(v_it1_245, 1ULL, 1);
        V v_t_2419 = heff_tag_at_n(v_ru_24it1_245_24JString, TAG_InR, 1, (V[]){heff_tag_n(TAG_UriPath, 2, (V[]){v_s_2417, ((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam4_clo)})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
        return heff_tail(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
      }
      case TAG_JArray: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam5_clo);
      }
      case TAG_JObject: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam6_clo);
      }
      default: return heff_nomatch(v_it1_245);
      }
    } else {
      heff_drop(v_field_244);
      return ((V)&g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam7_clo);
    }
  }
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(a[0]);
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam4(V self, V *args) {
  V v_p_2418 = args[0];
  return v_p_2418;
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam5(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam6(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_lam7(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str0, 42, "heff could not finish checking this file (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str1, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str2, 42, "heff could not finish checking this file (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str3, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str4, 59, "heff could not finish checking this file: it stopped here (");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str5, 30, "); what follows is not checked");
V g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_entry, 8, 0};

V g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614(V v_st_240, V v_f_241, V v_d_242, V v_why_243, V v_ds_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Left: {
    heff_drop(v_st_240);
    heff_drop(v_f_241);
    heff_drop(v_z_246);
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str0), v_why_243), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str1));
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_249, heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2411 = ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_t_2410; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
    V v_diags_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(2, shape_program__diags, (V[]){NTAG(TAG_Nil), v_diags_2412});
    return heff_tail(v_z_247, 1, (V[]){v_t_2413});
  }
  case TAG_Right: {
    V v_a_2414 = heff_field(v_x6_245, 0);
    V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ds_244));
    V v_c_2416 = (g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020(v_st_240, v_f_241, heff_dup(v_d_242), v_ds_244, MK_INT(0LL), v_t_2415, heff_dup(v_a_2414)));
    return heff_tail(v_c_2416, 2, (V[]){v_z_246, heff_clo_n(g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_lam0, 1, 3, (V[]){v_d_242, v_why_243, v_z_247})});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614(a[0], a[1], a[2], a[3], a4, a5, a[6], a[7]); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_why_243 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_src_2418 = heff_get_n(v_d_242, 1, 2);
  V v_why_2419 = v_why_243;
  V v_s_2420 = v_x_2417;
  V v_analysis_2421 = heff_take_field(v_s_2420, 0);
  V v_at_2422 = heff_get_n(v_s_2420, 1, 2);
  V v_program_2423 = heff_take_field(v_analysis_2421, 0);
  V v_t_2424 = v_at_2422;
  V v_t_2430;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Nothing: {
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str2), v_why_2419), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str3));
    V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_2425, heff_dup(g_heff_2elsp_2elsp_2ezeroSpan_get()), NTAG(TAG_Nothing)});
    v_t_2430 = ({ V a_0 = v_src_2418; V a_1 = v_t_2426; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(a_0, a_1)); heff_drop(v_src_2418); r_; });
    break;
  }
  case TAG_Just: {
    V v_t_2427 = heff_field(v_t_2424, 0);
    V v_ru_24t_2424_24Just = heff_take_reuse_n(v_t_2424, 1ULL, 1);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str4), v_why_2419), ((V)&g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614_str5));
    V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(0LL), NTAG(TAG_SError), v_t_2428, heff_get_n(v_t_2427, 1, 2), NTAG(TAG_Nothing)});
    v_t_2430 = ({ V a_0 = v_ru_24t_2424_24Just; V a_1 = v_src_2418; V a_2 = v_t_2429; V r_ = (g_heff_2elsp_2elsp_2ediagnostic_24tok1(a_0, a_1, a_2)); heff_drop(v_src_2418); r_; });
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  V v_diags_2432 = (g_prelude_2e_2b_2b(heff_take_field(v_analysis_2421, 1), v_t_2431));
  V v_x_2433 = ({ V rv_0 = v_program_2423; V rv_1 = v_diags_2432; V rr_ = heff_rec_reuse_nf(v_analysis_2421, 0ULL, 2, shape_program__diags, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_str1, 0, "");
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam2, 1, 0};
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_entry, 6, 0};

V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164(V v_st_240, V v_f_241, V v_d_242, V v_why_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam0, 1, 3, (V[]){heff_dup(v_d_242), heff_dup(v_st_240), heff_dup(v_f_241)})})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_244), heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam3, 1, 6, (V[]){v_d_242, v_st_240, v_f_241, v_why_243, v_hd_244, v_k_245})));
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_d_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_src_249 = heff_dup(heff_rfield(v_d_242, 1));
  V v_t_2410 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_242, 1), MK_INT(0LL)));
  V v_ds_2411 = (g_heff_2elsp_2elsp_2edeclsGo(v_t_2410, ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_str0), NTAG(TAG_Nothing)));
  HeffT3 v_t_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = v_ds_2411; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_2411); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    V v_field_2415 = v_t_2412.f[2];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    V v_t_2418;
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      heff_drop(v_src_249);
      V v_x_2416 = v_field_2414;
      V v_x12_2417 = v_field_2415;
      heff_drop(v_x12_2417);
      v_t_2418 = heff_get_n(v_x_2416, 0, 2);
    } else {
      heff_drop(v_field_2414);
      heff_drop(v_field_2415);
      v_t_2418 = heff_strLength(v_src_249);
    }
    heff_clo_take(self, 3);
    return ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_t_2418; V a_4 = v_hd_247; V a_5 = v_k_248; V r_ = (g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2418); r_; });
  }
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam2(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam0(V self, V *args) {
  V v_use_246 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_246;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam1, 2, 3, (V[]){v_d_242, v_st_240, v_f_241});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam2_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_why_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_t_2425 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_242, 1), MK_INT(0LL)));
  V v_t_2426 = (g_heff_2elsp_2elsp_2edeclsGo(v_t_2425, ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1772847775x1572134164_str1), NTAG(TAG_Nothing)));
  heff_clo_take(self, 6);
  return ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_why_243; V a_4 = v_t_2426; V a_5 = v_x_2424; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2estoppedFrom_24s888101832x1133654614(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2426); heff_drop(v_x_2424); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_dup(heff_rfield(v_st_240, 2)), v_f_241));
  V v_project_243 = heff_dup(heff_rfield(v_st_240, 3));
  V v_watch_244 = heff_dup(heff_rfield(v_st_240, 4));
  V v_shutdown_245 = heff_dup(heff_rfield(v_st_240, 5));
  V v_lib_246 = heff_dup(heff_rfield(v_st_240, 6));
  V v_t_247 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_240, 0)), heff_dup(heff_rfield(v_st_240, 1)), v_t_242, v_project_243, v_watch_244, v_shutdown_245, v_lib_246});
  V v_c_248 = (g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(v_t_247, heff_dup(v_f_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam0, 2, 3, (V[]){v_c_248, v_st_240, v_f_241});
}
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam2(V self, V *args) {
  V v_p_2413 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_t_2416;
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_dup(heff_field(v_p_2413, 0));
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_p_2413);
  }
  if (!heff_strEq_c_lent(v_t_2416, v_f_241, 0)) {
    heff_drop(v_t_2416);
    V v_t_2419;
    switch (heff_tag_of(v_p_2413)) {
    case TAG_MkPair: {
      V v_y_2418 = heff_field(v_p_2413, 1);
      heff_take_n(v_p_2413, 2ULL, 2);
      v_t_2419 = v_y_2418;
      break;
    }
    default: heff_nomatch(v_p_2413);
    }
    heff_clo_take(self, 1);
    return ({ V a_0 = v_f_241; V b_1 = heff_get_n(v_t_2419, 1, 2); V r_ = (g_list_2eany_24s1795474228x706402294(a_0, b_1)); heff_drop(v_f_241); heff_drop(b_1); r_; });
  } else {
    heff_drop(v_p_2413);
    heff_drop(self);
    heff_drop(v_t_2416);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = ({ V b_0 = heff_get_n(v_st_240, 1, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2420 = ({ V b_0 = heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam2, 1, 1, (V[]){v_f_241}); V a_1 = v_t_2412; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2421 = (g_list_2emap_24s1415906091x1371825187(v_t_2420));
  return ({ V a_0 = v_x_2411; V a_1 = v_t_2421; V a_2 = v_hd_249; V a_3 = v_k_2410; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_lam1, 1, 4, (V[]){v_st_240, v_f_241, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam0, 2, 0};
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_entry, 2, 0};

V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    return ((V)&g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam1, 2, 4, (V[]){v_c_246, v_st_240, v_rest_245, v_f_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_249, 0, 6), v_f_244});
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = (g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318(v_st_240, v_rest_245));
  V f_ = v_t_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam3, 1, 3, (V[]){v_x_249, v_f_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_lam2, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_247, v_f_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_str0, 0, "");
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam2, 1, 0};
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_entry, 3, 0};

V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787(V v_st_240, V v_names_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    return ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_p_245));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_c_2430;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_d_2410 = v_field_249;
        v_c_2430 = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam1, 2, 1, (V[]){v_d_2410});
      } else {
        heff_drop(v_field_249);
        V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_245)));
        V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2414); r_; });
        V v_a_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_ReadFile, 2, (V[]){v_t_2415, ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam2_clo)});
        v_c_2430 = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam3, 2, 1, (V[]){v_a_2417});
      }
      return heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam5, 2, 5, (V[]){v_c_2430, v_st_240, heff_dup(v_names_241), v_rest_246, v_p_245});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_d_2410 = heff_env(self)[0];
  heff_drop(v_hd_2411);
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2410, 1, 2)});
  V f_ = v_k_2412;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2419 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    heff_take_n(v_x_2425, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2419;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2427 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    switch (heff_tag_of(v_y_2427)) {
    case TAG_Left: {
      heff_take_n(v_y_2427, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2419;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2429 = heff_field(v_y_2427, 0);
      heff_take_n(v_y_2427, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2419;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2429});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2427);
    }
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_a_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2424, v_hd_2418, heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam4, 1, 1, (V[]){v_k_2419})));
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_names_241 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  V v_t_2437;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Nothing: {
    v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2436 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    v_t_2437 = v_x_2436;
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V v_t_2438 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2437; V a_2 = MK_INT(0LL); V a_3 = v_names_241; V r_ = (g_list_2eany_24s1027174601x1571638094(a_0, a_1, a_2, a_3)); heff_drop(v_t_2437); heff_drop(v_names_241); r_; });
  V v_x_2439;
  if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
    heff_drop(v_t_2438);
    v_x_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_x_2435});
  } else {
    heff_drop(v_p_245);
    heff_drop(v_t_2438);
    v_x_2439 = v_x_2435;
  }
  V f_ = v_k_2432;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_names_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2431 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  V v_k_2432 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2434 = (g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787(v_st_240, v_names_241, v_rest_246));
  V f_ = v_t_2434;
  heff_room[0] = v_hd_2431;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam7, 1, 4, (V[]){v_x_2433, v_names_241, v_p_245, v_k_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_names_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_lam6, 1, 6, (V[]){v_st_240, v_names_241, v_rest_246, v_hd_2431, v_p_245, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str17, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str18, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str19, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str20, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str21, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str22, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str23, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str24, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str25, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str27, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str28, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str31, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str32, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str33, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str34, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str35, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str36, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str37, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str38, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str39, 1, "}");
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_entry, 3, 0};

V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821(V v_st_240, V v_id_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam0, 2, 3, (V[]){v_c_243, heff_dup(v_id_241), v_st_240});
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_2424);
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam4(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_d_2434 = heff_env(self)[0];
  heff_drop(v_hd_2435);
  heff_clo_take(self, 1);
  V v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2434, 1, 2)});
  V f_ = v_k_2436;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam5(V self, V *args) {
  V v_r_2440 = args[0];
  return v_r_2440;
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2443 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Left: {
    heff_take_n(v_x_2449, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2443;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2451 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    switch (heff_tag_of(v_y_2451)) {
    case TAG_Left: {
      heff_take_n(v_y_2451, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2443;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2453 = heff_field(v_y_2451, 0);
      heff_take_n(v_y_2451, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2443;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2453});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2451);
    }
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam6(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_a_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2441})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2448, v_hd_2442, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam7, 1, 1, (V[]){v_k_2443})));
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam3(V self, V *args) {
  V v_q_2430 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2431 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_q_2430; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2433 = v_t_2431.f[1];
    int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
    if ((v_tag_2432 == ((int64_t)0ULL))) {
      heff_drop(v_q_2430);
      V v_d_2434 = v_field_2433;
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam4, 2, 1, (V[]){v_d_2434});
    } else {
      heff_drop(v_field_2433);
      V v_path_2438 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_q_2430));
      V v_t_2439 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2438; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2438); r_; });
      V v_a_2441 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2439, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam5_clo)});
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam6, 2, 1, (V[]){v_a_2441});
    }
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam8(V self, V *args) {
  V v_x_2455 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_d_2429 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_t_2456 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2455, 0, 5)));
  heff_clo_take(self, 5);
  return ({ V a_0 = v_st_240; V a_1 = v_id_241; V a_2 = v_d_2429; V a_3 = v_t_2456; V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_id_241); r_; });
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam9(V self, V *args) {
  V v_x_2474 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_2474);
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_id_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_247 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str0), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str1), MK_INT(0LL)));
    V v_acc_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str2)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str3));
    V v_t_249 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str4), heff_strAppend(v_acc_248, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str5)), MK_INT(0LL)));
    V v_acc_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str6));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_acc_2410, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str7)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str8));
    V v_t_2412 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str9), v_t_2411, MK_INT(0LL)));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str10)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str11));
    heff_clo_take(self, 4);
    V v_acc_2414 = ({ V a_0 = v_t_2413; V a_1 = v_id_241; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_241); r_; });
    V v_t_2415 = heff_strAppend(heff_strAppend(v_acc_2414, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str12)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str13));
    V v_t_2416 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str14), v_t_2415, MK_INT(0LL)));
    V v_acc_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str15)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str16));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_acc_2417, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str17)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str18));
    V v_a_2419 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str19)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s535099379x685970669(v_t_2423, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam2, 1, 2, (V[]){v_k_245, v_st_240})));
  }
  case TAG_Just: {
    V v_f_2425 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_2426 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_2425));
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_246_24Just, 1);
        V v_d_2429 = v_field_2428;
        V v_t_2454 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam3, 1, 1, (V[]){heff_dup(v_st_240)}), heff_dup(heff_rfield(v_st_240, 6)), v_f_2425));
        heff_clo_take(self, 4);
        V f_ = v_t_2454;
        heff_room[0] = heff_dup(v_hd_244);
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam8, 1, 5, (V[]){v_st_240, v_id_241, v_d_2429, v_hd_244, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_f_2425);
        heff_drop(v_field_2428);
        V v_t_2457 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str20), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str21), MK_INT(0LL)));
        V v_acc_2458 = heff_strAppend(heff_strAppend(v_t_2457, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str22)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str23));
        V v_t_2459 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str24), heff_strAppend(v_acc_2458, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str25)), MK_INT(0LL)));
        V v_acc_2460 = heff_strAppend(v_t_2459, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str26));
        V v_t_2461 = heff_strAppend(heff_strAppend(v_acc_2460, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str27)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str28));
        V v_t_2462 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str29), v_t_2461, MK_INT(0LL)));
        V v_t_2463 = heff_strAppend(heff_strAppend(v_t_2462, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str30)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str31));
        heff_clo_take(self, 4);
        V v_acc_2464 = ({ V a_0 = v_t_2463; V a_1 = v_id_241; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_241); r_; });
        V v_t_2465 = heff_strAppend(heff_strAppend(v_acc_2464, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str32)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str33));
        V v_t_2466 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str34), v_t_2465, MK_INT(0LL)));
        V v_acc_2467 = heff_strAppend(heff_strAppend(v_t_2466, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str35)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str36));
        V v_t_2468 = heff_strAppend(heff_strAppend(v_acc_2467, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str37)), ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str38));
        V v_a_2469 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2468, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_str39)), NTAG(TAG_MkUnit)});
        V v_t_2470 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2469})});
        V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
        V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
        V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
        return (g_co_2eop_24s535099379x685970669(v_t_2473, v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam9, 1, 2, (V[]){v_k_245, v_st_240})));
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_id_241 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_lam1, 1, 4, (V[]){v_id_241, v_hd_244, v_k_245, v_st_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_str0, 10, "not JSON, ");
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam8, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam12(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam12, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam14(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam14, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_entry, 3, 0};

V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341(V v_st_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam1, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242}));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam0(V self, V *args) {
  V v_n_243 = args[0];
  return v_n_243;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam4(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_st_240 = heff_env(self)[0];
  V v_msg_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043(v_st_240, v_msg_2419, v_hd_2421, v_k_2422));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam5(V self, V *args) {
  V v_r_2423 = args[0];
  return v_r_2423;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam3(V self, V *args) {
  V v_use_2420 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_msg_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2420;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam4, 2, 2, (V[]){v_st_240, v_msg_2419});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam5_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341(v_x_2429, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_msg_2419 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2elsp_2elsp_2ehandled_24s1065380665x703935503(v_st_240, v_msg_2419, v_x_2428, heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam7, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam8(V self, V *args) {
  V v_n_2430 = args[0];
  return v_n_2430;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam11(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_st_240 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  V v_t_2439 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  heff_clo_take(self, 2);
  V v_t_2440 = ({ V a_0 = v_x_2435; V a_1 = v_t_2439; V r_ = (g_list_2ekeepIf_24s1201185697x960477413(a_0, a_1)); heff_drop(v_x_2435); r_; });
  V v_t_2441 = (g_list_2emap_24s1415906091x1371825187(v_t_2440));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2441; V a_2 = v_hd_2437; V a_3 = v_k_2438; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1090298314x471083379(a_0, a_1, a_2, a_3)); heff_drop(v_t_2441); r_; });
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam12(V self, V *args) {
  V v_r_2442 = args[0];
  return v_r_2442;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam10(V self, V *args) {
  V v_use_2436 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2436;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam11, 2, 2, (V[]){v_st_240, v_x_2435});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam12_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam13(V self, V *args) {
  V v_x_2447 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_st_2448 = heff_dup(v_st_240);
  heff_clo_take(self, 4);
  V v_t_2449 = ({ V b_0 = heff_get_n(v_st_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2450 = ({ V a_0 = v_x_2435; V a_1 = v_t_2449; V r_ = (g_list_2ekeepIf_24s1201185697x960477413(a_0, a_1)); heff_drop(v_x_2435); r_; });
  V v_fs_2451 = (g_list_2emap_24s1415906091x1371825187(v_t_2450));
  V v_x3_2452 = v_x_2447;
  V v_t_2460;
  switch (heff_tag_of(v_x3_2452)) {
  case TAG_Left: {
    heff_take_n(v_x3_2452, 0ULL, 1);
    V v_t_2454 = ({ V a_0 = heff_take_field(v_st_2448, 2); V a_1 = v_fs_2451; V r_ = (g_heff_2elsp_2elsp_2eundue(a_0, a_1)); heff_drop(v_fs_2451); r_; });
    V v_project_2455 = heff_take_field(v_st_2448, 3);
    V v_watch_2456 = heff_take_field(v_st_2448, 4);
    V v_shutdown_2457 = heff_take_field(v_st_2448, 5);
    V v_lib_2458 = heff_take_field(v_st_2448, 6);
    v_t_2460 = ({ V rv_2 = v_t_2454; V rv_3 = v_project_2455; V rv_4 = v_watch_2456; V rv_5 = v_shutdown_2457; V rv_6 = v_lib_2458; V rr_ = heff_rec_reuse_nf(v_st_2448, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
    break;
  }
  case TAG_Right: {
    V v_st2_2459 = heff_field(v_x3_2452, 0);
    heff_take_n(v_x3_2452, 1ULL, 1);
    heff_drop_rec(v_st_2448, 7);
    heff_drop(v_fs_2451);
    v_t_2460 = v_st2_2459;
    break;
  }
  default: heff_nomatch(v_x3_2452);
  }
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341(v_t_2460, v_hd_241, v_k_242));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam9(V self, V *args) {
  V v_x_2435 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam10, 1, 2, (V[]){heff_dup(v_st_240), heff_dup(v_x_2435)})})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam13, 1, 4, (V[]){v_st_240, v_x_2435, v_hd_241, v_k_242})));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Message: {
    V v_msg_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Message = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2418_24Message, TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam3, 1, 2, (V[]){heff_dup(v_st_240), heff_dup(v_msg_2419)})})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    heff_clo_take(self, 3);
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam6, 1, 4, (V[]){v_st_240, v_msg_2419, v_hd_241, v_k_242})));
  }
  case TAG_Timeout: {
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam8_clo)})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    heff_clo_take(self, 3);
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_241), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam9, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242})));
  }
  case TAG_Closed: {
    heff_clo_take(self, 3);
    heff_drop_rec(v_st_240, 7);
    V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){MK_INT(1LL)})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam14(V self, V *args) {
  V v_x_2468 = args[0];
  return v_x_2468;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam15(V self, V *args) {
  V v_x_2473 = args[0];
  V v_ms_2416 = heff_env(self)[0];
  V v_p_2417 = heff_env(self)[1];
  V v_p_2465 = heff_env(self)[2];
  HeffT2 v_t_2474 = (g_heff_2elsp_2erpc_2eeventOf_24cpr(v_x_2473));
  {
    V v_field_2476 = v_t_2474.f[1];
    int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
    if ((v_tag_2475 == ((int64_t)0ULL))) {
      V v_x_2477 = v_field_2476;
      V v_t_2478 = heff_tag_n(TAG_Log, 2, (V[]){heff_strAppend(((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_str0), v_x_2477), NTAG(TAG_MkUnit)});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
      V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
      heff_clo_take(self, 3);
      return (g_co_2eop_24s1525053243x1115082286(v_ms_2416, heff_dup(v_p_2417), v_p_2465, v_t_2482, v_p_2417));
    } else {
      heff_clo_take(self, 3);
      heff_drop(v_ms_2416);
      heff_drop(v_p_2417);
      V v_y_2483 = v_field_2476;
      V f_ = v_p_2465;
      args[0] = v_y_2483;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_249 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_st_240, 2), NTAG(TAG_Nil)));
  V v_t_2410 = (g_list_2emap_24s366344330x1145113647(v_t_249));
  V v_ms_2416;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    heff_drop(v_x_248);
    v_ms_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_2411 = heff_field(v_t_2410, 0);
    V v_ds_2412 = heff_field(v_t_2410, 1);
    heff_take_n(v_t_2410, 3ULL, 2);
    V v_t_2413 = ({ V a_0 = v_d_2411; V a_1 = v_ds_2412; V r_ = (g_list_2efoldl_24s1096141254x104586789(a_0, a_1)); heff_drop(v_ds_2412); r_; });
    V v_y_2414 = heff_intSub(v_t_2413, v_x_248);
    V v_t_2415;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2414, 1)) {
      v_t_2415 = v_y_2414;
    } else {
      heff_drop(v_y_2414);
      v_t_2415 = MK_INT(0LL);
    }
    v_ms_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_p_2417 = heff_dup(v_hd_241);
  heff_clo_take(self, 3);
  V v_p_2465 = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam2, 1, 3, (V[]){v_st_240, v_hd_241, v_k_242});
  V v_t_2467;
  switch (heff_tag_of(v_ms_2416)) {
  case TAG_Nothing: {
    v_t_2467 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_2466 = heff_dup(heff_field(v_ms_2416, 0));
    v_t_2467 = v_x_2466;
    break;
  }
  default: heff_nomatch(v_ms_2416);
  }
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Await, 2, (V[]){v_t_2467, ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam14_clo)})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2472}), heff_dup(v_p_2417), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1872599033x1913181341_lam15, 1, 3, (V[]){v_ms_2416, v_p_2417, v_p_2465})));
}