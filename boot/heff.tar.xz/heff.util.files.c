// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_WriteFile 62589
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1(V, V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_clo;
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129(V, V, V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam2(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam1(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_entry, 3, 0};

V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374(V v_path_240, V v_z_241, V v_z_242) {
top: ;
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_245 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_243, ((V)&g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam0_clo)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  HEFF_LAST return g_co_2eop_24s1896221640x2141527803(v_t_2410, v_z_241, heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam1, 1, 2, (V[]){v_z_242, v_path_240}));
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374(a[0], a[1], a[2]);
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2416));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_240, v_t_2417));
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    heff_take_n(v_x_2411, 0ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_path_240);
    V f_ = v_z_242;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2413 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    switch (heff_tag_of(v_y_2413)) {
    case TAG_Left: {
      heff_take_n(v_y_2413, 0ULL, 1);
      heff_clo_take(self, 2);
      heff_drop(v_path_240);
      V f_ = v_z_242;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_y_2413, 0);
      heff_take_n(v_y_2413, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_x_2418 = (g_list_2emap(heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_lam2, 1, 1, (V[]){v_path_240}), v_x_2415));
      V v_x_2419 = (g_list_2emap_24s219049803x1458391381(v_x_2418));
      V f_ = v_z_242;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2413);
    }
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_lam1(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_entry, 3, 0};

V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634(V v_path_240, V v_z_241, V v_z_242) {
top: ;
  V v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_245 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_243, ((V)&g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_lam0_clo)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  HEFF_LAST return g_co_2eop_24s1896221640x2141527803(v_t_2410, v_z_241, heff_clo_n(g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_lam1, 1, 1, (V[]){v_z_242}));
}
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_242 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    heff_take_n(v_x_2411, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_z_242;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2413 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    switch (heff_tag_of(v_y_2413)) {
    case TAG_Left: {
      heff_take_n(v_y_2413, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_z_242;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_y_2413, 0);
      heff_take_n(v_y_2413, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_z_242;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2415});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2413);
    }
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_lam1(V self, V *args);
Clo g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_entry, 4, 0};

V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129(V v_path_240, V v_text_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_246 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_244, v_text_241, ((V)&g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2411, v_z_242, heff_clo_n(g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_lam1, 1, 1, (V[]){v_z_243})));
}
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2eutil_2efiles_2ewriteFile_24s1509614449x811375129_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_243 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_z_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2414)) {
    case TAG_Left: {
      heff_take_n(v_y_2414, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_z_243;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2414, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_z_243;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2414);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam0(V self, V *args); static Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam0, 1, 0};
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam2(V self, V *args);
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam1(V self, V *args);
Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_entry, 4, 0};

V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1(V v_tok_240, V v_path_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_246 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_244, ((V)&g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam0_clo)});
  V v_t_247 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2411, v_z_242, heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam1, 1, 2, (V[]){v_z_243, v_path_241})));
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1(a[0], a[1], a[2], a[3]);
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam2(V self, V *args) {
  V v_n_2417 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2417));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_241, v_t_2418));
}
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    heff_take_n(v_x_2412, 0ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_path_241);
    V f_ = v_z_243;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2414)) {
    case TAG_Left: {
      heff_take_n(v_y_2414, 0ULL, 1);
      heff_clo_take(self, 2);
      heff_drop(v_path_241);
      V f_ = v_z_243;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_y_2414, 0);
      heff_take_n(v_y_2414, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_x_2419 = (g_list_2emap(heff_clo_n(g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_lam2, 1, 1, (V[]){v_path_241}), v_x_2416));
      V v_x_2420 = (g_list_2emap_24s219049803x1458391381(v_x_2419));
      V f_ = v_z_243;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2420});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2414);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}