// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_Tip 31527
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2eordmap_2etoList_2etoListOnto_240_entry, 2, 0};

V g_std_2eordmap_2etoList_2etoListOnto_240(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Tip: {
    return v_acc_241;
  }
  case TAG_Bin: {
    V v_k_243 = heff_field(v_x1_240, 1);
    V v_v_244 = heff_field(v_x1_240, 2);
    V v_l_245 = heff_field(v_x1_240, 3);
    V v_r_246 = heff_field(v_x1_240, 4);
    V v_t_247 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_r_246, v_acc_241));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_243), heff_dup(v_v_244)}), v_t_247});
    V t_0 = v_l_245;
    V t_1 = v_t_248;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eordmap_2etoList_2etoListOnto_240(a0, a[1]); heff_drop(a0); return r;
}