// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define LBL_ar 9880
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_defs 9574869
#define LBL_dirty 296951788
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_many 9839398
#define LBL_name 9869138
#define LBL_pa 10328
#define LBL_params 951713969
#define LBL_supply 1056026650
#define LBL_tables 1065764240
#define LBL_takes 311482598
#define LBL_uses 10094739
#define LBL_vars 10107635
static uint32_t shape_calls__uses__takes[] = {LBL_calls, LBL_uses, LBL_takes};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__params__many__ar[] = {LBL_key, LBL_params, LBL_many, LBL_ar};
static uint32_t shape_known__defs__supply[] = {LBL_known, LBL_defs, LBL_supply};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
static uint32_t shape_vars__globals__dirty[] = {LBL_vars, LBL_globals, LBL_dirty};
V g_heff_2ecompile_2ecallarity_2eappNote(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eappNote_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eappNote_clo;
V g_heff_2ecompile_2ecallarity_2eargsNote(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eargsNote_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eargsNote_clo;
V g_heff_2ecompile_2ecallarity_2ecallOf(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ecallOf_clo;
V g_heff_2ecompile_2ecallarity_2ecallOf_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ecallOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ecallOf_24tok2_clo;
V g_heff_2ecompile_2ecallarity_2edefNotes(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2edefNotes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edefNotes_clo;
V g_heff_2ecompile_2ecallarity_2edropC(V, V);
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edropC_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2eexpandArg_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArgs(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo;
V g_heff_2ecompile_2ecallarity_2eexpandGo(V, V);
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo;
V g_heff_2ecompile_2ecallarity_2eextendAt(V, V);
V g_heff_2ecompile_2ecallarity_2eextendAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextendAt_clo;
V g_heff_2ecompile_2ecallarity_2efreshMany(V, V);
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V, V);
V g_heff_2ecompile_2ecallarity_2ehanded(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ehanded_clo;
V g_heff_2ecompile_2ecallarity_2eisNth(V, V, V);
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eisNth_clo;
V g_heff_2ecompile_2ecallarity_2eknownAdd(V, V, V);
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo;
V g_heff_2ecompile_2ecallarity_2enoteUse(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2enoteUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enoteUse_clo;
V g_heff_2ecompile_2ecallarity_2enthOr(V, V, V);
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enthOr_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars(V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(V, V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2erounds_clo;
V g_heff_2ecompile_2ecallarity_2erounds_24rec0_get(void);
V g_heff_2ecompile_2ecallarity_2erounds_24rec1_get(void);
V g_heff_2ecompile_2ecallarity_2esameAll(V, V);
V g_heff_2ecompile_2ecallarity_2esameAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameAll_clo;
V g_heff_2ecompile_2ecallarity_2esameInts(V, V);
V g_heff_2ecompile_2ecallarity_2esameInts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esameInts_clo;
V g_heff_2ecompile_2ecallarity_2esatGo(V, V);
V g_heff_2ecompile_2ecallarity_2esatGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2esatGo_clo;
V g_heff_2ecompile_2ecallarity_2eusesW(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eusesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eusesW_clo;
V g_heff_2ecompile_2ecallarity_2ezipTo(V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V);
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_heff_2ecompile_2eir_2ewaysMap(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_clo;
V g_heff_2eelab_2eprimitive_2eprimArity(V);
V g_heff_2eelab_2eprimitive_2eprimArity_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimArity_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s445268946x679229867(V, V);
V g_list_2efoldl_24s445268946x679229867_entry(V self, V *a);
extern Clo g_list_2efoldl_24s445268946x679229867_clo;
V g_list_2efoldl_24s619143909x1041174639(V, V, V);
V g_list_2efoldl_24s619143909x1041174639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s619143909x1041174639_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str0, 2, "z$");

HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V v_k_240, V v_p_241) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  } else {
    V v_x_242 = heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_24cpr_str0), heff_intShow(heff_dup(v_p_241)));
    V v_m_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_clo), 1, (V[]){heff_intSub(v_k_240, MK_INT(1LL))}));
    V v_x2_244 = heff_tr(heff_call(v_m_243, 1, (V[]){heff_intAdd(v_p_241, MK_INT(1LL))}));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_n_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_Cons, 2, (V[]){v_x_242, v_x_245}), v_n_246}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_244)}});
    }
  }
}
Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2efreshMany_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2efreshMany(V v_k_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_k_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2efreshMany(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edropC_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2edropC(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2enthOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enthOr_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2enthOr(V v_d_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(v_d_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return heff_dup(v_x_243);
    } else {
      V t_0 = v_d_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = v_xs_244;
      v_d_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2enthOr(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eisNth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eisNth_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eisNth(V v_i_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_241, v_y_243, 0));
      return v_ret_24bool;
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_x_241;
      V t_2 = v_ys_244;
      v_i_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eisNth(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ezipTo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2ezipTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x1_240, 0);
    V v_ys_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_dup(g_std_2eordmap_2eempty_get());
    }
    case TAG_Cons: {
      V v_z_244 = heff_field(v_x2_241, 0);
      V v_zs_245 = heff_field(v_x2_241, 1);
      V v_t_246 = (g_heff_2ecompile_2ecallarity_2ezipTo(v_ys_243, v_zs_245));
      return ({ V a_0 = v_t_246; V a_1 = v_y_242; V b_2 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_z_244)}); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2ezipTo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2enoteUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2enoteUse_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2enoteUse(V v_here_240, V v_g_241, V v_k_242, V v_x4_243, V v_n_244) {
top: ;
  V v_many_245 = heff_take_field(v_here_240, 2);
  V v_ar_246 = heff_get_n(v_here_240, 3, 4);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_247 = v_many_245;
    V v_t_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_t_248 = MK_INT(2LL);
    } else {
      heff_drop(v_t_247);
      v_t_248 = MK_INT(1LL);
    }
    HeffT2 v_t_249 = ({ V a_0 = v_ar_246; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_ar_246); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_t_2413;
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_2411;
        v_t_2413 = v_x_2412;
      } else {
        heff_drop(v_field_2411);
        v_t_2413 = MK_INT(0LL);
      }
      V v_u_2414 = heff_rec_n(3, shape_calls__uses__takes, (V[]){v_k_242, v_t_248, v_t_2413});
      V v_t_2415 = ({ V a_0 = heff_take_field(v_n_244, 1); V a_1 = v_g_241; V a_2 = v_u_2414; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop_rec(v_u_2414, 3); r_; });
      return ({ V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_n_244, 5ULL, 3, shape_vars__globals__dirty, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    }
  }
  case TAG_Just: {
    V v_u_2416 = heff_field(v_x4_243, 0);
    heff_drop(v_ar_246);
    if ((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_u_2416, 2))) ? heff_intLe_c(heff_dup(heff_rfield(v_u_2416, 0)), heff_dup(heff_rfield(v_u_2416, 2))) : (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_u_2416, 1))) || heff_intEq_c(heff_dup(heff_rfield(v_u_2416, 0)), MK_INT(0LL))))) {
      heff_drop(v_k_242);
      heff_drop(v_many_245);
      return v_n_244;
    } else {
      V v_t_2417;
      if (heff_intLt_c(heff_dup(v_k_242), heff_dup(heff_rfield(v_u_2416, 0)))) {
        v_t_2417 = v_k_242;
      } else {
        heff_drop(v_k_242);
        v_t_2417 = heff_dup(heff_rfield(v_u_2416, 0));
      }
      V v_t_2418 = v_many_245;
      V v_t_2419;
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        v_t_2419 = MK_INT(2LL);
      } else {
        heff_drop(v_t_2418);
        v_t_2419 = MK_INT(1LL);
      }
      V v_t_2420 = heff_intAdd(heff_dup(heff_rfield(v_u_2416, 1)), v_t_2419);
      V v_t_2421 = heff_rec_n(3, shape_calls__uses__takes, (V[]){v_t_2417, v_t_2420, heff_dup(heff_rfield(v_u_2416, 2))});
      V v_t_2422 = ({ V a_0 = heff_take_field(v_n_244, 1); V a_1 = v_g_241; V a_2 = v_t_2421; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop_rec(v_t_2421, 3); r_; });
      return ({ V rv_1 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_n_244, 5ULL, 3, shape_vars__globals__dirty, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecallarity_2enoteUse_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2enoteUse(a[0], a1, a[2], a3, a[4]); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ehanded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ehanded_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2ehanded(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x_244, V v_n_245) {
top: ;
  V v_key_246 = heff_take_field(v_here_241, 0);
  V v_params_247 = heff_get_n(v_here_241, 1, 4);
  if (heff_strEq_c_lent(v_h_242, v_key_246, 2)) {
    V v_t_248 = ({ V a_0 = heff_dup(v_j_243); V a_1 = v_x_244; V a_2 = v_params_247; V r_ = (g_heff_2ecompile_2ecallarity_2eisNth(a_0, a_1, a_2)); heff_drop(v_params_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_240, 1);
      heff_drop(v_j_243);
      heff_drop(v_t_248);
      return v_n_245;
    } else {
      heff_drop(v_t_248);
      HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_t_240, 0, 1); V a_1 = v_h_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_k_2413;
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_ps_2412 = v_field_2411;
          v_k_2413 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_243; V a_2 = v_ps_2412; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2412); r_; });
        } else {
          heff_drop(v_j_243);
          heff_drop(v_field_2411);
          v_k_2413 = MK_INT(0LL);
        }
        HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_n_245, 0), v_x_244));
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_k0_2417 = v_field_2416;
            if (heff_intLt_c_lent(v_k_2413, v_k0_2417, 2)) {
              V v_t_2418 = ({ V a_0 = heff_take_field(v_n_245, 0); V a_1 = v_x_244; V a_2 = v_k_2413; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_2413); r_; });
              return ({ V rv_0 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_n_245, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            } else {
              heff_drop(v_k_2413);
              return v_n_245;
            }
          } else {
            heff_drop(v_k_2413);
            heff_drop(v_field_2416);
            return v_n_245;
          }
        }
      }
    }
  } else {
    heff_drop(v_params_247);
    HeffT2 v_t_2419 = ({ V b_0 = heff_get_n(v_t_240, 0, 1); V a_1 = v_h_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      V v_k_2423;
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_ps_2422 = v_field_2421;
        v_k_2423 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_243; V a_2 = v_ps_2422; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2422); r_; });
      } else {
        heff_drop(v_j_243);
        heff_drop(v_field_2421);
        v_k_2423 = MK_INT(0LL);
      }
      HeffT2 v_t_2424 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_n_245, 0), v_x_244));
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_k0_2427 = v_field_2426;
          if (heff_intLt_c_lent(v_k_2423, v_k0_2427, 2)) {
            V v_t_2428 = ({ V a_0 = heff_take_field(v_n_245, 0); V a_1 = v_x_244; V a_2 = v_k_2423; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_2423); r_; });
            return ({ V rv_0 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_n_245, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          } else {
            heff_drop(v_k_2423);
            return v_n_245;
          }
        } else {
          heff_drop(v_k_2423);
          heff_drop(v_field_2426);
          return v_n_245;
        }
      }
    }
  }
}
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2ecallarity_2ehanded(a[0], a[1], a2, a[3], a4, a[5]); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eargsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eargsNote_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2eargsNote(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x5_244, V v_n_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_j_243);
    return v_n_245;
  }
  case TAG_Cons: {
    V v_x51_246 = heff_field(v_x5_244, 0);
    V v_args_247 = heff_field(v_x5_244, 1);
    switch (heff_tag_of(v_x51_246)) {
    case TAG_EVar: {
      V v_x_248 = heff_field(v_x51_246, 0);
      V v_t_249 = (g_heff_2ecompile_2ecallarity_2ehanded(heff_dup(v_t_240), heff_dup(v_here_241), v_h_242, heff_dup(v_j_243), v_x_248, v_n_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_t_249;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    case TAG_ELam: {
      V v_ys_2410 = heff_field(v_x51_246, 0);
      HeffT2 v_t_2412 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_t_240, 0), v_h_242));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        V v_x_2416;
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_ps_2415 = v_field_2414;
          v_x_2416 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_243); V a_2 = v_ps_2415; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2415); r_; });
        } else {
          heff_drop(v_field_2414);
          v_x_2416 = MK_INT(0LL);
        }
        V v_y_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2410));
        V v_t_2418;
        if (heff_intLt_c(v_y_2417, v_x_2416)) {
          v_t_2418 = ({ V rv_2 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_n_245, 3ULL, 3, shape_vars__globals__dirty, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        } else {
          v_t_2418 = v_n_245;
        }
        V t_0 = v_t_240;
        V t_1 = v_here_241;
        V t_2 = v_h_242;
        V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
        V t_4 = v_args_247;
        V t_5 = v_t_2418;
        v_t_240 = t_0;
        v_here_241 = t_1;
        v_h_242 = t_2;
        v_j_243 = t_3;
        v_x5_244 = t_4;
        v_n_245 = t_5;
        goto top;
      }
    }
    default: {
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_h_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_args_247;
      V t_5 = v_n_245;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_h_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_n_245 = t_5;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecallarity_2eargsNote_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2ecallarity_2eargsNote(a0, a1, a2, a[3], a4, a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eappNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eappNote_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eappNote(V v_t_240, V v_here_241, V v_f_242, V v_args_243, V v_n_244) {
top: ;
  switch (heff_tag_of(v_f_242)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_f_242, 0);
    heff_drop(v_here_241);
    V v_k_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_n_244, 0), v_x_245));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_k0_2410 = v_field_249;
        if (heff_intLt_c_lent(v_k_246, v_k0_2410, 2)) {
          V v_t_2411 = ({ V a_0 = heff_take_field(v_n_244, 0); V a_1 = v_x_245; V a_2 = v_k_246; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_246); r_; });
          return ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_n_244, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        } else {
          heff_drop(v_k_246);
          return v_n_244;
        }
      } else {
        heff_drop(v_k_246);
        heff_drop(v_field_249);
        return v_n_244;
      }
    }
  }
  case TAG_EGlobal: {
    V v_g_2412 = heff_field(v_f_242, 0);
    V v_k_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
    V v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_n_244, 1), v_g_2412));
    V v_t_2415 = ({ V a_0 = heff_dup(v_here_241); V a_1 = v_g_2412; V a_2 = v_k_2413; V a_3 = v_t_2414; V a_4 = v_n_244; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2414); r_; });
    return ({ V a_0 = v_t_240; V a_1 = v_here_241; V a_2 = v_g_2412; V a_3 = MK_INT(0LL); V a_4 = v_args_243; V a_5 = v_t_2415; V r_ = (g_heff_2ecompile_2ecallarity_2eargsNote(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_here_241); r_; });
  }
  case TAG_ELam: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EApp: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ELet: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ERecord: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EProj: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ETag: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EMatch: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EPrim: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EPrimCall: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ECall: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EInt: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFloat: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EStr: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EBytes: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFixed: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EBool: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_ESet: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EValues: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  case TAG_EFix: {
    heff_drop(v_here_241);
    return v_n_244;
  }
  default: return heff_nomatch(v_f_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eappNote_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2eappNote(a0, a[1], a2, a3, a[4]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(v_rest_241);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_args_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_args_243;
      V t_1 = v_rest_241;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      goto top;
    }
    default: {
      V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x11_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2epushNonVars(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_rest_241));
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_args_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_EVar: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_d_242;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: {
      V v_cell_246 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x11_243, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_u_247;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eusesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eusesW_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eusesW(V v_t_240, V v_here_241, V v_x3_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_here_241, 4);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_EVar: {
      V v_x_246 = heff_field(v_x31_244, 0);
      heff_take_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_n_243, 0), v_x_246));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2412;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_k0_2410 = v_field_249;
          if (heff_intLt_c(MK_INT(0LL), v_k0_2410)) {
            V v_t_2411 = ({ V a_0 = heff_take_field(v_n_243, 0); V a_1 = v_x_246; V a_2 = MK_INT(0LL); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
            v_t_2412 = ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_n_243, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          } else {
            heff_drop(v_x_246);
            v_t_2412 = v_n_243;
          }
        } else {
          heff_drop(v_x_246);
          heff_drop(v_field_249);
          v_t_2412 = v_n_243;
        }
        V t_0 = v_t_240;
        V t_1 = v_here_241;
        V t_2 = v_rest_245;
        V t_3 = v_t_2412;
        v_t_240 = t_0;
        v_here_241 = t_1;
        v_x3_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
    case TAG_EGlobal: {
      V v_g_2413 = heff_field(v_x31_244, 0);
      V v_ru_24x31_244_24EGlobal = heff_take_reuse_n(v_x31_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(v_ru_24x31_244_24EGlobal, heff_rfield(v_n_243, 1), v_g_2413));
      V v_t_2415 = ({ V a_0 = heff_dup(v_here_241); V a_1 = v_g_2413; V a_2 = MK_INT(0LL); V a_3 = v_t_2414; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_2413); heff_drop(v_t_2414); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2415;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2417 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 2ULL, 2);
      V v_t_2418 = heff_rec_n(4, shape_key__params__many__ar, (V[]){heff_dup(heff_rfield(v_here_241, 0)), heff_dup(heff_rfield(v_here_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_here_241, 3))});
      V v_t_2419 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2417, NTAG(TAG_Nil)});
      V v_t_2420 = (g_heff_2ecompile_2ecallarity_2eusesW(v_t_240, v_t_2418, v_t_2419, v_n_243));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_rest_245;
      V t_3 = v_t_2420;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2421 = heff_field(v_x31_244, 0);
      V v_args_2422 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24EApp = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_t_2426;
      switch (heff_tag_of(v_f_2421)) {
      case TAG_EVar: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2426 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_244_24EApp, heff_dup(v_args_2422), v_rest_245));
        break;
      }
      case TAG_EGlobal: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_244_24EApp, 2);
        v_t_2426 = ({ V a_0 = heff_dup(v_args_2422); V a_1 = v_rest_245; V r_ = (g_heff_2ecompile_2ecallarity_2epushNonVars(a_0, a_1)); heff_drop(v_rest_245); r_; });
        break;
      }
      default: {
        V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_244_24EApp, heff_dup(v_args_2422), v_rest_245));
        v_t_2426 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_f_2421), v_t_2425});
        break;
      }
      }
      V v_t_2427 = ({ V a_0 = v_t_240; V a_1 = heff_dup(v_here_241); V a_2 = v_f_2421; V a_3 = v_args_2422; V a_4 = v_n_243; V r_ = (g_heff_2ecompile_2ecallarity_2eappNote(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_2421); heff_drop(v_args_2422); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2426;
      V t_3 = v_t_2427;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2428 = heff_field(v_x31_244, 0);
      V v_args_2429 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24ECall = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_f_2430 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_g_2428)});
      V v_args_2431 = heff_dup(v_args_2429);
      V v_rest_2432 = v_rest_245;
      V v_t_2436;
      switch (heff_tag_of(v_f_2430)) {
      case TAG_EVar: {
        heff_take_n(v_f_2430, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_2436 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_244_24ECall, v_args_2431, v_rest_2432));
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_f_2430, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_244_24ECall, 2);
        v_t_2436 = ({ V a_0 = v_args_2431; V a_1 = v_rest_2432; V r_ = (g_heff_2ecompile_2ecallarity_2epushNonVars(a_0, a_1)); heff_drop(v_rest_2432); r_; });
        break;
      }
      default: {
        V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_244_24ECall, v_args_2431, v_rest_2432));
        v_t_2436 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2430, v_t_2435});
        break;
      }
      }
      V v_lit_2437 = v_g_2428;
      V v_t_2438 = heff_dup(v_t_240);
      V v_here_2439 = heff_dup(v_here_241);
      V v_args_2440 = v_args_2429;
      V v_n_2441 = v_n_243;
      V v_k_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2440));
      V v_t_2443 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_n_2441, 1), v_lit_2437));
      V v_t_2444 = ({ V a_0 = heff_dup(v_here_2439); V a_1 = v_lit_2437; V a_2 = v_k_2442; V a_3 = v_t_2443; V a_4 = v_n_2441; V r_ = (g_heff_2ecompile_2ecallarity_2enoteUse(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2443); r_; });
      V v_t_2445 = ({ V a_0 = v_t_2438; V a_1 = v_here_2439; V a_2 = v_lit_2437; V a_3 = MK_INT(0LL); V a_4 = v_args_2440; V a_5 = v_t_2444; V r_ = (g_heff_2ecompile_2ecallarity_2eargsNote(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2438); heff_drop(v_here_2439); heff_drop(v_lit_2437); heff_drop(v_args_2440); r_; });
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2436;
      V t_3 = v_t_2445;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2446 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_244, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_here_241;
      V t_2 = v_t_2446;
      V t_3 = v_n_243;
      v_t_240 = t_0;
      v_here_241 = t_1;
      v_x3_242 = t_2;
      v_n_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eusesW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecallarity_2eusesW(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2ecallarity_2edefNotes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edefNotes_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2edefNotes(V v_t_240, V v_ar_241, V v_gl_242, V v_d_243) {
top: ;
  V v_body_244 = heff_take_field(v_d_243, 2);
  V v_key_245 = heff_get_n(v_d_243, 0, 3);
  V v_t_246 = heff_dup(v_body_244);
  V v_t_2446;
  switch (heff_tag_of(v_t_246)) {
  case TAG_EVar: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    v_t_2446 = v_xs_249;
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_246, 0ULL, 3);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_246, 0ULL, 4);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_246, 0ULL, 3);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_t_246, 0ULL, 3);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_2446 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_2447 = heff_dup(v_body_244);
  V v_t_2487;
  switch (heff_tag_of(v_t_2447)) {
  case TAG_EVar: {
    heff_take_n(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELam: {
    V v_xs_2450 = heff_field(v_t_2447, 0);
    heff_take_n(v_t_2447, 1ULL, 2);
    v_t_2487 = v_xs_2450;
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_2447, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_2447, 0ULL, 3);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_2447, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_2447, 0ULL, 4);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_2447, 0ULL, 3);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_2447, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_2447, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_2447, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_2447, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EAbandon: {
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_t_2447, 0ULL, 3);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_t_2447, 0ULL, 1);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_2447, 0ULL, 2);
    v_t_2487 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_2447);
  }
  V v_t_2488 = ({ V a_0 = MK_INT(1000000LL); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_t_2487; V r_ = (g_list_2efoldl_24s619143909x1041174639(a_0, a_1, a_2)); heff_drop(v_t_2487); r_; });
  V v_t_2489 = heff_rec_n(4, shape_key__params__many__ar, (V[]){v_key_245, v_t_2446, NTAG(TAG_False), v_ar_241});
  V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_body_244, NTAG(TAG_Nil)});
  V v_t_2491 = heff_rec_n(3, shape_vars__globals__dirty, (V[]){v_t_2488, v_gl_242, NTAG(TAG_False)});
  HEFF_LAST return g_heff_2ecompile_2ecallarity_2eusesW(v_t_240, v_t_2489, v_t_2490, v_t_2491);
}
V g_heff_2ecompile_2ecallarity_2edefNotes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecallarity_2edefNotes(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eknownAdd_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eknownAdd(V v_k_240, V v_d_241, V v_n_242) {
top: ;
  V v_vars_243 = heff_take_field(v_n_242, 0);
  V v_globals_244 = heff_get_n(v_n_242, 1, 3);
  V v_body_245 = heff_take_field(v_d_241, 2);
  V v_key_246 = heff_get_n(v_d_241, 0, 3);
  V v_t_247 = v_body_245;
  switch (heff_tag_of(v_t_247)) {
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24ELam = heff_take_reuse_n(v_t_247, 1ULL, 2);
    V v_t_2415 = (g_list_2emap_24tok2(v_ru_24t_247_24ELam, heff_clo_n(g_heff_2ecompile_2ecallarity_2eknownAdd_lam0, 1, 1, (V[]){v_vars_243}), v_xs_248));
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_k_240, 0)), 0, 1);
    V v_t_2417 = ({ V a_0 = v_t_2416; V a_1 = v_key_246; V a_2 = v_t_2415; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_246); heff_drop(v_t_2415); r_; });
    return ({ V rv_0 = heff_rec_n(1, shape_pa, (V[]){v_t_2417}); V rv_1 = v_globals_244; V rr_ = heff_rec_reuse_nf(v_k_240, 0ULL, 2, shape_tables__globals, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  default: {
    heff_drop(v_vars_243);
    heff_drop(v_key_246);
    heff_drop(v_t_247);
    return ({ V rv_1 = v_globals_244; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  }
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eknownAdd(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_vars_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = ({ V a_0 = v_vars_243; V a_1 = v_x_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_vars_243); heff_drop(v_x_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_k_2414 = v_field_2413;
      if (heff_intLe_c_lent(MK_INT(1000000LL), v_k_2414, 1)) {
        heff_drop(v_k_2414);
        return MK_INT(0LL);
      } else {
        return v_k_2414;
      }
    } else {
      heff_drop(v_field_2413);
      return MK_INT(0LL);
    }
  }
}
Clo g_heff_2ecompile_2ecallarity_2eextendAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eextendAt_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eextendAt(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_zs_240)) {
  case TAG_Nil: {
    return v_e_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      V v_t_245 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_245});
    }
    case TAG_EGlobal: {
      V v_t_247 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_247});
    }
    case TAG_ELam: {
      V v_ys_248 = heff_field(v_e_241, 0);
      V v_b_249 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
      V v_y_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
      if (heff_intLt_c(v_y_2411, v_x_2410)) {
        V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
        V v_t_2413 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2412, heff_dup(v_ys_248)));
        V v_m_2414 = ({ V a_0 = v_ys_248; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_248); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2415 = (g_std_2eordmap_2esize(v_m_2414));
        V v_t_2416;
        if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
          heff_drop(v_m_2414);
          v_t_2416 = v_b_249;
        } else {
          v_t_2416 = ({ V a_0 = v_m_2414; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2414); r_; });
        }
        return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_t_2416});
      } else {
        heff_drop_cell(v_ru_24e_241_24ELam, 2);
        V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
        V v_t_2418 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2417, heff_dup(v_zs_240)));
        V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextendAt_clo), 1, (V[]){v_t_2418}));
        V v_m_2420 = ({ V a_0 = v_ys_248; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_248); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2421 = (g_std_2eordmap_2esize(v_m_2420));
        V v_t_2422;
        if (heff_intEq_c(v_t_2421, MK_INT(0LL))) {
          heff_drop(v_m_2420);
          v_t_2422 = v_b_249;
        } else {
          v_t_2422 = ({ V a_0 = v_m_2420; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2420); r_; });
        }
        HEFF_LAST return g_heff_2ecompile_2eir_2ewaysMap(v_t_2419, v_t_2422);
      }
    }
    case TAG_EApp: {
      V v_f_2423 = heff_field(v_e_241, 0);
      V v_args_2424 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_t_2425 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2426 = (g_prelude_2e_2b_2b(v_args_2424, v_t_2425));
      return heff_tag_re_n(v_ru_24e_241_24EApp, TAG_EApp, 2, 1ULL, (V[]){v_f_2423, v_t_2426});
    }
    case TAG_ELet: {
      V v_t_2430 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2430});
    }
    case TAG_ERecord: {
      V v_t_2433 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2433});
    }
    case TAG_EProj: {
      V v_t_2438 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2438});
    }
    case TAG_ETag: {
      V v_t_2442 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2442});
    }
    case TAG_EMatch: {
      V v_t_2445 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2445});
    }
    case TAG_EPrim: {
      V v_t_2447 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2447});
    }
    case TAG_EPrimCall: {
      V v_t_2450 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2450});
    }
    case TAG_ECall: {
      V v_t_2453 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2453});
    }
    case TAG_EInt: {
      V v_t_2455 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2455});
    }
    case TAG_EFloat: {
      V v_t_2457 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2457});
    }
    case TAG_EStr: {
      V v_t_2459 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2459});
    }
    case TAG_EBytes: {
      V v_t_2461 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2461});
    }
    case TAG_EFixed: {
      V v_t_2464 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2464});
    }
    case TAG_EFloat32: {
      V v_t_2466 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2466});
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_zs_240, 2);
      return NTAG(TAG_EAbandon);
    }
    case TAG_EBool: {
      V v_t_2468 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2468});
    }
    case TAG_ESet: {
      V v_t_2472 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2472});
    }
    case TAG_EValues: {
      V v_t_2474 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2474});
    }
    case TAG_EFix: {
      V v_t_2477 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2477});
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_zs_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eextendAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eextendAt(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(V v_d_240, V v_calls_241, V v_uses_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_calls_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{v_d_240, v_p_243}});
  }
  case TAG_Just: {
    V v_m_244 = heff_field(v_calls_241, 0);
    switch (heff_tag_of(v_uses_242)) {
    case TAG_Nothing: {
      return ((HeffT2){{v_d_240, v_p_243}});
    }
    case TAG_Just: {
      V v_uses1_245 = heff_field(v_uses_242, 0);
      if (heff_intEq_c_lent(v_uses1_245, MK_INT(1LL), 2)) {
        if (heff_intLt_c_lent(MK_INT(0LL), v_m_244, 1)) {
          HeffT2 v_t_246 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(heff_dup(v_m_244), v_p_243));
          {
            V v_field_247 = v_t_246.f[0];
            V v_field_248 = v_t_246.f[1];
            V v_x_249 = v_field_247;
            V v_n_2410 = v_field_248;
            V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextendAt_clo), 1, (V[]){heff_dup(v_x_249)}));
            V v_t_2412 = heff_tr(g_heff_2ecompile_2eir_2ewaysMap(v_t_2411, heff_take_field(v_d_240, 2)));
            V v_body_2413 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_249, v_t_2412});
            V v_f_2414 = ({ V rv_2 = v_body_2413; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            return ((HeffT2){{v_f_2414, v_n_2410}});
          }
        } else {
          return ((HeffT2){{v_d_240, v_p_243}});
        }
      } else {
        return ((HeffT2){{v_d_240, v_p_243}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_uses_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_calls_241)}});
  }
}

HeffT2 g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(V v_gl_240, V v_d_241, V v_z_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_t_243, 0);
    V v_b_245 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24ELam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_d_246 = heff_dup(v_d_241);
    V v_xs_247 = v_xs_244;
    V v_b_248 = v_b_245;
    HeffT2 v_t_249 = ({ V a_0 = v_gl_240; V b_1 = heff_get_n(v_d_241, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_x4_2413;
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_u_2412 = v_field_2411;
        v_x4_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2412, 0, 3)});
      } else {
        heff_drop(v_field_2411);
        v_x4_2413 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_x4_2413)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_243_24ELam, 2);
        heff_drop(v_xs_247);
        heff_drop(v_b_248);
        return ((HeffT2){{v_d_246, v_z_242}});
      }
      case TAG_Just: {
        V v_m_2414 = heff_field(v_x4_2413, 0);
        heff_take_n(v_x4_2413, 1ULL, 1);
        V v_y_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
        if (heff_intLt_c_lent(v_y_2415, v_m_2414, 1)) {
          V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
          V v_t_2417 = heff_intSub(v_m_2414, v_t_2416);
          HeffT2 v_t_2418 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_t_2417, v_z_242));
          {
            V v_field_2419 = v_t_2418.f[0];
            V v_field_2420 = v_t_2418.f[1];
            V v_x_2421 = v_field_2419;
            V v_n_2422 = v_field_2420;
            V v_t_2423 = (g_prelude_2e_2b_2b(v_xs_247, heff_dup(v_x_2421)));
            V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextendAt_clo), 1, (V[]){v_x_2421}));
            V v_t_2425 = heff_tr(g_heff_2ecompile_2eir_2ewaysMap(v_t_2424, v_b_248));
            V v_body_2426 = heff_tag_at_n(v_ru_24t_243_24ELam, TAG_ELam, 2, (V[]){v_t_2423, v_t_2425});
            V v_f_2427 = ({ V rv_2 = v_body_2426; V rr_ = heff_rec_reuse_nf(v_d_246, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            return ((HeffT2){{v_f_2427, v_n_2422}});
          }
        } else {
          heff_drop_cell(v_ru_24t_243_24ELam, 2);
          heff_drop(v_xs_247);
          heff_drop(v_b_248);
          heff_drop(v_m_2414);
          return ((HeffT2){{v_d_246, v_z_242}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x4_2413)}});
      }
    }
  }
  default: {
    heff_drop(v_t_243);
    HeffT2 v_t_2428 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      V v_t_2432;
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_u_2431 = v_field_2430;
        v_t_2432 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2431, 0, 3)});
      } else {
        heff_drop(v_field_2430);
        v_t_2432 = NTAG(TAG_Nothing);
      }
      HeffT2 v_t_2433 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
      {
        V v_field_2435 = v_t_2433.f[1];
        int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
        V v_t_2437;
        if ((v_tag_2434 == ((int64_t)0ULL))) {
          V v_u_2436 = v_field_2435;
          v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2436, 1, 3)});
        } else {
          heff_drop(v_field_2435);
          v_t_2437 = NTAG(TAG_Nothing);
        }
        return ({ V a_0 = v_d_241; V a_1 = v_t_2432; V a_2 = v_t_2437; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2432); heff_drop(v_t_2437); r_; });
      }
    }
  }
  }
}

HeffT2 g_heff_2ecompile_2ecallarity_2eexpandArg_24cpr(V v_t_240, V v_h_241, V v_j_242, V v_a_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_a_243)) {
  case TAG_ELam: {
    V v_ys_245 = heff_field(v_a_243, 0);
    V v_b_246 = heff_field(v_a_243, 1);
    V v_ru_24a_243_24ELam = heff_take_reuse_n(v_a_243, 3ULL, 2);
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_t_240, 0), v_h_241));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_x_2411;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_ps_2410 = v_field_249;
        v_x_2411 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_242); V a_2 = v_ps_2410; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2410); r_; });
      } else {
        heff_drop(v_field_249);
        v_x_2411 = MK_INT(0LL);
      }
      V v_y_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245));
      if (heff_intLt_c(v_y_2412, v_x_2411)) {
        HeffT2 v_t_2413 = ({ V b_0 = heff_get_n(v_t_240, 0, 1); V a_1 = v_h_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          V v_t_2417;
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_ps_2416 = v_field_2415;
            v_t_2417 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_242; V a_2 = v_ps_2416; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2416); r_; });
          } else {
            heff_drop(v_j_242);
            heff_drop(v_field_2415);
            v_t_2417 = MK_INT(0LL);
          }
          V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_245));
          V v_t_2419 = heff_intSub(v_t_2417, v_t_2418);
          HeffT2 v_t_2420 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_t_2419, v_z_244));
          {
            V v_field_2421 = v_t_2420.f[0];
            V v_field_2422 = v_t_2420.f[1];
            V v_x_2423 = v_field_2421;
            V v_n_2424 = v_field_2422;
            V v_t_2425 = (g_prelude_2e_2b_2b(v_ys_245, heff_dup(v_x_2423)));
            V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextendAt_clo), 1, (V[]){v_x_2423}));
            V v_t_2427 = heff_tr(g_heff_2ecompile_2eir_2ewaysMap(v_t_2426, v_b_246));
            V v_x_2428 = heff_tag_at_n(v_ru_24a_243_24ELam, TAG_ELam, 2, (V[]){v_t_2425, v_t_2427});
            return ((HeffT2){{v_x_2428, v_n_2424}});
          }
        }
      } else {
        heff_drop_rec(v_t_240, 1);
        heff_drop(v_j_242);
        return ((HeffT2){{heff_tag_re_n(v_ru_24a_243_24ELam, TAG_ELam, 2, 3ULL, (V[]){v_ys_245, v_b_246}), v_z_244}});
      }
    }
  }
  default: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return ((HeffT2){{v_a_243, v_z_244}});
  }
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0(V self, V *args); static Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0, 1, 0};
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArgs_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eexpandArgs(V v_go_240, V v_t_241, V v_h_242, V v_j_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_t_241);
    heff_drop(v_j_243);
    return ((V)&g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_244, 0);
    V v_args_247 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_246}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1, 1, 6, (V[]){v_m_248, v_t_241, heff_dup(v_h_242), v_j_243, v_go_240, v_args_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eexpandArgs(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam0(V self, V *args) {
  V v_n_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandArgs_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_h_242 = heff_env(self)[2];
  V v_j_243 = heff_env(self)[3];
  V v_go_240 = heff_env(self)[4];
  V v_args_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    HeffT2 v_t_2413 = (g_heff_2ecompile_2ecallarity_2eexpandArg_24cpr(heff_dup(v_t_241), v_h_242, heff_dup(v_j_243), v_x_2411, v_n_2412));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      V v_n_2417 = v_field_2415;
      V v_t_2418 = ({ V a_0 = v_go_240; V a_1 = v_t_241; V a_2 = v_h_242; V a_3 = heff_intAdd(v_j_243, MK_INT(1LL)); V a_4 = v_args_247; V r_ = (g_heff_2ecompile_2ecallarity_2eexpandArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_h_242); r_; });
      V v_x2_2419 = heff_tr(heff_call(v_t_2418, 1, (V[]){v_n_2417}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_MkPair: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_n_2421 = heff_field(v_x2_2419, 1);
        V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_Cons, 2, (V[]){v_x_2416, v_x_2420}), v_n_2421});
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandGo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eexpandGo(V v_t_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EApp: {
    V v_f_242 = heff_field(v_e_241, 0);
    V v_args_243 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_go_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    V v_t_245 = v_t_240;
    V v_f_246 = v_f_242;
    V v_args_247 = v_args_243;
    switch (heff_tag_of(v_f_246)) {
    case TAG_EGlobal: {
      V v_g_248 = heff_field(v_f_246, 0);
      heff_take_n(v_f_246, 1ULL, 1);
      V v_m_249 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_go_244, v_t_245, v_g_248, MK_INT(0LL), v_args_247));
      return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam0, 1, 2, (V[]){v_m_249, v_g_248});
    }
    default: {
      heff_drop(v_t_245);
      V v_m_2415 = heff_tr(heff_call(heff_dup(v_go_244), 1, (V[]){v_f_246}));
      return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam1, 1, 3, (V[]){v_m_2415, v_go_244, v_args_247});
    }
    }
  }
  case TAG_ECall: {
    V v_g_2424 = heff_field(v_e_241, 0);
    V v_args_2425 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    V v_m_2427 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_t_2426, v_t_240, v_g_2424, MK_INT(0LL), v_args_2425));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam2, 1, 2, (V[]){v_m_2427, v_g_2424});
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam3, 2, 1, (V[]){v_t_240}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandGo(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args) {
  V v_n_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_g_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_n_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_t_2414 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_248}), v_x_2412});
    return heff_tag_re_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2414, v_n_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_go_244 = heff_env(self)[1];
  V v_args_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = (g_prelude_2etraverse_24s1887447647x928396251(v_go_244, v_args_247));
    V v_x2_2421 = heff_tr(heff_call(v_t_2420, 1, (V[]){v_n_2419}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_n_2423 = heff_field(v_x2_2421, 1);
      V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_EApp, 2, (V[]){v_x_2418, v_x_2422}), v_n_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args) {
  V v_n_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_g_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_n_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_n_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2424, v_x_2430}), v_n_2431});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_p_2433 = args[1];
  V v_t_240 = heff_env(self)[0];
  heff_drop(v_x_2432);
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_p_2433));
}
Clo g_heff_2ecompile_2ecallarity_2esameInts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameInts_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameInts(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_intEq_c_lent(v_x_244, v_y_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2esameInts_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2esameInts(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2esameAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esameAll_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esameAll(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2ecallarity_2esameInts(v_x_244, v_y_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2esameAll_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2esameAll(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

static V g_heff_2ecompile_2ecallarity_2erounds_24rec0_val;
static HEFF_ONCE g_heff_2ecompile_2ecallarity_2erounds_24rec0_st;
static V g_heff_2ecompile_2ecallarity_2erounds_24rec0_init(void) {
  return heff_rec_n(1, shape_pa, (V[]){heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2ecompile_2ecallarity_2erounds_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ecallarity_2erounds_24rec0_st)) return g_heff_2ecompile_2ecallarity_2erounds_24rec0_val;
  return heff_global(&g_heff_2ecompile_2ecallarity_2erounds_24rec0_val, &g_heff_2ecompile_2ecallarity_2erounds_24rec0_st, g_heff_2ecompile_2ecallarity_2erounds_24rec0_init);
}

static V g_heff_2ecompile_2ecallarity_2erounds_24rec1_val;
static HEFF_ONCE g_heff_2ecompile_2ecallarity_2erounds_24rec1_st;
static V g_heff_2ecompile_2ecallarity_2erounds_24rec1_init(void) {
  return heff_rec_n(2, shape_tables__globals, (V[]){heff_dup(g_heff_2ecompile_2ecallarity_2erounds_24rec0_get()), heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2ecompile_2ecallarity_2erounds_24rec1_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2ecallarity_2erounds_24rec1_st)) return g_heff_2ecompile_2ecallarity_2erounds_24rec1_val;
  return heff_global(&g_heff_2ecompile_2ecallarity_2erounds_24rec1_val, &g_heff_2ecompile_2ecallarity_2erounds_24rec1_st, g_heff_2ecompile_2ecallarity_2erounds_24rec1_init);
}
V g_heff_2ecompile_2ecallarity_2erounds_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2erounds_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2erounds(V v_left_240, V v_before_241, V v_defs_242, V v_n_243) {
top: ;
  if (heff_intLe_c_lent(v_left_240, MK_INT(0LL), 2)) {
    heff_drop(v_left_240);
    heff_drop_rec(v_before_241, 2);
    return heff_rec_n(2, shape_defs__supply, (V[]){v_defs_242, v_n_243});
  } else {
    V v_more_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2erounds_clo), 1, (V[]){heff_intSub(v_left_240, MK_INT(1LL))}));
    V v_before_245 = heff_dup(v_before_241);
    V v_n_246 = heff_dup(v_n_243);
    V v_ar_247 = (g_list_2efoldl_24s445268946x679229867(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_242));
    V v_t_248 = heff_rec_n(3, shape_known__defs__supply, (V[]){heff_dup(g_heff_2ecompile_2ecallarity_2erounds_24rec1_get()), NTAG(TAG_Nil), v_n_243});
    V v_acc_2434 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecallarity_2erounds_lam0, 2, 2, (V[]){v_before_241, v_ar_247}); V a_1 = v_t_248; V a_2 = v_defs_242; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_defs_242); r_; });
    V v_supply_2435 = heff_take_field(v_acc_2434, 2);
    V v_known_2436 = heff_take_field(v_acc_2434, 0);
    V v_defs_2437 = heff_get_n(v_acc_2434, 1, 3);
    if (heff_intEq_c_lent(v_supply_2435, v_n_246, 0)) {
      V v_a_2438 = heff_get_n(v_before_245, 0, 2);
      V v_b_2439 = heff_dup(heff_rfield(v_known_2436, 0));
      V v_t_2440 = (g_std_2eordmap_2esize(heff_rfield(v_a_2438, 0)));
      V v_t_2441 = (g_std_2eordmap_2esize(heff_rfield(v_b_2439, 0)));
      V v_t_2446;
      if (heff_intEq_c(v_t_2440, v_t_2441)) {
        V v_t_2442 = ({ V b_0 = heff_get_n(v_a_2438, 0, 1); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2443 = (g_list_2emap_24s366344330x1145113647(v_t_2442));
        V v_t_2444 = ({ V b_0 = heff_get_n(v_b_2439, 0, 1); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2445 = (g_list_2emap_24s366344330x1145113647(v_t_2444));
        v_t_2446 = ({ V a_0 = v_t_2443; V a_1 = v_t_2445; V r_ = (g_heff_2ecompile_2ecallarity_2esameAll(a_0, a_1)); heff_drop(v_t_2443); heff_drop(v_t_2445); r_; });
      } else {
        heff_drop_rec(v_a_2438, 1);
        heff_drop_rec(v_b_2439, 1);
        v_t_2446 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_more_244);
        heff_drop(v_supply_2435);
        heff_drop_rec(v_known_2436, 2);
        heff_drop(v_t_2446);
        V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2437));
        return heff_rec_n(2, shape_defs__supply, (V[]){v_t_2447, v_n_246});
      } else {
        heff_drop(v_n_246);
        heff_drop(v_t_2446);
        V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2437));
        return heff_tail(v_more_244, 3, (V[]){v_known_2436, v_t_2448, v_supply_2435});
      }
    } else {
      heff_drop_rec(v_before_245, 2);
      heff_drop(v_n_246);
      V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2437));
      return heff_tail(v_more_244, 3, (V[]){v_known_2436, v_t_2449, v_supply_2435});
    }
  }
}
V g_heff_2ecompile_2ecallarity_2erounds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2erounds(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2erounds_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_d_2410 = args[1];
  V v_before_241 = heff_env(self)[0];
  V v_ar_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_before_241, 1, 2); V a_1 = v_d_2410; V a_2 = heff_dup(heff_rfield(v_acc_249, 2)); HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    V v_d_2414 = v_field_2412;
    V v_n_2415 = v_field_2413;
    V v_ar_2416 = heff_dup(v_ar_247);
    V v_acc_2417 = heff_dup(v_acc_249);
    V v_known_2418 = heff_take_field(v_acc_2417, 0);
    V v_defs_2419 = heff_get_n(v_acc_2417, 1, 3);
    V v_d_2420 = heff_dup(v_d_2414);
    V v_n_2421 = v_n_2415;
    V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_acc_249, 0)), 0, 2);
    V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_acc_249, 0)), 1, 2);
    V v_notes_2424 = ({ V a_0 = v_t_2422; V a_1 = v_ar_247; V a_2 = v_t_2423; V a_3 = v_d_2414; V r_ = (g_heff_2ecompile_2ecallarity_2edefNotes(a_0, a_1, a_2, a_3)); heff_drop(v_t_2422); r_; });
    V v_t_2425 = heff_dup(heff_rfield(v_notes_2424, 2));
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop_rec(v_notes_2424, 3);
      heff_drop(v_t_2425);
      V v_t_2426 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(heff_rfield(v_known_2418, 0)), heff_take_field(v_d_2420, 2)));
      V v_x2_2427 = heff_tr(heff_call(v_t_2426, 1, (V[]){v_n_2421}));
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_MkPair: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_n_2429 = heff_field(v_x2_2427, 1);
        heff_take_n(v_x2_2427, 3ULL, 2);
        V v_d_2430 = ({ V rv_2 = v_x_2428; V rr_ = heff_rec_reuse_nf(v_d_2420, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2431 = (g_heff_2ecompile_2ecallarity_2edefNotes(heff_rfield(v_known_2418, 0), v_ar_2416, heff_dup(heff_rfield(v_known_2418, 1)), heff_dup(v_d_2430)));
        V v_k_2432 = (g_heff_2ecompile_2ecallarity_2eknownAdd(v_known_2418, heff_dup(v_d_2430), v_t_2431));
        return ({ V rv_0 = v_k_2432; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2430, v_defs_2419}); V rv_2 = v_n_2429; V rr_ = heff_rec_reuse_nf(v_acc_249, 0ULL, 3, shape_known__defs__supply, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      default: return heff_nomatch(v_x2_2427);
      }
    } else {
      heff_drop(v_ar_2416);
      heff_drop(v_t_2425);
      V v_k_2433 = (g_heff_2ecompile_2ecallarity_2eknownAdd(v_known_2418, heff_dup(v_d_2420), v_notes_2424));
      return ({ V rv_0 = v_k_2433; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2420, v_defs_2419}); V rv_2 = v_n_2421; V rr_ = heff_rec_reuse_nf(v_acc_249, 0ULL, 3, shape_known__defs__supply, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    }
  }
}
Clo g_heff_2ecompile_2ecallarity_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ecallOf_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2ecallOf(V v_go_240, V v_ar_241, V v_h_242, V v_args_243) {
top: ;
  switch (heff_tag_of(v_h_242)) {
  case TAG_EGlobal: {
    V v_g_244 = heff_dup(heff_field(v_h_242, 0));
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_ar_241, v_g_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_n_248 = v_field_247;
        V v_x_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
        if (heff_intLe_c_lent(v_n_248, v_x_249, 2)) {
          heff_drop(v_go_240);
          heff_drop_tag(v_h_242, 1);
          V v_t_2410 = (g_list_2etake(heff_dup(v_n_248), heff_dup(v_args_243)));
          V v_f_2411 = heff_tag_n(TAG_ECall, 2, (V[]){v_g_244, v_t_2410});
          V v_args_2412 = ({ V a_0 = v_n_248; V a_1 = v_args_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_args_243); r_; });
          V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2412));
          if (heff_intEq_c(v_t_2413, MK_INT(0LL))) {
            heff_drop(v_args_2412);
            return v_f_2411;
          } else {
            return heff_tag_n(TAG_EApp, 2, (V[]){v_f_2411, v_args_2412});
          }
        } else {
          heff_drop(v_g_244);
          heff_drop(v_n_248);
          V v_t_2414 = heff_tr(heff_call(v_go_240, 1, (V[]){v_h_242}));
          return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2414, v_args_243});
        }
      } else {
        heff_drop(v_g_244);
        heff_drop(v_field_247);
        V v_t_2415 = heff_tr(heff_call(v_go_240, 1, (V[]){v_h_242}));
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2415, v_args_243});
      }
    }
  }
  case TAG_EPrim: {
    V v_p_2416 = heff_dup(heff_field(v_h_242, 0));
    V v_x_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
    V v_t_2418 = (g_heff_2eelab_2eprimitive_2eprimArity(v_p_2416));
    if (heff_intLe_c(v_t_2418, v_x_2417)) {
      heff_drop(v_go_240);
      heff_drop_tag(v_h_242, 1);
      V v_t_2419 = (g_heff_2eelab_2eprimitive_2eprimArity(v_p_2416));
      V v_t_2420 = (g_list_2etake(v_t_2419, heff_dup(v_args_243)));
      V v_f_2421 = heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(v_p_2416), v_t_2420});
      V v_t_2422 = ({ V a_0 = v_p_2416; V r_ = (g_heff_2eelab_2eprimitive_2eprimArity(a_0)); heff_drop(v_p_2416); r_; });
      V v_args_2423 = ({ V a_0 = v_t_2422; V a_1 = v_args_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_args_243); r_; });
      V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
      if (heff_intEq_c(v_t_2424, MK_INT(0LL))) {
        heff_drop(v_args_2423);
        return v_f_2421;
      } else {
        return heff_tag_n(TAG_EApp, 2, (V[]){v_f_2421, v_args_2423});
      }
    } else {
      heff_drop(v_p_2416);
      V v_t_2425 = heff_tr(heff_call(v_go_240, 1, (V[]){v_h_242}));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2425, v_args_243});
    }
  }
  default: {
    V v_t_2426 = heff_tr(heff_call(v_go_240, 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2426, v_args_243});
  }
  }
}
V g_heff_2ecompile_2ecallarity_2ecallOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2ecallOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecallarity_2esatGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2esatGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2esatGo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2esatGo(V v_ar_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EApp: {
    V v_f_242 = heff_field(v_e_241, 0);
    V v_args_243 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2esatGo_clo), 1, (V[]){heff_dup(v_ar_240)}));
    HeffT2 v_t_245 = ({ V a_0 = v_f_242; HeffT2 r_ = (g_heff_2ecompile_2eir_2espine_24cpr(a_0)); heff_drop(v_f_242); r_; });
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_h_248 = v_field_246;
      V v_bs_249 = v_field_247;
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24e_241_24EApp, v_bs_249, v_args_243));
      V v_t_2411 = (g_list_2emap(heff_dup(v_go_244), v_t_2410));
      return ({ V a_0 = v_go_244; V a_1 = v_ar_240; V a_2 = v_h_248; V a_3 = v_t_2411; V r_ = (g_heff_2ecompile_2ecallarity_2ecallOf(a_0, a_1, a_2, a_3)); heff_drop(v_ar_240); r_; });
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2ecallarity_2esatGo_lam0, 2, 1, (V[]){v_ar_240}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2ecallarity_2esatGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2esatGo(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2esatGo_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_2413 = args[1];
  V v_ar_240 = heff_env(self)[0];
  heff_drop(v_x_2412);
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2ecallarity_2esatGo(v_ar_240, v_p_2413));
}
Clo g_heff_2ecompile_2ecallarity_2ecallOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ecallOf_24tok2_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2ecallOf_24tok2(V v_tok_240, V v_go_241, V v_ar_242, V v_h_243, V v_args_244) {
top: ;
  switch (heff_tag_of(v_h_243)) {
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_h_243, 0));
    HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_ar_242, v_g_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_n_249 = v_field_248;
        V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_244));
        if (heff_intLe_c_lent(v_n_249, v_x_2410, 2)) {
          heff_drop(v_go_241);
          heff_drop_tag(v_h_243, 1);
          V v_t_2411 = (g_list_2etake(heff_dup(v_n_249), heff_dup(v_args_244)));
          V v_f_2412 = heff_tag_at_n(v_tok_240, TAG_ECall, 2, (V[]){v_g_245, v_t_2411});
          V v_args_2413 = ({ V a_0 = v_n_249; V a_1 = v_args_244; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_args_244); r_; });
          V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2413));
          if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
            heff_drop(v_args_2413);
            return v_f_2412;
          } else {
            return heff_tag_n(TAG_EApp, 2, (V[]){v_f_2412, v_args_2413});
          }
        } else {
          heff_drop(v_g_245);
          heff_drop(v_n_249);
          V v_t_2415 = heff_tr(heff_call(v_go_241, 1, (V[]){v_h_243}));
          return heff_tag_at_n(v_tok_240, TAG_EApp, 2, (V[]){v_t_2415, v_args_244});
        }
      } else {
        heff_drop(v_g_245);
        heff_drop(v_field_248);
        V v_t_2416 = heff_tr(heff_call(v_go_241, 1, (V[]){v_h_243}));
        return heff_tag_at_n(v_tok_240, TAG_EApp, 2, (V[]){v_t_2416, v_args_244});
      }
    }
  }
  case TAG_EPrim: {
    V v_p_2417 = heff_dup(heff_field(v_h_243, 0));
    V v_x_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_244));
    V v_t_2419 = (g_heff_2eelab_2eprimitive_2eprimArity(v_p_2417));
    if (heff_intLe_c(v_t_2419, v_x_2418)) {
      heff_drop(v_go_241);
      heff_drop_tag(v_h_243, 1);
      V v_t_2420 = (g_heff_2eelab_2eprimitive_2eprimArity(v_p_2417));
      V v_t_2421 = (g_list_2etake(v_t_2420, heff_dup(v_args_244)));
      V v_f_2422 = heff_tag_at_n(v_tok_240, TAG_EPrimCall, 2, (V[]){heff_dup(v_p_2417), v_t_2421});
      V v_t_2423 = ({ V a_0 = v_p_2417; V r_ = (g_heff_2eelab_2eprimitive_2eprimArity(a_0)); heff_drop(v_p_2417); r_; });
      V v_args_2424 = ({ V a_0 = v_t_2423; V a_1 = v_args_244; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_args_244); r_; });
      V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2424));
      if (heff_intEq_c(v_t_2425, MK_INT(0LL))) {
        heff_drop(v_args_2424);
        return v_f_2422;
      } else {
        return heff_tag_n(TAG_EApp, 2, (V[]){v_f_2422, v_args_2424});
      }
    } else {
      heff_drop(v_p_2417);
      V v_t_2426 = heff_tr(heff_call(v_go_241, 1, (V[]){v_h_243}));
      return heff_tag_at_n(v_tok_240, TAG_EApp, 2, (V[]){v_t_2426, v_args_244});
    }
  }
  default: {
    V v_t_2427 = heff_tr(heff_call(v_go_241, 1, (V[]){v_h_243}));
    return heff_tag_at_n(v_tok_240, TAG_EApp, 2, (V[]){v_t_2427, v_args_244});
  }
  }
}
V g_heff_2ecompile_2ecallarity_2ecallOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2ecallOf_24tok2(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}