// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Get 18914
#define TAG_HMeta 17321
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SOpaque 44226
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9006
#define TAG_SU 9427
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171_clo;
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V, V, V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2esubstTermF_24generate0(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_24generate0_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24generate0(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate0_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24map1(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24map1_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate0(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate0_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate1(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate1_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate2(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate2_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate3_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24map0(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map0_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24map1(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map1_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24map2(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map2_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24map3(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24map3_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map3_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
Clo g_heff_2eelab_2eunify_2esubstTermF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_24generate0_entry, 5, 0};

V g_heff_2eelab_2eunify_2esubstTermF_24generate0(V v_xs_240, V v_r_241, V v_d_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if (((((int64_t)0ULL) <= v_i_243) && (heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_p_245 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_243));
      V v_t_2410;
      switch (heff_tag_of(v_p_245)) {
      case TAG_MkPair: {
        V v_xs_246 = heff_field(v_p_245, 0);
        V v_b_247 = heff_field(v_p_245, 1);
        V v_t_248 = heff_intAdd_lent(v_d_242, heff_arrayLength_lent(v_xs_246, 0), 2);
        V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){v_t_248, heff_dup(v_b_247)}));
        v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_246), v_t_249});
        break;
      }
      default: heff_nomatch(v_p_245);
      }
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      V t_2 = v_d_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_2410);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_d_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_p_245 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_243));
    V v_t_2410;
    switch (heff_tag_of(v_p_245)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_p_245, 0);
      V v_b_247 = heff_field(v_p_245, 1);
      V v_t_248 = heff_intAdd_lent(v_d_242, heff_arrayLength_lent(v_xs_246, 0), 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){v_t_248, heff_dup(v_b_247)}));
      v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_246), v_t_249});
      break;
    }
    default: heff_nomatch(v_p_245);
    }
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    V t_2 = v_d_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_2410);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    return v_a_244;
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eunify_2esubstTermF_24generate0(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_24generate0_entry, 4, 0};

V g_heff_2eelab_2eunify_2ezonkTermF_24generate0(V v_r_240, V v_xs_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_241, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_xs_241, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_244}));
      V t_0 = v_r_240;
      V t_1 = v_xs_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_245);
      v_r_240 = t_0;
      v_xs_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_xs_241, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_244}));
    V t_0 = v_r_240;
    V t_1 = v_xs_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_245);
    v_r_240 = t_0;
    v_xs_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTermF_24generate0(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezonkTermF_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_24map1_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTermF_24map1(V v_r_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_243}));
      V t_0 = v_r_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_243}));
    V t_0 = v_r_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_24map1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2ezonkTermF_24map1(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTypeF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_lam0, 1, 0};
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTypeF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_lam1, 1, 0};
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTypeF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_lam2, 1, 0};
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTypeF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_lam3, 1, 0};
Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_244}));
    return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_dflt_2410 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_dom_247}));
    V v_f_2412 = heff_take_field(v_r_240, 1);
    V v_t_2418;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2413 = heff_field(v_cod_248, 0);
      V v_b_2414 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_b_2414}));
      v_t_2418 = heff_tag_re_n(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2413, v_t_2415});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_b_2416}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    V v_t_2421;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2419 = heff_field(v_dflt_2410, 0);
      V v_ru_24dflt_2410_24Just = heff_take_reuse_n(v_dflt_2410, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2419}));
      v_t_2421 = heff_tag_at_n(v_ru_24dflt_2410_24Just, TAG_Just, 1, (V[]){v_t_2420});
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_tag_re_n(v_ru_24t_242_24SFunction, TAG_SFunction, 5, 9ULL, (V[]){v_level_246, v_t_2411, v_t_2418, v_implicit_249, v_t_2421});
  }
  case TAG_SRecord: {
    V v_level_2422 = heff_field(v_t_242, 0);
    V v_ft_2423 = heff_field(v_t_242, 1);
    V v_ds_2424 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2425 = heff_take_field(v_ft_2423, 2);
    V v_m_2426 = heff_arrayLength_lent(v_xs_2425, 0);
    V v_t_2431;
    if ((heff_peek_word(v_m_2426) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_2425);
      v_t_2431 = heff_arrayGenerate(v_m_2426, ((V)&g_heff_2eelab_2eunify_2ezonkTypeF_lam0_clo));
    } else {
      V v_t_2428 = heff_arrayIndex_lent(v_xs_2425, MK_INT(0LL), 2);
      V v_y_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_t_2428}));
      V v_t_2430 = heff_arrayKeepsAs_lent(v_xs_2425, v_y_2429, 0);
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop(v_m_2426);
        heff_drop(v_t_2430);
        v_t_2431 = (g_heff_2eelab_2eunify_2ezonkTypeF_24map0(v_r_240, MK_INT(1LL), heff_arraySet(v_xs_2425, MK_INT(0LL), v_y_2429)));
      } else {
        heff_drop(v_t_2430);
        v_t_2431 = ({ V a_0 = v_r_240; V a_1 = v_xs_2425; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2426, v_y_2429); V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF_24generate0(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2425); r_; });
      }
    }
    V v_xs_2432 = heff_take_field(v_ds_2424, 2);
    V v_m_2433 = heff_arrayLength_lent(v_xs_2432, 0);
    V v_t_2438;
    if ((heff_peek_word(v_m_2433) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_xs_2432);
      v_t_2438 = heff_arrayGenerate(v_m_2433, ((V)&g_heff_2eelab_2eunify_2ezonkTypeF_lam1_clo));
    } else {
      V v_t_2435 = heff_arrayIndex_lent(v_xs_2432, MK_INT(0LL), 2);
      V v_y_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2435}));
      V v_t_2437 = heff_arrayKeepsAs_lent(v_xs_2432, v_y_2436, 0);
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_m_2433);
        heff_drop(v_t_2437);
        v_t_2438 = ({ V a_0 = v_r_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2432, MK_INT(0LL), v_y_2436); V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF_24map1(a_0, a_1, a_2)); heff_drop_rec(v_r_240, 2); r_; });
      } else {
        heff_drop(v_t_2437);
        v_t_2438 = ({ V a_0 = v_r_240; V a_1 = v_xs_2432; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2433, v_y_2436); V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF_24generate1(a_0, a_1, a_2, a_3)); heff_drop_rec(v_r_240, 2); heff_drop(v_xs_2432); r_; });
      }
    }
    V v_t_2439 = ({ V rv_2 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_ft_2423, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2440 = ({ V rv_2 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_ds_2424, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_re_n(v_ru_24t_242_24SRecord, TAG_SRecord, 3, 1ULL, (V[]){v_level_2422, v_t_2439, v_t_2440});
  }
  case TAG_SSum: {
    V v_vs_2441 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2442 = heff_take_field(v_vs_2441, 2);
    V v_m_2443 = heff_arrayLength_lent(v_xs_2442, 0);
    V v_t_2453;
    if ((heff_peek_word(v_m_2443) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_xs_2442);
      v_t_2453 = heff_arrayGenerate(v_m_2443, ((V)&g_heff_2eelab_2eunify_2ezonkTypeF_lam2_clo));
    } else {
      V v_xs_2445 = heff_arrayIndex_lent(v_xs_2442, MK_INT(0LL), 2);
      V v_m_2446 = heff_arrayLength_lent(v_xs_2445, 0);
      V v_y_2451;
      if ((heff_peek_word(v_m_2446) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_2445);
        v_y_2451 = heff_arrayGenerate(v_m_2446, ((V)&g_heff_2eelab_2eunify_2ezonkTypeF_lam3_clo));
      } else {
        V v_t_2448 = heff_arrayIndex_lent(v_xs_2445, MK_INT(0LL), 2);
        V v_y_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_t_2448}));
        V v_t_2450 = heff_arrayKeepsAs_lent(v_xs_2445, v_y_2449, 0);
        if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
          heff_drop(v_m_2446);
          heff_drop(v_t_2450);
          v_y_2451 = (g_heff_2eelab_2eunify_2ezonkTypeF_24map2(v_r_240, MK_INT(1LL), heff_arraySet(v_xs_2445, MK_INT(0LL), v_y_2449)));
        } else {
          heff_drop(v_t_2450);
          v_y_2451 = ({ V a_0 = v_r_240; V a_1 = v_xs_2445; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2446, v_y_2449); V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2445); r_; });
        }
      }
      V v_t_2452 = heff_arrayKeepsAs_lent(v_xs_2442, v_y_2451, 0);
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_m_2443);
        heff_drop(v_t_2452);
        v_t_2453 = ({ V a_0 = v_r_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2442, MK_INT(0LL), v_y_2451); V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF_24map3(a_0, a_1, a_2)); heff_drop_rec(v_r_240, 2); r_; });
      } else {
        heff_drop(v_t_2452);
        v_t_2453 = ({ V a_0 = v_xs_2442; V a_1 = v_r_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2443, v_y_2451); V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF_24generate3(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2442); heff_drop_rec(v_r_240, 2); r_; });
      }
    }
    V v_t_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_vs_2441, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2454});
  }
  case TAG_SIsTy: {
    V v_a_2455 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_a_2455}));
    return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2456});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    V v_a_2457 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SPrimArray = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_a_2457}));
    return heff_tag_at_n(v_ru_24t_242_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2458});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTypeF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_u_2427 = args[0];
  heff_drop(v_u_2427);
  return heff_abandon();
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_u_2434 = args[0];
  heff_drop(v_u_2434);
  return heff_abandon();
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_u_2444 = args[0];
  heff_drop(v_u_2444);
  return heff_abandon();
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args) {
  V v_u_2447 = args[0];
  heff_drop(v_u_2447);
  return heff_abandon();
}
Clo g_heff_2eelab_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eelab_2eunify_2ezonker(V v_mc_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2eunify_2ezonker_24cpr(v_mc_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_el__ty, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2ezonker(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry, 4, 0};

V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(V v_x1_240, V v_f_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_244)}));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_lam0, 1, 4, (V[]){heff_dup(v_xs_245), v_f_241, v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_xs_245 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_drop(v_x_247);
  heff_clo_take(self, 4);
  return ({ V a_0 = v_xs_245; V a_1 = v_f_241; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(a_0, a_1, a_2, a_3)); heff_drop(v_xs_245); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam1, 1, 5, (V[]){v_m_241, v_hd_244, v_k_245, v_g_240, v_pr_242})});
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_sp_2411; V a_4 = v_x_2419; V r_ = (g_heff_2eelab_2eunify_2erenameSpine_24s151460570x1452919340(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_240); heff_drop(v_m_241); heff_drop(v_pr_242); heff_drop(v_x_2419); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2426, v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_fty_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2424 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = heff_tr(heff_call(v_fty_2423, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2428 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2427)));
  V v_t_2440;
  switch (heff_tag_of(v_t_2428)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2428, 0ULL, 1);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2431 = heff_field(v_t_2428, 1);
    heff_take_n(v_t_2428, 2ULL, 4);
    heff_drop(v_t_2427);
    v_t_2440 = v_dom_2431;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2428, 0ULL, 3);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2428, 0ULL, 1);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeInt: {
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeString: {
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeRune: {
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2428, 0ULL, 1);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2428, 0ULL, 1);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_NoRules: {
    v_t_2440 = v_t_2427;
    break;
  }
  default: heff_nomatch(v_t_2428);
  }
  return (g_heff_2eelab_2eunify_2erenameClo_24s843015770x1215808171(v_g_240, v_m_241, v_pr_242, v_t_2440, v_body_2424, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam5, 1, 2, (V[]){v_k_245, v_x_2426})));
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam9(V self, V *args) {
  V v_x_2456 = args[0];
  V v_k_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2455;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2456});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam8(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2453 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323(v_g_240, v_m_241, v_pr_242, v_v_2453, v_hd_2454, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam9, 1, 1, (V[]){v_k_2455})));
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_k_2450 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2450;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2447, v_x_2458});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam7(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_x_2448 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_k_2447 = heff_env(self)[4];
  V v_t_2457;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2448)) {
  case TAG_Nom: {
    V v_v_2451 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2457 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2451}));
    break;
  }
  case TAG_Describe: {
    V v_v_2452 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2457 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2452}));
    break;
  }
  case TAG_Become: {
    V v_v_2453 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2457 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam8, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2453});
    break;
  }
  default: heff_nomatch(v_x_2448);
  }
  V f_ = v_t_2457;
  args[0] = v_hd_2449;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam10, 1, 2, (V[]){v_k_2450, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam6(V self, V *args) {
  V v_p_2446 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  switch (heff_tag_of(v_p_2446)) {
  case TAG_MkPair: {
    V v_k_2447 = heff_field(v_p_2446, 0);
    V v_x_2448 = heff_field(v_p_2446, 1);
    heff_take_n(v_p_2446, 3ULL, 2);
    heff_clo_take(self, 3);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam7, 2, 5, (V[]){v_x_2448, v_g_240, v_m_241, v_pr_242, v_k_2447});
  }
  default: return heff_nomatch(v_p_2446);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_t_2461 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2460)));
  V v_t_2462 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2460));
  V v_t_2463 = (g_list_2emap_24s1173914895x100384474(v_x_2460));
  V v_t_2464 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2461), v_t_2462, heff_arrayFromList(v_t_2463)});
  V v_x_2465 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2464});
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HMeta: {
      V v_m_27_2415 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2415, v_m_241, 0)) {
        heff_clo_take(self, 5);
        heff_drop(v_m_241);
        heff_drop(v_g_240);
        heff_drop(v_pr_242);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2415);
        V v_t_2416 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2417 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
        V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2417}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2418;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        heff_clo_take(self, 5);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s689087499x16394338(v_g_240, v_m_241, v_pr_242, v_m_27_2415, v_sp_2411, v_hd_244, v_k_245));
      }
    }
    default: {
      heff_clo_take(self, 5);
      return (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2410, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})));
    }
    }
  }
  case TAG_VCode: {
    V v_t_2421 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, v_pr_242, v_t_2421, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam3, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2423 = heff_field(v_x_249, 0);
    V v_body_2424 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2425 = heff_tr(heff_call(heff_dup(v_fty_2423), 1, (V[]){NTAG(TAG_MkUnit)}));
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2425, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam4, 1, 7, (V[]){v_fty_2423, v_g_240, v_m_241, v_pr_242, v_body_2424, v_hd_244, v_k_245})));
  }
  case TAG_VCons: {
    V v_d_2442 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_keys_2443 = heff_take_field(v_d_2442, 0);
    V v_values_2444 = heff_get_n(v_d_2442, 2, 3);
    V v_t_2445 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2443), heff_arrayToList(v_values_2444)));
    heff_clo_take(self, 5);
    V v_t_2459 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam6, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2445));
    V f_ = v_t_2459;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s849750563x1086252323_lam11, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VOpaque: {
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_pr_242);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}