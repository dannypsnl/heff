// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_names 305943394
#define LBL_ren 322325
#define LBL_selfKey 62480824
#define LBL_solStx 1050338738
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
V g_heff_2eelab_2econversion_2ecanon(V);
V g_heff_2eelab_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_clo;
V g_heff_2eelab_2econversion_2ecanon_24tok1(V, V);
V g_heff_2eelab_2econversion_2ecanon_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_24tok1_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_clo;
HeffT3 g_heff_2eelab_2eunify_2emetasK_24cpr(V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_clo;
HeffT2 g_heff_2eelab_2eunify_2enth_24cpr(V, V);
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epatVarsOf_24dps(V, V);
V g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_24dps_clo;
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo;
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_clo;
V g_heff_2eelab_2eunify_2espineArgs(V, V);
V g_heff_2eelab_2eunify_2espineArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2espineArgs_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_clo;
V g_heff_2eelab_2eunify_2estripLams(V, V);
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estripLams_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
HeffT2 g_heff_2eelab_2eunify_2esubstOf_24cpr(V);
V g_heff_2eelab_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_clo;
V g_heff_2eelab_2eunify_2esubstTermF_24map1(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_24map1_clo;
V g_heff_2eelab_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTypeF_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo;
V g_heff_2eelab_2eunify_2etypeApplied(V, V, V, V);
V g_heff_2eelab_2eunify_2etypeApplied_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etypeApplied_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_clo;
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_clo;
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489_clo;
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_clo;
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24generate0(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate0_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24generate1(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate1_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24generate2(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24generate2_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24map0(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24map0_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24map1(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24map1_clo;
V g_heff_2eelab_2eunify_2ezonkTermF_24map2(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_24map2_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eisError(V);
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisError_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f8874541x1844987517(V, V);
V g_list_2emap_24f8874541x1844987517_entry(V self, V *a);
extern Clo g_list_2emap_24f8874541x1844987517_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_list_2emap_24s64066279x273522434(V);
V g_list_2emap_24s64066279x273522434_entry(V self, V *a);
extern Clo g_list_2emap_24s64066279x273522434_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2epatVarsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatVarsOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2epatVarsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PVar: {
      V v_l_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eunify_2epatVarsOf_24dps(v_rest_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epatVarsOf(a[0]);
}
Clo g_heff_2eelab_2eunify_2epatVarsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry, 2, 0};

V g_heff_2eelab_2eunify_2epatVarsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PVar: {
      V v_l_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_rest_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2epatVarsOf_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2esubstTermF_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_24map1_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTermF_24map1(V v_d_240, V v_idxs_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if ((((int64_t)0ULL) <= v_i_242)) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_i_244 = heff_arrayIndexIn_lent(v_a_243, heff_box_word(v_i_242), 2);
      V v_t_2411;
      if (heff_intLt_c_lent(v_i_244, v_d_240, 0)) {
        v_t_2411 = v_i_244;
      } else {
        V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
        V v_t_246 = heff_intSub(heff_intSub(v_t_245, MK_INT(1LL)), heff_intSub_lent(v_i_244, v_d_240, 0));
        HeffT2 v_t_247 = (g_heff_2eelab_2eunify_2enth_24cpr(v_idxs_241, v_t_246));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            heff_drop(v_i_244);
            V v_j_2410 = v_field_249;
            v_t_2411 = heff_intAdd_lent(v_j_2410, v_d_240, 1);
          } else {
            heff_drop(v_field_249);
            v_t_2411 = v_i_244;
          }
        }
      }
      V t_0 = v_d_240;
      V t_1 = v_idxs_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_2411);
      v_d_240 = t_0;
      v_idxs_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_i_244 = heff_arrayIndex_lent(v_a_243, heff_box_word(v_i_242), 2);
    V v_t_2411;
    if (heff_intLt_c_lent(v_i_244, v_d_240, 0)) {
      v_t_2411 = v_i_244;
    } else {
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
      V v_t_246 = heff_intSub(heff_intSub(v_t_245, MK_INT(1LL)), heff_intSub_lent(v_i_244, v_d_240, 0));
      HeffT2 v_t_247 = (g_heff_2eelab_2eunify_2enth_24cpr(v_idxs_241, v_t_246));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_i_244);
          V v_j_2410 = v_field_249;
          v_t_2411 = heff_intAdd_lent(v_j_2410, v_d_240, 1);
        } else {
          heff_drop(v_field_249);
          v_t_2411 = v_i_244;
        }
      }
    }
    V t_0 = v_d_240;
    V t_1 = v_idxs_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_2411);
    v_d_240 = t_0;
    v_idxs_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_24map1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTermF_24map1(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2esubstOf_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstOf_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2eunify_2esubstOf_24cpr(V v_idxs_240) {
top: ;
  return ((HeffT2){{heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_24cpr_lam0, 2, 1, (V[]){heff_dup(v_idxs_240)}), heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_24cpr_lam1, 2, 1, (V[]){heff_dup(v_idxs_240)})}});
}
V g_heff_2eelab_2eunify_2esubstOf_24cpr_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  V v_t_243 = (g_heff_2eelab_2eunify_2esubstOf(v_idxs_240));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_243; V a_1 = v_idxs_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eelab_2eunify_2esubstTermF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
V g_heff_2eelab_2eunify_2esubstOf_24cpr_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  V v_t_246 = (g_heff_2eelab_2eunify_2esubstOf(v_idxs_240));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_246; V a_1 = v_idxs_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2eunify_2esubstTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTermF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_lam0, 1, 0};
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTermF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_lam1, 1, 0};
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2ezonkTermF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_lam2, 1, 0};
Clo g_heff_2eelab_2eunify_2ezonkTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SCode: {
    V v_ty_245 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_245}));
    return heff_tag_at_n(v_ru_24t_242_24SCode, TAG_SCode, 1, (V[]){v_t_246});
  }
  case TAG_SApp: {
    V v_f_247 = heff_field(v_t_242, 0);
    V v_a_248 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SApp = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_f_247}));
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_248}));
    return heff_tag_at_n(v_ru_24t_242_24SApp, TAG_SApp, 2, (V[]){v_t_249, v_t_2410});
  }
  case TAG_SLam: {
    V v_d_2411 = heff_field(v_t_242, 0);
    V v_b_2412 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SLam = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){v_d_2411}));
    V v_f_2414 = heff_get_n(v_r_240, 0, 2);
    V v_t_2420;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2412, 0);
      V v_b_2416 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24MkAbs = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_b_2416}));
      v_t_2420 = heff_tag_re_n(v_ru_24b_2412_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_b_2412, 0);
      V v_ru_24b_2412_24AbsConst = heff_take_reuse_n(v_b_2412, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_b_2418}));
      v_t_2420 = heff_tag_at_n(v_ru_24b_2412_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24t_242_24SLam, TAG_SLam, 2, (V[]){v_t_2413, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCons = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2422 = heff_take_field(v_d_2421, 2);
    V v_m_2423 = heff_arrayLength_lent(v_xs_2422, 0);
    V v_t_2428;
    if ((heff_peek_word(v_m_2423) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_xs_2422);
      v_t_2428 = heff_arrayGenerate(v_m_2423, ((V)&g_heff_2eelab_2eunify_2ezonkTermF_lam0_clo));
    } else {
      V v_t_2425 = heff_arrayIndex_lent(v_xs_2422, MK_INT(0LL), 2);
      V v_y_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2425}));
      V v_t_2427 = heff_arrayKeepsAs_lent(v_xs_2422, v_y_2426, 0);
      if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
        heff_drop(v_m_2423);
        heff_drop(v_t_2427);
        v_t_2428 = ({ V a_0 = v_r_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2422, MK_INT(0LL), v_y_2426); V r_ = (g_heff_2eelab_2eunify_2ezonkTermF_24map0(a_0, a_1, a_2)); heff_drop_rec(v_r_240, 2); r_; });
      } else {
        heff_drop(v_t_2427);
        v_t_2428 = ({ V a_0 = v_r_240; V a_1 = v_xs_2422; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2423, v_y_2426); V r_ = (g_heff_2eelab_2eunify_2ezonkTermF_24generate0(a_0, a_1, a_2, a_3)); heff_drop_rec(v_r_240, 2); heff_drop(v_xs_2422); r_; });
      }
    }
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_d_2421, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SCons, TAG_SCons, 1, (V[]){v_t_2429});
  }
  case TAG_SProj: {
    V v_e_2430 = heff_field(v_t_242, 0);
    V v_l_2431 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SProj = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2432 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2430}));
    return heff_tag_re_n(v_ru_24t_242_24SProj, TAG_SProj, 2, 2ULL, (V[]){v_t_2432, v_l_2431});
  }
  case TAG_STag: {
    V v_x_2433 = heff_field(v_t_242, 0);
    V v_argv_2434 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24STag = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_m_2435 = heff_arrayLength_lent(v_argv_2434, 0);
    V v_t_2440;
    if ((heff_peek_word(v_m_2435) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_argv_2434);
      v_t_2440 = heff_arrayGenerate(v_m_2435, ((V)&g_heff_2eelab_2eunify_2ezonkTermF_lam1_clo));
    } else {
      V v_t_2437 = heff_arrayIndex_lent(v_argv_2434, MK_INT(0LL), 2);
      V v_y_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2437}));
      V v_t_2439 = heff_arrayKeepsAs_lent(v_argv_2434, v_y_2438, 0);
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop(v_m_2435);
        heff_drop(v_t_2439);
        v_t_2440 = ({ V a_0 = v_r_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_argv_2434, MK_INT(0LL), v_y_2438); V r_ = (g_heff_2eelab_2eunify_2ezonkTermF_24map1(a_0, a_1, a_2)); heff_drop_rec(v_r_240, 2); r_; });
      } else {
        heff_drop(v_t_2439);
        v_t_2440 = ({ V a_0 = v_r_240; V a_1 = v_argv_2434; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2435, v_y_2438); V r_ = (g_heff_2eelab_2eunify_2ezonkTermF_24generate1(a_0, a_1, a_2, a_3)); heff_drop_rec(v_r_240, 2); heff_drop(v_argv_2434); r_; });
      }
    }
    return heff_tag_re_n(v_ru_24t_242_24STag, TAG_STag, 2, 1ULL, (V[]){v_x_2433, v_t_2440});
  }
  case TAG_SMatch: {
    V v_e_2441 = heff_field(v_t_242, 0);
    V v_cs_2442 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SMatch = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2441}));
    V v_xs_2444 = heff_take_field(v_cs_2442, 2);
    V v_m_2445 = heff_arrayLength_lent(v_xs_2444, 0);
    V v_t_2453;
    if ((heff_peek_word(v_m_2445) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_xs_2444);
      v_t_2453 = heff_arrayGenerate(v_m_2445, ((V)&g_heff_2eelab_2eunify_2ezonkTermF_lam2_clo));
    } else {
      V v_p_2447 = heff_arrayIndex_lent(v_xs_2444, MK_INT(0LL), 2);
      V v_y_2451;
      switch (heff_tag_of(v_p_2447)) {
      case TAG_MkPair: {
        V v_xs_2448 = heff_field(v_p_2447, 0);
        V v_b_2449 = heff_field(v_p_2447, 1);
        V v_ru_24p_2447_24MkPair = heff_take_reuse_n(v_p_2447, 3ULL, 2);
        V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_b_2449}));
        v_y_2451 = heff_tag_re_n(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_2448, v_t_2450});
        break;
      }
      default: heff_nomatch(v_p_2447);
      }
      V v_t_2452 = heff_arrayKeepsAs_lent(v_xs_2444, v_y_2451, 0);
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_m_2445);
        heff_drop(v_t_2452);
        v_t_2453 = ({ V a_0 = v_r_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2444, MK_INT(0LL), v_y_2451); V r_ = (g_heff_2eelab_2eunify_2ezonkTermF_24map2(a_0, a_1, a_2)); heff_drop_rec(v_r_240, 2); r_; });
      } else {
        heff_drop(v_t_2452);
        v_t_2453 = ({ V a_0 = v_xs_2444; V a_1 = v_r_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2445, v_y_2451); V r_ = (g_heff_2eelab_2eunify_2ezonkTermF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2444); heff_drop_rec(v_r_240, 2); r_; });
      }
    }
    V v_t_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_cs_2442, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2443, v_t_2454});
  }
  case TAG_SSpecialize: {
    V v_e_2455 = heff_field(v_t_242, 0);
    V v_l_2456 = heff_field(v_t_242, 1);
    V v_v_2457 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SSpecialize = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2455}));
    V v_t_2459 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_2457}));
    return heff_tag_re_n(v_ru_24t_242_24SSpecialize, TAG_SSpecialize, 3, 2ULL, (V[]){v_t_2458, v_l_2456, v_t_2459});
  }
  case TAG_SIs: {
    V v_e_2460 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIs = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2460}));
    return heff_tag_at_n(v_ru_24t_242_24SIs, TAG_SIs, 1, (V[]){v_t_2461});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SRec: {
    V v_e_2462 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SRec = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2462}));
    return heff_tag_at_n(v_ru_24t_242_24SRec, TAG_SRec, 1, (V[]){v_t_2463});
  }
  case TAG_SFix: {
    V v_d_2464 = heff_field(v_t_242, 0);
    V v_b_2465 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2466 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){v_d_2464}));
    V v_f_2467 = heff_get_n(v_r_240, 0, 2);
    V v_t_2473;
    switch (heff_tag_of(v_b_2465)) {
    case TAG_MkAbs: {
      V v_x_2468 = heff_field(v_b_2465, 0);
      V v_b_2469 = heff_field(v_b_2465, 1);
      V v_ru_24b_2465_24MkAbs = heff_take_reuse_n(v_b_2465, 3ULL, 2);
      V v_t_2470 = heff_tr(heff_call(v_f_2467, 1, (V[]){v_b_2469}));
      v_t_2473 = heff_tag_re_n(v_ru_24b_2465_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2468, v_t_2470});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2471 = heff_field(v_b_2465, 0);
      V v_ru_24b_2465_24AbsConst = heff_take_reuse_n(v_b_2465, 1ULL, 1);
      V v_t_2472 = heff_tr(heff_call(v_f_2467, 1, (V[]){v_b_2471}));
      v_t_2473 = heff_tag_at_n(v_ru_24b_2465_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2472});
      break;
    }
    default: heff_nomatch(v_b_2465);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFix, TAG_SFix, 2, (V[]){v_t_2466, v_t_2473});
  }
  case TAG_SImplicit: {
    V v_x_2474 = heff_field(v_t_242, 0);
    V v_e_2475 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SImplicit = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2475}));
    return heff_tag_re_n(v_ru_24t_242_24SImplicit, TAG_SImplicit, 2, 1ULL, (V[]){v_x_2474, v_t_2476});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SMetaApp: {
    V v_m_2478 = heff_field(v_t_242, 0);
    V v_idxs_2479 = heff_field(v_t_242, 1);
    V v_ty_2480 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SMetaApp = heff_take_reuse_n(v_t_242, 7ULL, 3);
    HeffT2 v_t_2481 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(v_mc_241, v_m_2478));
    {
      V v_field_2483 = v_t_2481.f[1];
      int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
      if ((v_tag_2482 == ((int64_t)0ULL))) {
        V v_e_2484 = v_field_2483;
        V v_t_2485 = heff_get_n(v_e_2484, 2, 6);
        switch (heff_tag_of(v_t_2485)) {
        case TAG_Nothing: {
          V v_t_2486 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_2480}));
          return heff_tag_re_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, 3ULL, (V[]){v_m_2478, v_idxs_2479, v_t_2486});
        }
        case TAG_Just: {
          V v_sol_2487 = heff_field(v_t_2485, 0);
          heff_take_n(v_t_2485, 1ULL, 1);
          heff_drop(v_m_2478);
          heff_drop(v_ty_2480);
          heff_drop_cell(v_ru_24t_242_24SMetaApp, 3);
          V v_idxs_2488 = heff_arrayToList(v_idxs_2479);
          HeffT2 v_t_2489 = (g_heff_2eelab_2eunify_2esubstOf_24cpr(v_idxs_2488));
          {
            V v_field_2490 = v_t_2489.f[0];
            heff_drop(v_t_2489.f[1]);
            V v_t_2492 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_idxs_2488; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_idxs_2488); r_; });
            V v_t_2493 = ({ V a_0 = v_t_2492; V a_1 = v_sol_2487; V r_ = (g_heff_2eelab_2eunify_2estripLams(a_0, a_1)); heff_drop(v_sol_2487); r_; });
            V v_t_2494 = heff_tr(heff_call(v_field_2490, 2, (V[]){MK_INT(0LL), v_t_2493}));
            return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2494});
          }
        }
        default: return heff_nomatch(v_t_2485);
        }
      } else {
        heff_drop(v_field_2483);
        V v_t_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_2480}));
        return heff_tag_re_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, 3ULL, (V[]){v_m_2478, v_idxs_2479, v_t_2495});
      }
    }
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTermF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args) {
  V v_u_2424 = args[0];
  heff_drop(v_u_2424);
  return heff_abandon();
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args) {
  V v_u_2436 = args[0];
  heff_drop(v_u_2436);
  return heff_abandon();
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args) {
  V v_u_2446 = args[0];
  heff_drop(v_u_2446);
  return heff_abandon();
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_ru_24a_245_24PVar = heff_take_reuse_n(v_a_245, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          V v_a_248 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          if (heff_intEq_c(v_a_247, v_a_248)) {
            v_t_2410 = heff_tag_at_n(v_ru_24a_245_24PVar, TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          } else {
            heff_drop_cell(v_ru_24a_245_24PVar, 1);
            v_t_2410 = NTAG(TAG_Nothing);
          }
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_247);
          heff_drop_cell(v_ru_24a_245_24PVar, 1);
          v_t_2410 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          heff_take_n(v_a_246, 0ULL, 1);
          v_t_2410 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PSelf: {
          v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2411);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_u_2412;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_str0, 1, "x");
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_entry, 8, 0};

V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695(V v_g_240, V v_cs_241, V v_x4_242, V v_cb_243, V v_a_244, V v_b_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_VNeu: {
    V v_h_248 = heff_field(v_x4_242, 0);
    V v_sp_249 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 5);
    switch (heff_tag_of(v_cb_243)) {
    case TAG_VNeu: {
      V v_h_27_2413 = heff_field(v_cb_243, 0);
      V v_sp_27_2414 = heff_field(v_cb_243, 1);
      heff_take_n(v_cb_243, 3ULL, 5);
      heff_drop(v_a_244);
      heff_drop(v_b_245);
      V v_t_2418 = ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_h_248; V a_3 = v_sp_249; V a_4 = v_h_27_2413; V a_5 = v_sp_27_2414; V r_ = (g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_g_240); heff_drop_rec(v_cs_241, 2); heff_drop(v_h_248); heff_drop(v_sp_249); heff_drop(v_h_27_2413); heff_drop(v_sp_27_2414); r_; });
      return heff_tail(v_t_2418, 2, (V[]){v_z_246, v_z_247});
    }
    case TAG_VCode: {
      V v_ru_24cb_243_24VCode = heff_take_reuse_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_h_248);
      heff_drop(v_sp_249);
      V v_t_2420 = heff_tag_at_n(v_ru_24cb_243_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2421 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2421, v_z_247});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_243, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_h_248);
      heff_drop(v_sp_249);
      V v_t_2424 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2425 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2425, v_z_247});
    }
    case TAG_VCons: {
      V v_ru_24cb_243_24VCons = heff_take_reuse_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_h_248);
      heff_drop(v_sp_249);
      V v_t_2427 = heff_tag_at_n(v_ru_24cb_243_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2428 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2428, v_z_247});
    }
    case TAG_VOpaque: {
      heff_drop(v_g_240);
      heff_drop(v_h_248);
      heff_drop(v_sp_249);
      V v_t_2429 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2430 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2430, v_z_247});
    }
    default: return heff_nomatch(v_cb_243);
    }
  }
  case TAG_VCode: {
    V v_t_2431 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24VCode = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    switch (heff_tag_of(v_cb_243)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_243, 0ULL, 5);
      heff_drop(v_g_240);
      heff_drop(v_t_2431);
      V v_t_2437 = heff_tag_at_n(v_ru_24x4_242_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2438 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2438, v_z_247});
    }
    case TAG_VCode: {
      V v_t_27_2439 = heff_field(v_cb_243, 0);
      heff_take_n(v_cb_243, 1ULL, 1);
      heff_drop(v_a_244);
      heff_drop(v_b_245);
      heff_drop_cell(v_ru_24x4_242_24VCode, 1);
      return (g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(v_g_240, v_cs_241, v_t_2431, v_t_27_2439, v_z_246, v_z_247));
    }
    case TAG_VLam: {
      heff_take_n(v_cb_243, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_t_2431);
      V v_t_2442 = heff_tag_at_n(v_ru_24x4_242_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2443 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2443, v_z_247});
    }
    case TAG_VCons: {
      heff_take_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_t_2431);
      V v_t_2445 = heff_tag_at_n(v_ru_24x4_242_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2446 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2446, v_z_247});
    }
    case TAG_VOpaque: {
      heff_drop(v_g_240);
      heff_drop(v_t_2431);
      V v_t_2447 = heff_tag_at_n(v_ru_24x4_242_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2448 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2448, v_z_247});
    }
    default: return heff_nomatch(v_cb_243);
    }
  }
  case TAG_VLam: {
    V v_d_2449 = heff_field(v_x4_242, 0);
    V v_c_2450 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24VLam = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_cb_243)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_243, 0ULL, 5);
      heff_drop(v_g_240);
      heff_drop(v_d_2449);
      heff_drop(v_c_2450);
      heff_drop_cell(v_ru_24x4_242_24VLam, 2);
      V v_t_2456 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2457 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2457, v_z_247});
    }
    case TAG_VCode: {
      V v_ru_24cb_243_24VCode = heff_take_reuse_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_d_2449);
      heff_drop(v_c_2450);
      heff_drop_cell(v_ru_24x4_242_24VLam, 2);
      V v_t_2459 = heff_tag_at_n(v_ru_24cb_243_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_2460 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_2460, v_z_247});
    }
    case TAG_VLam: {
      V v_c_27_2462 = heff_field(v_cb_243, 1);
      heff_take_n(v_cb_243, 2ULL, 2);
      heff_drop(v_a_244);
      heff_drop(v_b_245);
      V v_t_2463 = heff_tr(heff_call(v_d_2449, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2464 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2463)));
      V v_a_2476;
      switch (heff_tag_of(v_t_2464)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_2467 = heff_field(v_t_2464, 1);
        heff_take_n(v_t_2464, 2ULL, 4);
        heff_drop(v_t_2463);
        v_a_2476 = v_dom_2467;
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_2464, 0ULL, 3);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeInt: {
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeFloat: {
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeString: {
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeRune: {
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_a_2476 = v_t_2463;
        break;
      }
      case TAG_NoRules: {
        v_a_2476 = v_t_2463;
        break;
      }
      default: heff_nomatch(v_t_2464);
      }
      V v_t_2477 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
      V v_v_2479 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2477, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam0, 1, 1, (V[]){v_a_2476}), NTAG(TAG_Nothing)));
      V v_t_2484;
      switch (heff_tag_of(v_c_2450)) {
      case TAG_MkClo: {
        V v_n_2480 = heff_dup(heff_field(v_c_2450, 0));
        v_t_2484 = v_n_2480;
        break;
      }
      case TAG_CloConst: {
        v_t_2484 = ((V)&g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_str0);
        break;
      }
      default: heff_nomatch(v_c_2450);
      }
      V v_t_2485 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
      V v_t_2486 = heff_tag_at_n(v_ru_24x4_242_24VLam, TAG_Cons, 2, (V[]){v_t_2484, heff_dup(heff_rfield(v_cs_241, 1))});
      V v_cs_2487 = ({ V rv_0 = v_t_2485; V rv_1 = v_t_2486; V rr_ = heff_rec_reuse_nf(v_cs_241, 0ULL, 2, shape_len__names, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x1_2493;
      switch (heff_tag_of(v_c_2450)) {
      case TAG_MkClo: {
        V v_vs_2489 = heff_field(v_c_2450, 1);
        V v_body_2490 = heff_field(v_c_2450, 2);
        heff_take_n(v_c_2450, 6ULL, 3);
        v_x1_2493 = heff_tr(heff_call(v_body_2490, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2489, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam1, 1, 1, (V[]){heff_dup(v_v_2479)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2492 = heff_field(v_c_2450, 0);
        heff_take_n(v_c_2450, 1ULL, 1);
        v_x1_2493 = v_body_2492;
        break;
      }
      default: heff_nomatch(v_c_2450);
      }
      V v_a_2497;
      switch (heff_tag_of(v_x1_2493)) {
      case TAG_Nom: {
        V v_x_2494 = heff_field(v_x1_2493, 0);
        heff_take_n(v_x1_2493, 1ULL, 1);
        v_a_2497 = v_x_2494;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2493, 0ULL, 1);
        v_a_2497 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2496 = heff_field(v_x1_2493, 0);
        heff_take_n(v_x1_2493, 1ULL, 1);
        v_a_2497 = v_x_2496;
        break;
      }
      default: heff_nomatch(v_x1_2493);
      }
      V v_x1_24103;
      switch (heff_tag_of(v_c_27_2462)) {
      case TAG_MkClo: {
        V v_vs_2499 = heff_field(v_c_27_2462, 1);
        V v_body_24100 = heff_field(v_c_27_2462, 2);
        heff_take_n(v_c_27_2462, 6ULL, 3);
        v_x1_24103 = heff_tr(heff_call(v_body_24100, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2499, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam2, 1, 1, (V[]){v_v_2479})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24102 = heff_field(v_c_27_2462, 0);
        heff_take_n(v_c_27_2462, 1ULL, 1);
        heff_drop(v_v_2479);
        v_x1_24103 = v_body_24102;
        break;
      }
      default: heff_nomatch(v_c_27_2462);
      }
      V v_b_24107;
      switch (heff_tag_of(v_x1_24103)) {
      case TAG_Nom: {
        V v_x_24104 = heff_field(v_x1_24103, 0);
        heff_take_n(v_x1_24103, 1ULL, 1);
        v_b_24107 = v_x_24104;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24103, 0ULL, 1);
        v_b_24107 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24106 = heff_field(v_x1_24103, 0);
        heff_take_n(v_x1_24103, 1ULL, 1);
        v_b_24107 = v_x_24106;
        break;
      }
      default: heff_nomatch(v_x1_24103);
      }
      return (g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(v_g_240, v_cs_2487, v_a_2497, v_b_24107, v_z_246, v_z_247));
    }
    case TAG_VCons: {
      V v_ru_24cb_243_24VCons = heff_take_reuse_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_d_2449);
      heff_drop(v_c_2450);
      heff_drop_cell(v_ru_24x4_242_24VLam, 2);
      V v_t_24109 = heff_tag_at_n(v_ru_24cb_243_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24110 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24110, v_z_247});
    }
    case TAG_VOpaque: {
      heff_drop(v_g_240);
      heff_drop(v_d_2449);
      heff_drop(v_c_2450);
      heff_drop_cell(v_ru_24x4_242_24VLam, 2);
      V v_t_24111 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24112 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24111})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24112, v_z_247});
    }
    default: return heff_nomatch(v_cb_243);
    }
  }
  case TAG_VCons: {
    V v_d_24113 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24VCons = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    switch (heff_tag_of(v_cb_243)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_243, 0ULL, 5);
      heff_drop(v_g_240);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24119 = heff_tag_at_n(v_ru_24x4_242_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24120 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24119})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24120, v_z_247});
    }
    case TAG_VCode: {
      heff_take_n(v_cb_243, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24122 = heff_tag_at_n(v_ru_24x4_242_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24123 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24123, v_z_247});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_243, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24126 = heff_tag_at_n(v_ru_24x4_242_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24127 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24126})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24127, v_z_247});
    }
    case TAG_VCons: {
      V v_d_27_24128 = heff_field(v_cb_243, 0);
      heff_take_n(v_cb_243, 1ULL, 1);
      heff_drop(v_a_244);
      heff_drop(v_b_245);
      heff_drop_cell(v_ru_24x4_242_24VCons, 1);
      V v_t_24129 = heff_arrayToList(heff_get_n(v_d_24113, 2, 3));
      V v_t_24130 = heff_arrayToList(heff_get_n(v_d_27_24128, 2, 3));
      V v_t_24131 = (g_heff_2eelab_2eunify_2ezipL(v_t_24129, v_t_24130));
      return ({ V a_0 = v_t_24131; V a_1 = heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam3, 1, 2, (V[]){v_g_240, v_cs_241}); V a_2 = v_z_246; V a_3 = v_z_247; V r_ = (g_heff_2eelab_2eunify_2eforU_24s372992972x1203695142(a_0, a_1, a_2, a_3)); heff_drop(v_t_24131); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_g_240);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24143 = heff_tag_at_n(v_ru_24x4_242_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_241, v_a_244, v_b_245})});
      V v_t_24144 = heff_tr(heff_call(heff_take_field(v_z_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})}));
      return heff_tail(heff_get_n(v_z_246, 1, 3), 2, (V[]){v_t_24144, v_z_247});
    }
    default: return heff_nomatch(v_cb_243);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_g_240);
    heff_drop_rec(v_cs_241, 2);
    heff_drop(v_cb_243);
    heff_drop(v_a_244);
    heff_drop(v_b_245);
    heff_drop_rec(v_z_246, 3);
    return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam0(V self, V *args) {
  V v_u_2478 = args[0];
  V v_a_2476 = heff_env(self)[0];
  heff_drop(v_u_2478);
  heff_clo_take(self, 1);
  return v_a_2476;
}
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam1(V self, V *args) {
  V v_w_2491 = args[0];
  V v_v_2479 = heff_env(self)[0];
  heff_drop(v_w_2491);
  heff_clo_take(self, 1);
  return v_v_2479;
}
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam2(V self, V *args) {
  V v_w_24101 = args[0];
  V v_v_2479 = heff_env(self)[0];
  heff_drop(v_w_24101);
  heff_clo_take(self, 1);
  return v_v_2479;
}
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_lam3(V self, V *args) {
  V v_p_24132 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  switch (heff_tag_of(v_p_24132)) {
  case TAG_MkPair: {
    V v_x_24133 = heff_field(v_p_24132, 0);
    V v_y_24134 = heff_field(v_p_24132, 1);
    heff_take_n(v_p_24132, 3ULL, 2);
    V v_a_24138;
    switch (heff_tag_of(v_x_24133)) {
    case TAG_Nom: {
      V v_x_24135 = heff_field(v_x_24133, 0);
      heff_take_n(v_x_24133, 1ULL, 1);
      v_a_24138 = v_x_24135;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x_24133, 0ULL, 1);
      v_a_24138 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24137 = heff_field(v_x_24133, 0);
      heff_take_n(v_x_24133, 1ULL, 1);
      v_a_24138 = v_x_24137;
      break;
    }
    default: heff_nomatch(v_x_24133);
    }
    V v_b_24142;
    switch (heff_tag_of(v_y_24134)) {
    case TAG_Nom: {
      V v_x_24139 = heff_field(v_y_24134, 0);
      heff_take_n(v_y_24134, 1ULL, 1);
      v_b_24142 = v_x_24139;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_y_24134, 0ULL, 1);
      v_b_24142 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24141 = heff_field(v_y_24134, 0);
      heff_take_n(v_y_24134, 1ULL, 1);
      v_b_24142 = v_x_24141;
      break;
    }
    default: heff_nomatch(v_y_24134);
    }
    heff_clo_take(self, 2);
    V f_ = ((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo);
    heff_room[0] = v_g_240;
    heff_room[1] = v_cs_241;
    heff_room[2] = v_a_24138;
    heff_room[3] = v_b_24142;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_p_24132);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam0, 2, 1, (V[]){heff_dup(v_h_244)});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_s_247, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam1, 2, 5, (V[]){v_c_249, heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_s_2420, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam6, 2, 6, (V[]){v_c_2423, heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_drop(v_hd_245);
  heff_clo_take(self, 1);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam1, 1, 7, (V[]){v_hd_245, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_k_246})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 9);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 7, 9);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam4(V self, V *args) {
  V v_a_2422 = args[0];
  V v_pr_242 = heff_env(self)[0];
  switch (heff_tag_of(v_a_2422)) {
  case TAG_PVar: {
    V v_l_2423 = heff_field(v_a_2422, 0);
    heff_take_n(v_a_2422, 1ULL, 1);
    heff_clo_take(self, 1);
    HeffT2 v_t_2424 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2423; HeffT2 r_ = (g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_l_2423); r_; });
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2425 == ((int64_t)0ULL)) ? ({ V v_x_2427 = heff_dup(v_field_2426); int c_ = 0; heff_drop(v_x_2427); c_; }) : 1));
      heff_drop(v_field_2426);
      return v_ret_24bool;
    }
  }
  case TAG_PSelf: {
    heff_drop(self);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_a_2422);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam6(V self, V *args) {
  V v_i_2431 = args[0];
  V v_a_2432 = args[1];
  V v_pr_242 = heff_env(self)[0];
  switch (heff_tag_of(v_a_2432)) {
  case TAG_PVar: {
    V v_l_2433 = heff_field(v_a_2432, 0);
    V v_ru_24a_2432_24PVar = heff_take_reuse_n(v_a_2432, 1ULL, 1);
    heff_clo_take(self, 1);
    HeffT2 v_t_2434 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2433; HeffT2 r_ = (g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_l_2433); r_; });
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_x_2437 = v_field_2436;
        heff_drop(v_x_2437);
        return heff_tag_at_n(v_ru_24a_2432_24PVar, TAG_Just, 1, (V[]){v_i_2431});
      } else {
        heff_drop(v_i_2431);
        heff_drop_cell(v_ru_24a_2432_24PVar, 1);
        heff_drop(v_field_2436);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2431);
    heff_drop(self);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2432);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2441 = ({ V a_0 = v_x_2440; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_x_2440); heff_drop(v_sp_244); r_; });
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_v_2441, v_hd_245, v_k_246));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_args_2421 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2421));
  heff_clo_take(self, 8);
  V v_t_2438 = (g_heff_2eelab_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2421));
  V v_t_2439 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2438));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2429, v_t_2430, v_t_2439, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8(V self, V *args) {
  V v_c_2443 = args[0];
  return heff_get_n(v_c_2443, 3, 9);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2447 = ({ V a_0 = v_x_2446; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_x_2446); heff_drop(v_m_27_243); r_; });
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    if ((v_tag_2448 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2450 = v_field_2449;
      V f_ = v_k_2442;
      args[0] = v_e_2450;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2449);
      V v_t_2451 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2452}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2453;
      heff_room[1] = v_k_2442;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam13(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2467 = heff_env(self)[1];
  heff_drop(v_hd_2468);
  heff_clo_take(self, 2);
  V v_t_2470 = heff_intSub(heff_get_n(v_pr_242, 1, 3), v_l_27_2467);
  V f_ = v_k_2469;
  args[0] = heff_intSub(v_t_2470, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k2_2472 = args[1];
  V v_malg_2473 = heff_take_field(v_hd_2471, 2);
  V v_bind_2474 = heff_get_n(v_hd_2471, 1, 3);
  V v_t_2475 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tr(heff_call(v_malg_2473, 1, (V[]){v_t_2476}));
  V f_ = v_bind_2474;
  args[0] = v_t_2477;
  args[1] = v_k2_2472;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_malg_2480 = heff_take_field(v_hd_2478, 2);
  V v_bind_2481 = heff_get_n(v_hd_2478, 1, 3);
  V v_t_2482 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(v_malg_2480, 1, (V[]){v_t_2483}));
  V f_ = v_bind_2481;
  args[0] = v_t_2484;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam12(V self, V *args) {
  V v_a_2462 = args[0];
  V v_pr_242 = heff_env(self)[0];
  switch (heff_tag_of(v_a_2462)) {
  case TAG_PVar: {
    V v_l_2463 = heff_field(v_a_2462, 0);
    heff_take_n(v_a_2462, 1ULL, 1);
    HeffT2 v_t_2464 = ({ V a_0 = heff_rfield(v_pr_242, 2); V a_1 = v_l_2463; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_l_2463); r_; });
    {
      V v_field_2466 = v_t_2464.f[1];
      int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
      if ((v_tag_2465 == ((int64_t)0ULL))) {
        V v_l_27_2467 = v_field_2466;
        heff_clo_take(self, 1);
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam13, 2, 2, (V[]){v_pr_242, v_l_27_2467});
      } else {
        heff_drop(self);
        heff_drop(v_field_2466);
        return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14_clo);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop(self);
    return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15_clo);
  }
  default: return heff_nomatch(v_a_2462);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam16(V self, V *args) {
  V v_x_2486 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2461 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2487 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2486), v_x_2461});
  V f_ = v_k_246;
  args[0] = v_t_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam11(V self, V *args) {
  V v_x_2461 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2421 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2485 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam12, 1, 1, (V[]){v_pr_242}), v_args_2421));
  V f_ = v_t_2485;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam16, 1, 3, (V[]){v_m_27_243, v_x_2461, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_m_27_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_pr_242 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_args_2421 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  V v_arity_2455 = heff_take_field(v_x_2454, 3);
  V v_ty_2456 = heff_get_n(v_x_2454, 0, 6);
  heff_clo_take(self, 9);
  V v_t_2457 = (g_heff_2eelab_2eunify_2espineArgs(v_sp_244, NTAG(TAG_Nil)));
  V v_t_2458 = ({ V a_0 = v_arity_2455; V a_1 = v_t_2457; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2457); r_; });
  V v_t_2459 = (g_list_2emap_24s64066279x273522434(v_t_2458));
  V v_t_2460 = ({ V a_0 = v_x_2410; V a_1 = v_m_27_243; V a_2 = v_t_2459; V a_3 = v_ty_2456; V r_ = (g_heff_2eelab_2eunify_2etypeApplied(a_0, a_1, a_2, a_3)); heff_drop(v_x_2410); heff_drop(v_t_2459); r_; });
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(v_g_240, v_m_241, heff_dup(v_pr_242), v_t_2460, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam11, 1, 5, (V[]){v_pr_242, v_args_2421, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17(V self, V *args) {
  V v_c_2489 = args[0];
  return heff_get_n(v_c_2489, 3, 9);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam18(V self, V *args) {
  V v_x_2492 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2488 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2493 = ({ V a_0 = v_x_2492; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_x_2492); heff_drop(v_m_27_243); r_; });
  {
    V v_field_2495 = v_t_2493.f[1];
    int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
    if ((v_tag_2494 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2496 = v_field_2495;
      V f_ = v_k_2488;
      args[0] = v_e_2496;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2495);
      V v_t_2497 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2497})});
      V v_t_2499 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2498}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2499;
      heff_room[1] = v_k_2488;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  HeffT2 v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = heff_dup(v_sp_244); HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_items_2418 = v_field_2417;
      V v_t_2419 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2418)));
      V v_t_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2419); r_; });
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        V v_args_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2418));
        V v_t_2428 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}); V a_1 = v_args_2421; V r_ = (g_heff_2eelab_2eunify_2eanyL(b_0, a_1)); heff_drop(b_0); r_; });
        if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
          heff_clo_take(self, 8);
          heff_drop(v_x_2410);
          heff_drop(v_t_2428);
          V v_k_2442 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam5, 1, 8, (V[]){v_args_2421, v_pr_242, v_g_240, v_m_241, heff_dup(v_m_27_243), heff_dup(v_hd_245), v_sp_244, v_k_246});
          V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8_clo)})});
          V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2444}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2445;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam9, 1, 3, (V[]){v_m_27_243, v_k_2442, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_t_2428);
          heff_clo_take(self, 8);
          V v_k_2488 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam10, 1, 9, (V[]){v_sp_244, v_x_2410, heff_dup(v_m_27_243), v_g_240, v_m_241, v_pr_242, heff_dup(v_hd_245), v_args_2421, v_k_246});
          V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17_clo)})});
          V v_t_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2490}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2491;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam18, 1, 3, (V[]){v_m_27_243, v_k_2488, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_clo_take(self, 8);
        heff_drop(v_x_2410);
        heff_drop(v_sp_244);
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_m_27_243);
        heff_drop(v_items_2418);
        heff_drop(v_t_2420);
        V v_t_24100 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24100})});
        V v_t_24102 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24101}));
        V f_ = heff_get_n(v_hd_245, 1, 3);
        heff_room[0] = v_t_24102;
        heff_room[1] = v_k_246;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_clo_take(self, 8);
      heff_drop(v_x_2410);
      heff_drop(v_sp_244);
      heff_drop_rec(v_pr_242, 3);
      heff_drop(v_g_240);
      heff_drop(v_m_241);
      heff_drop(v_m_27_243);
      heff_drop(v_field_2417);
      V v_t_24103 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24103})});
      V v_t_24105 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24104}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_24105;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2412}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam1, 1, 8, (V[]){v_entry_243, v_n_244, v_storeM_242, v_g_240, v_occursM_241, v_hd_246, v_kept_245, v_k_247})});
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 9);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2434 = heff_env(self)[1];
  heff_drop(v_x_2436);
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = v_v_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2434 = heff_env(self)[4];
  heff_drop(v_x_2435);
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_storeM_242, v_t_2429, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam5, 1, 2, (V[]){v_k_247, v_v_2434})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = (g_list_2emap_24s1947501783x1475115781(heff_dup(v_n_244), MK_INT(1LL), v_kept_245));
  V v_t_2428 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_x_2426, heff_arrayFromList(v_t_2427), v_x_2417});
  V v_t_2429 = (g_heff_2eelab_2eunify_2elamsU(v_n_244, v_t_2428));
  V v_x1_2430 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = heff_dup(v_t_2429); V a_3 = NTAG(TAG_LNil); V r_ = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); r_; });
  V v_v_2434;
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_Nom: {
    V v_x_2431 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    v_v_2434 = v_x_2431;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2430, 0ULL, 1);
    v_v_2434 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2433 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    v_v_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x1_2430);
  }
  return ({ V a_0 = v_storeM_242; V a_1 = heff_dup(v_v_2434); V a_2 = heff_dup(v_t_2429); V a_3 = heff_dup(v_hd_246); V a_4 = heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam4, 1, 5, (V[]){heff_dup(v_storeM_242), v_t_2429, v_hd_246, v_k_247, v_v_2434}); V r_ = (g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_storeM_242); r_; });
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  HeffT2 v_t_2419 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_x_2417), NTAG(TAG_LNil)));
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    V v_t_2425;
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2422 = v_field_2421;
      v_t_2425 = v_x_2422;
    } else {
      if ((v_tag_2420 == ((int64_t)1ULL))) {
        V v_x11_2423 = v_field_2421;
        heff_drop(v_x11_2423);
        v_t_2425 = heff_abandon();
      } else {
        V v_x_2424 = v_field_2421;
        v_t_2425 = v_x_2424;
      }
    }
    heff_clo_take(self, 7);
    return (g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(v_entry_243, v_t_2418, v_t_2425, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam3, 1, 7, (V[]){v_n_244, v_kept_245, v_x_2417, v_g_240, v_storeM_242, v_hd_246, v_k_247})));
  }
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_entry_243 = heff_env(self)[0];
  V v_n_244 = heff_env(self)[1];
  V v_storeM_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_occursM_241 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_kept_245 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_y_2412 = heff_dup(heff_rfield(v_entry_243, 3));
  V v_t_2413;
  if (heff_intLe_c_lent(v_n_244, v_y_2412, 0)) {
    v_t_2413 = v_y_2412;
  } else {
    heff_drop(v_y_2412);
    v_t_2413 = heff_dup(v_n_244);
  }
  V v_pr_2414 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_2413, MK_INT(0LL), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_t_2415 = (g_list_2emap_24f8874541x1844987517(heff_dup(heff_rfield(v_entry_243, 3)), heff_intSub_lent(v_n_244, MK_INT(1LL), 2)));
  V v_t_2416 = ({ V a_0 = v_x_2411; V a_1 = v_storeM_242; V a_2 = v_t_2415; V a_3 = heff_dup(heff_rfield(v_entry_243, 0)); V r_ = (g_heff_2eelab_2eunify_2etypeApplied(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); heff_drop(v_t_2415); r_; });
  heff_clo_take(self, 8);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(heff_dup(v_g_240), v_occursM_241, v_pr_2414, v_t_2416, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam2, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_247 = heff_field(v_x6_244, 0);
    V v_l_248 = heff_field(v_x6_244, 1);
    V v_f_249 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_2410 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_pr_242, 2), heff_rfield(v_pr_242, 0), heff_rfield(v_pr_242, 1)));
    V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_2412 = heff_intAdd(heff_take_field(v_pr_242, 1), MK_INT(1LL));
    V v_pr_2413 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_2411, v_t_2412, v_t_2410});
    V v_t_2414 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2416 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2414, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2418 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam1, 1, 1, (V[]){v_v_2416})})}));
    V v_t_2425;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nom: {
      V v_a_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_a_2419}));
      break;
    }
    case TAG_Describe: {
      V v_a_2420 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_a_2420}));
      break;
    }
    case TAG_Become: {
      V v_a_2421 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2413, v_a_2421});
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    return heff_tail(v_t_2425, 2, (V[]){v_z_245, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam4, 1, 2, (V[]){v_z_246, v_x_247})});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_t_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_a_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2428}));
      break;
    }
    case TAG_Describe: {
      V v_a_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2429}));
      break;
    }
    case TAG_Become: {
      V v_a_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_t_2434 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam5, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_tail(v_t_2434, 2, (V[]){v_z_245, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam7, 1, 1, (V[]){v_z_246})});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam0(V self, V *args) {
  V v_u_2415 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_drop(v_u_2415);
  heff_clo_take(self, 1);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  V v_v_2416 = heff_env(self)[0];
  heff_drop(v_u_2417);
  heff_clo_take(self, 1);
  return v_v_2416;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2413 = heff_env(self)[2];
  V v_a_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, v_pr_2413, v_a_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam3, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_247, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, v_pr_242, v_a_2430, v_hd_2431, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam6, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 9); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  return heff_get_n(v_c_2416, 3, 9);
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam7(V self, V *args) {
  V v_c_2426 = args[0];
  return heff_get_n(v_c_2426, 3, 9);
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  HeffT3 v_t_2430 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2429));
  {
    V v_field_2431 = v_t_2430.f[0];
    heff_drop(v_t_2430.f[1]);
    heff_drop(v_t_2430.f[2]);
    heff_clo_take(self, 4);
    V v_t_2434 = heff_tr(heff_call(v_field_2431, 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2413}));
    return ({ V a_0 = v_t_2434; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
  }
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_drop(v_x_2425);
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam7_clo)})});
  V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2427}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2428;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam8, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  HeffT3 v_t_2420 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2419));
  {
    V v_field_2421 = v_t_2420.f[0];
    heff_drop(v_t_2420.f[1]);
    heff_drop(v_t_2420.f[2]);
    heff_clo_take(self, 5);
    V v_t_2424 = heff_tr(heff_call(v_field_2421, 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_249}));
    return ({ V a_0 = v_t_2424; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2413, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
  }
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_t_2414 = (g_heff_2eelab_2evalue_2eisError(v_x_249));
  V v_t_2415;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    v_t_2415 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2414);
    v_t_2415 = (g_heff_2eelab_2evalue_2eisError(v_x_2413));
  }
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_clo_take(self, 5);
    heff_drop(v_g_240);
    heff_drop(v_t_2415);
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam4_clo)})});
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2417}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2418;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam5, 1, 5, (V[]){v_cs_241, v_x_249, v_hd_244, v_x_2413, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2415);
    heff_clo_take(self, 5);
    switch (heff_tag_of(v_x_249)) {
    case TAG_VOpaque: {
      heff_drop(v_x_2413);
      heff_drop_rec(v_hd_244, 3);
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_g_240);
      V f_ = v_k_245;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: {
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VOpaque: {
        heff_drop(v_x_249);
        heff_drop_rec(v_hd_244, 3);
        heff_drop_rec(v_cs_241, 2);
        heff_drop(v_g_240);
        V f_ = v_k_245;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: {
        V v_t_2447;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VNeu: {
          V v_v1_2435 = heff_dup(heff_field(v_x_249, 0));
          V v_sp_2436 = heff_dup(heff_field(v_x_249, 1));
          switch (heff_tag_of(v_v1_2435)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2435, 0ULL, 1);
            heff_drop(v_sp_2436);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2435, 0ULL, 1);
            heff_drop(v_sp_2436);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_2442 = heff_field(v_v1_2435, 0);
            V v_ru_24v1_2435_24HMeta = heff_take_reuse_n(v_v1_2435, 1ULL, 1);
            v_t_2447 = heff_tag_at_n(v_ru_24v1_2435_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2442, v_sp_2436})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2436);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2435);
          }
          break;
        }
        case TAG_VCode: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        switch (heff_tag_of(v_t_2447)) {
        case TAG_Nothing: {
          V v_t_2460;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VNeu: {
            V v_v1_2448 = heff_dup(heff_field(v_x_2413, 0));
            V v_sp_2449 = heff_dup(heff_field(v_x_2413, 1));
            switch (heff_tag_of(v_v1_2448)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_2448, 0ULL, 1);
              heff_drop(v_sp_2449);
              v_t_2460 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_2448, 0ULL, 1);
              heff_drop(v_sp_2449);
              v_t_2460 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_2455 = heff_field(v_v1_2448, 0);
              V v_ru_24v1_2448_24HMeta = heff_take_reuse_n(v_v1_2448, 1ULL, 1);
              v_t_2460 = heff_tag_at_n(v_ru_24v1_2448_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2455, v_sp_2449})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_2449);
              v_t_2460 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_2448);
            }
            break;
          }
          case TAG_VCode: {
            v_t_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_2460 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          switch (heff_tag_of(v_t_2460)) {
          case TAG_Nothing: {
            V v_t_2473;
            switch (heff_tag_of(v_x_249)) {
            case TAG_VNeu: {
              V v_v1_2461 = heff_dup(heff_field(v_x_249, 0));
              switch (heff_tag_of(v_v1_2461)) {
              case TAG_HLocal: {
                V v_ru_24v1_2461_24HLocal = heff_take_reuse_n(v_v1_2461, 0ULL, 1);
                v_t_2473 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2461_24HLocal, heff_dup(v_x_249)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_2461_24HGlobal = heff_take_reuse_n(v_v1_2461, 0ULL, 1);
                v_t_2473 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2461_24HGlobal, heff_dup(v_x_249)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2461, 0ULL, 1);
                v_t_2473 = heff_dup(v_x_249);
                break;
              }
              case TAG_HError: {
                v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
                break;
              }
              default: heff_nomatch(v_v1_2461);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
              break;
            }
            case TAG_VLam: {
              v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
              break;
            }
            case TAG_VCons: {
              v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
              break;
            }
            default: heff_nomatch(v_x_249);
            }
            V v_t_2486;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_2474 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_2474)) {
              case TAG_HLocal: {
                V v_ru_24v1_2474_24HLocal = heff_take_reuse_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2474_24HLocal, heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_2474_24HGlobal = heff_take_reuse_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2474_24HGlobal, heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_2474);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            return (g_heff_2eelab_2eunify_2euElRigid_24s924422181x496822489(v_g_240, v_cs_241, v_t_2473, v_t_2486, v_x_249, v_x_2413, v_hd_244, v_k_245));
          }
          case TAG_Just: {
            V v_it1_2487 = heff_field(v_t_2460, 0);
            heff_take_n(v_t_2460, 1ULL, 1);
            switch (heff_tag_of(v_it1_2487)) {
            case TAG_MkPair: {
              V v_m_2488 = heff_field(v_it1_2487, 0);
              V v_sp_2489 = heff_field(v_it1_2487, 1);
              heff_take_n(v_it1_2487, 3ULL, 2);
              return (g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(v_g_240, v_cs_241, v_m_2488, v_sp_2489, v_x_249, v_x_2413, v_hd_244, v_k_245));
            }
            default: return heff_nomatch(v_it1_2487);
            }
          }
          default: return heff_nomatch(v_t_2460);
          }
        }
        case TAG_Just: {
          V v_it1_2490 = heff_field(v_t_2447, 0);
          heff_take_n(v_t_2447, 1ULL, 1);
          switch (heff_tag_of(v_it1_2490)) {
          case TAG_MkPair: {
            V v_m_2491 = heff_field(v_it1_2490, 0);
            V v_sp_2492 = heff_field(v_it1_2490, 1);
            heff_take_n(v_it1_2490, 3ULL, 2);
            return (g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(v_g_240, v_cs_241, v_m_2491, v_sp_2492, v_x_2413, v_x_249, v_hd_244, v_k_245));
          }
          default: return heff_nomatch(v_it1_2490);
          }
        }
        default: return heff_nomatch(v_t_2447);
        }
      }
      }
    }
    }
  }
}
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_lam3, 1, 5, (V[]){v_x_249, v_hd_244, v_cs_241, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(V v_g_240, V v_cs_241, V v_a_242, V v_b_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_246 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_247 = heff_dup(heff_field(v_b_243, 0));
      switch (heff_tag_of(v_u_246)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        case TAG_LargeU: {
          V v_t_248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_249, v_z_245});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          V v_t_2410 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_2411 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2411, v_z_245});
        }
        case TAG_LargeU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      default: return heff_nomatch(v_u_246);
      }
    }
    default: {
      heff_drop(v_u_246);
      V v_t_2412 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2413 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2413, v_z_245});
    }
    }
  }
  case TAG_VDecode: {
    V v_h_2414 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2415 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VDecode: {
      V v_h_27_2419 = heff_field(v_b_243, 0);
      V v_sp_27_2420 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      V v_t_2424 = ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_h_2414; V a_3 = v_sp_2415; V a_4 = v_h_27_2419; V a_5 = v_sp_27_2420; V r_ = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_g_240); heff_drop_rec(v_cs_241, 2); heff_drop(v_h_2414); heff_drop(v_sp_2415); heff_drop(v_h_27_2419); heff_drop(v_sp_27_2420); r_; });
      return heff_tail(v_t_2424, 2, (V[]){v_z_244, v_z_245});
    }
    default: {
      heff_drop(v_g_240);
      heff_drop(v_h_2414);
      heff_drop(v_sp_2415);
      V v_t_2425 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2426, v_z_245});
    }
    }
  }
  case TAG_VFunction: {
    V v_level_2427 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2428 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2429 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2430 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VFunction: {
      V v_level_27_2433 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_2434 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_2435 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_2436 = heff_dup(heff_field(v_b_243, 3));
      V v_t_2439 = ({ V a_0 = v_level_2427; V a_1 = v_level_27_2433; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2427); heff_drop(v_level_27_2433); r_; });
      V v_t_2440;
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop(v_t_2439);
        switch (heff_tag_of(v_implicit_2430)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_2436)) {
          case TAG_Expl: {
            v_t_2440 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_2436);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_2436)) {
          case TAG_Expl: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_2440 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_2436);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_2436)) {
          case TAG_Expl: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_2440 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_2436);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2430);
        }
      } else {
        heff_drop(v_implicit_2430);
        heff_drop(v_implicit_27_2436);
        heff_drop(v_t_2439);
        v_t_2440 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop_tag(v_a_242, 6);
        heff_drop_tag(v_b_243, 6);
        heff_drop(v_t_2440);
        HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2428), v_dom_27_2434, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam0, 1, 7, (V[]){v_cs_241, v_dom_2428, v_cod_2429, v_cod_27_2435, v_g_240, v_z_244, v_z_245}));
      } else {
        heff_drop(v_g_240);
        heff_drop(v_dom_2428);
        heff_drop(v_cod_2429);
        heff_drop(v_dom_27_2434);
        heff_drop(v_cod_27_2435);
        heff_drop(v_t_2440);
        V v_t_2473 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        V v_t_2474 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})}));
        return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2474, v_z_245});
      }
    }
    default: {
      heff_drop(v_g_240);
      heff_drop(v_level_2427);
      heff_drop(v_dom_2428);
      heff_drop(v_cod_2429);
      heff_drop(v_implicit_2430);
      V v_t_2475 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2476 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2476, v_z_245});
    }
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_2481 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_2482 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2482, v_z_245});
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_2484 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_2485 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2485, v_z_245});
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: {
      V v_t_2486 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2487 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2487, v_z_245});
    }
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: {
      V v_t_2488 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2489 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2489, v_z_245});
    }
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: {
      V v_t_2490 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2491 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2491, v_z_245});
    }
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24111;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24111 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    if ((heff_dup(v_t_24111) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24111);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24111);
      V v_t_24112 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24113 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24113, v_z_245});
    }
  }
  case TAG_VPrimArray: {
    V v_x_24114 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VPrimArray: {
      V v_y_24115 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(v_g_240, v_cs_241, v_x_24114, v_y_24115, v_z_244, v_z_245);
    }
    default: {
      heff_drop(v_g_240);
      heff_drop(v_x_24114);
      V v_t_24116 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24117 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24116})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24117, v_z_245});
    }
    }
  }
  case TAG_VFixed: {
    V v_w_24118 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24119 = ({ V a_0 = v_w_24118; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24118); r_; });
    if ((heff_dup(v_t_24119) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24119);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24119);
      V v_t_24120 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24121 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24120})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24121, v_z_245});
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam1(V self, V *args) {
  V v_u_2443 = args[0];
  V v_dom_2428 = heff_env(self)[0];
  heff_drop(v_u_2443);
  heff_clo_take(self, 1);
  return v_dom_2428;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam2(V self, V *args) {
  V v_w_2456 = args[0];
  V v_v_2444 = heff_env(self)[0];
  heff_drop(v_w_2456);
  heff_clo_take(self, 1);
  return v_v_2444;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam3(V self, V *args) {
  V v_w_2466 = args[0];
  V v_v_2444 = heff_env(self)[0];
  heff_drop(v_w_2466);
  heff_clo_take(self, 1);
  return v_v_2444;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam0(V self, V *args) {
  V v_x_2441 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2428 = heff_env(self)[1];
  V v_cod_2429 = heff_env(self)[2];
  V v_cod_27_2435 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  heff_clo_take(self, 7);
  V v_v_2444 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2442, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam1, 1, 1, (V[]){v_dom_2428}), NTAG(TAG_Nothing)));
  V v_t_2449;
  switch (heff_tag_of(v_cod_2429)) {
  case TAG_MkClo: {
    V v_n_2445 = heff_dup(heff_field(v_cod_2429, 0));
    v_t_2449 = v_n_2445;
    break;
  }
  case TAG_CloConst: {
    v_t_2449 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_str0);
    break;
  }
  default: heff_nomatch(v_cod_2429);
  }
  V v_t_2450 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, heff_take_field(v_cs_241, 1)});
  V v_cs_2452 = ({ V rv_0 = v_t_2450; V rv_1 = v_t_2451; V rr_ = heff_rec_reuse_nf(v_cs_241, 0ULL, 2, shape_len__names, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_x1_2458;
  switch (heff_tag_of(v_cod_2429)) {
  case TAG_MkClo: {
    V v_vs_2454 = heff_field(v_cod_2429, 1);
    V v_body_2455 = heff_field(v_cod_2429, 2);
    heff_take_n(v_cod_2429, 6ULL, 3);
    v_x1_2458 = heff_tr(heff_call(v_body_2455, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2454, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam2, 1, 1, (V[]){heff_dup(v_v_2444)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2457 = heff_field(v_cod_2429, 0);
    heff_take_n(v_cod_2429, 1ULL, 1);
    v_x1_2458 = v_body_2457;
    break;
  }
  default: heff_nomatch(v_cod_2429);
  }
  V v_a_2462;
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nom: {
    V v_x_2459 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    v_a_2462 = v_x_2459;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    v_a_2462 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    v_a_2462 = v_x_2461;
    break;
  }
  default: heff_nomatch(v_x1_2458);
  }
  V v_x1_2468;
  switch (heff_tag_of(v_cod_27_2435)) {
  case TAG_MkClo: {
    V v_vs_2464 = heff_field(v_cod_27_2435, 1);
    V v_body_2465 = heff_field(v_cod_27_2435, 2);
    heff_take_n(v_cod_27_2435, 6ULL, 3);
    v_x1_2468 = heff_tr(heff_call(v_body_2465, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2464, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam3, 1, 1, (V[]){v_v_2444})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2467 = heff_field(v_cod_27_2435, 0);
    heff_take_n(v_cod_27_2435, 1ULL, 1);
    heff_drop(v_v_2444);
    v_x1_2468 = v_body_2467;
    break;
  }
  default: heff_nomatch(v_cod_27_2435);
  }
  V v_b_2472;
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_Nom: {
    V v_x_2469 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_b_2472 = v_x_2469;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2468, 0ULL, 1);
    v_b_2472 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2471 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_b_2472 = v_x_2471;
    break;
  }
  default: heff_nomatch(v_x1_2468);
  }
  return (g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(v_g_240, v_cs_2452, v_a_2462, v_b_2472, v_z_244, v_z_245));
}