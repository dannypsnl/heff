// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_MkChk 56962
#define LBL_start 311115900
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242(V, V, V);
V g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_clo;
HeffT1 g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr(V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2elocalNamed(V, V);
V g_heff_2eelab_2erules_2elocalNamed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalNamed_clo;
HeffT1 g_heff_2eelab_2erules_2etagChk_24cpr(V, V, V, V, V);
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr_str0, 2, "p#");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr_str1, 2, "p#");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr_str2, 3, "InR");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr_str3, 3, "InL");

HeffT1 g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr(V v_w_240, V v_sp_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    V v_w_243 = v_w_240;
    V v_sp_244 = v_sp_241;
    switch (heff_tag_of(v_w_243)) {
    case TAG_Nothing: {
      V v_t_245 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
      V v_t_246 = (g_heff_2eelab_2erules_2elocalNamed(heff_dup(v_sp_244), heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr_str0), v_t_245)));
      return ({ V a_0 = v_sp_244; V a_1 = v_t_246; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_w_243, 0);
      heff_take_n(v_w_243, 1ULL, 1);
      V v_callee_248 = (g_heff_2eelab_2erules_2elocalNamed(heff_dup(v_sp_244), v_x_247));
      V v_t_249 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
      V v_t_2410 = (g_heff_2eelab_2erules_2elocalNamed(heff_dup(v_sp_244), heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr_str1), v_t_249)));
      V v_arg_2411 = ({ V a_0 = heff_dup(v_sp_244); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2erules_2eapply(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = ({ V a_0 = NTAG(TAG_False); V a_1 = NTAG(TAG_False); V a_2 = heff_dup(v_sp_244); V a_3 = v_callee_248; V a_4 = v_arg_2411; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_callee_248); r_; });
      return ({ V a_0 = v_sp_244; V a_1 = v_t_2412; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
    }
    default: return ((HeffT1){{heff_nomatch(v_w_243)}});
    }
  }
  case TAG_Cons: {
    V v_b_2413 = heff_field(v_x1_242, 0);
    V v_rest_2414 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    V v_t_2415 = (g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242(v_w_240, heff_dup(v_sp_241), v_rest_2414));
    V v_cs_2416 = heff_tag_at_n(v_ru_24x1_242_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    V v_t_2417;
    if ((heff_dup(v_b_2413) == NTAG(TAG_True))) {
      heff_drop(v_b_2413);
      v_t_2417 = ((V)&g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr_str2);
    } else {
      heff_drop(v_b_2413);
      v_t_2417 = ((V)&g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr_str3);
    }
    return (g_heff_2eelab_2erules_2etagChk_24cpr(NTAG(TAG_True), heff_dup(v_sp_241), v_sp_241, v_t_2417, v_cs_2416));
  }
  default: return ((HeffT1){{heff_nomatch(v_x1_242)}});
  }
}
Clo g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_entry, 3, 0};

V g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242(V v_w_240, V v_sp_241, V v_x1_242) {
top: ;
  HeffT1 v_t_243 = (g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_24cpr(v_w_240, v_sp_241, v_x1_242));
  {
    V v_field_244 = v_t_243.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_244});
  }
}
V g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242(a[0], a[1], a[2]);
}