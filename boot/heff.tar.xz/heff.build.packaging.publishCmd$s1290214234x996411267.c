// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_package 1572278921
#define LBL_packages 1496006433
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_clo;
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str0, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str2, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str3, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str4, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str5, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam8(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam9(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0(V v_hd_240, V v_k_241, V v_v_242, V v_x_243) {
top: ;
  switch (heff_tag_of(v_x_243)) {
  case TAG_Left: {
    V v_ru_24x_243_24Left = heff_take_reuse_n(v_x_243, 0ULL, 1);
    heff_drop(v_v_242);
    V v_t_245 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str0), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_at_n(v_ru_24x_243_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Right: {
    heff_take_n(v_x_243, 0ULL, 1);
    V v_c_2419 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
    return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_v_242})});
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2411);
  V v_t_2412 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam9(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2465);
  V v_t_2466 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_cs_2428 = heff_env(self)[4];
  V v_v_242 = heff_env(self)[5];
  heff_drop(v_x_2429);
  V v_t_2430 = heff_dup(heff_rfield(v_x_2424, 3));
  switch (heff_tag_of(v_t_2430)) {
  case TAG_Nothing: {
    heff_clo_take(self, 6);
    heff_drop_rec(v_x_2424, 5);
    heff_drop(v_x_2425);
    heff_drop(v_cs_2428);
    heff_drop(v_v_242);
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str3), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam7, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_pk_2444 = heff_field(v_t_2430, 0);
    V v_ru_24t_2430_24Just = heff_take_reuse_n(v_t_2430, 1ULL, 1);
    heff_clo_take(self, 6);
    if (heff_intLt_c(MK_INT(0LL), v_x_2425)) {
      heff_drop_rec(v_x_2424, 5);
      heff_drop(v_cs_2428);
      heff_drop(v_v_242);
      heff_drop(v_pk_2444);
      V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str4), NTAG(TAG_MkUnit)});
      V v_t_2446 = heff_tag_at_n(v_ru_24t_2430_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam8, 1, 2, (V[]){v_hd_240, v_k_241})));
    } else {
      V v_t_2458 = ({ V a_0 = v_cs_2428; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_2428); r_; });
      if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2424, 5);
        heff_drop(v_v_242);
        heff_drop(v_pk_2444);
        heff_drop(v_t_2458);
        V v_t_2459 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str5), NTAG(TAG_MkUnit)});
        V v_t_2460 = heff_tag_at_n(v_ru_24t_2430_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
        V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
        V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
        V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
        V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam9, 1, 2, (V[]){v_hd_240, v_k_241})));
      } else {
        heff_drop_cell(v_ru_24t_2430_24Just, 1);
        heff_drop(v_t_2458);
        return (g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659(v_v_242, v_x_2424, v_pk_2444, v_hd_240, v_k_241));
      }
    }
  }
  default: return heff_nomatch(v_t_2430);
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_cs_2428 = heff_get_n(v_x_2427, 0, 2);
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2428), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam6, 1, 6, (V[]){v_x_2424, v_hd_240, v_k_241, v_x_2425, v_cs_2428, v_v_242})));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_t_2426 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_x_2424)));
  heff_clo_take(self, 4);
  V f_ = v_t_2426;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam5, 1, 5, (V[]){v_hd_240, v_x_2424, v_k_241, v_x_2425, v_v_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_t_2423 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2422, heff_dup(heff_rfield(v_x_2421, 4))));
  heff_clo_take(self, 4);
  V v_x_2424 = (g_list_2efoldl_24s571074576x1179600767(v_x_2421, v_t_2423));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str2), heff_dup(heff_rfield(v_x_2424, 1)), MK_INT(0LL), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam4, 1, 4, (V[]){v_x_2424, v_hd_240, v_k_241, v_v_242})));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam3, 1, 4, (V[]){v_x_2421, v_hd_240, v_k_241, v_v_242})));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2420, ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_v_242})));
}