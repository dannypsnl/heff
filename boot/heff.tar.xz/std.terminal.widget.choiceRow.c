// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Plain 3036
#define LBL_style 311138763
#define LBL_text 10052084
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(V, V, V, V);
V g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_clo;
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str1, 6, "(none)");
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str2, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str3, 6, "(none)");
HEFF_LIT(g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str4, 2, "  ");
Clo g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_entry, 4, 0};

V g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(V v_mark_240, V v_at_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x4_243, 0);
    V v_os_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_248;
    if (heff_intEq_c_lent(v_i_242, v_at_241, 0)) {
      V v_t_246;
      if (heff_strEq_c_lent(v_o_244, ((V)&g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str0), 2)) {
        heff_drop(v_o_244);
        v_t_246 = ((V)&g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str1);
      } else {
        v_t_246 = v_o_244;
      }
      v_t_248 = heff_tr(heff_call(heff_dup(v_mark_240), 1, (V[]){v_t_246}));
    } else {
      V v_t_247;
      if (heff_strEq_c_lent(v_o_244, ((V)&g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str2), 2)) {
        heff_drop(v_o_244);
        v_t_247 = ((V)&g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str3);
      } else {
        v_t_247 = v_o_244;
      }
      v_t_248 = heff_rec_n(2, shape_text__style, (V[]){v_t_247, NTAG(TAG_Plain)});
    }
    V v_t_2412;
    switch (heff_tag_of(v_os_245)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      v_t_2412 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_str4), NTAG(TAG_Plain)});
      v_t_2412 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_os_245);
    }
    V v_t_2413 = (g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(v_mark_240, v_at_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_os_245));
    V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2413));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2414});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}