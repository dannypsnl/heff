// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayAppend 23933
#define TAG_ArrayFromList 11455
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_ArrayIndexInAny 674
#define TAG_ArrayInsertAt 1609
#define TAG_ArrayKeeps 39370
#define TAG_ArrayKeepsAs 18630
#define TAG_ArrayLength 32493
#define TAG_ArrayOwn 58870
#define TAG_ArrayPeek 2264
#define TAG_ArrayPeekIn 6151
#define TAG_ArrayPush 18071
#define TAG_ArrayRemoveAt 38526
#define TAG_ArrayReplicate 47039
#define TAG_ArrayReserve 45606
#define TAG_ArraySet 62162
#define TAG_ArraySetOwned 53556
#define TAG_ArraySetOwnedIn 22211
#define TAG_ArraySlice 38486
#define TAG_ArrayToList 20274
#define TAG_BitsBytes 6377
#define TAG_BitsConcat 14523
#define TAG_BitsEq 8995
#define TAG_BitsIntAt 48290
#define TAG_BitsLength 37027
#define TAG_BitsOfBytes 24218
#define TAG_BitsOfInt 3554
#define TAG_BitsSlice 40746
#define TAG_BocGiven 26228
#define TAG_BocNew 29139
#define TAG_BocTaken 53948
#define TAG_BocWhen 59622
#define TAG_BytesAppend 445
#define TAG_BytesAsString 10306
#define TAG_BytesAt 9508
#define TAG_BytesConcat 52027
#define TAG_BytesEq 9629
#define TAG_BytesFind 30348
#define TAG_BytesFromList 45957
#define TAG_BytesFromString 47012
#define TAG_BytesHasAt 63051
#define TAG_BytesIntAt 64296
#define TAG_BytesLength 9005
#define TAG_BytesOfInt 19560
#define TAG_BytesSlice 56752
#define TAG_BytesToList 62312
#define TAG_BytesToString 37927
#define TAG_CustodianDue 8759
#define TAG_CustodyIn 58670
#define TAG_F32 16337
#define TAG_FloatAcos 708
#define TAG_FloatAdd 6390
#define TAG_FloatAsin 15893
#define TAG_FloatAtan 16606
#define TAG_FloatAtan2 55855
#define TAG_FloatBits 36420
#define TAG_FloatCos 8668
#define TAG_FloatDiv 9446
#define TAG_FloatEq 13032
#define TAG_FloatExp 10866
#define TAG_FloatFloor 58439
#define TAG_FloatFromInt 61384
#define TAG_FloatLe 13237
#define TAG_FloatLog 17305
#define TAG_FloatLt 13252
#define TAG_FloatMul 18457
#define TAG_FloatOfBits 49155
#define TAG_FloatOfDecimal 61587
#define TAG_FloatPow 21165
#define TAG_FloatShow 17547
#define TAG_FloatSin 23853
#define TAG_FloatSqrt 26286
#define TAG_FloatSub 24213
#define TAG_FloatTan 24566
#define TAG_FuelTick 47424
#define TAG_FuelTicks 28388
#define TAG_Hole 35555
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IntAdd 18227
#define TAG_IntAnd 18537
#define TAG_IntDiv 21283
#define TAG_IntEq 36665
#define TAG_IntHash 50175
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMod 30100
#define TAG_IntMul 30294
#define TAG_IntOr 36976
#define TAG_IntShl 35657
#define TAG_IntShow 56864
#define TAG_IntShr 35663
#define TAG_IntSub 36050
#define TAG_IntXor 40685
#define TAG_Keep 49586
#define TAG_OfFixed 17267
#define TAG_OnWindows 60758
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Panic 15447
#define TAG_Perform 19235
#define TAG_PerformAt 64592
#define TAG_Reuse 22912
#define TAG_RuneEq 61407
#define TAG_RuneFromInt 49375
#define TAG_RuneLe 61612
#define TAG_RuneLt 61627
#define TAG_RuneToInt 27192
#define TAG_SetField 47531
#define TAG_SetFieldPeek 37592
#define TAG_StrAppend 34515
#define TAG_StrByteAt 5424
#define TAG_StrCompare 35677
#define TAG_StrEq 12955
#define TAG_StrEqRange 52111
#define TAG_StrFind 15860
#define TAG_StrFromByte 3813
#define TAG_StrFromJS 60564
#define TAG_StrHash 2387
#define TAG_StrHashRange 56513
#define TAG_StrLength 43075
#define TAG_StrLt 13175
#define TAG_StrOfRunes 54236
#define TAG_StrRuneAt 38304
#define TAG_StrRuneCount 54745
#define TAG_StrRuneDecode 45427
#define TAG_StrRuneWidth 48503
#define TAG_StrRunes 5519
#define TAG_StrSlice 780
#define TAG_StrToJS 44411
#define TAG_TrieSlot 53599
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_WordAdd 60179
#define TAG_WordDiv 63235
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define TAG_WordMod 6526
#define TAG_WordMul 6720
#define TAG_WordQuot 65290
#define TAG_WordRem 11030
#define TAG_WordSub 12476
#define TAG_WordToFloat 50865
#define LBL_fixed 298804110
#define LBL_op 10312
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
V g_heff_2ecompile_2eprims_2ebitsJs_get(void);
V g_heff_2ecompile_2eprims_2ebyNonZero(V, V, V);
V g_heff_2ecompile_2eprims_2ebyNonZero_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2ebyNonZero_clo;
V g_heff_2ecompile_2eprims_2ecOnly_get(void);
V g_heff_2ecompile_2eprims_2efloat32ShowJs_get(void);
V g_heff_2ecompile_2eprims_2efmixJs_get(void);
V g_heff_2ecompile_2eprims_2eintOpJs(V, V);
V g_heff_2ecompile_2eprims_2eintOpJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eintOpJs_clo;
V g_heff_2ecompile_2eprims_2ejsPrims_get(void);
V g_heff_2ecompile_2eprims_2eliteralJs_get(void);
V g_heff_2ecompile_2eprims_2enarrowJs(V, V);
V g_heff_2ecompile_2eprims_2enarrowJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2enarrowJs_clo;
V g_heff_2ecompile_2eprims_2eprimJs(V);
V g_heff_2ecompile_2eprims_2eprimJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimJs_clo;
V g_heff_2ecompile_2eprims_2eshiftJs(V, V, V);
V g_heff_2ecompile_2eprims_2eshiftJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eshiftJs_clo;
V g_heff_2ecompile_2eprims_2eshiftMaskJs(V);
V g_heff_2ecompile_2eprims_2eshiftMaskJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eshiftMaskJs_clo;
V g_heff_2ecompile_2eprims_2estrHashJs_get(void);
V g_heff_2ecompile_2eprims_2eutf8AtJs_get(void);
V g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_get(void);
V g_heff_2eelab_2eprimitive_2elibraryPrims_get(void);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str0, 1, "[");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str2, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str3, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str4, 1, "1");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str5, 61, "const n = s.length, b = s.charCodeAt(i); if (b < 128) return ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str6, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str7, 5, "65533");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str8, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str9, 31, "if (!(i >= 0 && i < n)) return ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str10, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str11, 5, "65533");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str12, 1, "1");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str13, 12, "else return ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str14, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str15, 5, "65533");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str16, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str17, 29, "if (d < lo || d > hi) return ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str18, 46, "; lo = 128; hi = 191; c = c * 64 + (d & 63); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str19, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str20, 5, "m + 1");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str21, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str22, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str23, 78, "for (let k = 1; k <= m; k++) { const d = i + k < n \? s.charCodeAt(i + k) : -1;");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str24, 107, "else if (b >= 240 && b <= 244) { m = 3; c = b & 7; if (b === 240) lo = 144; else if (b === 244) hi = 143; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str25, 48, "if (b >= 194 && b <= 223) { m = 1; c = b & 31; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str26, 108, "else if (b >= 224 && b <= 239) { m = 2; c = b & 15; if (b === 224) lo = 160; else if (b === 237) hi = 159; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str27, 29, "let m, c, lo = 128, hi = 191;");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str28, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str29, 13, "((s, i) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8AtJs_str30, 3, " })");
V g_heff_2ecompile_2eprims_2eutf8AtJs_lam0(V self, V *args); static Clo g_heff_2ecompile_2eprims_2eutf8AtJs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eutf8AtJs_lam0, 2, 0};

static V g_heff_2ecompile_2eprims_2eutf8AtJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2eutf8AtJs_st;
static V g_heff_2ecompile_2eprims_2eutf8AtJs_init(void) {
  V v_ret_243 = ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_lam0_clo);
  V v_t_244 = heff_tr(heff_call(heff_dup(v_ret_243), 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str3), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str4)}));
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str5), v_t_244), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str6));
  V v_t_246 = heff_tr(heff_call(heff_dup(v_ret_243), 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str7), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str8)}));
  V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str9), v_t_246), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str10));
  V v_t_248 = heff_tr(heff_call(heff_dup(v_ret_243), 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str11), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str12)}));
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str13), v_t_248), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str14));
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_ret_243), 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str15), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str16)}));
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str17), v_t_2410), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str18));
  V v_t_2412 = heff_tr(heff_call(v_ret_243, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str19), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str20)}));
  V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str21), v_t_2412), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str22));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str23), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str24), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str26), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str27), v_t_2417})});
  V v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str28); V a_1 = v_t_245; V a_2 = v_t_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2418, 2); r_; });
  return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str29), v_t_2419), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str30));
}
V g_heff_2ecompile_2eprims_2eutf8AtJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2eutf8AtJs_st)) return g_heff_2ecompile_2eprims_2eutf8AtJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2eutf8AtJs_val, &g_heff_2ecompile_2eprims_2eutf8AtJs_st, g_heff_2ecompile_2eprims_2eutf8AtJs_init);
}
V g_heff_2ecompile_2eprims_2eutf8AtJs_lam0(V self, V *args) {
  V v_r_240 = args[0];
  V v_w_241 = args[1];
  V v_t_242 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str0), v_r_240), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str1));
  return heff_strAppend(heff_strAppend(v_t_242, v_w_241), ((V)&g_heff_2ecompile_2eprims_2eutf8AtJs_str2));
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ebitsJs_str0, 1408, "const rd = (a, at, n) => { let u = 0n; if (at % 8 === 0 && n % 8 === 0) { for (let i = at / 8; i < (at + n) / 8; i++) u = (u << 8n) | BigInt(a[i]); } else { for (let i = at; i < at + n; i++) u = (u << 1n) | BigInt((a[i >> 3] >> (7 - (i & 7))) & 1); } return u; }; const le = (u, n, out) => { const k = n >> 3, r = n & 7; let w = 0n; if (out) { for (let i = 0; i < k; i++) w = (w << 8n) | ((u >> BigInt(8 * i)) & 255n); if (r) w = (w << BigInt(r)) | ((u >> BigInt(8 * k)) & BigInt((1 << r) - 1)); } else { if (r) w = (u & BigInt((1 << r) - 1)) << BigInt(8 * k); for (let i = 0; i < k; i++) w |= ((u >> BigInt(n - 8 * (i + 1))) & 255n) << BigInt(8 * i); } return w; }; const int = (a, at, n, f) => { let u = rd(a, at, n); if (f & 1n) u = le(u, n, false); return (f & 2n) \? BigInt.asIntN(n, u) : u; }; const word = (v, n, f) => { const u = BigInt.asUintN(n, v); return (f & 1n) \? le(u, n, true) : u; }; const wr = (a, at, w, n) => { for (let i = 0; i < n; i++) if ((w >> BigInt(n - 1 - i)) & 1n) a[(at + i) >> 3] |= 0x80 >> ((at + i) & 7); }; const mk = (n) => { const r = new Uint8Array((n + 7) >> 3); r.bits = n; return r; }; const cp = (d, at, s, from, n) => { let i = 0; if (at % 8 === 0 && from % 8 === 0) { d.set(s.subarray(from / 8, from / 8 + (n >> 3)), at / 8); i = n - (n & 7); } for (; i < n; i++) if ((s[(from + i) >> 3] >> (7 - ((from + i) & 7))) & 1) d[(at + i) >> 3] |= 0x80 >> ((at + i) & 7); };");

static V g_heff_2ecompile_2eprims_2ebitsJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ebitsJs_st;
static V g_heff_2ecompile_2eprims_2ebitsJs_init(void) {
  return ((V)&g_heff_2ecompile_2eprims_2ebitsJs_str0);
}
V g_heff_2ecompile_2eprims_2ebitsJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ebitsJs_st)) return g_heff_2ecompile_2eprims_2ebitsJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ebitsJs_val, &g_heff_2ecompile_2eprims_2ebitsJs_st, g_heff_2ecompile_2eprims_2ebitsJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str1, 13, ") << 24 >> 24");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str3, 13, ") << 16 >> 16");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str5, 5, ") | 0");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str6, 18, "BigInt.asIntN(64, ");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str9, 7, ") & 255");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str11, 9, ") & 65535");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str13, 7, ") >>> 0");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str14, 19, "BigInt.asUintN(64, ");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str16, 12, "Math.fround(");
HEFF_LIT(g_heff_2ecompile_2eprims_2enarrowJs_str17, 1, ")");
Clo g_heff_2ecompile_2eprims_2enarrowJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2enarrowJs_entry, 2, 0};

V g_heff_2ecompile_2eprims_2enarrowJs(V v_x1_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_I8: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str0), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str1));
  }
  case TAG_I16: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str2), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str3));
  }
  case TAG_I32: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str4), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str5));
  }
  case TAG_I64: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str6), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str7));
  }
  case TAG_U8: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str8), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str9));
  }
  case TAG_U16: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str10), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str11));
  }
  case TAG_U32: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str12), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str13));
  }
  case TAG_U64: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str14), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str15));
  }
  case TAG_F32: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2enarrowJs_str16), v_e_241), ((V)&g_heff_2ecompile_2eprims_2enarrowJs_str17));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eprims_2enarrowJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2enarrowJs(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftMaskJs_str0, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftMaskJs_str1, 0, "");
Clo g_heff_2ecompile_2eprims_2eshiftMaskJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eshiftMaskJs_entry, 1, 0};

V g_heff_2ecompile_2eprims_2eshiftMaskJs(V v_w_240) {
top: ;
  int64_t v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_241 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_241 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_241 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_241 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_241 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_241 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_241 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_241 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  int64_t v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_242 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_242 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_242 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_242 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_242 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_243;
  if ((v_t_242 == ((int64_t)64ULL))) {
    v_t_243 = ((V)&g_heff_2ecompile_2eprims_2eshiftMaskJs_str0);
  } else {
    v_t_243 = ((V)&g_heff_2ecompile_2eprims_2eshiftMaskJs_str1);
  }
  V v_t_244 = heff_intShow(heff_box_word((v_t_241 - ((int64_t)1ULL))));
  return heff_strAppend(v_t_244, v_t_243);
}
V g_heff_2ecompile_2eprims_2eshiftMaskJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2eshiftMaskJs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str0, 2, "0n");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str2, 6, "b === ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str3, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str4, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eprims_2ebyNonZero_str5, 14, "(a) => (b) => ");
Clo g_heff_2ecompile_2eprims_2ebyNonZero_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2ebyNonZero_entry, 3, 0};

V g_heff_2ecompile_2eprims_2ebyNonZero(V v_w_240, V v_byZero_241, V v_e_242) {
top: ;
  int64_t v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_243 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_243 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_243 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_243 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_243 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_243 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_244;
  if ((v_t_243 == ((int64_t)64ULL))) {
    v_t_244 = ((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str0);
  } else {
    v_t_244 = ((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str1);
  }
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str2), v_t_244), ((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str3));
  V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, v_byZero_241), ((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str4));
  return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2ebyNonZero_str5), heff_strAppend(v_t_246, v_e_242));
}
V g_heff_2ecompile_2eprims_2ebyNonZero_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2ebyNonZero(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str0, 2, "0n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str2, 2, "a ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str3, 7, " (-b & ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str5, 2, "a ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str6, 6, " (b & ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str8, 4, "b < ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str9, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str10, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str11, 2, "a ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str12, 6, " (b & ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eshiftJs_str13, 1, ")");
Clo g_heff_2ecompile_2eprims_2eshiftJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eshiftJs_entry, 3, 0};

V g_heff_2ecompile_2eprims_2eshiftJs(V v_w_240, V v_op_241, V v_back_242) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_I16: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_I32: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_I64: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_U8: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    int64_t v_t_244;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_244 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_244 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_244 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_244 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_244 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_244 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_245;
    if ((v_t_244 == ((int64_t)64ULL))) {
      v_t_245 = ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str0);
    } else {
      v_t_245 = ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str1);
    }
    V v_t_246 = (g_heff_2ecompile_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str2), v_back_242), ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str3));
    V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, v_t_246), ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str4));
    V v_t_249 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_248));
    V v_t_2410 = (g_heff_2ecompile_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str5), v_op_241), ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str6));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, v_t_2410), ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str7));
    V v_t_2413 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2412));
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str8), v_t_245), ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str9));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, v_t_249), ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str10));
    return heff_strAppend(v_t_2415, v_t_2413);
  } else {
    heff_drop(v_back_242);
    heff_drop(v_t_243);
    V v_t_2416 = (g_heff_2ecompile_2eprims_2eshiftMaskJs(v_w_240));
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eshiftJs_str11), v_op_241), ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str12));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_t_2416), ((V)&g_heff_2ecompile_2eprims_2eshiftJs_str13));
    return (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2418));
  }
}
V g_heff_2ecompile_2eprims_2eshiftJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2eshiftJs(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str0, 5, "a + b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str1, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str2, 5, "a - b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str3, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str4, 5, "a * b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str5, 15, "Math.imul(a, b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str6, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str7, 5, "a * b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str8, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str9, 5, "a / b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str10, 17, "Math.trunc(a / b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str11, 5, "a - b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str12, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str13, 5, "a % b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str14, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str15, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str16, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str17, 5, "a & b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str18, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str19, 5, "a | b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str20, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str21, 5, "a ^ b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str22, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str23, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str24, 3, ">>>");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str25, 2, "<<");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str26, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str27, 2, ">>");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str28, 3, ">>>");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str29, 2, "<<");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str30, 14, "(a) => (b) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str31, 19, "(a) => a.toString()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str32, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str33, 7, "(a) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str34, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str35, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str36, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str37, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str38, 6, "UintN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str39, 6, "UintN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str40, 6, "UintN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str41, 6, "UintN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str42, 5, "IntN(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str43, 23, "(a) => Number(BigInt.as");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str44, 5, ", a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str45, 8, "(a) => a");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str46, 16, "(a) => BigInt(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str47, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str48, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str49, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eintOpJs_str50, 17, "(a) => $abandon()");
Clo g_heff_2ecompile_2eprims_2eintOpJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eintOpJs_entry, 2, 0};

V g_heff_2ecompile_2eprims_2eintOpJs(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_body_242 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str0)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str1), v_body_242);
  }
  case TAG_OpSub: {
    V v_body_243 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str2)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str3), v_body_243);
  }
  case TAG_OpMul: {
    int64_t v_t_244;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_244 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_244 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_244 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_244 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_244 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_244 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_244 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_245;
    if ((v_t_244 == ((int64_t)64ULL))) {
      v_t_245 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str4);
    } else {
      v_t_245 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str5);
    }
    V v_body_246 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_245));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str6), v_body_246);
  }
  case TAG_OpDiv: {
    int64_t v_t_247;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_247 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_247 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_247 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_247 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_247 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_247 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_247 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_248;
    if ((v_t_247 == ((int64_t)64ULL))) {
      v_t_248 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str7);
    } else {
      v_t_248 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str8);
    }
    int64_t v_t_249;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_249 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_249 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_249 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_249 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_249 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_249 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_249 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_249 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_249 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2410;
    if ((v_t_249 == ((int64_t)64ULL))) {
      v_t_2410 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str9);
    } else {
      v_t_2410 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str10);
    }
    V v_t_2411 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, v_t_2410));
    return (g_heff_2ecompile_2eprims_2ebyNonZero(v_w_240, v_t_248, v_t_2411));
  }
  case TAG_OpRem: {
    int64_t v_t_2412;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2412 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2412 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2412 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2412 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2412 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2412 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2412 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2412 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2412 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2413;
    if ((v_t_2412 == ((int64_t)64ULL))) {
      v_t_2413 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str11);
    } else {
      v_t_2413 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str12);
    }
    V v_t_2414 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str13)));
    return (g_heff_2ecompile_2eprims_2ebyNonZero(v_w_240, v_t_2413, v_t_2414));
  }
  case TAG_OpEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str14);
  }
  case TAG_OpLt: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str15);
  }
  case TAG_OpLe: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str16);
  }
  case TAG_OpAnd: {
    V v_body_2415 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str17)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str18), v_body_2415);
  }
  case TAG_OpOr: {
    V v_body_2416 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str19)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str20), v_body_2416);
  }
  case TAG_OpXor: {
    V v_body_2417 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str21)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str22), v_body_2417);
  }
  case TAG_OpShl: {
    V v_t_2418;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_I16: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_I32: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_I64: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_U8: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_U16: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_U32: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_U64: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_F32: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2431;
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2431 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2418);
      int64_t v_t_2434;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2434 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_2434 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_2434 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_2434 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_2434 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_2434 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_2434 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_2434 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_2434 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      v_t_2431 = heff_bool((v_t_2434 == ((int64_t)64ULL)));
    }
    V v_t_2419;
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str23);
      break;
    }
    case TAG_False: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str24);
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    V v_body_2420 = (g_heff_2ecompile_2eprims_2eshiftJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str25), v_t_2419));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str26), v_body_2420);
  }
  case TAG_OpShr: {
    V v_t_2421;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2421 = NTAG(TAG_True);
      break;
    }
    case TAG_I16: {
      v_t_2421 = NTAG(TAG_True);
      break;
    }
    case TAG_I32: {
      v_t_2421 = NTAG(TAG_True);
      break;
    }
    case TAG_I64: {
      v_t_2421 = NTAG(TAG_True);
      break;
    }
    case TAG_U8: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_U16: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_U32: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_U64: {
      v_t_2421 = NTAG(TAG_False);
      break;
    }
    case TAG_F32: {
      v_t_2421 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2436;
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_t_2421);
      v_t_2436 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2421);
      int64_t v_t_2439;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2439 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_2439 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_2439 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_2439 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_2439 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_2439 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_2439 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_2439 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_2439 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      v_t_2436 = heff_bool((v_t_2439 == ((int64_t)64ULL)));
    }
    V v_t_2422;
    switch (heff_tag_of(v_t_2436)) {
    case TAG_True: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str27);
      break;
    }
    case TAG_False: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str28);
      break;
    }
    default: heff_nomatch(v_t_2436);
    }
    V v_body_2423 = (g_heff_2ecompile_2eprims_2eshiftJs(v_w_240, v_t_2422, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str29)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str30), v_body_2423);
  }
  case TAG_OpShow: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str31);
  }
  case TAG_OpFromInt: {
    int64_t v_t_2424;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2424 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2424 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2424 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2424 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2424 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2424 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2424 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2424 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2424 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if ((v_t_2424 == ((int64_t)64ULL))) {
      V v_t_2425 = (g_heff_2ecompile_2eprims_2enarrowJs(v_w_240, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str32)));
      return heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str33), v_t_2425);
    } else {
      V v_t_2426;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str34);
        break;
      }
      case TAG_I16: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str35);
        break;
      }
      case TAG_I32: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str36);
        break;
      }
      case TAG_I64: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str37);
        break;
      }
      case TAG_U8: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str38);
        break;
      }
      case TAG_U16: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str39);
        break;
      }
      case TAG_U32: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str40);
        break;
      }
      case TAG_U64: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str41);
        break;
      }
      case TAG_F32: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str42);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2427;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2427 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2427 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2427 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2427 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2427 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2427 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2427 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2427 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2427 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eintOpJs_str43), v_t_2426), heff_intShow(v_t_2427));
      return heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str44));
    }
  }
  case TAG_OpToInt: {
    int64_t v_t_2429;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2429 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2429 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2429 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2429 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2429 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2429 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2429 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2429 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2429 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    if ((v_t_2429 == ((int64_t)64ULL))) {
      return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str45);
    } else {
      return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str46);
    }
  }
  case TAG_OpSqrt: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str47);
  }
  case TAG_OpFromFloat: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str48);
  }
  case TAG_OpToFloat: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str49);
  }
  case TAG_OpFloor: {
    return ((V)&g_heff_2ecompile_2eprims_2eintOpJs_str50);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eprims_2eintOpJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eprims_2eintOpJs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eliteralJs_str0, 295, "if (t === 0) return 1 / t < 0 \? \"-0.0\" : \"0.0\"; const s = String(t); if (!Number.isFinite(t)) return s; const i = s.indexOf(\"e\"); if (i < 0) return s.includes(\".\") \? s : s + \".0\"; const m = s.slice(0, i); return (m.includes(\".\") \? m : m + \".0\") + \"e\" + s.slice(s[i + 1] === \"+\" \? i + 2 : i + 1);");

static V g_heff_2ecompile_2eprims_2eliteralJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2eliteralJs_st;
static V g_heff_2ecompile_2eprims_2eliteralJs_init(void) {
  return ((V)&g_heff_2ecompile_2eprims_2eliteralJs_str0);
}
V g_heff_2ecompile_2eprims_2eliteralJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2eliteralJs_st)) return g_heff_2ecompile_2eprims_2eliteralJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2eliteralJs_val, &g_heff_2ecompile_2eprims_2eliteralJs_st, g_heff_2ecompile_2eprims_2eliteralJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str0, 1, "}");
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_lit_v_t_240, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str0), NTAG(TAG_Nil));
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str1, 67, "if (w >= 0n) { t = Number(w + \"e\" + s) * Math.sign(a); break; } } }");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str2, 94, "const near = r2 > den || (r2 === den && (q & 1n)) \? q + 1n : q, far = near === q \? q + 1n : q;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str3, 62, "const w = inside(near, s) \? near : inside(far, s) \? far : -1n;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str4, 88, "const num = s >= 0 \? n : n * 10n ** BigInt(-s), den = s >= 0 \? d * 10n ** BigInt(s) : d;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str5, 43, "const q = num / den, r2 = 2n * (num % den);");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str6, 55, "return even \? lo <= c && c <= hi : lo < c && c < hi; };");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str7, 51, "for (let p = 1; p <= 9; p++) { const s = k - p + 1;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str8, 106, "const inside = (q, s) => { const c = q * 10n ** BigInt(Math.max(s, 0)) * 2n ** BigInt(Math.max(2 - e, 0));");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str9, 123, "const f = 10n ** BigInt(Math.max(-s, 0)) * 2n ** BigInt(Math.max(e - 2, 0)), lo = (4n * m - g) * f, hi = (4n * m + 2n) * f;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str10, 87, "let k = Math.floor(Math.log10(Math.abs(a))); while (!ge(k)) k--; while (ge(k + 1)) k++;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str11, 69, "const g = m === 8388608n && be > 1 \? 1n : 2n, even = (m & 1n) === 0n;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str12, 74, "const n = e >= 0 \? m << BigInt(e) : m, d = e >= 0 \? 1n : 1n << BigInt(-e);");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str13, 82, "const ge = (k) => k >= 0 \? n >= d * 10n ** BigInt(k) : n * 10n ** BigInt(-k) >= d;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str14, 40, "const b = v.getUint32(0), be = b >>> 23;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str15, 82, "const m = BigInt(be \? (b & 8388607) | 8388608 : b & 8388607), e = (be || 1) - 150;");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str16, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str17, 56, "(a) => { let t = a; if (Number.isFinite(a) && a !== 0) {");
HEFF_LIT(g_heff_2ecompile_2eprims_2efloat32ShowJs_str18, 73, "const v = new DataView(new ArrayBuffer(4)); v.setFloat32(0, Math.abs(a));");

static V g_heff_2ecompile_2eprims_2efloat32ShowJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2efloat32ShowJs_st;
static V g_heff_2ecompile_2eprims_2efloat32ShowJs_init(void) {
  V v_t_240 = ((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_lit_v_t_240);
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str1), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eprims_2eliteralJs_get()), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str3), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str5), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str7), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str9), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str11), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str13), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str15), v_t_247})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str16); V a_1 = ((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str17); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eprims_2efloat32ShowJs_str18), v_t_248}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ecompile_2eprims_2efloat32ShowJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2efloat32ShowJs_st)) return g_heff_2ecompile_2eprims_2efloat32ShowJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2efloat32ShowJs_val, &g_heff_2ecompile_2eprims_2efloat32ShowJs_st, g_heff_2ecompile_2eprims_2efloat32ShowJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2efmixJs_str0, 162, "((h) => { const M = 0xffffffffffffffffn; h ^= h >> 33n; h = h * 0xff51afd7ed558ccdn & M; h ^= h >> 33n; h = h * 0xc4ceb9fe1a85ec53n & M; return h ^ (h >> 33n); })");

static V g_heff_2ecompile_2eprims_2efmixJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2efmixJs_st;
static V g_heff_2ecompile_2eprims_2efmixJs_init(void) {
  return ((V)&g_heff_2ecompile_2eprims_2efmixJs_str0);
}
V g_heff_2ecompile_2eprims_2efmixJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2efmixJs_st)) return g_heff_2ecompile_2eprims_2efmixJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2efmixJs_val, &g_heff_2ecompile_2eprims_2efmixJs_st, g_heff_2ecompile_2eprims_2efmixJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2estrHashJs_str0, 382, "(s) => { const M = 0xffffffffffffffffn, n = s.length; let h = BigInt(n), i = 0; const half = (j, e) => { let x = 0; for (let k = Math.min(j + 4, e) - 1; k >= j; k--) x = x * 256 + s.charCodeAt(k); return BigInt(x); }; const step = (w) => { h = ((((h << 5n) | (h >> 59n)) & M) ^ w) * 0x517cc1b727220a95n & M; }; for (; i < n; i += 8) step(half(i, n) | half(i + 4, n) << 32n); return ");
HEFF_LIT(g_heff_2ecompile_2eprims_2estrHashJs_str1, 12, "(h) >> 2n; }");

static V g_heff_2ecompile_2eprims_2estrHashJs_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2estrHashJs_st;
static V g_heff_2ecompile_2eprims_2estrHashJs_init(void) {
  return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2estrHashJs_str0), heff_dup(g_heff_2ecompile_2eprims_2efmixJs_get())), ((V)&g_heff_2ecompile_2eprims_2estrHashJs_str1));
}
V g_heff_2ecompile_2eprims_2estrHashJs_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2estrHashJs_st)) return g_heff_2ecompile_2eprims_2estrHashJs_val;
  return heff_global(&g_heff_2ecompile_2eprims_2estrHashJs_val, &g_heff_2ecompile_2eprims_2estrHashJs_st, g_heff_2ecompile_2eprims_2estrHashJs_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2ecOnly_str0, 16, "() => $abandon()");

static V g_heff_2ecompile_2eprims_2ecOnly_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ecOnly_st;
static V g_heff_2ecompile_2eprims_2ecOnly_init(void) {
  return ((V)&g_heff_2ecompile_2eprims_2ecOnly_str0);
}
V g_heff_2ecompile_2eprims_2ecOnly_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ecOnly_st)) return g_heff_2ecompile_2eprims_2ecOnly_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ecOnly_val, &g_heff_2ecompile_2eprims_2ecOnly_st, g_heff_2ecompile_2eprims_2ecOnly_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str0, 61, "if (!(i >= 0 && i < n)) return { $: \"#_,_\", a: [65533, 0n] };");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str1, 29, "let m, c, lo = 128, hi = 191;");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str2, 48, "if (b >= 194 && b <= 223) { m = 1; c = b & 31; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str3, 108, "else if (b >= 224 && b <= 239) { m = 2; c = b & 15; if (b === 224) lo = 160; else if (b === 237) hi = 159; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str4, 107, "else if (b >= 240 && b <= 244) { m = 3; c = b & 7; if (b === 240) lo = 144; else if (b === 244) hi = 143; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str5, 42, "else return { $: \"#_,_\", a: [65533, 1n] };");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str6, 78, "for (let k = 1; k <= m; k++) { const d = i + k < n \? s.charCodeAt(i + k) : -1;");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str7, 111, "if (d < lo || d > hi) return { $: \"#_,_\", a: [65533, BigInt(k)] }; lo = 128; hi = 191; c = c * 64 + (d & 63); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str8, 44, "return { $: \"#_,_\", a: [c, BigInt(m + 1)] };");
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit9, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str8), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit10, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str7), ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit9));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit11, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str6), ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit10));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit12, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str5), ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit11));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit13, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str4), ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit12));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit14, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str3), ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit13));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit15, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str2), ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit14));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit16, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str1), ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit15));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit_v_t_244, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str0), ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit16));
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str17, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str18, 87, "const n = s.length, b = s.charCodeAt(i); if (b < 128) return { $: \"#_,_\", a: [b, 1n] };");

static V g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_st;
static V g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_init(void) {
  V v_t_244 = ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_lit_v_t_244);
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str17); V a_1 = ((V)&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_str18); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_st)) return g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_val;
  return heff_global(&g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_val, &g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_st, g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_init);
}
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str0, 19, "(a) => (b) => a + b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str1, 19, "(a) => (b) => a - b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str2, 19, "(a) => (b) => a * b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str3, 128, "(a) => (b) => { if (b === 0n) return a * b; const q = a / b, r = a % b; return r !== 0n && (r < 0n) !== (b < 0n) \? q - 1n : q; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str4, 116, "(a) => (b) => { if (b === 0n) return a - b; const r = a % b; return r !== 0n && (r < 0n) !== (b < 0n) \? r + b : r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str5, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str6, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str7, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str8, 19, "(a) => a.toString()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str9, 19, "(a) => (b) => a & b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str10, 19, "(a) => (b) => a | b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str11, 19, "(a) => (b) => a ^ b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str12, 39, "(a) => (b) => b < 0n \? a >> -b : a << b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str13, 39, "(a) => (b) => b < 0n \? a << -b : a >> b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str14, 19, "(a) => (b) => a + b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str15, 19, "(a) => (b) => a - b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str16, 19, "(a) => (b) => a * b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str17, 19, "(a) => (b) => a / b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str18, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str19, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str20, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str21, 9, "(t) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str22, 2, " }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str23, 16, "(a) => Number(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str24, 19, "(a) => Math.sqrt(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str25, 79, "(u) => typeof process !== \"undefined\" && process.platform === \"win32\" \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str26, 54, "(a) => Number.isFinite(a) \? BigInt(Math.floor(a)) : 0n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str27, 18, "(a) => Math.sin(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str28, 18, "(a) => Math.cos(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str29, 18, "(a) => Math.tan(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str30, 19, "(a) => Math.asin(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str31, 19, "(a) => Math.acos(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str32, 19, "(a) => Math.atan(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str33, 30, "(a) => (b) => Math.atan2(a, b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str34, 18, "(a) => Math.exp(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str35, 18, "(a) => Math.log(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str36, 84, "(a) => (b) => a === 1 || (a === -1 && Math.abs(b) === Infinity) \? 1 : Math.pow(a, b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str37, 23, "(a) => BigInt(a.length)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str38, 73, "(a) => (i) => i >= 0n && i < BigInt(a.length) \? a[Number(i)] : $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str39, 123, "(a) => (i) => (x) => { if (!(i >= 0n && i < BigInt(a.length))) return a; const b = a.slice(); b[Number(i)] = x; return b; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str40, 167, "(n) => (f) => ((r) => r.length > 0 && typeof r[0] === \"number\" \? Float64Array.from(r) : r)(Array.from({ length: n > 0n \? Number(n) : 0 }, (_, k) => $tr(f(BigInt(k)))))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str41, 167, "(l) => { const r = []; while (l.$ === \"Cons\") { r.push(l.a[0]); l = l.a[1]; } return ((r) => r.length > 0 && typeof r[0] === \"number\" \? Float64Array.from(r) : r)(r); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str42, 85, "(a) => a.reduceRight((rest, x) => ({ $: \"Cons\", a: [x, rest] }), { $: \"Nil\", a: [] })");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str43, 134, "(n) => (x) => { const m = n > 0n \? Number(n) : 0; return typeof x === \"number\" \? new Float64Array(m).fill(x) : new Array(m).fill(x); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str44, 50, "(a) => (i) => (j) => a.slice(Number(i), Number(j))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str45, 220, "(a) => (b) => { if (b.length === 0) return a; if (a.length === 0) return b; if (!(a instanceof Float64Array)) return a.concat(b); const r = new Float64Array(a.length + b.length); r.set(a); r.set(b, a.length); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str46, 211, "(a) => (i) => (x) => { const r = Array.from(a); r.splice(i < 0n \? 0 : i > BigInt(r.length) \? r.length : Number(i), 0, x); return ((r) => r.length > 0 && typeof r[0] === \"number\" \? Float64Array.from(r) : r)(r); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str47, 204, "(a) => (i) => { if (!(i >= 0n && i < BigInt(a.length))) return a; const r = Array.from(a); r.splice(Number(i), 1); return ((r) => r.length > 0 && typeof r[0] === \"number\" \? Float64Array.from(r) : r)(r); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str48, 141, "(a) => (x) => { const r = Array.from(a); r.push(x); return ((r) => r.length > 0 && typeof r[0] === \"number\" \? Float64Array.from(r) : r)(r); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str49, 15, "(a) => (k) => a");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str50, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str51, 46, "(d) => (i) => (v) => { d.a[i] = v; return v; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str52, 19, "(a) => (b) => a + b");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str53, 23, "(a) => BigInt(a.length)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str54, 50, "(a) => (i) => (j) => a.slice(Number(i), Number(j))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str55, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str56, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str57, 45, "(a) => (b) => a < b \? -1n : a === b \? 0n : 1n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str58, 122, "(n) => (s) => (i) => { const k = i < 0n \? 0 : Number(i); return k + n.length > s.length \? -1n : BigInt(s.indexOf(n, k)); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str59, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str60, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str61, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str62, 16, "(a) => BigInt(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str63, 35, "(a) => Number(BigInt.asIntN(32, a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str64, 8, "(x) => x");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str65, 30, "(s) => { throw new Error(s); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str66, 85, "(a) => (i) => i >= 0n && i < BigInt(a.length) \? BigInt(a.charCodeAt(Number(i))) : -1n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str67, 29, "(c) => String.fromCharCode(c)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str68, 14, "(s) => (i) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str69, 17, "(s, Number(i))[0]");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str70, 21, "(s) => (i) => BigInt(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str71, 18, "(s, Number(i))[1])");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str72, 20, "(s) => { const at = ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str73, 85, "; let n = 0; for (let i = 0; i < s.length; i += at(s, i)[1]) n++; return BigInt(n); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str74, 20, "(s) => { const at = ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str75, 277, "; const r = []; for (let i = 0; i < s.length;) { const b = s.charCodeAt(i); if (b < 128) { r.push(b); i++; } else { const [c, w] = at(s, i); r.push(c); i += w; } } let l = { $: \"Nil\", a: [] }; for (let i = r.length - 1; i >= 0; i--) l = { $: \"Cons\", a: [r[i], l] }; return l; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str76, 446, "(l) => { let s = \"\"; while (l.$ === \"Cons\") { let c = l.a[0]; if (!(c >= 0 && c <= 0x10FFFF && (c < 0xD800 || c > 0xDFFF))) c = 0xFFFD; s += c < 0x80 \? String.fromCharCode(c) : c < 0x800 \? String.fromCharCode(0xC0 | c >> 6, 0x80 | c & 63) : c < 0x10000 \? String.fromCharCode(0xE0 | c >> 12, 0x80 | c >> 6 & 63, 0x80 | c & 63) : String.fromCharCode(0xF0 | c >> 18, 0x80 | c >> 12 & 63, 0x80 | c >> 6 & 63, 0x80 | c & 63); l = l.a[1]; } return s; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str77, 15, "(s) => $toJs(s)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str78, 17, "(t) => $fromJs(t)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str79, 23, "(a) => BigInt(a.length)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str80, 73, "(a) => (i) => i >= 0n && i < BigInt(a.length) \? a[Number(i)] : $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str81, 50, "(a) => (i) => (j) => a.slice(Number(i), Number(j))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str82, 104, "(a) => (b) => { const r = new Uint8Array(a.length + b.length); r.set(a); r.set(b, a.length); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str83, 210, "(l) => { let n = 0; for (let c = l; c.$ === \"Cons\"; c = c.a[1]) n += c.a[0].length; const r = new Uint8Array(n); for (let k = 0; l.$ === \"Cons\"; l = l.a[1]) { r.set(l.a[0], k); k += l.a[0].length; } return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str84, 131, "(a) => (b) => { if (a.length !== b.length) return $F; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return $F; return $T; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str85, 106, "(l) => { const r = []; while (l.$ === \"Cons\") { r.push(l.a[0]); l = l.a[1]; } return Uint8Array.from(r); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str86, 122, "(a) => { let l = { $: \"Nil\", a: [] }; for (let i = a.length - 1; i >= 0; i--) l = { $: \"Cons\", a: [a[i], l] }; return l; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str87, 115, "(s) => { const r = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) r[i] = s.charCodeAt(i); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str88, 136, "(a) => { let s = \"\"; for (let i = 0; i < a.length; i += 8192) s += String.fromCharCode.apply(null, a.subarray(i, i + 8192)); return s; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str89, 71, "(a) => $fromJs(new TextDecoder(\"utf-8\", { ignoreBOM: true }).decode(a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str90, 30, "(a) => (o) => (n) => (f) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str91, 146, " const at = Number(o), m = Number(n); if (!(at >= 0 && m >= 0 && m <= 64 && at + m <= a.length * 8)) return $abandon(); return int(a, at, m, f); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str92, 23, "(n) => (f) => (v) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str93, 154, " const m = Number(n); if (!(m >= 0 && m <= 64 && m % 8 === 0)) return $abandon(); const r = new Uint8Array(m / 8); wr(r, 0, word(v, m, f), m); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str94, 183, "(a) => (o) => (b) => { const at = Number(o); if (!(at >= 0 && at <= a.length - b.length)) return $F; for (let i = 0; i < b.length; i++) if (a[at + i] !== b[i]) return $F; return $T; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str95, 310, "(n) => (a) => (i) => { const m = n.length, end = a.length - m; let k = i < 0n \? 0 : Number(i); if (k > end) return -1n; if (m === 0) return BigInt(k); for (;;) { k = a.indexOf(n[0], k); if (k < 0 || k > end) return -1n; let j = 1; while (j < m && a[k + j] === n[j]) j++; if (j === m) return BigInt(k); k++; } }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str96, 21, "(a) => BigInt(a.bits)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str97, 30, "(a) => (o) => (n) => (f) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str98, 140, " const at = Number(o), m = Number(n); if (!(at >= 0 && m >= 0 && m <= 64 && at + m <= a.bits)) return $abandon(); return int(a, at, m, f); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str99, 23, "(n) => (f) => (v) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str100, 123, " const m = Number(n); if (!(m >= 0 && m <= 64)) return $abandon(); const r = mk(m); wr(r, 0, word(v, m, f), m); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str101, 9, "(l) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str102, 202, " let n = 0; for (let c = l; c.$ === \"Cons\"; c = c.a[1]) n += c.a[0].bits; const r = mk(n); for (let k = 0; l.$ === \"Cons\"; l = l.a[1]) { cp(r, k, l.a[0], 0, l.a[0].bits); k += l.a[0].bits; } return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str103, 23, "(a) => (o) => (n) => { ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str104, 151, " const at = Number(o), m = Number(n); if (!(at >= 0 && m >= 0 && at + m <= a.bits)) return $abandon(); const r = mk(m); cp(r, 0, a, at, m); return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str105, 103, "(a) => { const r = new Uint8Array(a.buffer, a.byteOffset, a.length); r.bits = a.length * 8; return r; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str106, 87, "(a) => a.bits % 8 !== 0 \? $abandon() : new Uint8Array(a.buffer, a.byteOffset, a.length)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str107, 127, "(a) => (b) => { if (a.bits !== b.bits) return $F; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return $F; return $T; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str108, 289, "(n) => (x) => { const v = new DataView(new ArrayBuffer(8)); if (n === 64n) { if (x !== x) return 0x7ff8000000000000n; v.setFloat64(0, x); return v.getBigUint64(0); } if (n === 32n) { if (x !== x) return 0x7fc00000n; v.setFloat32(0, x); return BigInt(v.getUint32(0)); } return $abandon(); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str109, 255, "(n) => (u) => { const v = new DataView(new ArrayBuffer(8)); if (n === 64n) { v.setBigUint64(0, BigInt.asUintN(64, u)); return v.getFloat64(0); } if (n === 32n) { v.setUint32(0, Number(BigInt.asUintN(32, u))); return v.getFloat32(0); } return $abandon(); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str110, 1080, "(n) => (s) => (i) => (j) => { if (n !== 64n && n !== 32n) return $abandon(); const t = s.slice(Number(i), Number(j)); if (!/^-\?[0-9]+(\?:[.][0-9]+)\?(\?:[eE][+-]\?[0-9]+)\?$/.test(t)) return NaN; const d = Number(t); if (n === 64n) return d; const f = Math.fround(d), a = Math.abs(d); if (a === 0 || a === Infinity) return f; const v = new DataView(new ArrayBuffer(8)); v.setFloat64(0, a); const u = v.getBigUint64(0), x = Number(u >> 52n); if (x === 0) return f; const m = (u & 0xfffffffffffffn) | 0x10000000000000n, e = x - 1075; const k = BigInt(Math.max(x - 1046, -149) - 1 - e); if ((m >> k) % 2n !== 1n || m % (1n << k) !== 0n) return f; const g = t.match(/^-\?([0-9]+)(\?:[.]([0-9]+))\?(\?:[eE]([+-]\?[0-9]+))\?$/), r = g[2] || ''; const p = BigInt(g[3] || '0') - BigInt(r.length); let A = BigInt(g[1] + r), B = m; if (p >= 0n) A *= 10n ** p; else B *= 10n ** -p; if (e >= 0) B <<= BigInt(e); else A <<= BigInt(-e); if (A === B) return f; v.setBigUint64(0, BigInt(e + 1023) + k << 52n); const h = v.getFloat64(0); const c = Math.fround(A > B \? a + h : a - h); return d < 0 \? -c : c; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str111, 22, "(s) => (i) => (j) => (");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str112, 32, ")(s.slice(Number(i), Number(j)))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str113, 73, "(t) => (s) => (i) => (j) => t === s.slice(Number(i), Number(j)) \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str114, 7, "(a) => ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str115, 29, "(BigInt.asUintN(64, a)) >> 2n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str116, 157, "(bm) => (h) => (s) => { const bit = 1n << ((h >> s) & 31n); let m = bm & (bit - 1n), c = 0n; while (m) { m &= m - 1n; c++; } return bm & bit \? c : -1n - c; }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str117, 32, "(a) => (b) => Math.fround(a + b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str118, 32, "(a) => (b) => Math.fround(a - b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str119, 32, "(a) => (b) => Math.fround(a * b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str120, 32, "(a) => (b) => Math.fround(a / b)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str121, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str122, 31, "(a) => (b) => a === b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str123, 29, "(a) => (b) => a < b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str124, 30, "(a) => (b) => a <= b \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str125, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str126, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str127, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str128, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str129, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str130, 29, "(a) => Math.fround(Number(a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str131, 17, "(a) => $abandon()");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str132, 32, "(a) => Math.fround(Math.sqrt(a))");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str133, 21, "(a) => Math.fround(a)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str134, 8, "(a) => a");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str135, 54, "(a) => Number.isFinite(a) \? BigInt(Math.floor(a)) : 0n");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str136, 30, "(p) => (k) => $performer(p, k)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str137, 27, "(p) => (k) => $performerAt(");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str138, 7, ", p, k)");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str139, 26, "(a) => (i) => a[Number(i)]");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str140, 37, "(s) => (j) => { const i = Number(j); ");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str141, 2, " }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str142, 32, "{ if (--$fuel < 0) $fuelOut(); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str143, 57, "(n) => { $fuel -= Number(n); if ($fuel < 0) $fuelOut(); }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str144, 3, "{ }");
HEFF_LIT(g_heff_2ecompile_2eprims_2eprimJs_str145, 24, "(c) => { $custody = c; }");
Clo g_heff_2ecompile_2eprims_2eprimJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eprims_2eprimJs_entry, 1, 0};

V g_heff_2ecompile_2eprims_2eprimJs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IntAdd: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str0);
  }
  case TAG_IntSub: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str1);
  }
  case TAG_IntMul: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str2);
  }
  case TAG_IntDiv: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str3);
  }
  case TAG_IntMod: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str4);
  }
  case TAG_IntEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str5);
  }
  case TAG_IntLt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str6);
  }
  case TAG_IntLe: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str7);
  }
  case TAG_IntShow: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str8);
  }
  case TAG_IntAnd: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str9);
  }
  case TAG_IntOr: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str10);
  }
  case TAG_IntXor: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str11);
  }
  case TAG_IntShl: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str12);
  }
  case TAG_IntShr: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str13);
  }
  case TAG_FloatAdd: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str14);
  }
  case TAG_FloatSub: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str15);
  }
  case TAG_FloatMul: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str16);
  }
  case TAG_FloatDiv: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str17);
  }
  case TAG_FloatEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str18);
  }
  case TAG_FloatLt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str19);
  }
  case TAG_FloatLe: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str20);
  }
  case TAG_FloatShow: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str21), heff_dup(g_heff_2ecompile_2eprims_2eliteralJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str22));
  }
  case TAG_FloatFromInt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str23);
  }
  case TAG_FloatSqrt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str24);
  }
  case TAG_OnWindows: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str25);
  }
  case TAG_FloatFloor: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str26);
  }
  case TAG_FloatSin: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str27);
  }
  case TAG_FloatCos: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str28);
  }
  case TAG_FloatTan: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str29);
  }
  case TAG_FloatAsin: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str30);
  }
  case TAG_FloatAcos: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str31);
  }
  case TAG_FloatAtan: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str32);
  }
  case TAG_FloatAtan2: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str33);
  }
  case TAG_FloatExp: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str34);
  }
  case TAG_FloatLog: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str35);
  }
  case TAG_FloatPow: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str36);
  }
  case TAG_ArrayLength: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str37);
  }
  case TAG_ArrayIndex: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str38);
  }
  case TAG_ArraySet: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str39);
  }
  case TAG_ArrayGenerate: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str40);
  }
  case TAG_ArrayFromList: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str41);
  }
  case TAG_ArrayToList: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str42);
  }
  case TAG_ArrayReplicate: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str43);
  }
  case TAG_ArraySlice: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str44);
  }
  case TAG_ArrayAppend: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str45);
  }
  case TAG_ArrayInsertAt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str46);
  }
  case TAG_ArrayRemoveAt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str47);
  }
  case TAG_ArrayPush: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str48);
  }
  case TAG_ArrayReserve: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str49);
  }
  case TAG_Hole: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str50);
  }
  case TAG_SetField: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str51);
  }
  case TAG_StrAppend: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str52);
  }
  case TAG_StrLength: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str53);
  }
  case TAG_StrSlice: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str54);
  }
  case TAG_StrEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str55);
  }
  case TAG_StrLt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str56);
  }
  case TAG_StrCompare: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str57);
  }
  case TAG_StrFind: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str58);
  }
  case TAG_RuneEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str59);
  }
  case TAG_RuneLt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str60);
  }
  case TAG_RuneLe: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str61);
  }
  case TAG_RuneToInt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str62);
  }
  case TAG_RuneFromInt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str63);
  }
  case TAG_Keep: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str64);
  }
  case TAG_Panic: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str65);
  }
  case TAG_StrByteAt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str66);
  }
  case TAG_StrFromByte: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str67);
  }
  case TAG_StrRuneAt: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str68), heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str69));
  }
  case TAG_StrRuneWidth: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str70), heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str71));
  }
  case TAG_StrRuneCount: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str72), heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str73));
  }
  case TAG_StrRunes: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str74), heff_dup(g_heff_2ecompile_2eprims_2eutf8AtJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str75));
  }
  case TAG_StrOfRunes: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str76);
  }
  case TAG_StrToJS: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str77);
  }
  case TAG_StrFromJS: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str78);
  }
  case TAG_BytesLength: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str79);
  }
  case TAG_BytesAt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str80);
  }
  case TAG_BytesSlice: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str81);
  }
  case TAG_BytesAppend: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str82);
  }
  case TAG_BytesConcat: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str83);
  }
  case TAG_BytesEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str84);
  }
  case TAG_BytesFromList: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str85);
  }
  case TAG_BytesToList: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str86);
  }
  case TAG_BytesFromString: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str87);
  }
  case TAG_BytesAsString: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str88);
  }
  case TAG_BytesToString: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str89);
  }
  case TAG_BytesIntAt: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str90), heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str91));
  }
  case TAG_BytesOfInt: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str92), heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str93));
  }
  case TAG_BytesHasAt: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str94);
  }
  case TAG_BytesFind: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str95);
  }
  case TAG_BitsLength: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str96);
  }
  case TAG_BitsIntAt: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str97), heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str98));
  }
  case TAG_BitsOfInt: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str99), heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str100));
  }
  case TAG_BitsConcat: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str101), heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str102));
  }
  case TAG_BitsSlice: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str103), heff_dup(g_heff_2ecompile_2eprims_2ebitsJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str104));
  }
  case TAG_BitsOfBytes: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str105);
  }
  case TAG_BitsBytes: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str106);
  }
  case TAG_BitsEq: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str107);
  }
  case TAG_FloatBits: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str108);
  }
  case TAG_FloatOfBits: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str109);
  }
  case TAG_FloatOfDecimal: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str110);
  }
  case TAG_StrHash: {
    return heff_dup(g_heff_2ecompile_2eprims_2estrHashJs_get());
  }
  case TAG_StrHashRange: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str111), heff_dup(g_heff_2ecompile_2eprims_2estrHashJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str112));
  }
  case TAG_StrEqRange: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str113);
  }
  case TAG_IntHash: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str114), heff_dup(g_heff_2ecompile_2eprims_2efmixJs_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str115));
  }
  case TAG_TrieSlot: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str116);
  }
  case TAG_OfFixed: {
    V v_w_241 = heff_field(v_x1_240, 0);
    V v_op_242 = heff_field(v_x1_240, 1);
    V v_p_243 = heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_w_241), heff_dup(v_op_242)});
    V v_fixed_244 = heff_take_field(v_p_243, 0);
    V v_op_245 = heff_get_n(v_p_243, 1, 2);
    V v_t_246 = heff_dup(v_fixed_244);
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_I8: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_I16: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_I32: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_I64: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_U8: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_U16: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_U32: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_U64: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_F32: {
      v_t_247 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_fixed_244);
      heff_drop(v_t_247);
      V v_t_248 = v_op_245;
      switch (heff_tag_of(v_t_248)) {
      case TAG_OpAdd: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str117);
      }
      case TAG_OpSub: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str118);
      }
      case TAG_OpMul: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str119);
      }
      case TAG_OpDiv: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str120);
      }
      case TAG_OpRem: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str121);
      }
      case TAG_OpEq: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str122);
      }
      case TAG_OpLt: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str123);
      }
      case TAG_OpLe: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str124);
      }
      case TAG_OpAnd: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str125);
      }
      case TAG_OpOr: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str126);
      }
      case TAG_OpXor: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str127);
      }
      case TAG_OpShl: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str128);
      }
      case TAG_OpShr: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str129);
      }
      case TAG_OpShow: {
        return heff_dup(g_heff_2ecompile_2eprims_2efloat32ShowJs_get());
      }
      case TAG_OpFromInt: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str130);
      }
      case TAG_OpToInt: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str131);
      }
      case TAG_OpSqrt: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str132);
      }
      case TAG_OpFromFloat: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str133);
      }
      case TAG_OpToFloat: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str134);
      }
      case TAG_OpFloor: {
        return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str135);
      }
      default: return heff_nomatch(v_t_248);
      }
    } else {
      heff_drop(v_t_247);
      return ({ V a_0 = v_fixed_244; V a_1 = v_op_245; V r_ = (g_heff_2ecompile_2eprims_2eintOpJs(a_0, a_1)); heff_drop(v_fixed_244); heff_drop(v_op_245); r_; });
    }
  }
  case TAG_Perform: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str136);
  }
  case TAG_PerformAt: {
    V v_i_249 = heff_field(v_x1_240, 0);
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str137), heff_intShow(heff_dup(v_i_249)));
    return heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eprims_2eprimJs_str138));
  }
  case TAG_BocWhen: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_BocNew: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_BocTaken: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_BocGiven: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordAdd: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordSub: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordMul: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordDiv: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordMod: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordQuot: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordRem: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordEq: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordLt: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordLe: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_WordToFloat: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_ArrayIndexIn: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str139);
  }
  case TAG_ArrayIndexInAny: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_ArrayPeek: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_ArrayPeekIn: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_ArraySetOwned: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_ArraySetOwnedIn: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_ArrayOwn: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_ArrayKeeps: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_ArrayKeepsAs: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_Reuse: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_SetFieldPeek: {
    return heff_dup(g_heff_2ecompile_2eprims_2ecOnly_get());
  }
  case TAG_StrRuneDecode: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eprims_2eprimJs_str140), heff_dup(g_heff_2ecompile_2eprims_2eutf8Decode_24s556491502x153787454_get())), ((V)&g_heff_2ecompile_2eprims_2eprimJs_str141));
  }
  case TAG_FuelTick: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str142);
  }
  case TAG_FuelTicks: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str143);
  }
  case TAG_CustodianDue: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str144);
  }
  case TAG_CustodyIn: {
    return ((V)&g_heff_2ecompile_2eprims_2eprimJs_str145);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eprims_2eprimJs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eprims_2eprimJs(a0); heff_drop(a0); return r;
}
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2ejsPrims_lit0, TAG_Cons, 2, NTAG(TAG_ArrayIndexIn), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2ejsPrims_lit1, TAG_Cons, 2, NTAG(TAG_CustodyIn), ((V)&g_heff_2ecompile_2eprims_2ejsPrims_lit0));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2ejsPrims_lit2, TAG_Cons, 2, NTAG(TAG_CustodianDue), ((V)&g_heff_2ecompile_2eprims_2ejsPrims_lit1));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2ejsPrims_lit3, TAG_Cons, 2, NTAG(TAG_FuelTicks), ((V)&g_heff_2ecompile_2eprims_2ejsPrims_lit2));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2ejsPrims_lit4, TAG_Cons, 2, NTAG(TAG_FuelTick), ((V)&g_heff_2ecompile_2eprims_2ejsPrims_lit3));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2ejsPrims_lit5, TAG_Cons, 2, NTAG(TAG_StrRuneDecode), ((V)&g_heff_2ecompile_2eprims_2ejsPrims_lit4));
HEFF_TAG_LIT(g_heff_2ecompile_2eprims_2ejsPrims_lit_v_t_246, TAG_Cons, 2, NTAG(TAG_Perform), ((V)&g_heff_2ecompile_2eprims_2ejsPrims_lit5));

static V g_heff_2ecompile_2eprims_2ejsPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eprims_2ejsPrims_st;
static V g_heff_2ecompile_2eprims_2ejsPrims_init(void) {
  V v_t_246 = ((V)&g_heff_2ecompile_2eprims_2ejsPrims_lit_v_t_246);
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2eelab_2eprimitive_2elibraryPrims_get()), v_t_246));
}
V g_heff_2ecompile_2eprims_2ejsPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eprims_2ejsPrims_st)) return g_heff_2ecompile_2eprims_2ejsPrims_val;
  return heff_global(&g_heff_2ecompile_2eprims_2ejsPrims_val, &g_heff_2ecompile_2eprims_2ejsPrims_st, g_heff_2ecompile_2eprims_2ejsPrims_init);
}