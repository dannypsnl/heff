// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FailBecause 16014
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepV 61860
#define TAG_SetField 47531
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_discarded 1490202606
#define LBL_e 319
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_failure 1292767177
#define LBL_field 298786068
#define LBL_fld 311000
#define LBL_goldens 436112074
#define LBL_hidden 729654485
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_labels 836724522
#define LBL_leaves 840404935
#define LBL_library 398066429
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_property 1899481104
#define LBL_rest 9992347
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_short 310771862
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tighter 1059982480
#define LBL_ty 10476
#define LBL_underLam 296337946
#define LBL_value 313331083
#define LBL_var 326049
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__arity__at__rest[] = {LBL_key, LBL_arity, LBL_at, LBL_rest};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_keys__defs[] = {LBL_keys, LBL_defs};
static uint32_t shape_module__code__msg__note[] = {LBL_module, LBL_code, LBL_msg, LBL_note};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_var__fld__leaves[] = {LBL_var, LBL_fld, LBL_leaves};
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
HeffT2 g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(V, V, V, V);
V g_heff_2ecompile_2ebounds_2eownedSt(V);
V g_heff_2ecompile_2ebounds_2eownedSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eownedSt_clo;
V g_heff_2ecompile_2ecpr_2efldAt(V, V);
V g_heff_2ecompile_2ecpr_2efldAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2efldAt_clo;
V g_heff_2ecompile_2efuse_2epathCalls(V, V);
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2epathCalls_clo;
V g_heff_2ecompile_2efuse_2eselfOut(V, V);
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2esimplify_2evalueTag(V);
V g_heff_2ecompile_2esimplify_2evalueTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evalueTag_clo;
V g_heff_2ecompile_2eworlds_2efloatAll(V, V, V);
V g_heff_2ecompile_2eworlds_2efloatAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2efloatAll_clo;
V g_heff_2ecompile_2eworlds_2ereplaced(V, V);
V g_heff_2ecompile_2eworlds_2ereplaced_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2ereplaced_clo;
V g_heff_2ecompile_2eworlds_2eworldsIn(V, V);
V g_heff_2ecompile_2eworlds_2eworldsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2eworldsIn_clo;
V g_heff_2eelab_2efixed_2efloat32Ops_get(void);
V g_heff_2eelab_2efixed_2eintOps_get(void);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1011930416x23610018(V, V);
V g_list_2eany_24s1011930416x23610018_entry(V self, V *a);
extern Clo g_list_2eany_24s1011930416x23610018_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s1968468648x2095421717(V, V, V, V, V, V, V);
V g_list_2eany_24s1968468648x2095421717_entry(V self, V *a);
extern Clo g_list_2eany_24s1968468648x2095421717_clo;
V g_list_2eany_24s357349853x1862456690(V, V);
V g_list_2eany_24s357349853x1862456690_entry(V self, V *a);
extern Clo g_list_2eany_24s357349853x1862456690_clo;
V g_list_2eany_24s415398368x1824706470(V);
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a);
extern Clo g_list_2eany_24s415398368x1824706470_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2eany_24s944501138x775098345(V, V);
V g_list_2eany_24s944501138x775098345_entry(V self, V *a);
extern Clo g_list_2eany_24s944501138x775098345_clo;
V g_list_2eany_24s949890700x388707860(V);
V g_list_2eany_24s949890700x388707860_entry(V self, V *a);
extern Clo g_list_2eany_24s949890700x388707860_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V, V);
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24s1318914558x1386196507(V, V);
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1318914558x1386196507_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1513798766x1460159176_24scalars(V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1513798766x1460159176_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513798766x1460159176_24scalars_clo;
V g_list_2efoldl_24s1870413144x1677052540(V, V);
V g_list_2efoldl_24s1870413144x1677052540_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1870413144x1677052540_clo;
V g_list_2efoldl_24s199835065x1975386105(V, V);
V g_list_2efoldl_24s199835065x1975386105_entry(V self, V *a);
extern Clo g_list_2efoldl_24s199835065x1975386105_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s2027973668x1165178200(V, V);
V g_list_2efoldl_24s2027973668x1165178200_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2027973668x1165178200_clo;
V g_list_2efoldl_24s278088687x1269971185(V, V);
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s278088687x1269971185_clo;
V g_list_2efoldl_24s370525507x1787909101(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s370525507x1787909101_entry(V self, V *a);
extern Clo g_list_2efoldl_24s370525507x1787909101_clo;
V g_list_2efoldl_24s619143909x1041174639(V, V, V);
V g_list_2efoldl_24s619143909x1041174639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s619143909x1041174639_clo;
V g_list_2efoldl_24s644510009x1719377493(V, V);
V g_list_2efoldl_24s644510009x1719377493_entry(V self, V *a);
extern Clo g_list_2efoldl_24s644510009x1719377493_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1950790755x1251737354(V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_clo;
V g_list_2ekeepIf_24s1950790755x1251737354_24dps(V, V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_24dps_clo;
V g_list_2ekeepIf_24s2053104128x1598844325_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_24dps_clo;
V g_list_2emap_24dps(V, V, V);
V g_list_2emap_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24dps_clo;
V g_list_2emap_24f1524014098x1956473147_24dps(V, V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_24dps_clo;
V g_list_2emap_24f525774350x554415833(V, V, V, V, V);
V g_list_2emap_24f525774350x554415833_entry(V self, V *a);
extern Clo g_list_2emap_24f525774350x554415833_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1009200955x251267316_24dps(V, V);
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_24dps_clo;
V g_list_2emap_24s1099021180x1702355548(V, V);
V g_list_2emap_24s1099021180x1702355548_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_clo;
V g_list_2emap_24s1099021180x1702355548_24dps(V, V, V);
V g_list_2emap_24s1099021180x1702355548_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_24dps_clo;
V g_list_2emap_24s130357166x1398406834(V);
V g_list_2emap_24s130357166x1398406834_entry(V self, V *a);
extern Clo g_list_2emap_24s130357166x1398406834_clo;
V g_list_2emap_24s130357166x1398406834_24dps(V, V);
V g_list_2emap_24s130357166x1398406834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s130357166x1398406834_24dps_clo;
V g_list_2emap_24s158244903x55062455_24dps(V, V);
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_24dps_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24s159228909x554161698_24dps(V, V, V, V, V);
V g_list_2emap_24s159228909x554161698_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_24dps_clo;
V g_list_2emap_24s1817208647x1282894070_24dps(V, V);
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_24dps_clo;
V g_list_2emap_24s1947501783x1475115781_24dps(V, V, V, V);
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_24dps_clo;
V g_list_2emap_24s2015709068x2065046486_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_24dps_clo;
V g_list_2emap_24s214260857x938990544(V);
V g_list_2emap_24s214260857x938990544_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_clo;
V g_list_2emap_24s214260857x938990544_24dps(V, V);
V g_list_2emap_24s214260857x938990544_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s249042484x1701682908_24dps(V, V);
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_24dps_clo;
V g_list_2emap_24s418652630x628827683(V);
V g_list_2emap_24s418652630x628827683_entry(V self, V *a);
extern Clo g_list_2emap_24s418652630x628827683_clo;
V g_list_2emap_24s418652630x628827683_24dps(V, V);
V g_list_2emap_24s418652630x628827683_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s418652630x628827683_24dps_clo;
V g_list_2emap_24s570961906x1112476114(V);
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_clo;
V g_list_2emap_24s570961906x1112476114_24dps(V, V);
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_24dps_clo;
V g_list_2emap_24s866308031x234213482(V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_clo;
V g_list_2emap_24s866308031x234213482_24dps(V, V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_24dps_clo;
V g_list_2emap_24s930532762x1764747629(V, V);
V g_list_2emap_24s930532762x1764747629_entry(V self, V *a);
extern Clo g_list_2emap_24s930532762x1764747629_clo;
V g_list_2emap_24s930532762x1764747629_24dps(V, V, V);
V g_list_2emap_24s930532762x1764747629_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s930532762x1764747629_24dps_clo;
V g_list_2ezipWith_24s1261798533x517442282_24dps(V, V, V);
V g_list_2ezipWith_24s1261798533x517442282_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1261798533x517442282_24dps_clo;
V g_list_2ezipWith_24s151204990x680105425(V, V);
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_clo;
V g_list_2ezipWith_24s151204990x680105425_24dps(V, V, V);
V g_list_2ezipWith_24s151204990x680105425_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s151204990x680105425_24dps_clo;
V g_list_2ezipWith_24s1530546918x299821644_24dps(V, V, V);
V g_list_2ezipWith_24s1530546918x299821644_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1530546918x299821644_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1206589350x791019229(V, V, V);
V g_prelude_2e_2b_2b_24f1206589350x791019229_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1206589350x791019229_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240(V);
V g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_list_2emap_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24dps_entry, 3, 0};

V g_list_2emap_24dps(V v_f_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_f_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_247;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1370882877x364361272_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1370882877x364361272_entry, 2, 0};

V g_list_2efoldl_24s1370882877x364361272(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V t_0 = heff_tag_re_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1370882877x364361272(a[0], a[1]);
}
Clo g_list_2efoldl_24s199835065x1975386105_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s199835065x1975386105_entry, 2, 0};

V g_list_2efoldl_24s199835065x1975386105(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244;
    switch (heff_tag_of(v_x_242)) {
    case TAG_I8: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I16: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_I64: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U8: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U16: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_U64: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2eintOps_get());
      break;
    }
    case TAG_F32: {
      v_t_244 = heff_dup(g_heff_2eelab_2efixed_2efloat32Ops_get());
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_245 = (g_prelude_2e_2b_2b_24f1206589350x791019229(v_z_240, heff_dup(v_x_242), v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s199835065x1975386105_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s199835065x1975386105(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s619143909x1041174639_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s619143909x1041174639_entry, 3, 0};

V g_list_2efoldl_24s619143909x1041174639(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_241, v_x_243, v_lit_240));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s619143909x1041174639_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s619143909x1041174639(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2eany_24s688114072x773797180_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s688114072x773797180_entry, 2, 0};

V g_list_2eany_24s688114072x773797180(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_x_242, v_lit_240, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s688114072x773797180_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s688114072x773797180(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s158244903x55062455_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s158244903x55062455_24dps_entry, 2, 0};

V g_list_2emap_24s158244903x55062455_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x_242_24At, v_a_245, v_a_244));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
    V t_0 = v_xs_243;
    V t_1 = v_u_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s158244903x55062455_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s249042484x1701682908_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s249042484x1701682908_entry, 1, 0};

V g_list_2emap_24s249042484x1701682908(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2415;
      switch (heff_tag_of(v_a_243)) {
      case TAG_SetField: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24SetField = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_249, v_a_248));
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2415 = heff_tag_re_n(v_ru_24a_243_24SetField, TAG_SetField, 3, 3ULL, (V[]){v_a_245, v_a_246, v_t_2410});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2411 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadFieldSet = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_a_2411)) {
        case TAG_At: {
          V v_a_2412 = heff_field(v_a_2411, 0);
          V v_a_2413 = heff_field(v_a_2411, 1);
          heff_take_n(v_a_2411, 3ULL, 2);
          v_t_2414 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2413, v_a_2412));
          break;
        }
        default: heff_nomatch(v_a_2411);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24a_243_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2414});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2416 = heff_tag_re_n(v_ru_24x_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_2415, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24s249042484x1701682908_24dps(v_xs_242, v_cell_2417));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s249042484x1701682908(a[0]);
}
Clo g_list_2ekeepIf_24s2053104128x1598844325_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2053104128x1598844325_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s2053104128x1598844325_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(v_lit_240, heff_dup(v_lit_241), heff_rfield(v_x_245, 1)));
    V v_a_248 = heff_bool(heff_intEq_c_lent(v_t_247, v_lit_242, 0));
    heff_drop(v_t_247);
    if (!(heff_dup(v_a_248) == NTAG(TAG_True))) {
      heff_drop(v_a_248);
      V v_cell_249 = heff_tag_re_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
      V v_u_2410 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_u_2410;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_rec(v_x_245, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_a_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s2053104128x1598844325_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2ekeepIf_24s2053104128x1598844325_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2emap_24s418652630x628827683_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s418652630x628827683_entry, 1, 0};

V g_list_2emap_24s418652630x628827683(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2442;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 4);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2443 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2442, heff_hole()});
    V v_u_2444 = (g_list_2emap_24s418652630x628827683_24dps(v_xs_242, v_cell_2443));
    heff_drop(v_u_2444);
    return v_cell_2443;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s418652630x628827683_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s418652630x628827683(a[0]);
}
Clo g_list_2eany_24s415398368x1824706470_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s415398368x1824706470_entry, 1, 0};

V g_list_2eany_24s415398368x1824706470(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2442;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EMatch: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_t_2442);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2442);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s415398368x1824706470_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s415398368x1824706470(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s949890700x388707860_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s949890700x388707860_entry, 1, 0};

V g_list_2eany_24s949890700x388707860(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2evalueTag(heff_dup(v_x_241)));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s949890700x388707860_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s949890700x388707860(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1318914558x1386196507_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1318914558x1386196507_entry, 2, 0};

V g_list_2efoldl_24s1318914558x1386196507(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_a_246)));
      v_t_248 = (g_list_2efoldl_24s2003609603x1707519208(v_z_240, v_t_247));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1318914558x1386196507_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1318914558x1386196507(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s910662703x1730636603_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s910662703x1730636603_entry, 1, 0};

V g_list_2eany_24s910662703x1730636603(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x_243 = heff_field(v_x_241, 0);
      v_t_245 = heff_dup(v_x_243);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s910662703x1730636603(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s357349853x1862456690_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s357349853x1862456690_entry, 2, 0};

V g_list_2eany_24s357349853x1862456690(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_x_244 = heff_dup(v_lit_240);
    V v_x2_245 = heff_dup(v_x_242);
    V v_t_2492;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_RLocal: {
      V v_y_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      v_t_2492 = heff_bool(heff_strEq_c_lent(v_x_244, v_y_246, 0));
      heff_drop(v_x_244);
      heff_drop(v_y_246);
      break;
    }
    case TAG_RDup: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RClo: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RGet: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetRaw: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RInt: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RFloat: {
      heff_take_na(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RStr: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RBytes: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RFixed: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RF32: {
      heff_take_na(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RNTag: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RStatic: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RTag: {
      heff_take_n(v_x2_245, 0ULL, 3);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RTagIn: {
      heff_take_n(v_x2_245, 0ULL, 5);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RRec: {
      heff_take_n(v_x2_245, 0ULL, 3);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RRecIn: {
      heff_take_n(v_x2_245, 0ULL, 8);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RField: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RDupE: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RFieldV: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetN: {
      heff_take_n(v_x2_245, 0ULL, 3);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RFieldU: {
      heff_take_n(v_x2_245, 0ULL, 4);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetNU: {
      heff_take_n(v_x2_245, 0ULL, 5);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RWord: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RTakeField: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetLabel: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimFn: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrim: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RLam: {
      heff_take_n(v_x2_245, 0ULL, 4);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RCall: {
      heff_take_n(v_x2_245, 0ULL, 4);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RApply: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RBool: {
      heff_take_n(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RAbandon: {
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RBox: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RUnbox: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RPeek: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimU: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimAt: {
      heff_take_n(v_x2_245, 0ULL, 3);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RFixU: {
      heff_take_n(v_x2_245, 0ULL, 2);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RF32U: {
      heff_take_na(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    case TAG_RF64U: {
      heff_take_na(v_x2_245, 0ULL, 1);
      heff_drop(v_x_244);
      v_t_2492 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
      heff_drop(v_t_2492);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2492);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s357349853x1862456690_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s357349853x1862456690(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2027973668x1165178200_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2027973668x1165178200_entry, 2, 0};

V g_list_2efoldl_24s2027973668x1165178200(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2ebounds_2eownedSt(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2027973668x1165178200_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2027973668x1165178200(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1530546918x299821644_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1530546918x299821644_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1530546918x299821644_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2ecpr_2efldAt(v_x_243, v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1530546918x299821644_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s1530546918x299821644_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ezipWith_24s1261798533x517442282_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1261798533x517442282_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1261798533x517442282_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_y_245)) {
      case TAG_MkPair: {
        V v_f_247 = heff_field(v_y_245, 0);
        V v_xs_248 = heff_field(v_y_245, 1);
        heff_take_n(v_y_245, 3ULL, 2);
        v_t_249 = heff_rec_n(3, shape_var__fld__leaves, (V[]){v_x_243, v_f_247, v_xs_248});
        break;
      }
      default: heff_nomatch(v_y_245);
      }
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_2411;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1261798533x517442282_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s1261798533x517442282_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s278088687x1269971185_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s278088687x1269971185_entry, 2, 0};

V g_list_2efoldl_24s278088687x1269971185(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_x_242, NTAG(TAG_MkUnit)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s278088687x1269971185_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s278088687x1269971185(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1947501783x1475115781_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1947501783x1475115781_24dps_entry, 4, 0};

V g_list_2emap_24s1947501783x1475115781_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_intSub(heff_intSub_lent(v_lit_240, v_x_244, 2), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1947501783x1475115781_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2emap_24s1947501783x1475115781_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2emap_24s866308031x234213482_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s866308031x234213482_entry, 5, 0};

V g_list_2emap_24s866308031x234213482(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_key_247 = heff_dup(v_lit_240);
    V v_n_248 = heff_dup(v_lit_241);
    V v_at_249 = heff_dup(v_lit_242);
    V v_l_2410 = heff_dup(v_lit_243);
    V v_x5_2411 = v_x_245;
    V v_t_2437;
    switch (heff_tag_of(v_x5_2411)) {
    case TAG_MkArm: {
      V v_vs_2413 = heff_field(v_x5_2411, 1);
      V v_b_2414 = heff_field(v_x5_2411, 2);
      heff_take_n(v_x5_2411, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_2414), NTAG(TAG_Nil)});
      V v_t_2416 = (g_heff_2ecompile_2eir_2ecountW(v_l_2410, MK_INT(0LL), v_t_2415));
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2414), NTAG(TAG_Nil)});
      V v_t_2418 = ({ V a_0 = v_l_2410; V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_l_2410); r_; });
      V v_x_2419 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2416, v_t_2418}), 0, 2);
      if (heff_intLt_c(MK_INT(0LL), v_x_2419)) {
        heff_drop(v_key_247);
        heff_drop(v_n_248);
        heff_drop(v_at_249);
        heff_drop(v_vs_2413);
        heff_drop(v_b_2414);
        v_t_2437 = NTAG(TAG_Nothing);
      } else {
        V v_t_2420 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2414)));
        V v_xs_2421 = (g_heff_2ecompile_2eir_2enubI(v_t_2420));
        V v_x1_2422 = ({ V a_0 = v_key_247; V a_1 = v_xs_2421; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2421); r_; });
        if (!(heff_dup(v_x1_2422) == NTAG(TAG_True))) {
          heff_drop(v_key_247);
          heff_drop(v_n_248);
          heff_drop(v_at_249);
          heff_drop(v_vs_2413);
          heff_drop(v_b_2414);
          heff_drop(v_x1_2422);
          v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
        } else {
          heff_drop(v_x1_2422);
          V v_x1_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2413));
          switch (heff_tag_of(v_x1_2423)) {
          case TAG_Nil: {
            heff_drop(v_key_247);
            heff_drop(v_n_248);
            heff_drop(v_at_249);
            heff_drop(v_b_2414);
            v_t_2437 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_x_2424 = heff_field(v_x1_2423, 0);
            V v_ru_24x1_2423_24Cons = heff_take_reuse_n(v_x1_2423, 1ULL, 2);
            V v_me_2426 = heff_rec_n(4, shape_key__arity__at__rest, (V[]){v_key_247, v_n_248, v_at_249, v_x_2424});
            V v_b_2427 = v_b_2414;
            V v_it_2428 = heff_tr(g_heff_2ecompile_2efuse_2epathCalls(v_me_2426, heff_dup(v_b_2427)));
            switch (heff_tag_of(v_it_2428)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x1_2423_24Cons, 2);
              heff_drop_rec(v_me_2426, 4);
              heff_drop(v_b_2427);
              v_t_2437 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_it1_2429 = heff_field(v_it_2428, 0);
              V v_ru_24it_2428_24Just = heff_take_reuse_n(v_it_2428, 1ULL, 1);
              if (heff_intEq_c(v_it1_2429, MK_INT(1LL))) {
                V v_x_2430 = heff_dup(heff_rfield(v_me_2426, 3));
                V v_e_2431 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_2426, v_b_2427));
                V v_t_2432 = heff_tag_at_n(v_ru_24x1_2423_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_e_2431), NTAG(TAG_Nil)});
                V v_t_2433 = (g_heff_2ecompile_2eir_2ecountW(v_x_2430, MK_INT(0LL), v_t_2432));
                V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2431, NTAG(TAG_Nil)});
                V v_t_2435 = ({ V a_0 = v_x_2430; V a_1 = v_t_2434; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2430); r_; });
                V v_x_2436 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2433, v_t_2435}), 0, 2);
                if (heff_intLt_c(MK_INT(0LL), v_x_2436)) {
                  heff_drop_cell(v_ru_24it_2428_24Just, 1);
                  v_t_2437 = NTAG(TAG_Nothing);
                } else {
                  v_t_2437 = heff_tag_at_n(v_ru_24it_2428_24Just, TAG_Just, 1, (V[]){NTAG(TAG_True)});
                }
              } else {
                heff_drop_cell(v_ru_24x1_2423_24Cons, 2);
                heff_drop_rec(v_me_2426, 4);
                heff_drop(v_b_2427);
                heff_drop_cell(v_ru_24it_2428_24Just, 1);
                v_t_2437 = NTAG(TAG_Nothing);
              }
              break;
            }
            default: heff_nomatch(v_it_2428);
            }
            break;
          }
          default: heff_nomatch(v_x1_2423);
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x5_2411);
    }
    V v_cell_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_hole()});
    V v_u_2439 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_xs_246; V a_5 = v_cell_2438; V r_ = (g_list_2emap_24s866308031x234213482_24dps(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); heff_drop(v_lit_243); r_; });
    heff_drop(v_u_2439);
    return v_cell_2438;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s866308031x234213482_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s866308031x234213482(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24s1870413144x1677052540_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1870413144x1677052540_entry, 2, 0};

V g_list_2efoldl_24s1870413144x1677052540(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_e_244 = v_x_242;
    V v_t_2445;
    switch (heff_tag_of(v_e_244)) {
    case TAG_EVar: {
      heff_take_n(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_e_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_e_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_e_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_e_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_e_244, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_e_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_e_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      V v_g_2428 = heff_field(v_e_244, 0);
      V v_args_2429 = heff_field(v_e_244, 1);
      V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 3ULL, 2);
      V v_t_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2429; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2429); r_; });
      v_t_2445 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_244_24ECall, TAG_MkPair, 2, (V[]){v_g_2428, v_t_2430}), NTAG(TAG_Nil)});
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_e_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_e_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_e_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_e_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2445 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2445, v_z_240));
    V t_0 = v_t_2446;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1870413144x1677052540_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1870413144x1677052540(a[0], a[1]);
}
Clo g_list_2ezipWith_24s151204990x680105425_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s151204990x680105425_entry, 2, 0};

V g_list_2ezipWith_24s151204990x680105425(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_y_244; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_y_244); r_; });
      V v_t_247;
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = v_x_242;
      } else {
        heff_drop(v_x_242);
        heff_drop(v_t_246);
        v_t_247 = NTAG(TAG_RepV);
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s151204990x680105425_24dps(v_xs_243, v_ys_245, v_cell_248));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s151204990x680105425_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s151204990x680105425(a[0], a[1]);
}
Clo g_list_2efoldl_24s644510009x1719377493_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s644510009x1719377493_entry, 2, 0};

V g_list_2efoldl_24s644510009x1719377493(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_d_244 = v_x_242;
    V v_t_245 = (g_heff_2ecompile_2eworlds_2eworldsIn(heff_rfield(v_d_244, 2), NTAG(TAG_Nil)));
    V v_t_246 = heff_rec_n(2, shape_keys__defs, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_fl_247 = ({ V a_0 = heff_rfield(v_d_244, 0); V a_1 = v_t_246; V a_2 = v_t_245; V r_ = (g_heff_2ecompile_2eworlds_2efloatAll(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
    V v_defs_248 = heff_take_field(v_fl_247, 1);
    V v_keys_249 = heff_get_n(v_fl_247, 0, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_248));
    V v_body_2411 = ({ V a_0 = v_keys_249; V a_1 = heff_take_field(v_d_244, 2); V r_ = (g_heff_2ecompile_2eworlds_2ereplaced(a_0, a_1)); heff_drop(v_keys_249); r_; });
    V v_t_2412 = ({ V rv_2 = v_body_2411; V rr_ = heff_rec_reuse_nf(v_d_244, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
    V v_t_2414 = (g_heff_2ecompile_2eir_2eappendI(v_t_2410, v_t_2413));
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s644510009x1719377493_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s644510009x1719377493(a[0], a[1]);
}
Clo g_list_2emap_24s1009200955x251267316_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1009200955x251267316_entry, 1, 0};

V g_list_2emap_24s1009200955x251267316(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_t_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 3);
      v_t_246 = v_t_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1009200955x251267316_24dps(v_xs_242, v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1009200955x251267316(a[0]);
}
Clo g_list_2emap_24s1817208647x1282894070_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1817208647x1282894070_24dps_entry, 2, 0};

V g_list_2emap_24s1817208647x1282894070_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1817208647x1282894070_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1817208647x1282894070_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1513798766x1460159176_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1513798766x1460159176_24scalars_entry, 9, 0};

V g_list_2efoldl_24s1513798766x1460159176_24scalars(V v_order_240, V v_entries_241, V v_aliases_242, V v_broken_243, V v_ambiguous_244, V v_places_245, V v_hidden_246, V v_instances_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nil: {
    return heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){heff_dup(v_order_240), heff_dup(v_entries_241), heff_dup(v_aliases_242), v_broken_243, heff_dup(v_ambiguous_244), heff_dup(v_places_245), heff_dup(v_hidden_246), heff_dup(v_instances_247)});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x3_248, 0);
    V v_xs_2410 = heff_field(v_x3_248, 1);
    V v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_broken_243, v_x_249, NTAG(TAG_MkUnit)));
    V t_0 = v_order_240;
    V t_1 = v_entries_241;
    V t_2 = v_aliases_242;
    V t_3 = v_t_2411;
    V t_4 = v_ambiguous_244;
    V t_5 = v_places_245;
    V t_6 = v_hidden_246;
    V t_7 = v_instances_247;
    V t_8 = v_xs_2410;
    v_order_240 = t_0;
    v_entries_241 = t_1;
    v_aliases_242 = t_2;
    v_broken_243 = t_3;
    v_ambiguous_244 = t_4;
    v_places_245 = t_5;
    v_hidden_246 = t_6;
    v_instances_247 = t_7;
    v_x3_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x3_248);
  }
}
V g_list_2efoldl_24s1513798766x1460159176_24scalars_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V a8 = a[8]; V r = g_list_2efoldl_24s1513798766x1460159176_24scalars(a0, a1, a2, a[3], a4, a5, a6, a7, a8); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); heff_drop(a8); return r;
}
HEFF_LIT(g_list_2emap_24s214260857x938990544_str0, 0, "");
V g_list_2emap_24s214260857x938990544_lam0(V self, V *args); static Clo g_list_2emap_24s214260857x938990544_lam0_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_lam0, 1, 0};
Clo g_list_2emap_24s214260857x938990544_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s214260857x938990544_entry, 1, 0};

V g_list_2emap_24s214260857x938990544(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V rv_4 = ((V)&g_list_2emap_24s214260857x938990544_lam0_clo); V rr_ = heff_rec_reuse_nf(v_x_241, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s214260857x938990544_24dps(v_xs_242, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s214260857x938990544_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s214260857x938990544(a[0]);
}
V g_list_2emap_24s214260857x938990544_lam0(V self, V *args) {
  V v_u_243 = args[0];
  heff_drop(v_u_243);
  return ((V)&g_list_2emap_24s214260857x938990544_str0);
}
HEFF_LIT(g_list_2efoldl_24s370525507x1787909101_str0, 0, "");
HEFF_LIT(g_list_2efoldl_24s370525507x1787909101_str1, 1, "\012");
HEFF_LIT(g_list_2efoldl_24s370525507x1787909101_str2, 1, "\012");
HEFF_LIT(g_list_2efoldl_24s370525507x1787909101_str3, 0, "");
HEFF_LIT(g_list_2efoldl_24s370525507x1787909101_str4, 1, "\012");
HEFF_LIT(g_list_2efoldl_24s370525507x1787909101_str5, 0, "");
HEFF_LIT(g_list_2efoldl_24s370525507x1787909101_str6, 0, "");
Clo g_list_2efoldl_24s370525507x1787909101_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s370525507x1787909101_entry, 8, 0};

V g_list_2efoldl_24s370525507x1787909101(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_z_246, V v_x3_247) {
top: ;
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nil: {
    return v_z_246;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x3_247, 0);
    V v_xs_249 = heff_field(v_x3_247, 1);
    V v_s_2410 = v_z_246;
    V v_from_2411 = heff_dup(heff_rfield(v_x_248, 7));
    V v_to_2412 = heff_dup(heff_rfield(v_x_248, 8));
    V v_t_2413;
    if ((heff_strEq_c(heff_strSlice_lent(v_s_2410, MK_INT(0LL), v_from_2411, 2), ((V)&g_list_2efoldl_24s370525507x1787909101_str0)) ? 0 : !heff_strEq_c(heff_strSlice_lent(v_s_2410, heff_intSub_lent(v_from_2411, MK_INT(1LL), 2), v_from_2411, 2), ((V)&g_list_2efoldl_24s370525507x1787909101_str1)))) {
      v_t_2413 = ((V)&g_list_2efoldl_24s370525507x1787909101_str2);
    } else {
      v_t_2413 = ((V)&g_list_2efoldl_24s370525507x1787909101_str3);
    }
    V v_a_2414 = heff_dup(heff_rfield(v_x_248, 4));
    V v_t_2415 = ({ V a_0 = v_a_2414; V a_1 = v_lit_242; V a_2 = heff_dup(v_lit_243); V a_3 = heff_strFind_lent(v_lit_244, v_a_2414, v_lit_245, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_2414); r_; });
    V v_x2_2416 = (g_list_2emap_24f525774350x554415833(((V)&g_list_2efoldl_24s370525507x1787909101_str4), heff_dup(v_x_248), heff_dup(v_lit_240), heff_dup(v_lit_241), v_t_2415));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_list_2efoldl_24s370525507x1787909101_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_list_2efoldl_24s370525507x1787909101_str6); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2420 = heff_strAppend(heff_strSlice_lent(v_s_2410, MK_INT(0LL), v_from_2411, 6), v_t_2413);
    V v_t_2421 = heff_strSlice(heff_dup(v_s_2410), v_to_2412, heff_strLength(v_s_2410));
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2420, v_t_2419), v_t_2421);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_t_2422;
    V t_7 = v_xs_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_z_246 = t_6;
    v_x3_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_list_2efoldl_24s370525507x1787909101_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a7 = a[7]; V r = g_list_2efoldl_24s370525507x1787909101(a0, a1, a2, a3, a4, a5, a[6], a7); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a7); return r;
}
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str0, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str1, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str2, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str3, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str4, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str5, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str6, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str7, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str8, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str9, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str10, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_str11, 0, "");
Clo g_list_2emap_24s570961906x1112476114_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570961906x1112476114_entry, 1, 0};

V g_list_2emap_24s570961906x1112476114(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_v_243 = v_x_241;
    V v_t_2417;
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_247 = heff_dup(heff_field(v_v_243, 1));
      v_t_2417 = v_vs_247;
      break;
    }
    case TAG_VInt: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_243);
    }
    HeffT3 v_t_2418 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2417; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    {
      V v_field_2420 = v_t_2418.f[1];
      V v_field_2421 = v_t_2418.f[2];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      V v_t_2437;
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_x_2422 = v_field_2420;
        V v_x12_2423 = v_field_2421;
        heff_drop(v_x12_2423);
        switch (heff_tag_of(v_x_2422)) {
        case TAG_VFun: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str0);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str1);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2422, 0ULL, 2);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str2);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str3);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str4);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str5);
          break;
        }
        case TAG_VStr: {
          V v_s_2431 = heff_field(v_x_2422, 0);
          heff_take_n(v_x_2422, 1ULL, 1);
          v_t_2437 = v_s_2431;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str6);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str7);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str8);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2422, 0ULL, 2);
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str9);
          break;
        }
        case TAG_VErased: {
          v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str10);
          break;
        }
        default: heff_nomatch(v_x_2422);
        }
      } else {
        heff_drop(v_field_2420);
        heff_drop(v_field_2421);
        v_t_2437 = ((V)&g_list_2emap_24s570961906x1112476114_str11);
      }
      V v_t_2451;
      switch (heff_tag_of(v_v_243)) {
      case TAG_VFun: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2441 = heff_field(v_v_243, 1);
        heff_take_n(v_v_243, 2ULL, 2);
        v_t_2451 = v_vs_2441;
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take_na(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        heff_take_n(v_v_243, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      HeffT3 v_t_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2451; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2451); r_; });
      {
        V v_field_2454 = v_t_2452.f[1];
        V v_field_2455 = v_t_2452.f[2];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        V v_t_2471;
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          V v_x_2456 = v_field_2454;
          V v_x12_2457 = v_field_2455;
          heff_drop(v_x12_2457);
          switch (heff_tag_of(v_x_2456)) {
          case TAG_VFun: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VTag: {
            heff_take_n(v_x_2456, 0ULL, 2);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VInt: {
            V v_i_2462 = heff_field(v_x_2456, 0);
            heff_take_n(v_x_2456, 1ULL, 1);
            v_t_2471 = v_i_2462;
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VStr: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_2456, 0ULL, 2);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VErased: {
            v_t_2471 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_x_2456);
          }
        } else {
          heff_drop(v_field_2454);
          heff_drop(v_field_2455);
          v_t_2471 = MK_INT(0LL);
        }
        V v_cell_2472 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_t_2471}), heff_hole()});
        V v_u_2473 = (g_list_2emap_24s570961906x1112476114_24dps(v_xs_242, v_cell_2472));
        heff_drop(v_u_2473);
        return v_cell_2472;
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570961906x1112476114(a[0]);
}
Clo g_list_2emap_24s930532762x1764747629_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s930532762x1764747629_entry, 2, 0};

V g_list_2emap_24s930532762x1764747629(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_tighter_244 = heff_take_field(v_x_242, 0);
    V v_looser_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_strAppend(heff_strAppend(v_tighter_244, heff_dup(v_lit_240)), v_looser_245);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_247; V r_ = (g_list_2emap_24s930532762x1764747629_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s930532762x1764747629_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s930532762x1764747629(a[0], a[1]);
}
Clo g_list_2eany_24s1011930416x23610018_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1011930416x23610018_entry, 2, 0};

V g_list_2eany_24s1011930416x23610018(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    V v_a_247 = heff_dup(heff_rfield(v_lit_240, 1));
    V v_start_248 = heff_take_field(v_a_247, 0);
    V v_end_249 = heff_get_n(v_a_247, 1, 2);
    if ((heff_intEq_c_lent(v_start_245, v_start_248, 0) && heff_intEq_c_lent(v_end_246, v_end_249, 0))) {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1011930416x23610018_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1011930416x23610018(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    if ((heff_intEq_c(heff_dup(v_start_245), heff_dup(heff_rfield(v_lit_240, 0))) && heff_intEq_c(heff_dup(v_end_246), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2ekeepIf_24s1950790755x1251737354_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1950790755x1251737354_entry, 2, 0};

V g_list_2ekeepIf_24s1950790755x1251737354(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 0, 2);
    if ((heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_t_244)) && heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_x_242, 2)), 1, 2), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24s1950790755x1251737354_24dps(v_lit_240, v_xs_243, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1950790755x1251737354_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1950790755x1251737354(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str0, 1, " ");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str3, 4, "(set");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str4, 1, ")");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str5, 1, " ");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str6, 0, "");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str7, 0, "");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str8, 4, "(bad");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_str9, 1, ")");
Clo g_list_2emap_24s1099021180x1702355548_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1099021180x1702355548_entry, 2, 0};

V g_list_2emap_24s1099021180x1702355548(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2425;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 1ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_SetField: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_e_2410 = heff_field(v_x21_246, 2);
        heff_take_n(v_x21_246, 5ULL, 3);
        V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2410}));
        V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
        V v_parts_2413 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_x_248, v_t_2412});
        V v_x2_2414 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s1099021180x1702355548_str0), v_parts_2413));
        V v_t_2417;
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_Nil: {
          v_t_2417 = ((V)&g_list_2emap_24s1099021180x1702355548_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_xs_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          v_t_2417 = ({ V a_0 = ((V)&g_list_2emap_24s1099021180x1702355548_str2); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2414);
        }
        v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1099021180x1702355548_str3), v_t_2417), ((V)&g_list_2emap_24s1099021180x1702355548_str4));
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2418 = heff_field(v_x21_246, 0);
        heff_take_n(v_x21_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2418}));
        V v_parts_2420 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
        V v_x2_2421 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s1099021180x1702355548_str5), v_parts_2420));
        V v_t_2424;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_list_2emap_24s1099021180x1702355548_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_xs_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_list_2emap_24s1099021180x1702355548_str7); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1099021180x1702355548_str8), v_t_2424), ((V)&g_list_2emap_24s1099021180x1702355548_str9));
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_2426; V r_ = (g_list_2emap_24s1099021180x1702355548_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_2427);
    return v_cell_2426;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1099021180x1702355548_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1099021180x1702355548(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s159228909x554161698_str0, 4, "std.");
HEFF_LIT(g_list_2emap_24s159228909x554161698_str1, 1, "`");
HEFF_LIT(g_list_2emap_24s159228909x554161698_str2, 81, "` is an effect of the system (lib/std/), for C: it has no provider for --backend=");
HEFF_LIT(g_list_2emap_24s159228909x554161698_str3, 1, "`");
HEFF_LIT(g_list_2emap_24s159228909x554161698_str4, 89, "` is the system's (lib/std/), for C: it imports an effect with no provider for --backend=");
HEFF_LIT(g_list_2emap_24s159228909x554161698_str5, 1, "`");
HEFF_LIT(g_list_2emap_24s159228909x554161698_str6, 19, "` is that effect: `");
HEFF_LIT(g_list_2emap_24s159228909x554161698_str7, 2, "` ");
Clo g_list_2emap_24s159228909x554161698_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s159228909x554161698_entry, 4, 0};

V g_list_2emap_24s159228909x554161698(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_host_246 = heff_dup(v_lit_240);
    V v_sources_247 = heff_dup(v_lit_241);
    V v_only_248 = heff_dup(v_lit_242);
    V v_s_249 = v_x_244;
    V v_t_2434;
    if (((heff_dup(heff_rfield(v_s_249, 7)) == NTAG(TAG_True)) ? !heff_strEq_c(heff_strSlice(heff_dup(heff_rfield(v_s_249, 0)), MK_INT(0LL), MK_INT(4LL)), ((V)&g_list_2emap_24s159228909x554161698_str0)) : 1)) {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_host_246);
      heff_drop(v_sources_247);
      heff_drop(v_only_248);
      heff_drop_rec(v_s_249, 8);
      v_t_2434 = NTAG(TAG_Nothing);
    } else {
      V v_t_2410 = (g_list_2eany_24s1477604419x1568736711(heff_rfield(v_s_249, 0), v_only_248));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_sources_247);
        heff_drop(v_only_248);
        heff_drop(v_t_2410);
        V v_t_2411 = heff_strAppend(((V)&g_list_2emap_24s159228909x554161698_str1), heff_dup(heff_rfield(v_s_249, 0)));
        V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_list_2emap_24s159228909x554161698_str2)), v_host_246);
        V v_t_2413 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_249, 0, 8), MK_INT(352LL), v_t_2412, NTAG(TAG_Nothing)});
        v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
      } else {
        heff_drop(v_t_2410);
        V v_t_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_s_249, 0)), NTAG(TAG_Nil)});
        V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
        HeffT2 v_t_2416 = ({ V a_0 = v_sources_247; V a_1 = v_only_248; V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2415; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2ereachOnly_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_sources_247); heff_drop(v_only_248); r_; });
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x_2419 = v_field_2418;
            V v_host_2420 = v_host_246;
            V v_s_2421 = v_s_249;
            V v_path_2422 = v_x_2419;
            V v_x1_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_path_2422)));
            V v_t_2426;
            switch (heff_tag_of(v_x1_2423)) {
            case TAG_Nil: {
              v_t_2426 = heff_dup(heff_rfield(v_s_2421, 0));
              break;
            }
            case TAG_Cons: {
              V v_x_2424 = heff_field(v_x1_2423, 0);
              heff_take_n(v_x1_2423, 1ULL, 2);
              v_t_2426 = v_x_2424;
              break;
            }
            default: heff_nomatch(v_x1_2423);
            }
            V v_t_2427 = (g_heff_2ebuild_2ecommands_2eimportsOn(v_path_2422));
            V v_t_2428 = heff_strAppend(((V)&g_list_2emap_24s159228909x554161698_str3), heff_dup(heff_rfield(v_s_2421, 0)));
            V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, ((V)&g_list_2emap_24s159228909x554161698_str4)), v_host_2420);
            V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s159228909x554161698_str5), v_t_2426), ((V)&g_list_2emap_24s159228909x554161698_str6));
            V v_t_2431 = heff_strAppend(v_t_2430, heff_dup(heff_rfield(v_s_2421, 0)));
            V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_list_2emap_24s159228909x554161698_str7)), v_t_2427);
            V v_t_2433 = heff_rec_n(4, shape_module__code__msg__note, (V[]){heff_get_n(v_s_2421, 0, 8), MK_INT(352LL), v_t_2429, heff_tag_n(TAG_Just, 1, (V[]){v_t_2432})});
            v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2433});
          } else {
            heff_drop(v_host_246);
            heff_drop_rec(v_s_249, 8);
            heff_drop(v_field_2418);
            v_t_2434 = NTAG(TAG_Nothing);
          }
        }
      }
    }
    V v_cell_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, heff_hole()});
    V v_u_2436 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_245; V a_4 = v_cell_2435; V r_ = (g_list_2emap_24s159228909x554161698_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    heff_drop(v_u_2436);
    return v_cell_2435;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s159228909x554161698_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s159228909x554161698(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s2015709068x2065046486_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2015709068x2065046486_24dps_entry, 8, 0};

V g_list_2emap_24s2015709068x2065046486_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_247), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2413 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(heff_dup(v_lit_243), heff_dup(v_lit_244))});
    V v_t_2414 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_t_2412, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_2413}), heff_dup(v_lit_245), NTAG(TAG_Nil)});
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2415);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_u_2416;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s2015709068x2065046486_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a7 = a[7]; V r = g_list_2emap_24s2015709068x2065046486_24dps(a0, a1, a2, a3, a4, a5, a[6], a7); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a7); return r;
}
Clo g_list_2eany_24s944501138x775098345_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s944501138x775098345_entry, 2, 0};

V g_list_2eany_24s944501138x775098345(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s944501138x775098345_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s944501138x775098345(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1968468648x2095421717_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1968468648x2095421717_entry, 7, 0};

V g_list_2eany_24s1968468648x2095421717(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_long_249 = heff_dup(heff_rfield(v_x_247, 0));
    V v_short_2410 = heff_dup(heff_rfield(v_x_247, 1));
    if ((heff_strEq_c_lent(v_long_249, v_lit_240, 0) || (heff_strEq_c_lent(v_short_2410, v_lit_241, 0) || (heff_strEq_c_lent(v_long_249, v_lit_242, 0) || !heff_intLt_c_lent(heff_strFind_lent(v_lit_243, v_long_249, v_lit_244, 0), v_lit_245, 1))))) {
      heff_drop(v_long_249);
      heff_drop(v_short_2410);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_long_249);
      heff_drop(v_short_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2eany_24s1968468648x2095421717_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V r = g_list_2eany_24s1968468648x2095421717(a0, a1, a2, a3, a4, a5, a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); return r;
}
Clo g_list_2emap_24s130357166x1398406834_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s130357166x1398406834_entry, 1, 0};

V g_list_2emap_24s130357166x1398406834(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_std_2ecli_2einteractive_2eofferedRows_2enameOf_240(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s130357166x1398406834_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s130357166x1398406834_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s130357166x1398406834(a[0]);
}
Clo g_list_2efoldl_24f155552269x628597815_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f155552269x628597815_entry, 3, 0};

V g_list_2efoldl_24f155552269x628597815(V v_z_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x3_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245});
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_xs_244;
      V t_2 = v_ys_246;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f155552269x628597815(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24f1524014098x1956473147_24dps_str0, 8, "browser.");
Clo g_list_2emap_24f1524014098x1956473147_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1524014098x1956473147_24dps_entry, 5, 0};

V g_list_2emap_24f1524014098x1956473147_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_library_247 = heff_take_field(v_x_245, 7);
    V v_module_248 = heff_get_n(v_x_245, 0, 8);
    if (((heff_dup(v_library_247) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice_lent(v_module_248, MK_INT(0LL), MK_INT(8LL), 6), ((V)&g_list_2emap_24f1524014098x1956473147_24dps_str0)))) {
      heff_drop(v_library_247);
      V v_t_249 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), heff_dup(v_module_248)), heff_dup(v_lit_242));
      V v_t_2410 = heff_rec_n(4, shape_module__code__msg__note, (V[]){v_module_248, heff_dup(v_lit_240), v_t_249, NTAG(TAG_Nothing)});
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_u_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_library_247);
      heff_drop(v_module_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1524014098x1956473147_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2emap_24f1524014098x1956473147_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}