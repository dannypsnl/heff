// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_HError 21467
#define TAG_LNil 57394
#define TAG_Left 13886
#define TAG_MkFieldPat 14710
#define TAG_MkSyn 7342
#define TAG_N 306
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_diags 296935042
#define LBL_end 310101
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_name 9869138
#define LBL_prim 9944941
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_unreached 121683306
#define LBL_value 313331083
#define LBL_watches 1357821955
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2erules_2eevidenceGo(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceGo_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(V);
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendM_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendM_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_24tok2_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2eonceEach(V, V);
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eonceEach_clo;
HeffT2 g_heff_2eelab_2etoplevel_2eselfWalk_24cpr(V);
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_clo;
V g_heff_2eelab_2etoplevel_2etopOne(V, V, V);
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_244));
      v_t_246 = heff_bool(!(heff_dup(v_a_245) == NTAG(TAG_True)));
      heff_drop(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_At: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_sp_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_ArgExplicit: {
      V v_c_245 = heff_field(v_x41_243, 0);
      V v_m_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0, 2, 5, (V[]){v_m_246, heff_dup(v_c_245), v_start_240, heff_dup(v_sp_244), heff_dup(v_s_241)});
    }
    case TAG_ArgProject: {
      V v_x_2440 = heff_field(v_x41_243, 0);
      heff_drop(v_start_240);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2, 2, 3, (V[]){heff_dup(v_sp_244), heff_dup(v_s_241), heff_dup(v_x_2440)});
    }
    case TAG_ArgNamed: {
      V v_x_2444 = heff_field(v_x41_243, 0);
      V v_c_2445 = heff_field(v_x41_243, 1);
      V v_m_2446 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2445)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3, 2, 5, (V[]){v_m_2446, heff_dup(v_s_241), v_start_240, heff_dup(v_sp_244), heff_dup(v_x_2444)});
    }
    case TAG_ArgEvidence: {
      V v_x_2460 = heff_field(v_x41_243, 0);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8, 2, 4, (V[]){heff_dup(v_s_241), v_start_240, heff_dup(v_sp_244), heff_dup(v_x_2460)});
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_t_2411 = (g_heff_2eelab_2etoplevel_2echecksOnly(v_c_245));
  V v_t_2437;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_c_245)) {
  case TAG_At: {
    V v_x11_2412 = heff_field(v_c_245, 0);
    heff_take_n(v_c_245, 1ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2412, 0ULL, 4);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2412);
    }
    break;
  }
  default: heff_nomatch(v_c_245);
  }
  V v_t_2438 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2439 = ({ V a_0 = v_t_2411; V a_1 = v_t_2437; V a_2 = v_t_2438; V a_3 = v_s_241; V a_4 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2411); heff_drop(v_t_2437); heff_drop(v_s_241); r_; });
  V f_ = v_k_248;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_m_246 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_s_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_246}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_249, v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1, 1, 5, (V[]){v_c_245, v_start_240, v_sp_244, v_s_241, v_k_248})));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_sp_244 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  heff_drop(v_hd_2441);
  heff_clo_take(self, 3);
  V v_t_2443 = ({ V a_0 = v_sp_244; V a_1 = v_s_241; V a_2 = v_x_2440; V r_ = (g_heff_2eelab_2erules_2erecordElim(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
  V f_ = v_k_2442;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_2444 = heff_env(self)[2];
  V v_x_2450 = heff_env(self)[3];
  V v_e_2451 = heff_env(self)[4];
  V v_hd_2454 = heff_env(self)[5];
  V v_k_2455 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2456)) {
  case TAG_MkPair: {
    V v_ecallee_2457 = heff_field(v_x_2456, 0);
    V v_a0_2458 = heff_field(v_x_2456, 1);
    heff_take_n(v_x_2456, 3ULL, 2);
    heff_clo_take(self, 7);
    V v_t_2459 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ({ V a_0 = v_t_2459; V a_1 = v_x_2444; V a_2 = v_x_2450; V a_3 = v_e_2451; V a_4 = v_ecallee_2457; V a_5 = v_a0_2458; V a_6 = v_hd_2454; V a_7 = v_k_2455; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2450); r_; });
  }
  default: return heff_nomatch(v_x_2456);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_c_2453 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2444 = heff_env(self)[3];
  V v_x_2450 = heff_env(self)[4];
  V v_e_2451 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2453;
  args[0] = heff_dup(v_hd_2454);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7, 1, 7, (V[]){v_start_240, v_sp_244, v_x_2444, v_x_2450, v_e_2451, v_hd_2454, v_k_2455});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args) {
  V v_e_2451 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2444 = heff_env(self)[3];
  V v_x_2450 = heff_env(self)[4];
  V v_c_2453;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_2452 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_2453 = heff_tr(heff_call(v_f_2452, 1, (V[]){heff_dup(v_e_2451)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6, 2, 6, (V[]){v_c_2453, v_start_240, v_sp_244, v_x_2444, v_x_2450, v_e_2451});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2448 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2444 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2448;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5, 1, 5, (V[]){v_s_241, v_start_240, v_sp_244, v_x_2444, v_x_2450})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_m_2446 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2444 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_2446}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_2449, v_hd_2447, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4, 1, 5, (V[]){v_k_2448, v_s_241, v_start_240, v_sp_244, v_x_2444})));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11(V self, V *args) {
  V v_x_2468 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_2460 = heff_env(self)[2];
  V v_e_2463 = heff_env(self)[3];
  V v_hd_2466 = heff_env(self)[4];
  V v_k_2467 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2468)) {
  case TAG_MkPair: {
    V v_ecallee_2469 = heff_field(v_x_2468, 0);
    V v_a0_2470 = heff_field(v_x_2468, 1);
    heff_take_n(v_x_2468, 3ULL, 2);
    heff_clo_take(self, 6);
    V v_t_2471 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_nf(v_sp_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return (g_heff_2eelab_2erules_2eevidenceGo(v_t_2471, v_x_2460, v_e_2463, v_ecallee_2469, v_a0_2470, v_hd_2466, v_k_2467));
  }
  default: return heff_nomatch(v_x_2468);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2460 = heff_env(self)[3];
  V v_e_2463 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2465;
  args[0] = heff_dup(v_hd_2466);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam11, 1, 6, (V[]){v_start_240, v_sp_244, v_x_2460, v_e_2463, v_hd_2466, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9(V self, V *args) {
  V v_e_2463 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2460 = heff_env(self)[3];
  V v_c_2465;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_2464 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_2465 = heff_tr(heff_call(v_f_2464, 1, (V[]){heff_dup(v_e_2463)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam10, 2, 5, (V[]){v_c_2465, v_start_240, v_sp_244, v_x_2460, v_e_2463});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam8(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2460 = heff_env(self)[3];
  heff_drop(v_hd_2461);
  heff_clo_take(self, 4);
  V f_ = v_k_2462;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam9, 1, 4, (V[]){v_s_241, v_start_240, v_sp_244, v_x_2460})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2etoplevel_2eappendM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendM(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = ({ V a_0 = v_xs_243; V a_1 = v_ys_241; V a_2 = v_cell_244; V r_ = (g_heff_2eelab_2etoplevel_2eappendM_24dps(a_0, a_1, a_2)); heff_drop(v_ys_241); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendM_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_24dps_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendM_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eappendM_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2espineVals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2espineVals_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2espineVals(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_e_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_241));
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_e_242, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_243, v_t_244));
  }
  case TAG_SpProj: {
    V v_sp_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V t_0 = v_sp_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_247 = heff_field(v_x1_240, 0);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    V v_t_2410 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_247));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2espineVals(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2etopOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopOne(V v_kf_240, V v_acc_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_n1_243 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_n1_243)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_243, 0ULL, 5);
      V v_t_2410 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), heff_dup(v_n_242), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2410));
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_243, 0ULL, 5);
      V v_t_2416 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), heff_dup(v_n_242), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2416));
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_243, 0ULL, 4);
      V v_t_2421 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), heff_dup(v_n_242), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2421));
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_243, 0ULL, 3);
      V v_t_2425 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), heff_dup(v_n_242), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return (g_heff_2eelab_2etoplevel_2etopTake(v_kf_240, v_acc_241, v_n_242, v_t_2425));
    }
    case TAG_DeclTest: {
      V v_x_2426 = heff_field(v_n1_243, 0);
      V v_ru_24n1_243_24DeclTest = heff_take_reuse_n(v_n1_243, 1ULL, 2);
      heff_drop(v_kf_240);
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_sp_2429 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        V v_keys_2430 = heff_take_field(v_acc_241, 2);
        V v_broken_2431 = heff_take_field(v_acc_241, 3);
        V v_watches_2432 = heff_take_field(v_acc_241, 4);
        V v_t_2433 = heff_take_field(v_acc_241, 5);
        V v_spans_2434 = heff_take_field(v_acc_241, 6);
        V v_infos_2435 = heff_take_field(v_acc_241, 7);
        V v_trace_2436 = heff_take_field(v_acc_241, 8);
        V v_unreached_2437 = heff_take_field(v_acc_241, 9);
        V v_t_2438 = heff_tag_at_n(v_ru_24n1_243_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2426, v_sp_2429}), v_t_2433});
        return ({ V rv_2 = v_keys_2430; V rv_3 = v_broken_2431; V rv_4 = v_watches_2432; V rv_5 = v_t_2438; V rv_6 = v_spans_2434; V rv_7 = v_infos_2435; V rv_8 = v_trace_2436; V rv_9 = v_unreached_2437; V rr_ = heff_rec_reuse_nf(v_acc_241, 3ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
      }
      default: return heff_nomatch(v_n_242);
      }
    }
    case TAG_DeclWatch: {
      V v_e_2439 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop(v_kf_240);
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_sp_2441 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        V v_t_2442 = heff_tr(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(heff_dup(heff_rfield(v_acc_241, 0)), v_e_2439, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
        HEFF_LAST return g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_241, v_sp_2441, v_t_2442);
      }
      default: return heff_nomatch(v_n_242);
      }
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883(V v_lit_240, V v_lit_241, V v_acc_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    V v_globals_244 = heff_take_field(v_acc_242, 0);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 1)));
    V v_diags_246 = (g_heff_2eelab_2etoplevel_2eonceEach(NTAG(TAG_Nil), v_t_245));
    V v_keys_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 2)));
    V v_broken_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 3)));
    V v_watches_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 4)));
    V v_tests_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 5)));
    V v_spans_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 6)));
    V v_infos_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 7)));
    V v_trace_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 8)));
    V v_unreached_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_242, 9)));
    return ({ V rv_0 = v_globals_244; V rv_1 = v_diags_246; V rv_2 = v_keys_247; V rv_3 = v_broken_248; V rv_4 = v_watches_249; V rv_5 = v_tests_2410; V rv_6 = v_spans_2411; V rv_7 = v_infos_2412; V rv_8 = v_trace_2413; V rv_9 = v_unreached_2414; V rr_ = heff_rec_reuse_nf(v_acc_242, 0ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
  }
  case TAG_Cons: {
    V v_n_2415 = heff_field(v_x3_243, 0);
    V v_rest_2416 = heff_field(v_x3_243, 1);
    V v_t_2418 = (g_heff_2eelab_2etoplevel_2etopOne(heff_clo_n(g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_lam0, 1, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_acc_242, heff_dup(v_n_2415)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2418;
    V t_3 = v_rest_2416;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_acc_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_strAppend(heff_strAppend(v_lit_240, v_lit_241), v_a_2417);
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry, 8, 0};

V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V v_g_240, V v_d_241, V v_isInstance_242, V v_tyStx_243, V v_mc_244, V v_x7_245, V v_z_246, V v_z_247) {
top: ;
  V v_prim_248 = heff_take_field(v_d_241, 3);
  V v_name_249 = heff_get_n(v_d_241, 0, 4);
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Left: {
    V v_failed_2410 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    V v_t_2411 = heff_dup(v_prim_248);
    V v_key_2412;
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      v_key_2412 = heff_dup(v_name_249);
    } else {
      heff_drop(v_t_2411);
      v_key_2412 = heff_dup(v_name_249);
    }
    HeffT2 v_t_2413 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      V v_a_2419;
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_x_2416 = v_field_2415;
        v_a_2419 = v_x_2416;
      } else {
        if ((v_tag_2414 == ((int64_t)1ULL))) {
          V v_x11_2417 = v_field_2415;
          heff_drop(v_x11_2417);
          v_a_2419 = heff_abandon();
        } else {
          V v_x_2418 = v_field_2415;
          v_a_2419 = v_x_2418;
        }
      }
      V v_t_2421 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0, 1, 1, (V[]){v_a_2419}), NTAG(TAG_Nothing)));
      HeffT2 v_t_2422 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
      {
        V v_field_2424 = v_t_2422.f[1];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        V v_t_2428;
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          V v_x_2425 = v_field_2424;
          v_t_2428 = v_x_2425;
        } else {
          if ((v_tag_2423 == ((int64_t)1ULL))) {
            V v_x11_2426 = v_field_2424;
            heff_drop(v_x11_2426);
            v_t_2428 = heff_abandon();
          } else {
            V v_x_2427 = v_field_2424;
            v_t_2428 = v_x_2427;
          }
        }
        V v_entry_2429 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SAbandon), v_tyStx_243, v_t_2421, v_t_2428});
        V v_t_2430 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_249, v_key_2412, v_prim_248, v_isInstance_242, v_entry_2429, heff_tag_n(TAG_Just, 1, (V[]){v_failed_2410})});
        return heff_tail(v_z_247, 1, (V[]){v_t_2430});
      }
    }
  }
  case TAG_Right: {
    V v_t_2431 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    V v_t_2432 = heff_dup(v_prim_248);
    V v_key_2433;
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_t_2432);
      v_key_2433 = heff_dup(v_name_249);
    } else {
      heff_drop(v_t_2432);
      v_key_2433 = heff_dup(v_name_249);
    }
    V v_t_2434 = heff_dup(v_prim_248);
    V v_t_2435;
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_t_2434);
      v_t_2435 = heff_dup(v_name_249);
    } else {
      heff_drop(v_t_2434);
      v_t_2435 = heff_dup(v_name_249);
    }
    HeffT2 v_t_2436 = (g_heff_2eelab_2eunify_2ezonker_24cpr(v_mc_244));
    {
      V v_field_2437 = v_t_2436.f[0];
      heff_drop(v_t_2436.f[1]);
      V v_t_2439 = heff_tr(heff_call(v_field_2437, 1, (V[]){heff_get_n(v_t_2431, 0, 2)}));
      V v_t_2440 = heff_dup(v_prim_248);
      V v_t_2441;
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_t_2440);
        v_t_2441 = heff_dup(v_name_249);
      } else {
        heff_drop(v_t_2440);
        v_t_2441 = heff_dup(v_name_249);
      }
      HeffT2 v_t_2442 = ({ V a_0 = v_t_2441; HeffT2 r_ = (g_heff_2eelab_2etoplevel_2eselfWalk_24cpr(a_0)); heff_drop(v_t_2441); r_; });
      {
        V v_field_2443 = v_t_2442.f[0];
        heff_drop(v_t_2442.f[1]);
        V v_t_2445 = heff_tr(heff_call(v_field_2443, 2, (V[]){MK_INT(0LL), v_t_2439}));
        V v_entry_2446 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_240, v_t_2435, v_prim_248, v_tyStx_243, v_t_2445));
        V v_t_2447 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_249, v_key_2433, v_prim_248, v_isInstance_242, v_entry_2446, NTAG(TAG_Nothing)});
        return heff_tail(v_z_247, 1, (V[]){v_t_2447});
      }
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a4 = a[4]; V a6 = a[6]; V r = g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a0, a[1], a[2], a[3], a4, a[5], a6, a[7]); heff_drop(a0); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_lam0(V self, V *args) {
  V v_u_2420 = args[0];
  V v_a_2419 = heff_env(self)[0];
  heff_drop(v_u_2420);
  heff_clo_take(self, 1);
  return v_a_2419;
}
Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawGlobals_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawGlobals(V v_acc_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 5);
  V v_key_243 = heff_take_field(v_d_241, 1);
  V v_ty_244 = heff_take_field(v_d_241, 4);
  V v_name_245 = heff_take_field(v_d_241, 0);
  V v_isInstance_246 = heff_get_n(v_d_241, 2, 6);
  V v_t_247 = (g_heff_2eelab_2etoplevel_2eisPrimB(v_body_242));
  V v_t_248 = ({ V a_0 = heff_rfield(v_acc_240, 0); V a_1 = heff_dup(v_key_243); V a_2 = v_t_247; V a_3 = v_ty_244; V a_4 = v_body_242; V r_ = (g_heff_2eelab_2etoplevel_2eentryFor(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_247); r_; });
  V v_t_249 = ({ V a_0 = heff_dup(v_key_243); V a_1 = v_t_248; V a_2 = heff_get_n(v_acc_240, 0, 10); V r_ = (g_heff_2eelab_2eglobals_2eaddEntry(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_heff_2eelab_2eglobals_2eaddOwn(v_name_245, v_key_243, v_t_249));
  return ({ V a_0 = v_isInstance_246; V a_1 = v_key_243; V a_2 = v_name_245; V a_3 = v_t_2410; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(a_0, a_1, a_2, a_3)); heff_drop(v_isInstance_246); heff_drop(v_name_245); r_; });
}
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawGlobals(a[0], a[1]);
}