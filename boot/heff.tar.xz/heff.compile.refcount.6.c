// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CDropSelf 14512
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CTakeSelf 23160
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_MkBlock 5679
#define TAG_MkCArm 24694
#define TAG_MkDrop 35958
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetFieldPeek 37592
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_flat 9641024
#define LBL_funs 9650075
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_owned 307523263
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tags 10047712
#define LBL_takes 311482598
#define LBL_tokens 1078955205
static uint32_t shape_at__tags[] = {LBL_at, LBL_tags};
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
V g_heff_2ecompile_2erefcount_2eanyW(V, V);
V g_heff_2ecompile_2erefcount_2eanyW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eanyW_clo;
V g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646(V, V);
V g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646_clo;
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_clo;
V g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027_clo;
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_clo;
V g_heff_2ecompile_2erefcount_2edropOf(V, V);
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropOf_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvArm(V);
V g_heff_2ecompile_2erefcount_2efvArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvArm_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epartsThen(V, V);
V g_heff_2ecompile_2erefcount_2epartsThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epartsThen_clo;
V g_heff_2ecompile_2erefcount_2epeekPrim_get(void);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700_clo;
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_clo;
V g_heff_2ecompile_2erefcount_2esameBits(V, V, V, V);
V g_heff_2ecompile_2erefcount_2esameBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameBits_clo;
V g_heff_2ecompile_2erefcount_2eslotBits(V);
V g_heff_2ecompile_2erefcount_2eslotBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eslotBits_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2etaggedArg(V, V, V, V);
V g_heff_2ecompile_2erefcount_2etaggedArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etaggedArg_clo;
V g_heff_2ecompile_2erefcount_2ethreadSts(V, V);
V g_heff_2ecompile_2erefcount_2ethreadSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreadSts_clo;
V g_heff_2ecompile_2erefcount_2ethreaded(V, V);
V g_heff_2ecompile_2erefcount_2ethreaded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ethreaded_clo;
V g_heff_2ecompile_2erefcount_2eupdatedIn(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eupdatedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eupdatedIn_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1050197499x1941129217(V, V);
V g_list_2efoldl_24s1050197499x1941129217_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1050197499x1941129217_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1860157317x1198712058(V, V);
V g_list_2efoldl_24s1860157317x1198712058_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1860157317x1198712058_clo;
V g_list_2efoldl_24s1879887278x1868824044(V, V);
V g_list_2efoldl_24s1879887278x1868824044_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1879887278x1868824044_clo;
V g_list_2efoldl_24s2092021924x904081891(V, V);
V g_list_2efoldl_24s2092021924x904081891_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2092021924x904081891_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1512396752x1753792987(V, V, V);
V g_list_2emap_24s1512396752x1753792987_entry(V self, V *a);
extern Clo g_list_2emap_24s1512396752x1753792987_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s870182194x1066240094(V, V);
V g_list_2ezipWith_24s870182194x1066240094_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithBorrowed_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ewithBorrowed(V v_bs_240, V v_ce_241) {
top: ;
  return ({ V rv_6 = v_bs_240; V rr_ = heff_rec_reuse_nf(v_ce_241, 131007ULL, 17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, 4294955007u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ewithBorrowed(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V v_bs_240, V v_ms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return ((HeffT2){{v_bs_240, v_ms_241}});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24IVal = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_SVar: {
        V v_x_246 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_ms_241});
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x311_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_xs_2416 = heff_field(v_x311_245, 0);
        V v_x3112_2417 = heff_field(v_x311_245, 1);
        V v_ru_24x311_245_24SLam = heff_take_reuse_n(v_x311_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        switch (heff_tag_of(v_x3112_2417)) {
        case TAG_MkBlock: {
          V v_t_2418 = heff_field(v_x3112_2417, 0);
          V v_ru_24x3112_2417_24MkBlock = heff_take_reuse_n(v_x3112_2417, 1ULL, 1);
          V v_t_2419 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x311_245_24SLam, v_xs_2416, v_bs_240));
          V v_t_2420 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x3112_2417_24MkBlock, TAG_ITl, 1, (V[]){v_t_2418}), v_rest_244});
          V t_0 = v_t_2419;
          V t_1 = v_ms_241;
          V t_2 = v_t_2420;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x3112_2417)}});
        }
      }
      case TAG_STag: {
        V v_argv_2422 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2422));
        V v_t_2425 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2424));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2425;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2426 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V v_t_2428 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2426));
        V v_t_2429 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2428));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2429;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_v_2430 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 4);
        V v_t_2434 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24IVal, TAG_IVal, 1, (V[]){v_v_2430}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2434;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrim: {
        V v_argv_2436 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IVal, 1);
        V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2436));
        V v_t_2438 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2437));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2438;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_245)}});
      }
    }
    case TAG_IOp: {
      V v_x311_2439 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24IOp = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2439)) {
      case TAG_OSimple: {
        V v_v_2440 = heff_field(v_x311_2439, 0);
        heff_take_n(v_x311_2439, 1ULL, 1);
        V v_t_2441 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24IOp, TAG_IVal, 1, (V[]){v_v_2440}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2441;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_argv_2443 = heff_field(v_x311_2439, 1);
        heff_take_n(v_x311_2439, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IOp, 1);
        V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2443));
        V v_t_2445 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2444));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2445;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2446 = heff_field(v_x311_2439, 0);
        V v_argv_2447 = heff_field(v_x311_2439, 1);
        heff_take_n(v_x311_2439, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24IOp, 1);
        V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2446, v_argv_2447})));
        V v_t_2449 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2448));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2449;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_argv_2451 = heff_field(v_x311_2439, 1);
        heff_take_n(v_x311_2439, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IOp, 1);
        V v_t_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2451));
        V v_t_2453 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2452));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2453;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24IOp, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2454 = heff_field(v_x311_2439, 0);
        heff_take_n(v_x311_2439, 1ULL, 1);
        V v_t_2455 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24IOp, TAG_ICond, 1, (V[]){v_c_2454}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2455;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_2439)}});
      }
    }
    case TAG_ICond: {
      V v_x311_2456 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2456)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_a_2458 = heff_field(v_x311_2456, 1);
        V v_b_2459 = heff_field(v_x311_2456, 2);
        heff_take_n(v_x311_2456, 6ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2460 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2459}), v_rest_244});
        V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_a_2458}), v_t_2460});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2461;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_2462 = heff_field(v_x311_2456, 0);
        V v_ru_24x311_2456_24PBool = heff_take_reuse_n(v_x311_2456, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2463 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x311_2456_24PBool, TAG_IVal, 1, (V[]){v_v_2462}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2463;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_2464 = heff_field(v_x311_2456, 0);
        heff_take_n(v_x311_2456, 1ULL, 1);
        V v_t_2465 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_c_2464}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2465;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_2466 = heff_field(v_x311_2456, 0);
        V v_b_2467 = heff_field(v_x311_2456, 1);
        V v_c_2468 = heff_field(v_x311_2456, 2);
        heff_take_n(v_x311_2456, 7ULL, 3);
        V v_t_2469 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_c_2468}), v_rest_244});
        V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_b_2467}), v_t_2469});
        V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2466}), v_t_2470});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2471;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_x_2472 = heff_field(v_x311_2456, 0);
        V v_o_2473 = heff_field(v_x311_2456, 1);
        V v_c_2474 = heff_field(v_x311_2456, 2);
        heff_take_n(v_x311_2456, 7ULL, 3);
        V v_t_2475 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_c_2474}), v_rest_244});
        V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2473}), v_t_2475});
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2472, v_bs_240});
        V t_1 = v_ms_241;
        V t_2 = v_t_2476;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_2456)}});
      }
    }
    case TAG_ISts: {
      V v_x311_2477 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2477)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_2478 = heff_field(v_x311_2477, 0);
        V v_ss_2479 = heff_field(v_x311_2477, 1);
        V v_ru_24x311_2477_24Cons = heff_take_reuse_n(v_x311_2477, 3ULL, 2);
        switch (heff_tag_of(v_x3111_2478)) {
        case TAG_SLet: {
          V v_x_2480 = heff_field(v_x3111_2478, 0);
          V v_o_2481 = heff_field(v_x3111_2478, 1);
          V v_ru_24x3111_2478_24SLet = heff_take_reuse_n(v_x3111_2478, 3ULL, 2);
          V v_t_2482 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_2483 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2481}), v_t_2482});
          V t_0 = heff_tag_at_n(v_ru_24x3111_2478_24SLet, TAG_Cons, 2, (V[]){v_x_2480, v_bs_240});
          V t_1 = v_ms_241;
          V t_2 = v_t_2483;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SOnce: {
          V v_x_2484 = heff_field(v_x3111_2478, 0);
          V v_o_2485 = heff_field(v_x3111_2478, 1);
          V v_ru_24x3111_2478_24SOnce = heff_take_reuse_n(v_x3111_2478, 3ULL, 2);
          V v_t_2486 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_2487 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2485}), v_t_2486});
          V t_0 = heff_tag_at_n(v_ru_24x3111_2478_24SOnce, TAG_Cons, 2, (V[]){v_x_2484, v_bs_240});
          V t_1 = v_ms_241;
          V t_2 = v_t_2487;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          V v_x_2488 = heff_field(v_x3111_2478, 0);
          heff_take_n(v_x3111_2478, 1ULL, 1);
          V v_t_2489 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V t_0 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){v_x_2488, v_bs_240});
          V t_1 = v_ms_241;
          V t_2 = v_t_2489;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_o_2491 = heff_field(v_x3111_2478, 1);
          heff_take_n(v_x3111_2478, 2ULL, 2);
          V v_t_2492 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_2493 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_2491}), v_t_2492});
          V t_0 = v_bs_240;
          V t_1 = v_ms_241;
          V t_2 = v_t_2493;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_2494 = heff_field(v_x3111_2478, 0);
          V v_ts_2495 = heff_field(v_x3111_2478, 1);
          V v_fs_2496 = heff_field(v_x3111_2478, 2);
          heff_take_n(v_x3111_2478, 7ULL, 3);
          V v_t_2497 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_2498 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_fs_2496}), v_t_2497});
          V v_t_2499 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_2495}), v_t_2498});
          V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2494}), v_t_2499});
          V t_0 = v_bs_240;
          V t_1 = v_ms_241;
          V t_2 = v_t_24100;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24101 = heff_field(v_x3111_2478, 0);
          V v_arms_24102 = heff_field(v_x3111_2478, 1);
          V v_ru_24x3111_2478_24SCase = heff_take_reuse_n(v_x3111_2478, 3ULL, 2);
          V v_t_24103 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_24102)));
          V v_t_24104 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24103; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_24103); r_; });
          V v_t_24105 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3111_2478_24SCase, v_t_24104, v_bs_240));
          V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24102));
          V v_t_24107 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_2479}), v_rest_244});
          V v_t_24108 = (g_list_2efoldl_24s1104809983x118204267(v_t_24107, v_t_24106));
          V v_t_24109 = heff_tag_at_n(v_ru_24x311_2477_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24101}), v_t_24108});
          V t_0 = v_t_24105;
          V t_1 = v_ms_241;
          V t_2 = v_t_24109;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x3111_2478)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_2477)}});
      }
    }
    case TAG_ITl: {
      V v_x311_24110 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24110)) {
      case TAG_TSeq: {
        V v_ss_24111 = heff_field(v_x311_24110, 0);
        V v_t_24112 = heff_field(v_x311_24110, 1);
        V v_ru_24x311_24110_24TSeq = heff_take_reuse_n(v_x311_24110, 3ULL, 2);
        V v_t_24113 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_t_24112}), v_rest_244});
        V v_t_24114 = heff_tag_at_n(v_ru_24x311_24110_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24111}), v_t_24113});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24114;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24115 = heff_field(v_x311_24110, 0);
        V v_ru_24x311_24110_24TReturn = heff_take_reuse_n(v_x311_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24116 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x311_24110_24TReturn, TAG_IOp, 1, (V[]){v_o_24115}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24116;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24117 = heff_field(v_x311_24110, 0);
        heff_take_n(v_x311_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24118 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24117));
        V v_t_24119 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_24118));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24119;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24120 = heff_field(v_x311_24110, 0);
        V v_t_24121 = heff_field(v_x311_24110, 1);
        V v_e_24122 = heff_field(v_x311_24110, 2);
        heff_take_n(v_x311_24110, 7ULL, 3);
        V v_t_24123 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_e_24122}), v_rest_244});
        V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24121}), v_t_24123});
        V v_t_24125 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24120}), v_t_24124});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24125;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24126 = heff_field(v_x311_24110, 0);
        V v_arms_24127 = heff_field(v_x311_24110, 1);
        V v_ru_24x311_24110_24TCase = heff_take_reuse_n(v_x311_24110, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24128 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_24127)));
        V v_t_24129 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24128; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_24128); r_; });
        V v_t_24130 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x311_24110_24TCase, v_t_24129, v_bs_240));
        V v_t_24131 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24127));
        V v_t_24132 = (g_list_2efoldl_24s421921225x565177679(v_rest_244, v_t_24131));
        V v_t_24133 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24126}), v_t_24132});
        V t_0 = v_t_24130;
        V t_1 = v_ms_241;
        V t_2 = v_t_24133;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x311_24110)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2edropOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edropOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2edropOf(V v_x_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_k_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_x11_242 = heff_dup(heff_field(v_k_241, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_KnownTag: {
      V v_n_243 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_intLt_c(MK_INT(0LL), v_n_243)) {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_x_240);
        heff_drop_tag(v_k_241, 1);
        return NTAG(TAG_Nil);
      }
    }
    case TAG_KnownCell: {
      heff_take_n(v_x11_242, 0ULL, 3);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
    }
    case TAG_KnownRec: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
    }
    case TAG_KnownClo: {
      V v_n_248 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_intLt_c(MK_INT(0LL), v_n_248)) {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_x_240);
        heff_drop_tag(v_k_241, 1);
        return NTAG(TAG_Nil);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_k_241);
  }
}
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edropOf(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseArgs_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ereuseArgs(V v_go_240, V v_vs_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseArgs_lam0, 2, 1, (V[]){v_go_240}); V a_1 = v_t_242; V a_2 = v_vs_241; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ereuseArgs(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseArgs_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_v_244 = args[1];
  V v_go_240 = heff_env(self)[0];
  V v_t_247;
  switch (heff_tag_of(v_acc_243)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_acc_243, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_acc_243);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(self);
    heff_drop(v_t_247);
    V v_t_2410;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_244, NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_t_2412});
  } else {
    heff_drop(v_t_247);
    heff_clo_take(self, 1);
    V v_x2_2413 = heff_tr(heff_call(v_go_240, 1, (V[]){v_v_244}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_b_2414 = heff_field(v_x2_2413, 0);
      V v_e_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_acc_243)) {
      case TAG_MkPair: {
        V v_y_2417 = heff_field(v_acc_243, 1);
        heff_take_n(v_acc_243, 2ULL, 2);
        v_t_2418 = v_y_2417;
        break;
      }
      default: heff_nomatch(v_acc_243);
      }
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2415, NTAG(TAG_Nil)});
      V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2419));
      return heff_tag_re_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_b_2414, v_t_2420});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
}
Clo g_heff_2ecompile_2erefcount_2eanyW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eanyW_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eanyW(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_it_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_it_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_it_242);
      heff_drop(v_rest_243);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2erefcount_2epartsThen(v_it_242, v_rest_243));
      V t_0 = v_f_240;
      V t_1 = v_t_245;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eanyW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2eanyW(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erefcount_2etaggedArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2etaggedArg_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2etaggedArg(V v_b_240, V v_x_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x4_243);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x3_242, 0);
    V v_ps_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_p_244);
      heff_drop(v_ps_245);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_v_246 = heff_field(v_x4_243, 0);
      V v_vs_247 = heff_field(v_x4_243, 1);
      V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
      V v_t_2484;
      switch (heff_tag_of(v_v_246)) {
      case TAG_SVar: {
        V v_y_248 = heff_field(v_v_246, 0);
        V v_ru_24v_246_24SVar = heff_take_reuse_n(v_v_246, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_241, v_y_248, 2)) {
          V v_lit_249 = heff_dup(v_b_240);
          V v_x_2410 = heff_dup(v_p_244);
          V v_t_2443;
          switch (heff_tag_of(v_lit_249)) {
          case TAG_TSeq: {
            heff_take_n(v_lit_249, 0ULL, 2);
            heff_drop(v_x_2410);
            v_t_2443 = NTAG(TAG_False);
            break;
          }
          case TAG_TReturn: {
            heff_take_n(v_lit_249, 0ULL, 1);
            heff_drop(v_x_2410);
            v_t_2443 = NTAG(TAG_False);
            break;
          }
          case TAG_TLoop: {
            heff_take_n(v_lit_249, 0ULL, 1);
            heff_drop(v_x_2410);
            v_t_2443 = NTAG(TAG_False);
            break;
          }
          case TAG_TIf: {
            heff_take_n(v_lit_249, 0ULL, 3);
            heff_drop(v_x_2410);
            v_t_2443 = NTAG(TAG_False);
            break;
          }
          case TAG_TCase: {
            V v_v_2418 = heff_field(v_lit_249, 0);
            heff_take_n(v_lit_249, 1ULL, 2);
            switch (heff_tag_of(v_v_2418)) {
            case TAG_SVar: {
              V v_y_2420 = heff_field(v_v_2418, 0);
              heff_take_n(v_v_2418, 1ULL, 1);
              v_t_2443 = heff_bool(heff_strEq_c_lent(v_x_2410, v_y_2420, 0));
              heff_drop(v_x_2410);
              heff_drop(v_y_2420);
              break;
            }
            case TAG_SGlobal: {
              heff_take_n(v_v_2418, 0ULL, 1);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SInt: {
              heff_take_n(v_v_2418, 0ULL, 1);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SFloat: {
              heff_take_na(v_v_2418, 0ULL, 1);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SStr: {
              heff_take_n(v_v_2418, 0ULL, 1);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SBytes: {
              heff_take_n(v_v_2418, 0ULL, 1);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SFixed: {
              heff_take_n(v_v_2418, 0ULL, 2);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SFloat32: {
              heff_take_na(v_v_2418, 0ULL, 1);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SPrimFn: {
              heff_take_n(v_v_2418, 0ULL, 1);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SLam: {
              heff_take_n(v_v_2418, 0ULL, 2);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_STag: {
              heff_take_n(v_v_2418, 0ULL, 3);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SRec: {
              heff_take_n(v_v_2418, 0ULL, 2);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SProj: {
              heff_take_n(v_v_2418, 0ULL, 4);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_SPrim: {
              heff_take_n(v_v_2418, 0ULL, 2);
              heff_drop(v_x_2410);
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_v_2418);
            }
            break;
          }
          default: heff_nomatch(v_lit_249);
          }
          if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
            heff_drop(v_p_244);
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            heff_drop_cell(v_ru_24v_246_24SVar, 1);
            heff_drop(v_t_2443);
            v_t_2484 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_2443);
            V v_lit_2444 = heff_dup(v_b_240);
            V v_rest_2445 = NTAG(TAG_Nil);
            V v_t_2461;
            switch (heff_tag_of(v_lit_2444)) {
            case TAG_TSeq: {
              V v_ss_2446 = heff_field(v_lit_2444, 0);
              V v_t_2447 = heff_field(v_lit_2444, 1);
              heff_take_n(v_lit_2444, 3ULL, 2);
              V v_t_2448 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v_246_24SVar, TAG_ITl, 1, (V[]){v_t_2447}), v_rest_2445});
              v_t_2461 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2446}), v_t_2448});
              break;
            }
            case TAG_TReturn: {
              V v_o_2449 = heff_field(v_lit_2444, 0);
              heff_take_n(v_lit_2444, 1ULL, 1);
              heff_drop_cell(v_ru_24x4_243_24Cons, 2);
              v_t_2461 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v_246_24SVar, TAG_IOp, 1, (V[]){v_o_2449}), v_rest_2445});
              break;
            }
            case TAG_TLoop: {
              V v_vs_2450 = heff_field(v_lit_2444, 0);
              heff_take_n(v_lit_2444, 1ULL, 1);
              heff_drop_cell(v_ru_24x3_242_24Cons, 2);
              heff_drop_cell(v_ru_24x4_243_24Cons, 2);
              heff_drop_cell(v_ru_24v_246_24SVar, 1);
              V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2450));
              v_t_2461 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_2445, v_t_2451));
              break;
            }
            case TAG_TIf: {
              V v_c_2452 = heff_field(v_lit_2444, 0);
              V v_t_2453 = heff_field(v_lit_2444, 1);
              V v_e_2454 = heff_field(v_lit_2444, 2);
              heff_take_n(v_lit_2444, 7ULL, 3);
              V v_t_2455 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v_246_24SVar, TAG_ITl, 1, (V[]){v_e_2454}), v_rest_2445});
              V v_t_2456 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2453}), v_t_2455});
              v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2452}), v_t_2456});
              break;
            }
            case TAG_TCase: {
              V v_v_2457 = heff_field(v_lit_2444, 0);
              V v_arms_2458 = heff_field(v_lit_2444, 1);
              heff_take_n(v_lit_2444, 3ULL, 2);
              heff_drop_cell(v_ru_24x4_243_24Cons, 2);
              V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2458));
              V v_t_2460 = (g_list_2efoldl_24s421921225x565177679(v_rest_2445, v_t_2459));
              v_t_2461 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v_246_24SVar, TAG_IVal, 1, (V[]){v_v_2457}), v_t_2460});
              break;
            }
            default: heff_nomatch(v_lit_2444);
            }
            v_t_2484 = ({ V a_0 = v_p_244; V a_1 = v_t_2461; V r_ = (g_heff_2ecompile_2erefcount_2eanyW_24s862285549x1356448646(a_0, a_1)); heff_drop(v_p_244); r_; });
          }
        } else {
          heff_drop(v_p_244);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop_cell(v_ru_24v_246_24SVar, 1);
          v_t_2484 = NTAG(TAG_False);
        }
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_v_246, 0ULL, 1);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_v_246, 0ULL, 1);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_v_246, 0ULL, 3);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_v_246, 0ULL, 4);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_v_246);
      }
      if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
        heff_drop(v_ps_245);
        heff_drop(v_vs_247);
        heff_drop(v_t_2484);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2484);
        V t_0 = v_b_240;
        V t_1 = v_x_241;
        V t_2 = v_ps_245;
        V t_3 = v_vs_247;
        v_b_240 = t_0;
        v_x_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erefcount_2etaggedArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2etaggedArg(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2ethreadSts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ethreadSts_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ethreadSts(V v_th_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2ethreadSts_clo), 1, (V[]){heff_dup(v_th_240)}));
  return (g_list_2emap_24s1512396752x1753792987(v_th_240, v_t_242, v_ss_241));
}
V g_heff_2ecompile_2erefcount_2ethreadSts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ethreadSts(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2ethreaded_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ethreaded_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ethreaded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ethreaded_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ethreaded(V v_xs_240, V v_ss_241) {
top: ;
  switch (heff_tag_of(v_ss_241)) {
  case TAG_Nil: {
    return v_ss_241;
  }
  case TAG_Cons: {
    V v_ss1_242 = heff_dup(heff_field(v_ss_241, 0));
    V v_ss2_243 = heff_dup(heff_field(v_ss_241, 1));
    switch (heff_tag_of(v_ss1_242)) {
    case TAG_CDrop: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CLet: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CDecl: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CSet: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CAbandon: {
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CIf: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CSwitch: {
      V v_ss11_2413 = heff_field(v_ss1_242, 0);
      V v_arms_2414 = heff_field(v_ss1_242, 1);
      V v_r_2415 = heff_field(v_ss1_242, 2);
      V v_ru_24ss1_242_24CSwitch = heff_take_reuse_n(v_ss1_242, 7ULL, 3);
      switch (heff_tag_of(v_ss11_2413)) {
      case TAG_RLocal: {
        V v_p_2416 = heff_field(v_ss11_2413, 0);
        V v_ru_24ss11_2413_24RLocal = heff_take_reuse_n(v_ss11_2413, 1ULL, 1);
        switch (heff_tag_of(v_ss2_243)) {
        case TAG_Nil: {
          heff_drop_tag(v_ss_241, 2);
          HeffT2 v_t_2417 = (g_heff_2ecompile_2erefcount_2eindexIn_24cpr(v_p_2416, MK_INT(0LL), v_xs_240));
          {
            V v_field_2419 = v_t_2417.f[1];
            int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
            if ((v_tag_2418 == ((int64_t)0ULL))) {
              V v_i_2420 = v_field_2419;
              V v_t_2421 = (g_list_2efoldl_24s2092021924x904081891(NTAG(TAG_Nil), heff_dup(v_arms_2414)));
              V v_th_2422 = heff_rec_n(2, shape_at__tags, (V[]){v_i_2420, v_t_2421});
              V v_arms_2423 = v_arms_2414;
              V v_gone_2434 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ethreaded_lam0, 1, 1, (V[]){v_th_2422}), v_arms_2423));
              V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_gone_2434)));
              V v_t_2436 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2435; V r_ = (g_list_2efoldl_24s1879887278x1868824044(a_0, a_1)); heff_drop(v_t_2435); r_; });
              V v_ts_2437 = (g_list_2efoldl_24s1860157317x1198712058(NTAG(TAG_Nil), v_t_2436));
              V v_t_2449 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ethreaded_lam1, 1, 1, (V[]){v_ts_2437}), v_gone_2434));
              V v_t_2450 = heff_tag_re_n(v_ru_24ss1_242_24CSwitch, TAG_CSwitch, 3, 4ULL, (V[]){heff_tag_re_n(v_ru_24ss11_2413_24RLocal, TAG_RLocal, 1, 1ULL, (V[]){v_p_2416}), v_t_2449, v_r_2415});
              return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
            } else {
              heff_drop(v_field_2419);
              V v_t_2451 = heff_tag_re_n(v_ru_24ss1_242_24CSwitch, TAG_CSwitch, 3, 6ULL, (V[]){heff_tag_re_n(v_ru_24ss11_2413_24RLocal, TAG_RLocal, 1, 1ULL, (V[]){v_p_2416}), v_arms_2414, v_r_2415});
              return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
            }
          }
        }
        case TAG_Cons: {
          heff_take_n(v_ss2_243, 0ULL, 2);
          heff_drop(v_arms_2414);
          heff_drop(v_r_2415);
          heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
          heff_drop(v_p_2416);
          heff_drop_cell(v_ru_24ss11_2413_24RLocal, 1);
          return v_ss_241;
        }
        default: return heff_nomatch(v_ss2_243);
        }
      }
      case TAG_RDup: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RClo: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGet: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGetRaw: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RInt: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFloat: {
        heff_take_na(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RStr: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RBytes: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFixed: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RF32: {
        heff_take_na(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RNTag: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RStatic: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RTag: {
        heff_take_n(v_ss11_2413, 0ULL, 3);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RTagIn: {
        heff_take_n(v_ss11_2413, 0ULL, 5);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RRec: {
        heff_take_n(v_ss11_2413, 0ULL, 3);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RRecIn: {
        heff_take_n(v_ss11_2413, 0ULL, 8);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RField: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RDupE: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFieldV: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGetN: {
        heff_take_n(v_ss11_2413, 0ULL, 3);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFieldU: {
        heff_take_n(v_ss11_2413, 0ULL, 4);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGetNU: {
        heff_take_n(v_ss11_2413, 0ULL, 5);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RWord: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RTakeField: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RGetLabel: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPrimFn: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPrim: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RLam: {
        heff_take_n(v_ss11_2413, 0ULL, 4);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RCall: {
        heff_take_n(v_ss11_2413, 0ULL, 4);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RApply: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RBool: {
        heff_take_n(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RAbandon: {
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RBox: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RUnbox: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPeek: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPrimU: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RPrimAt: {
        heff_take_n(v_ss11_2413, 0ULL, 3);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RFixU: {
        heff_take_n(v_ss11_2413, 0ULL, 2);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RF32U: {
        heff_take_na(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      case TAG_RF64U: {
        heff_take_na(v_ss11_2413, 0ULL, 1);
        heff_drop(v_ss2_243);
        heff_drop(v_arms_2414);
        heff_drop(v_r_2415);
        heff_drop_cell(v_ru_24ss1_242_24CSwitch, 3);
        return v_ss_241;
      }
      default: return heff_nomatch(v_ss11_2413);
      }
    }
    case TAG_CReturn: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CInPlace: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CRoomed: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CTail: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CLoop: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CLoopTo: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CLabel: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CJump: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CTakeSelf: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    case TAG_CDropSelf: {
      heff_drop(v_ss2_243);
      return v_ss_241;
    }
    default: return heff_nomatch(v_ss1_242);
    }
  }
  default: return heff_nomatch(v_ss_241);
  }
}
V g_heff_2ecompile_2erefcount_2ethreaded_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2ethreaded(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erefcount_2ethreaded_lam0(V self, V *args) {
  V v_x2_2424 = args[0];
  V v_th_2422 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkCArm: {
    V v_t_2425 = heff_field(v_x2_2424, 0);
    V v_fs_2426 = heff_field(v_x2_2424, 1);
    V v_fl_2427 = heff_field(v_x2_2424, 2);
    V v_su_2428 = heff_field(v_x2_2424, 3);
    V v_pl_2429 = heff_field(v_x2_2424, 4);
    V v_tk_2430 = heff_field(v_x2_2424, 5);
    V v_body_2431 = heff_field(v_x2_2424, 6);
    V v_lv_2432 = heff_field(v_x2_2424, 7);
    V v_ru_24x2_2424_24MkCArm = heff_take_reuse_n(v_x2_2424, 255ULL, 8);
    heff_clo_take(self, 1);
    V v_t_2433 = (g_heff_2ecompile_2erefcount_2ethreadSts(v_th_2422, v_body_2431));
    return heff_tag_re_n(v_ru_24x2_2424_24MkCArm, TAG_MkCArm, 8, 191ULL, (V[]){v_t_2425, v_fs_2426, v_fl_2427, v_su_2428, v_pl_2429, v_tk_2430, v_t_2433, v_lv_2432});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2erefcount_2ethreaded_lam1(V self, V *args) {
  V v_x2_2438 = args[0];
  V v_ts_2437 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkCArm: {
    V v_t_2439 = heff_field(v_x2_2438, 0);
    V v_fs_2440 = heff_field(v_x2_2438, 1);
    V v_fl_2441 = heff_field(v_x2_2438, 2);
    V v_su_2442 = heff_field(v_x2_2438, 3);
    V v_pl_2443 = heff_field(v_x2_2438, 4);
    V v_tk_2444 = heff_field(v_x2_2438, 5);
    V v_body_2445 = heff_field(v_x2_2438, 6);
    V v_lv_2446 = heff_field(v_x2_2438, 7);
    V v_ru_24x2_2438_24MkCArm = heff_take_reuse_n(v_x2_2438, 255ULL, 8);
    heff_clo_take(self, 1);
    V v_t_2447 = ({ V a_0 = v_t_2439; V a_1 = v_ts_2437; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_ts_2437); r_; });
    V v_t_2448;
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_t_2447);
      v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLabel, 1, (V[]){heff_dup(v_t_2439)}), v_body_2445});
    } else {
      heff_drop(v_t_2447);
      v_t_2448 = v_body_2445;
    }
    return heff_tag_re_n(v_ru_24x2_2438_24MkCArm, TAG_MkCArm, 8, 191ULL, (V[]){v_t_2439, v_fs_2440, v_fl_2441, v_su_2442, v_pl_2443, v_tk_2444, v_t_2448, v_lv_2446});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_SVar: {
      V v_x_245 = heff_field(v_x41_243, 0);
      switch (heff_tag_of(v_x42_244)) {
      case TAG_Nil: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_Cons: {
        V v_x421_246 = heff_field(v_x42_244, 0);
        V v_x422_247 = heff_field(v_x42_244, 1);
        switch (heff_tag_of(v_x421_246)) {
        case TAG_SVar: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SGlobal: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SInt: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SFloat: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SStr: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SBytes: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SFixed: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SFloat32: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SPrimFn: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SLam: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_STag: {
          V v_t_2420 = heff_field(v_x421_246, 0);
          V v_argv_2421 = heff_field(v_x421_246, 1);
          V v_ts_2422 = heff_field(v_x421_246, 2);
          switch (heff_tag_of(v_x422_247)) {
          case TAG_Nil: {
            V v_n_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2421));
            V v_t_2424 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2423, MK_INT(1LL))));
            V v_rps_2427 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0, 1, 1, (V[]){heff_dup(v_ts_2422)}), v_t_2424));
            V v_t_2428 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_rps_2427), heff_dup(v_argv_2421)));
            V v_es_2429 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2427, v_t_2428));
            V v_n_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2421));
            V v_t_2431 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2430, MK_INT(1LL))));
            V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1, 1, 1, (V[]){heff_dup(v_ts_2422)}), v_t_2431));
            V v_flat_2435 = (g_heff_2ecompile_2erefcount_2eslotBits(v_t_2434));
            V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_argv_2421)));
            V v_t_2437 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_2436));
            V v_live_2438 = (g_prelude_2e_2b_2b(v_t_2437, v_live_241));
            V v_t_2439 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2438, NTAG(TAG_RepV), heff_dup(v_x41_243)));
            V v_t_2440;
            if (heff_intEq_c_lent(v_flat_2435, MK_INT(0LL), 2)) {
              v_t_2440 = (g_heff_2ecompile_2erefcount_2esameBits(v_ce_240, v_x41_243, v_t_2420, v_es_2429));
            } else {
              heff_drop(v_ce_240);
              v_t_2440 = MK_INT(0LL);
            }
            return heff_tag_n(TAG_RTagIn, 5, (V[]){v_t_2439, heff_dup(v_t_2420), v_flat_2435, v_t_2440, v_es_2429});
          }
          case TAG_Cons: {
            heff_drop(v_ce_240);
            heff_drop(v_live_241);
            return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
          }
          default: return heff_nomatch(v_x422_247);
          }
        }
        case TAG_SRec: {
          V v_fs_2443 = heff_field(v_x421_246, 0);
          V v_ts_2444 = heff_field(v_x421_246, 1);
          switch (heff_tag_of(v_x422_247)) {
          case TAG_Nil: {
            V v_ce_2445 = heff_dup(v_ce_240);
            V v_live_2446 = heff_dup(v_live_241);
            V v_x_2447 = heff_dup(v_x_245);
            V v_fs_2448 = heff_dup(v_fs_2443);
            V v_t_2449 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2447, heff_rfield(v_ce_2445, 4)));
            V v_t_2455;
            if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
              heff_drop(v_t_2449);
              V v_x1_2450 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2447, v_live_2446));
              if (!(heff_dup(v_x1_2450) == NTAG(TAG_True))) {
                heff_drop(v_x1_2450);
                V v_x1_2451 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2447, heff_rfield(v_ce_2445, 6)));
                if (!(heff_dup(v_x1_2451) == NTAG(TAG_True))) {
                  heff_drop_rec(v_ce_2445, 17);
                  heff_drop(v_live_2446);
                  heff_drop(v_fs_2448);
                  heff_drop(v_x1_2451);
                  v_t_2455 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2447});
                } else {
                  heff_drop(v_x_2447);
                  heff_drop(v_x1_2451);
                  V v_t_2452 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2448)));
                  v_t_2455 = ({ V a_0 = v_ce_2445; V a_1 = v_live_2446; V a_2 = v_t_2452; V a_3 = v_fs_2448; V r_ = (g_heff_2ecompile_2erefcount_2eupdatedIn(a_0, a_1, a_2, a_3)); heff_drop(v_live_2446); heff_drop(v_t_2452); r_; });
                }
              } else {
                heff_drop(v_x_2447);
                heff_drop(v_x1_2450);
                V v_t_2453 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2448)));
                v_t_2455 = ({ V a_0 = v_ce_2445; V a_1 = v_live_2446; V a_2 = v_t_2453; V a_3 = v_fs_2448; V r_ = (g_heff_2ecompile_2erefcount_2eupdatedIn(a_0, a_1, a_2, a_3)); heff_drop(v_live_2446); heff_drop(v_t_2453); r_; });
              }
            } else {
              heff_drop(v_x_2447);
              heff_drop(v_t_2449);
              V v_t_2454 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2448)));
              v_t_2455 = ({ V a_0 = v_ce_2445; V a_1 = v_live_2446; V a_2 = v_t_2454; V a_3 = v_fs_2448; V r_ = (g_heff_2ecompile_2erefcount_2eupdatedIn(a_0, a_1, a_2, a_3)); heff_drop(v_live_2446); heff_drop(v_t_2454); r_; });
            }
            return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = heff_dup(v_fs_2443); V a_3 = v_ts_2444; V a_4 = v_t_2455; V r_ = (g_heff_2ecompile_2erefcount_2erecordVal_24s675211968x1543611700(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2455); r_; });
          }
          case TAG_Cons: {
            heff_drop(v_ce_240);
            heff_drop(v_live_241);
            return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
          }
          default: return heff_nomatch(v_x422_247);
          }
        }
        case TAG_SProj: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SPrim: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        default: return heff_nomatch(v_x421_246);
        }
      }
      default: return heff_nomatch(v_x42_244);
      }
    }
    default: {
      switch (heff_tag_of(v_x42_244)) {
      case TAG_Nil: {
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_Cons: {
        V v_x421_2464 = heff_field(v_x42_244, 0);
        V v_x422_2465 = heff_field(v_x42_244, 1);
        switch (heff_tag_of(v_x421_2464)) {
        case TAG_SVar: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SGlobal: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SInt: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SFloat: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SStr: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SBytes: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SFixed: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SFloat32: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SPrimFn: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SLam: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_STag: {
          V v_t_2478 = heff_field(v_x421_2464, 0);
          V v_argv_2479 = heff_field(v_x421_2464, 1);
          V v_ts_2480 = heff_field(v_x421_2464, 2);
          switch (heff_tag_of(v_x422_2465)) {
          case TAG_Nil: {
            V v_n_2481 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2479));
            V v_t_2482 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2481, MK_INT(1LL))));
            V v_rps_2485 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam2, 1, 1, (V[]){heff_dup(v_ts_2480)}), v_t_2482));
            V v_t_2486 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_rps_2485), heff_dup(v_argv_2479)));
            V v_es_2487 = (g_list_2ezipWith_24s870182194x1066240094(v_rps_2485, v_t_2486));
            V v_n_2488 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2479));
            V v_t_2489 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2488, MK_INT(1LL))));
            V v_t_2492 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam3, 1, 1, (V[]){heff_dup(v_ts_2480)}), v_t_2489));
            V v_flat_2493 = (g_heff_2ecompile_2erefcount_2eslotBits(v_t_2492));
            V v_t_2494 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_argv_2479)));
            V v_t_2495 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_2494));
            V v_live_2496 = (g_prelude_2e_2b_2b(v_t_2495, v_live_241));
            V v_t_2497 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2496, NTAG(TAG_RepV), heff_dup(v_x41_243)));
            V v_t_2498;
            if (heff_intEq_c_lent(v_flat_2493, MK_INT(0LL), 2)) {
              v_t_2498 = (g_heff_2ecompile_2erefcount_2esameBits(v_ce_240, v_x41_243, v_t_2478, v_es_2487));
            } else {
              heff_drop(v_ce_240);
              v_t_2498 = MK_INT(0LL);
            }
            return heff_tag_n(TAG_RTagIn, 5, (V[]){v_t_2497, heff_dup(v_t_2478), v_flat_2493, v_t_2498, v_es_2487});
          }
          case TAG_Cons: {
            heff_drop(v_ce_240);
            heff_drop(v_live_241);
            return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
          }
          default: return heff_nomatch(v_x422_2465);
          }
        }
        case TAG_SRec: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SProj: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        case TAG_SPrim: {
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        default: return heff_nomatch(v_x421_2464);
        }
      }
      default: return heff_nomatch(v_x42_244);
      }
    }
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam0(V self, V *args) {
  V v_i_2425 = args[0];
  V v_ts_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = ({ V a_0 = heff_dup(v_i_2425); V a_1 = v_ts_2422; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2422); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2425, v_t_2426));
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_ts_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = ({ V a_0 = heff_dup(v_i_2432); V a_1 = v_ts_2422; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2422); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2432, v_t_2433));
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam2(V self, V *args) {
  V v_i_2483 = args[0];
  V v_ts_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2484 = ({ V a_0 = heff_dup(v_i_2483); V a_1 = v_ts_2480; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2480); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2483, v_t_2484));
}
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_lam3(V self, V *args) {
  V v_i_2490 = args[0];
  V v_ts_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = ({ V a_0 = heff_dup(v_i_2490); V a_1 = v_ts_2480; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2480); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2490, v_t_2491));
}
Clo g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(V v_lit_240, V v_lit_241, V v_ce_242, V v_c_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){heff_dup(v_c_243)}), NTAG(TAG_Nil)});
  HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_bs_248 = v_field_246;
    V v_ms_249 = v_field_247;
    V v_ms_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_249));
    V v_t_2411 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_248; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_248); r_; });
    V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2410; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ASts, 1, (V[]){heff_dup(v_lit_241)})));
    V v_t_2414 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ASts, 1, (V[]){heff_dup(v_lit_240)})));
    V v_t_2415 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_242, 5)), v_t_2413, v_t_2414));
    V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2415));
    return (g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816(v_lit_241, v_lit_240, v_ce_242, v_c_243, v_t_2416));
  }
}
V g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdTest_24s993638392x831598027(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam2(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2(V v_tok_240, V v_ce_241, V v_x_242, V v_d_243, V v_iv_244, V v_rest_245, V v_after_246, V v_wb_247) {
top: ;
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_iv_244)));
  V v_t_249 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_248));
  V v_wanted_2410 = (g_prelude_2e_2b_2b(v_t_249, heff_dup(v_wb_247)));
  V v_xs_2413 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam0, 1, 1, (V[]){v_wanted_2410}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2413));
  V v_t_2415 = (g_list_2emap_24s1796125103x644876049(v_t_2414));
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_iv_244)));
  V v_t_2417 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_2416));
  V v_wanted_2418 = (g_prelude_2e_2b_2b(v_t_2417, heff_dup(v_wb_247)));
  V v_t_2420 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam1, 1, 1, (V[]){v_wanted_2418}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2421 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2420, heff_dup(v_wb_247), heff_dup(v_ce_241)));
  V v_t_2422 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_t_2421, heff_dup(v_wb_247), v_iv_244));
  V v_t_2424 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam2, 1, 1, (V[]){v_wb_247}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2425 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_dup(heff_rfield(v_ce_241, 6))});
  V v_t_2426 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2425, heff_dup(v_ce_241)));
  V v_ce_2427 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2424, heff_get_n(v_ce_241, 5, 17), v_t_2426));
  V v_t_2428 = ({ V a_0 = v_ce_2427; V a_1 = v_rest_245; V a_2 = v_after_246; V r_ = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(a_0, a_1, a_2)); heff_drop(v_ce_2427); r_; });
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_d_243}), v_t_2422});
  V v_t_2430 = heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_SetFieldPeek), v_t_2429});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_2430}), v_t_2428});
  return (g_prelude_2e_2b_2b(v_t_2415, v_t_2431));
}
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam0(V self, V *args) {
  V v_v_2411 = args[0];
  V v_wanted_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2412 = ({ V a_0 = v_v_2411; V a_1 = v_wanted_2410; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2411); heff_drop(v_wanted_2410); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
  heff_drop(v_x1_2412);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam1(V self, V *args) {
  V v_v_2419 = args[0];
  V v_wanted_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2419; V a_1 = v_wanted_2418; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2419); heff_drop(v_wanted_2418); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_lam2(V self, V *args) {
  V v_v_2423 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2423; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2423); heff_drop(v_wb_247); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam2(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2(V v_tok_240, V v_ce_241, V v_x_242, V v_a_243, V v_i_244, V v_rest_245, V v_after_246, V v_wb_247) {
top: ;
  V v_t_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){heff_dup(v_i_244)}), NTAG(TAG_Nil)});
  HeffT2 v_t_249 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_248));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_bs_2412 = v_field_2410;
    V v_ms_2413 = v_field_2411;
    V v_ms_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2413));
    V v_t_2415 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2412; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2412); r_; });
    V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2414; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
    V v_wanted_2417 = (g_prelude_2e_2b_2b(v_t_2416, heff_dup(v_wb_247)));
    V v_xs_2420 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam0, 1, 1, (V[]){v_wanted_2417}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2421 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2420));
    V v_t_2422 = (g_list_2emap_24s1796125103x644876049(v_t_2421));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){heff_dup(v_i_244)}), NTAG(TAG_Nil)});
    HeffT2 v_t_2424 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2423));
    {
      V v_field_2425 = v_t_2424.f[0];
      V v_field_2426 = v_t_2424.f[1];
      V v_bs_2427 = v_field_2425;
      V v_ms_2428 = v_field_2426;
      V v_ms_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2428));
      V v_t_2430 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2427; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2427); r_; });
      V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2429; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2430); r_; });
      V v_wanted_2432 = (g_prelude_2e_2b_2b(v_t_2431, heff_dup(v_wb_247)));
      V v_t_2434 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam1, 1, 1, (V[]){v_wanted_2432}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_ce_2435 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2434, heff_dup(v_wb_247), heff_dup(v_ce_241)));
      V v_t_2436 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2435, heff_dup(v_wb_247), NTAG(TAG_RepV), v_i_244));
      V v_t_2438 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam2, 1, 1, (V[]){v_wb_247}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_dup(heff_rfield(v_ce_241, 6))});
      V v_t_2440 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2439, heff_dup(v_ce_241)));
      V v_ce_2441 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2438, heff_get_n(v_ce_241, 5, 17), v_t_2440));
      V v_t_2442 = ({ V a_0 = v_ce_2441; V a_1 = v_rest_245; V a_2 = v_after_246; V r_ = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(a_0, a_1, a_2)); heff_drop(v_ce_2441); r_; });
      V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
      V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_a_243}), v_t_2443});
      V v_t_2445 = heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, heff_tag_n(TAG_RPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2epeekPrim_get()), v_t_2444})});
      return (g_prelude_2e_2b_2b(v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2442})));
    }
  }
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam0(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wanted_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = ({ V a_0 = v_v_2418; V a_1 = v_wanted_2417; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2418); heff_drop(v_wanted_2417); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2419) == NTAG(TAG_True)));
  heff_drop(v_x1_2419);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam1(V self, V *args) {
  V v_v_2433 = args[0];
  V v_wanted_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2433; V a_1 = v_wanted_2432; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2433); heff_drop(v_wanted_2432); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok2_lam2(V self, V *args) {
  V v_v_2437 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2437; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2437); heff_drop(v_wb_247); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3(V v_tok_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_ce_245, V v_p_246, V v_fa_247, V v_wb_248) {
top: ;
  V v_wanted_249 = (g_prelude_2e_2b_2b(heff_dup(v_fa_247), heff_dup(v_wb_248)));
  V v_xs_2412 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam0, 1, 1, (V[]){v_wanted_249}); V a_1 = heff_dup(heff_rfield(v_ce_245, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_245), v_xs_2412));
  V v_t_2414 = (g_list_2emap_24s1796125103x644876049(v_t_2413));
  V v_wanted_2415 = (g_prelude_2e_2b_2b(v_fa_247, heff_dup(v_wb_248)));
  V v_t_2417 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam1, 1, 1, (V[]){v_wanted_2415}); V a_1 = heff_dup(heff_rfield(v_ce_245, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_ce_2418 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2417, heff_dup(v_wb_248), heff_dup(v_ce_245)));
  HeffT2 v_t_2419 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_246));
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    V v_t_2427;
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_sh_2422 = v_field_2421;
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_244, NTAG(TAG_Nil)});
      V v_t_2424 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_2418, heff_dup(v_wb_248), heff_get_n(v_sh_2422, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_243, v_t_2423})));
      v_t_2427 = heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_246, v_t_2424});
    } else {
      heff_drop(v_field_2421);
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_244, NTAG(TAG_Nil)});
      V v_t_2426 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_2418, heff_dup(v_wb_248), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_243, v_t_2425})));
      v_t_2427 = heff_tag_n(TAG_CondRel, 2, (V[]){v_p_246, v_t_2426});
    }
    V v_t_2429 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam2, 1, 1, (V[]){heff_dup(v_wb_248)}); V a_1 = heff_dup(heff_rfield(v_ce_245, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2430 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2429, heff_dup(heff_rfield(v_ce_245, 5)), heff_dup(v_ce_245)));
    V v_t_2431 = (g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(v_lit_242, v_t_2430));
    V v_t_2433 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam3, 1, 1, (V[]){v_wb_248}); V a_1 = heff_dup(heff_rfield(v_ce_245, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2434 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2433, heff_dup(heff_rfield(v_ce_245, 5)), v_ce_245));
    V v_t_2435 = (g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(v_lit_241, v_t_2434));
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_CIf, 3, (V[]){v_t_2427, v_t_2431, v_t_2435}), NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(v_t_2414, v_t_2436));
  }
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V a_1 = v_wanted_249; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_249); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam1(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wanted_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wanted_2415; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2416); heff_drop(v_wanted_2415); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam2(V self, V *args) {
  V v_v_2428 = args[0];
  V v_wb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2428; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2428); heff_drop(v_wb_248); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_lam3(V self, V *args) {
  V v_v_2432 = args[0];
  V v_wb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2432; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2432); heff_drop(v_wb_248); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3(V v_tok_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_ce_245, V v_p_246, V v_fa_247, V v_wb_248) {
top: ;
  V v_wanted_249 = (g_prelude_2e_2b_2b(heff_dup(v_fa_247), heff_dup(v_wb_248)));
  V v_xs_2412 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam0, 1, 1, (V[]){v_wanted_249}); V a_1 = heff_dup(heff_rfield(v_ce_245, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_245), v_xs_2412));
  V v_t_2414 = (g_list_2emap_24s1796125103x644876049(v_t_2413));
  V v_wanted_2415 = (g_prelude_2e_2b_2b(v_fa_247, heff_dup(v_wb_248)));
  V v_t_2417 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam1, 1, 1, (V[]){v_wanted_2415}); V a_1 = heff_dup(heff_rfield(v_ce_245, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_ce_2418 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2417, heff_dup(v_wb_248), heff_dup(v_ce_245)));
  HeffT2 v_t_2419 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_246));
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    V v_t_2427;
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_sh_2422 = v_field_2421;
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_244, NTAG(TAG_Nil)});
      V v_t_2424 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_2418, heff_dup(v_wb_248), heff_get_n(v_sh_2422, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_243, v_t_2423})));
      v_t_2427 = heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_246, v_t_2424});
    } else {
      heff_drop(v_field_2421);
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_244, NTAG(TAG_Nil)});
      V v_t_2426 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_2418, heff_dup(v_wb_248), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_243, v_t_2425})));
      v_t_2427 = heff_tag_n(TAG_CondRel, 2, (V[]){v_p_246, v_t_2426});
    }
    V v_t_2429 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam2, 1, 1, (V[]){heff_dup(v_wb_248)}); V a_1 = heff_dup(heff_rfield(v_ce_245, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2430 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2429, heff_dup(heff_rfield(v_ce_245, 5)), heff_dup(v_ce_245)));
    V v_t_2431 = (g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(v_lit_242, v_t_2430));
    V v_t_2433 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam3, 1, 1, (V[]){v_wb_248}); V a_1 = heff_dup(heff_rfield(v_ce_245, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2434 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2433, heff_dup(heff_rfield(v_ce_245, 5)), v_ce_245));
    V v_t_2435 = (g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(v_lit_241, v_t_2434));
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_CIf, 3, (V[]){v_t_2427, v_t_2431, v_t_2435}), NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(v_t_2414, v_t_2436));
  }
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V a_1 = v_wanted_249; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_249); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam1(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wanted_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wanted_2415; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2416); heff_drop(v_wanted_2415); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam2(V self, V *args) {
  V v_v_2428 = args[0];
  V v_wb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2428; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2428); heff_drop(v_wb_248); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_24tok3_lam3(V self, V *args) {
  V v_v_2432 = args[0];
  V v_wb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2432; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2432); heff_drop(v_wb_248); r_; });
}