// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayIndex 31774
#define TAG_ArrayLength 32493
#define TAG_BytesAt 9508
#define TAG_BytesEq 9629
#define TAG_BytesFind 30348
#define TAG_BytesHasAt 63051
#define TAG_BytesIntAt 64296
#define TAG_BytesLength 9005
#define TAG_BytesSlice 56752
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FloatOfDecimal 61587
#define TAG_StrByteAt 5424
#define TAG_StrCompare 35677
#define TAG_StrEq 12955
#define TAG_StrEqRange 52111
#define TAG_StrFind 15860
#define TAG_StrHash 2387
#define TAG_StrHashRange 56513
#define TAG_StrLength 43075
#define TAG_StrLt 13175
#define TAG_StrRuneAt 38304
#define TAG_StrRuneDecode 45427
#define TAG_StrRuneWidth 48503
#define TAG_StrSlice 780
V g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0(V, V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0_clo;
Clo g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0_entry, 4, 0};

V g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0(V v_p_240, V v_q_241, V v_go_242, V v_x_243) {
top: ;
  V v_t_2443;
  switch (heff_tag_of(v_x_243)) {
  case TAG_EVar: {
    V v_x_244 = heff_dup(heff_field(v_x_243, 0));
    if (heff_strEq_c_lent(v_p_240, v_x_244, 2)) {
      switch (heff_tag_of(v_q_241)) {
      case TAG_ArrayLength: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_ArrayIndex: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrLength: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrSlice: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrEq: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrLt: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrCompare: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrFind: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrByteAt: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneAt: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneWidth: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesLength: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesAt: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesSlice: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesEq: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesIntAt: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesHasAt: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_BytesFind: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_FloatOfDecimal: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrHash: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrHashRange: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrEqRange: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      case TAG_StrRuneDecode: {
        v_t_2443 = NTAG(TAG_True);
        break;
      }
      default: {
        v_t_2443 = NTAG(TAG_False);
        break;
      }
      }
    } else {
      v_t_2443 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EGlobal: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
    heff_drop(v_go_242);
    heff_drop(v_x_243);
    heff_drop(v_t_2443);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2443);
    return heff_tail(v_go_242, 1, (V[]){v_x_243});
  }
}
V g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eborrow_2eonlyLentCond_2ep_24l0(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}