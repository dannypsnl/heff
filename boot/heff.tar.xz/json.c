// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expected 48537
#define TAG_Failed 62128
#define TAG_Finished 10465
#define TAG_Got 19224
#define TAG_InArray 20296
#define TAG_InObject 18783
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Value 50841
#define LBL_column 592304769
#define LBL_expected 956903529
#define LBL_line 9817275
#define LBL_offset 927361982
static uint32_t shape_offset__line__column__expected[] = {LBL_offset, LBL_line, LBL_column, LBL_expected};
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2edigitsEnd(V, V);
V g_json_2edigitsEnd_entry(V self, V *a);
extern Clo g_json_2edigitsEnd_clo;
V g_json_2edigitsValue(V, V, V, V);
V g_json_2edigitsValue_entry(V self, V *a);
extern Clo g_json_2edigitsValue_clo;
HeffT3 g_json_2eescapeText_24cpr(V, V);
V g_json_2egotIn(V, V, V, V, V);
V g_json_2egotIn_entry(V self, V *a);
extern Clo g_json_2egotIn_clo;
V g_json_2egotIn_24tok2(V, V, V, V, V, V);
V g_json_2egotIn_24tok2_entry(V self, V *a);
extern Clo g_json_2egotIn_24tok2_clo;
V g_json_2ehex4(V, V);
V g_json_2ehex4_entry(V self, V *a);
extern Clo g_json_2ehex4_clo;
V g_json_2ehexValue(V);
V g_json_2ehexValue_entry(V self, V *a);
extern Clo g_json_2ehexValue_clo;
V g_json_2ekeyThen(V, V, V, V);
V g_json_2ekeyThen_entry(V self, V *a);
extern Clo g_json_2ekeyThen_clo;
HeffT2 g_json_2elocated_2epositionFrom_240_24cpr(V, V, V, V, V);
V g_json_2enumberAfterDigits(V, V, V, V);
V g_json_2enumberAfterDigits_entry(V self, V *a);
extern Clo g_json_2enumberAfterDigits_clo;
V g_json_2eplainEnd(V, V);
V g_json_2eplainEnd_entry(V self, V *a);
extern Clo g_json_2eplainEnd_clo;
V g_json_2eskipSpace(V, V);
V g_json_2eskipSpace_entry(V self, V *a);
extern Clo g_json_2eskipSpace_clo;
V g_json_2esteps(V, V);
V g_json_2esteps_entry(V self, V *a);
extern Clo g_json_2esteps_clo;
HeffT2 g_json_2esteps_24cpr(V, V);
V g_json_2esteps_2evalueAt_240(V, V, V);
V g_json_2esteps_2evalueAt_240_entry(V self, V *a);
extern Clo g_json_2esteps_2evalueAt_240_clo;
V g_json_2estringAt_2estringFrom_240(V, V, V, V);
V g_json_2estringAt_2estringFrom_240_entry(V self, V *a);
extern Clo g_json_2estringAt_2estringFrom_240_clo;
HeffT3 g_json_2eunicodeEscape_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_json_2eplainEnd_clo = {{0x80000000u, K_CLO, 0}, g_json_2eplainEnd_entry, 2, 0};

V g_json_2eplainEnd(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if (((((int64_t)32ULL) <= heff_peek_word(v_c_242)) && ((heff_peek_word(v_c_242) < ((int64_t)128ULL)) && ((heff_peek_word(v_c_242) == ((int64_t)34ULL)) ? 0 : !(heff_peek_word(v_c_242) == ((int64_t)92ULL)))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    if ((((int64_t)128ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
      HeffT2 v_t_243 = heff_strRuneDecode_lent(v_s_240, v_i_241, 0);
      {
        V v_rune_244 = v_t_243.f[0];
        V v_width_245 = v_t_243.f[1];
        V v_t_246 = heff_runeToInt(heff_dup(v_rune_244));
        V v_t_247;
        if (heff_intEq_c(v_t_246, heff_runeToInt(MK_INT(65533LL)))) {
          v_t_247 = MK_INT(0LL);
        } else {
          v_t_247 = heff_dup(v_width_245);
        }
        if (heff_intLt_c(MK_INT(0LL), v_t_247)) {
          V v_t_248 = v_rune_244;
          V v_t_249;
          if (heff_intEq_c(heff_runeToInt(v_t_248), heff_runeToInt(MK_INT(65533LL)))) {
            heff_drop(v_width_245);
            v_t_249 = MK_INT(0LL);
          } else {
            v_t_249 = v_width_245;
          }
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, v_t_249);
          v_s_240 = t_0;
          v_i_241 = t_1;
          goto top;
        } else {
          heff_drop(v_rune_244);
          heff_drop(v_width_245);
          return v_i_241;
        }
      }
    } else {
      return v_i_241;
    }
  }
}
V g_json_2eplainEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2eplainEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_json_2eskipSpace_clo = {{0x80000000u, K_CLO, 0}, g_json_2eskipSpace_entry, 2, 0};

V g_json_2eskipSpace(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if (((heff_peek_word(v_c_242) == ((int64_t)32ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)10ULL)) || ((heff_peek_word(v_c_242) == ((int64_t)13ULL)) || (heff_peek_word(v_c_242) == ((int64_t)9ULL)))))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    return v_i_241;
  }
}
V g_json_2eskipSpace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2eskipSpace(a0, a[1]); heff_drop(a0); return r;
}
Clo g_json_2edigitsEnd_clo = {{0x80000000u, K_CLO, 0}, g_json_2edigitsEnd_entry, 2, 0};

V g_json_2edigitsEnd(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if (((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL)))) {
    heff_drop(v_c_242);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    heff_drop(v_c_242);
    return v_i_241;
  }
}
V g_json_2edigitsEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2edigitsEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_json_2edigitsValue_clo = {{0x80000000u, K_CLO, 0}, g_json_2edigitsValue_entry, 4, 0};

V g_json_2edigitsValue(V v_s_240, V v_i_241, V v_j_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_j_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    return v_acc_243;
  } else {
    V v_t_244 = heff_intAdd(heff_intMul(v_acc_243, MK_INT(10LL)), heff_strByteAt_lent(v_s_240, v_i_241, 0));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_j_242;
    V t_3 = heff_intSub(v_t_244, MK_INT(48LL));
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_j_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_json_2edigitsValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_json_2edigitsValue(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_json_2enumberAfterDigits_str0, 7, "a digit");
HEFF_LIT(g_json_2enumberAfterDigits_str1, 7, "a digit");
Clo g_json_2enumberAfterDigits_clo = {{0x80000000u, K_CLO, 0}, g_json_2enumberAfterDigits_entry, 4, 0};

V g_json_2enumberAfterDigits(V v_s_240, V v_start_241, V v_d_242, V v_p_243) {
top: ;
  V v_f_244;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_p_243, 0)) == ((int64_t)46ULL))) {
    v_f_244 = (g_json_2edigitsEnd(v_s_240, heff_intAdd_lent(v_p_243, MK_INT(1LL), 2)));
  } else {
    v_f_244 = heff_dup(v_p_243);
  }
  V v_hasExponent_245 = heff_bool(((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_f_244, 0)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_f_244, 0)) == ((int64_t)69ULL))));
  V v_end_247;
  if ((heff_dup(v_hasExponent_245) == NTAG(TAG_True))) {
    V v_i_246 = heff_intAdd_lent(v_f_244, MK_INT(1LL), 2);
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_246, 0)) == ((int64_t)43ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_246, 0)) == ((int64_t)45ULL)))) {
      v_end_247 = (g_json_2edigitsEnd(v_s_240, heff_intAdd(v_i_246, MK_INT(1LL))));
    } else {
      v_end_247 = (g_json_2edigitsEnd(v_s_240, v_i_246));
    }
  } else {
    v_end_247 = heff_dup(v_f_244);
  }
  if (heff_intEq_c_lent(v_f_244, heff_intAdd_lent(v_p_243, MK_INT(1LL), 2), 2)) {
    heff_drop(v_d_242);
    heff_drop(v_p_243);
    heff_drop(v_hasExponent_245);
    heff_drop(v_end_247);
    return heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_f_244, ((V)&g_json_2enumberAfterDigits_str0)})});
  } else {
    if ((heff_dup(v_hasExponent_245) == NTAG(TAG_True))) {
      V v_c_248 = heff_strByteAt_lent(v_s_240, heff_intSub_lent(v_end_247, MK_INT(1LL), 2), 2);
      if (((((int64_t)48ULL) <= heff_peek_word(v_c_248)) ? !(heff_peek_word(v_c_248) <= ((int64_t)57ULL)) : 1)) {
        heff_drop(v_d_242);
        heff_drop(v_p_243);
        heff_drop(v_f_244);
        heff_drop(v_hasExponent_245);
        heff_drop(v_c_248);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_end_247, ((V)&g_json_2enumberAfterDigits_str1)})});
      } else {
        heff_drop(v_c_248);
        if ((heff_intEq_c_lent(v_f_244, v_p_243, 0) && !(heff_dup(v_hasExponent_245) == NTAG(TAG_True)))) {
          heff_drop(v_f_244);
          heff_drop(v_hasExponent_245);
          V v_n_249 = ({ V a_0 = v_s_240; V a_1 = v_d_242; V a_2 = v_p_243; V a_3 = MK_INT(0LL); V r_ = (g_json_2edigitsValue(a_0, a_1, a_2, a_3)); heff_drop(v_p_243); r_; });
          V v_t_2410;
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_start_241, 0)) == ((int64_t)45ULL))) {
            v_t_2410 = heff_intSub(MK_INT(0LL), v_n_249);
          } else {
            v_t_2410 = v_n_249;
          }
          V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_JInt, 1, (V[]){v_t_2410}), v_end_247});
          return heff_tag_n(TAG_Right, 1, (V[]){v_t_2411});
        } else {
          heff_drop(v_d_242);
          heff_drop(v_p_243);
          heff_drop(v_f_244);
          heff_drop(v_hasExponent_245);
          V v_t_2412 = heff_tag_nf(TAG_JFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(heff_floatOfDecimal_lent(MK_INT(64LL), v_s_240, v_start_241, v_end_247, 1)))});
          return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_end_247})});
        }
      }
    } else {
      if ((heff_intEq_c_lent(v_f_244, v_p_243, 0) && !(heff_dup(v_hasExponent_245) == NTAG(TAG_True)))) {
        heff_drop(v_f_244);
        heff_drop(v_hasExponent_245);
        V v_n_2413 = ({ V a_0 = v_s_240; V a_1 = v_d_242; V a_2 = v_p_243; V a_3 = MK_INT(0LL); V r_ = (g_json_2edigitsValue(a_0, a_1, a_2, a_3)); heff_drop(v_p_243); r_; });
        V v_t_2414;
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_start_241, 0)) == ((int64_t)45ULL))) {
          v_t_2414 = heff_intSub(MK_INT(0LL), v_n_2413);
        } else {
          v_t_2414 = v_n_2413;
        }
        V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_JInt, 1, (V[]){v_t_2414}), v_end_247});
        return heff_tag_n(TAG_Right, 1, (V[]){v_t_2415});
      } else {
        heff_drop(v_d_242);
        heff_drop(v_p_243);
        heff_drop(v_f_244);
        heff_drop(v_hasExponent_245);
        V v_t_2416 = heff_tag_nf(TAG_JFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(heff_floatOfDecimal_lent(MK_INT(64LL), v_s_240, v_start_241, v_end_247, 1)))});
        return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_end_247})});
      }
    }
  }
}
V g_json_2enumberAfterDigits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_json_2enumberAfterDigits(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_json_2ehexValue_clo = {{0x80000000u, K_CLO, 0}, g_json_2ehexValue_entry, 1, 0};

V g_json_2ehexValue(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if (((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) {
    return heff_box_word((v_c_240 - ((int64_t)48ULL)));
  } else {
    if (((((int64_t)97ULL) <= v_c_240) && (v_c_240 <= ((int64_t)102ULL)))) {
      return heff_box_word((v_c_240 - ((int64_t)87ULL)));
    } else {
      if (((((int64_t)65ULL) <= v_c_240) && (v_c_240 <= ((int64_t)70ULL)))) {
        return heff_box_word((v_c_240 - ((int64_t)55ULL)));
      } else {
        return MK_INT(-65536LL);
      }
    }
  }
}
V g_json_2ehexValue_entry(V self, V *a) {
  (void)self;
  return g_json_2ehexValue(a[0]);
}
Clo g_json_2ehex4_clo = {{0x80000000u, K_CLO, 0}, g_json_2ehex4_entry, 2, 0};

V g_json_2ehex4(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = (g_json_2ehexValue(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
  V v_t_243 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
  V v_t_244 = (g_json_2ehexValue(v_t_243));
  V v_t_245 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(2LL), 2), 2);
  V v_t_246 = (g_json_2ehexValue(v_t_245));
  V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(v_i_241, MK_INT(3LL)));
  V v_t_248 = (g_json_2ehexValue(v_t_247));
  V v_t_249 = heff_intAdd(heff_intMul(v_t_242, MK_INT(4096LL)), heff_intMul(v_t_244, MK_INT(256LL)));
  V v_t_2410 = heff_intAdd(v_t_249, heff_intMul(v_t_246, MK_INT(16LL)));
  return heff_intAdd(v_t_2410, v_t_248);
}
V g_json_2ehex4_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2ehex4(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_json_2eunicodeEscape_24cpr_str0, 23, "four hexadecimal digits");

HeffT3 g_json_2eunicodeEscape_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = (g_json_2ehex4(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2)));
  V v_lo_243 = (g_json_2ehex4(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(7LL), 2)));
  if (heff_intLt_c_lent(v_c_242, MK_INT(0LL), 2)) {
    heff_drop(v_c_242);
    heff_drop(v_lo_243);
    V v_f_244 = heff_intAdd(v_i_241, MK_INT(1LL));
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_244, ((V)&g_json_2eunicodeEscape_24cpr_str0)}});
  } else {
    if ((heff_intLe_c_lent(MK_INT(55296LL), v_c_242, 1) && (heff_intLt_c_lent(v_c_242, MK_INT(56320LL), 2) && ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(5LL), 2), 2)) == ((int64_t)92ULL)) && ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(6LL), 2), 2)) == ((int64_t)117ULL)) && (heff_intLe_c_lent(MK_INT(56320LL), v_lo_243, 1) && heff_intLt_c_lent(v_lo_243, MK_INT(57344LL), 2))))))) {
      int64_t v_t_245 = ((heff_unbox_word(v_c_242) - ((int64_t)55296ULL)) * ((int64_t)1024ULL));
      int64_t v_t_246 = ((((int64_t)65536ULL) + v_t_245) + (heff_unbox_word(v_lo_243) - ((int64_t)56320ULL)));
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(heff_box_word(v_t_246)), NTAG(TAG_Nil)});
      V v_f_248 = heff_strOfRunes(v_t_247);
      V v_f_249 = heff_intAdd(v_i_241, MK_INT(11LL));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_248, v_f_249}});
    } else {
      heff_drop(v_lo_243);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_c_242), NTAG(TAG_Nil)});
      V v_f_2411 = heff_strOfRunes(v_t_2410);
      V v_f_2412 = heff_intAdd(v_i_241, MK_INT(5LL));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2411, v_f_2412}});
    }
  }
}
HEFF_LIT(g_json_2eescapeText_24cpr_str0, 1, "\"");
HEFF_LIT(g_json_2eescapeText_24cpr_str1, 1, "\\");
HEFF_LIT(g_json_2eescapeText_24cpr_str2, 1, "/");
HEFF_LIT(g_json_2eescapeText_24cpr_str3, 1, "\012");
HEFF_LIT(g_json_2eescapeText_24cpr_str4, 1, "\011");
HEFF_LIT(g_json_2eescapeText_24cpr_str5, 1, "\015");
HEFF_LIT(g_json_2eescapeText_24cpr_str6, 1, "\010");
HEFF_LIT(g_json_2eescapeText_24cpr_str7, 1, "\014");
HEFF_LIT(g_json_2eescapeText_24cpr_str8, 9, "an escape");

HeffT3 g_json_2eescapeText_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if ((heff_peek_word(v_c_242) == ((int64_t)34ULL))) {
    heff_drop(v_c_242);
    V v_f_243 = heff_intAdd(v_i_241, MK_INT(1LL));
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), ((V)&g_json_2eescapeText_24cpr_str0), v_f_243}});
  } else {
    if ((heff_peek_word(v_c_242) == ((int64_t)92ULL))) {
      heff_drop(v_c_242);
      V v_f_244 = heff_intAdd(v_i_241, MK_INT(1LL));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), ((V)&g_json_2eescapeText_24cpr_str1), v_f_244}});
    } else {
      if ((heff_peek_word(v_c_242) == ((int64_t)47ULL))) {
        heff_drop(v_c_242);
        V v_f_245 = heff_intAdd(v_i_241, MK_INT(1LL));
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), ((V)&g_json_2eescapeText_24cpr_str2), v_f_245}});
      } else {
        if ((heff_peek_word(v_c_242) == ((int64_t)110ULL))) {
          heff_drop(v_c_242);
          V v_f_246 = heff_intAdd(v_i_241, MK_INT(1LL));
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), ((V)&g_json_2eescapeText_24cpr_str3), v_f_246}});
        } else {
          if ((heff_peek_word(v_c_242) == ((int64_t)116ULL))) {
            heff_drop(v_c_242);
            V v_f_247 = heff_intAdd(v_i_241, MK_INT(1LL));
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), ((V)&g_json_2eescapeText_24cpr_str4), v_f_247}});
          } else {
            if ((heff_peek_word(v_c_242) == ((int64_t)114ULL))) {
              heff_drop(v_c_242);
              V v_f_248 = heff_intAdd(v_i_241, MK_INT(1LL));
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), ((V)&g_json_2eescapeText_24cpr_str5), v_f_248}});
            } else {
              if ((heff_peek_word(v_c_242) == ((int64_t)98ULL))) {
                heff_drop(v_c_242);
                V v_f_249 = heff_intAdd(v_i_241, MK_INT(1LL));
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), ((V)&g_json_2eescapeText_24cpr_str6), v_f_249}});
              } else {
                if ((heff_peek_word(v_c_242) == ((int64_t)102ULL))) {
                  heff_drop(v_c_242);
                  V v_f_2410 = heff_intAdd(v_i_241, MK_INT(1LL));
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), ((V)&g_json_2eescapeText_24cpr_str7), v_f_2410}});
                } else {
                  if ((heff_unbox_word(v_c_242) == ((int64_t)117ULL))) {
                    HEFF_LAST return g_json_2eunicodeEscape_24cpr(v_s_240, v_i_241);
                  } else {
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_241, ((V)&g_json_2eescapeText_24cpr_str8)}});
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_json_2ekeyThen_str0, 0, "");
HEFF_LIT(g_json_2ekeyThen_str1, 8, "a string");
HEFF_LIT(g_json_2ekeyThen_str2, 3, "':'");
HEFF_LIT(g_json_2ekeyThen_str3, 8, "a string");
Clo g_json_2ekeyThen_clo = {{0x80000000u, K_CLO, 0}, g_json_2ekeyThen_entry, 4, 0};

V g_json_2ekeyThen(V v_s_240, V v_i_241, V v_fs_242, V v_frames_243) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
    V v_s_244 = heff_dup(v_s_240);
    V v_fs_245 = v_fs_242;
    V v_frames_246 = v_frames_243;
    V v_x4_247;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
      v_x4_247 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd_lent(v_i_241, MK_INT(1LL), 2); V a_2 = heff_intAdd(v_i_241, MK_INT(1LL)); V a_3 = ((V)&g_json_2ekeyThen_str0); V r_ = (g_json_2estringAt_2estringFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_s_240); r_; });
    } else {
      heff_drop(v_s_240);
      v_x4_247 = heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2ekeyThen_str1)})});
    }
    switch (heff_tag_of(v_x4_247)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x4_247, 0);
      V v_ru_24x4_247_24Left = heff_take_reuse_n(v_x4_247, 1ULL, 1);
      heff_drop(v_s_244);
      heff_drop(v_fs_245);
      heff_drop(v_frames_246);
      return heff_tag_at_n(v_ru_24x4_247_24Left, TAG_Failed, 1, (V[]){v_e_248});
    }
    case TAG_Right: {
      V v_x41_249 = heff_field(v_x4_247, 0);
      V v_ru_24x4_247_24Right = heff_take_reuse_n(v_x4_247, 1ULL, 1);
      switch (heff_tag_of(v_x41_249)) {
      case TAG_MkPair: {
        V v_k_2410 = heff_field(v_x41_249, 0);
        V v_j_2411 = heff_field(v_x41_249, 1);
        V v_ru_24x41_249_24MkPair = heff_take_reuse_n(v_x41_249, 3ULL, 2);
        V v_c_2412 = (g_json_2eskipSpace(v_s_244, v_j_2411));
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_244, v_c_2412, 1)) == ((int64_t)58ULL))) {
          heff_drop_cell(v_ru_24x4_247_24Right, 1);
          V v_t_2413 = heff_tag_at_n(v_ru_24x41_249_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_InObject, 2, (V[]){v_fs_245, v_k_2410}), v_frames_246});
          return heff_tag_n(TAG_Value, 2, (V[]){heff_intAdd(v_c_2412, MK_INT(1LL)), v_t_2413});
        } else {
          heff_drop(v_fs_245);
          heff_drop(v_frames_246);
          heff_drop(v_k_2410);
          return heff_tag_at_n(v_ru_24x4_247_24Right, TAG_Failed, 1, (V[]){heff_tag_at_n(v_ru_24x41_249_24MkPair, TAG_Expected, 2, (V[]){v_c_2412, ((V)&g_json_2ekeyThen_str2)})});
        }
      }
      default: return heff_nomatch(v_x41_249);
      }
    }
    default: return heff_nomatch(v_x4_247);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_fs_242);
    heff_drop(v_frames_243);
    return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2ekeyThen_str3)})});
  }
}
V g_json_2ekeyThen_entry(V self, V *a) {
  (void)self;
  return g_json_2ekeyThen(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_json_2egotIn_str0, 10, "',' or ']'");
HEFF_LIT(g_json_2egotIn_str1, 10, "',' or '}'");
Clo g_json_2egotIn_clo = {{0x80000000u, K_CLO, 0}, g_json_2egotIn_entry, 5, 0};

V g_json_2egotIn(V v_s_240, V v_v_241, V v_i_242, V v_x4_243, V v_frames_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_InArray: {
    V v_xs_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24InArray = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)44ULL))) {
      heff_drop(v_s_240);
      V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24InArray, TAG_InArray, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_v_241, v_xs_245})});
      return heff_tag_n(TAG_Value, 2, (V[]){heff_intAdd(v_i_242, MK_INT(1LL)), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_frames_244})});
    } else {
      heff_drop_cell(v_ru_24x4_243_24InArray, 1);
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 1)) == ((int64_t)93ULL))) {
        V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_v_241, v_xs_245})));
        return heff_tag_n(TAG_Got, 3, (V[]){heff_tag_n(TAG_JArray, 1, (V[]){v_t_247}), heff_intAdd(v_i_242, MK_INT(1LL)), v_frames_244});
      } else {
        heff_drop(v_v_241);
        heff_drop(v_frames_244);
        heff_drop(v_xs_245);
        return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_242, ((V)&g_json_2egotIn_str0)})});
      }
    }
  }
  case TAG_InObject: {
    V v_fs_248 = heff_field(v_x4_243, 0);
    V v_k_249 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24InObject = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 0)) == ((int64_t)44ULL))) {
      V v_t_2410 = (g_json_2eskipSpace(v_s_240, heff_intAdd(v_i_242, MK_INT(1LL))));
      V v_t_2411 = heff_tag_at_n(v_ru_24x4_243_24InObject, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_249, v_v_241}), v_fs_248});
      return (g_json_2ekeyThen(v_s_240, v_t_2410, v_t_2411, v_frames_244));
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_242, 1)) == ((int64_t)125ULL))) {
        V v_t_2412 = heff_tag_at_n(v_ru_24x4_243_24InObject, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_249, v_v_241}), v_fs_248});
        V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2412));
        return heff_tag_n(TAG_Got, 3, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2413}), heff_intAdd(v_i_242, MK_INT(1LL)), v_frames_244});
      } else {
        heff_drop(v_v_241);
        heff_drop(v_frames_244);
        heff_drop(v_fs_248);
        heff_drop(v_k_249);
        return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24InObject, TAG_Expected, 2, (V[]){v_i_242, ((V)&g_json_2egotIn_str1)})});
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_json_2egotIn_entry(V self, V *a) {
  (void)self;
  return g_json_2egotIn(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_json_2esteps_24cpr_str0, 7, "the end");

HeffT2 g_json_2esteps_24cpr(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Value: {
    V v_i_242 = heff_field(v_x2_241, 0);
    V v_frames_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_json_2eskipSpace(v_s_240, v_i_242));
    V v_t_245 = (g_json_2esteps_2evalueAt_240(heff_dup(v_s_240), v_t_244, v_frames_243));
    V t_0 = v_s_240;
    V t_1 = v_t_245;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_Got: {
    V v_v_246 = heff_field(v_x2_241, 0);
    V v_i_247 = heff_field(v_x2_241, 1);
    V v_frames_248 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_s_249 = heff_dup(v_s_240);
    V v_v_2410 = v_v_246;
    V v_i_2411 = (g_json_2eskipSpace(v_s_240, v_i_247));
    V v_x3_2412 = v_frames_248;
    V v_t_2415;
    switch (heff_tag_of(v_x3_2412)) {
    case TAG_Nil: {
      if (heff_intLe_c(heff_strLength(v_s_249), heff_dup(v_i_2411))) {
        heff_drop(v_i_2411);
        v_t_2415 = heff_tag_n(TAG_Finished, 1, (V[]){v_v_2410});
      } else {
        heff_drop(v_v_2410);
        v_t_2415 = heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_2411, ((V)&g_json_2esteps_24cpr_str0)})});
      }
      break;
    }
    case TAG_Cons: {
      V v_f_2413 = heff_field(v_x3_2412, 0);
      V v_frames_2414 = heff_field(v_x3_2412, 1);
      V v_ru_24x3_2412_24Cons = heff_take_reuse_n(v_x3_2412, 3ULL, 2);
      v_t_2415 = (g_json_2egotIn_24tok2(v_ru_24x3_2412_24Cons, v_s_249, v_v_2410, v_i_2411, v_f_2413, v_frames_2414));
      break;
    }
    default: heff_nomatch(v_x3_2412);
    }
    V t_0 = v_s_240;
    V t_1 = v_t_2415;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_Finished: {
    V v_v_2416 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_v_2416}});
  }
  case TAG_Failed: {
    V v_e_2417 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_e_2417)) {
    case TAG_Expected: {
      V v_i_2418 = heff_field(v_e_2417, 0);
      V v_what_2419 = heff_field(v_e_2417, 1);
      heff_take_n(v_e_2417, 3ULL, 2);
      HeffT2 v_t_2420 = (g_json_2elocated_2epositionFrom_240_24cpr(v_i_2418, v_s_240, MK_INT(0LL), MK_INT(1LL), MK_INT(1LL)));
      {
        V v_field_2421 = v_t_2420.f[0];
        V v_field_2422 = v_t_2420.f[1];
        V v_x_2423 = heff_dup(v_field_2421);
        V v_y_2424 = heff_dup(v_field_2422);
        heff_drop(v_y_2424);
        V v_t_2425 = v_x_2423;
        V v_x_2426 = v_field_2421;
        heff_drop(v_x_2426);
        V v_y_2427 = v_field_2422;
        V v_t_2428 = v_y_2427;
        v_t_2429 = heff_rec_n(4, shape_offset__line__column__expected, (V[]){v_i_2418, v_t_2425, v_t_2428, v_what_2419});
      }
      break;
    }
    default: heff_nomatch(v_e_2417);
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2429}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_json_2esteps_clo = {{0x80000000u, K_CLO, 0}, g_json_2esteps_entry, 2, 0};

V g_json_2esteps(V v_s_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_json_2esteps_24cpr(v_s_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_244});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_244});
    }
  }
}
V g_json_2esteps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2esteps(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_json_2eat_24cpr(V v_x1_240, V v_j_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_j_241}});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_ks_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_j_241)) {
    case TAG_JNull: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_JBool: {
      heff_take_n(v_j_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_JInt: {
      heff_take_n(v_j_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_JFloat: {
      heff_take_na(v_j_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_JString: {
      heff_take_n(v_j_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_JArray: {
      heff_take_n(v_j_241, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_JObject: {
      V v_fs_249 = heff_field(v_j_241, 0);
      heff_take_n(v_j_241, 1ULL, 1);
      HeffT2 v_t_2410 = ({ V a_0 = v_k_242; V a_1 = v_fs_249; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_p_2413 = v_field_2412;
          V v_t_2416;
          switch (heff_tag_of(v_p_2413)) {
          case TAG_MkPair: {
            V v_y_2415 = heff_field(v_p_2413, 1);
            heff_take_n(v_p_2413, 2ULL, 2);
            v_t_2416 = v_y_2415;
            break;
          }
          default: heff_nomatch(v_p_2413);
          }
          V t_0 = v_ks_243;
          V t_1 = v_t_2416;
          v_x1_240 = t_0;
          v_j_241 = t_1;
          goto top;
        } else {
          heff_drop(v_field_2412);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_j_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_json_2egotIn_24tok2_str0, 10, "',' or ']'");
HEFF_LIT(g_json_2egotIn_24tok2_str1, 10, "',' or '}'");
Clo g_json_2egotIn_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_json_2egotIn_24tok2_entry, 6, 0};

V g_json_2egotIn_24tok2(V v_tok_240, V v_s_241, V v_v_242, V v_i_243, V v_x4_244, V v_frames_245) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_InArray: {
    V v_xs_246 = heff_field(v_x4_244, 0);
    V v_ru_24x4_244_24InArray = heff_take_reuse_n(v_x4_244, 1ULL, 1);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == ((int64_t)44ULL))) {
      heff_drop(v_s_241);
      V v_t_247 = heff_tag_at_n(v_ru_24x4_244_24InArray, TAG_InArray, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_v_242, v_xs_246})});
      return heff_tag_n(TAG_Value, 2, (V[]){heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_frames_245})});
    } else {
      heff_drop_cell(v_ru_24x4_244_24InArray, 1);
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 1)) == ((int64_t)93ULL))) {
        V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_v_242, v_xs_246})));
        return heff_tag_n(TAG_Got, 3, (V[]){heff_tag_n(TAG_JArray, 1, (V[]){v_t_248}), heff_intAdd(v_i_243, MK_INT(1LL)), v_frames_245});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_frames_245);
        heff_drop(v_xs_246);
        return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_Expected, 2, (V[]){v_i_243, ((V)&g_json_2egotIn_24tok2_str0)})});
      }
    }
  }
  case TAG_InObject: {
    V v_fs_249 = heff_field(v_x4_244, 0);
    V v_k_2410 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24InObject = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 0)) == ((int64_t)44ULL))) {
      V v_t_2411 = (g_json_2eskipSpace(v_s_241, heff_intAdd(v_i_243, MK_INT(1LL))));
      V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_244_24InObject, TAG_MkPair, 2, (V[]){v_k_2410, v_v_242}), v_fs_249});
      return (g_json_2ekeyThen(v_s_241, v_t_2411, v_t_2412, v_frames_245));
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, v_i_243, 1)) == ((int64_t)125ULL))) {
        V v_t_2413 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_244_24InObject, TAG_MkPair, 2, (V[]){v_k_2410, v_v_242}), v_fs_249});
        V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2413));
        return heff_tag_n(TAG_Got, 3, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2414}), heff_intAdd(v_i_243, MK_INT(1LL)), v_frames_245});
      } else {
        heff_drop(v_v_242);
        heff_drop(v_frames_245);
        heff_drop(v_fs_249);
        heff_drop(v_k_2410);
        heff_drop_cell(v_ru_24x4_244_24InObject, 2);
        return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_Expected, 2, (V[]){v_i_243, ((V)&g_json_2egotIn_24tok2_str1)})});
      }
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_json_2egotIn_24tok2_entry(V self, V *a) {
  (void)self;
  return g_json_2egotIn_24tok2(a[0], a[1], a[2], a[3], a[4], a[5]);
}