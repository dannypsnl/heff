// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CloseFile 52884
#define TAG_Copy 17796
#define TAG_FileStatus 2909
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_Move 53768
#define TAG_OpenPath 44468
#define TAG_PathStatus 29154
#define TAG_ReadChunk 39695
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_ReadLine 54539
#define TAG_ReadLink 54545
#define TAG_ReadOnly 17623
#define TAG_RealPath 18882
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Seek 25805
#define TAG_SetMode 203
#define TAG_Standard 18554
#define TAG_StandardPort 63523
#define TAG_TemporaryDirectory 61563
#define TAG_TemporaryFile 11955
#define TAG_Writable 11315
#define TAG_WriteBytes 40855
#define TAG_WriteFile 62589
#define TAG_WriteString 34128
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_exception_2eattempted_24s588401679x1225922520_get(void);
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465(V);
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s141698176x1512134465_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2efilesystem_2efilesystem_lam1(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam2(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam3(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam4(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam5(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam6(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam7(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam8(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam9(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam10(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam11(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam12(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam13(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam14(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam15(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam16(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam17(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam18(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam19(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam20(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam21(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam22(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam23(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam24(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam25(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam26(V self, V *args);
V g_std_2efilesystem_2efilesystem_lam0(V self, V *args); static Clo g_std_2efilesystem_2efilesystem_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efilesystem_lam0, 3, 0};
V g_std_2efilesystem_2efilesystem_lam27(V self, V *args); static Clo g_std_2efilesystem_2efilesystem_lam27_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efilesystem_lam27, 4, 0};

static V g_std_2efilesystem_2efilesystem_val;
static HEFF_ONCE g_std_2efilesystem_2efilesystem_st;
static V g_std_2efilesystem_2efilesystem_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2efilesystem_2efilesystem_lam0_clo), ((V)&g_std_2efilesystem_2efilesystem_lam27_clo)});
}
V g_std_2efilesystem_2efilesystem_get(void) {
  if (HEFF_DONE(g_std_2efilesystem_2efilesystem_st)) return g_std_2efilesystem_2efilesystem_val;
  return heff_global(&g_std_2efilesystem_2efilesystem_val, &g_std_2efilesystem_2efilesystem_st, g_std_2efilesystem_2efilesystem_init);
}
V g_std_2efilesystem_2efilesystem_lam1(V self, V *args) {
  V v_t_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_t_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam2(V self, V *args) {
  V v_ok_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tr(heff_call(v_k_249, 1, (V[]){v_ok_2410}));
  V f_ = v_g_241;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam3(V self, V *args) {
  V v_ok_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_ok_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam4(V self, V *args) {
  V v_ns_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_ns_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam5(V self, V *args) {
  V v_ok_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_k_2421, 1, (V[]){v_ok_2422}));
  V f_ = v_g_241;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam6(V self, V *args) {
  V v_ok_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_k_2425, 1, (V[]){v_ok_2426}));
  V f_ = v_g_241;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam7(V self, V *args) {
  V v_ok_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_call(v_k_2430, 1, (V[]){v_ok_2431}));
  V f_ = v_g_241;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam8(V self, V *args) {
  V v_ok_2436 = args[0];
  V v_k_2435 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tr(heff_call(v_k_2435, 1, (V[]){v_ok_2436}));
  V f_ = v_g_241;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam9(V self, V *args) {
  V v_ok_2441 = args[0];
  V v_k_2440 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_tr(heff_call(v_k_2440, 1, (V[]){v_ok_2441}));
  V f_ = v_g_241;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam10(V self, V *args) {
  V v_ok_2445 = args[0];
  V v_k_2444 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tr(heff_call(v_k_2444, 1, (V[]){v_ok_2445}));
  V f_ = v_g_241;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam11(V self, V *args) {
  V v_r_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_tr(heff_call(v_k_2449, 1, (V[]){v_r_2450}));
  V f_ = v_g_241;
  args[0] = v_t_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam12(V self, V *args) {
  V v_r_2455 = args[0];
  V v_k_2454 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = heff_tr(heff_call(v_k_2454, 1, (V[]){v_r_2455}));
  V f_ = v_g_241;
  args[0] = v_t_2456;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam13(V self, V *args) {
  V v_r_2459 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2460 = heff_tr(heff_call(v_k_2458, 1, (V[]){v_r_2459}));
  V f_ = v_g_241;
  args[0] = v_t_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam14(V self, V *args) {
  V v_r_2463 = args[0];
  V v_k_2462 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = heff_tr(heff_call(v_k_2462, 1, (V[]){v_r_2463}));
  V f_ = v_g_241;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam15(V self, V *args) {
  V v_r_2467 = args[0];
  V v_k_2466 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = heff_tr(heff_call(v_k_2466, 1, (V[]){v_r_2467}));
  V f_ = v_g_241;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam16(V self, V *args) {
  V v_r_2471 = args[0];
  V v_k_2470 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2472 = heff_tr(heff_call(v_k_2470, 1, (V[]){v_r_2471}));
  V f_ = v_g_241;
  args[0] = v_t_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam17(V self, V *args) {
  V v_r_2480 = args[0];
  V v_k_2479 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2481 = heff_tr(heff_call(v_k_2479, 1, (V[]){v_r_2480}));
  V f_ = v_g_241;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam18(V self, V *args) {
  V v_h_2484 = args[0];
  V v_k_2483 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_tr(heff_call(v_k_2483, 1, (V[]){v_h_2484}));
  V f_ = v_g_241;
  args[0] = v_t_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam19(V self, V *args) {
  V v_h_2488 = args[0];
  V v_k_2487 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2489 = heff_tr(heff_call(v_k_2487, 1, (V[]){v_h_2488}));
  V f_ = v_g_241;
  args[0] = v_t_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam20(V self, V *args) {
  V v_r_2493 = args[0];
  V v_k_2492 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2494 = heff_tr(heff_call(v_k_2492, 1, (V[]){v_r_2493}));
  V f_ = v_g_241;
  args[0] = v_t_2494;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam21(V self, V *args) {
  V v_r_2497 = args[0];
  V v_k_2496 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2498 = heff_tr(heff_call(v_k_2496, 1, (V[]){v_r_2497}));
  V f_ = v_g_241;
  args[0] = v_t_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam22(V self, V *args) {
  V v_r_24102 = args[0];
  V v_k_24101 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24103 = heff_tr(heff_call(v_k_24101, 1, (V[]){v_r_24102}));
  V f_ = v_g_241;
  args[0] = v_t_24103;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam23(V self, V *args) {
  V v_r_24107 = args[0];
  V v_k_24106 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24108 = heff_tr(heff_call(v_k_24106, 1, (V[]){v_r_24107}));
  V f_ = v_g_241;
  args[0] = v_t_24108;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam24(V self, V *args) {
  V v_r_24113 = args[0];
  V v_k_24112 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24114 = heff_tr(heff_call(v_k_24112, 1, (V[]){v_r_24113}));
  V f_ = v_g_241;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam25(V self, V *args) {
  V v_r_24117 = args[0];
  V v_k_24116 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24118 = heff_tr(heff_call(v_k_24116, 1, (V[]){v_r_24117}));
  V f_ = v_g_241;
  args[0] = v_t_24118;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam26(V self, V *args) {
  V v_r_24121 = args[0];
  V v_k_24120 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24122 = heff_tr(heff_call(v_k_24120, 1, (V[]){v_r_24121}));
  V f_ = v_g_241;
  args[0] = v_t_24122;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efilesystem_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_ReadFile: {
    V v_path_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24ReadFile, TAG_ReadFile, 2, 1ULL, (V[]){v_path_243, heff_clo_n(g_std_2efilesystem_2efilesystem_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_WriteFile: {
    V v_path_247 = heff_field(v_p_242, 0);
    V v_str_248 = heff_field(v_p_242, 1);
    V v_k_249 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteFile = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24WriteFile, TAG_WriteFile, 3, 3ULL, (V[]){v_path_247, v_str_248, heff_clo_n(g_std_2efilesystem_2efilesystem_lam2, 1, 2, (V[]){v_k_249, v_g_241})});
  }
  case TAG_MakeDirectory: {
    V v_path_2412 = heff_field(v_p_242, 0);
    V v_k_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24MakeDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24MakeDirectory, TAG_MakeDirectory, 2, 1ULL, (V[]){v_path_2412, heff_clo_n(g_std_2efilesystem_2efilesystem_lam3, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_ReadDirectory: {
    V v_path_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24ReadDirectory, TAG_ReadDirectory, 2, 1ULL, (V[]){v_path_2416, heff_clo_n(g_std_2efilesystem_2efilesystem_lam4, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_Remove: {
    V v_path_2420 = heff_field(v_p_242, 0);
    V v_k_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Remove = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24Remove, TAG_Remove, 2, 1ULL, (V[]){v_path_2420, heff_clo_n(g_std_2efilesystem_2efilesystem_lam5, 1, 2, (V[]){v_k_2421, v_g_241})});
  }
  case TAG_ReadOnly: {
    V v_path_2424 = heff_field(v_p_242, 0);
    V v_k_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadOnly = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24ReadOnly, TAG_ReadOnly, 2, 1ULL, (V[]){v_path_2424, heff_clo_n(g_std_2efilesystem_2efilesystem_lam6, 1, 2, (V[]){v_k_2425, v_g_241})});
  }
  case TAG_Copy: {
    V v_path_2428 = heff_field(v_p_242, 0);
    V v_to_2429 = heff_field(v_p_242, 1);
    V v_k_2430 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Copy = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24Copy, TAG_Copy, 3, 3ULL, (V[]){v_path_2428, v_to_2429, heff_clo_n(g_std_2efilesystem_2efilesystem_lam7, 1, 2, (V[]){v_k_2430, v_g_241})});
  }
  case TAG_Move: {
    V v_path_2433 = heff_field(v_p_242, 0);
    V v_to_2434 = heff_field(v_p_242, 1);
    V v_k_2435 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Move = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24Move, TAG_Move, 3, 3ULL, (V[]){v_path_2433, v_to_2434, heff_clo_n(g_std_2efilesystem_2efilesystem_lam8, 1, 2, (V[]){v_k_2435, v_g_241})});
  }
  case TAG_Replace: {
    V v_path_2438 = heff_field(v_p_242, 0);
    V v_to_2439 = heff_field(v_p_242, 1);
    V v_k_2440 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Replace = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24Replace, TAG_Replace, 3, 3ULL, (V[]){v_path_2438, v_to_2439, heff_clo_n(g_std_2efilesystem_2efilesystem_lam9, 1, 2, (V[]){v_k_2440, v_g_241})});
  }
  case TAG_Writable: {
    V v_path_2443 = heff_field(v_p_242, 0);
    V v_k_2444 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Writable = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24Writable, TAG_Writable, 2, 1ULL, (V[]){v_path_2443, heff_clo_n(g_std_2efilesystem_2efilesystem_lam10, 1, 2, (V[]){v_k_2444, v_g_241})});
  }
  case TAG_PathStatus: {
    V v_path_2447 = heff_field(v_p_242, 0);
    V v_follow_2448 = heff_field(v_p_242, 1);
    V v_k_2449 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24PathStatus = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24PathStatus, TAG_PathStatus, 3, 3ULL, (V[]){v_path_2447, v_follow_2448, heff_clo_n(g_std_2efilesystem_2efilesystem_lam11, 1, 2, (V[]){v_k_2449, v_g_241})});
  }
  case TAG_SetMode: {
    V v_path_2452 = heff_field(v_p_242, 0);
    V v_mode_2453 = heff_field(v_p_242, 1);
    V v_k_2454 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24SetMode = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24SetMode, TAG_SetMode, 3, 3ULL, (V[]){v_path_2452, v_mode_2453, heff_clo_n(g_std_2efilesystem_2efilesystem_lam12, 1, 2, (V[]){v_k_2454, v_g_241})});
  }
  case TAG_RealPath: {
    V v_path_2457 = heff_field(v_p_242, 0);
    V v_k_2458 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24RealPath = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24RealPath, TAG_RealPath, 2, 1ULL, (V[]){v_path_2457, heff_clo_n(g_std_2efilesystem_2efilesystem_lam13, 1, 2, (V[]){v_k_2458, v_g_241})});
  }
  case TAG_ReadLink: {
    V v_path_2461 = heff_field(v_p_242, 0);
    V v_k_2462 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadLink = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24ReadLink, TAG_ReadLink, 2, 1ULL, (V[]){v_path_2461, heff_clo_n(g_std_2efilesystem_2efilesystem_lam14, 1, 2, (V[]){v_k_2462, v_g_241})});
  }
  case TAG_TemporaryDirectory: {
    V v_prefix_2465 = heff_field(v_p_242, 0);
    V v_k_2466 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24TemporaryDirectory = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24TemporaryDirectory, TAG_TemporaryDirectory, 2, 1ULL, (V[]){v_prefix_2465, heff_clo_n(g_std_2efilesystem_2efilesystem_lam15, 1, 2, (V[]){v_k_2466, v_g_241})});
  }
  case TAG_TemporaryFile: {
    V v_prefix_2469 = heff_field(v_p_242, 0);
    V v_k_2470 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24TemporaryFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24TemporaryFile, TAG_TemporaryFile, 2, 1ULL, (V[]){v_prefix_2469, heff_clo_n(g_std_2efilesystem_2efilesystem_lam16, 1, 2, (V[]){v_k_2470, v_g_241})});
  }
  case TAG_OpenPath: {
    V v_path_2473 = heff_field(v_p_242, 0);
    V v_a_2474 = heff_field(v_p_242, 1);
    V v_c_2475 = heff_field(v_p_242, 2);
    V v_t_2476 = heff_field(v_p_242, 3);
    V v_x_2477 = heff_field(v_p_242, 4);
    V v_mode_2478 = heff_field(v_p_242, 5);
    V v_k_2479 = heff_field(v_p_242, 6);
    V v_ru_24p_242_24OpenPath = heff_take_reuse_n(v_p_242, 127ULL, 7);
    return heff_tag_re_n(v_ru_24p_242_24OpenPath, TAG_OpenPath, 7, 63ULL, (V[]){v_path_2473, v_a_2474, v_c_2475, v_t_2476, v_x_2477, v_mode_2478, heff_clo_n(g_std_2efilesystem_2efilesystem_lam17, 1, 2, (V[]){v_k_2479, v_g_241})});
  }
  case TAG_Standard: {
    V v_i_2482 = heff_field(v_p_242, 0);
    V v_k_2483 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Standard = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24Standard, TAG_Standard, 2, 1ULL, (V[]){v_i_2482, heff_clo_n(g_std_2efilesystem_2efilesystem_lam18, 1, 2, (V[]){v_k_2483, v_g_241})});
  }
  case TAG_StandardPort: {
    V v_i_2486 = heff_field(v_p_242, 0);
    V v_k_2487 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24StandardPort = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24StandardPort, TAG_StandardPort, 2, 1ULL, (V[]){v_i_2486, heff_clo_n(g_std_2efilesystem_2efilesystem_lam19, 1, 2, (V[]){v_k_2487, v_g_241})});
  }
  case TAG_ReadChunk: {
    V v_h_2490 = heff_field(v_p_242, 0);
    V v_n_2491 = heff_field(v_p_242, 1);
    V v_k_2492 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24ReadChunk = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24ReadChunk, TAG_ReadChunk, 3, 3ULL, (V[]){v_h_2490, v_n_2491, heff_clo_n(g_std_2efilesystem_2efilesystem_lam20, 1, 2, (V[]){v_k_2492, v_g_241})});
  }
  case TAG_ReadLine: {
    V v_h_2495 = heff_field(v_p_242, 0);
    V v_k_2496 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ReadLine = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24ReadLine, TAG_ReadLine, 2, 1ULL, (V[]){v_h_2495, heff_clo_n(g_std_2efilesystem_2efilesystem_lam21, 1, 2, (V[]){v_k_2496, v_g_241})});
  }
  case TAG_WriteBytes: {
    V v_h_2499 = heff_field(v_p_242, 0);
    V v_b_24100 = heff_field(v_p_242, 1);
    V v_k_24101 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteBytes = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24WriteBytes, TAG_WriteBytes, 3, 3ULL, (V[]){v_h_2499, v_b_24100, heff_clo_n(g_std_2efilesystem_2efilesystem_lam22, 1, 2, (V[]){v_k_24101, v_g_241})});
  }
  case TAG_WriteString: {
    V v_h_24104 = heff_field(v_p_242, 0);
    V v_s_24105 = heff_field(v_p_242, 1);
    V v_k_24106 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteString = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24WriteString, TAG_WriteString, 3, 3ULL, (V[]){v_h_24104, v_s_24105, heff_clo_n(g_std_2efilesystem_2efilesystem_lam23, 1, 2, (V[]){v_k_24106, v_g_241})});
  }
  case TAG_Seek: {
    V v_h_24109 = heff_field(v_p_242, 0);
    V v_from_24110 = heff_field(v_p_242, 1);
    V v_n_24111 = heff_field(v_p_242, 2);
    V v_k_24112 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Seek = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_re_n(v_ru_24p_242_24Seek, TAG_Seek, 4, 7ULL, (V[]){v_h_24109, v_from_24110, v_n_24111, heff_clo_n(g_std_2efilesystem_2efilesystem_lam24, 1, 2, (V[]){v_k_24112, v_g_241})});
  }
  case TAG_FileStatus: {
    V v_h_24115 = heff_field(v_p_242, 0);
    V v_k_24116 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24FileStatus = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24FileStatus, TAG_FileStatus, 2, 1ULL, (V[]){v_h_24115, heff_clo_n(g_std_2efilesystem_2efilesystem_lam25, 1, 2, (V[]){v_k_24116, v_g_241})});
  }
  case TAG_CloseFile: {
    V v_h_24119 = heff_field(v_p_242, 0);
    V v_k_24120 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24CloseFile = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24CloseFile, TAG_CloseFile, 2, 1ULL, (V[]){v_h_24119, heff_clo_n(g_std_2efilesystem_2efilesystem_lam26, 1, 2, (V[]){v_k_24120, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2efilesystem_2efilesystem_lam27(V self, V *args) {
  V v_m_24123 = args[0];
  V v_n_24124 = args[1];
  V v_nt_24125 = args[2];
  V v_p_24126 = args[3];
  heff_drop(v_m_24123);
  heff_drop(v_n_24124);
  heff_drop(v_nt_24125);
  return v_p_24126;
}
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam1(V self, V *args);
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam2(V self, V *args);
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam0(V self, V *args); static Clo g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam0, 1, 0};
Clo g_std_2efilesystem_2efromSystem_24s141698176x1512134465_clo = {{0x80000000u, K_CLO, 0}, g_std_2efilesystem_2efromSystem_24s141698176x1512134465_entry, 1, 0};

V g_std_2efilesystem_2efromSystem_24s141698176x1512134465(V v_c_240) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){heff_dup(g_exception_2eattempted_24s588401679x1225922520_get()), ((V)&g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam0_clo)});
}
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_entry(V self, V *a) {
  (void)self;
  return g_std_2efilesystem_2efromSystem_24s141698176x1512134465(a[0]);
}
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_err_242 = heff_env(self)[0];
  heff_drop(v_hd_243);
  heff_clo_take(self, 1);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam2(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_drop(v_a_247);
  heff_clo_take(self, 1);
  V f_ = v_a_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam0(V self, V *args) {
  V v_x_241 = args[0];
  switch (heff_tag_of(v_x_241)) {
  case TAG_Left: {
    V v_err_242 = heff_field(v_x_241, 0);
    heff_take_n(v_x_241, 1ULL, 1);
    return heff_clo_n(g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam1, 2, 1, (V[]){v_err_242});
  }
  case TAG_Right: {
    V v_x_245 = heff_field(v_x_241, 0);
    heff_take_n(v_x_241, 1ULL, 1);
    V v_x_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_245));
    return heff_clo_n(g_std_2efilesystem_2efromSystem_24s141698176x1512134465_lam2, 2, 1, (V[]){v_x_246});
  }
  default: return heff_nomatch(v_x_241);
  }
}