// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn 19030
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_name 9869138
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_keys__defs[] = {LBL_keys, LBL_defs};
V g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle(V, V, V, V, V);
V g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
HeffT3 g_heff_2ecompile_2eworlds_2eappSides_24cpr(V, V);
V g_heff_2ecompile_2eworlds_2efloatAll(V, V, V);
V g_heff_2ecompile_2eworlds_2efloatAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2efloatAll_clo;
HeffT2 g_heff_2ecompile_2eworlds_2efloatOne_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eworlds_2ekeyOf_24cpr(V, V);
V g_heff_2ecompile_2eworlds_2eofGlobals(V);
V g_heff_2ecompile_2eworlds_2eofGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2eofGlobals_clo;
V g_heff_2ecompile_2eworlds_2ereplaced(V, V);
V g_heff_2ecompile_2eworlds_2ereplaced_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2ereplaced_clo;
HeffT3 g_heff_2ecompile_2eworlds_2esidesOf_24cpr(V);
V g_heff_2ecompile_2eworlds_2esumKey_get(void);
V g_heff_2ecompile_2eworlds_2eworldText(V);
V g_heff_2ecompile_2eworlds_2eworldText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2eworldText_clo;
V g_heff_2ecompile_2eworlds_2eworldsIn(V, V);
V g_heff_2ecompile_2eworlds_2eworldsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2eworldsIn_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
HEFF_LIT(g_heff_2ecompile_2eworlds_2esumKey_str0, 6, "co.<+>");

static V g_heff_2ecompile_2eworlds_2esumKey_val;
static HEFF_ONCE g_heff_2ecompile_2eworlds_2esumKey_st;
static V g_heff_2ecompile_2eworlds_2esumKey_init(void) {
  return ((V)&g_heff_2ecompile_2eworlds_2esumKey_str0);
}
V g_heff_2ecompile_2eworlds_2esumKey_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eworlds_2esumKey_st)) return g_heff_2ecompile_2eworlds_2esumKey_val;
  return heff_global(&g_heff_2ecompile_2eworlds_2esumKey_val, &g_heff_2ecompile_2eworlds_2esumKey_st, g_heff_2ecompile_2eworlds_2esumKey_init);
}

HeffT3 g_heff_2ecompile_2eworlds_2eappSides_24cpr(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EApp: {
    V v_f_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_f_242)) {
    case TAG_EVar: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      V v_p_245 = heff_field(v_f_242, 0);
      if (heff_strEq_c(heff_dup(v_p_245), heff_dup(g_heff_2ecompile_2eworlds_2esumKey_get()))) {
        switch (heff_tag_of(v_x12_243)) {
        case TAG_Nil: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_a_246 = heff_field(v_x12_243, 0);
          V v_x12_247 = heff_field(v_x12_243, 1);
          switch (heff_tag_of(v_x12_247)) {
          case TAG_Nil: {
            switch (heff_tag_of(v_x2_241)) {
            case TAG_Nil: {
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            case TAG_Cons: {
              V v_b_248 = heff_field(v_x2_241, 0);
              V v_x22_249 = heff_field(v_x2_241, 1);
              switch (heff_tag_of(v_x22_249)) {
              case TAG_Nil: {
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_a_246), heff_dup(v_b_248)}});
              }
              case TAG_Cons: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              default: return ((HeffT3){{heff_nomatch(v_x22_249)}});
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
            }
          }
          case TAG_Cons: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          default: return ((HeffT3){{heff_nomatch(v_x12_247)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x12_243)}});
        }
      } else {
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
    case TAG_ELam: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    default: return ((HeffT3){{heff_nomatch(v_f_242)}});
    }
  }
  default: {
    switch (heff_tag_of(v_x1_240)) {
    case TAG_EVar: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      V v_p_2452 = heff_field(v_x1_240, 0);
      if (heff_strEq_c(heff_dup(v_p_2452), heff_dup(g_heff_2ecompile_2eworlds_2esumKey_get()))) {
        switch (heff_tag_of(v_x2_241)) {
        case TAG_Nil: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_a_2453 = heff_field(v_x2_241, 0);
          V v_x12_2454 = heff_field(v_x2_241, 1);
          switch (heff_tag_of(v_x12_2454)) {
          case TAG_Nil: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_Cons: {
            V v_b_2455 = heff_field(v_x12_2454, 0);
            V v_x122_2456 = heff_field(v_x12_2454, 1);
            switch (heff_tag_of(v_x122_2456)) {
            case TAG_Nil: {
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_a_2453), heff_dup(v_b_2455)}});
            }
            case TAG_Cons: {
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            default: return ((HeffT3){{heff_nomatch(v_x122_2456)}});
            }
          }
          default: return ((HeffT3){{heff_nomatch(v_x12_2454)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
        }
      } else {
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
    case TAG_ELam: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    default: return ((HeffT3){{heff_nomatch(v_x1_240)}});
    }
  }
  }
}

HeffT3 g_heff_2ecompile_2eworlds_2esidesOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_xs_246 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2eworlds_2eappSides_24cpr(v_f_245, v_xs_246));
  }
  case TAG_ELet: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eworlds_2eofGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworlds_2eofGlobals_entry, 1, 0};

V g_heff_2ecompile_2eworlds_2eofGlobals(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: {
    HeffT3 v_t_242 = ({ V a_0 = v_e_240; HeffT3 r_ = (g_heff_2ecompile_2eworlds_2esidesOf_24cpr(a_0)); heff_drop(v_e_240); r_; });
    {
      V v_field_244 = v_t_242.f[1];
      V v_field_245 = v_t_242.f[2];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_a_246 = v_field_244;
        V v_b_247 = v_field_245;
        V v_t_248 = (g_heff_2ecompile_2eworlds_2eofGlobals(v_a_246));
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          V t_0 = v_b_247;
          v_e_240 = t_0;
          goto top;
        } else {
          heff_drop(v_b_247);
          heff_drop(v_t_248);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_field_244);
        heff_drop(v_field_245);
        return NTAG(TAG_False);
      }
    }
  }
  }
}
V g_heff_2ecompile_2eworlds_2eofGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworlds_2eofGlobals(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eworlds_2eworldText_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eworlds_2eworldText_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eworlds_2eworldText_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eworlds_2eworldText_str3, 1, "\?");
Clo g_heff_2ecompile_2eworlds_2eworldText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworlds_2eworldText_entry, 1, 0};

V g_heff_2ecompile_2eworlds_2eworldText(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EGlobal: {
    V v_g_241 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return v_g_241;
  }
  default: {
    HeffT3 v_t_242 = ({ V a_0 = v_e_240; HeffT3 r_ = (g_heff_2ecompile_2eworlds_2esidesOf_24cpr(a_0)); heff_drop(v_e_240); r_; });
    {
      V v_field_244 = v_t_242.f[1];
      V v_field_245 = v_t_242.f[2];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_a_246 = v_field_244;
        V v_b_247 = v_field_245;
        V v_t_248 = (g_heff_2ecompile_2eworlds_2eworldText(v_a_246));
        V v_t_249 = (g_heff_2ecompile_2eworlds_2eworldText(v_b_247));
        V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eworlds_2eworldText_str0), v_t_248), ((V)&g_heff_2ecompile_2eworlds_2eworldText_str1));
        return heff_strAppend(heff_strAppend(v_t_2410, v_t_249), ((V)&g_heff_2ecompile_2eworlds_2eworldText_str2));
      } else {
        heff_drop(v_field_244);
        heff_drop(v_field_245);
        return ((V)&g_heff_2ecompile_2eworlds_2eworldText_str3);
      }
    }
  }
  }
}
V g_heff_2ecompile_2eworlds_2eworldText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eworlds_2eworldText(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eworlds_2eworldsIn_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eworlds_2eworldsIn_str1, 0, "");
Clo g_heff_2ecompile_2eworlds_2eworldsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworlds_2eworldsIn_entry, 2, 0};

V g_heff_2ecompile_2eworlds_2eworldsIn(V v_e_240, V v_acc_241) {
top: ;
  return (g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn), ((V)&g_heff_2ecompile_2eworlds_2eworldsIn_str0), ((V)&g_heff_2ecompile_2eworlds_2eworldsIn_str1), v_e_240, v_acc_241));
}
V g_heff_2ecompile_2eworlds_2eworldsIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworlds_2eworldsIn(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eworlds_2ekeyOf_24cpr(V v_x1_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_u_244 = heff_field(v_x11_242, 0);
      V v_k_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_u_244, v_t_241, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_k_245)}});
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_t_241;
        v_x1_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eworlds_2efloatOne_24cpr_str0, 6, "$world");
HEFF_LIT(g_heff_2ecompile_2eworlds_2efloatOne_24cpr_str1, 6, "$world");
HEFF_LIT(g_heff_2ecompile_2eworlds_2efloatOne_24cpr_str2, 6, "$world");
HEFF_LIT(g_heff_2ecompile_2eworlds_2efloatOne_24cpr_str3, 6, "$world");

HeffT2 g_heff_2ecompile_2eworlds_2efloatOne_24cpr(V v_owner_240, V v_fl_241, V v_e_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ecompile_2eworlds_2esidesOf_24cpr(v_e_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_a_247 = v_field_245;
      V v_b_248 = v_field_246;
      V v_t_249 = (g_heff_2ecompile_2eworlds_2eworldText(heff_dup(v_e_242)));
      HeffT2 v_t_2410 = ({ V a_0 = heff_rfield(v_fl_241, 0); V a_1 = v_t_249; HeffT2 r_ = (g_heff_2ecompile_2eworlds_2ekeyOf_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_e_242);
          heff_drop(v_a_247);
          heff_drop(v_b_248);
          V v_k_2413 = v_field_2412;
          return ((HeffT2){{heff_tag_n(TAG_EGlobal, 1, (V[]){v_k_2413}), v_fl_241}});
        } else {
          heff_drop(v_field_2412);
          V v_t_2414 = (g_heff_2ecompile_2eworlds_2eworldText(v_e_242));
          HeffT2 v_t_2415 = (g_heff_2ecompile_2eworlds_2efloatOne_24cpr(v_owner_240, v_fl_241, v_a_247));
          {
            V v_field_2416 = v_t_2415.f[0];
            V v_field_2417 = v_t_2415.f[1];
            V v_a2_2418 = v_field_2416;
            V v_fl_2419 = v_field_2417;
            HeffT2 v_t_2420 = (g_heff_2ecompile_2eworlds_2efloatOne_24cpr(v_owner_240, v_fl_2419, v_b_248));
            {
              V v_field_2421 = v_t_2420.f[0];
              V v_field_2422 = v_t_2420.f[1];
              V v_b2_2423 = v_field_2421;
              V v_fl_2424 = v_field_2422;
              V v_owner_2425 = heff_dup(v_owner_240);
              V v_t_2426 = v_t_2414;
              V v_a_2427 = v_a2_2418;
              V v_b_2428 = v_b2_2423;
              V v_fl_2429 = v_fl_2424;
              V v_defs_2430 = heff_take_field(v_fl_2429, 1);
              V v_keys_2431 = heff_take_field(v_fl_2429, 0);
              V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_defs_2430));
              V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_defs_2430));
              V v_t_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_defs_2430));
              V v_key_2435 = heff_strAppend(heff_strAppend(heff_dup(v_owner_2425), ((V)&g_heff_2ecompile_2eworlds_2efloatOne_24cpr_str0)), heff_intShow(v_t_2434));
              V v_t_2436 = heff_strAppend(heff_strAppend(heff_dup(v_owner_2425), ((V)&g_heff_2ecompile_2eworlds_2efloatOne_24cpr_str1)), heff_intShow(v_t_2432));
              V v_f_2437 = heff_tag_n(TAG_EGlobal, 1, (V[]){v_t_2436});
              V v_t_2438 = heff_strAppend(heff_strAppend(heff_dup(v_owner_2425), ((V)&g_heff_2ecompile_2eworlds_2efloatOne_24cpr_str2)), heff_intShow(v_t_2433));
              V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_t_2438}), v_keys_2431});
              V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2428, NTAG(TAG_Nil)});
              V v_t_2441 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(g_heff_2ecompile_2eworlds_2esumKey_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2427, v_t_2440})});
              V v_t_2442 = heff_rec_n(3, shape_key__name__body, (V[]){v_key_2435, heff_strAppend(v_owner_2425, ((V)&g_heff_2ecompile_2eworlds_2efloatOne_24cpr_str3)), v_t_2441});
              V v_f_2443 = ({ V rv_0 = v_t_2439; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_defs_2430}); V rr_ = heff_rec_reuse_nf(v_fl_2429, 0ULL, 2, shape_keys__defs, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
              return ((HeffT2){{v_f_2437, v_f_2443}});
            }
          }
        }
      }
    } else {
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return ((HeffT2){{v_e_242, v_fl_241}});
    }
  }
}
Clo g_heff_2ecompile_2eworlds_2efloatAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworlds_2efloatAll_entry, 3, 0};

V g_heff_2ecompile_2eworlds_2efloatAll(V v_owner_240, V v_fl_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_fl_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    HeffT2 v_t_245 = (g_heff_2ecompile_2eworlds_2efloatOne_24cpr(v_owner_240, v_fl_241, heff_dup(v_e_243)));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_x_248 = v_field_246;
      heff_drop(v_x_248);
      V v_y_249 = v_field_247;
      V v_t_2410 = v_y_249;
      V t_0 = v_owner_240;
      V t_1 = v_t_2410;
      V t_2 = v_rest_244;
      v_owner_240 = t_0;
      v_fl_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eworlds_2efloatAll_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eworlds_2efloatAll(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eworlds_2ereplaced_lam0(V self, V *args);
V g_heff_2ecompile_2eworlds_2ereplaced_lam1(V self, V *args);
V g_heff_2ecompile_2eworlds_2ereplaced_lam2(V self, V *args);
Clo g_heff_2ecompile_2eworlds_2ereplaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eworlds_2ereplaced_entry, 2, 0};

V g_heff_2ecompile_2eworlds_2ereplaced(V v_keys_240, V v_e_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ecompile_2eworlds_2esidesOf_24cpr(v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_a_246 = v_field_244;
      V v_b_247 = v_field_245;
      V v_t_248 = (g_heff_2ecompile_2eworlds_2eofGlobals(v_a_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = (g_heff_2ecompile_2eworlds_2eofGlobals(v_b_247));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          V v_t_2410 = (g_heff_2ecompile_2eworlds_2eworldText(heff_dup(v_e_241)));
          HeffT2 v_t_2411 = ({ V a_0 = v_keys_240; V a_1 = v_t_2410; HeffT2 r_ = (g_heff_2ecompile_2eworlds_2ekeyOf_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop(v_e_241);
              V v_k_2414 = v_field_2413;
              return heff_tag_n(TAG_EGlobal, 1, (V[]){v_k_2414});
            } else {
              heff_drop(v_field_2413);
              return v_e_241;
            }
          }
        } else {
          heff_drop(v_t_249);
          HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eworlds_2ereplaced_lam0, 2, 1, (V[]){heff_dup(v_keys_240)}), v_e_241);
        }
      } else {
        heff_drop(v_b_247);
        heff_drop(v_t_248);
        HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eworlds_2ereplaced_lam1, 2, 1, (V[]){heff_dup(v_keys_240)}), v_e_241);
      }
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eworlds_2ereplaced_lam2, 2, 1, (V[]){heff_dup(v_keys_240)}), v_e_241);
    }
  }
}
V g_heff_2ecompile_2eworlds_2ereplaced_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eworlds_2ereplaced(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eworlds_2ereplaced_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_2416 = args[1];
  V v_keys_240 = heff_env(self)[0];
  heff_drop(v_x_2415);
  heff_clo_take(self, 1);
  return ({ V a_0 = v_keys_240; V a_1 = v_p_2416; V r_ = (g_heff_2ecompile_2eworlds_2ereplaced(a_0, a_1)); heff_drop(v_keys_240); r_; });
}
V g_heff_2ecompile_2eworlds_2ereplaced_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_p_2418 = args[1];
  V v_keys_240 = heff_env(self)[0];
  heff_drop(v_x_2417);
  heff_clo_take(self, 1);
  return ({ V a_0 = v_keys_240; V a_1 = v_p_2418; V r_ = (g_heff_2ecompile_2eworlds_2ereplaced(a_0, a_1)); heff_drop(v_keys_240); r_; });
}
V g_heff_2ecompile_2eworlds_2ereplaced_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_p_2420 = args[1];
  V v_keys_240 = heff_env(self)[0];
  heff_drop(v_x_2419);
  heff_clo_take(self, 1);
  return ({ V a_0 = v_keys_240; V a_1 = v_p_2420; V r_ = (g_heff_2ecompile_2eworlds_2ereplaced(a_0, a_1)); heff_drop(v_keys_240); r_; });
}