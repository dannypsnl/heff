// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332(V, V);
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_clo;
V g_heff_2ebuild_2efetch_2erevSaid(V);
V g_heff_2ebuild_2efetch_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2erevSaid_clo;
V g_heff_2ebuild_2eproject_2eisMajorPart(V);
V g_heff_2ebuild_2eproject_2eisMajorPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisMajorPart_clo;
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str6, 27, "cannot list the commits of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str7, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str9, 3, "no ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str10, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str11, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str13, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str14, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str16, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str17, 1, "/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str18, 1, "0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str19, 5, ".0.0-");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str20, 1, "-");
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_entry, 8, 0};

V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0(V v_x_240, V v_hd_241, V v_x_242, V v_path_243, V v_x_244, V v_rev_245, V v_k_246, V v_x_247) {
top: ;
  V v_ended_248 = heff_take_field(v_x_242, 0);
  V v_err_249 = heff_get_n(v_x_242, 2, 3);
  V v_t_2410 = heff_tag_n(TAG_End, 2, (V[]){v_x_240, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_hd_241, heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_lam0, 1, 6, (V[]){v_ended_248, v_path_243, v_err_249, v_x_244, v_rev_245, v_k_246})));
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7); heff_drop(a7); return r;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ended_248 = heff_env(self)[0];
  V v_path_243 = heff_env(self)[1];
  V v_err_249 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_rev_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_drop(v_x_2412);
  V v_t_2413 = heff_dup(v_ended_248);
  V v_t_2417;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Exited: {
    V v_n_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    v_t_2417 = heff_bool(!heff_intEq_c_lent(v_n_2414, MK_INT(0LL), 2));
    heff_drop(v_n_2414);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2413, 0ULL, 1);
    v_t_2417 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2417 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2413, 0ULL, 1);
    v_t_2417 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_x_2465;
  heff_clo_take(self, 6);
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_x_244);
    heff_drop(v_rev_245);
    heff_drop(v_t_2417);
    V v_t_2418 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_243));
    V v_t_2419 = v_ended_248;
    V v_t_2428;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Exited: {
      heff_take_n(v_t_2419, 0ULL, 1);
      v_t_2428 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str0);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2419, 0ULL, 1);
      v_t_2428 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str1);
      break;
    }
    case TAG_TimedOut: {
      v_t_2428 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str2);
      break;
    }
    case TAG_NotRun: {
      V v_err_2422 = heff_field(v_t_2419, 0);
      heff_take_n(v_t_2419, 1ULL, 1);
      V v_path_2423 = heff_take_field(v_err_2422, 3);
      V v_name_2424 = heff_take_field(v_err_2422, 1);
      V v_message_2425 = heff_get_n(v_err_2422, 2, 4);
      V v_t_2426 = heff_strAppend(heff_strAppend(v_path_2423, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str3)), v_name_2424);
      V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str4)), v_message_2425);
      v_t_2428 = heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str5));
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    V v_s_2429 = heff_strAppend(v_t_2428, v_err_249);
    V v_t_2430 = (g_prelude_2eskipSpaces(v_s_2429, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_s_2429, 0)) - ((int64_t)1ULL));
    V v_t_2432 = (g_prelude_2eskipSpaces(v_s_2429, heff_box_word(v_t_2431), MK_INT(-1LL)));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str6), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str7), v_t_2418));
    V v_t_2434 = heff_strSlice(v_s_2429, v_t_2430, heff_intAdd(v_t_2432, MK_INT(1LL)));
    V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str8)), v_t_2434);
    v_x_2465 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2435});
  } else {
    heff_drop(v_ended_248);
    heff_drop(v_err_249);
    heff_drop(v_t_2417);
    switch (heff_tag_of(v_x_244)) {
    case TAG_Nothing: {
      V v_t_2436 = (g_heff_2ebuild_2efetch_2erevSaid(v_rev_245));
      V v_t_2437 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_243));
      V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str9), v_t_2436), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str10));
      V v_t_2439 = heff_strAppend(v_t_2438, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str11), v_t_2437));
      v_x_2465 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2439});
      break;
    }
    case TAG_Just: {
      V v_it1_2440 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24Just = heff_take_reuse_n(v_x_244, 1ULL, 1);
      heff_drop(v_rev_245);
      switch (heff_tag_of(v_it1_2440)) {
      case TAG_MkPair: {
        V v_time_2441 = heff_field(v_it1_2440, 0);
        V v_hash_2442 = heff_field(v_it1_2440, 1);
        heff_take_n(v_it1_2440, 3ULL, 2);
        V v_path_2443 = v_path_243;
        V v_time_2444 = v_time_2441;
        V v_hash_2445 = v_hash_2442;
        V v_xs_2446 = (g_prelude_2esplit_2esplitFrom_240(v_path_2443, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str12), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str13), v_path_2443, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2446));
        V v_t_2450;
        switch (heff_tag_of(v_t_2447)) {
        case TAG_Nil: {
          v_t_2450 = heff_dup(v_path_2443);
          break;
        }
        case TAG_Cons: {
          V v_x_2448 = heff_field(v_t_2447, 0);
          heff_take_n(v_t_2447, 1ULL, 2);
          v_t_2450 = v_x_2448;
          break;
        }
        default: heff_nomatch(v_t_2447);
        }
        V v_t_2451 = ({ V a_0 = v_t_2450; V r_ = (g_heff_2ebuild_2eproject_2eisMajorPart(a_0)); heff_drop(v_t_2450); r_; });
        V v_t_2462;
        if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
          heff_drop(v_t_2451);
          V v_xs_2452 = (g_prelude_2esplit_2esplitFrom_240(v_path_2443, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str14), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str15), v_path_2443, MK_INT(0LL), 5), NTAG(TAG_Nil)));
          V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2452));
          V v_t_2456;
          switch (heff_tag_of(v_t_2453)) {
          case TAG_Nil: {
            v_t_2456 = heff_dup(v_path_2443);
            break;
          }
          case TAG_Cons: {
            V v_x_2454 = heff_field(v_t_2453, 0);
            heff_take_n(v_t_2453, 1ULL, 2);
            v_t_2456 = v_x_2454;
            break;
          }
          default: heff_nomatch(v_t_2453);
          }
          V v_xs_2457 = (g_prelude_2esplit_2esplitFrom_240(v_path_2443, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str16), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str17), v_path_2443, MK_INT(0LL), 5), NTAG(TAG_Nil)));
          V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2457));
          V v_t_2461;
          switch (heff_tag_of(v_t_2458)) {
          case TAG_Nil: {
            v_t_2461 = v_path_2443;
            break;
          }
          case TAG_Cons: {
            V v_x_2459 = heff_field(v_t_2458, 0);
            heff_take_n(v_t_2458, 1ULL, 2);
            heff_drop(v_path_2443);
            v_t_2461 = v_x_2459;
            break;
          }
          default: heff_nomatch(v_t_2458);
          }
          v_t_2462 = heff_strSlice(v_t_2456, MK_INT(1LL), heff_strLength(v_t_2461));
        } else {
          heff_drop(v_path_2443);
          heff_drop(v_t_2451);
          v_t_2462 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str18);
        }
        V v_t_2463 = heff_strAppend(heff_strAppend(v_t_2462, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str19)), v_time_2444);
        V v_t_2464 = heff_strAppend(heff_strAppend(v_t_2463, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0_str20)), heff_strSlice(v_hash_2445, MK_INT(0LL), MK_INT(12LL)));
        v_x_2465 = heff_tag_at_n(v_ru_24x_244_24Just, TAG_Right, 1, (V[]){v_t_2464});
        break;
      }
      default: heff_nomatch(v_it1_2440);
      }
      break;
    }
    default: heff_nomatch(v_x_244);
    }
  }
  V f_ = v_k_246;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str0, 12, "finding the ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str1, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str2, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str3, 6, "--bare");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str4, 15, "--filter=tree:0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str5, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str6, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str7, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str9, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str10, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str11, 11, "refs/heads/");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str12, 11, "refs/heads/");
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam2(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam2, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam4(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam4, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam5(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam5, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam6(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam6, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam7(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam7, 2, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam9(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam9, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_entry, 6, 0};

V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1(V v_rev_240, V v_path_241, V v_hd_242, V v_x_243, V v_k_244, V v_x_245) {
top: ;
  V v_t_246 = (g_heff_2ebuild_2efetch_2erevSaid(heff_dup(v_rev_240)));
  V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str0), v_t_246), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str1));
  V v_name_248 = heff_strAppend(v_t_247, heff_dup(v_path_241));
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_name_248, MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s535099379x685970669(v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam1, 1, 5, (V[]){v_path_241, v_x_243, v_hd_242, v_rev_240, v_k_244})));
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam0(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam2(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam6(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam7(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam9(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_x_2444 = heff_env(self)[4];
  V v_rev_240 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Left: {
    V v_x_2455 = heff_field(v_x_2454, 0);
    V v_ru_24x_2454_24Left = heff_take_reuse_n(v_x_2454, 1ULL, 1);
    heff_clo_take(self, 7);
    return ({ V a_0 = v_x_2412; V a_1 = v_hd_242; V a_2 = v_x_2426; V a_3 = v_path_241; V a_4 = v_x_2444; V a_5 = v_rev_240; V a_6 = v_k_244; V b_7 = heff_tag_re_n(v_ru_24x_2454_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2455}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, b_7)); heff_drop(b_7); r_; });
  }
  case TAG_Right: {
    V v_y_2456 = heff_field(v_x_2454, 0);
    V v_ru_24x_2454_24Right = heff_take_reuse_n(v_x_2454, 1ULL, 1);
    switch (heff_tag_of(v_y_2456)) {
    case TAG_Left: {
      V v_err_2457 = heff_field(v_y_2456, 0);
      V v_ru_24y_2456_24Left = heff_take_reuse_n(v_y_2456, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2454_24Right, 1);
      heff_clo_take(self, 7);
      return ({ V a_0 = v_x_2412; V a_1 = v_hd_242; V a_2 = v_x_2426; V a_3 = v_path_241; V a_4 = v_x_2444; V a_5 = v_rev_240; V a_6 = v_k_244; V b_7 = heff_tag_re_n(v_ru_24y_2456_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2457}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, b_7)); heff_drop(b_7); r_; });
    }
    case TAG_Right: {
      V v_x_2458 = heff_field(v_y_2456, 0);
      heff_take_n(v_y_2456, 1ULL, 1);
      heff_clo_take(self, 7);
      return ({ V a_0 = v_x_2412; V a_1 = v_hd_242; V a_2 = v_x_2426; V a_3 = v_path_241; V a_4 = v_x_2444; V a_5 = v_rev_240; V a_6 = v_k_244; V b_7 = heff_tag_at_n(v_ru_24x_2454_24Right, TAG_Right, 1, (V[]){v_x_2458}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, b_7)); heff_drop(b_7); r_; });
    }
    default: return heff_nomatch(v_y_2456);
    }
  }
  default: return heff_nomatch(v_x_2454);
  }
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam8(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_rev_240 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_path_2445 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_243));
  V v_t_2446 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2445; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2445); r_; });
  V v_a_2448 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2446, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam9_clo)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2453, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam10, 1, 7, (V[]){v_x_2412, v_hd_242, v_x_2426, v_path_241, v_x_2444, v_rev_240, v_k_244})));
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_rev_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_t_2427 = heff_dup(heff_rfield(v_x_2426, 0));
  V v_c_2443;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Exited: {
    V v_n_2428 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    if (heff_intEq_c(v_n_2428, MK_INT(0LL))) {
      V v_rev_2429 = heff_dup(v_rev_240);
      V v_t_2432;
      if (heff_strEq_c_lent(v_rev_2429, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str9), 2)) {
        v_t_2432 = v_rev_2429;
      } else {
        if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_2429, 0)))) {
          if ((heff_unbox_word(heff_strLength_lent(v_rev_2429, 0)) <= ((int64_t)40ULL))) {
            V v_t_2430 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_2429, 0)));
            V v_t_2431 = ({ V a_0 = v_rev_2429; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_2430; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2430); r_; });
            if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
              heff_drop(v_t_2431);
              v_t_2432 = v_rev_2429;
            } else {
              heff_drop(v_t_2431);
              v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str10), v_rev_2429);
            }
          } else {
            v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str11), v_rev_2429);
          }
        } else {
          v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str12), v_rev_2429);
        }
      }
      v_c_2443 = (g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332(heff_dup(v_x_243), v_t_2432));
    } else {
      v_c_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam4_clo);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2427, 0ULL, 1);
    v_c_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam5_clo);
    break;
  }
  case TAG_TimedOut: {
    v_c_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam6_clo);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2427, 0ULL, 1);
    v_c_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam7_clo);
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  heff_clo_take(self, 6);
  V f_ = v_c_2443;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam8, 1, 7, (V[]){v_x_243, v_hd_242, v_x_2412, v_x_2426, v_path_241, v_rev_240, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_rev_240 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_t_2413 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str2), v_t_2413), v_t_2414});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str4), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str6), v_t_2416})});
  V v_t_2418 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str7), v_t_2417, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_str8), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam2_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  heff_clo_take(self, 5);
  return (g_co_2eop_24s535099379x685970669(v_t_2425, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1_lam3, 1, 6, (V[]){v_rev_240, v_x_243, v_hd_242, v_x_2412, v_path_241, v_k_244})));
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_entry, 7, 0};

V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2(V v_ps_240, V v_x_241, V v_hd_242, V v_rev_243, V v_path_244, V v_k_245, V v_x_246) {
top: ;
  V v_st_247 = heff_get_n(v_ps_240, 5, 6);
  HeffT3 v_t_248 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_247), heff_dup(v_x_241)));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    V v_d_2412 = v_field_249;
    V v_a_2413 = v_field_2410;
    V v_xs_2414 = v_field_2411;
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
    V v_xs_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2415; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_t_2418 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2412, v_a_2413, v_t_2417});
    V v_s_2419 = ({ V a_0 = v_st_247; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop_tag(v_t_2418, 3); r_; });
    V v_path_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2419));
    V v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2420; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2420); r_; });
    V v_a_2423 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2421, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_lam0_clo)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2428, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_lam1, 1, 5, (V[]){v_rev_243, v_path_244, v_hd_242, v_x_241, v_k_245})));
  }
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_lam0(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    V v_x_2430 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Left = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    heff_clo_take(self, 5);
    return ({ V a_0 = v_rev_243; V a_1 = v_path_244; V a_2 = v_hd_242; V a_3 = v_x_241; V a_4 = v_k_245; V b_5 = heff_tag_re_n(v_ru_24x_2429_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2430}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(b_5); r_; });
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Right = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    switch (heff_tag_of(v_y_2431)) {
    case TAG_Left: {
      V v_err_2432 = heff_field(v_y_2431, 0);
      V v_ru_24y_2431_24Left = heff_take_reuse_n(v_y_2431, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2429_24Right, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_rev_243; V a_1 = v_path_244; V a_2 = v_hd_242; V a_3 = v_x_241; V a_4 = v_k_245; V b_5 = heff_tag_re_n(v_ru_24y_2431_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2432}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(b_5); r_; });
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_y_2431, 0);
      heff_take_n(v_y_2431, 1ULL, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_rev_243; V a_1 = v_path_244; V a_2 = v_hd_242; V a_3 = v_x_241; V a_4 = v_k_245; V b_5 = heff_tag_at_n(v_ru_24x_2429_24Right, TAG_Right, 1, (V[]){v_x_2433}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(b_5); r_; });
    }
    default: return heff_nomatch(v_y_2431);
    }
  }
  default: return heff_nomatch(v_x_2429);
  }
}