// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_ELam 43266
#define TAG_EReturn 59059
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_IsInferable 49402
#define LBL_decl 9574769
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_head 9693863
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24dps_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2epackE(V, V);
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackE_clo;
V g_heff_2esyntax_2epresyntax_2epackTy(V, V);
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackTy_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackE_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackE_str1, 6, "MkPair");
Clo g_heff_2esyntax_2epresyntax_2epackE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epackE_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epackE(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackE_str0)}), heff_dup(v_sp_240)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
    }
    case TAG_Cons: {
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2epackE(v_sp_240, v_x22_243));
      V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackE_str1)}), heff_dup(v_sp_240)});
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_249}));
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2epackE(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str0, 12, "builtin.Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str1, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str2, 14, "prelude.typeOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epackTy_str3, 12, "prelude.Pair");
Clo g_heff_2esyntax_2epresyntax_2epackTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epackTy_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epackTy(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str0)}), heff_dup(v_sp_240)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str1)}), heff_dup(v_sp_240)});
      V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246);
    }
    case TAG_Cons: {
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str2)}), heff_dup(v_sp_240)});
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_sp_240)});
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_249, v_t_2411));
      V v_t_2413 = (g_heff_2esyntax_2epresyntax_2epackTy(v_sp_240, v_x22_243));
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2epackTy_str3)}), heff_dup(v_sp_240)});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2415}));
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2epackTy(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_2421;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_2421 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      switch (heff_tag_of(v_x_245)) {
      case TAG_At: {
        V v_a_247 = heff_dup(heff_field(v_x_245, 0));
        switch (heff_tag_of(v_a_247)) {
        case TAG_ELam: {
          heff_take_n(v_a_247, 0ULL, 2);
          switch (heff_tag_of(v_x_245)) {
          case TAG_At: {
            v_st_2421 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_245);
          }
          break;
        }
        case TAG_EReturn: {
          heff_take_n(v_a_247, 0ULL, 1);
          switch (heff_tag_of(v_x_245)) {
          case TAG_At: {
            v_st_2421 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x_245);
          }
          break;
        }
        default: {
          heff_drop(v_a_247);
          HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_x_245)));
          {
            V v_field_2417 = v_t_2416.f[0];
            V v_field_2418 = v_t_2416.f[1];
            V v_a_2419 = v_field_2417;
            V v_a_2420 = v_field_2418;
            heff_drop(v_a_2420);
            v_st_2421 = v_a_2419;
          }
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_x_245);
      }
    }
    V v_cell_2422 = heff_tag_re_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
    V v_u_2423 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2422);
    V t_0 = v_st_2421;
    V t_1 = v_xs_246;
    V t_2 = v_u_2423;
    v_st_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam0, 1, 0};
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam1, 1, 0};

static V g_heff_2esyntax_2epresyntax_2eclassifier_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassifier_st;
static V g_heff_2esyntax_2epresyntax_2eclassifier_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo), ((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo)});
}
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassifier_st)) return g_heff_2esyntax_2epresyntax_2eclassifier_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassifier_val, &g_heff_2esyntax_2epresyntax_2eclassifier_st, g_heff_2esyntax_2epresyntax_2eclassifier_init);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyTermF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_e_240));
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyDeclF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_d_241));
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2(V v_tok_240, V v_r_241, V v_asBits_242, V v_segs_243, V v_sp_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(v_r_241, v_asBits_242, v_segs_243, v_sp_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_field_246, v_field_247})});
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V v_tok_240, V v_cx_241, V v_sp_242, V v_j_243) {
top: ;
  V v_vars_244 = heff_take_field(v_j_243, 1);
  V v_unit_245 = heff_take_field(v_j_243, 2);
  V v_head_246 = heff_take_field(v_j_243, 0);
  V v_depth_247 = heff_get_n(v_j_243, 3, 4);
  V v_vars_248 = v_vars_244;
  V v_t_249 = v_unit_245;
  V v_t_2413;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    switch (heff_tag_of(v_vars_248)) {
    case TAG_Nil: {
      V v_t_2410 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_str0)}), heff_dup(v_sp_242)});
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      heff_drop_cell(v_tok_240, 2);
      v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_248));
      break;
    }
    default: heff_nomatch(v_vars_248);
    }
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_t_249);
    v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_248));
  }
  V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_246, v_t_2413));
  V v_t_2415 = heff_intSub(heff_dup(heff_rfield(v_cx_241, 4)), v_depth_247);
  return ({ V a_0 = v_cx_241; V a_1 = v_sp_242; V a_2 = v_t_2415; V a_3 = v_t_2414; V r_ = (g_heff_2esyntax_2epresyntax_2eleaving(a_0, a_1, a_2, a_3)); heff_drop_rec(v_cx_241, 7); heff_drop(v_sp_242); heff_drop(v_t_2414); r_; });
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(a[0], a[1], a[2], a[3]);
}