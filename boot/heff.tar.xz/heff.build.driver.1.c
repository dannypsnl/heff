// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Bug 14592
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Div 16157
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimInt 22031
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VOpaque 37311
#define TAG_VPrimInt 4244
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_cached 579094605
#define LBL_claim 296100950
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_doc 309170
#define LBL_effect 641056956
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_expected 956903529
#define LBL_exposes 1070285678
#define LBL_fixities 357800079
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_hidden 729654485
#define LBL_holds 300818350
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_line 9817275
#define LBL_listed 844633320
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_opens 307306371
#define LBL_order 307364712
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_tags 10047712
#define LBL_tests 311609915
#define LBL_to 10466
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_decls, LBL_top, LBL_diags, LBL_own, LBL_deps, LBL_opens, LBL_aliases, LBL_fixities, LBL_cached, LBL_exposes};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_owner__line__watch[] = {LBL_owner, LBL_line, LBL_watch};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_heff_2ebuild_2edriver_2eaddTests(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eaddTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eaddTests_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24dps(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24dps_clo;
V g_heff_2ebuild_2edriver_2eappendD_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(V, V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate0(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_24generate0_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate1(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_24generate1_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF_24map0(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_24map0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_24map0_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF_24map1(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_24map1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_24map1_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo;
V g_heff_2ebuild_2edriver_2eexposedDiag(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiag_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedDiag_clo;
V g_heff_2ebuild_2edriver_2eexposedIn(V, V);
V g_heff_2ebuild_2edriver_2eexposedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedIn_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efixityLine(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLine_clo;
V g_heff_2ebuild_2edriver_2efixityLines(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLines_clo;
V g_heff_2ebuild_2edriver_2efixityLines_24acc(V, V, V, V);
V g_heff_2ebuild_2edriver_2efixityLines_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLines_24acc_clo;
V g_heff_2ebuild_2edriver_2eisTestEl(V);
V g_heff_2ebuild_2edriver_2eisTestEl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestEl_clo;
V g_heff_2ebuild_2edriver_2elistOfV(V);
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_clo;
V g_heff_2ebuild_2edriver_2elistOfV_24dps(V, V);
V g_heff_2ebuild_2edriver_2elistOfV_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_24dps_clo;
V g_heff_2ebuild_2edriver_2elistedName(V);
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistedName_clo;
V g_heff_2ebuild_2edriver_2emkWatchInfo(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2emkWatchInfo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emkWatchInfo_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2enubStrD_24dps(V, V);
V g_heff_2ebuild_2edriver_2enubStrD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_24dps_clo;
V g_heff_2ebuild_2edriver_2eopenNames(V);
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_clo;
V g_heff_2ebuild_2edriver_2eopenNames_24dps(V, V);
V g_heff_2ebuild_2edriver_2eopenNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_24dps_clo;
HeffT2 g_heff_2ebuild_2edriver_2eownKeyOf_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eownUses(V, V);
V g_heff_2ebuild_2edriver_2eownUses_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eownUses_clo;
V g_heff_2ebuild_2edriver_2ereachOwn(V, V, V);
V g_heff_2ebuild_2edriver_2ereachOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ereachOwn_clo;
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2edriver_2estructIdxGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructIdxGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructIdxGo_clo;
V g_heff_2ebuild_2edriver_2etestOwner(V, V);
V g_heff_2ebuild_2edriver_2etestOwner_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestOwner_clo;
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked(V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo;
V g_heff_2ebuild_2edriver_2etypeArgsOf(V, V);
V g_heff_2ebuild_2edriver_2etypeArgsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etypeArgsOf_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2edriver_2ewithEntry(V, V, V);
V g_heff_2ebuild_2edriver_2ewithEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithEntry_clo;
V g_heff_2ebuild_2edriver_2ewithHiddenOne(V, V);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithHiddenOne_clo;
V g_heff_2ebuild_2edriver_2ewithImportedInstances(V, V, V);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo;
V g_heff_2ebuild_2edriver_2ewithStruct(V, V, V);
V g_heff_2ebuild_2edriver_2ewithStruct_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithStruct_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2eglobalEnvGo(V, V);
V g_heff_2ecompile_2einterp_2eglobalEnvGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eglobalEnvGo_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eisData(V, V);
V g_heff_2esyntax_2esurfaceprint_2eisData_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eisData_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s1955261718x109443523(V, V, V);
V g_list_2eany_24s1955261718x109443523_entry(V self, V *a);
extern Clo g_list_2eany_24s1955261718x109443523_clo;
V g_list_2eany_24s285809686x1684902122(V, V);
V g_list_2eany_24s285809686x1684902122_entry(V self, V *a);
extern Clo g_list_2eany_24s285809686x1684902122_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s75764538x1218461500(V, V, V);
V g_list_2efoldl_24s75764538x1218461500_entry(V self, V *a);
extern Clo g_list_2efoldl_24s75764538x1218461500_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s2115931744x466898799(V, V);
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2ekeepIf_24s958254147x1083401940(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1749649202x1754028860(V, V);
V g_list_2emap_24f1749649202x1754028860_entry(V self, V *a);
extern Clo g_list_2emap_24f1749649202x1754028860_clo;
V g_list_2emap_24s1354328764x1362350361(V);
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s262223576x596329185(V, V, V, V, V);
V g_list_2emap_24s262223576x596329185_entry(V self, V *a);
extern Clo g_list_2emap_24s262223576x596329185_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ebuild_2edriver_2eappendD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendD_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eappendD(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = ({ V a_0 = v_xs_243; V a_1 = v_ys_241; V a_2 = v_cell_244; V r_ = (g_heff_2ebuild_2edriver_2eappendD_24dps(a_0, a_1, a_2)); heff_drop(v_ys_241); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendD(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2eappendD_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendD_24dps_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eappendD_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendD_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eappendD_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2edriver_2enubStrD_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2enubStrD_24dps_entry, 2, 0};

V g_heff_2ebuild_2edriver_2enubStrD_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s930188071x496633547(v_x_242, v_xs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2enubStrD_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2enubStrD_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2ewithEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithEntry_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithEntry(V v_k_240, V v_c_241, V v_g_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_242, 1), v_k_240));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_k_240);
      heff_drop_rec(v_c_241, 14);
      V v_e_246 = v_field_245;
      heff_drop(v_e_246);
      return v_g_242;
    } else {
      heff_drop(v_field_245);
      V v_g_247 = heff_get_n(heff_get_n(v_c_241, 5, 14), 0, 10);
      V v_entries_248 = heff_take_field(v_g_247, 1);
      V v_aliases_249 = heff_get_n(v_g_247, 2, 8);
      HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_248, v_k_240));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_entries_248);
          heff_drop(v_aliases_249);
          V v_e_2413 = v_field_2412;
          return ({ V a_0 = v_k_240; V a_1 = v_e_2413; V a_2 = v_g_242; V r_ = (g_heff_2eelab_2eglobals_2eaddEntry(a_0, a_1, a_2)); heff_drop(v_e_2413); r_; });
        } else {
          heff_drop(v_field_2412);
          HeffT2 v_t_2414 = ({ V a_0 = v_aliases_249; V a_1 = v_k_240; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_249); r_; });
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_k2_2417 = v_field_2416;
              HeffT2 v_t_2418 = ({ V a_0 = v_entries_248; V a_1 = v_k2_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_248); heff_drop(v_k2_2417); r_; });
              {
                V v_field_2420 = v_t_2418.f[1];
                int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                if ((v_tag_2419 == ((int64_t)0ULL))) {
                  V v_e_2421 = v_field_2420;
                  return ({ V a_0 = v_k_240; V a_1 = v_e_2421; V a_2 = v_g_242; V r_ = (g_heff_2eelab_2eglobals_2eaddEntry(a_0, a_1, a_2)); heff_drop(v_e_2421); r_; });
                } else {
                  heff_drop(v_k_240);
                  heff_drop(v_field_2420);
                  return v_g_242;
                }
              }
            } else {
              heff_drop(v_k_240);
              heff_drop(v_entries_248);
              heff_drop(v_field_2416);
              return v_g_242;
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2ewithEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithEntry(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_xs_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_name_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_tags_245 = heff_dup(heff_rfield(v_x_242, 1));
    if (heff_strEq_c_lent(v_name_244, v_lit_240, 1)) {
      V v_t_246 = v_tags_245;
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_246);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_tags_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewithHiddenOne_str0, 4, "(..)");
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam3(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewithHiddenOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithHiddenOne_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ewithHiddenOne(V v_g_240, V v_c_241) {
top: ;
  V v_exposes_242 = heff_take_field(v_c_241, 13);
  V v_own_243 = heff_take_field(v_c_241, 7);
  V v_module_244 = heff_get_n(v_c_241, 0, 14);
  V v_t_245 = heff_dup(v_exposes_242);
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_es_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_t_249 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithHiddenOne_lam0, 1, 1, (V[]){v_es_246}); V a_1 = heff_dup(v_own_243); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2413 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithHiddenOne_lam1, 2, 1, (V[]){heff_dup(v_module_244)}); V a_1 = v_g_240; V a_2 = v_t_249; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_249); r_; });
  V v_t_2414 = v_exposes_242;
  V v_t_2418;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    heff_drop(v_own_243);
    v_t_2418 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_es_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    v_t_2418 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithHiddenOne_lam2, 1, 1, (V[]){v_es_2415}); V a_1 = v_own_243; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  return ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithHiddenOne_lam3, 2, 1, (V[]){v_module_244}); V a_1 = v_t_2413; V a_2 = v_t_2418; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2418); r_; });
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithHiddenOne(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam0(V self, V *args) {
  V v_o_247 = args[0];
  V v_es_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = ({ V b_0 = heff_get_n(v_o_247, 0, 2); V a_1 = v_es_246; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_246); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
  heff_drop(v_x1_248);
  return v_ret_24bool;
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam1(V self, V *args) {
  V v_g2_2410 = args[0];
  V v_o_2411 = args[1];
  V v_module_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V a_0 = heff_take_field(v_g2_2410, 6); V b_1 = heff_get_n(v_o_2411, 1, 2); V a_2 = v_module_244; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_module_244); r_; });
  return ({ V rv_6 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_g2_2410, 191ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 53247u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam2(V self, V *args) {
  V v_o_2416 = args[0];
  V v_es_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2417 = ({ V b_0 = heff_get_n(v_o_2416, 0, 2); V a_1 = v_es_2415; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s2096958470x1930932429(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_2415); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2417) == NTAG(TAG_True)));
  heff_drop(v_x1_2417);
  return v_ret_24bool;
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam3(V self, V *args) {
  V v_g2_2419 = args[0];
  V v_o_2420 = args[1];
  V v_module_244 = heff_env(self)[0];
  V v_t_2421 = heff_strAppend(heff_get_n(v_o_2420, 1, 2), ((V)&g_heff_2ebuild_2edriver_2ewithHiddenOne_str0));
  heff_clo_take(self, 1);
  V v_t_2422 = ({ V a_0 = heff_take_field(v_g2_2419, 6); V a_1 = v_t_2421; V a_2 = v_module_244; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2421); heff_drop(v_module_244); r_; });
  return ({ V rv_6 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_g2_2419, 191ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 53247u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithImportedInstances_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithImportedInstances(V v_done_240, V v_modules_241, V v_g_242) {
top: ;
  return ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0, 2, 1, (V[]){heff_dup(v_done_240)}); V a_1 = v_g_242; V a_2 = v_modules_241; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ewithImportedInstances(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1(V self, V *args) {
  V v_k_2412 = args[0];
  V v_c_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = ({ V b_0 = heff_take_field(v_c_248, 13); V a_1 = heff_get_n(v_c_248, 7, 14); V r_ = (g_heff_2ebuild_2edriver_2eexposedIn(b_0, a_1)); heff_drop(b_0); r_; });
  return ({ V a_0 = v_k_2412; V a_1 = v_t_2413; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448(a_0, a_1)); heff_drop(v_k_2412); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam2(V self, V *args) {
  V v_g3_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_t_2417 = (g_list_2ekeepIf_24s2115931744x466898799(v_k_2416, heff_take_field(v_g3_2415, 7)));
  heff_clo_take(self, 1);
  V v_t_2418 = heff_rec_n(2, shape_key__module, (V[]){v_k_2416, heff_get_n(v_c_248, 0, 14)});
  return ({ V rv_7 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2417}); V rr_ = heff_rec_reuse_nf(v_g3_2415, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0(V self, V *args) {
  V v_g2_243 = args[0];
  V v_m_244 = args[1];
  V v_done_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = ({ V a_0 = v_done_240; V a_1 = v_m_244; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(a_0, a_1)); heff_drop(v_done_240); heff_drop(v_m_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_c_248 = v_field_247;
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_248, 5)), 0, 10);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_249, 7, 8)));
      V v_t_2411 = (g_list_2emap_24f1749649202x1754028860(v_c_248, v_t_2410));
      V v_t_2414 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1, 1, 1, (V[]){heff_dup(v_c_248)}); V a_1 = v_t_2411; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      return ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam2, 2, 1, (V[]){v_c_248}); V a_1 = v_g2_243; V a_2 = v_t_2414; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2414); r_; });
    } else {
      heff_drop(v_field_247);
      return v_g2_243;
    }
  }
}
Clo g_heff_2ebuild_2edriver_2eopenNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eopenNames_24dps_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eopenNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_i_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_alias_244 = heff_take_field(v_i_242, 1);
    V v_name_245 = heff_get_n(v_i_242, 0, 3);
    V v_t_246 = v_alias_244;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_245, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
      V t_0 = v_rest_243;
      V t_1 = v_u_248;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eopenNames_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eopenNames_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2estructIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructIdxGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2estructIdxGo(V v_i_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, heff_rfield(v_r_243, 1), v_i_240));
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_t_245;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_m_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2estructIdxGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2estructIdxGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_entry, 6, 0};

V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(V v_xs_240, V v_r_241, V v_i_242, V v_depth_243, V v_box_24i_244, V v_a_245) {
  int64_t v_i_244 = heff_unbox_word(v_box_24i_244);
  v_a_245 = heff_arrayOwn(v_a_245);
  if (((((int64_t)0ULL) <= v_i_244) && (heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
      V v_t2_246 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_244), 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t2_246}));
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      V t_2 = v_i_242;
      V t_3 = v_depth_243;
      int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
      V t_5 = heff_arraySetOwnedIn(v_a_245, heff_box_word(v_i_244), v_t_247);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_i_242 = t_2;
      v_depth_243 = t_3;
      v_i_244 = t_4;
      v_a_245 = t_5;
      goto top_TAG_InRange;
    } else {
      return v_a_245;
    }
  } else {
  }
top: ;
  if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
    V v_t2_246 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_244), 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t2_246}));
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    V t_2 = v_i_242;
    V t_3 = v_depth_243;
    int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
    V t_5 = heff_arraySetOwned(v_a_245, heff_box_word(v_i_244), v_t_247);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_i_242 = t_2;
    v_depth_243 = t_3;
    v_i_244 = t_4;
    v_a_245 = t_5;
    goto top;
  } else {
    return v_a_245;
  }
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(a0, a1, a2, a3, a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam0(V self, V *args); static Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam0, 1, 0};
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam1(V self, V *args); static Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam1, 1, 0};
Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1(V v_r_240, V v_i_241, V v_depth_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if ((((int64_t)0ULL) <= v_i_243)) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_xs_245 = heff_arrayIndexIn_lent(v_a_244, heff_box_word(v_i_243), 2);
      V v_m_246 = heff_arrayLength_lent(v_xs_245, 0);
      V v_t_2411;
      if ((heff_peek_word(v_m_246) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_245);
        v_t_2411 = heff_arrayGenerate(v_m_246, ((V)&g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam0_clo));
      } else {
        V v_t2_248 = heff_arrayIndex_lent(v_xs_245, MK_INT(0LL), 2);
        V v_y_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_241), heff_dup(v_depth_242), v_t2_248}));
        V v_t_2410 = heff_arrayKeepsAs_lent(v_xs_245, v_y_249, 0);
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_m_246);
          heff_drop(v_t_2410);
          v_t_2411 = (g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(v_r_240, v_i_241, v_depth_242, MK_INT(1LL), heff_arraySet(v_xs_245, MK_INT(0LL), v_y_249)));
        } else {
          heff_drop(v_t_2410);
          v_t_2411 = ({ V a_0 = v_xs_245; V a_1 = v_r_240; V a_2 = v_i_241; V a_3 = v_depth_242; V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_246, v_y_249); V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_245); r_; });
        }
      }
      V t_0 = v_r_240;
      V t_1 = v_i_241;
      V t_2 = v_depth_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_2411);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_depth_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_xs_245 = heff_arrayIndex_lent(v_a_244, heff_box_word(v_i_243), 2);
    V v_m_246 = heff_arrayLength_lent(v_xs_245, 0);
    V v_t_2411;
    if ((heff_peek_word(v_m_246) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_245);
      v_t_2411 = heff_arrayGenerate(v_m_246, ((V)&g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam1_clo));
    } else {
      V v_t2_248 = heff_arrayIndex_lent(v_xs_245, MK_INT(0LL), 2);
      V v_y_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_241), heff_dup(v_depth_242), v_t2_248}));
      V v_t_2410 = heff_arrayKeepsAs_lent(v_xs_245, v_y_249, 0);
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_m_246);
        heff_drop(v_t_2410);
        v_t_2411 = (g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(v_r_240, v_i_241, v_depth_242, MK_INT(1LL), heff_arraySet(v_xs_245, MK_INT(0LL), v_y_249)));
      } else {
        heff_drop(v_t_2410);
        v_t_2411 = ({ V a_0 = v_xs_245; V a_1 = v_r_240; V a_2 = v_i_241; V a_3 = v_depth_242; V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_246, v_y_249); V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_245); r_; });
      }
    }
    V t_0 = v_r_240;
    V t_1 = v_i_241;
    V t_2 = v_depth_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_2411);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_depth_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    return v_a_244;
  }
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2ecloseTypeF_24map1(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam0(V self, V *args) {
  V v_u_247 = args[0];
  heff_drop(v_u_247);
  return heff_abandon();
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_lam1(V self, V *args) {
  V v_u_247 = args[0];
  heff_drop(v_u_247);
  return heff_abandon();
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam0(V self, V *args); static Clo g_heff_2ebuild_2edriver_2ecloseTermF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_lam0, 1, 0};
V g_heff_2ebuild_2edriver_2ecloseTermF_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ecloseTermF_lam2(V self, V *args); static Clo g_heff_2ebuild_2edriver_2ecloseTermF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_lam2, 1, 0};
Clo g_heff_2ebuild_2edriver_2ecloseTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTermF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SGlobal: {
    V v_k_246 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SGlobal = heff_take_reuse_n(v_e_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_idx_241, v_k_246));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_j_2410 = v_field_249;
        if (heff_intLt_c_lent(v_j_2410, v_i_242, 0)) {
          heff_drop(v_k_246);
          heff_drop_cell(v_ru_24e_244_24SGlobal, 1);
          V v_t_2411 = heff_intSub(heff_intSub(v_i_242, MK_INT(1LL)), v_j_2410);
          return heff_tag_n(TAG_SLocal, 1, (V[]){heff_intAdd(v_depth_243, v_t_2411)});
        } else {
          heff_drop(v_i_242);
          heff_drop(v_depth_243);
          heff_drop(v_j_2410);
          return heff_tag_re_n(v_ru_24e_244_24SGlobal, TAG_SGlobal, 1, 1ULL, (V[]){v_k_246});
        }
      } else {
        heff_drop(v_i_242);
        heff_drop(v_depth_243);
        heff_drop(v_field_249);
        return heff_tag_re_n(v_ru_24e_244_24SGlobal, TAG_SGlobal, 1, 1ULL, (V[]){v_k_246});
      }
    }
  }
  case TAG_SCode: {
    V v_t_2412 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SCode = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2412}));
    return heff_tag_at_n(v_ru_24e_244_24SCode, TAG_SCode, 1, (V[]){v_t_2413});
  }
  case TAG_SApp: {
    V v_f_2414 = heff_field(v_e_244, 0);
    V v_a2_2415 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SApp = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_f_2414}));
    V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_a2_2415}));
    return heff_tag_at_n(v_ru_24e_244_24SApp, TAG_SApp, 2, (V[]){v_t_2416, v_t_2417});
  }
  case TAG_SLam: {
    V v_t_2418 = heff_field(v_e_244, 0);
    V v_b_2419 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SLam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t_2418}));
    V v_t_2426;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_MkAbs: {
      V v_x_2421 = heff_field(v_b_2419, 0);
      V v_t_2422 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24MkAbs = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2422}));
      v_t_2426 = heff_tag_re_n(v_ru_24b_2419_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2421, v_t_2423});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2424 = heff_field(v_b_2419, 0);
      V v_ru_24b_2419_24AbsConst = heff_take_reuse_n(v_b_2419, 1ULL, 1);
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2424}));
      v_t_2426 = heff_tag_at_n(v_ru_24b_2419_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2425});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at_n(v_ru_24e_244_24SLam, TAG_SLam, 2, (V[]){v_t_2420, v_t_2426});
  }
  case TAG_SCons: {
    V v_d_2427 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SCons = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_xs_2428 = heff_take_field(v_d_2427, 2);
    V v_m_2429 = heff_arrayLength_lent(v_xs_2428, 0);
    V v_t_2434;
    if ((heff_peek_word(v_m_2429) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_i_242);
      heff_drop(v_depth_243);
      heff_drop(v_xs_2428);
      v_t_2434 = heff_arrayGenerate(v_m_2429, ((V)&g_heff_2ebuild_2edriver_2ecloseTermF_lam0_clo));
    } else {
      V v_e2_2431 = heff_arrayIndex_lent(v_xs_2428, MK_INT(0LL), 2);
      V v_y_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2431}));
      V v_t_2433 = heff_arrayKeepsAs_lent(v_xs_2428, v_y_2432, 0);
      if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
        heff_drop(v_m_2429);
        heff_drop(v_t_2433);
        v_t_2434 = ({ V a_0 = v_r_240; V a_1 = v_i_242; V a_2 = v_depth_243; V a_3 = MK_INT(1LL); V a_4 = heff_arraySet(v_xs_2428, MK_INT(0LL), v_y_2432); V r_ = (g_heff_2ebuild_2edriver_2ecloseTermF_24map0(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_r_240, 2); heff_drop(v_i_242); heff_drop(v_depth_243); r_; });
      } else {
        heff_drop(v_t_2433);
        v_t_2434 = ({ V a_0 = v_xs_2428; V a_1 = v_r_240; V a_2 = v_i_242; V a_3 = v_depth_243; V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_2429, v_y_2432); V r_ = (g_heff_2ebuild_2edriver_2ecloseTermF_24generate0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_2428); heff_drop_rec(v_r_240, 2); heff_drop(v_i_242); heff_drop(v_depth_243); r_; });
      }
    }
    V v_t_2435 = ({ V rv_2 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_d_2427, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_244_24SCons, TAG_SCons, 1, (V[]){v_t_2435});
  }
  case TAG_SProj: {
    V v_e2_2436 = heff_field(v_e_244, 0);
    V v_l_2437 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SProj = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2436}));
    return heff_tag_re_n(v_ru_24e_244_24SProj, TAG_SProj, 2, 2ULL, (V[]){v_t_2438, v_l_2437});
  }
  case TAG_STag: {
    V v_t_2439 = heff_field(v_e_244, 0);
    V v_args_2440 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24STag = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2442 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTermF_lam1, 1, 3, (V[]){v_r_240, v_i_242, v_depth_243}), heff_arrayToList(v_args_2440)));
    return heff_tag_re_n(v_ru_24e_244_24STag, TAG_STag, 2, 1ULL, (V[]){v_t_2439, heff_arrayFromList(v_t_2442)});
  }
  case TAG_SMatch: {
    V v_e2_2443 = heff_field(v_e_244, 0);
    V v_cs_2444 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SMatch = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2443}));
    V v_xs_2446 = heff_take_field(v_cs_2444, 2);
    V v_m_2447 = heff_arrayLength_lent(v_xs_2446, 0);
    V v_t_2456;
    if ((heff_peek_word(v_m_2447) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_i_242);
      heff_drop(v_depth_243);
      heff_drop(v_xs_2446);
      v_t_2456 = heff_arrayGenerate(v_m_2447, ((V)&g_heff_2ebuild_2edriver_2ecloseTermF_lam2_clo));
    } else {
      V v_p_2449 = heff_arrayIndex_lent(v_xs_2446, MK_INT(0LL), 2);
      V v_y_2454;
      switch (heff_tag_of(v_p_2449)) {
      case TAG_MkPair: {
        V v_xs_2450 = heff_field(v_p_2449, 0);
        V v_b_2451 = heff_field(v_p_2449, 1);
        V v_ru_24p_2449_24MkPair = heff_take_reuse_n(v_p_2449, 3ULL, 2);
        V v_t_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_2450)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_intAdd_lent(v_depth_243, v_t_2452, 2), v_b_2451}));
        v_y_2454 = heff_tag_re_n(v_ru_24p_2449_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_2450, v_t_2453});
        break;
      }
      default: heff_nomatch(v_p_2449);
      }
      V v_t_2455 = heff_arrayKeepsAs_lent(v_xs_2446, v_y_2454, 0);
      if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
        heff_drop(v_m_2447);
        heff_drop(v_t_2455);
        v_t_2456 = ({ V a_0 = v_r_240; V a_1 = v_i_242; V a_2 = v_depth_243; V a_3 = MK_INT(1LL); V a_4 = heff_arraySet(v_xs_2446, MK_INT(0LL), v_y_2454); V r_ = (g_heff_2ebuild_2edriver_2ecloseTermF_24map1(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_r_240, 2); heff_drop(v_i_242); heff_drop(v_depth_243); r_; });
      } else {
        heff_drop(v_t_2455);
        v_t_2456 = ({ V a_0 = v_xs_2446; V a_1 = v_r_240; V a_2 = v_i_242; V a_3 = v_depth_243; V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_2447, v_y_2454); V r_ = (g_heff_2ebuild_2edriver_2ecloseTermF_24generate1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_2446); heff_drop_rec(v_r_240, 2); heff_drop(v_i_242); heff_drop(v_depth_243); r_; });
      }
    }
    V v_t_2457 = ({ V rv_2 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_cs_2444, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_244_24SMatch, TAG_SMatch, 2, (V[]){v_t_2445, v_t_2457});
  }
  case TAG_SSpecialize: {
    V v_e2_2458 = heff_field(v_e_244, 0);
    V v_l_2459 = heff_field(v_e_244, 1);
    V v_v_2460 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24SSpecialize = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2458}));
    V v_t_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_v_2460}));
    return heff_tag_re_n(v_ru_24e_244_24SSpecialize, TAG_SSpecialize, 3, 2ULL, (V[]){v_t_2461, v_l_2459, v_t_2462});
  }
  case TAG_SIs: {
    V v_e2_2463 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SIs = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2463}));
    return heff_tag_at_n(v_ru_24e_244_24SIs, TAG_SIs, 1, (V[]){v_t_2464});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SRec: {
    V v_e2_2465 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SRec = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2465}));
    return heff_tag_at_n(v_ru_24e_244_24SRec, TAG_SRec, 1, (V[]){v_t_2466});
  }
  case TAG_SFix: {
    V v_t_2467 = heff_field(v_e_244, 0);
    V v_b_2468 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SFix = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2469 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t_2467}));
    V v_t_2475;
    switch (heff_tag_of(v_b_2468)) {
    case TAG_MkAbs: {
      V v_x_2470 = heff_field(v_b_2468, 0);
      V v_t_2471 = heff_field(v_b_2468, 1);
      V v_ru_24b_2468_24MkAbs = heff_take_reuse_n(v_b_2468, 3ULL, 2);
      V v_t_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2471}));
      v_t_2475 = heff_tag_re_n(v_ru_24b_2468_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2470, v_t_2472});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2473 = heff_field(v_b_2468, 0);
      V v_ru_24b_2468_24AbsConst = heff_take_reuse_n(v_b_2468, 1ULL, 1);
      V v_t_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2473}));
      v_t_2475 = heff_tag_at_n(v_ru_24b_2468_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2474});
      break;
    }
    default: heff_nomatch(v_b_2468);
    }
    return heff_tag_at_n(v_ru_24e_244_24SFix, TAG_SFix, 2, (V[]){v_t_2469, v_t_2475});
  }
  case TAG_SImplicit: {
    V v_x_2476 = heff_field(v_e_244, 0);
    V v_e2_2477 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SImplicit = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2477}));
    return heff_tag_re_n(v_ru_24e_244_24SImplicit, TAG_SImplicit, 2, 1ULL, (V[]){v_x_2476, v_t_2478});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SMetaApp: {
    V v_m_2480 = heff_field(v_e_244, 0);
    V v_xs_2481 = heff_field(v_e_244, 1);
    V v_t_2482 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24SMetaApp = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2482}));
    return heff_tag_re_n(v_ru_24e_244_24SMetaApp, TAG_SMetaApp, 3, 3ULL, (V[]){v_m_2480, v_xs_2481, v_t_2483});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ecloseTermF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam0(V self, V *args) {
  V v_u_2430 = args[0];
  heff_drop(v_u_2430);
  return heff_abandon();
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam1(V self, V *args) {
  V v_e2_2441 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_i_242 = heff_env(self)[1];
  V v_depth_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_i_242;
  heff_room[1] = v_depth_243;
  heff_room[2] = v_e2_2441;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam2(V self, V *args) {
  V v_u_2448 = args[0];
  heff_drop(v_u_2448);
  return heff_abandon();
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ethawedChecked_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2ethawedChecked_str1, 1, ".");
Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ethawedChecked_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ethawedChecked(V v_s_240, V v_imps_241, V v_th_242, V v_t_243) {
top: ;
  V v_claim_244 = heff_take_field(v_imps_241, 2);
  V v_imports_245 = heff_take_field(v_imps_241, 0);
  V v_implicit_246 = heff_get_n(v_imps_241, 1, 4);
  V v_shown_247 = heff_take_field(v_s_240, 3);
  V v_source_248 = heff_take_field(v_s_240, 4);
  V v_module_249 = heff_take_field(v_s_240, 0);
  V v_path_2410 = heff_get_n(v_s_240, 2, 8);
  V v_shown_2411 = v_shown_247;
  V v_source_2412 = v_source_248;
  V v_t_2413 = heff_dup(v_claim_244);
  V v_t_2418;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2414 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    V v_listed_2415 = heff_take_field(v_h_2414, 1);
    V v_exposes_2416 = heff_get_n(v_h_2414, 2, 5);
    V v_t_2417 = v_listed_2415;
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      v_t_2418 = heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){v_exposes_2416});
    } else {
      heff_drop_cell(v_ru_24t_2413_24Just, 1);
      heff_drop(v_exposes_2416);
      heff_drop(v_t_2417);
      v_t_2418 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_t_2419 = (g_list_2emap_24s262223576x596329185(heff_dup(v_module_249), ((V)&g_heff_2ebuild_2edriver_2ethawedChecked_str0), MK_INT(0LL), MK_INT(1LL), heff_dup(heff_rfield(v_t_243, 2))));
  V v_t_2420 = ({ V a_0 = v_t_2418; V a_1 = v_t_2419; V r_ = (g_heff_2ebuild_2edriver_2eexposedIn(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_top_2421 = (g_heff_2ebuild_2edriver_2ewithStruct(heff_dup(v_module_249), v_t_2420, heff_dup(v_t_243)));
  V v_own_2422 = (g_list_2emap_24s262223576x596329185(heff_dup(v_module_249), ((V)&g_heff_2ebuild_2edriver_2ethawedChecked_str1), MK_INT(0LL), MK_INT(1LL), heff_get_n(v_t_243, 2, 10)));
  V v_t_2423 = (g_list_2emap_24s1817208647x1282894070(heff_dup(v_imports_245)));
  V v_deps_2424 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2423));
  V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_implicit_246));
  V v_t_2426 = (g_list_2edrop(v_t_2425, v_imports_245));
  V v_opens_2427 = (g_heff_2ebuild_2edriver_2eopenNames(v_t_2426));
  V v_t_2428 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_implicit_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_implicit_246); r_; });
  V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_imports_245; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_imports_245); r_; });
  V v_aliases_2430 = (g_heff_2ebuild_2edriver_2ealiasPairs(v_t_2429));
  V v_t_2431 = v_claim_244;
  V v_t_2436;
  switch (heff_tag_of(v_t_2431)) {
  case TAG_Nothing: {
    v_t_2436 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2432 = heff_field(v_t_2431, 0);
    V v_ru_24t_2431_24Just = heff_take_reuse_n(v_t_2431, 1ULL, 1);
    V v_listed_2433 = heff_take_field(v_h_2432, 1);
    V v_exposes_2434 = heff_get_n(v_h_2432, 2, 5);
    V v_t_2435 = v_listed_2433;
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_t_2435);
      v_t_2436 = heff_tag_at_n(v_ru_24t_2431_24Just, TAG_Just, 1, (V[]){v_exposes_2434});
    } else {
      heff_drop_cell(v_ru_24t_2431_24Just, 1);
      heff_drop(v_exposes_2434);
      heff_drop(v_t_2435);
      v_t_2436 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_t_2431);
  }
  return heff_rec_n(14, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes, (V[]){v_module_249, v_path_2410, v_shown_2411, v_source_2412, NTAG(TAG_Nil), v_top_2421, NTAG(TAG_Nil), v_own_2422, v_deps_2424, v_opens_2427, v_aliases_2430, heff_get_n(v_th_242, 0, 3), NTAG(TAG_True), v_t_2436});
}
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ethawedChecked(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str1, 17, "` is listed twice");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str3, 40, "` has no tags to expose: list it bare, `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str5, 23, "the module defines no `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str6, 43, "`: a module claim lists its own definitions");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str7, 23, "the module defines no `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str8, 43, "`: a module claim lists its own definitions");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str9, 23, "the module defines no `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str10, 43, "`: a module claim lists its own definitions");
Clo g_heff_2ebuild_2edriver_2eexposedDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexposedDiag_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eexposedDiag(V v_g_240, V v_own_241, V v_before_242, V v_x_243) {
top: ;
  V v_name_244 = heff_take_field(v_x_243, 0);
  V v_span_245 = heff_take_field(v_x_243, 2);
  V v_tags_246 = heff_get_n(v_x_243, 1, 3);
  V v_t_247 = (g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(v_name_244, v_before_242));
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_tags_246);
    heff_drop(v_t_247);
    V v_t_248 = (g_heff_2ebuild_2edriver_2elistedName(v_name_244));
    V v_msg_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str0), v_t_248), ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str1));
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(155LL), NTAG(TAG_SError), v_msg_249, v_span_245, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_247);
    HeffT2 v_t_2411 = (g_heff_2ebuild_2edriver_2eownKeyOf_24cpr(v_own_241, v_name_244));
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_k_2414 = v_field_2413;
        V v_t_2415 = v_tags_246;
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          V v_g_2416 = v_g_240;
          V v_entries_2417 = heff_take_field(v_g_2416, 1);
          V v_aliases_2418 = heff_get_n(v_g_2416, 2, 8);
          V v_k_2419 = v_k_2414;
          HeffT2 v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2417, v_k_2419));
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            V v_x1_2436;
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              heff_drop(v_entries_2417);
              heff_drop(v_aliases_2418);
              heff_drop(v_k_2419);
              V v_e_2423 = v_field_2422;
              V v_tySyntax_2424 = heff_take_field(v_e_2423, 1);
              V v_syntax_2425 = heff_get_n(v_e_2423, 0, 4);
              v_x1_2436 = (g_heff_2esyntax_2esurfaceprint_2eisData(v_tySyntax_2424, v_syntax_2425));
            } else {
              heff_drop(v_field_2422);
              HeffT2 v_t_2426 = ({ V a_0 = v_aliases_2418; V a_1 = v_k_2419; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2418); heff_drop(v_k_2419); r_; });
              {
                V v_field_2428 = v_t_2426.f[1];
                int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                if ((v_tag_2427 == ((int64_t)0ULL))) {
                  V v_k2_2429 = v_field_2428;
                  HeffT2 v_t_2430 = ({ V a_0 = v_entries_2417; V a_1 = v_k2_2429; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2417); heff_drop(v_k2_2429); r_; });
                  {
                    V v_field_2432 = v_t_2430.f[1];
                    int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
                    if ((v_tag_2431 == ((int64_t)0ULL))) {
                      V v_e_2433 = v_field_2432;
                      V v_tySyntax_2434 = heff_take_field(v_e_2433, 1);
                      V v_syntax_2435 = heff_get_n(v_e_2433, 0, 4);
                      v_x1_2436 = (g_heff_2esyntax_2esurfaceprint_2eisData(v_tySyntax_2434, v_syntax_2435));
                    } else {
                      heff_drop(v_field_2432);
                      v_x1_2436 = NTAG(TAG_False);
                    }
                  }
                } else {
                  heff_drop(v_entries_2417);
                  heff_drop(v_field_2428);
                  v_x1_2436 = NTAG(TAG_False);
                }
              }
            }
            if (!(heff_dup(v_x1_2436) == NTAG(TAG_True))) {
              heff_drop(v_x1_2436);
              V v_t_2437 = (g_heff_2ebuild_2edriver_2elistedName(heff_dup(v_name_244)));
              V v_t_2438 = (g_heff_2ebuild_2edriver_2elistedName(v_name_244));
              V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str2), v_t_2437), ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str3));
              V v_msg_2440 = heff_strAppend(heff_strAppend(v_t_2439, v_t_2438), ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str4));
              V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(155LL), NTAG(TAG_SError), v_msg_2440, v_span_245, NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
            } else {
              heff_drop(v_name_244);
              heff_drop(v_span_245);
              heff_drop(v_x1_2436);
              return NTAG(TAG_Nil);
            }
          }
        } else {
          heff_drop(v_g_240);
          heff_drop(v_name_244);
          heff_drop(v_span_245);
          heff_drop(v_k_2414);
          heff_drop(v_t_2415);
          return NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_tags_246);
        heff_drop(v_field_2413);
        HeffT3 v_t_2442 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g_240, heff_dup(v_name_244)));
        {
          V v_field_2444 = v_t_2442.f[1];
          V v_field_2445 = v_t_2442.f[2];
          int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
          if ((v_tag_2443 == ((int64_t)0ULL))) {
            heff_drop(v_field_2445);
            V v_x_2446 = v_field_2444;
            heff_drop(v_x_2446);
            V v_t_2447 = (g_heff_2ebuild_2edriver_2elistedName(v_name_244));
            V v_msg_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str5), v_t_2447), ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str6));
            V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(155LL), NTAG(TAG_SError), v_msg_2448, v_span_245, NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
          } else {
            if ((v_tag_2443 == ((int64_t)1ULL))) {
              heff_drop(v_name_244);
              heff_drop(v_span_245);
              heff_drop(v_field_2444);
              heff_drop(v_field_2445);
              return NTAG(TAG_Nil);
            } else {
              if ((v_tag_2443 == ((int64_t)2ULL))) {
                V v_x_2450 = v_field_2444;
                heff_drop(v_x_2450);
                V v_x_2451 = v_field_2445;
                heff_drop(v_x_2451);
                V v_t_2452 = (g_heff_2ebuild_2edriver_2elistedName(v_name_244));
                V v_msg_2453 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str7), v_t_2452), ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str8));
                V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(155LL), NTAG(TAG_SError), v_msg_2453, v_span_245, NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
              } else {
                heff_drop(v_field_2444);
                heff_drop(v_field_2445);
                V v_t_2455 = (g_heff_2ebuild_2edriver_2elistedName(v_name_244));
                V v_msg_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str9), v_t_2455), ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str10));
                V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(155LL), NTAG(TAG_SError), v_msg_2456, v_span_245, NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2eexposedDiag_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eexposedDiag(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2etypeArgsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etypeArgsOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etypeArgsOf(V v_lvl_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LikeU: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFunction: {
    V v_dom_244 = heff_field(v_x2_241, 1);
    V v_cod_245 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 4);
    V v_t_247 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(v_lvl_240), heff_dup(v_dom_244)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_x1_2414;
      switch (heff_tag_of(v_cod_245)) {
      case TAG_MkClo: {
        V v_vs_249 = heff_field(v_cod_245, 1);
        V v_body_2410 = heff_field(v_cod_245, 2);
        heff_take_n(v_cod_245, 6ULL, 3);
        v_x1_2414 = heff_tr(heff_call(v_body_2410, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo_n(g_heff_2ebuild_2edriver_2etypeArgsOf_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_244})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2413 = heff_field(v_cod_245, 0);
        heff_take_n(v_cod_245, 1ULL, 1);
        heff_drop(v_dom_244);
        v_x1_2414 = v_body_2413;
        break;
      }
      default: heff_nomatch(v_cod_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nom: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        v_t_2418 = v_x_2415;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        v_t_2418 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2417 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        v_t_2418 = v_x_2417;
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_t_2419 = (g_heff_2eelab_2evalue_2ebehavior(v_t_2418));
      V v_t_2420 = (g_heff_2ebuild_2edriver_2etypeArgsOf(heff_intAdd(v_lvl_240, MK_INT(1LL)), v_t_2419));
      return heff_intAdd(MK_INT(1LL), v_t_2420);
    } else {
      heff_drop(v_lvl_240);
      heff_drop(v_dom_244);
      heff_drop(v_cod_245);
      heff_drop(v_t_247);
      return MK_INT(0LL);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeSum: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeRune: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeArray: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etypeArgsOf(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_244 = heff_env(self)[0];
  heff_drop(v_u_2412);
  heff_clo_take(self, 1);
  return v_dom_244;
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_244 = heff_env(self)[1];
  heff_drop(v_u_2411);
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2ebuild_2edriver_2etypeArgsOf_lam1, 1, 1, (V[]){v_dom_244}), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchesOf_str0, 8, "-- | >>>");
V g_heff_2ebuild_2edriver_2ewatchesOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ewatchesOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewatchesOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ewatchesOf(V v_c_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_ws_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 14);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_gs_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
    V v_entries_245 = heff_take_field(v_gs_244, 1);
    V v_order_246 = heff_get_n(v_gs_244, 0, 8);
    V v_t_2413 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewatchesOf_lam0, 2, 1, (V[]){v_entries_245}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_246; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_order_246); r_; });
    V v_ge_2414 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2einterp_2eglobalEnvGo(a_0, a_1)); heff_drop(v_t_2413); r_; });
    HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ewatchesOf_lam1, 1, 2, (V[]){v_c_240, v_ge_2414}), v_ws_241);
  }
  default: return heff_nomatch(v_ws_241);
  }
}
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewatchesOf(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2ewatchesOf_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_k_248 = args[1];
  V v_entries_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V a_0 = v_entries_245; V a_1 = v_k_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_245); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_e_2412 = v_field_2411;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_248, v_e_2412}), v_acc_247});
    } else {
      heff_drop(v_k_248);
      heff_drop(v_field_2411);
      return v_acc_247;
    }
  }
}
V g_heff_2ebuild_2edriver_2ewatchesOf_lam1(V self, V *args) {
  V v_w_2415 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ge_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2416 = v_c_240;
  V v_ge_2417 = v_ge_2414;
  V v_w_2418 = v_w_2415;
  V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_w_2418, 1)), 3, 4);
  V v_t_2420 = heff_get_n(heff_dup(heff_rfield(v_w_2418, 1)), 0, 4);
  V v_x1_2421 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(heff_dup(v_ge_2417), v_t_2420, MK_INT(0LL)));
  V v_t_2422 = (g_heff_2eelab_2evalue_2ebehavior(v_t_2419));
  V v_t_2423 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_2422));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Ok: {
    V v_v_2424 = heff_field(v_x1_2421, 0);
    V v_ru_24x1_2421_24Ok = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
    v_t_2426 = heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2424});
    break;
  }
  case TAG_Abn: {
    v_t_2426 = NTAG(TAG_RAbandoned);
    break;
  }
  case TAG_Div: {
    v_t_2426 = NTAG(TAG_RDiverged);
    break;
  }
  case TAG_Bug: {
    V v_what_2425 = heff_field(v_x1_2421, 0);
    V v_ru_24x1_2421_24Bug = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
    v_t_2426 = heff_tag_at_n(v_ru_24x1_2421_24Bug, TAG_RBug, 1, (V[]){v_what_2425});
    break;
  }
  default: heff_nomatch(v_x1_2421);
  }
  V v_t_2427 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_2423, v_t_2426));
  V v_src_2428 = heff_dup(heff_rfield(v_c_2416, 3));
  V v_sp_2429 = heff_dup(heff_rfield(v_w_2418, 0));
  V v_start_2430 = heff_take_field(v_sp_2429, 0);
  V v_end_2431 = heff_get_n(v_sp_2429, 1, 2);
  V v_start_2432 = v_start_2430;
  V v_t_2433 = heff_strSlice(heff_dup(v_src_2428), heff_dup(v_start_2432), heff_intAdd(v_start_2432, MK_INT(8LL)));
  V v_t_2434 = heff_bool(heff_strEq_c_lent(v_t_2433, ((V)&g_heff_2ebuild_2edriver_2ewatchesOf_str0), 2));
  heff_drop(v_t_2433);
  V v_t_2435 = ({ V a_0 = v_t_2434; V a_1 = v_src_2428; V a_2 = v_end_2431; V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(a_0, a_1, a_2)); heff_drop(v_t_2434); heff_drop(v_src_2428); heff_drop(v_end_2431); r_; });
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_w_2418, 1)), 3, 4);
  V v_t_2437 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_2436));
  V v_t_2438 = heff_get_n(heff_dup(heff_rfield(v_c_2416, 5)), 0, 10);
  V v_t_2439 = (g_heff_2ebuild_2edriver_2eshowTySx(v_t_2438, v_t_2437));
  return (g_heff_2ebuild_2edriver_2emkWatchInfo(v_c_2416, v_ge_2417, v_w_2418, v_t_2427, v_t_2435, v_t_2439));
}
V g_heff_2ebuild_2edriver_2etestOwner_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2etestOwner_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etestOwner_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etestOwner(V v_c_240, V v_from_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 10);
  V v_x1_248 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_clo_n(g_heff_2ebuild_2edriver_2etestOwner_lam0, 1, 2, (V[]){v_from_241, v_c_240}); V a_2 = v_t_242; V r_ = (g_list_2efoldl_24f1428393365x1980555854(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_249, 0, 2)});
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2ebuild_2edriver_2etestOwner_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etestOwner(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2etestOwner_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_from_241 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_m_243, 1)), 0, 2);
  if (heff_intLt_c_lent(v_t_244, v_from_241, 1)) {
    heff_clo_take(self, 2);
    V v_t_245 = heff_get_n(heff_get_n(v_c_240, 5, 14), 6, 10);
    V v_t_246 = (g_list_2emap_24s1354328764x1362350361(v_t_245));
    V v_x1_247 = ({ V a_0 = v_m_243; V a_1 = v_from_241; V a_2 = v_t_246; V r_ = (g_list_2eany_24s1955261718x109443523(a_0, a_1, a_2)); heff_drop_rec(v_m_243, 2); heff_drop(v_from_241); heff_drop(v_t_246); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
    heff_drop(v_x1_247);
    return v_ret_24bool;
  } else {
    heff_drop_rec(v_m_243, 2);
    heff_drop(self);
    return NTAG(TAG_False);
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2etestReportOf_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2etestReportOf_str1, 1, "\012");
Clo g_heff_2ebuild_2edriver_2etestReportOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etestReportOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etestReportOf(V v_c_240, V v_w_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_w_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_dup(heff_rfield(v_w_241, 6));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 14);
      heff_drop_rec(v_w_241, 10);
      heff_drop(v_t_243);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_243);
      V v_t_244 = heff_dup(heff_rfield(v_w_241, 9));
      V v_t_2412;
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 10);
        V v_t_246 = ({ V a_0 = heff_rfield(v_w_241, 1); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_245; V r_ = (g_list_2efoldl_24s75764538x1218461500(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
        switch (heff_tag_of(v_t_246)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_p_247 = heff_field(v_t_246, 0);
          V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
          V v_t_2410;
          switch (heff_tag_of(v_p_247)) {
          case TAG_MkPair: {
            V v_x_248 = heff_field(v_p_247, 0);
            heff_take_n(v_p_247, 1ULL, 2);
            v_t_2410 = v_x_248;
            break;
          }
          default: heff_nomatch(v_p_247);
          }
          V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_t_2410));
          v_t_2412 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_t_2411});
          break;
        }
        default: heff_nomatch(v_t_246);
        }
      } else {
        heff_drop(v_t_244);
        v_t_2412 = (g_heff_2ebuild_2edriver_2etestOwner(heff_dup(v_c_240), heff_dup(heff_rfield(v_w_241, 0))));
      }
      V v_src_2413 = heff_get_n(v_c_240, 3, 14);
      V v_j_2414 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2etestReportOf_str0), v_src_2413, MK_INT(0LL), 5);
      V v_t_2415;
      if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
        heff_drop(v_j_2414);
        v_t_2415 = NTAG(TAG_Nothing);
      } else {
        v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2414});
      }
      HeffT3 v_t_2416 = ({ V a_0 = v_src_2413; V a_1 = heff_rfield(v_w_241, 0); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_2415; HeffT3 r_ = (g_heff_2elsp_2erender_2elineColAt_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2413); r_; });
      {
        V v_field_2417 = v_t_2416.f[0];
        heff_drop(v_t_2416.f[1]);
        heff_drop(v_t_2416.f[2]);
        V v_t_2420 = heff_rec_n(3, shape_owner__line__watch, (V[]){v_t_2412, heff_intAdd(v_field_2417, MK_INT(1LL)), v_w_241});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
      }
    }
  }
  case TAG_Just: {
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 0ULL, 1);
    V v_t_2422 = heff_dup(heff_rfield(v_w_241, 9));
    V v_t_2430;
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_t_2422);
      V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 10);
      V v_t_2424 = ({ V a_0 = heff_rfield(v_w_241, 1); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2423; V r_ = (g_list_2efoldl_24s75764538x1218461500(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
      switch (heff_tag_of(v_t_2424)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_242_24Just, 1);
        v_t_2430 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_p_2425 = heff_field(v_t_2424, 0);
        heff_take_n(v_t_2424, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_p_2425)) {
        case TAG_MkPair: {
          V v_x_2426 = heff_field(v_p_2425, 0);
          heff_take_n(v_p_2425, 1ULL, 2);
          v_t_2428 = v_x_2426;
          break;
        }
        default: heff_nomatch(v_p_2425);
        }
        V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_t_2428));
        v_t_2430 = heff_tag_at_n(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_t_2429});
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
    } else {
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      heff_drop(v_t_2422);
      v_t_2430 = (g_heff_2ebuild_2edriver_2etestOwner(heff_dup(v_c_240), heff_dup(heff_rfield(v_w_241, 0))));
    }
    V v_src_2431 = heff_get_n(v_c_240, 3, 14);
    V v_j_2432 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2etestReportOf_str1), v_src_2431, MK_INT(0LL), 5);
    V v_t_2433;
    if (heff_intLt_c_lent(v_j_2432, MK_INT(0LL), 2)) {
      heff_drop(v_j_2432);
      v_t_2433 = NTAG(TAG_Nothing);
    } else {
      v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2432});
    }
    HeffT3 v_t_2434 = ({ V a_0 = v_src_2431; V a_1 = heff_rfield(v_w_241, 0); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_2433; HeffT3 r_ = (g_heff_2elsp_2erender_2elineColAt_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2431); r_; });
    {
      V v_field_2435 = v_t_2434.f[0];
      heff_drop(v_t_2434.f[1]);
      heff_drop(v_t_2434.f[2]);
      V v_t_2438 = heff_rec_n(3, shape_owner__line__watch, (V[]){v_t_2430, heff_intAdd(v_field_2435, MK_INT(1LL)), v_w_241});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2438});
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etestReportOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eisTestEl_str0, 10, "check.Test");
Clo g_heff_2ebuild_2edriver_2eisTestEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eisTestEl_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eisTestEl(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_k_242, ((V)&g_heff_2ebuild_2edriver_2eisTestEl_str0), 2));
    return v_ret_24bool;
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eisTestEl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eisTestEl(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eownUses_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eownUses_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eownUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eownUses_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eownUses(V v_c_240, V v_k_241) {
top: ;
  V v_top_242 = heff_take_field(v_c_240, 5);
  V v_own_243 = heff_get_n(v_c_240, 7, 14);
  V v_g_244 = heff_get_n(v_top_242, 0, 10);
  V v_entries_245 = heff_take_field(v_g_244, 1);
  V v_aliases_246 = heff_get_n(v_g_244, 2, 8);
  HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_245, v_k_241));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_entries_245);
      heff_drop(v_aliases_246);
      V v_e_2410 = v_field_249;
      V v_t_2411 = ({ V b_0 = heff_get_n(v_e_2410, 0, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(b_0)); heff_drop(b_0); r_; });
      V v_t_2412 = (g_heff_2eelab_2erename_2enubFirst(v_t_2411));
      return ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eownUses_lam0, 1, 1, (V[]){v_own_243}); V a_1 = v_t_2412; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_field_249);
      HeffT2 v_t_2414 = ({ V a_0 = v_aliases_246; V a_1 = v_k_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_246); r_; });
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_k2_2417 = v_field_2416;
          HeffT2 v_t_2418 = ({ V a_0 = v_entries_245; V a_1 = v_k2_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_245); heff_drop(v_k2_2417); r_; });
          {
            V v_field_2420 = v_t_2418.f[1];
            int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
            if ((v_tag_2419 == ((int64_t)0ULL))) {
              V v_e_2421 = v_field_2420;
              V v_t_2422 = ({ V b_0 = heff_get_n(v_e_2421, 0, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(b_0)); heff_drop(b_0); r_; });
              V v_t_2423 = (g_heff_2eelab_2erename_2enubFirst(v_t_2422));
              return ({ V b_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eownUses_lam1, 1, 1, (V[]){v_own_243}); V a_1 = v_t_2423; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
            } else {
              heff_drop(v_own_243);
              heff_drop(v_field_2420);
              return NTAG(TAG_Nil);
            }
          }
        } else {
          heff_drop(v_own_243);
          heff_drop(v_entries_245);
          heff_drop(v_field_2416);
          return NTAG(TAG_Nil);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2eownUses_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eownUses(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2eownUses_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_own_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_u_2413; V a_1 = v_own_243; V r_ = (g_list_2eany_24s285809686x1684902122(a_0, a_1)); heff_drop(v_u_2413); heff_drop(v_own_243); r_; });
}
V g_heff_2ebuild_2edriver_2eownUses_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_own_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_u_2424; V a_1 = v_own_243; V r_ = (g_list_2eany_24s285809686x1684902122(a_0, a_1)); heff_drop(v_u_2424); heff_drop(v_own_243); r_; });
}
Clo g_heff_2ebuild_2edriver_2ereachOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ereachOwn_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ereachOwn(V v_c_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1477604419x1568736711(v_k_243, v_seen_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_k_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_c_240;
      V t_1 = v_seen_241;
      V t_2 = v_rest_244;
      v_c_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ebuild_2edriver_2eownUses(heff_dup(v_c_240), v_k_243));
      V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_rest_244));
      V t_0 = v_c_240;
      V t_1 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_k_243, v_seen_241});
      V t_2 = v_t_247;
      v_c_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2ereachOwn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ereachOwn(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str11, 4, "Cons");
Clo g_heff_2ebuild_2edriver_2elistOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elistOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elistOfV(V v_v_240) {
top: ;
  V v_t_2414;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_field(v_v_240, 0);
    v_t_2414 = heff_dup(v_x_243);
    break;
  }
  case TAG_VInt: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str3);
    break;
  }
  case TAG_VFloat32: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str4);
    break;
  }
  case TAG_VStr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str5);
    break;
  }
  case TAG_VRune: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str6);
    break;
  }
  case TAG_VArr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str7);
    break;
  }
  case TAG_VBytes: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str8);
    break;
  }
  case TAG_VBits: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str9);
    break;
  }
  case TAG_VErased: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str10);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edriver_2elistOfV_str11))) {
    V v_t_2428;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2418 = heff_field(v_v_240, 1);
      v_t_2428 = heff_dup(v_vs_2418);
      break;
    }
    case TAG_VInt: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    HeffT3 v_t_2429 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2428; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2428); r_; });
    {
      V v_field_2431 = v_t_2429.f[1];
      V v_field_2432 = v_t_2429.f[2];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      V v_t_2435;
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_x_2433 = v_field_2431;
        V v_x12_2434 = v_field_2432;
        heff_drop(v_x12_2434);
        v_t_2435 = v_x_2433;
      } else {
        heff_drop(v_field_2431);
        heff_drop(v_field_2432);
        v_t_2435 = NTAG(TAG_VErased);
      }
      V v_t_2449;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2439 = heff_field(v_v_240, 1);
        v_t_2449 = heff_dup(v_vs_2439);
        break;
      }
      case TAG_VInt: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      HeffT3 v_t_2450 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2449; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2449); r_; });
      {
        V v_field_2452 = v_t_2450.f[1];
        V v_field_2453 = v_t_2450.f[2];
        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
        V v_t_2456;
        if ((v_tag_2451 == ((int64_t)0ULL))) {
          V v_x_2454 = v_field_2452;
          V v_x12_2455 = v_field_2453;
          heff_drop(v_x12_2455);
          v_t_2456 = v_x_2454;
        } else {
          heff_drop(v_field_2452);
          heff_drop(v_field_2453);
          v_t_2456 = NTAG(TAG_VErased);
        }
        V v_cell_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, heff_hole()});
        V v_u_2458 = (g_heff_2ebuild_2edriver_2elistOfV_24dps(v_t_2456, v_cell_2457));
        heff_drop(v_u_2458);
        return v_cell_2457;
      }
    }
  } else {
    return NTAG(TAG_Nil);
  }
}
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2elistOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str0, 7, "> test ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str1, 17, "check.runSelected");
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str2, 20, "> test integrations ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str3, 26, "check.integrationsSelected");
Clo g_heff_2ebuild_2edriver_2eaddTests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eaddTests_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eaddTests(V v_pattern_240, V v_seed_241, V v_i_242, V v_x4_243, V v_g_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return v_g_244;
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eaddTests_str0), heff_intShow(heff_dup(v_i_242)));
    V v_t_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_SApp, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2eaddTests_str1)}), heff_tag_n(TAG_SLitString, 1, (V[]){heff_dup(v_pattern_240)})});
    V v_t_249 = heff_tag_n(TAG_SApp, 2, (V[]){v_t_248, heff_tag_n(TAG_SLitInt, 1, (V[]){heff_dup(v_seed_241)})});
    V v_t_2410 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_dup(heff_rfield(v_o_245, 1))});
    V v_t_2411 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_t_249, v_t_2410}), NTAG(TAG_SPrimInt), NTAG(TAG_VOpaque), NTAG(TAG_VPrimInt)});
    V v_t_2412 = ({ V a_0 = v_t_247; V a_1 = v_t_2411; V a_2 = v_g_244; V r_ = (g_heff_2eelab_2eglobals_2eaddEntry(a_0, a_1, a_2)); heff_drop_rec(v_t_2411, 4); r_; });
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eaddTests_str2), heff_intShow(heff_dup(v_i_242)));
    V v_t_2414 = heff_tag_n(TAG_SApp, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2eaddTests_str3)}), heff_tag_n(TAG_SLitString, 1, (V[]){heff_dup(v_pattern_240)})});
    V v_t_2415 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_get_n(v_o_245, 1, 2)});
    V v_t_2416 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_t_2414, v_t_2415}), NTAG(TAG_SPrimInt), NTAG(TAG_VOpaque), NTAG(TAG_VPrimInt)});
    V v_t_2417 = ({ V a_0 = v_t_2413; V a_1 = v_t_2416; V a_2 = v_t_2412; V r_ = (g_heff_2eelab_2eglobals_2eaddEntry(a_0, a_1, a_2)); heff_drop_rec(v_t_2416, 4); r_; });
    V t_0 = v_pattern_240;
    V t_1 = v_seed_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_rest_246;
    V t_4 = v_t_2417;
    v_pattern_240 = t_0;
    v_seed_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_g_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2edriver_2eaddTests_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eaddTests(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLines_str0, 0, "");
Clo g_heff_2ebuild_2edriver_2efixityLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixityLines_entry, 3, 0};

V g_heff_2ebuild_2edriver_2efixityLines(V v_fx_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_fx_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2ebuild_2edriver_2efixityLines_str0);
  }
  case TAG_Cons: {
    V v_g_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2edriver_2efixityLine(heff_dup(v_fx_240), v_i_241, heff_dup(v_g_243)));
    V v_s_246 = v_t_245;
    return ({ V a_0 = v_fx_240; V a_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))); V a_2 = v_rest_244; V a_3 = v_s_246; V r_ = (g_heff_2ebuild_2edriver_2efixityLines_24acc(a_0, a_1, a_2, a_3)); heff_drop(v_fx_240); r_; });
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2efixityLines_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2efixityLines(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ecandidatesOf_str0, 1, "#");
V g_heff_2ebuild_2edriver_2ecandidatesOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecandidatesOf_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ecandidatesOf(V v_c_240) {
top: ;
  V v_t_241 = (g_list_2ekeepIf_24s958254147x1083401940(MK_INT(0LL), ((V)&g_heff_2ebuild_2edriver_2ecandidatesOf_str0), MK_INT(0LL), MK_INT(97LL), MK_INT(0LL), MK_INT(0LL), MK_INT(122LL), MK_INT(65LL), MK_INT(0LL), MK_INT(0LL), MK_INT(90LL), heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ecandidatesOf_lam0, 1, 1, (V[]){v_c_240}), v_t_241));
  HEFF_LAST return g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_249);
}
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecandidatesOf(a[0]);
}
V g_heff_2ebuild_2edriver_2ecandidatesOf_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_key_243 = heff_take_field(v_o_242, 1);
  V v_name_244 = heff_get_n(v_o_242, 0, 2);
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_240, v_key_243));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_eff_248 = v_field_247;
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_name__key__effect, (V[]){v_name_244, v_key_243, v_eff_248})});
    } else {
      heff_drop(v_key_243);
      heff_drop(v_name_244);
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendD_24tok2_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eappendD_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = ({ V a_0 = v_xs_244; V a_1 = v_ys_242; V a_2 = v_cell_245; V r_ = (g_heff_2ebuild_2edriver_2eappendD_24dps(a_0, a_1, a_2)); heff_drop(v_ys_242); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendD_24tok2(a[0], a[1], a[2]);
}