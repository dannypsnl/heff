// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_ArrayLength 32493
#define TAG_Bin 14227
#define TAG_BytesLength 9005
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_CustodianDue 8759
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FuelTick 47424
#define TAG_FuelTicks 28388
#define TAG_IntAdd 18227
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntSub 36050
#define TAG_MkArm 55352
#define TAG_Perform 19235
#define TAG_PerformAt 64592
#define TAG_StrLength 43075
#define TAG_Tip 31527
#define LBL_array 294448755
#define LBL_goes 9673821
#define LBL_index 301704428
#define LBL_round 310062504
#define LBL_step 10036115
static uint32_t shape_index__step__goes__round__array[] = {LBL_index, LBL_step, LBL_goes, LBL_round, LBL_array};
V g_heff_2ecompile_2efuel_2earrayBelow(V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2earrayBelow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2earrayBelow_clo;
V g_heff_2ecompile_2efuel_2ebatchedBy(V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2ebatchedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ebatchedBy_clo;
V g_heff_2ecompile_2efuel_2ecallsNothing(V);
V g_heff_2ecompile_2efuel_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecallsNothing_clo;
V g_heff_2ecompile_2efuel_2ecloses(V, V);
V g_heff_2ecompile_2efuel_2ecloses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecloses_clo;
V g_heff_2ecompile_2efuel_2ecounted(V, V, V);
V g_heff_2ecompile_2efuel_2ecounted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecounted_clo;
V g_heff_2ecompile_2efuel_2ecountedAt(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2ecountedAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecountedAt_clo;
V g_heff_2ecompile_2efuel_2ecountedAt_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2ecountedAt_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecountedAt_24tok1_clo;
V g_heff_2ecompile_2efuel_2ecountedAt_24tok3(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2ecountedAt_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecountedAt_24tok3_clo;
V g_heff_2ecompile_2efuel_2ecountedBatched(V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2ecountedBatched_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecountedBatched_clo;
V g_heff_2ecompile_2efuel_2egiven(V, V, V, V, V);
V g_heff_2ecompile_2efuel_2egiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2egiven_clo;
V g_heff_2ecompile_2efuel_2egiven_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2egiven_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2egiven_24dps_clo;
V g_heff_2ecompile_2efuel_2egivenTo(V, V);
V g_heff_2ecompile_2efuel_2egivenTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2egivenTo_clo;
V g_heff_2ecompile_2efuel_2einRange(V, V, V);
V g_heff_2ecompile_2efuel_2einRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2einRange_clo;
HeffT3 g_heff_2ecompile_2efuel_2eindexOf2_24cpr(V, V, V, V);
V g_heff_2ecompile_2efuel_2einvariant(V, V);
V g_heff_2ecompile_2efuel_2einvariant_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2einvariant_clo;
V g_heff_2ecompile_2efuel_2enextOf(V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2enextOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2enextOf_clo;
V g_heff_2ecompile_2efuel_2enumbered(V, V, V);
V g_heff_2ecompile_2efuel_2enumbered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2enumbered_clo;
V g_heff_2ecompile_2efuel_2eonlyRoundW(V, V);
V g_heff_2ecompile_2efuel_2eonlyRoundW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2eonlyRoundW_clo;
HeffT3 g_heff_2ecompile_2efuel_2eroundArm_24cpr(V, V);
V g_heff_2ecompile_2efuel_2eroundCalls(V, V);
V g_heff_2ecompile_2efuel_2eroundCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2eroundCalls_clo;
V g_heff_2ecompile_2efuel_2eroundsOf(V, V);
V g_heff_2ecompile_2efuel_2eroundsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2eroundsOf_clo;
HeffT2 g_heff_2ecompile_2efuel_2estepOf_24cpr(V, V);
V g_heff_2ecompile_2efuel_2etickedIn(V, V);
V g_heff_2ecompile_2efuel_2etickedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2etickedIn_clo;
V g_heff_2ecompile_2efuel_2eunrolled(V, V, V, V, V);
V g_heff_2ecompile_2efuel_2eunrolled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2eunrolled_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886(V, V, V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s371864724x604755177(V, V);
V g_list_2eany_24s371864724x604755177_entry(V self, V *a);
extern Clo g_list_2eany_24s371864724x604755177_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2etraverse_24s75890152x1871550235(V, V, V, V);
V g_prelude_2etraverse_24s75890152x1871550235_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s75890152x1871550235_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_heff_2ecompile_2efuel_2enumbered_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuel_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2enumbered_entry, 3, 0};

V g_heff_2ecompile_2efuel_2enumbered(V v_m_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return v_m_240;
  }
  case TAG_Cons: {
    V v_g_243 = heff_field(v_x3_242, 0);
    V v_gs_244 = heff_field(v_x3_242, 1);
    V v_t_247 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2efuel_2enumbered_lam0, 2, 1, (V[]){heff_dup(v_i_241)}); V a_1 = v_m_240; V a_2 = v_g_243; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V t_0 = v_t_247;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_gs_244;
    v_m_240 = t_0;
    v_i_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuel_2enumbered_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2efuel_2enumbered(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2efuel_2enumbered_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_k_246 = args[1];
  V v_i_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_acc_245; V a_1 = v_k_246; V a_2 = v_i_241; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_246); heff_drop(v_i_241); r_; });
}
Clo g_heff_2ecompile_2efuel_2ecloses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2ecloses_entry, 2, 0};

V g_heff_2ecompile_2efuel_2ecloses(V v_inGroup_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ELam: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_inGroup_240;
      V t_1 = v_rest_243;
      v_inGroup_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_246 = heff_field(v_x21_242, 0);
      V v_args_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_f_246)) {
      case TAG_EVar: {
        heff_take_n(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EGlobal: {
        V v_g_249 = heff_field(v_f_246, 0);
        heff_take_n(v_f_246, 1ULL, 1);
        V v_t_2410 = heff_tr(heff_call(heff_dup(v_inGroup_240), 1, (V[]){v_g_249}));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_args_247);
          heff_drop(v_t_2410);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2410);
          V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_247, v_rest_243));
          V t_0 = v_inGroup_240;
          V t_1 = v_t_2411;
          v_inGroup_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_ELam: {
        heff_take_n(v_f_246, 0ULL, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EApp: {
        heff_take_n(v_f_246, 0ULL, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_ELet: {
        heff_take_n(v_f_246, 0ULL, 3);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_ERecord: {
        heff_take_n(v_f_246, 0ULL, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EProj: {
        heff_take_n(v_f_246, 0ULL, 4);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_ETag: {
        heff_take_n(v_f_246, 0ULL, 3);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EMatch: {
        heff_take_n(v_f_246, 0ULL, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EPrim: {
        heff_take_n(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_f_246, 0ULL, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_ECall: {
        heff_take_n(v_f_246, 0ULL, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EInt: {
        heff_take_n(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EFloat: {
        heff_take_nf(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EStr: {
        heff_take_n(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EBytes: {
        heff_take_n(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EFixed: {
        heff_take_n(v_f_246, 0ULL, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EFloat32: {
        heff_take_na(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EAbandon: {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EBool: {
        heff_take_n(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_ESet: {
        heff_take_n(v_f_246, 0ULL, 3);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EValues: {
        heff_take_n(v_f_246, 0ULL, 1);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      case TAG_EFix: {
        heff_take_n(v_f_246, 0ULL, 2);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_247);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_f_246);
      }
    }
    case TAG_ECall: {
      V v_g_2449 = heff_field(v_x21_242, 0);
      V v_args_2450 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2451 = heff_tr(heff_call(heff_dup(v_inGroup_240), 1, (V[]){v_g_2449}));
      if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_args_2450);
        heff_drop(v_t_2451);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2451);
        V v_t_2452 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_2450, v_rest_243));
        V t_0 = v_inGroup_240;
        V t_1 = v_t_2452;
        v_inGroup_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2453 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_inGroup_240;
      V t_1 = v_t_2453;
      v_inGroup_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuel_2ecloses_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuel_2ecloses(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuel_2etickedIn_str0, 5, "fuel$");
V g_heff_2ecompile_2efuel_2etickedIn_lam1(V self, V *args);
V g_heff_2ecompile_2efuel_2etickedIn_lam2(V self, V *args);
V g_heff_2ecompile_2efuel_2etickedIn_lam0(V self, V *args);
V g_heff_2ecompile_2efuel_2etickedIn_lam3(V self, V *args);
Clo g_heff_2ecompile_2efuel_2etickedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2etickedIn_entry, 2, 0};

V g_heff_2ecompile_2efuel_2etickedIn(V v_inGroup_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ELam: {
    V v_xs_242 = heff_field(v_e_241, 0);
    V v_b_243 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2efuel_2etickedIn(v_inGroup_240, v_b_243));
    return heff_clo_n(g_heff_2ecompile_2efuel_2etickedIn_lam0, 1, 3, (V[]){v_m_244, heff_dup(v_inGroup_240), v_xs_242});
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2efuel_2etickedIn_lam3, 2, 1, (V[]){heff_dup(v_inGroup_240)}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2efuel_2etickedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuel_2etickedIn(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efuel_2etickedIn_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2efuel_2etickedIn_str0), heff_intShow(heff_dup(v_n_2411)));
  V v_t_2413 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_FuelTick), NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2412, v_t_2413, v_x_247}), heff_intAdd(v_n_2411, MK_INT(1LL))});
}
V g_heff_2ecompile_2efuel_2etickedIn_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_n_2414});
}
V g_heff_2ecompile_2efuel_2etickedIn_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_inGroup_240 = heff_env(self)[1];
  V v_xs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_247), NTAG(TAG_Nil)});
    V v_t_2410 = ({ V a_0 = v_inGroup_240; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2efuel_2ecloses(a_0, a_1)); heff_drop(v_inGroup_240); r_; });
    V v_m_2415;
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      v_m_2415 = heff_clo_n(g_heff_2ecompile_2efuel_2etickedIn_lam1, 1, 1, (V[]){v_x_247});
    } else {
      heff_drop(v_t_2410);
      v_m_2415 = heff_clo_n(g_heff_2ecompile_2efuel_2etickedIn_lam2, 1, 1, (V[]){v_x_247});
    }
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_n_2418 = heff_field(v_x2_2416, 1);
      V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_ELam, 2, (V[]){v_xs_242, v_x_2417}), v_n_2418});
    }
    default: return heff_nomatch(v_x2_2416);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2efuel_2etickedIn_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_p_2420 = args[1];
  V v_inGroup_240 = heff_env(self)[0];
  heff_drop(v_x_2419);
  heff_clo_take(self, 1);
  return ({ V a_0 = v_inGroup_240; V a_1 = v_p_2420; V r_ = (g_heff_2ecompile_2efuel_2etickedIn(a_0, a_1)); heff_drop(v_inGroup_240); r_; });
}
Clo g_heff_2ecompile_2efuel_2ecallsNothing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2ecallsNothing_entry, 1, 0};

V g_heff_2ecompile_2efuel_2ecallsNothing(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      V v_p_247 = heff_field(v_x11_241, 0);
      V v_args_248 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_p_247)) {
      case TAG_ArrayGenerate: {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_args_248);
        return NTAG(TAG_False);
      }
      case TAG_Perform: {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_args_248);
        return NTAG(TAG_False);
      }
      case TAG_PerformAt: {
        heff_take_n(v_p_247, 0ULL, 1);
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_args_248);
        return NTAG(TAG_False);
      }
      case TAG_FuelTick: {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_args_248);
        return NTAG(TAG_False);
      }
      case TAG_FuelTicks: {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_args_248);
        return NTAG(TAG_False);
      }
      case TAG_CustodianDue: {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_args_248);
        return NTAG(TAG_False);
      }
      default: {
        heff_drop(v_p_247);
        V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24Cons, v_args_248, v_rest_242));
        V t_0 = v_t_2410;
        v_x1_240 = t_0;
        goto top;
      }
      }
    }
    case TAG_ECall: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_False);
    }
    default: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_2413 = (g_heff_2ecompile_2eir_2epartsOnto(v_x11_241, v_rest_242));
      V t_0 = v_t_2413;
      v_x1_240 = t_0;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuel_2ecallsNothing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuel_2ecallsNothing(a[0]);
}
V g_heff_2ecompile_2efuel_2eroundCalls_lam0(V self, V *args);
V g_heff_2ecompile_2efuel_2eroundCalls_lam1(V self, V *args);
V g_heff_2ecompile_2efuel_2eroundCalls_lam2(V self, V *args);
Clo g_heff_2ecompile_2efuel_2eroundCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2eroundCalls_entry, 2, 0};

V g_heff_2ecompile_2efuel_2eroundCalls(V v_k_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    switch (heff_tag_of(v_a_249)) {
    case TAG_ELam: {
      V t_0 = v_k_240;
      V t_1 = v_b_2410;
      v_k_240 = t_0;
      v_e_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      V v_p_2415 = heff_field(v_a_249, 0);
      V v_args_2416 = heff_field(v_a_249, 1);
      switch (heff_tag_of(v_p_2415)) {
      case TAG_ArrayGenerate: {
        return NTAG(TAG_True);
      }
      case TAG_Perform: {
        return NTAG(TAG_True);
      }
      case TAG_PerformAt: {
        return NTAG(TAG_True);
      }
      case TAG_FuelTick: {
        return NTAG(TAG_True);
      }
      case TAG_FuelTicks: {
        return NTAG(TAG_True);
      }
      case TAG_CustodianDue: {
        return NTAG(TAG_True);
      }
      default: {
        V v_t_2418 = (g_heff_2ecompile_2eir_2eappendI(heff_dup(v_args_2416), NTAG(TAG_Nil)));
        V v_x1_2419 = (g_heff_2ecompile_2efuel_2ecallsNothing(v_t_2418));
        if (!(heff_dup(v_x1_2419) == NTAG(TAG_True))) {
          heff_drop(v_x1_2419);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_x1_2419);
          V t_0 = v_k_240;
          V t_1 = v_b_2410;
          v_k_240 = t_0;
          v_e_241 = t_1;
          goto top;
        }
      }
      }
    }
    case TAG_ECall: {
      return NTAG(TAG_True);
    }
    default: {
      V v_t_2422 = (g_heff_2ecompile_2eir_2epartsOnto(heff_dup(v_a_249), NTAG(TAG_Nil)));
      V v_x1_2423 = (g_heff_2ecompile_2efuel_2ecallsNothing(v_t_2422));
      if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
        heff_drop(v_x1_2423);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_x1_2423);
        V t_0 = v_k_240;
        V t_1 = v_b_2410;
        v_k_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    }
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2433 = heff_field(v_e_241, 0);
    V v_arms_2434 = heff_field(v_e_241, 1);
    switch (heff_tag_of(v_s_2433)) {
    case TAG_ELam: {
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2efuel_2eroundCalls_lam0, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_arms_2434; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
    }
    case TAG_EApp: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      V v_p_2444 = heff_field(v_s_2433, 0);
      V v_args_2445 = heff_field(v_s_2433, 1);
      switch (heff_tag_of(v_p_2444)) {
      case TAG_ArrayGenerate: {
        return NTAG(TAG_True);
      }
      case TAG_Perform: {
        return NTAG(TAG_True);
      }
      case TAG_PerformAt: {
        return NTAG(TAG_True);
      }
      case TAG_FuelTick: {
        return NTAG(TAG_True);
      }
      case TAG_FuelTicks: {
        return NTAG(TAG_True);
      }
      case TAG_CustodianDue: {
        return NTAG(TAG_True);
      }
      default: {
        V v_t_2447 = (g_heff_2ecompile_2eir_2eappendI(heff_dup(v_args_2445), NTAG(TAG_Nil)));
        V v_x1_2448 = (g_heff_2ecompile_2efuel_2ecallsNothing(v_t_2447));
        if (!(heff_dup(v_x1_2448) == NTAG(TAG_True))) {
          heff_drop(v_x1_2448);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_x1_2448);
          return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2efuel_2eroundCalls_lam1, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_arms_2434; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
        }
      }
      }
    }
    case TAG_ECall: {
      return NTAG(TAG_True);
    }
    default: {
      V v_t_2456 = (g_heff_2ecompile_2eir_2epartsOnto(heff_dup(v_s_2433), NTAG(TAG_Nil)));
      V v_x1_2457 = (g_heff_2ecompile_2efuel_2ecallsNothing(v_t_2456));
      if (!(heff_dup(v_x1_2457) == NTAG(TAG_True))) {
        heff_drop(v_x1_2457);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_x1_2457);
        return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2efuel_2eroundCalls_lam2, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_arms_2434; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
      }
    }
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_g_2466 = heff_field(v_e_241, 0);
    V v_args_2467 = heff_field(v_e_241, 1);
    if (heff_strEq_c_lent(v_g_2466, v_k_240, 0)) {
      V v_x1_2468 = (g_heff_2ecompile_2efuel_2ecallsNothing(heff_dup(v_args_2467)));
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2468) == NTAG(TAG_True)));
      heff_drop(v_x1_2468);
      return v_ret_24bool;
    } else {
      return NTAG(TAG_False);
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    V v_a_2478 = heff_field(v_e_241, 1);
    V v_b_2479 = heff_field(v_e_241, 2);
    switch (heff_tag_of(v_a_2478)) {
    case TAG_ELam: {
      V t_0 = v_k_240;
      V t_1 = v_b_2479;
      v_k_240 = t_0;
      v_e_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      V v_p_2484 = heff_field(v_a_2478, 0);
      V v_args_2485 = heff_field(v_a_2478, 1);
      switch (heff_tag_of(v_p_2484)) {
      case TAG_ArrayGenerate: {
        return NTAG(TAG_True);
      }
      case TAG_Perform: {
        return NTAG(TAG_True);
      }
      case TAG_PerformAt: {
        return NTAG(TAG_True);
      }
      case TAG_FuelTick: {
        return NTAG(TAG_True);
      }
      case TAG_FuelTicks: {
        return NTAG(TAG_True);
      }
      case TAG_CustodianDue: {
        return NTAG(TAG_True);
      }
      default: {
        V v_t_2487 = (g_heff_2ecompile_2eir_2eappendI(heff_dup(v_args_2485), NTAG(TAG_Nil)));
        V v_x1_2488 = (g_heff_2ecompile_2efuel_2ecallsNothing(v_t_2487));
        if (!(heff_dup(v_x1_2488) == NTAG(TAG_True))) {
          heff_drop(v_x1_2488);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_x1_2488);
          V t_0 = v_k_240;
          V t_1 = v_b_2479;
          v_k_240 = t_0;
          v_e_241 = t_1;
          goto top;
        }
      }
      }
    }
    case TAG_ECall: {
      return NTAG(TAG_True);
    }
    default: {
      V v_t_2491 = (g_heff_2ecompile_2eir_2epartsOnto(heff_dup(v_a_2478), NTAG(TAG_Nil)));
      V v_x1_2492 = (g_heff_2ecompile_2efuel_2ecallsNothing(v_t_2491));
      if (!(heff_dup(v_x1_2492) == NTAG(TAG_True))) {
        heff_drop(v_x1_2492);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_x1_2492);
        V t_0 = v_k_240;
        V t_1 = v_b_2479;
        v_k_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    }
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2efuel_2eroundCalls_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuel_2eroundCalls(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efuel_2eroundCalls_lam0(V self, V *args) {
  V v_a_2437 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_t_2441;
  switch (heff_tag_of(v_a_2437)) {
  case TAG_MkArm: {
    V v_b_2440 = heff_field(v_a_2437, 2);
    heff_take_n(v_a_2437, 4ULL, 3);
    v_t_2441 = v_b_2440;
    break;
  }
  default: heff_nomatch(v_a_2437);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_240; V a_1 = v_t_2441; V r_ = (g_heff_2ecompile_2efuel_2eroundCalls(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_t_2441); r_; });
}
V g_heff_2ecompile_2efuel_2eroundCalls_lam1(V self, V *args) {
  V v_a_2449 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_t_2453;
  switch (heff_tag_of(v_a_2449)) {
  case TAG_MkArm: {
    V v_b_2452 = heff_field(v_a_2449, 2);
    heff_take_n(v_a_2449, 4ULL, 3);
    v_t_2453 = v_b_2452;
    break;
  }
  default: heff_nomatch(v_a_2449);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_240; V a_1 = v_t_2453; V r_ = (g_heff_2ecompile_2efuel_2eroundCalls(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_t_2453); r_; });
}
V g_heff_2ecompile_2efuel_2eroundCalls_lam2(V self, V *args) {
  V v_a_2458 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_t_2462;
  switch (heff_tag_of(v_a_2458)) {
  case TAG_MkArm: {
    V v_b_2461 = heff_field(v_a_2458, 2);
    heff_take_n(v_a_2458, 4ULL, 3);
    v_t_2462 = v_b_2461;
    break;
  }
  default: heff_nomatch(v_a_2458);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_240; V a_1 = v_t_2462; V r_ = (g_heff_2ecompile_2efuel_2eroundCalls(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_t_2462); r_; });
}
Clo g_heff_2ecompile_2efuel_2eroundsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2eroundsOf_entry, 2, 0};

V g_heff_2ecompile_2efuel_2eroundsOf(V v_k_240, V v_b_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b_241, NTAG(TAG_Nil)));
  V v_x1_243 = ({ V a_0 = v_k_240; V a_1 = v_t_242; V r_ = (g_list_2eany_24s371864724x604755177(a_0, a_1)); heff_drop(v_t_242); r_; });
  if (!(heff_dup(v_x1_243) == NTAG(TAG_True))) {
    heff_drop(v_b_241);
    heff_drop(v_x1_243);
    return MK_INT(0LL);
  } else {
    heff_drop(v_x1_243);
    V v_t_244 = (g_heff_2ecompile_2efuel_2eroundCalls(v_k_240, v_b_241));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_b_241);
      heff_drop(v_t_244);
      return MK_INT(1LL);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_241, NTAG(TAG_Nil)});
      V v_t_246 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_245));
      V v_n_247 = heff_intDiv(MK_INT(64LL), v_t_246);
      if (heff_intLt_c_lent(v_n_247, MK_INT(1LL), 2)) {
        heff_drop(v_n_247);
        return MK_INT(1LL);
      } else {
        if (heff_intLt_c_lent(MK_INT(64LL), v_n_247, 1)) {
          heff_drop(v_n_247);
          return MK_INT(64LL);
        } else {
          return v_n_247;
        }
      }
    }
  }
}
V g_heff_2ecompile_2efuel_2eroundsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuel_2eroundsOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2efuel_2egiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2egiven_entry, 5, 0};

V g_heff_2ecompile_2efuel_2egiven(V v_x1_240, V v_x2_241, V v_x3_242, V v_m_243, V v_c_244) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_245 = (g_std_2eordmap_2esize(v_m_243));
    if (heff_intEq_c(v_t_245, MK_INT(0LL))) {
      heff_drop(v_m_243);
      return heff_dup(v_c_244);
    } else {
      return ({ V a_0 = v_m_243; V a_1 = heff_dup(v_c_244); V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_243); r_; });
    }
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xs_247 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      V v_t_248 = (g_std_2eordmap_2esize(v_m_243));
      if (heff_intEq_c(v_t_248, MK_INT(0LL))) {
        heff_drop(v_m_243);
        return heff_dup(v_c_244);
      } else {
        return ({ V a_0 = v_m_243; V a_1 = heff_dup(v_c_244); V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_243); r_; });
      }
    }
    case TAG_Cons: {
      V v_y_249 = heff_field(v_x2_241, 0);
      V v_ys_2410 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        V v_t_2411 = (g_std_2eordmap_2esize(v_m_243));
        if (heff_intEq_c(v_t_2411, MK_INT(0LL))) {
          heff_drop(v_m_243);
          return heff_dup(v_c_244);
        } else {
          return ({ V a_0 = v_m_243; V a_1 = heff_dup(v_c_244); V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_243); r_; });
        }
      }
      case TAG_Cons: {
        V v_a_2412 = heff_field(v_x3_242, 0);
        V v_args_2413 = heff_field(v_x3_242, 1);
        V v_t_2453;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_EVar: {
          v_t_2453 = NTAG(TAG_True);
          break;
        }
        case TAG_EGlobal: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_ELam: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EApp: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_ELet: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_ERecord: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EProj: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EMatch: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrim: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrimCall: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_ECall: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          v_t_2453 = NTAG(TAG_True);
          break;
        }
        case TAG_EFloat: {
          v_t_2453 = NTAG(TAG_True);
          break;
        }
        case TAG_EStr: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EBytes: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EFixed: {
          v_t_2453 = NTAG(TAG_True);
          break;
        }
        case TAG_EFloat32: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EAbandon: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EBool: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_ESet: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EValues: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        case TAG_EFix: {
          v_t_2453 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
          heff_drop(v_t_2453);
          V v_t_2454 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_243, v_x_246, v_a_2412));
          V t_0 = v_xs_247;
          V t_1 = v_ys_2410;
          V t_2 = v_args_2413;
          V t_3 = v_t_2454;
          V t_4 = v_c_244;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_m_243 = t_3;
          v_c_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2453);
          V v_t_2455 = ({ V a_0 = v_m_243; V a_1 = v_x_246; V b_2 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_y_249)}); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          V v_cell_2456 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_y_249), heff_dup(v_a_2412), heff_hole()});
          V v_u_2457 = (g_heff_2ecompile_2efuel_2egiven_24dps(v_xs_247, v_ys_2410, v_args_2413, v_t_2455, v_c_244, v_cell_2456));
          heff_drop(v_u_2457);
          return v_cell_2456;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuel_2egiven_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2efuel_2egiven(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2efuel_2egiven_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2egiven_24dps_entry, 6, 0};

V g_heff_2ecompile_2efuel_2egiven_24dps(V v_x1_240, V v_x2_241, V v_x3_242, V v_m_243, V v_c_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_246 = (g_std_2eordmap_2esize(v_m_243));
    if (heff_intEq_c(v_t_246, MK_INT(0LL))) {
      heff_drop(v_m_243);
      return heff_setField(heff_dup(v_d_245), MK_INT(2LL), heff_dup(v_c_244));
    } else {
      V v_t_247 = ({ V a_0 = v_m_243; V a_1 = heff_dup(v_c_244); V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_243); r_; });
      return heff_setField(heff_dup(v_d_245), MK_INT(2LL), v_t_247);
    }
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_240, 0);
    V v_xs_249 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      V v_t_2410 = (g_std_2eordmap_2esize(v_m_243));
      if (heff_intEq_c(v_t_2410, MK_INT(0LL))) {
        heff_drop(v_m_243);
        return heff_setField(heff_dup(v_d_245), MK_INT(2LL), heff_dup(v_c_244));
      } else {
        V v_t_2411 = ({ V a_0 = v_m_243; V a_1 = heff_dup(v_c_244); V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_243); r_; });
        return heff_setField(heff_dup(v_d_245), MK_INT(2LL), v_t_2411);
      }
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_x2_241, 0);
      V v_ys_2413 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        V v_t_2414 = (g_std_2eordmap_2esize(v_m_243));
        if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
          heff_drop(v_m_243);
          return heff_setField(heff_dup(v_d_245), MK_INT(2LL), heff_dup(v_c_244));
        } else {
          V v_t_2415 = ({ V a_0 = v_m_243; V a_1 = heff_dup(v_c_244); V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_243); r_; });
          return heff_setField(heff_dup(v_d_245), MK_INT(2LL), v_t_2415);
        }
      }
      case TAG_Cons: {
        V v_a_2416 = heff_field(v_x3_242, 0);
        V v_args_2417 = heff_field(v_x3_242, 1);
        V v_t_2457;
        switch (heff_tag_of(v_a_2416)) {
        case TAG_EVar: {
          v_t_2457 = NTAG(TAG_True);
          break;
        }
        case TAG_EGlobal: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_ELam: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EApp: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_ELet: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_ERecord: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EProj: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EMatch: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrim: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrimCall: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_ECall: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          v_t_2457 = NTAG(TAG_True);
          break;
        }
        case TAG_EFloat: {
          v_t_2457 = NTAG(TAG_True);
          break;
        }
        case TAG_EStr: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EBytes: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EFixed: {
          v_t_2457 = NTAG(TAG_True);
          break;
        }
        case TAG_EFloat32: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EAbandon: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EBool: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_ESet: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EValues: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_EFix: {
          v_t_2457 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_2416);
        }
        if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
          heff_drop(v_t_2457);
          V v_t_2458 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_243, v_x_248, v_a_2416));
          V t_0 = v_xs_249;
          V t_1 = v_ys_2413;
          V t_2 = v_args_2417;
          V t_3 = v_t_2458;
          V t_4 = v_c_244;
          V t_5 = v_d_245;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_m_243 = t_3;
          v_c_244 = t_4;
          v_d_245 = t_5;
          goto top;
        } else {
          heff_drop(v_t_2457);
          V v_t_2459 = ({ V a_0 = v_m_243; V a_1 = v_x_248; V b_2 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_y_2412)}); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, b_2)); heff_drop(b_2); r_; });
          V v_cell_2460 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_y_2412), heff_dup(v_a_2416), heff_hole()});
          V v_u_2461 = heff_setFieldPeek(v_d_245, MK_INT(2LL), v_cell_2460);
          V t_0 = v_xs_249;
          V t_1 = v_ys_2413;
          V t_2 = v_args_2417;
          V t_3 = v_t_2459;
          V t_4 = v_c_244;
          V t_5 = v_u_2461;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_m_243 = t_3;
          v_c_244 = t_4;
          v_d_245 = t_5;
          goto top;
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuel_2egiven_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ecompile_2efuel_2egiven_24dps(a0, a1, a2, a[3], a4, a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuel_2enextOf_str0, 1, "$");
Clo g_heff_2ecompile_2efuel_2enextOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2enextOf_entry, 6, 0};

V g_heff_2ecompile_2efuel_2enextOf(V v_k_240, V v_xs_241, V v_b_242, V v_next_243, V v_e_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_ECall: {
    V v_g_246 = heff_field(v_e_244, 0);
    V v_args_247 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_246, v_k_240, 0)) {
      heff_drop(v_g_246);
      heff_drop_cell(v_ru_24e_244_24ECall, 2);
      HeffT2 v_t_248 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), v_p_245, v_b_242));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_n_2412 = v_field_2410;
        V v_t_2413 = (g_prelude_2etraverse_24s75890152x1871550235(MK_INT(0LL), ((V)&g_heff_2ecompile_2efuel_2enextOf_str0), MK_INT(1LL), heff_dup(v_xs_241)));
        V v_x2_2414 = heff_tr(heff_call(v_t_2413, 1, (V[]){v_n_2412}));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_n_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_t_2417 = ({ V a_0 = v_xs_241; V a_1 = v_x_2415; V a_2 = v_args_247; V a_3 = heff_dup(g_std_2eordmap_2eempty_get()); V a_4 = v_x_2411; V r_ = (g_heff_2ecompile_2efuel_2egiven(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_241); heff_drop(v_x_2415); heff_drop(v_args_247); heff_drop(v_x_2411); r_; });
          return heff_tail(v_next_243, 2, (V[]){v_t_2417, v_n_2416});
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
    } else {
      heff_drop(v_xs_241);
      heff_drop(v_b_242);
      heff_drop(v_next_243);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24e_244_24ECall, TAG_ECall, 2, 3ULL, (V[]){v_g_246, v_args_247}), v_p_245});
    }
  }
  default: {
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    heff_drop(v_next_243);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_p_245});
  }
  }
}
V g_heff_2ecompile_2efuel_2enextOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuel_2enextOf(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2efuel_2eunrolled_lam0(V self, V *args);
V g_heff_2ecompile_2efuel_2eunrolled_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuel_2eunrolled_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2eunrolled_entry, 5, 0};

V g_heff_2ecompile_2efuel_2eunrolled(V v_k_240, V v_xs_241, V v_b_242, V v_j_243, V v_e_244) {
top: ;
  if (heff_intLe_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    return heff_clo_n(g_heff_2ecompile_2efuel_2eunrolled_lam0, 1, 1, (V[]){v_e_244});
  } else {
    return ({ V a_0 = v_k_240; V a_1 = v_xs_241; V a_2 = v_b_242; V b_3 = heff_clo_n(g_heff_2ecompile_2efuel_2eunrolled_lam1, 2, 4, (V[]){heff_dup(v_k_240), heff_dup(v_xs_241), heff_dup(v_b_242), v_j_243}); V a_4 = v_e_244; V r_ = (g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); r_; });
  }
}
V g_heff_2ecompile_2efuel_2eunrolled_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2efuel_2eunrolled(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2efuel_2eunrolled_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_245});
}
V g_heff_2ecompile_2efuel_2eunrolled_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_z_247 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_j_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = ({ V a_0 = v_k_240; V a_1 = v_xs_241; V a_2 = v_b_242; V a_3 = heff_intSub(v_j_243, MK_INT(1LL)); V a_4 = v_c_246; V r_ = (g_heff_2ecompile_2efuel_2eunrolled(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_240); heff_drop(v_xs_241); heff_drop(v_b_242); r_; });
  V f_ = v_t_248;
  args[0] = v_z_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ecompile_2efuel_2egivenTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2egivenTo_entry, 2, 0};

V g_heff_2ecompile_2efuel_2egivenTo(V v_xs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_ECall: {
    V v_args_243 = heff_field(v_x2_241, 1);
    V v_ps_244 = (g_list_2ezipWith_24s1876717925x1404326288(v_xs_240, heff_dup(v_args_243)));
    return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_244; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_244); r_; });
  }
  default: {
    heff_drop(v_xs_240);
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  }
}
V g_heff_2ecompile_2efuel_2egivenTo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuel_2egivenTo(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuel_2einvariant_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2einvariant_entry, 2, 0};

V g_heff_2ecompile_2efuel_2einvariant(V v_again_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_again_243 = heff_dup(v_again_240);
    V v_x_244 = heff_dup(v_x_242);
    HeffT2 v_t_245 = ({ V a_0 = v_again_243; V a_1 = v_x_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_again_243); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_it1_248 = v_field_247;
        switch (heff_tag_of(v_it1_248)) {
        case TAG_EVar: {
          V v_y_249 = heff_field(v_it1_248, 0);
          heff_take_n(v_it1_248, 1ULL, 1);
          V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_244, v_y_249, 0));
          heff_drop(v_x_244);
          heff_drop(v_y_249);
          return v_ret_24bool;
        }
        case TAG_EGlobal: {
          heff_take_n(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_ELam: {
          heff_take_n(v_it1_248, 0ULL, 2);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EApp: {
          heff_take_n(v_it1_248, 0ULL, 2);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_ELet: {
          heff_take_n(v_it1_248, 0ULL, 3);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_ERecord: {
          heff_take_n(v_it1_248, 0ULL, 2);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EProj: {
          heff_take_n(v_it1_248, 0ULL, 4);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_ETag: {
          heff_take_n(v_it1_248, 0ULL, 3);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EMatch: {
          heff_take_n(v_it1_248, 0ULL, 2);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EPrim: {
          heff_take_n(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EPrimCall: {
          heff_take_n(v_it1_248, 0ULL, 2);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_ECall: {
          heff_take_n(v_it1_248, 0ULL, 2);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EInt: {
          heff_take_n(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EFloat: {
          heff_take_nf(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EStr: {
          heff_take_n(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EBytes: {
          heff_take_n(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EFixed: {
          heff_take_n(v_it1_248, 0ULL, 2);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EFloat32: {
          heff_take_na(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EAbandon: {
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EBool: {
          heff_take_n(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_ESet: {
          heff_take_n(v_it1_248, 0ULL, 3);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EValues: {
          heff_take_n(v_it1_248, 0ULL, 1);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        case TAG_EFix: {
          heff_take_n(v_it1_248, 0ULL, 2);
          heff_drop(v_x_244);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_it1_248);
        }
      } else {
        heff_drop(v_x_244);
        heff_drop(v_field_247);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_x21_2468 = heff_field(v_x2_241, 0);
    V v_x22_2469 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_2468)) {
    case TAG_ArrayLength: {
      switch (heff_tag_of(v_x22_2469)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_a_2470 = heff_field(v_x22_2469, 0);
        V v_x222_2471 = heff_field(v_x22_2469, 1);
        switch (heff_tag_of(v_x222_2471)) {
        case TAG_Nil: {
          V t_0 = v_again_240;
          V t_1 = v_a_2470;
          v_again_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x222_2471);
        }
      }
      default: return heff_nomatch(v_x22_2469);
      }
    }
    case TAG_StrLength: {
      switch (heff_tag_of(v_x22_2469)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_a_2474 = heff_field(v_x22_2469, 0);
        V v_x222_2475 = heff_field(v_x22_2469, 1);
        switch (heff_tag_of(v_x222_2475)) {
        case TAG_Nil: {
          V t_0 = v_again_240;
          V t_1 = v_a_2474;
          v_again_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x222_2475);
        }
      }
      default: return heff_nomatch(v_x22_2469);
      }
    }
    case TAG_BytesLength: {
      switch (heff_tag_of(v_x22_2469)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_a_2478 = heff_field(v_x22_2469, 0);
        V v_x222_2479 = heff_field(v_x22_2469, 1);
        switch (heff_tag_of(v_x222_2479)) {
        case TAG_Nil: {
          V t_0 = v_again_240;
          V t_1 = v_a_2478;
          v_again_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x222_2479);
        }
      }
      default: return heff_nomatch(v_x22_2469);
      }
    }
    default: {
      return NTAG(TAG_False);
    }
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuel_2einvariant_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuel_2einvariant(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2efuel_2estepOf_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      V v_x211_2424 = heff_field(v_x21_242, 0);
      V v_x212_2425 = heff_field(v_x21_242, 1);
      switch (heff_tag_of(v_x211_2424)) {
      case TAG_IntAdd: {
        switch (heff_tag_of(v_x212_2425)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x2121_2426 = heff_field(v_x212_2425, 0);
          V v_x2122_2427 = heff_field(v_x212_2425, 1);
          switch (heff_tag_of(v_x2121_2426)) {
          case TAG_EVar: {
            V v_y_2428 = heff_field(v_x2121_2426, 0);
            switch (heff_tag_of(v_x2122_2427)) {
            case TAG_Nil: {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Cons: {
              V v_x21221_2429 = heff_field(v_x2122_2427, 0);
              V v_x21222_2430 = heff_field(v_x2122_2427, 1);
              switch (heff_tag_of(v_x21221_2429)) {
              case TAG_EVar: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EGlobal: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ELam: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EApp: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ELet: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ERecord: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EProj: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ETag: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EMatch: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EPrim: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EPrimCall: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ECall: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EInt: {
                V v_d_2456 = heff_field(v_x21221_2429, 0);
                switch (heff_tag_of(v_x21222_2430)) {
                case TAG_Nil: {
                  if (heff_strEq_c_lent(v_x_240, v_y_2428, 0)) {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_d_2456)}});
                  } else {
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
                case TAG_Cons: {
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x21222_2430)}});
                }
              }
              case TAG_EFloat: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EStr: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EBytes: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFixed: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFloat32: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EAbandon: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EBool: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ESet: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EValues: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFix: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x21221_2429)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x2122_2427)}});
            }
          }
          case TAG_EGlobal: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ELam: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EApp: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ELet: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ERecord: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EProj: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ETag: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EMatch: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EPrim: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EPrimCall: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ECall: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EInt: {
            V v_d_2496 = heff_field(v_x2121_2426, 0);
            switch (heff_tag_of(v_x2122_2427)) {
            case TAG_Nil: {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Cons: {
              V v_x21221_2497 = heff_field(v_x2122_2427, 0);
              V v_x21222_2498 = heff_field(v_x2122_2427, 1);
              switch (heff_tag_of(v_x21221_2497)) {
              case TAG_EVar: {
                V v_y_2499 = heff_field(v_x21221_2497, 0);
                switch (heff_tag_of(v_x21222_2498)) {
                case TAG_Nil: {
                  if (heff_strEq_c_lent(v_x_240, v_y_2499, 0)) {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_d_2496)}});
                  } else {
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
                case TAG_Cons: {
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x21222_2498)}});
                }
              }
              case TAG_EGlobal: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ELam: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EApp: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ELet: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ERecord: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EProj: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ETag: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EMatch: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EPrim: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EPrimCall: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ECall: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EInt: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFloat: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EStr: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EBytes: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFixed: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFloat32: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EAbandon: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EBool: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ESet: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EValues: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFix: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x21221_2497)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x2122_2427)}});
            }
          }
          case TAG_EFloat: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EStr: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EBytes: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EFixed: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EFloat32: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EAbandon: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EBool: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ESet: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EValues: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EFix: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x2121_2426)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x212_2425)}});
        }
      }
      case TAG_IntSub: {
        switch (heff_tag_of(v_x212_2425)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x2121_24153 = heff_field(v_x212_2425, 0);
          V v_x2122_24154 = heff_field(v_x212_2425, 1);
          switch (heff_tag_of(v_x2121_24153)) {
          case TAG_EVar: {
            V v_y_24155 = heff_field(v_x2121_24153, 0);
            switch (heff_tag_of(v_x2122_24154)) {
            case TAG_Nil: {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Cons: {
              V v_x21221_24156 = heff_field(v_x2122_24154, 0);
              V v_x21222_24157 = heff_field(v_x2122_24154, 1);
              switch (heff_tag_of(v_x21221_24156)) {
              case TAG_EVar: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EGlobal: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ELam: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EApp: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ELet: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ERecord: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EProj: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ETag: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EMatch: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EPrim: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EPrimCall: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ECall: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EInt: {
                V v_d_24183 = heff_field(v_x21221_24156, 0);
                switch (heff_tag_of(v_x21222_24157)) {
                case TAG_Nil: {
                  if (heff_strEq_c_lent(v_x_240, v_y_24155, 0)) {
                    V v_f_24184 = heff_intSub_lent(MK_INT(0LL), v_d_24183, 1);
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24184}});
                  } else {
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
                case TAG_Cons: {
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x21222_24157)}});
                }
              }
              case TAG_EFloat: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EStr: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EBytes: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFixed: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFloat32: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EAbandon: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EBool: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_ESet: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EValues: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_EFix: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x21221_24156)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x2122_24154)}});
            }
          }
          case TAG_EGlobal: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ELam: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EApp: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ELet: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ERecord: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EProj: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ETag: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EMatch: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EPrim: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EPrimCall: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ECall: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EInt: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EFloat: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EStr: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EBytes: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EFixed: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EFloat32: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EAbandon: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EBool: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_ESet: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EValues: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_EFix: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x2121_24153)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x212_2425)}});
        }
      }
      default: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      }
    }
    case TAG_ECall: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT3 g_heff_2ecompile_2efuel_2eindexOf2_24cpr(V v_xs_240, V v_again_241, V v_x3_242, V v_other_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_t_245 = (g_list_2eany_24s1006624359x760861690(v_x_244, v_xs_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ecompile_2efuel_2einvariant(v_again_241, v_other_243));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_again_241, v_x_244));
        HeffT2 v_t_248 = ({ V a_0 = v_x_244; V a_1 = v_t_247; HeffT2 r_ = (g_heff_2ecompile_2efuel_2estepOf_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x_2411 = v_field_2410;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_244), v_x_2411}});
          } else {
            heff_drop(v_field_2410);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_t_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_t_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
  case TAG_EGlobal: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2efuel_2earrayBelow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2earrayBelow_entry, 6, 0};

V g_heff_2ecompile_2efuel_2earrayBelow(V v_x1_240, V v_x2_241, V v_x3_242, V v_x4_243, V v_x5_244, V v_x6_245) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_IntLt: {
      switch (heff_tag_of(v_x5_244)) {
      case TAG_EVar: {
        V v_j_246 = heff_field(v_x5_244, 0);
        V v_ru_24x5_244_24EVar = heff_take_reuse_n(v_x5_244, 1ULL, 1);
        switch (heff_tag_of(v_x6_245)) {
        case TAG_EVar: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EGlobal: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_ELam: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EApp: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_ELet: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_ERecord: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EProj: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_ETag: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EMatch: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EPrim: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EPrimCall: {
          V v_x61_2428 = heff_field(v_x6_245, 0);
          V v_x62_2429 = heff_field(v_x6_245, 1);
          switch (heff_tag_of(v_x61_2428)) {
          case TAG_ArrayLength: {
            switch (heff_tag_of(v_x62_2429)) {
            case TAG_Nil: {
              heff_drop(v_x4_243);
              heff_drop(v_j_246);
              heff_drop_cell(v_ru_24x5_244_24EVar, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_x621_2430 = heff_field(v_x62_2429, 0);
              V v_x622_2431 = heff_field(v_x62_2429, 1);
              switch (heff_tag_of(v_x621_2430)) {
              case TAG_EVar: {
                V v_a_2432 = heff_field(v_x621_2430, 0);
                switch (heff_tag_of(v_x622_2431)) {
                case TAG_Nil: {
                  if ((heff_strEq_c_lent(v_x3_242, v_j_246, 0) && heff_intLt_c_lent(MK_INT(0LL), v_x4_243, 1))) {
                    heff_drop(v_x4_243);
                    heff_drop(v_j_246);
                    return heff_tag_at_n(v_ru_24x5_244_24EVar, TAG_Just, 1, (V[]){heff_dup(v_a_2432)});
                  } else {
                    heff_drop(v_x4_243);
                    heff_drop(v_j_246);
                    heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                    return NTAG(TAG_Nothing);
                  }
                }
                case TAG_Cons: {
                  heff_drop(v_x4_243);
                  heff_drop(v_j_246);
                  heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_x622_2431);
                }
              }
              case TAG_EGlobal: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_ELam: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EApp: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_ELet: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_ERecord: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EProj: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_ETag: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EMatch: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EPrim: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EPrimCall: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_ECall: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EInt: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EFloat: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EStr: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EBytes: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EFixed: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EFloat32: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EAbandon: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EBool: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_ESet: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EValues: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_EFix: {
                heff_drop(v_x4_243);
                heff_drop(v_j_246);
                heff_drop_cell(v_ru_24x5_244_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              default: return heff_nomatch(v_x621_2430);
              }
            }
            default: return heff_nomatch(v_x62_2429);
            }
          }
          default: {
            heff_drop(v_x4_243);
            heff_drop(v_j_246);
            heff_drop_cell(v_ru_24x5_244_24EVar, 1);
            return NTAG(TAG_Nothing);
          }
          }
        }
        case TAG_ECall: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EInt: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EFloat: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EStr: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EBytes: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EFixed: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EFloat32: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EAbandon: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EBool: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_ESet: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EValues: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_EFix: {
          heff_drop(v_x4_243);
          heff_drop(v_j_246);
          heff_drop_cell(v_ru_24x5_244_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x6_245);
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        heff_take_n(v_x5_244, 0ULL, 2);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        heff_take_n(v_x5_244, 0ULL, 2);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        heff_take_n(v_x5_244, 0ULL, 3);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        heff_take_n(v_x5_244, 0ULL, 2);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EProj: {
        heff_take_n(v_x5_244, 0ULL, 4);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        heff_take_n(v_x5_244, 0ULL, 3);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EMatch: {
        heff_take_n(v_x5_244, 0ULL, 2);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        heff_take_n(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x5_244, 0ULL, 2);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        heff_take_n(v_x5_244, 0ULL, 2);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        heff_take_n(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        heff_take_nf(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        heff_take_n(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBytes: {
        heff_take_n(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFixed: {
        heff_take_n(v_x5_244, 0ULL, 2);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat32: {
        heff_take_na(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBool: {
        heff_take_n(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_ESet: {
        heff_take_n(v_x5_244, 0ULL, 3);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EValues: {
        heff_take_n(v_x5_244, 0ULL, 1);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        heff_take_n(v_x5_244, 0ULL, 2);
        heff_drop(v_x4_243);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x5_244);
      }
    }
    default: {
      heff_drop(v_x4_243);
      heff_drop(v_x5_244);
      return NTAG(TAG_Nothing);
    }
    }
  } else {
    heff_drop(v_x4_243);
    heff_drop(v_x5_244);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2efuel_2earrayBelow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a5 = a[5]; V r = g_heff_2ecompile_2efuel_2earrayBelow(a0, a1, a2, a[3], a[4], a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a5); return r;
}
Clo g_heff_2ecompile_2efuel_2eonlyRoundW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2eonlyRoundW_entry, 2, 0};

V g_heff_2ecompile_2efuel_2eonlyRoundW(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      V v_g_2427 = heff_field(v_x21_242, 0);
      switch (heff_tag_of(v_x22_243)) {
      case TAG_Nil: {
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_g_2427, v_k_240, 0));
        return v_ret_24bool;
      }
      case TAG_Cons: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x22_243);
      }
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuel_2eonlyRoundW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuel_2eonlyRoundW(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuel_2ecountedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2ecountedAt_entry, 7, 0};

V g_heff_2ecompile_2efuel_2ecountedAt(V v_xs_240, V v_p_241, V v_l_242, V v_r_243, V v_holds_244, V v_arm_245, V v_again_246) {
top: ;
  HeffT3 v_t_247 = (g_heff_2ecompile_2efuel_2eindexOf2_24cpr(v_xs_240, v_again_246, v_l_242, v_r_243));
  {
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_i_2411 = v_field_249;
      V v_d_2412 = v_field_2410;
      V v_t_2413;
      if ((heff_dup(v_holds_244) == NTAG(TAG_True))) {
        v_t_2413 = heff_tag_n(TAG_CRel, 3, (V[]){heff_dup(v_p_241), heff_dup(v_l_242), heff_dup(v_r_243)});
      } else {
        v_t_2413 = heff_tag_n(TAG_CNot, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){heff_dup(v_p_241), heff_dup(v_l_242), heff_dup(v_r_243)})});
      }
      V v_t_2414 = ({ V a_0 = v_holds_244; V a_1 = v_p_241; V a_2 = v_i_2411; V a_3 = heff_dup(v_d_2412); V a_4 = v_l_242; V a_5 = v_r_243; V r_ = (g_heff_2ecompile_2efuel_2earrayBelow(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_241); heff_drop(v_r_243); r_; });
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(5, shape_index__step__goes__round__array, (V[]){v_i_2411, v_d_2412, v_t_2413, v_arm_245, v_t_2414})});
    } else {
      heff_drop(v_field_249);
      heff_drop(v_field_2410);
      HeffT3 v_t_2415 = (g_heff_2ecompile_2efuel_2eindexOf2_24cpr(v_xs_240, v_again_246, v_r_243, v_l_242));
      {
        V v_field_2417 = v_t_2415.f[1];
        V v_field_2418 = v_t_2415.f[2];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_i_2419 = v_field_2417;
          V v_d_2420 = v_field_2418;
          V v_t_2421;
          if ((heff_dup(v_holds_244) == NTAG(TAG_True))) {
            v_t_2421 = heff_tag_n(TAG_CRel, 3, (V[]){v_p_241, v_l_242, v_r_243});
          } else {
            v_t_2421 = heff_tag_n(TAG_CNot, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_241, v_l_242, v_r_243})});
          }
          V v_t_2422 = heff_rec_n(5, shape_index__step__goes__round__array, (V[]){v_i_2419, v_d_2420, v_t_2421, v_arm_245, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
        } else {
          heff_drop(v_p_241);
          heff_drop(v_l_242);
          heff_drop(v_r_243);
          heff_drop(v_arm_245);
          heff_drop(v_field_2417);
          heff_drop(v_field_2418);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
}
V g_heff_2ecompile_2efuel_2ecountedAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a4 = a[4]; V a6 = a[6]; V r = g_heff_2ecompile_2efuel_2ecountedAt(a0, a[1], a[2], a[3], a4, a[5], a6); heff_drop(a0); heff_drop(a4); heff_drop(a6); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuel_2eroundArm_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2efuel_2eroundArm_24cpr_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2efuel_2eroundArm_24cpr_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2efuel_2eroundArm_24cpr_str3, 5, "False");
HEFF_LIT(g_heff_2ecompile_2efuel_2eroundArm_24cpr_str4, 5, "False");

HeffT3 g_heff_2ecompile_2efuel_2eroundArm_24cpr(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t1_244 = heff_field(v_x21_242, 0);
      V v_b1_246 = heff_field(v_x21_242, 2);
      switch (heff_tag_of(v_x22_243)) {
      case TAG_Nil: {
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x221_247 = heff_field(v_x22_243, 0);
        V v_x222_248 = heff_field(v_x22_243, 1);
        switch (heff_tag_of(v_x221_247)) {
        case TAG_MkArm: {
          V v_t2_249 = heff_field(v_x221_247, 0);
          V v_b2_2411 = heff_field(v_x221_247, 2);
          switch (heff_tag_of(v_x222_248)) {
          case TAG_Nil: {
            V v_t_2413;
            if (heff_strEq_c_lent(v_t1_244, ((V)&g_heff_2ecompile_2efuel_2eroundArm_24cpr_str0), 2)) {
              V v_t_2412 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b1_246, NTAG(TAG_Nil)));
              v_t_2413 = ({ V a_0 = v_k_240; V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2efuel_2eonlyRoundW(a_0, a_1)); heff_drop(v_t_2412); r_; });
            } else {
              v_t_2413 = NTAG(TAG_False);
            }
            if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
              heff_drop(v_t_2413);
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_True), heff_dup(v_b1_246)}});
            } else {
              heff_drop(v_t_2413);
              V v_t_2415;
              if (heff_strEq_c_lent(v_t1_244, ((V)&g_heff_2ecompile_2efuel_2eroundArm_24cpr_str1), 2)) {
                V v_t_2414 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b1_246, NTAG(TAG_Nil)));
                v_t_2415 = ({ V a_0 = v_k_240; V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2efuel_2eonlyRoundW(a_0, a_1)); heff_drop(v_t_2414); r_; });
              } else {
                v_t_2415 = NTAG(TAG_False);
              }
              if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                heff_drop(v_t_2415);
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_False), heff_dup(v_b1_246)}});
              } else {
                heff_drop(v_t_2415);
                if (heff_strEq_c_lent(v_t2_249, ((V)&g_heff_2ecompile_2efuel_2eroundArm_24cpr_str2), 2)) {
                  V v_t_2416 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b2_2411, NTAG(TAG_Nil)));
                  V v_t_2417 = ({ V a_0 = v_k_240; V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2efuel_2eonlyRoundW(a_0, a_1)); heff_drop(v_t_2416); r_; });
                  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
                    heff_drop(v_t_2417);
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_True), heff_dup(v_b2_2411)}});
                  } else {
                    heff_drop(v_t_2417);
                    if (heff_strEq_c_lent(v_t2_249, ((V)&g_heff_2ecompile_2efuel_2eroundArm_24cpr_str3), 2)) {
                      V v_t_2418 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b2_2411, NTAG(TAG_Nil)));
                      V v_t_2419 = ({ V a_0 = v_k_240; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2efuel_2eonlyRoundW(a_0, a_1)); heff_drop(v_t_2418); r_; });
                      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
                        heff_drop(v_t_2419);
                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_False), heff_dup(v_b2_2411)}});
                      } else {
                        heff_drop(v_t_2419);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    } else {
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_t2_249, ((V)&g_heff_2ecompile_2efuel_2eroundArm_24cpr_str4), 2)) {
                    V v_t_2420 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b2_2411, NTAG(TAG_Nil)));
                    V v_t_2421 = ({ V a_0 = v_k_240; V a_1 = v_t_2420; V r_ = (g_heff_2ecompile_2efuel_2eonlyRoundW(a_0, a_1)); heff_drop(v_t_2420); r_; });
                    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
                      heff_drop(v_t_2421);
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_False), heff_dup(v_b2_2411)}});
                    } else {
                      heff_drop(v_t_2421);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  } else {
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              }
            }
          }
          case TAG_Cons: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          default: return ((HeffT3){{heff_nomatch(v_x222_248)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x221_247)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x22_243)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2efuel_2ecounted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2ecounted_entry, 3, 0};

V g_heff_2ecompile_2efuel_2ecounted(V v_k_240, V v_xs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    V v_x31_2421 = heff_field(v_x3_242, 0);
    V v_arms_2422 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_2421)) {
    case TAG_EVar: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBool: {
      V v_x311_2455 = heff_field(v_x31_2421, 0);
      switch (heff_tag_of(v_x311_2455)) {
      case TAG_CTrue: {
        heff_drop(v_xs_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_CFalse: {
        heff_drop(v_xs_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_CRel: {
        V v_p_2456 = heff_field(v_x311_2455, 0);
        V v_l_2457 = heff_field(v_x311_2455, 1);
        V v_r_2458 = heff_field(v_x311_2455, 2);
        switch (heff_tag_of(v_p_2456)) {
        case TAG_IntLt: {
          HeffT3 v_t_2459 = (g_heff_2ecompile_2efuel_2eroundArm_24cpr(v_k_240, v_arms_2422));
          {
            V v_field_2461 = v_t_2459.f[1];
            V v_field_2462 = v_t_2459.f[2];
            int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
            if ((v_tag_2460 == ((int64_t)0ULL))) {
              V v_holds_2463 = v_field_2461;
              V v_arm_2464 = v_field_2462;
              V v_x1_2465 = (g_heff_2ecompile_2eir_2ewaysOnto(v_arm_2464, NTAG(TAG_Nil)));
              V v_t_2468;
              switch (heff_tag_of(v_x1_2465)) {
              case TAG_Nil: {
                v_t_2468 = heff_dup(v_arm_2464);
                break;
              }
              case TAG_Cons: {
                V v_x_2466 = heff_field(v_x1_2465, 0);
                heff_take_n(v_x1_2465, 1ULL, 2);
                v_t_2468 = v_x_2466;
                break;
              }
              default: heff_nomatch(v_x1_2465);
              }
              V v_t_2469 = ({ V a_0 = heff_dup(v_xs_241); V a_1 = v_t_2468; V r_ = (g_heff_2ecompile_2efuel_2egivenTo(a_0, a_1)); heff_drop(v_t_2468); r_; });
              return ({ V a_0 = v_xs_241; V a_1 = heff_dup(v_p_2456); V a_2 = heff_dup(v_l_2457); V a_3 = heff_dup(v_r_2458); V a_4 = v_holds_2463; V a_5 = v_arm_2464; V a_6 = v_t_2469; V r_ = (g_heff_2ecompile_2efuel_2ecountedAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_xs_241); heff_drop(v_holds_2463); heff_drop(v_t_2469); r_; });
            } else {
              heff_drop(v_xs_241);
              heff_drop(v_field_2461);
              heff_drop(v_field_2462);
              return NTAG(TAG_Nothing);
            }
          }
        }
        case TAG_IntLe: {
          HeffT3 v_t_2470 = (g_heff_2ecompile_2efuel_2eroundArm_24cpr(v_k_240, v_arms_2422));
          {
            V v_field_2472 = v_t_2470.f[1];
            V v_field_2473 = v_t_2470.f[2];
            int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
            if ((v_tag_2471 == ((int64_t)0ULL))) {
              V v_holds_2474 = v_field_2472;
              V v_arm_2475 = v_field_2473;
              V v_x1_2476 = (g_heff_2ecompile_2eir_2ewaysOnto(v_arm_2475, NTAG(TAG_Nil)));
              V v_t_2479;
              switch (heff_tag_of(v_x1_2476)) {
              case TAG_Nil: {
                v_t_2479 = heff_dup(v_arm_2475);
                break;
              }
              case TAG_Cons: {
                V v_x_2477 = heff_field(v_x1_2476, 0);
                heff_take_n(v_x1_2476, 1ULL, 2);
                v_t_2479 = v_x_2477;
                break;
              }
              default: heff_nomatch(v_x1_2476);
              }
              V v_t_2480 = ({ V a_0 = heff_dup(v_xs_241); V a_1 = v_t_2479; V r_ = (g_heff_2ecompile_2efuel_2egivenTo(a_0, a_1)); heff_drop(v_t_2479); r_; });
              return ({ V a_0 = v_xs_241; V a_1 = heff_dup(v_p_2456); V a_2 = heff_dup(v_l_2457); V a_3 = heff_dup(v_r_2458); V a_4 = v_holds_2474; V a_5 = v_arm_2475; V a_6 = v_t_2480; V r_ = (g_heff_2ecompile_2efuel_2ecountedAt(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_xs_241); heff_drop(v_holds_2474); heff_drop(v_t_2480); r_; });
            } else {
              heff_drop(v_xs_241);
              heff_drop(v_field_2472);
              heff_drop(v_field_2473);
              return NTAG(TAG_Nothing);
            }
          }
        }
        default: {
          heff_drop(v_xs_241);
          return NTAG(TAG_Nothing);
        }
        }
      }
      case TAG_CTest: {
        heff_drop(v_xs_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_CNot: {
        heff_drop(v_xs_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_CIf: {
        heff_drop(v_xs_241);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x311_2455);
      }
    }
    case TAG_ESet: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EValues: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_drop(v_xs_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_2421);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBool: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ESet: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EValues: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuel_2ecounted_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2efuel_2ecounted(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2efuel_2einRange_lam0(V self, V *args);
V g_heff_2ecompile_2efuel_2einRange_lam1(V self, V *args);
V g_heff_2ecompile_2efuel_2einRange_lam2(V self, V *args);
V g_heff_2ecompile_2efuel_2einRange_lam3(V self, V *args);
V g_heff_2ecompile_2efuel_2einRange_lam4(V self, V *args);
V g_heff_2ecompile_2efuel_2einRange_lam5(V self, V *args);
V g_heff_2ecompile_2efuel_2einRange_lam6(V self, V *args);
Clo g_heff_2ecompile_2efuel_2einRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2einRange_entry, 3, 0};

V g_heff_2ecompile_2efuel_2einRange(V v_a_240, V v_i_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EPrimCall: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    V v_e2_244 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_ArrayIndex: {
      switch (heff_tag_of(v_e2_244)) {
      case TAG_Nil: {
        return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuel_2einRange_lam0, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_i_241)}), v_e_242));
      }
      case TAG_Cons: {
        V v_e21_247 = heff_field(v_e2_244, 0);
        V v_e22_248 = heff_field(v_e2_244, 1);
        V v_ru_24e2_244_24Cons = heff_take_reuse_n(v_e2_244, 3ULL, 2);
        switch (heff_tag_of(v_e21_247)) {
        case TAG_EVar: {
          V v_b_249 = heff_field(v_e21_247, 0);
          V v_ru_24e21_247_24EVar = heff_take_reuse_n(v_e21_247, 1ULL, 1);
          switch (heff_tag_of(v_e22_248)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24e2_244_24Cons, 2);
            heff_drop(v_b_249);
            heff_drop_cell(v_ru_24e21_247_24EVar, 1);
            return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuel_2einRange_lam1, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_i_241)}), v_e_242));
          }
          case TAG_Cons: {
            V v_e221_2412 = heff_field(v_e22_248, 0);
            V v_e222_2413 = heff_field(v_e22_248, 1);
            V v_ru_24e22_248_24Cons = heff_take_reuse_n(v_e22_248, 3ULL, 2);
            switch (heff_tag_of(v_e221_2412)) {
            case TAG_EVar: {
              V v_j_2414 = heff_field(v_e221_2412, 0);
              V v_ru_24e221_2412_24EVar = heff_take_reuse_n(v_e221_2412, 1ULL, 1);
              switch (heff_tag_of(v_e222_2413)) {
              case TAG_Nil: {
                heff_drop_tag(v_e_242, 2);
                if ((heff_strEq_c_lent(v_a_240, v_b_249, 0) && heff_strEq_c_lent(v_i_241, v_j_2414, 0))) {
                  V v_t_2415 = heff_tag_at_n(v_ru_24e2_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e21_247_24EVar, TAG_EVar, 1, (V[]){v_j_2414}), NTAG(TAG_Nil)});
                  V v_t_2416 = heff_tag_at_n(v_ru_24e22_248_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e221_2412_24EVar, TAG_EVar, 1, (V[]){v_b_249}), v_t_2415});
                  return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayIndexIn), v_t_2416});
                } else {
                  V v_t_2417 = heff_tag_at_n(v_ru_24e2_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e21_247_24EVar, TAG_EVar, 1, (V[]){v_j_2414}), NTAG(TAG_Nil)});
                  V v_t_2418 = heff_tag_at_n(v_ru_24e22_248_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e221_2412_24EVar, TAG_EVar, 1, (V[]){v_b_249}), v_t_2417});
                  return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_ArrayIndex), v_t_2418});
                }
              }
              case TAG_Cons: {
                heff_take_n(v_e222_2413, 0ULL, 2);
                heff_drop_cell(v_ru_24e2_244_24Cons, 2);
                heff_drop(v_b_249);
                heff_drop_cell(v_ru_24e21_247_24EVar, 1);
                heff_drop_cell(v_ru_24e22_248_24Cons, 2);
                heff_drop(v_j_2414);
                heff_drop_cell(v_ru_24e221_2412_24EVar, 1);
                return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuel_2einRange_lam2, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_i_241)}), v_e_242));
              }
              default: return heff_nomatch(v_e222_2413);
              }
            }
            default: {
              heff_drop_cell(v_ru_24e2_244_24Cons, 2);
              heff_drop(v_b_249);
              heff_drop_cell(v_ru_24e21_247_24EVar, 1);
              heff_drop(v_e221_2412);
              heff_drop(v_e222_2413);
              heff_drop_cell(v_ru_24e22_248_24Cons, 2);
              return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuel_2einRange_lam3, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_i_241)}), v_e_242));
            }
            }
          }
          default: return heff_nomatch(v_e22_248);
          }
        }
        default: {
          heff_drop(v_e21_247);
          heff_drop(v_e22_248);
          heff_drop_cell(v_ru_24e2_244_24Cons, 2);
          return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuel_2einRange_lam4, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_i_241)}), v_e_242));
        }
        }
      }
      default: return heff_nomatch(v_e2_244);
      }
    }
    default: {
      heff_drop(v_e1_243);
      heff_drop(v_e2_244);
      return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuel_2einRange_lam5, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_i_241)}), v_e_242));
    }
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuel_2einRange_lam6, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_i_241)}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2efuel_2einRange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuel_2einRange(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efuel_2einRange_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_p_246 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_drop(v_x_245);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_a_240; V a_1 = v_i_241; V a_2 = v_p_246; V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_a_240); heff_drop(v_i_241); r_; });
}
V g_heff_2ecompile_2efuel_2einRange_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_2411 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_drop(v_x_2410);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_a_240; V a_1 = v_i_241; V a_2 = v_p_2411; V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_a_240); heff_drop(v_i_241); r_; });
}
V g_heff_2ecompile_2efuel_2einRange_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_p_2422 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_drop(v_x_2421);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_a_240; V a_1 = v_i_241; V a_2 = v_p_2422; V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_a_240); heff_drop(v_i_241); r_; });
}
V g_heff_2ecompile_2efuel_2einRange_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_p_2424 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_drop(v_x_2423);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_a_240; V a_1 = v_i_241; V a_2 = v_p_2424; V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_a_240); heff_drop(v_i_241); r_; });
}
V g_heff_2ecompile_2efuel_2einRange_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_p_2426 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_drop(v_x_2425);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_a_240; V a_1 = v_i_241; V a_2 = v_p_2426; V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_a_240); heff_drop(v_i_241); r_; });
}
V g_heff_2ecompile_2efuel_2einRange_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_p_2428 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_drop(v_x_2427);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_a_240; V a_1 = v_i_241; V a_2 = v_p_2428; V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_a_240); heff_drop(v_i_241); r_; });
}
V g_heff_2ecompile_2efuel_2einRange_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_p_2430 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_drop(v_x_2429);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_a_240; V a_1 = v_i_241; V a_2 = v_p_2430; V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_a_240); heff_drop(v_i_241); r_; });
}
HEFF_LIT(g_heff_2ecompile_2efuel_2ecountedBatched_str0, 5, "fuel$");
HEFF_LIT(g_heff_2ecompile_2efuel_2ecountedBatched_str1, 5, "fuel$");
HEFF_LIT(g_heff_2ecompile_2efuel_2ecountedBatched_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2efuel_2ecountedBatched_str3, 5, "False");
V g_heff_2ecompile_2efuel_2ecountedBatched_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuel_2ecountedBatched_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2ecountedBatched_entry, 6, 0};

V g_heff_2ecompile_2efuel_2ecountedBatched(V v_k_240, V v_xs_241, V v_n_242, V v_c_243, V v_b_244, V v_z_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_c_243, 4));
  V v_b_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_b_248 = heff_dup(heff_rfield(v_c_243, 3));
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_b_248 = ({ V a_0 = v_x_247; V a_1 = heff_rfield(v_c_243, 0); V a_2 = heff_dup(heff_rfield(v_c_243, 3)); V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_x_247); r_; });
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  HeffT2 v_t_249 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), v_z_245, v_b_248));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_x_2412 = v_field_2410;
    V v_n_2413 = v_field_2411;
    V v_d_2414 = heff_dup(heff_rfield(v_c_243, 3));
    V v_t_2415 = heff_dup(heff_rfield(v_c_243, 4));
    V v_t_2417;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      v_t_2417 = v_d_2414;
      break;
    }
    case TAG_Just: {
      V v_x_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      heff_drop(v_d_2414);
      v_t_2417 = ({ V a_0 = v_x_2416; V a_1 = heff_rfield(v_c_243, 0); V a_2 = heff_dup(heff_rfield(v_c_243, 3)); V r_ = (g_heff_2ecompile_2efuel_2einRange(a_0, a_1, a_2)); heff_drop(v_x_2416); r_; });
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2418 = ({ V a_0 = v_k_240; V a_1 = v_xs_241; V a_2 = v_t_2417; V a_3 = heff_box_word((heff_peek_word(v_n_242) - ((int64_t)1ULL))); V a_4 = v_x_2412; V r_ = (g_heff_2ecompile_2efuel_2eunrolled(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2417); r_; });
    V v_x2_2419 = heff_tr(heff_call(v_t_2418, 1, (V[]){v_n_2413}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_x_2422 = heff_strAppend(((V)&g_heff_2ecompile_2efuel_2ecountedBatched_str0), heff_intShow(heff_dup(v_n_2421)));
      V v_n_2423 = heff_intAdd(v_n_2421, MK_INT(1LL));
      int64_t v_t_2424 = (((int64_t)1ULL) - heff_peek_word(v_n_242));
      V v_n_2425 = heff_dup(v_n_242);
      V v_c_2426 = v_c_243;
      V v_index_2427 = heff_take_field(v_c_2426, 0);
      V v_step_2428 = heff_take_field(v_c_2426, 1);
      V v_goes_2429 = heff_take_field(v_c_2426, 2);
      V v_array_2430 = heff_get_n(v_c_2426, 4, 5);
      V v_t_2438 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2efuel_2ecountedBatched_lam0, 1, 3, (V[]){v_n_2425, v_step_2428, heff_dup(v_index_2427)}); V a_1 = heff_dup(v_goes_2429); V r_ = (g_heff_2ecompile_2eir_2econdMap(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2439 = v_array_2430;
      V v_t_2441;
      switch (heff_tag_of(v_t_2439)) {
      case TAG_Nothing: {
        heff_drop(v_index_2427);
        v_t_2441 = NTAG(TAG_CTrue);
        break;
      }
      case TAG_Just: {
        V v_ru_24t_2439_24Just = heff_take_reuse_n(v_t_2439, 0ULL, 1);
        v_t_2441 = heff_tag_n(TAG_CRel, 3, (V[]){NTAG(TAG_IntLe), heff_tag_at_n(v_ru_24t_2439_24Just, TAG_EInt, 1, (V[]){MK_INT(0LL)}), heff_tag_n(TAG_EVar, 1, (V[]){v_index_2427})});
        break;
      }
      default: heff_nomatch(v_t_2439);
      }
      V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2efuel_2ecountedBatched_str1), heff_intShow(heff_dup(v_n_2423)));
      V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_n_242}), NTAG(TAG_Nil)});
      V v_t_2444 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_FuelTicks), v_t_2443});
      V v_t_2445 = heff_tag_n(TAG_CIf, 3, (V[]){v_t_2438, v_t_2441, NTAG(TAG_CFalse)});
      V v_t_2446 = heff_tag_n(TAG_CIf, 3, (V[]){v_goes_2429, v_t_2445, NTAG(TAG_CFalse)});
      V v_t_2447 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2efuel_2ecountedBatched_str2), NTAG(TAG_Nil), v_x_2420});
      V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){heff_box_word(v_t_2424)}), NTAG(TAG_Nil)});
      V v_t_2449 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_FuelTicks), v_t_2448});
      V v_t_2450 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2efuel_2ecountedBatched_str3), NTAG(TAG_Nil), heff_tag_n(TAG_ELet, 3, (V[]){v_x_2422, v_t_2449, v_b_244})});
      V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
      V v_t_2452 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_t_2446}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2451})});
      V v_x_2453 = heff_tag_n(TAG_ELet, 3, (V[]){v_t_2442, v_t_2444, v_t_2452});
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2453, heff_intAdd(v_n_2423, MK_INT(1LL))});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
}
V g_heff_2ecompile_2efuel_2ecountedBatched_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuel_2ecountedBatched(a0, a1, a[2], a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efuel_2ecountedBatched_lam0(V self, V *args) {
  V v_e_2431 = args[0];
  V v_n_2425 = heff_env(self)[0];
  V v_step_2428 = heff_env(self)[1];
  V v_index_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432 = heff_intMul(heff_box_word((heff_unbox_word(v_n_2425) - ((int64_t)1ULL))), v_step_2428);
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_t_2432}), NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_index_2427)}), v_t_2433});
  V v_t_2435 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_IntAdd), v_t_2434});
  V v_m_2436 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), v_index_2427, v_t_2435, NTAG(TAG_Tip), NTAG(TAG_Tip)});
  V v_t_2437 = (g_std_2eordmap_2esize(v_m_2436));
  if (heff_intEq_c(v_t_2437, MK_INT(0LL))) {
    heff_drop_tag(v_m_2436, 5);
    return v_e_2431;
  } else {
    return ({ V a_0 = v_m_2436; V a_1 = v_e_2431; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop_tag(v_m_2436, 5); r_; });
  }
}
HEFF_LIT(g_heff_2ecompile_2efuel_2ebatchedBy_str0, 5, "fuel$");
Clo g_heff_2ecompile_2efuel_2ebatchedBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2ebatchedBy_entry, 6, 0};

V g_heff_2ecompile_2efuel_2ebatchedBy(V v_k_240, V v_xs_241, V v_n_242, V v_b_243, V v_x5_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_k_246 = v_k_240;
    V v_xs_247 = v_xs_241;
    V v_n_248 = v_n_242;
    V v_b_249 = v_b_243;
    V v_m_2410 = ({ V a_0 = v_k_246; V a_1 = v_xs_247; V a_2 = v_b_249; V a_3 = heff_intSub_lent(v_n_248, MK_INT(1LL), 2); V a_4 = heff_dup(v_b_249); V r_ = (g_heff_2ecompile_2efuel_2eunrolled(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_246); heff_drop(v_xs_247); heff_drop(v_b_249); r_; });
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_245}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2efuel_2ebatchedBy_str0), heff_intShow(heff_dup(v_n_2413)));
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_n_248}), NTAG(TAG_Nil)});
      V v_t_2416 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_FuelTicks), v_t_2415});
      return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2414, v_t_2416, v_x_2412}), heff_intAdd(v_n_2413, MK_INT(1LL))});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  case TAG_Just: {
    V v_c_2417 = heff_field(v_x5_244, 0);
    heff_drop(v_n_242);
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_2417, 3)), NTAG(TAG_Nil)});
    V v_t_2419 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2418));
    V v_n_2420 = heff_intDiv(MK_INT(256LL), v_t_2419);
    V v_t_2421;
    if (heff_intLt_c_lent(v_n_2420, MK_INT(1LL), 2)) {
      heff_drop(v_n_2420);
      v_t_2421 = MK_INT(1LL);
    } else {
      if (heff_intLt_c_lent(MK_INT(64LL), v_n_2420, 1)) {
        heff_drop(v_n_2420);
        v_t_2421 = MK_INT(64LL);
      } else {
        v_t_2421 = v_n_2420;
      }
    }
    return ({ V a_0 = v_k_240; V a_1 = v_xs_241; V a_2 = v_t_2421; V a_3 = heff_dup(v_c_2417); V a_4 = v_b_243; V a_5 = v_z_245; V r_ = (g_heff_2ecompile_2efuel_2ecountedBatched(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_k_240); heff_drop(v_xs_241); r_; });
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2efuel_2ebatchedBy_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2efuel_2ebatchedBy(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2efuel_2ecountedAt_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2ecountedAt_24tok1_entry, 8, 0};

V g_heff_2ecompile_2efuel_2ecountedAt_24tok1(V v_tok_240, V v_xs_241, V v_p_242, V v_l_243, V v_r_244, V v_holds_245, V v_arm_246, V v_again_247) {
top: ;
  HeffT3 v_t_248 = (g_heff_2ecompile_2efuel_2eindexOf2_24cpr(v_xs_241, v_again_247, v_l_243, v_r_244));
  {
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_i_2412 = v_field_2410;
      V v_d_2413 = v_field_2411;
      V v_t_2414;
      if ((heff_dup(v_holds_245) == NTAG(TAG_True))) {
        heff_drop_cell(v_tok_240, 1);
        v_t_2414 = heff_tag_n(TAG_CRel, 3, (V[]){heff_dup(v_p_242), heff_dup(v_l_243), heff_dup(v_r_244)});
      } else {
        v_t_2414 = heff_tag_at_n(v_tok_240, TAG_CNot, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){heff_dup(v_p_242), heff_dup(v_l_243), heff_dup(v_r_244)})});
      }
      V v_t_2415 = ({ V a_0 = v_holds_245; V a_1 = v_p_242; V a_2 = v_i_2412; V a_3 = heff_dup(v_d_2413); V a_4 = v_l_243; V a_5 = v_r_244; V r_ = (g_heff_2ecompile_2efuel_2earrayBelow(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_242); heff_drop(v_r_244); r_; });
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(5, shape_index__step__goes__round__array, (V[]){v_i_2412, v_d_2413, v_t_2414, v_arm_246, v_t_2415})});
    } else {
      heff_drop(v_field_2410);
      heff_drop(v_field_2411);
      HeffT3 v_t_2416 = (g_heff_2ecompile_2efuel_2eindexOf2_24cpr(v_xs_241, v_again_247, v_r_244, v_l_243));
      {
        V v_field_2418 = v_t_2416.f[1];
        V v_field_2419 = v_t_2416.f[2];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_i_2420 = v_field_2418;
          V v_d_2421 = v_field_2419;
          V v_t_2422;
          if ((heff_dup(v_holds_245) == NTAG(TAG_True))) {
            heff_drop_cell(v_tok_240, 1);
            v_t_2422 = heff_tag_n(TAG_CRel, 3, (V[]){v_p_242, v_l_243, v_r_244});
          } else {
            v_t_2422 = heff_tag_at_n(v_tok_240, TAG_CNot, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_242, v_l_243, v_r_244})});
          }
          V v_t_2423 = heff_rec_n(5, shape_index__step__goes__round__array, (V[]){v_i_2420, v_d_2421, v_t_2422, v_arm_246, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2423});
        } else {
          heff_drop_cell(v_tok_240, 1);
          heff_drop(v_p_242);
          heff_drop(v_l_243);
          heff_drop(v_r_244);
          heff_drop(v_arm_246);
          heff_drop(v_field_2418);
          heff_drop(v_field_2419);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
}
V g_heff_2ecompile_2efuel_2ecountedAt_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V a7 = a[7]; V r = g_heff_2ecompile_2efuel_2ecountedAt_24tok1(a[0], a1, a[2], a[3], a[4], a5, a[6], a7); heff_drop(a1); heff_drop(a5); heff_drop(a7); return r;
}
Clo g_heff_2ecompile_2efuel_2ecountedAt_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuel_2ecountedAt_24tok3_entry, 8, 0};

V g_heff_2ecompile_2efuel_2ecountedAt_24tok3(V v_tok_240, V v_xs_241, V v_p_242, V v_l_243, V v_r_244, V v_holds_245, V v_arm_246, V v_again_247) {
top: ;
  HeffT3 v_t_248 = (g_heff_2ecompile_2efuel_2eindexOf2_24cpr(v_xs_241, v_again_247, v_l_243, v_r_244));
  {
    V v_field_2410 = v_t_248.f[1];
    V v_field_2411 = v_t_248.f[2];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_i_2412 = v_field_2410;
      V v_d_2413 = v_field_2411;
      V v_t_2414;
      if ((heff_dup(v_holds_245) == NTAG(TAG_True))) {
        v_t_2414 = heff_tag_at_n(v_tok_240, TAG_CRel, 3, (V[]){heff_dup(v_p_242), heff_dup(v_l_243), heff_dup(v_r_244)});
      } else {
        v_t_2414 = heff_tag_n(TAG_CNot, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_CRel, 3, (V[]){heff_dup(v_p_242), heff_dup(v_l_243), heff_dup(v_r_244)})});
      }
      V v_t_2415 = ({ V a_0 = v_holds_245; V a_1 = v_p_242; V a_2 = v_i_2412; V a_3 = heff_dup(v_d_2413); V a_4 = v_l_243; V a_5 = v_r_244; V r_ = (g_heff_2ecompile_2efuel_2earrayBelow(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_242); heff_drop(v_r_244); r_; });
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(5, shape_index__step__goes__round__array, (V[]){v_i_2412, v_d_2413, v_t_2414, v_arm_246, v_t_2415})});
    } else {
      heff_drop(v_field_2410);
      heff_drop(v_field_2411);
      HeffT3 v_t_2416 = (g_heff_2ecompile_2efuel_2eindexOf2_24cpr(v_xs_241, v_again_247, v_r_244, v_l_243));
      {
        V v_field_2418 = v_t_2416.f[1];
        V v_field_2419 = v_t_2416.f[2];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_i_2420 = v_field_2418;
          V v_d_2421 = v_field_2419;
          V v_t_2422;
          if ((heff_dup(v_holds_245) == NTAG(TAG_True))) {
            v_t_2422 = heff_tag_at_n(v_tok_240, TAG_CRel, 3, (V[]){v_p_242, v_l_243, v_r_244});
          } else {
            v_t_2422 = heff_tag_n(TAG_CNot, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_CRel, 3, (V[]){v_p_242, v_l_243, v_r_244})});
          }
          V v_t_2423 = heff_rec_n(5, shape_index__step__goes__round__array, (V[]){v_i_2420, v_d_2421, v_t_2422, v_arm_246, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2423});
        } else {
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_p_242);
          heff_drop(v_l_243);
          heff_drop(v_r_244);
          heff_drop(v_arm_246);
          heff_drop(v_field_2418);
          heff_drop(v_field_2419);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
}
V g_heff_2ecompile_2efuel_2ecountedAt_24tok3_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V a7 = a[7]; V r = g_heff_2ecompile_2efuel_2ecountedAt_24tok3(a[0], a1, a[2], a[3], a[4], a5, a[6], a7); heff_drop(a1); heff_drop(a5); heff_drop(a7); return r;
}