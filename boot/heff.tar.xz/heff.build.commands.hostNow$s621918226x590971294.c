// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_cwd 308458
#define LBL_heff 9694020
#define LBL_lib 316671
#define LBL_mod 317820
#define LBL_style 311138763
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_str0, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0(V v_st_240, V v_x_241, V v_hd_242, V v_x_243, V v_x_244, V v_x_245, V v_x_246, V v_k_247, V v_x_248) {
top: ;
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_241));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_str0)));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  V v_s_2412 = ({ V a_0 = v_st_240; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
  V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2413; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2413); r_; });
  V v_a_2416 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_lam0_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2421, v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_lam1, 1, 7, (V[]){v_st_240, v_x_246, v_x_248, v_x_243, v_x_244, v_x_245, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_lam0(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 0ULL, 1);
    heff_clo_take(self, 7);
    V v_t_2424 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_240), v_x_246));
    V v_t_2427;
    switch (heff_tag_of(v_x_248)) {
    case TAG_Left: {
      heff_take_n(v_x_248, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2422_24Left, 1);
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_y_2426 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_Just, 1, (V[]){v_y_2426});
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2428 = ({ V a_0 = v_t_2427; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2427); r_; });
    V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2428, NTAG(TAG_Nil)));
    V v_x_2430 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_243, v_x_244, v_x_245, v_st_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2429})});
    V f_ = v_k_247;
    args[0] = v_x_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Right = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    switch (heff_tag_of(v_y_2431)) {
    case TAG_Left: {
      heff_take_n(v_y_2431, 0ULL, 1);
      heff_clo_take(self, 7);
      V v_t_2433 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_240), v_x_246));
      V v_t_2436;
      switch (heff_tag_of(v_x_248)) {
      case TAG_Left: {
        heff_take_n(v_x_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x_2422_24Right, 1);
        v_t_2436 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Right: {
        V v_y_2435 = heff_field(v_x_248, 0);
        heff_take_n(v_x_248, 1ULL, 1);
        v_t_2436 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_Just, 1, (V[]){v_y_2435});
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      V v_t_2437 = ({ V a_0 = v_t_2436; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2436); r_; });
      V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2437, NTAG(TAG_Nil)));
      V v_x_2439 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_243, v_x_244, v_x_245, v_st_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2438})});
      V f_ = v_k_247;
      args[0] = v_x_2439;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2440 = heff_field(v_y_2431, 0);
      V v_ru_24y_2431_24Right = heff_take_reuse_n(v_y_2431, 1ULL, 1);
      heff_clo_take(self, 7);
      V v_t_2441 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_240), v_x_246));
      V v_t_2444;
      switch (heff_tag_of(v_x_248)) {
      case TAG_Left: {
        heff_take_n(v_x_248, 0ULL, 1);
        heff_drop_cell(v_ru_24x_2422_24Right, 1);
        v_t_2444 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Right: {
        V v_y_2443 = heff_field(v_x_248, 0);
        heff_take_n(v_x_248, 1ULL, 1);
        v_t_2444 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_Just, 1, (V[]){v_y_2443});
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      V v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2444); r_; });
      V v_t_2446 = ({ V b_0 = heff_tag_at_n(v_ru_24y_2431_24Right, TAG_Just, 1, (V[]){v_x_2440}); V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(b_0)); heff_drop(b_0); r_; });
      V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2445, v_t_2446));
      V v_x_2448 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_243, v_x_244, v_x_245, v_st_240, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2447})});
      V f_ = v_k_247;
      args[0] = v_x_2448;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2431);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}