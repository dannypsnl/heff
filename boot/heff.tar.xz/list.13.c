// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_Binds 36386
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_HLocal 25864
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkSegment 38079
#define TAG_OSimple 59809
#define TAG_Pinned 8573
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_SSet 8516
#define TAG_SetPath 11095
#define TAG_SpId 35501
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_field 298786068
#define LBL_flat 9641024
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_id 10114
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_muts 9858798
#define LBL_name 9869138
#define LBL_params 951713969
#define LBL_read 9991773
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_use 325633
static uint32_t shape_name__field__use[] = {LBL_name, LBL_field, LBL_use};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2edriver_2elistedName(V);
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistedName_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eowned_2eelemS(V, V);
V g_heff_2ecompile_2eowned_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eelemS_clo;
V g_heff_2ecompile_2esimplify_2ecountArm(V, V, V);
V g_heff_2ecompile_2esimplify_2ecountArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecountArm_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2ethawKeep(V, V, V);
V g_heff_2eelab_2etoplevel_2ethawKeep_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawKeep_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1414119352x995333365(V, V);
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a);
extern Clo g_list_2eall_24s1414119352x995333365_clo;
V g_list_2eall_24s418009941x978041577(V, V, V, V);
V g_list_2eall_24s418009941x978041577_entry(V self, V *a);
extern Clo g_list_2eall_24s418009941x978041577_clo;
V g_list_2eall_24s751274328x395946890(V, V, V);
V g_list_2eall_24s751274328x395946890_entry(V self, V *a);
extern Clo g_list_2eall_24s751274328x395946890_clo;
V g_list_2eany_24s1206739756x709939553(V, V, V, V);
V g_list_2eany_24s1206739756x709939553_entry(V self, V *a);
extern Clo g_list_2eany_24s1206739756x709939553_clo;
V g_list_2eany_24s1931936847x1400497912(V);
V g_list_2eany_24s1931936847x1400497912_entry(V self, V *a);
extern Clo g_list_2eany_24s1931936847x1400497912_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
V g_list_2eany_24s357349853x1862456690(V, V);
V g_list_2eany_24s357349853x1862456690_entry(V self, V *a);
extern Clo g_list_2eany_24s357349853x1862456690_clo;
V g_list_2eany_24s464681941x898021545(V, V);
V g_list_2eany_24s464681941x898021545_entry(V self, V *a);
extern Clo g_list_2eany_24s464681941x898021545_clo;
V g_list_2eany_24s756915015x218492736(V);
V g_list_2eany_24s756915015x218492736_entry(V self, V *a);
extern Clo g_list_2eany_24s756915015x218492736_clo;
V g_list_2ecollapse_24s1005822741x724228783(V, V, V, V);
V g_list_2ecollapse_24s1005822741x724228783_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1005822741x724228783_clo;
V g_list_2edescending_24s2023694772x1287719119(V, V, V, V, V);
V g_list_2edescending_24s2023694772x1287719119_entry(V self, V *a);
extern Clo g_list_2edescending_24s2023694772x1287719119_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1508082563x149957932_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1096141254x104586789(V, V);
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1096141254x104586789_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2023159590x14712440(V, V);
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2023159590x14712440_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s323561330x1697851707(V, V);
V g_list_2efoldl_24s323561330x1697851707_entry(V self, V *a);
extern Clo g_list_2efoldl_24s323561330x1697851707_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2efoldl_24s964765707x1396946999(V, V);
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s964765707x1396946999_clo;
V g_list_2ekeepIf_24s1166238673x178798903(V, V);
V g_list_2ekeepIf_24s1166238673x178798903_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1166238673x178798903_clo;
V g_list_2ekeepIf_24s1166238673x178798903_24dps(V, V, V);
V g_list_2ekeepIf_24s1166238673x178798903_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1166238673x178798903_24dps_clo;
V g_list_2ekeepIf_24s1613584875x1342487326(V, V);
V g_list_2ekeepIf_24s1613584875x1342487326_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1613584875x1342487326_clo;
V g_list_2ekeepIf_24s1613584875x1342487326_24dps(V, V, V);
V g_list_2ekeepIf_24s1613584875x1342487326_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1613584875x1342487326_24dps_clo;
V g_list_2ekeepIf_24s1819141159x1906443669(V);
V g_list_2ekeepIf_24s1819141159x1906443669_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1819141159x1906443669_clo;
V g_list_2ekeepIf_24s1819141159x1906443669_24dps(V, V);
V g_list_2ekeepIf_24s1819141159x1906443669_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1819141159x1906443669_24dps_clo;
V g_list_2ekeepIf_24s920421308x594300259_24dps(V, V, V, V);
V g_list_2ekeepIf_24s920421308x594300259_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s920421308x594300259_24dps_clo;
V g_list_2emap_24f1141799624x1826918381(V, V, V);
V g_list_2emap_24f1141799624x1826918381_entry(V self, V *a);
extern Clo g_list_2emap_24f1141799624x1826918381_clo;
V g_list_2emap_24f1141799624x1826918381_24dps(V, V, V, V);
V g_list_2emap_24f1141799624x1826918381_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1141799624x1826918381_24dps_clo;
V g_list_2emap_24f1457339348x592422294(V, V, V);
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_clo;
V g_list_2emap_24f1457339348x592422294_24dps(V, V, V, V);
V g_list_2emap_24f1457339348x592422294_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1457339348x592422294_24dps_clo;
V g_list_2emap_24f1749649202x1754028860(V, V);
V g_list_2emap_24f1749649202x1754028860_entry(V self, V *a);
extern Clo g_list_2emap_24f1749649202x1754028860_clo;
V g_list_2emap_24f1749649202x1754028860_24dps(V, V, V);
V g_list_2emap_24f1749649202x1754028860_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1749649202x1754028860_24dps_clo;
V g_list_2emap_24f189927396x2059034600(V);
V g_list_2emap_24f189927396x2059034600_entry(V self, V *a);
extern Clo g_list_2emap_24f189927396x2059034600_clo;
V g_list_2emap_24f189927396x2059034600_24dps(V, V);
V g_list_2emap_24f189927396x2059034600_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f189927396x2059034600_24dps_clo;
V g_list_2emap_24f565269645x1954016017(V);
V g_list_2emap_24f565269645x1954016017_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_clo;
V g_list_2emap_24f565269645x1954016017_24dps(V, V);
V g_list_2emap_24f565269645x1954016017_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f565269645x1954016017_24dps_clo;
V g_list_2emap_24f8874541x1844987517_24dps(V, V, V);
V g_list_2emap_24f8874541x1844987517_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f8874541x1844987517_24dps_clo;
V g_list_2emap_24s1113395621x248103432(V);
V g_list_2emap_24s1113395621x248103432_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_clo;
V g_list_2emap_24s1113395621x248103432_24dps(V, V);
V g_list_2emap_24s1113395621x248103432_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_24dps_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1230969749x2018313496_24dps(V, V);
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_24dps_clo;
V g_list_2emap_24s1275294336x693095586(V, V);
V g_list_2emap_24s1275294336x693095586_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_clo;
V g_list_2emap_24s1275294336x693095586_24dps(V, V, V);
V g_list_2emap_24s1275294336x693095586_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_24dps_clo;
V g_list_2emap_24s1354328764x1362350361_24dps(V, V);
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_24dps_clo;
V g_list_2emap_24s1354671438x1264137843(V);
V g_list_2emap_24s1354671438x1264137843_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_clo;
V g_list_2emap_24s1354671438x1264137843_24dps(V, V);
V g_list_2emap_24s1354671438x1264137843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_24dps_clo;
V g_list_2emap_24s1460603830x671758883_24dps(V, V, V);
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24dps_clo;
V g_list_2emap_24s1611344417x463861413(V, V, V);
V g_list_2emap_24s1611344417x463861413_entry(V self, V *a);
extern Clo g_list_2emap_24s1611344417x463861413_clo;
V g_list_2emap_24s1611344417x463861413_24dps(V, V, V, V);
V g_list_2emap_24s1611344417x463861413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1611344417x463861413_24dps_clo;
V g_list_2emap_24s1709068899x1960726563_24dps(V, V, V, V, V);
V g_list_2emap_24s1709068899x1960726563_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1709068899x1960726563_24dps_clo;
V g_list_2emap_24s2029356170x1054793697(V);
V g_list_2emap_24s2029356170x1054793697_entry(V self, V *a);
extern Clo g_list_2emap_24s2029356170x1054793697_clo;
V g_list_2emap_24s2029356170x1054793697_24dps(V, V);
V g_list_2emap_24s2029356170x1054793697_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029356170x1054793697_24dps_clo;
V g_list_2emap_24s205414595x1692305030_24dps(V, V);
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_24dps_clo;
V g_list_2emap_24s328934344x1728860012(V, V);
V g_list_2emap_24s328934344x1728860012_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_clo;
V g_list_2emap_24s328934344x1728860012_24dps(V, V, V);
V g_list_2emap_24s328934344x1728860012_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_24dps_clo;
V g_list_2emap_24s725725455x1186198702_24dps(V, V);
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_24dps_clo;
V g_list_2emap_24s784191759x2032889081(V);
V g_list_2emap_24s784191759x2032889081_entry(V self, V *a);
extern Clo g_list_2emap_24s784191759x2032889081_clo;
V g_list_2emap_24s784191759x2032889081_24dps(V, V);
V g_list_2emap_24s784191759x2032889081_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s784191759x2032889081_24dps_clo;
V g_list_2emap_24s903588428x1469638784(V, V);
V g_list_2emap_24s903588428x1469638784_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_clo;
V g_list_2emap_24s903588428x1469638784_24dps(V, V, V);
V g_list_2emap_24s903588428x1469638784_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_24dps_clo;
V g_list_2emergeRuns_24s810789954x1170958779(V, V, V, V);
V g_list_2emergeRuns_24s810789954x1170958779_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s810789954x1170958779_clo;
V g_list_2epushRun_24s1839415905x1299165467(V, V, V, V, V);
V g_list_2epushRun_24s1839415905x1299165467_entry(V self, V *a);
extern Clo g_list_2epushRun_24s1839415905x1299165467_clo;
V g_list_2erunFrom(V, V, V);
V g_list_2erunFrom_entry(V self, V *a);
extern Clo g_list_2erunFrom_clo;
V g_list_2ezipWith_24s1893966264x617194987(V, V);
V g_list_2ezipWith_24s1893966264x617194987_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_clo;
V g_list_2ezipWith_24s1893966264x617194987_24dps(V, V, V);
V g_list_2ezipWith_24s1893966264x617194987_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_24dps_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s1958630276x749154843_24dps(V, V, V);
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo;
V g_list_2ezipWith_24s583291244x257539062(V, V);
V g_list_2ezipWith_24s583291244x257539062_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_clo;
V g_list_2ezipWith_24s583291244x257539062_24dps(V, V, V);
V g_list_2ezipWith_24s583291244x257539062_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s583291244x257539062_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032(V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_list_2efoldl_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_entry, 3, 0};

V g_list_2efoldl(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_z_241, heff_dup(v_x_243)}));
    V t_0 = v_f_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_f_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1613584875x1342487326_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1613584875x1342487326_entry, 2, 0};

V g_list_2ekeepIf_24s1613584875x1342487326(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_242, 0)))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1613584875x1342487326_24dps(v_lit_240, v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1613584875x1342487326_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1613584875x1342487326(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1166238673x178798903_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1166238673x178798903_entry, 2, 0};

V g_list_2ekeepIf_24s1166238673x178798903(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_242, 0))) ? !heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_x_242, 1))) : 1)) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1166238673x178798903_24dps(v_lit_240, v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1166238673x178798903_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1166238673x178798903(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2eall_24s1414119352x995333365_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1414119352x995333365_entry, 2, 0};

V g_list_2eall_24s1414119352x995333365(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        v_a_2411 = (g_heff_2esyntax_2epresyntax_2esegmentOdd(v_a_247, v_a_248));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_a_2412 = heff_field(v_a_2411, 0);
      heff_take_n(v_a_2411, 1ULL, 1);
      if (heff_intEq_c_lent(v_a_2412, v_lit_240, 1)) {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_a_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eall_24s1414119352x995333365(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1709068899x1960726563_24dps_str0, 1, "`");
HEFF_LIT(g_list_2emap_24s1709068899x1960726563_24dps_str1, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_list_2emap_24s1709068899x1960726563_24dps_str2, 7, " := e`)");
V g_list_2emap_24s1709068899x1960726563_24dps_lam0(V self, V *args);
Clo g_list_2emap_24s1709068899x1960726563_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1709068899x1960726563_24dps_entry, 5, 0};

V g_list_2emap_24s1709068899x1960726563_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_cx_247 = heff_dup(v_lit_240);
    V v_rest_248 = heff_dup(v_lit_241);
    V v_end_249 = heff_dup(v_lit_242);
    V v_x5_2410 = v_x_245;
    V v_t_2460;
    switch (heff_tag_of(v_x5_2410)) {
    case TAG_MkPair: {
      V v_p_2411 = heff_field(v_x5_2410, 0);
      V v_ss_2412 = heff_field(v_x5_2410, 1);
      V v_ru_24x5_2410_24MkPair = heff_take_reuse_n(v_x5_2410, 3ULL, 2);
      V v_x1_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_2412)));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_Nil: {
        v_t_2430 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x1_2413, 0);
        heff_take_n(v_x1_2413, 1ULL, 2);
        switch (heff_tag_of(v_x_2414)) {
        case TAG_At: {
          V v_it11_2416 = heff_field(v_x_2414, 0);
          heff_take_n(v_x_2414, 1ULL, 2);
          switch (heff_tag_of(v_it11_2416)) {
          case TAG_StmtBind: {
            heff_take_n(v_it11_2416, 0ULL, 3);
            v_t_2430 = NTAG(TAG_True);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_it11_2416, 0ULL, 2);
            v_t_2430 = NTAG(TAG_True);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_2423 = heff_field(v_it11_2416, 0);
            heff_take_n(v_it11_2416, 1ULL, 1);
            v_t_2430 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2423));
            break;
          }
          case TAG_StmtLetMut: {
            heff_take_n(v_it11_2416, 0ULL, 3);
            v_t_2430 = NTAG(TAG_True);
            break;
          }
          case TAG_StmtLetElse: {
            heff_take_n(v_it11_2416, 0ULL, 3);
            v_t_2430 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it11_2416);
          }
          break;
        }
        default: heff_nomatch(v_x_2414);
        }
        break;
      }
      default: heff_nomatch(v_x1_2413);
      }
      if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
        heff_drop(v_t_2430);
        V v_t_2431 = (g_prelude_2e_2b_2b(v_ss_2412, v_rest_248));
        v_t_2460 = (g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(v_cx_247, v_end_249, heff_tag_re_n(v_ru_24x5_2410_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_p_2411, v_t_2431})));
      } else {
        heff_drop(v_rest_248);
        heff_drop_cell(v_ru_24x5_2410_24MkPair, 2);
        heff_drop(v_t_2430);
        V v_lit_2432 = v_p_2411;
        V v_lit_2433 = v_ss_2412;
        V v_cx_2434 = v_cx_247;
        V v_end_2435 = v_end_249;
        V v_xs_2436 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_lit_2432)));
        HeffT2 v_t_2438 = ({ V b_0 = heff_clo_n(g_list_2emap_24s1709068899x1960726563_24dps_lam0, 1, 1, (V[]){heff_dup(v_cx_2434)}); V a_1 = v_xs_2436; HeffT2 r_ = (g_list_2efind_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_xs_2436); r_; });
        {
          V v_field_2440 = v_t_2438.f[1];
          int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
          if ((v_tag_2439 == ((int64_t)0ULL))) {
            heff_drop(v_lit_2433);
            heff_drop_rec(v_cx_2434, 7);
            heff_drop(v_end_2435);
            V v_x_2441 = v_field_2440;
            V v_t_2444;
            switch (heff_tag_of(v_lit_2432)) {
            case TAG_At: {
              V v_s_2443 = heff_dup(heff_field(v_lit_2432, 1));
              v_t_2444 = v_s_2443;
              break;
            }
            default: heff_nomatch(v_lit_2432);
            }
            V v_t_2447;
            switch (heff_tag_of(v_lit_2432)) {
            case TAG_At: {
              V v_s_2446 = heff_dup(heff_field(v_lit_2432, 1));
              v_t_2447 = v_s_2446;
              break;
            }
            default: heff_nomatch(v_lit_2432);
            }
            V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1709068899x1960726563_24dps_str0), heff_dup(v_x_2441)), ((V)&g_list_2emap_24s1709068899x1960726563_24dps_str1));
            V v_t_2449 = heff_strAppend(heff_strAppend(v_t_2448, v_x_2441), ((V)&g_list_2emap_24s1709068899x1960726563_24dps_str2));
            V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2449}), heff_dup(v_t_2444)});
            V v_t_2451 = ({ V rv_1 = heff_get_n(v_t_2444, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2447, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_lit_2432, v_t_2450}), v_t_2451});
          } else {
            heff_drop(v_field_2440);
            V v_e_2452 = ({ V a_0 = v_cx_2434; V a_1 = v_lit_2433; V a_2 = v_end_2435; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_lit_2433); r_; });
            V v_t_2455;
            switch (heff_tag_of(v_lit_2432)) {
            case TAG_At: {
              V v_s_2454 = heff_dup(heff_field(v_lit_2432, 1));
              v_t_2455 = v_s_2454;
              break;
            }
            default: heff_nomatch(v_lit_2432);
            }
            V v_t_2458;
            switch (heff_tag_of(v_e_2452)) {
            case TAG_At: {
              V v_s_2457 = heff_dup(heff_field(v_e_2452, 1));
              v_t_2458 = v_s_2457;
              break;
            }
            default: heff_nomatch(v_e_2452);
            }
            V v_t_2459 = ({ V rv_1 = heff_get_n(v_t_2458, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2455, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_lit_2432, v_e_2452}), v_t_2459});
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x5_2410);
    }
    V v_cell_2461 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2460, heff_hole()});
    V v_u_2462 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2461);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_2462;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1709068899x1960726563_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2emap_24s1709068899x1960726563_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
V g_list_2emap_24s1709068899x1960726563_24dps_lam0(V self, V *args) {
  V v_x_2437 = args[0];
  V v_cx_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2437; V b_1 = heff_get_n(v_cx_2434, 1, 7); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2437); heff_drop(b_1); r_; });
}
Clo g_list_2emap_24s205414595x1692305030_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s205414595x1692305030_24dps_entry, 2, 0};

V g_list_2emap_24s205414595x1692305030_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2456;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_sp_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_DeclareField: {
        V v_x_247 = heff_field(v_x21_245, 0);
        V v_xsp_248 = heff_field(v_x21_245, 1);
        V v_t_249 = heff_field(v_x21_245, 2);
        V v_d_2410 = heff_field(v_x21_245, 3);
        V v_ru_24x21_245_24DeclareField = heff_take_reuse_n(v_x21_245, 15ULL, 4);
        HeffT3 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_249));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          V v_t_2424;
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_c_2415 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
            V v_t_2418;
            switch (heff_tag_of(v_c_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_c_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_c_2415);
            }
            v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2415}), v_t_2418});
          } else {
            if ((v_tag_2412 == ((int64_t)1ULL))) {
              V v_i_2419 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
              v_t_2424 = v_t_2423;
            }
          }
          V v_t_2440;
          switch (heff_tag_of(v_d_2410)) {
          case TAG_Nothing: {
            v_t_2440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x_2425 = heff_field(v_d_2410, 0);
            V v_ru_24d_2410_24Just = heff_take_reuse_n(v_d_2410, 1ULL, 1);
            HeffT3 v_t_2426 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2425));
            {
              V v_field_2428 = v_t_2426.f[1];
              V v_field_2429 = v_t_2426.f[2];
              int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
              V v_t_2439;
              if ((v_tag_2427 == ((int64_t)0ULL))) {
                V v_c_2430 = heff_tag_n(TAG_At, 2, (V[]){v_field_2428, v_field_2429});
                v_t_2439 = v_c_2430;
              } else {
                if ((v_tag_2427 == ((int64_t)1ULL))) {
                  V v_i_2431 = heff_tag_n(TAG_At, 2, (V[]){v_field_2428, v_field_2429});
                  V v_t_2434;
                  switch (heff_tag_of(v_i_2431)) {
                  case TAG_At: {
                    V v_s_2433 = heff_dup(heff_field(v_i_2431, 1));
                    v_t_2434 = v_s_2433;
                    break;
                  }
                  default: heff_nomatch(v_i_2431);
                  }
                  v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2431}), v_t_2434});
                } else {
                  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){v_field_2428, v_field_2429});
                  V v_t_2438;
                  switch (heff_tag_of(v_t_2435)) {
                  case TAG_At: {
                    V v_s_2437 = heff_dup(heff_field(v_t_2435, 1));
                    v_t_2438 = v_s_2437;
                    break;
                  }
                  default: heff_nomatch(v_t_2435);
                  }
                  v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2435}), v_t_2438});
                }
              }
              v_t_2440 = heff_tag_at_n(v_ru_24d_2410_24Just, TAG_Just, 1, (V[]){v_t_2439});
            }
            break;
          }
          default: heff_nomatch(v_d_2410);
          }
          v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_245_24DeclareField, TAG_DeclareField, 4, 3ULL, (V[]){v_x_247, v_xsp_248, v_t_2424, v_t_2440}), v_sp_246});
        }
        break;
      }
      case TAG_BadFieldDecl: {
        V v_e_2441 = heff_field(v_x21_245, 0);
        V v_ru_24x21_245_24BadFieldDecl = heff_take_reuse_n(v_x21_245, 1ULL, 1);
        HeffT3 v_t_2442 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2441));
        {
          V v_field_2444 = v_t_2442.f[1];
          V v_field_2445 = v_t_2442.f[2];
          int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
          V v_t_2455;
          if ((v_tag_2443 == ((int64_t)0ULL))) {
            V v_c_2446 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2444, v_field_2445});
            V v_t_2449;
            switch (heff_tag_of(v_c_2446)) {
            case TAG_At: {
              V v_s_2448 = heff_dup(heff_field(v_c_2446, 1));
              v_t_2449 = v_s_2448;
              break;
            }
            default: heff_nomatch(v_c_2446);
            }
            v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2446}), v_t_2449});
          } else {
            if ((v_tag_2443 == ((int64_t)1ULL))) {
              V v_i_2450 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2444, v_field_2445});
              V v_t_2453;
              switch (heff_tag_of(v_i_2450)) {
              case TAG_At: {
                V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
                v_t_2453 = v_s_2452;
                break;
              }
              default: heff_nomatch(v_i_2450);
              }
              v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
            } else {
              V v_t_2454 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2444, v_field_2445});
              v_t_2455 = v_t_2454;
            }
          }
          v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_245_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2455}), v_sp_246});
        }
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_cell_2457 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2456, heff_hole()});
    V v_u_2458 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2457);
    V t_0 = v_xs_243;
    V t_1 = v_u_2458;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s205414595x1692305030_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s205414595x1692305030_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1230969749x2018313496_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_entry, 1, 0};

V g_list_2emap_24s1230969749x2018313496(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2422;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkAlt: {
        V v_p_246 = heff_field(v_x21_244, 0);
        V v_b_247 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkAlt = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        HeffT3 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_247));
        {
          V v_field_2410 = v_t_248.f[1];
          V v_field_2411 = v_t_248.f[2];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          V v_t_2421;
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_c_2412 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
            v_t_2421 = v_c_2412;
          } else {
            if ((v_tag_249 == ((int64_t)1ULL))) {
              V v_i_2413 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
              V v_t_2416;
              switch (heff_tag_of(v_i_2413)) {
              case TAG_At: {
                V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
                v_t_2416 = v_s_2415;
                break;
              }
              default: heff_nomatch(v_i_2413);
              }
              v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2413}), v_t_2416});
            } else {
              V v_t_2417 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
              V v_t_2420;
              switch (heff_tag_of(v_t_2417)) {
              case TAG_At: {
                V v_s_2419 = heff_dup(heff_field(v_t_2417, 1));
                v_t_2420 = v_s_2419;
                break;
              }
              default: heff_nomatch(v_t_2417);
              }
              v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2417}), v_t_2420});
            }
          }
          v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_244_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_246, v_t_2421}), v_sp_245});
        }
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s1230969749x2018313496_24dps(v_xs_242, v_cell_2423));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230969749x2018313496(a[0]);
}
Clo g_list_2eany_24s1206739756x709939553_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1206739756x709939553_entry, 4, 0};

V g_list_2eany_24s1206739756x709939553(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_budget_246 = heff_dup(v_lit_240);
    V v_x2_247 = heff_dup(v_lit_241);
    V v_arms_248 = heff_dup(v_lit_242);
    V v_a_249 = v_x_244;
    V v_t_2423;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_ts_2410 = heff_field(v_x2_247, 0);
      V v_n_2411 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2ecountArm(v_arms_248, v_a_249, v_ts_2410));
      V v_x_2413 = heff_intAdd_lent(v_t_2412, v_n_2411, 1);
      if (heff_intLt_c(MK_INT(1LL), v_x_2413)) {
        V v_t_2414 = ({ V a_0 = v_arms_248; V a_1 = v_a_249; V a_2 = v_ts_2410; V r_ = (g_heff_2ecompile_2esimplify_2ecountArm(a_0, a_1, a_2)); heff_drop(v_arms_248); heff_drop(v_ts_2410); r_; });
        V v_t_2415 = heff_intSub(heff_intAdd(v_t_2414, v_n_2411), MK_INT(1LL));
        V v_lim_2416 = heff_intDiv(v_budget_246, v_t_2415);
        V v_t_2420;
        switch (heff_tag_of(v_a_249)) {
        case TAG_MkArm: {
          V v_b_2419 = heff_field(v_a_249, 2);
          heff_take_n(v_a_249, 4ULL, 3);
          v_t_2420 = v_b_2419;
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        V v_t_2421 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
        V v_x_2422 = (g_heff_2ecompile_2eir_2esizeB(v_lim_2416, MK_INT(0LL), v_t_2421));
        v_t_2423 = heff_bool(heff_intLt_c_lent(v_lim_2416, v_x_2422, 0));
        heff_drop(v_lim_2416);
        heff_drop(v_x_2422);
      } else {
        heff_drop_cell(v_ru_24x2_243_24Cons, 2);
        heff_drop(v_budget_246);
        heff_drop(v_arms_248);
        heff_drop(v_a_249);
        heff_drop(v_ts_2410);
        heff_drop(v_n_2411);
        v_t_2423 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_xs_245);
      heff_drop(v_t_2423);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2423);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s1206739756x709939553_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2eany_24s1206739756x709939553(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1096141254x104586789_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1096141254x104586789_entry, 2, 0};

V g_list_2efoldl_24s1096141254x104586789(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244;
    if (heff_intLe_c_lent(v_z_240, v_x_242, 0)) {
      v_t_244 = v_z_240;
    } else {
      heff_drop(v_z_240);
      v_t_244 = heff_dup(v_x_242);
    }
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1096141254x104586789(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1347985788x1836008258_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1347985788x1836008258_entry, 2, 0};

V g_list_2efoldl_24s1347985788x1836008258(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b_24f368057430x559112032(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1347985788x1836008258(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s756915015x218492736_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s756915015x218492736_entry, 1, 0};

V g_list_2eany_24s756915015x218492736(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_x1_243 = heff_dup(v_x_241);
    V v_t_2482;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_EVar: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      V v_x11_2415 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 4);
      switch (heff_tag_of(v_x11_2415)) {
      case TAG_EVar: {
        heff_take_n(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_True);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x11_2415, 0ULL, 2);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x11_2415, 0ULL, 2);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x11_2415, 0ULL, 3);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x11_2415, 0ULL, 2);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x11_2415, 0ULL, 4);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x11_2415, 0ULL, 3);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x11_2415, 0ULL, 2);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x11_2415, 0ULL, 2);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x11_2415, 0ULL, 2);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x11_2415, 0ULL, 2);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x11_2415, 0ULL, 3);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x11_2415, 0ULL, 1);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x11_2415, 0ULL, 2);
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2415);
      }
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    if ((heff_dup(v_t_2482) == NTAG(TAG_True))) {
      heff_drop(v_t_2482);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2482);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s756915015x218492736_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s756915015x218492736(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s583291244x257539062_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s583291244x257539062_entry, 2, 0};

V g_list_2ezipWith_24s583291244x257539062(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_SSet, 2, (V[]){v_x_242, heff_tag_n(TAG_OSimple, 1, (V[]){v_y_244})});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s583291244x257539062_24dps(v_xs_243, v_ys_245, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s583291244x257539062_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s583291244x257539062(a[0], a[1]);
}
Clo g_list_2efoldl_24s964765707x1396946999_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s964765707x1396946999_entry, 2, 0};

V g_list_2efoldl_24s964765707x1396946999(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_z_240});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Pinned, 1, (V[]){v_x_242}), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s964765707x1396946999(a[0], a[1]);
}
Clo g_list_2eall_24s751274328x395946890_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s751274328x395946890_entry, 3, 0};

V g_list_2eall_24s751274328x395946890(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_ok_245 = heff_dup(v_lit_240);
    V v_us_246 = heff_dup(v_lit_241);
    V v_a_247 = v_x_243;
    V v_t_2436;
    switch (heff_tag_of(v_a_247)) {
    case TAG_Given: {
      heff_drop(v_us_246);
      V v_t_2415;
      switch (heff_tag_of(v_a_247)) {
      case TAG_Given: {
        V v_e_249 = heff_field(v_a_247, 0);
        heff_take_n(v_a_247, 1ULL, 1);
        v_t_2415 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
        break;
      }
      case TAG_GivenU: {
        V v_e_2411 = heff_field(v_a_247, 1);
        heff_take_n(v_a_247, 2ULL, 2);
        v_t_2415 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_2411, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LentVar: {
        heff_take_n(v_a_247, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        v_t_2415 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LentValue: {
        V v_e_2414 = heff_field(v_a_247, 0);
        heff_take_n(v_a_247, 1ULL, 1);
        v_t_2415 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_2414, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_a_247);
      }
      v_t_2436 = ({ V a_0 = v_ok_245; V a_1 = v_t_2415; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_ok_245); heff_drop(v_t_2415); r_; });
      break;
    }
    case TAG_GivenU: {
      heff_drop(v_us_246);
      V v_t_2424;
      switch (heff_tag_of(v_a_247)) {
      case TAG_Given: {
        V v_e_2418 = heff_field(v_a_247, 0);
        heff_take_n(v_a_247, 1ULL, 1);
        v_t_2424 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_2418, NTAG(TAG_Nil)});
        break;
      }
      case TAG_GivenU: {
        V v_e_2420 = heff_field(v_a_247, 1);
        heff_take_n(v_a_247, 2ULL, 2);
        v_t_2424 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_2420, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LentVar: {
        heff_take_n(v_a_247, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        v_t_2424 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LentValue: {
        V v_e_2423 = heff_field(v_a_247, 0);
        heff_take_n(v_a_247, 1ULL, 1);
        v_t_2424 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_a_247);
      }
      v_t_2436 = ({ V a_0 = v_ok_245; V a_1 = v_t_2424; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_ok_245); heff_drop(v_t_2424); r_; });
      break;
    }
    case TAG_LentVar: {
      V v_x_2425 = heff_field(v_a_247, 0);
      heff_take_n(v_a_247, 1ULL, 2);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_ok_245);
      V v_x1_2427 = ({ V a_0 = v_x_2425; V a_1 = v_us_246; V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, a_1)); heff_drop(v_x_2425); heff_drop(v_us_246); r_; });
      v_t_2436 = heff_bool(!(heff_dup(v_x1_2427) == NTAG(TAG_True)));
      heff_drop(v_x1_2427);
      break;
    }
    case TAG_LentValue: {
      heff_drop(v_us_246);
      V v_t_2435;
      switch (heff_tag_of(v_a_247)) {
      case TAG_Given: {
        V v_e_2429 = heff_field(v_a_247, 0);
        heff_take_n(v_a_247, 1ULL, 1);
        v_t_2435 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_2429, NTAG(TAG_Nil)});
        break;
      }
      case TAG_GivenU: {
        V v_e_2431 = heff_field(v_a_247, 1);
        heff_take_n(v_a_247, 2ULL, 2);
        v_t_2435 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_2431, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LentVar: {
        heff_take_n(v_a_247, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        v_t_2435 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LentValue: {
        V v_e_2434 = heff_field(v_a_247, 0);
        heff_take_n(v_a_247, 1ULL, 1);
        v_t_2435 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_e_2434, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_a_247);
      }
      v_t_2436 = ({ V a_0 = v_ok_245; V a_1 = v_t_2435; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_ok_245); heff_drop(v_t_2435); r_; });
      break;
    }
    default: heff_nomatch(v_a_247);
    }
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_xs_244);
      heff_drop(v_t_2436);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eall_24s751274328x395946890_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eall_24s751274328x395946890(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s323561330x1697851707_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s323561330x1697851707_entry, 2, 0};

V g_list_2efoldl_24s323561330x1697851707(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_flat_244 = heff_take_field(v_x_242, 3);
    V v_read_245 = heff_get_n(v_x_242, 2, 4);
    V v_t_246 = v_flat_244;
    V v_t_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_read_245);
      v_t_248 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_read_245, v_a_247}), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s323561330x1697851707_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s323561330x1697851707(a[0], a[1]);
}
Clo g_list_2emap_24s1460603830x671758883_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1460603830x671758883_24dps_entry, 3, 0};

V g_list_2emap_24s1460603830x671758883_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1460603830x671758883_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s2023159590x14712440_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2023159590x14712440_entry, 2, 0};

V g_list_2efoldl_24s2023159590x14712440(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 2)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2023159590x14712440_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2023159590x14712440(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1354671438x1264137843_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354671438x1264137843_entry, 1, 0};

V g_list_2emap_24s1354671438x1264137843(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1354671438x1264137843_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354671438x1264137843_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354671438x1264137843(a[0]);
}
Clo g_list_2emap_24s784191759x2032889081_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s784191759x2032889081_entry, 1, 0};

V g_list_2emap_24s784191759x2032889081(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24Given = heff_take_reuse_n(v_x_241, 1ULL, 1);
      V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_243));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24Given, TAG_Given, 1, (V[]){v_t_244});
      break;
    }
    case TAG_GivenU: {
      V v_a_245 = heff_field(v_x_241, 0);
      V v_a_246 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24GivenU = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_246));
      v_t_2412 = heff_tag_re_n(v_ru_24x_241_24GivenU, TAG_GivenU, 2, 1ULL, (V[]){v_a_245, v_t_247});
      break;
    }
    case TAG_LentVar: {
      v_t_2412 = v_x_241;
      break;
    }
    case TAG_LentValue: {
      V v_a_2410 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24LentValue = heff_take_reuse_n(v_x_241, 1ULL, 1);
      V v_t_2411 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_a_2410));
      v_t_2412 = heff_tag_at_n(v_ru_24x_241_24LentValue, TAG_LentValue, 1, (V[]){v_t_2411});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = (g_list_2emap_24s784191759x2032889081_24dps(v_xs_242, v_cell_2413));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s784191759x2032889081_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s784191759x2032889081(a[0]);
}
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str0, 7, "Float64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str1, 4, "Int8");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str2, 5, "Int16");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str3, 5, "Int32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str4, 5, "Int64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str5, 5, "UInt8");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str6, 6, "UInt16");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str7, 6, "UInt32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str8, 6, "UInt64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str9, 7, "Float32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str10, 1, "_");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str11, 1, "\?");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str12, 7, "Float64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str13, 4, "Int8");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str14, 5, "Int16");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str15, 5, "Int32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str16, 5, "Int64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str17, 5, "UInt8");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str18, 6, "UInt16");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str19, 6, "UInt32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str20, 6, "UInt64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str21, 7, "Float32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str22, 1, "_");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_str23, 1, "\?");
Clo g_list_2ezipWith_24s1893966264x617194987_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1893966264x617194987_entry, 2, 0};

V g_list_2ezipWith_24s1893966264x617194987(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_a_246 = v_x_242;
      V v_b_247 = v_y_244;
      V v_t_249;
      switch (heff_tag_of(v_a_246)) {
      case TAG_FtFloat: {
        v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str0);
        break;
      }
      case TAG_FtFixed: {
        V v_w_248 = heff_dup(heff_field(v_a_246, 0));
        switch (heff_tag_of(v_w_248)) {
        case TAG_I8: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str1);
          break;
        }
        case TAG_I16: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str2);
          break;
        }
        case TAG_I32: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str3);
          break;
        }
        case TAG_I64: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str4);
          break;
        }
        case TAG_U8: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str5);
          break;
        }
        case TAG_U16: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str6);
          break;
        }
        case TAG_U32: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str7);
          break;
        }
        case TAG_U64: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str8);
          break;
        }
        case TAG_F32: {
          v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str9);
          break;
        }
        default: heff_nomatch(v_w_248);
        }
        break;
      }
      case TAG_FtOther: {
        v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str10);
        break;
      }
      case TAG_FtAny: {
        v_t_249 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str11);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      V v_t_2411;
      switch (heff_tag_of(v_b_247)) {
      case TAG_FtFloat: {
        v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str12);
        break;
      }
      case TAG_FtFixed: {
        V v_w_2410 = heff_field(v_b_247, 0);
        heff_take_n(v_b_247, 1ULL, 1);
        switch (heff_tag_of(v_w_2410)) {
        case TAG_I8: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str13);
          break;
        }
        case TAG_I16: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str14);
          break;
        }
        case TAG_I32: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str15);
          break;
        }
        case TAG_I64: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str16);
          break;
        }
        case TAG_U8: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str17);
          break;
        }
        case TAG_U16: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str18);
          break;
        }
        case TAG_U32: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str19);
          break;
        }
        case TAG_U64: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str20);
          break;
        }
        case TAG_F32: {
          v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str21);
          break;
        }
        default: heff_nomatch(v_w_2410);
        }
        break;
      }
      case TAG_FtOther: {
        v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str22);
        break;
      }
      case TAG_FtAny: {
        v_t_2411 = ((V)&g_list_2ezipWith_24s1893966264x617194987_str23);
        break;
      }
      default: heff_nomatch(v_b_247);
      }
      V v_t_2412;
      if (heff_strEq_c(v_t_249, v_t_2411)) {
        v_t_2412 = v_a_246;
      } else {
        heff_drop(v_a_246);
        v_t_2412 = NTAG(TAG_FtOther);
      }
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = (g_list_2ezipWith_24s1893966264x617194987_24dps(v_xs_243, v_ys_245, v_cell_2413));
      heff_drop(v_u_2414);
      return v_cell_2413;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1893966264x617194987_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1893966264x617194987(a[0], a[1]);
}

HeffT2 g_list_2efind_24s1508082563x149957932_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2eany_24s1931936847x1400497912_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1931936847x1400497912_entry, 1, 0};

V g_list_2eany_24s1931936847x1400497912(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      v_t_246 = heff_bool(heff_strEq_c(heff_dup(v_a_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1931936847x1400497912_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1931936847x1400497912(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1275294336x693095586_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1275294336x693095586_entry, 2, 0};

V g_list_2emap_24s1275294336x693095586(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_es_244 = heff_dup(v_lit_240);
    V v_e_245 = v_x_242;
    V v_t_2493;
    switch (heff_tag_of(v_e_245)) {
    case TAG_RLocal: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RDup: {
      V v_x_247 = heff_field(v_e_245, 0);
      V v_ru_24e_245_24RDup = heff_take_reuse_n(v_e_245, 1ULL, 1);
      V v_x1_248 = ({ V a_0 = v_x_247; V a_1 = v_es_244; V r_ = (g_list_2eany_24s357349853x1862456690(a_0, a_1)); heff_drop(v_es_244); r_; });
      if (!(heff_dup(v_x1_248) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24e_245_24RDup, 1);
        heff_drop(v_x1_248);
        v_t_2493 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_247});
      } else {
        heff_drop(v_x1_248);
        v_t_2493 = heff_tag_re_n(v_ru_24e_245_24RDup, TAG_RDup, 1, 1ULL, (V[]){v_x_247});
      }
      break;
    }
    case TAG_RClo: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RGet: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RGetRaw: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RInt: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RFloat: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RStr: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RBytes: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RFixed: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RF32: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RNTag: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RStatic: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RTag: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RTagIn: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RRec: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RRecIn: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RField: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RDupE: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RFieldV: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RGetN: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RFieldU: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RGetNU: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RWord: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RTakeField: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RGetLabel: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RPrimFn: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RPrim: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RLam: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RCall: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RApply: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RBool: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RAbandon: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RBox: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RUnbox: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RPeek: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RPrimU: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RPrimAt: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RFixU: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RF32U: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    case TAG_RF64U: {
      heff_drop(v_es_244);
      v_t_2493 = v_e_245;
      break;
    }
    default: heff_nomatch(v_e_245);
    }
    V v_cell_2494 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2493, heff_hole()});
    V v_u_2495 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_2494; V r_ = (g_list_2emap_24s1275294336x693095586_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_2495);
    return v_cell_2494;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1275294336x693095586_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1275294336x693095586(a[0], a[1]);
}
Clo g_list_2efoldl_24s337463599x663364213_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s337463599x663364213_entry, 2, 0};

V g_list_2efoldl_24s337463599x663364213(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_acc_244 = v_z_240;
    V v_d_245 = heff_dup(v_x_242);
    V v_t_246 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_245, 5)));
    V v_t_2415;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_acc_244, 0)), 1, 8);
      HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = heff_rfield(v_d_245, 1); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_e_2411 = v_field_2410;
          heff_drop(v_e_2411);
          V v_t_2412 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_rfield(v_d_245, 0), heff_rfield(v_d_245, 1), heff_dup(heff_rfield(v_acc_244, 0))));
          v_t_2415 = (g_heff_2eelab_2etoplevel_2ethawKeep(v_acc_244, v_d_245, v_t_2412));
        } else {
          heff_drop(v_field_2410);
          V v_t_2413 = (g_heff_2eelab_2etoplevel_2ethawGlobals(heff_dup(v_acc_244), heff_dup(v_d_245)));
          v_t_2415 = (g_heff_2eelab_2etoplevel_2ethawKeep(v_acc_244, v_d_245, v_t_2413));
        }
      }
    } else {
      heff_drop(v_t_246);
      V v_t_2414 = (g_heff_2eelab_2etoplevel_2ethawGlobals(heff_dup(v_acc_244), heff_dup(v_d_245)));
      v_t_2415 = (g_heff_2eelab_2etoplevel_2ethawKeep(v_acc_244, v_d_245, v_t_2414));
    }
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s337463599x663364213(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1819141159x1906443669_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1819141159x1906443669_entry, 1, 0};

V g_list_2ekeepIf_24s1819141159x1906443669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_dup(heff_field(v_x_241, 0));
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_243, 0ULL, 5);
        V v_cell_2410 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
        V v_u_2411 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, v_cell_2410));
        heff_drop(v_u_2411);
        return v_cell_2410;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_243, 0ULL, 5);
        V v_cell_2417 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
        V v_u_2418 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, v_cell_2417));
        heff_drop(v_u_2418);
        return v_cell_2417;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_243, 0ULL, 4);
        V v_cell_2423 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
        V v_u_2424 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, v_cell_2423));
        heff_drop(v_u_2424);
        return v_cell_2423;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_x11_243, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        switch (heff_tag_of(v_x_241)) {
        case TAG_At: {
          heff_take_n(v_x_241, 0ULL, 2);
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_x_241);
        }
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_243, 0ULL, 2);
        V v_cell_2432 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
        V v_u_2433 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, v_cell_2432));
        heff_drop(v_u_2433);
        return v_cell_2432;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_243, 0ULL, 1);
        V v_cell_2435 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
        V v_u_2436 = (g_list_2ekeepIf_24s1819141159x1906443669_24dps(v_xs_242, v_cell_2435));
        heff_drop(v_u_2436);
        return v_cell_2435;
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1819141159x1906443669_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1819141159x1906443669(a[0]);
}
Clo g_list_2ekeepIf_24s1819141159x1906443669_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1819141159x1906443669_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1819141159x1906443669_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_dup(heff_field(v_x_242, 0));
      switch (heff_tag_of(v_x11_244)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_244, 0ULL, 5);
        V v_cell_2411 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
        V v_u_2412 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2411);
        V t_0 = v_xs_243;
        V t_1 = v_u_2412;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_244, 0ULL, 5);
        V v_cell_2418 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
        V v_u_2419 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2418);
        V t_0 = v_xs_243;
        V t_1 = v_u_2419;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_244, 0ULL, 4);
        V v_cell_2424 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
        V v_u_2425 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2424);
        V t_0 = v_xs_243;
        V t_1 = v_u_2425;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_x11_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        switch (heff_tag_of(v_x_242)) {
        case TAG_At: {
          heff_take_n(v_x_242, 0ULL, 2);
          V t_0 = v_xs_243;
          V t_1 = v_d_241;
          v_x2_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_x_242);
        }
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_244, 0ULL, 2);
        V v_cell_2433 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
        V v_u_2434 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2433);
        V t_0 = v_xs_243;
        V t_1 = v_u_2434;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_244, 0ULL, 1);
        V v_cell_2436 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
        V v_u_2437 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2436);
        V t_0 = v_xs_243;
        V t_1 = v_u_2437;
        v_x2_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x11_244);
      }
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1819141159x1906443669_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s1819141159x1906443669_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s328934344x1728860012_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s328934344x1728860012_entry, 2, 0};

V g_list_2emap_24s328934344x1728860012(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_x_242)));
    V v_t_245 = heff_strAppend(heff_strAppend(v_t_244, heff_dup(v_lit_240)), heff_get_n(v_x_242, 2, 5));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_246; V r_ = (g_list_2emap_24s328934344x1728860012_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s328934344x1728860012_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s328934344x1728860012(a[0], a[1]);
}
Clo g_list_2emap_24s1354328764x1362350361_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354328764x1362350361_24dps_entry, 2, 0};

V g_list_2emap_24s1354328764x1362350361_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 0, 2), heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
    V t_0 = v_xs_243;
    V t_1 = v_u_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1354328764x1362350361_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2emergeRuns_24s810789954x1170958779_lam0(V self, V *args);
Clo g_list_2emergeRuns_24s810789954x1170958779_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s810789954x1170958779_entry, 4, 0};

V g_list_2emergeRuns_24s810789954x1170958779(V v_lit_240, V v_lit_241, V v_stack_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_MkPair: {
    V v_run_244 = heff_field(v_x3_243, 0);
    V v_x32_245 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_run_244; V a_3 = v_stack_242; V r_ = (g_list_2ecollapse_24s1005822741x724228783(a_0, a_1, a_2, a_3)); heff_drop(v_stack_242); r_; });
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x32_245, 0);
      V v_xs_247 = heff_field(v_x32_245, 1);
      heff_take_n(v_x32_245, 3ULL, 2);
      V v_t_248 = (g_list_2epushRun_24s1839415905x1299165467(v_lit_240, v_lit_241, MK_INT(0LL), v_run_244, v_stack_242));
      V v_t_2413 = (g_list_2erunFrom(heff_clo_n(g_list_2emergeRuns_24s810789954x1170958779_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_x_246, v_xs_247));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_248;
      V t_3 = v_t_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_stack_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2emergeRuns_24s810789954x1170958779_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emergeRuns_24s810789954x1170958779(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_list_2emergeRuns_24s810789954x1170958779_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_intSub(v_lit_240, heff_get_n(v_a_249, 0, 10));
  V v_t_2412 = heff_intSub(v_lit_241, heff_get_n(v_a_2410, 0, 10));
  V v_ret_24bool = heff_bool(heff_intLe_c_lent(v_t_2411, v_t_2412, 0));
  heff_drop(v_t_2411);
  heff_drop(v_t_2412);
  return v_ret_24bool;
}
Clo g_list_2emap_24s1611344417x463861413_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1611344417x463861413_entry, 3, 0};

V g_list_2emap_24s1611344417x463861413(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_name_245 = heff_take_field(v_x_243, 0);
    V v_tags_246 = heff_get_n(v_x_243, 1, 3);
    V v_t_247 = (g_heff_2ebuild_2edriver_2elistedName(v_name_245));
    V v_t_248 = v_tags_246;
    V v_t_249;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_249 = heff_dup(v_lit_240);
    } else {
      heff_drop(v_t_248);
      v_t_249 = heff_dup(v_lit_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_247, v_t_249), heff_hole()});
    V v_u_2411 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_xs_244; V a_3 = v_cell_2410; V r_ = (g_list_2emap_24s1611344417x463861413_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1611344417x463861413_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1611344417x463861413(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s418009941x978041577_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s418009941x978041577_entry, 4, 0};

V g_list_2eall_24s418009941x978041577(V v_lit_240, V v_box_24lit_241, V v_box_24lit_242, V v_x2_243) {
  int64_t v_lit_241 = heff_peek_word(v_box_24lit_241);
  int64_t v_lit_242 = heff_peek_word(v_box_24lit_242);
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_a_246 = heff_strByteAt_lent(v_lit_240, v_x_244, 0);
    if (((v_lit_241 <= heff_peek_word(v_a_246)) && (heff_peek_word(v_a_246) <= v_lit_242))) {
      heff_drop(v_a_246);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_a_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eall_24s418009941x978041577_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eall_24s418009941x978041577(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2ezipWith_24s1958630276x749154843_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1958630276x749154843_entry, 2, 0};

V g_list_2ezipWith_24s1958630276x749154843(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 2), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1958630276x749154843_24dps(v_xs_243, v_ys_245, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1958630276x749154843(a[0], a[1]);
}
Clo g_list_2edescending_24s2023694772x1287719119_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s2023694772x1287719119_entry, 5, 0};

V g_list_2edescending_24s2023694772x1287719119(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_242, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_245 = heff_field(v_x4_244, 0);
    V v_ys_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_a_247 = heff_strCompare(heff_get_n(v_x_242, 0, 2), heff_dup(heff_rfield(v_y_245, 0)));
    if ((heff_intLt_c_lent(v_a_247, v_lit_240, 0) || heff_intEq_c_lent(v_a_247, v_lit_241, 0))) {
      heff_drop(v_a_247);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_245, v_ys_246})});
    } else {
      heff_drop(v_a_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_245);
      V t_3 = heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_245, v_acc_243});
      V t_4 = v_ys_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2edescending_24s2023694772x1287719119_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2edescending_24s2023694772x1287719119(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s464681941x898021545_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s464681941x898021545_entry, 2, 0};

V g_list_2eany_24s464681941x898021545(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_start_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_end_245 = heff_dup(heff_rfield(v_x_242, 1));
    if ((heff_intLe_c_lent(v_start_244, v_lit_240, 0) && heff_intLe_c_lent(v_lit_240, v_end_245, 0))) {
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s464681941x898021545_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s464681941x898021545(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1026998256x1634433314_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1026998256x1634433314_entry, 2, 0};

V g_list_2efoldl_24s1026998256x1634433314(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1026998256x1634433314(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s302194196x751324068_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s302194196x751324068_entry, 2, 0};

V g_list_2efoldl_24s302194196x751324068(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s302194196x751324068(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s725725455x1186198702_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_24dps_entry, 2, 0};

V g_list_2emap_24s725725455x1186198702_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_x_242, heff_strLength_lent(v_x_242, 0)));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_242, MK_INT(0LL), v_t_244), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s725725455x1186198702_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s903588428x1469638784_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s903588428x1469638784_entry, 2, 0};

V g_list_2emap_24s903588428x1469638784(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_244 = heff_get_n(v_x_242, 2, 3);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(v_a_244, heff_strLength_lent(v_a_244, 0)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strSlice_lent(v_a_244, v_lit_240, v_t_245, 5), heff_hole()});
    V v_u_247 = (g_list_2emap_24s903588428x1469638784_24dps(v_lit_240, v_xs_243, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s903588428x1469638784_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s903588428x1469638784(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s1113395621x248103432_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_str3, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_str4, 0, "");
HEFF_LIT(g_list_2emap_24s1113395621x248103432_str5, 0, "");
Clo g_list_2emap_24s1113395621x248103432_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1113395621x248103432_entry, 1, 0};

V g_list_2emap_24s1113395621x248103432(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_JNull: {
      v_t_249 = ((V)&g_list_2emap_24s1113395621x248103432_str0);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1113395621x248103432_str1);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1113395621x248103432_str2);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1113395621x248103432_str3);
      break;
    }
    case TAG_JString: {
      V v_t_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_t_246;
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1113395621x248103432_str4);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_249 = ((V)&g_list_2emap_24s1113395621x248103432_str5);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1113395621x248103432_24dps(v_xs_242, v_cell_2410));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1113395621x248103432_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1113395621x248103432(a[0]);
}
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str0, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str1, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str2, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str3, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str4, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str5, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str6, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str7, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str8, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str9, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str10, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str11, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str12, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str13, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str14, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str15, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str16, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str17, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str18, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str19, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str20, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str21, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str22, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str23, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str24, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str25, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str26, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_str27, 0, "");
Clo g_list_2emap_24s2029356170x1054793697_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029356170x1054793697_entry, 1, 0};

V g_list_2emap_24s2029356170x1054793697(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = v_x_241;
    V v_t_2428;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_JNull: {
      v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_str0), ((V)&g_list_2emap_24s2029356170x1054793697_str1)});
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_str2), ((V)&g_list_2emap_24s2029356170x1054793697_str3)});
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_str4), ((V)&g_list_2emap_24s2029356170x1054793697_str5)});
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_str6), ((V)&g_list_2emap_24s2029356170x1054793697_str7)});
      break;
    }
    case TAG_JString: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_str8), ((V)&g_list_2emap_24s2029356170x1054793697_str9)});
      break;
    }
    case TAG_JArray: {
      V v_x11_248 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      switch (heff_tag_of(v_x11_248)) {
      case TAG_Nil: {
        v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_str10), ((V)&g_list_2emap_24s2029356170x1054793697_str11)});
        break;
      }
      case TAG_Cons: {
        V v_n_249 = heff_field(v_x11_248, 0);
        V v_x112_2410 = heff_field(v_x11_248, 1);
        V v_ru_24x11_248_24Cons = heff_take_reuse_n(v_x11_248, 3ULL, 2);
        switch (heff_tag_of(v_x112_2410)) {
        case TAG_Nil: {
          heff_drop(v_n_249);
          v_t_2428 = heff_tag_at_n(v_ru_24x11_248_24Cons, TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_str12), ((V)&g_list_2emap_24s2029356170x1054793697_str13)});
          break;
        }
        case TAG_Cons: {
          V v_t_2411 = heff_field(v_x112_2410, 0);
          heff_take_n(v_x112_2410, 1ULL, 2);
          V v_t_2419;
          switch (heff_tag_of(v_n_249)) {
          case TAG_JNull: {
            v_t_2419 = ((V)&g_list_2emap_24s2029356170x1054793697_str14);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_n_249, 0ULL, 1);
            v_t_2419 = ((V)&g_list_2emap_24s2029356170x1054793697_str15);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_n_249, 0ULL, 1);
            v_t_2419 = ((V)&g_list_2emap_24s2029356170x1054793697_str16);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_n_249, 0ULL, 1);
            v_t_2419 = ((V)&g_list_2emap_24s2029356170x1054793697_str17);
            break;
          }
          case TAG_JString: {
            V v_t_2416 = heff_field(v_n_249, 0);
            heff_take_n(v_n_249, 1ULL, 1);
            v_t_2419 = v_t_2416;
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_n_249, 0ULL, 1);
            v_t_2419 = ((V)&g_list_2emap_24s2029356170x1054793697_str18);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_n_249, 0ULL, 1);
            v_t_2419 = ((V)&g_list_2emap_24s2029356170x1054793697_str19);
            break;
          }
          default: heff_nomatch(v_n_249);
          }
          V v_t_2426;
          switch (heff_tag_of(v_t_2411)) {
          case TAG_JNull: {
            v_t_2426 = ((V)&g_list_2emap_24s2029356170x1054793697_str20);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2411, 0ULL, 1);
            v_t_2426 = ((V)&g_list_2emap_24s2029356170x1054793697_str21);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2411, 0ULL, 1);
            v_t_2426 = ((V)&g_list_2emap_24s2029356170x1054793697_str22);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2411, 0ULL, 1);
            v_t_2426 = ((V)&g_list_2emap_24s2029356170x1054793697_str23);
            break;
          }
          case TAG_JString: {
            V v_t_2423 = heff_field(v_t_2411, 0);
            heff_take_n(v_t_2411, 1ULL, 1);
            v_t_2426 = v_t_2423;
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2411, 0ULL, 1);
            v_t_2426 = ((V)&g_list_2emap_24s2029356170x1054793697_str24);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2411, 0ULL, 1);
            v_t_2426 = ((V)&g_list_2emap_24s2029356170x1054793697_str25);
            break;
          }
          default: heff_nomatch(v_t_2411);
          }
          v_t_2428 = heff_tag_at_n(v_ru_24x11_248_24Cons, TAG_MkPair, 2, (V[]){v_t_2419, v_t_2426});
          break;
        }
        default: heff_nomatch(v_x112_2410);
        }
        break;
      }
      default: heff_nomatch(v_x11_248);
      }
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_str26), ((V)&g_list_2emap_24s2029356170x1054793697_str27)});
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    V v_cell_2429 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2428, heff_hole()});
    V v_u_2430 = (g_list_2emap_24s2029356170x1054793697_24dps(v_xs_242, v_cell_2429));
    heff_drop(v_u_2430);
    return v_cell_2429;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029356170x1054793697_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029356170x1054793697(a[0]);
}
Clo g_list_2ekeepIf_24s920421308x594300259_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s920421308x594300259_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s920421308x594300259_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_249 = heff_strSlice_lent(v_t_248, v_lit_240, heff_strLength_lent(v_lit_241, 0), 5);
    if (heff_strEq_c_lent(v_t_249, v_lit_241, 1)) {
      V v_cell_2410 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, heff_hole()});
      V v_u_2411 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_u_2411;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s920421308x594300259_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2ekeepIf_24s920421308x594300259_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2emap_24f189927396x2059034600_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f189927396x2059034600_entry, 1, 0};

V g_list_2emap_24f189927396x2059034600(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_loosest_243 = heff_take_field(v_x_241, 3);
    V v_id_244 = heff_get_n(v_x_241, 0, 5);
    V v_t_245 = v_loosest_243;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_id_244, heff_hole()});
      V v_u_247 = (g_list_2emap_24f189927396x2059034600_24dps(v_xs_242, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_id_244);
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f189927396x2059034600_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f189927396x2059034600(a[0]);
}
V g_list_2emap_24f8874541x1844987517_24dps_lam1(V self, V *args);
V g_list_2emap_24f8874541x1844987517_24dps_lam0(V self, V *args);
Clo g_list_2emap_24f8874541x1844987517_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f8874541x1844987517_24dps_entry, 3, 0};

V g_list_2emap_24f8874541x1844987517_24dps(V v_a_240, V v_b_241, V v_d_242) {
top: ;
  if (heff_intLt_c_lent(v_b_241, v_a_240, 0)) {
    heff_drop(v_a_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_clo_n(g_list_2emap_24f8874541x1844987517_24dps_lam0, 1, 1, (V[]){heff_dup(v_a_240)}), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = heff_intAdd(v_a_240, MK_INT(1LL));
    V t_1 = v_b_241;
    V t_2 = v_u_246;
    v_a_240 = t_0;
    v_b_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2emap_24f8874541x1844987517_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f8874541x1844987517_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_list_2emap_24f8874541x1844987517_24dps_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_drop(v_a_244);
  heff_clo_take(self, 1);
  return v_a_243;
}
V g_list_2emap_24f8874541x1844987517_24dps_lam0(V self, V *args) {
  V v_a_243 = args[0];
  V v_a_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_a_240}), NTAG(TAG_SpId), heff_clo_n(g_list_2emap_24f8874541x1844987517_24dps_lam1, 1, 1, (V[]){v_a_243}), NTAG(TAG_Nothing)));
}
Clo g_list_2emap_24f1457339348x592422294_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1457339348x592422294_entry, 3, 0};

V g_list_2emap_24f1457339348x592422294(V v_lit_240, V v_box_24a_241, V v_b_242) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
top: ;
  if ((heff_peek_word(v_b_242) < v_a_241)) {
    heff_drop(v_b_242);
    return NTAG(TAG_Nil);
  } else {
    V v_t_243 = heff_intShow(heff_strByteAt_lent(v_lit_240, heff_box_word(v_a_241), 2));
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = ({ V a_0 = v_lit_240; V a_1 = heff_box_word((v_a_241 + ((int64_t)1ULL))); V a_2 = v_b_242; V a_3 = v_cell_244; V r_ = (g_list_2emap_24f1457339348x592422294_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_b_242); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
}
V g_list_2emap_24f1457339348x592422294_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f1457339348x592422294(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f1749649202x1754028860_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1749649202x1754028860_entry, 2, 0};

V g_list_2emap_24f1749649202x1754028860(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_module_244 = heff_take_field(v_x_242, 1);
    V v_key_245 = heff_get_n(v_x_242, 0, 2);
    if (heff_strEq_c(v_module_244, heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_key_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f1749649202x1754028860_24dps(v_lit_240, v_xs_243, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_key_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1749649202x1754028860_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f1749649202x1754028860(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f565269645x1954016017_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f565269645x1954016017_entry, 1, 0};

V g_list_2emap_24f565269645x1954016017(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_binder_243 = heff_take_field(v_x_241, 0);
    V v_use_244 = heff_get_n(v_x_241, 1, 2);
    V v_t_245 = heff_take_field(v_binder_243, 2);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_rec_n(3, shape_name__field__use, (V[]){heff_take_field(v_binder_243, 0), heff_get_n(v_binder_243, 1, 3), v_use_244});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f565269645x1954016017_24dps(v_xs_242, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop_rec(v_binder_243, 3);
      heff_drop(v_use_244);
      heff_drop(v_t_245);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f565269645x1954016017_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f565269645x1954016017(a[0]);
}
Clo g_list_2emap_24f1141799624x1826918381_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1141799624x1826918381_entry, 3, 0};

V g_list_2emap_24f1141799624x1826918381(V v_lit_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_243, 0, 8));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f1141799624x1826918381_24dps(v_lit_240, v_p_241, v_xs_244, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1141799624x1826918381_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emap_24f1141799624x1826918381(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}