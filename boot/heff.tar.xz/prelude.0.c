// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EQ 8989
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_Expl 20488
#define TAG_ExplicitParam 63083
#define TAG_GT 9054
#define TAG_Impl 63555
#define TAG_ImplicitParam 51130
#define TAG_LT 9209
#define TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply0 1346
#define TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply1 1347
#define TAG_Lam1_24prelude_2etraverse_24s1310917876x950458632_24apply2 9167
#define TAG_Left 13886
#define TAG_MkArm 55352
#define TAG_MkTF 48839
#define TAG_OfRecords 55355
#define TAG_OfTags 60669
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SDecl 12991
#define TAG_SWarning 44190
#define TAG_TypeWord 10401
#define LBL_atom 9500184
#define LBL_body 9524841
#define LBL_bound 295286168
#define LBL_code 9554612
#define LBL_compare 1182341923
#define LBL_def 308863
#define LBL_e 319
#define LBL_end 310101
#define LBL_eq 10003
#define LBL_equal 298115918
#define LBL_field 298786068
#define LBL_fvs 311325
#define LBL_implicit 319715269
#define LBL_key 315609
#define LBL_l 326
#define LBL_labels 836724522
#define LBL_labs 9809229
#define LBL_lams 9809570
#define LBL_launch 837298910
#define LBL_le 10208
#define LBL_limit 304334805
#define LBL_lt 10223
#define LBL_msg 317947
#define LBL_n 328
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_numbered 1006183371
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_r 332
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_slots 310891087
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_supply 1056026650
#define LBL_tag 324116
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_typ 324869
#define LBL_x 338
static uint32_t shape_bound__atom[] = {LBL_bound, LBL_atom};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_def__slots[] = {LBL_def, LBL_slots};
static uint32_t shape_eq__compare__lt__le[] = {LBL_eq, LBL_compare, LBL_lt, LBL_le};
static uint32_t shape_equal[] = {LBL_equal};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_r__x[] = {LBL_r, LBL_x};
static uint32_t shape_span__name__typ__implicit[] = {LBL_span, LBL_name, LBL_typ, LBL_implicit};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tag__fvs[] = {LBL_tag, LBL_fvs};
V g_heff_2ebuild_2edriver_2elineStart(V, V);
V g_heff_2ebuild_2edriver_2elineStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elineStart_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo(V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo;
V g_heff_2ecompile_2edefun_2erw(V, V);
V g_heff_2ecompile_2edefun_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2erw_clo;
V g_heff_2ecompile_2efields_2ereadsAt(V, V, V);
V g_heff_2ecompile_2efields_2ereadsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadsAt_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo;
V g_heff_2ecompile_2elift_2efreeGo(V, V, V);
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2efreeGo_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_clo;
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_heff_2ecompile_2escalars_2edefWith(V, V, V);
V g_heff_2ecompile_2escalars_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2edefWith_clo;
V g_heff_2ecompile_2escalars_2efoundWith(V, V, V);
V g_heff_2ecompile_2escalars_2efoundWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2efoundWith_clo;
V g_heff_2ecompile_2escalars_2eslotsOf(V, V);
V g_heff_2ecompile_2escalars_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotsOf_clo;
V g_heff_2ecompile_2escalars_2ewithVars(V);
V g_heff_2ecompile_2escalars_2ewithVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewithVars_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopyTake_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(V, V);
V g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
V g_heff_2ecompile_2etrmc_2edefT(V);
V g_heff_2ecompile_2etrmc_2edefT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edefT_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo;
HeffT2 g_heff_2esyntax_2esurface_2edefaultL_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryFieldOne_24s1473805472x1314815828_24cpr(V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap_24s146946949x1862800301(V);
V g_list_2emap_24s146946949x1862800301_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24dps(V, V, V);
V g_prelude_2e_2b_2b_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24dps_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_clo;
V g_prelude_2e_2b_2b_24f132290754x1091834184_24dps(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_clo;
V g_prelude_2e_2b_2b_24f1583460153x999201201(V, V, V, V);
V g_prelude_2e_2b_2b_24f1583460153x999201201_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1583460153x999201201_clo;
V g_prelude_2e_2b_2b_24f1583460153x999201201_24dps(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1583460153x999201201_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1583460153x999201201_24dps_clo;
V g_prelude_2e_2b_2b_24f1589519835x26889547(V, V, V, V);
V g_prelude_2e_2b_2b_24f1589519835x26889547_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1589519835x26889547_clo;
V g_prelude_2e_2b_2b_24f1589519835x26889547_24dps(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_clo;
V g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps(V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps_clo;
V g_prelude_2e_2b_2b_24f1960751014x547354513_24dps(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670(V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo;
V g_prelude_2e_2b_2b_24f339900781x1605227681_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f339900781x1605227681_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f339900781x1605227681_24dps_clo;
V g_prelude_2e_2b_2b_24f354580856x2119298159(V, V, V, V);
V g_prelude_2e_2b_2b_24f354580856x2119298159_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f354580856x2119298159_clo;
V g_prelude_2e_2b_2b_24f354580856x2119298159_24dps(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ecompareString(V, V);
V g_prelude_2ecompareString_entry(V self, V *a);
extern Clo g_prelude_2ecompareString_clo;
V g_prelude_2einstanceEqualityString_get(void);
V g_prelude_2einstanceOrderPair_24s369861572x2077527721_get(void);
V g_prelude_2einstanceOrderPair_24s566030815x71064266_get(void);
V g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285(V, V, V);
V g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285_clo;
V g_prelude_2emaybe(V, V, V);
V g_prelude_2emaybe_entry(V self, V *a);
extern Clo g_prelude_2emaybe_clo;
V g_prelude_2eorderByCompare_24s1329979559x1043691411_get(void);
HeffT2 g_prelude_2etraverse_24s1023157662x1060337521_24dps_24cpr(V, V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s1048254938x1609755296(V, V, V, V);
V g_prelude_2etraverse_24s1048254938x1609755296_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1048254938x1609755296_clo;
HeffT2 g_prelude_2etraverse_24s1048254938x1609755296_24cpr(V, V, V, V);
HeffT2 g_prelude_2etraverse_24s1096531376x1665190054_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1099455515x1225465224(V, V, V);
V g_prelude_2etraverse_24s1099455515x1225465224_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1099455515x1225465224_clo;
HeffT2 g_prelude_2etraverse_24s1144925704x1514729383_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s1159166259x948777116_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1159166259x948777116_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1169518895x2088283545(V);
V g_prelude_2etraverse_24s1169518895x2088283545_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1169518895x2088283545_clo;
HeffT2 g_prelude_2etraverse_24s119460564x671287541_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1218231813x1819446478(V, V);
V g_prelude_2etraverse_24s1218231813x1819446478_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1218231813x1819446478_clo;
V g_prelude_2etraverse_24s1232682027x654714928(V);
V g_prelude_2etraverse_24s1232682027x654714928_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1232682027x654714928_clo;
V g_prelude_2etraverse_24s1254646865x1442622806(V);
V g_prelude_2etraverse_24s1254646865x1442622806_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1254646865x1442622806_clo;
V g_prelude_2etraverse_24s1310917876x950458632(V, V);
V g_prelude_2etraverse_24s1310917876x950458632_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1310917876x950458632_clo;
V g_prelude_2etraverse_24s1310917876x950458632_24apply0(V, V);
V g_prelude_2etraverse_24s1310917876x950458632_24apply0_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1310917876x950458632_24apply0_clo;
V g_prelude_2etraverse_24s1310917876x950458632_24apply1(V, V);
V g_prelude_2etraverse_24s1310917876x950458632_24apply1_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1310917876x950458632_24apply1_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
HeffT2 g_prelude_2etraverse_24s1442653311x1678194035_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1442653311x1678194035_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s1462482035x919987020_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1587080482x1917521257(V, V);
V g_prelude_2etraverse_24s1587080482x1917521257_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1587080482x1917521257_clo;
HeffT2 g_prelude_2etraverse_24s1764298183x420715364_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s1764298183x420715364_24dps_24cpr(V, V, V, V);
HeffT2 g_prelude_2etraverse_24s1801023533x118610014_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1801023533x118610014_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s1882351740x242225671_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
V g_prelude_2etraverse_24s1963041714x1343204084(V, V, V);
V g_prelude_2etraverse_24s1963041714x1343204084_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1963041714x1343204084_clo;
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2(V, V, V, V);
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1963041714x1343204084_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s196770916x1113382074_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s196770916x1113382074_24dps_24cpr(V, V, V, V);
HeffT2 g_prelude_2etraverse_24s1989123107x1062793186_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s205209257x1087869143(V, V);
V g_prelude_2etraverse_24s205209257x1087869143_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s205209257x1087869143_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_prelude_2etraverse_24s352965232x546119438(V, V);
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s352965232x546119438_clo;
HeffT2 g_prelude_2etraverse_24s379292819x1163591097_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s379292819x1163591097_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s430827533x596660821(V, V, V, V);
V g_prelude_2etraverse_24s430827533x596660821_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s430827533x596660821_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_prelude_2etraverse_24s544736993x1914601267(V);
V g_prelude_2etraverse_24s544736993x1914601267_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s544736993x1914601267_clo;
V g_prelude_2etraverse_24s75890152x1871550235(V, V, V, V);
V g_prelude_2etraverse_24s75890152x1871550235_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s75890152x1871550235_clo;
HeffT2 g_prelude_2etraverse_24s956608878x365908798_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s962837131x1183228870_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s988656740x982054589(V, V);
V g_prelude_2etraverse_24s988656740x982054589_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s988656740x982054589_clo;
HeffT2 g_prelude_2etraverse_24s993801089x502291790_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s993801089x502291790_24dps_24cpr(V, V, V);
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
Clo g_prelude_2emaybe_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emaybe_entry, 3, 0};

V g_prelude_2emaybe(V v_d_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_f_241);
    return v_d_240;
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_x3_242, 0);
    heff_drop(v_d_240);
    return heff_tail(v_f_241, 1, (V[]){heff_dup(v_x_243)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_prelude_2emaybe_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2emaybe(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2e_2b_2b_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_prelude_2e_2b_2b_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_prelude_2eorderByCompare_24s1329979559x1043691411_lam0(V self, V *args); static Clo g_prelude_2eorderByCompare_24s1329979559x1043691411_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eorderByCompare_24s1329979559x1043691411_lam0, 2, 0};
V g_prelude_2eorderByCompare_24s1329979559x1043691411_lam1(V self, V *args); static Clo g_prelude_2eorderByCompare_24s1329979559x1043691411_lam1_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2eorderByCompare_24s1329979559x1043691411_lam1, 2, 0};

static V g_prelude_2eorderByCompare_24s1329979559x1043691411_val;
static HEFF_ONCE g_prelude_2eorderByCompare_24s1329979559x1043691411_st;
static V g_prelude_2eorderByCompare_24s1329979559x1043691411_init(void) {
  return heff_rec_n(4, shape_eq__compare__lt__le, (V[]){heff_dup(g_prelude_2einstanceEqualityString_get()), ((V)&g_prelude_2ecompareString_clo), ((V)&g_prelude_2eorderByCompare_24s1329979559x1043691411_lam0_clo), ((V)&g_prelude_2eorderByCompare_24s1329979559x1043691411_lam1_clo)});
}
V g_prelude_2eorderByCompare_24s1329979559x1043691411_get(void) {
  if (HEFF_DONE(g_prelude_2eorderByCompare_24s1329979559x1043691411_st)) return g_prelude_2eorderByCompare_24s1329979559x1043691411_val;
  return heff_global(&g_prelude_2eorderByCompare_24s1329979559x1043691411_val, &g_prelude_2eorderByCompare_24s1329979559x1043691411_st, g_prelude_2eorderByCompare_24s1329979559x1043691411_init);
}
V g_prelude_2eorderByCompare_24s1329979559x1043691411_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_y_241 = args[1];
  V v_a_242 = heff_strCompare(v_x_240, v_y_241);
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_242, MK_INT(0LL), 2) || (heff_intEq_c_lent(v_a_242, MK_INT(0LL), 2) && 0)));
  heff_drop(v_a_242);
  return v_ret_24bool;
}
V g_prelude_2eorderByCompare_24s1329979559x1043691411_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_y_244 = args[1];
  V v_a_245 = heff_strCompare(v_x_243, v_y_244);
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_245, MK_INT(0LL), 2) || heff_intEq_c_lent(v_a_245, MK_INT(0LL), 2)));
  heff_drop(v_a_245);
  return v_ret_24bool;
}
V g_prelude_2etraverse_24s1587080482x1917521257_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1587080482x1917521257_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1587080482x1917521257_lam0, 1, 0};
V g_prelude_2etraverse_24s1587080482x1917521257_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1587080482x1917521257_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1587080482x1917521257_entry, 2, 0};

V g_prelude_2etraverse_24s1587080482x1917521257(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1587080482x1917521257_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1587080482x1917521257_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1587080482x1917521257_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1587080482x1917521257(a[0], a[1]);
}
V g_prelude_2etraverse_24s1587080482x1917521257_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s1587080482x1917521257_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_prelude_2etraverse_24s1587080482x1917521257(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s430827533x596660821_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s430827533x596660821_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s430827533x596660821_lam0, 1, 0};
V g_prelude_2etraverse_24s430827533x596660821_lam1(V self, V *args);
V g_prelude_2etraverse_24s430827533x596660821_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s430827533x596660821_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s430827533x596660821_entry, 4, 0};

V g_prelude_2etraverse_24s430827533x596660821(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return ((V)&g_prelude_2etraverse_24s430827533x596660821_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_243, 0);
    V v_xs_247 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_r_248 = heff_dup(v_lit_240);
    V v_ty_249 = heff_dup(v_lit_241);
    V v_d_2410 = heff_dup(v_lit_242);
    V v_x_2411 = v_x_246;
    V v_text_2412 = heff_take_field(v_x_2411, 1);
    V v_start_2413 = heff_take_field(v_x_2411, 3);
    V v_end_2414 = heff_get_n(v_x_2411, 4, 9);
    V v_m_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_248, 0)), 1, (V[]){v_ty_249}));
    V v_m_2439 = heff_clo_n(g_prelude_2etraverse_24s430827533x596660821_lam1, 1, 6, (V[]){v_m_2415, v_r_248, v_d_2410, v_text_2412, v_start_2413, v_end_2414});
    return heff_clo_n(g_prelude_2etraverse_24s430827533x596660821_lam2, 1, 5, (V[]){v_m_2439, v_lit_240, v_lit_241, v_lit_242, v_xs_247});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2etraverse_24s430827533x596660821_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s430827533x596660821(a[0], a[1], a[2], a[3]);
}
V g_prelude_2etraverse_24s430827533x596660821_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_st_244});
}
V g_prelude_2etraverse_24s430827533x596660821_lam1(V self, V *args) {
  V v_st_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_r_248 = heff_env(self)[1];
  V v_d_2410 = heff_env(self)[2];
  V v_text_2412 = heff_env(self)[3];
  V v_start_2413 = heff_env(self)[4];
  V v_end_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_st_2416}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      heff_drop_rec(v_r_248, 3);
      heff_drop(v_d_2410);
      heff_drop(v_text_2412);
      heff_drop(v_start_2413);
      heff_drop(v_end_2414);
      return heff_tag_re_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      HeffT2 v_t_2422 = (g_heff_2esyntax_2esurface_2edefaultL_24cpr(v_r_248, v_d_2410, v_st_2419));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x11_2425 = v_field_2423;
        V v_st_2426 = v_field_2424;
        switch (heff_tag_of(v_x11_2425)) {
        case TAG_Left: {
          V v_e_2427 = heff_field(v_x11_2425, 0);
          V v_ru_24x11_2425_24Left = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
          heff_drop(v_text_2412);
          heff_drop(v_start_2413);
          heff_drop(v_end_2414);
          heff_drop(v_x_2421);
          heff_drop_cell(v_ru_24x11_2418_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2425_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2427}), v_st_2426});
        }
        case TAG_Right: {
          V v_x_2428 = heff_field(v_x11_2425, 0);
          heff_take_n(v_x11_2425, 1ULL, 1);
          V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_text_2412), heff_dup(heff_rfield(v_st_2426, 1))});
          V v_st_2430 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2429, v_st_2426));
          V v_t_2432;
          switch (heff_tag_of(v_x_2428)) {
          case TAG_Nothing: {
            v_t_2432 = heff_dup(v_x_2421);
            break;
          }
          case TAG_Just: {
            V v_x_2431 = heff_dup(heff_field(v_x_2428, 0));
            v_t_2432 = v_x_2431;
            break;
          }
          default: heff_nomatch(v_x_2428);
          }
          V v_t_2435;
          switch (heff_tag_of(v_t_2432)) {
          case TAG_At: {
            V v_s_2434 = heff_field(v_t_2432, 1);
            heff_take_n(v_t_2432, 2ULL, 2);
            v_t_2435 = v_s_2434;
            break;
          }
          default: heff_nomatch(v_t_2432);
          }
          V v_t_2436 = heff_tag_n(TAG_DeclareField, 4, (V[]){v_text_2412, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_2413), v_end_2414}), v_x_2421, v_x_2428});
          V v_t_2437 = ({ V rv_0 = v_start_2413; V rr_ = heff_rec_reuse_nf(v_t_2435, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2438 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_t_2437})});
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2438, v_st_2430});
        }
        default: return heff_nomatch(v_x11_2425);
        }
      }
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_prelude_2etraverse_24s430827533x596660821_lam2(V self, V *args) {
  V v_st_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_xs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2440}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_MkPair: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_st_2443 = heff_field(v_x1_2441, 1);
    V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_Left: {
      V v_e_2444 = heff_field(v_x11_2442, 0);
      V v_ru_24x11_2442_24Left = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_xs_247);
      return heff_tag_re_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2442_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2444}), v_st_2443});
    }
    case TAG_Right: {
      V v_x_2445 = heff_field(v_x11_2442, 0);
      V v_ru_24x11_2442_24Right = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
      V v_t_2446 = (g_prelude_2etraverse_24s430827533x596660821(v_lit_240, v_lit_241, v_lit_242, v_xs_247));
      V v_x1_2447 = heff_tr(heff_call(v_t_2446, 1, (V[]){v_st_2443}));
      switch (heff_tag_of(v_x1_2447)) {
      case TAG_MkPair: {
        V v_x11_2448 = heff_field(v_x1_2447, 0);
        V v_st_2449 = heff_field(v_x1_2447, 1);
        V v_ru_24x1_2447_24MkPair = heff_take_reuse_n(v_x1_2447, 3ULL, 2);
        switch (heff_tag_of(v_x11_2448)) {
        case TAG_Left: {
          V v_e_2450 = heff_field(v_x11_2448, 0);
          V v_ru_24x11_2448_24Left = heff_take_reuse_n(v_x11_2448, 1ULL, 1);
          heff_drop(v_x_2445);
          heff_drop_cell(v_ru_24x11_2442_24Right, 1);
          heff_drop_cell(v_ru_24x1_2447_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2448_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2450}), v_st_2449});
        }
        case TAG_Right: {
          V v_x_2451 = heff_field(v_x11_2448, 0);
          heff_take_n(v_x11_2448, 1ULL, 1);
          V v_t_2452 = heff_tag_at_n(v_ru_24x11_2442_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2447_24MkPair, TAG_Cons, 2, (V[]){v_x_2445, v_x_2451})});
          return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){v_t_2452, v_st_2449});
        }
        default: return heff_nomatch(v_x11_2448);
        }
      }
      default: return heff_nomatch(v_x1_2447);
      }
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_prelude_2etraverse_24s518454301x170091462_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s518454301x170091462_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s518454301x170091462_lam0, 1, 0};
V g_prelude_2etraverse_24s518454301x170091462_lam1(V self, V *args);
V g_prelude_2etraverse_24s518454301x170091462_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s518454301x170091462_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s518454301x170091462_entry, 1, 0};

V g_prelude_2etraverse_24s518454301x170091462(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s518454301x170091462_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_e_245 = v_x_243;
    HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2eatomOf_24cpr(v_e_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_m_2418;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_e_245);
        V v_x_249 = v_field_248;
        V v_text_2410 = heff_take_field(v_x_249, 1);
        V v_start_2411 = heff_take_field(v_x_249, 3);
        V v_end_2412 = heff_get_n(v_x_249, 4, 9);
        v_m_2418 = heff_clo_n(g_prelude_2etraverse_24s518454301x170091462_lam1, 1, 3, (V[]){v_start_2411, v_end_2412, v_text_2410});
      } else {
        heff_drop(v_field_248);
        v_m_2418 = heff_tr(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(v_e_245));
      }
      return heff_clo_n(g_prelude_2etraverse_24s518454301x170091462_lam2, 1, 2, (V[]){v_m_2418, v_xs_244});
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s518454301x170091462(a[0]);
}
V g_prelude_2etraverse_24s518454301x170091462_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_prelude_2etraverse_24s518454301x170091462_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_start_2411 = heff_env(self)[0];
  V v_end_2412 = heff_env(self)[1];
  V v_text_2410 = heff_env(self)[2];
  V v_t_2414 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_2411), heff_dup(v_end_2412)})});
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_text_2410, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_2411), heff_dup(v_end_2412)}), v_t_2415});
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_rec_n(2, shape_start__end, (V[]){v_start_2411, v_end_2412})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2417}), v_st_2413});
}
V g_prelude_2etraverse_24s518454301x170091462_lam2(V self, V *args) {
  V v_st_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_st_2419}));
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_MkPair: {
    V v_x11_2421 = heff_field(v_x1_2420, 0);
    V v_st_2422 = heff_field(v_x1_2420, 1);
    V v_ru_24x1_2420_24MkPair = heff_take_reuse_n(v_x1_2420, 3ULL, 2);
    switch (heff_tag_of(v_x11_2421)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x11_2421, 0);
      V v_ru_24x11_2421_24Left = heff_take_reuse_n(v_x11_2421, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_re_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2423}), v_st_2422});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x11_2421, 0);
      V v_ru_24x11_2421_24Right = heff_take_reuse_n(v_x11_2421, 1ULL, 1);
      V v_t_2425 = (g_prelude_2etraverse_24s518454301x170091462(v_xs_244));
      V v_x1_2426 = heff_tr(heff_call(v_t_2425, 1, (V[]){v_st_2422}));
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_MkPair: {
        V v_x11_2427 = heff_field(v_x1_2426, 0);
        V v_st_2428 = heff_field(v_x1_2426, 1);
        V v_ru_24x1_2426_24MkPair = heff_take_reuse_n(v_x1_2426, 3ULL, 2);
        switch (heff_tag_of(v_x11_2427)) {
        case TAG_Left: {
          V v_e_2429 = heff_field(v_x11_2427, 0);
          V v_ru_24x11_2427_24Left = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
          heff_drop(v_x_2424);
          heff_drop_cell(v_ru_24x11_2421_24Right, 1);
          heff_drop_cell(v_ru_24x1_2426_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2427_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2429}), v_st_2428});
        }
        case TAG_Right: {
          V v_x_2430 = heff_field(v_x11_2427, 0);
          heff_take_n(v_x11_2427, 1ULL, 1);
          V v_t_2431 = heff_tag_at_n(v_ru_24x11_2421_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_Cons, 2, (V[]){v_x_2424, v_x_2430})});
          return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2428});
        }
        default: return heff_nomatch(v_x11_2427);
        }
      }
      default: return heff_nomatch(v_x1_2426);
      }
    }
    default: return heff_nomatch(v_x11_2421);
    }
  }
  default: return heff_nomatch(v_x1_2420);
  }
}

HeffT2 g_prelude_2etraverse_24s1048254938x1609755296_24cpr(V v_lit_240, V v_lit_241, V v_x2_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    V v_t_244 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_244, v_p_243}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_242, 0);
    V v_xs_246 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2etheoryFieldOne_24s1473805472x1314815828_24cpr(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_245, v_p_243));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x11_2410 = v_field_248;
      V v_st_2411 = v_field_249;
      switch (heff_tag_of(v_x11_2410)) {
      case TAG_Left: {
        V v_e_2412 = heff_field(v_x11_2410, 0);
        V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
        heff_drop(v_xs_246);
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2410_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2412}), v_st_2411}});
      }
      case TAG_Right: {
        V v_x_2413 = heff_field(v_x11_2410, 0);
        V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
        HeffT2 v_t_2414 = (g_prelude_2etraverse_24s1048254938x1609755296_24cpr(v_lit_240, v_lit_241, v_xs_246, v_st_2411));
        {
          V v_field_2415 = v_t_2414.f[0];
          V v_field_2416 = v_t_2414.f[1];
          V v_x11_2417 = v_field_2415;
          V v_st_2418 = v_field_2416;
          switch (heff_tag_of(v_x11_2417)) {
          case TAG_Left: {
            V v_e_2419 = heff_field(v_x11_2417, 0);
            V v_ru_24x11_2417_24Left = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_242_24Cons, 2);
            heff_drop(v_x_2413);
            heff_drop_cell(v_ru_24x11_2410_24Right, 1);
            return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2419}), v_st_2418}});
          }
          case TAG_Right: {
            V v_x_2420 = heff_field(v_x11_2417, 0);
            heff_take_n(v_x11_2417, 1ULL, 1);
            V v_t_2421 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_2413, v_x_2420})});
            return ((HeffT2){{v_t_2421, v_st_2418}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x11_2417)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2410)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_242)}});
  }
}
V g_prelude_2etraverse_24s956608878x365908798_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s956608878x365908798_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_242, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_2416;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_248 = heff_field(v_x_243, 3);
      V v_a_249 = heff_field(v_x_243, 4);
      heff_take_n(v_x_243, 25ULL, 5);
      V v_t_2410 = (g_list_2emap_24s146946949x1862800301(heff_dup(v_a_245)));
      HeffT2 v_t_2411 = (g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(NTAG(TAG_Nil), v_t_2410));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop(v_a_245);
          heff_drop(v_a_248);
          heff_drop(v_a_249);
          V v_a_2414 = v_field_2413;
          v_m_2416 = heff_clo_n(g_prelude_2etraverse_24s956608878x365908798_24cpr_lam0, 1, 1, (V[]){v_a_2414});
        } else {
          heff_drop(v_field_2413);
          v_m_2416 = heff_tr(heff_call(((V)&g_prelude_2etraverse_24s1048254938x1609755296_clo), 3, (V[]){v_a_248, v_a_249, v_a_245}));
        }
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_MkPair: {
      V v_x11_2418 = heff_field(v_x1_2417, 0);
      V v_st_2419 = heff_field(v_x1_2417, 1);
      heff_take_n(v_x1_2417, 3ULL, 2);
      switch (heff_tag_of(v_x11_2418)) {
      case TAG_Left: {
        V v_e_2420 = heff_field(v_x11_2418, 0);
        V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
        heff_drop(v_xs_244);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2420}), v_st_2419}});
      }
      case TAG_Right: {
        V v_x_2421 = heff_field(v_x11_2418, 0);
        V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
        HeffT2 v_t_2422 = (g_prelude_2etraverse_24s956608878x365908798_24cpr(v_xs_244, v_st_2419));
        {
          V v_field_2423 = v_t_2422.f[0];
          V v_field_2424 = v_t_2422.f[1];
          V v_x11_2425 = v_field_2423;
          V v_st_2426 = v_field_2424;
          switch (heff_tag_of(v_x11_2425)) {
          case TAG_Left: {
            V v_e_2427 = heff_field(v_x11_2425, 0);
            V v_ru_24x11_2425_24Left = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_x_2421);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2425_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2427}), v_st_2426}});
          }
          case TAG_Right: {
            V v_x_2428 = heff_field(v_x11_2425, 0);
            heff_take_n(v_x11_2425, 1ULL, 1);
            V v_t_2429 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2421, v_x_2428})});
            return ((HeffT2){{v_t_2429, v_st_2426}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x11_2425)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2418)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2417)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s956608878x365908798_24cpr_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_a_2414}), v_a_2415});
}

HeffT2 g_prelude_2etraverse_24s1159166259x948777116_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_x_242, v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_st_248 = v_field_246;
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
      HeffT2 v_t_2410 = (g_prelude_2etraverse_24s1159166259x948777116_24dps_24cpr(v_xs_243, v_st_248, v_cell_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v__5f_2413 = v_field_2411;
        heff_drop(v__5f_2413);
        V v_st_2414 = v_field_2412;
        return ((HeffT2){{v_cell_249, v_st_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s119460564x671287541_24dps_24cpr(V v_x2_240, V v_p_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_p_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24MkPair = heff_take_reuse_n(v_x_245, 3ULL, 2);
      HeffT2 v_t_249 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_248, v_p_241));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_a_2412 = v_field_2410;
        V v_a_2413 = v_field_2411;
        V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x_245_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_a_247, v_a_2412}), heff_hole()});
        V v_u_2415 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2414);
        V t_0 = v_xs_246;
        V t_1 = v_a_2413;
        V t_2 = v_u_2415;
        v_x2_240 = t_0;
        v_p_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s2064368144x1684679122_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2064368144x1684679122_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2064368144x1684679122_lam0, 1, 0};
V g_prelude_2etraverse_24s2064368144x1684679122_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s2064368144x1684679122_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2064368144x1684679122_entry, 2, 0};

V g_prelude_2etraverse_24s2064368144x1684679122(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s2064368144x1684679122_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s2064368144x1684679122_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2064368144x1684679122(a[0], a[1]);
}
V g_prelude_2etraverse_24s2064368144x1684679122_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s2064368144x1684679122_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_prelude_2etraverse_24s2064368144x1684679122(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s1218231813x1819446478_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1218231813x1819446478_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1218231813x1819446478_lam0, 1, 0};
V g_prelude_2etraverse_24s1218231813x1819446478_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1218231813x1819446478_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1218231813x1819446478_entry, 2, 0};

V g_prelude_2etraverse_24s1218231813x1819446478(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1218231813x1819446478_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1218231813x1819446478_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1218231813x1819446478_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1218231813x1819446478(a[0], a[1]);
}
V g_prelude_2etraverse_24s1218231813x1819446478_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s1218231813x1819446478_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_prelude_2etraverse_24s1218231813x1819446478(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s1989123107x1062793186_24dps_24cpr(V v_x2_240, V v_p_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_p_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_x_245)) {
    case TAG_EVar: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_t_2446);
      V v_cell_2447 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
      V v_u_2448 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2447);
      V t_0 = v_xs_246;
      V t_1 = v_p_241;
      V t_2 = v_u_2448;
      v_x2_240 = t_0;
      v_p_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2446);
      V v_t_2449 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_p_241, 0)), v_x_245));
      HeffT2 v_t_2450 = ({ V a_0 = v_p_241; V a_1 = v_t_2449; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2ecopyTake_24cpr(a_0, a_1)); heff_drop(v_t_2449); r_; });
      {
        V v_field_2451 = v_t_2450.f[0];
        V v_field_2452 = v_t_2450.f[1];
        V v_x_2453 = v_field_2451;
        V v_s_2454 = v_field_2452;
        V v_cell_2455 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2453, heff_hole()});
        V v_u_2456 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2455);
        V t_0 = v_xs_246;
        V t_1 = v_s_2454;
        V t_2 = v_u_2456;
        v_x2_240 = t_0;
        v_p_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s962837131x1183228870_24dps_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s962837131x1183228870_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_2415;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkArm: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_a_249 = heff_field(v_x_245, 2);
      heff_take_n(v_x_245, 7ULL, 3);
      V v_a_2410 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_a_249));
      v_m_2415 = heff_clo_n(g_prelude_2etraverse_24s962837131x1183228870_24dps_24cpr_lam0, 1, 3, (V[]){v_a_2410, v_a_247, v_a_248});
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_s_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2420 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2419);
      V t_0 = v_xs_246;
      V t_1 = v_s_2418;
      V t_2 = v_u_2420;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2416)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s962837131x1183228870_24dps_24cpr_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2412 = heff_tr(heff_call(v_a_2410, 1, (V[]){v_a_2411}));
  switch (heff_tag_of(v_a_2412)) {
  case TAG_MkPair: {
    V v_a_2413 = heff_field(v_a_2412, 0);
    V v_a_2414 = heff_field(v_a_2412, 1);
    V v_ru_24a_2412_24MkPair = heff_take_reuse_n(v_a_2412, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_247, v_a_248, v_a_2413}), v_a_2414});
  }
  default: return heff_nomatch(v_a_2412);
  }
}

HeffT2 g_prelude_2etraverse_24s196770916x1113382074_24cpr(V v_lit_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_242}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_arms_245 = heff_dup(v_lit_240);
    V v_x3_246 = v_x_243;
    V v_p_247 = v_p_242;
    V v_x2_2467;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_MkArm: {
      V v_t_248 = heff_field(v_x3_246, 0);
      V v_vs_249 = heff_field(v_x3_246, 1);
      V v_b_2410 = heff_field(v_x3_246, 2);
      V v_ru_24x3_246_24MkArm = heff_take_reuse_n(v_x3_246, 7ULL, 3);
      HeffT2 v_t_2411 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_p_247, 0)), v_arms_245));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_arms_27_2414 = v_field_2412;
        V v_n2_2415 = v_field_2413;
        V v_t_2416 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_27_2414});
        V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_n2_2415});
        HeffT2 v_t_2418 = ({ V a_0 = v_p_247; V a_1 = v_t_2417; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2ecopyTake_24cpr(a_0, a_1)); heff_drop_tag(v_t_2417, 2); r_; });
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_x_2421 = v_field_2419;
          V v_s_2422 = v_field_2420;
          V v_t_2462;
          switch (heff_tag_of(v_x_2421)) {
          case TAG_EVar: {
            heff_take_n(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EGlobal: {
            heff_take_n(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ELam: {
            heff_take_n(v_x_2421, 0ULL, 2);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_x_2421, 0ULL, 2);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_x_2421, 0ULL, 3);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_x_2421, 0ULL, 2);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_x_2421, 0ULL, 4);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ETag: {
            heff_take_n(v_x_2421, 0ULL, 3);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EMatch: {
            V v_arms_2442 = heff_field(v_x_2421, 1);
            heff_take_n(v_x_2421, 2ULL, 2);
            v_t_2462 = v_arms_2442;
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_x_2421, 0ULL, 2);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_x_2421, 0ULL, 2);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_x_2421, 0ULL, 2);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EAbandon: {
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_x_2421, 0ULL, 3);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_x_2421, 0ULL, 1);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_x_2421, 0ULL, 2);
            v_t_2462 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_x_2421);
          }
          V v_t_2463 = (g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(v_b_2410, v_t_2462));
          V v_x2_2464 = heff_tr(heff_call(v_t_2463, 1, (V[]){v_s_2422}));
          switch (heff_tag_of(v_x2_2464)) {
          case TAG_MkPair: {
            V v_x_2465 = heff_field(v_x2_2464, 0);
            V v_s_2466 = heff_field(v_x2_2464, 1);
            V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
            v_x2_2467 = heff_tag_re_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x3_246_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_248, v_vs_249, v_x_2465}), v_s_2466});
            break;
          }
          default: heff_nomatch(v_x2_2464);
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    switch (heff_tag_of(v_x2_2467)) {
    case TAG_MkPair: {
      V v_x_2468 = heff_field(v_x2_2467, 0);
      V v_s_2469 = heff_field(v_x2_2467, 1);
      heff_take_n(v_x2_2467, 3ULL, 2);
      V v_cell_2470 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_2468, heff_hole()});
      HeffT2 v_t_2471 = ({ V a_0 = v_lit_240; V a_1 = v_xs_244; V a_2 = v_s_2469; V a_3 = v_cell_2470; HeffT2 r_ = (g_prelude_2etraverse_24s196770916x1113382074_24dps_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); r_; });
      {
        V v_field_2472 = v_t_2471.f[0];
        V v_field_2473 = v_t_2471.f[1];
        V v__5f_2474 = v_field_2472;
        heff_drop(v__5f_2474);
        V v_s_2475 = v_field_2473;
        return ((HeffT2){{v_cell_2470, v_s_2475}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2467)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_prelude_2etraverse_24s196770916x1113382074_24dps_24cpr(V v_lit_240, V v_x2_241, V v_p_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_u_244 = heff_setFieldPeek(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_245 = heff_hole();
    return ((HeffT2){{v_f_245, v_p_242}});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_241, 0);
    V v_xs_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_arms_248 = heff_dup(v_lit_240);
    V v_x3_249 = v_x_246;
    V v_p_2410 = v_p_242;
    V v_x2_2470;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_MkArm: {
      V v_t_2411 = heff_field(v_x3_249, 0);
      V v_vs_2412 = heff_field(v_x3_249, 1);
      V v_b_2413 = heff_field(v_x3_249, 2);
      V v_ru_24x3_249_24MkArm = heff_take_reuse_n(v_x3_249, 7ULL, 3);
      HeffT2 v_t_2414 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_p_2410, 0)), v_arms_248));
      {
        V v_field_2415 = v_t_2414.f[0];
        V v_field_2416 = v_t_2414.f[1];
        V v_arms_27_2417 = v_field_2415;
        V v_n2_2418 = v_field_2416;
        V v_t_2419 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_27_2417});
        V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_n2_2418});
        HeffT2 v_t_2421 = ({ V a_0 = v_p_2410; V a_1 = v_t_2420; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2ecopyTake_24cpr(a_0, a_1)); heff_drop_tag(v_t_2420, 2); r_; });
        {
          V v_field_2422 = v_t_2421.f[0];
          V v_field_2423 = v_t_2421.f[1];
          V v_x_2424 = v_field_2422;
          V v_s_2425 = v_field_2423;
          V v_t_2465;
          switch (heff_tag_of(v_x_2424)) {
          case TAG_EVar: {
            heff_take_n(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EGlobal: {
            heff_take_n(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ELam: {
            heff_take_n(v_x_2424, 0ULL, 2);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EApp: {
            heff_take_n(v_x_2424, 0ULL, 2);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_x_2424, 0ULL, 3);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ERecord: {
            heff_take_n(v_x_2424, 0ULL, 2);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EProj: {
            heff_take_n(v_x_2424, 0ULL, 4);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ETag: {
            heff_take_n(v_x_2424, 0ULL, 3);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EMatch: {
            V v_arms_2445 = heff_field(v_x_2424, 1);
            heff_take_n(v_x_2424, 2ULL, 2);
            v_t_2465 = v_arms_2445;
            break;
          }
          case TAG_EPrim: {
            heff_take_n(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_x_2424, 0ULL, 2);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ECall: {
            heff_take_n(v_x_2424, 0ULL, 2);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EInt: {
            heff_take_n(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EFloat: {
            heff_take_nf(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EStr: {
            heff_take_n(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EBytes: {
            heff_take_n(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EFixed: {
            heff_take_n(v_x_2424, 0ULL, 2);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EFloat32: {
            heff_take_na(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EAbandon: {
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EBool: {
            heff_take_n(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_ESet: {
            heff_take_n(v_x_2424, 0ULL, 3);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EValues: {
            heff_take_n(v_x_2424, 0ULL, 1);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_EFix: {
            heff_take_n(v_x_2424, 0ULL, 2);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_x_2424);
          }
          V v_t_2466 = (g_heff_2ecompile_2esimplify_2ematchF_24s731377139x488377637(v_b_2413, v_t_2465));
          V v_x2_2467 = heff_tr(heff_call(v_t_2466, 1, (V[]){v_s_2425}));
          switch (heff_tag_of(v_x2_2467)) {
          case TAG_MkPair: {
            V v_x_2468 = heff_field(v_x2_2467, 0);
            V v_s_2469 = heff_field(v_x2_2467, 1);
            V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
            v_x2_2470 = heff_tag_re_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x3_249_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2411, v_vs_2412, v_x_2468}), v_s_2469});
            break;
          }
          default: heff_nomatch(v_x2_2467);
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_MkPair: {
      V v_x_2471 = heff_field(v_x2_2470, 0);
      V v_s_2472 = heff_field(v_x2_2470, 1);
      heff_take_n(v_x2_2470, 3ULL, 2);
      V v_cell_2473 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_2471, heff_hole()});
      V v_u_2474 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2473);
      V t_0 = v_lit_240;
      V t_1 = v_xs_247;
      V t_2 = v_s_2472;
      V t_3 = v_u_2474;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_p_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2470)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_prelude_2etraverse_24s1144925704x1514729383_24dps_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s1144925704x1514729383_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_2415;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkArm: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_a_249 = heff_field(v_x_245, 2);
      heff_take_n(v_x_245, 7ULL, 3);
      V v_a_2410 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_a_249));
      v_m_2415 = heff_clo_n(g_prelude_2etraverse_24s1144925704x1514729383_24dps_24cpr_lam0, 1, 3, (V[]){v_a_2410, v_a_247, v_a_248});
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_s_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2420 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2419);
      V t_0 = v_xs_246;
      V t_1 = v_s_2418;
      V t_2 = v_u_2420;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2416)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1144925704x1514729383_24dps_24cpr_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2412 = heff_tr(heff_call(v_a_2410, 1, (V[]){v_a_2411}));
  switch (heff_tag_of(v_a_2412)) {
  case TAG_MkPair: {
    V v_a_2413 = heff_field(v_a_2412, 0);
    V v_a_2414 = heff_field(v_a_2412, 1);
    V v_ru_24a_2412_24MkPair = heff_take_reuse_n(v_a_2412, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_247, v_a_248, v_a_2413}), v_a_2414});
  }
  default: return heff_nomatch(v_a_2412);
  }
}
V g_prelude_2etraverse_24s988656740x982054589_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s988656740x982054589_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s988656740x982054589_lam0, 1, 0};
V g_prelude_2etraverse_24s988656740x982054589_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s988656740x982054589_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s988656740x982054589_entry, 2, 0};

V g_prelude_2etraverse_24s988656740x982054589(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s988656740x982054589_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s988656740x982054589_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s988656740x982054589_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s988656740x982054589(a[0], a[1]);
}
V g_prelude_2etraverse_24s988656740x982054589_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_acc_242});
}
V g_prelude_2etraverse_24s988656740x982054589_lam1(V self, V *args) {
  V v_acc_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_acc_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_acc_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_prelude_2etraverse_24s988656740x982054589(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_acc_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_acc_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_acc_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s1023157662x1060337521_24dps_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_p_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    V v_u_249 = heff_setFieldPeek(v_d_248, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_2410 = heff_hole();
    return ((HeffT2){{v_f_2410, v_p_247}});
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_246, 0);
    V v_xs_2412 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2413;
    if (((heff_dup(heff_rfield(v_lit_240, 1)) == NTAG(TAG_True)) && heff_intEq_c_lent(v_x_2411, v_lit_241, 0))) {
      heff_drop(v_x_2411);
      v_t_2413 = heff_dup(v_lit_242);
    } else {
      heff_drop(v_x_2411);
      v_t_2413 = heff_dup(v_lit_243);
    }
    V v_x_2414 = heff_strAppend(heff_strAppend(v_t_2413, heff_dup(v_lit_244)), heff_intShow(heff_dup(v_p_247)));
    V v_n_2415 = heff_intAdd_lent(v_p_247, v_lit_245, 1);
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_x_2414, heff_hole()});
    V v_u_2417 = heff_setFieldPeek(v_d_248, MK_INT(1LL), v_cell_2416);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_2412;
    V t_7 = v_n_2415;
    V t_8 = v_u_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_p_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1764298183x420715364_24cpr_str0, 2, "k$");
HEFF_LIT(g_prelude_2etraverse_24s1764298183x420715364_24cpr_str1, 1, "$");
V g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam1(V self, V *args);
V g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam2(V self, V *args); static Clo g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam2_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam2, 1, 0};
V g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam3(V self, V *args); static Clo g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam3_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam3, 1, 0};
V g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s1764298183x420715364_24cpr(V v_lit_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_p_242}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_p_245 = heff_dup(v_lit_240);
    V v_a_246 = v_x_243;
    V v_n_247 = heff_take_field(v_a_246, 1);
    V v_labels_248 = heff_take_field(v_a_246, 2);
    V v_key_249 = heff_get_n(v_a_246, 0, 3);
    V v_n_2410 = v_p_242;
    V v_x_2411 = heff_strAppend(((V)&g_prelude_2etraverse_24s1764298183x420715364_24cpr_str0), heff_intShow(heff_dup(v_n_2410)));
    HeffT2 v_t_2412 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_n_247, heff_intAdd(v_n_2410, MK_INT(1LL))));
    {
      V v_field_2413 = v_t_2412.f[0];
      V v_field_2414 = v_t_2412.f[1];
      V v_x_2415 = v_field_2413;
      V v_n_2416 = v_field_2414;
      V v_t_2448 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam0, 1, 2, (V[]){v_p_245, heff_dup(v_x_2415)}), v_labels_248));
      V v_x2_2449 = heff_tr(heff_call(v_t_2448, 1, (V[]){v_n_2416}));
      V v_x2_2454;
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_MkPair: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_n_2451 = heff_field(v_x2_2449, 1);
        V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
        V v_t_2452 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2411)}), v_x_2450});
        V v_t_2453 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_2411, v_x_2415}), v_t_2452});
        v_x2_2454 = heff_tag_re_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_key_249), v_key_249, v_t_2453}), v_n_2451});
        break;
      }
      default: heff_nomatch(v_x2_2449);
      }
      switch (heff_tag_of(v_x2_2454)) {
      case TAG_MkPair: {
        V v_x_2455 = heff_field(v_x2_2454, 0);
        V v_n_2456 = heff_field(v_x2_2454, 1);
        V v_ru_24x2_2454_24MkPair = heff_take_reuse_n(v_x2_2454, 3ULL, 2);
        V v_cell_2457 = heff_tag_at_n(v_ru_24x2_2454_24MkPair, TAG_Cons, 2, (V[]){v_x_2455, heff_hole()});
        HeffT2 v_t_2458 = ({ V a_0 = v_lit_240; V a_1 = v_xs_244; V a_2 = v_n_2456; V a_3 = v_cell_2457; HeffT2 r_ = (g_prelude_2etraverse_24s1764298183x420715364_24dps_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); r_; });
        {
          V v_field_2459 = v_t_2458.f[0];
          V v_field_2460 = v_t_2458.f[1];
          V v__5f_2461 = v_field_2459;
          heff_drop(v__5f_2461);
          V v_n_2462 = v_field_2460;
          return ((HeffT2){{v_cell_2457, v_n_2462}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2454)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam1(V self, V *args) {
  V v_n_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_params_2427 = heff_env(self)[1];
  V v_fvs_2430 = heff_env(self)[2];
  V v_zs_2419 = heff_env(self)[3];
  V v_p_2418 = heff_env(self)[4];
  V v_body_2428 = heff_env(self)[5];
  V v_tag_2431 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2433}));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_n_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    V v_t_2437 = (g_prelude_2e_2b_2b(v_params_2427, v_fvs_2430));
    V v_t_2438 = (g_prelude_2e_2b_2b(v_zs_2419, heff_dup(v_x_2435)));
    V v_m_2439 = ({ V a_0 = v_t_2437; V a_1 = v_t_2438; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_t_2437); heff_drop(v_t_2438); r_; });
    V v_e_2440 = (g_heff_2ecompile_2edefun_2erw(v_p_2418, v_body_2428));
    V v_t_2441 = (g_std_2eordmap_2esize(v_m_2439));
    V v_t_2442;
    if (heff_intEq_c(v_t_2441, MK_INT(0LL))) {
      heff_drop(v_m_2439);
      v_t_2442 = v_e_2440;
    } else {
      v_t_2442 = ({ V a_0 = v_m_2439; V a_1 = v_e_2440; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2439); r_; });
    }
    V v_x_2443 = heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_2431, v_x_2435, v_t_2442});
    return heff_tag_re_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2443, v_n_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam2(V self, V *args) {
  V v_n_2444 = args[0];
  V v_t_2445 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()), NTAG(TAG_Nil), NTAG(TAG_EAbandon)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_n_2444});
}
V g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam3(V self, V *args) {
  V v_n_2446 = args[0];
  V v_t_2447 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()), NTAG(TAG_Nil), NTAG(TAG_EAbandon)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2447, v_n_2446});
}
V g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam0(V self, V *args) {
  V v_l_2417 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_p_2418 = heff_dup(v_p_245);
  heff_clo_take(self, 2);
  V v_zs_2419 = v_x_2415;
  HeffT2 v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_p_245, 3), v_l_2417));
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    HeffT2 v_t_2423 = ({ V b_0 = heff_get_n(v_p_245, 0, 4); V a_1 = v_l_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_l_2417); r_; });
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_lam_2426 = v_field_2422;
        V v_params_2427 = heff_take_field(v_lam_2426, 0);
        V v_body_2428 = heff_get_n(v_lam_2426, 1, 2);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          V v_i_2429 = v_field_2425;
          V v_fvs_2430 = heff_take_field(v_i_2429, 1);
          V v_tag_2431 = heff_get_n(v_i_2429, 0, 2);
          V v_m_2432 = (g_prelude_2etraverse_24s75890152x1871550235(MK_INT(0LL), ((V)&g_prelude_2etraverse_24s1764298183x420715364_24cpr_str1), MK_INT(1LL), heff_dup(v_fvs_2430)));
          return heff_clo_n(g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam1, 1, 7, (V[]){v_m_2432, v_params_2427, v_fvs_2430, v_zs_2419, v_p_2418, v_body_2428, v_tag_2431});
        } else {
          heff_drop(v_p_2418);
          heff_drop(v_zs_2419);
          heff_drop(v_field_2425);
          heff_drop(v_params_2427);
          heff_drop(v_body_2428);
          return ((V)&g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam2_clo);
        }
      } else {
        heff_drop(v_p_2418);
        heff_drop(v_zs_2419);
        heff_drop(v_field_2422);
        heff_drop(v_field_2425);
        return ((V)&g_prelude_2etraverse_24s1764298183x420715364_24cpr_lam3_clo);
      }
    }
  }
}
V g_prelude_2etraverse_24s352965232x546119438_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s352965232x546119438_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s352965232x546119438_lam0, 1, 0};
V g_prelude_2etraverse_24s352965232x546119438_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s352965232x546119438_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s352965232x546119438_entry, 2, 0};

V g_prelude_2etraverse_24s352965232x546119438(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s352965232x546119438_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_prelude_2etraverse_24s352965232x546119438_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s352965232x546119438(a[0], a[1]);
}
V g_prelude_2etraverse_24s352965232x546119438_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_243});
}
V g_prelude_2etraverse_24s352965232x546119438_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    heff_drop(v_f_240);
    heff_drop(v_xs_245);
    return heff_tag_re_n(v_ru_24x2_248_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_t_2413 = (g_prelude_2etraverse_24s352965232x546119438(v_f_240, v_xs_245));
      V v_x2_2414 = heff_tr(heff_call(v_t_2413, 1, (V[]){v_n_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Left: {
        V v_e_2415 = heff_field(v_x2_2414, 0);
        V v_ru_24x2_2414_24Left = heff_take_reuse_n(v_x2_2414, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_248_24Right, 1);
        heff_drop(v_x_2411);
        heff_drop_cell(v_ru_24x21_2410_24MkPair, 2);
        return heff_tag_re_n(v_ru_24x2_2414_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2415});
      }
      case TAG_Right: {
        V v_x21_2416 = heff_field(v_x2_2414, 0);
        heff_take_n(v_x2_2414, 1ULL, 1);
        switch (heff_tag_of(v_x21_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x21_2416, 0);
          V v_n_2418 = heff_field(v_x21_2416, 1);
          V v_ru_24x21_2416_24MkPair = heff_take_reuse_n(v_x21_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at_n(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x21_2416_24MkPair, TAG_Cons, 2, (V[]){v_x_2411, v_x_2417}), v_n_2418});
          return heff_tag_at_n(v_ru_24x2_248_24Right, TAG_Right, 1, (V[]){v_t_2419});
        }
        default: return heff_nomatch(v_x21_2416);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s1801023533x118610014_24cpr_str0, 1, "$");

HeffT2 g_prelude_2etraverse_24s1801023533x118610014_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_prelude_2etraverse_24s1801023533x118610014_24cpr_str0));
    V v_x_245 = heff_strAppend(v_t_244, heff_intShow(heff_dup(v_p_241)));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_r__x, (V[]){v_x_242, v_x_245}), heff_hole()});
    HeffT2 v_t_247 = (g_prelude_2etraverse_24s1801023533x118610014_24dps_24cpr(v_xs_243, heff_intAdd(v_p_241, MK_INT(1LL)), v_cell_246));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v__5f_2410 = v_field_248;
      heff_drop(v__5f_2410);
      V v_n_2411 = v_field_249;
      return ((HeffT2){{v_cell_246, v_n_2411}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1462482035x919987020_24dps_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s1462482035x919987020_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_2418;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkArm: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_a_249 = heff_field(v_x_245, 2);
      heff_take_n(v_x_245, 7ULL, 3);
      V v_a_2410 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_a_249));
      v_m_2418 = heff_clo_n(g_prelude_2etraverse_24s1462482035x919987020_24dps_24cpr_lam0, 1, 3, (V[]){v_a_2410, v_a_248, v_a_247});
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      V v_cell_2422 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2420, heff_hole()});
      V v_u_2423 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2422);
      V t_0 = v_xs_246;
      V t_1 = v_n_2421;
      V t_2 = v_u_2423;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2419)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1462482035x919987020_24dps_24cpr_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2412 = heff_tr(heff_call(v_a_2410, 1, (V[]){v_a_2411}));
  V v_a_2415;
  switch (heff_tag_of(v_a_2412)) {
  case TAG_MkPair: {
    V v_a_2413 = heff_field(v_a_2412, 0);
    V v_a_2414 = heff_field(v_a_2412, 1);
    heff_take_n(v_a_2412, 3ULL, 2);
    v_a_2415 = (g_heff_2ecompile_2efields_2ereadsAt(v_a_248, v_a_2413, v_a_2414));
    break;
  }
  default: heff_nomatch(v_a_2412);
  }
  switch (heff_tag_of(v_a_2415)) {
  case TAG_MkPair: {
    V v_a_2416 = heff_field(v_a_2415, 0);
    V v_a_2417 = heff_field(v_a_2415, 1);
    V v_ru_24a_2415_24MkPair = heff_take_reuse_n(v_a_2415, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_2415_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_247, v_a_248, v_a_2416}), v_a_2417});
  }
  default: return heff_nomatch(v_a_2415);
  }
}
V g_prelude_2etraverse_24s1169518895x2088283545_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1169518895x2088283545_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1169518895x2088283545_lam0, 1, 0};
V g_prelude_2etraverse_24s1169518895x2088283545_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1169518895x2088283545_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1169518895x2088283545_entry, 1, 0};

V g_prelude_2etraverse_24s1169518895x2088283545(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1169518895x2088283545_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s1169518895x2088283545_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1169518895x2088283545_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1169518895x2088283545(a[0]);
}
V g_prelude_2etraverse_24s1169518895x2088283545_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1169518895x2088283545_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = (g_prelude_2etraverse_24s1169518895x2088283545(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_t_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2etraverse_24s1096531376x1665190054_24dps_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s1096531376x1665190054_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_2415;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkArm: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_a_249 = heff_field(v_x_245, 2);
      heff_take_n(v_x_245, 7ULL, 3);
      V v_a_2410 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_a_249));
      v_m_2415 = heff_clo_n(g_prelude_2etraverse_24s1096531376x1665190054_24dps_24cpr_lam0, 1, 3, (V[]){v_a_2410, v_a_247, v_a_248});
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_n_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      V v_cell_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2420 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2419);
      V t_0 = v_xs_246;
      V t_1 = v_n_2418;
      V t_2 = v_u_2420;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2416)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1096531376x1665190054_24dps_24cpr_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  V v_a_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2412 = heff_tr(heff_call(v_a_2410, 1, (V[]){v_a_2411}));
  switch (heff_tag_of(v_a_2412)) {
  case TAG_MkPair: {
    V v_a_2413 = heff_field(v_a_2412, 0);
    V v_a_2414 = heff_field(v_a_2412, 1);
    V v_ru_24a_2412_24MkPair = heff_take_reuse_n(v_a_2412, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_247, v_a_248, v_a_2413}), v_a_2414});
  }
  default: return heff_nomatch(v_a_2412);
  }
}
V g_prelude_2etraverse_24s1254646865x1442622806_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1254646865x1442622806_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1254646865x1442622806_lam0, 1, 0};
V g_prelude_2etraverse_24s1254646865x1442622806_lam1(V self, V *args);
V g_prelude_2etraverse_24s1254646865x1442622806_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1254646865x1442622806_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1254646865x1442622806_entry, 1, 0};

V g_prelude_2etraverse_24s1254646865x1442622806(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1254646865x1442622806_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_a_246 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_a_245));
      v_m_2414 = heff_clo_n(g_prelude_2etraverse_24s1254646865x1442622806_lam1, 1, 2, (V[]){v_a_246, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1254646865x1442622806_lam2, 1, 2, (V[]){v_m_2414, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1254646865x1442622806_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1254646865x1442622806(a[0]);
}
V g_prelude_2etraverse_24s1254646865x1442622806_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1254646865x1442622806_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_a_247}));
  V v_a_2411;
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_a_249 = heff_field(v_a_248, 0);
    V v_a_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    v_a_2411 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24a_248_24MkPair, v_a_249, v_a_2410));
    break;
  }
  default: heff_nomatch(v_a_248);
  }
  switch (heff_tag_of(v_a_2411)) {
  case TAG_MkPair: {
    V v_a_2412 = heff_field(v_a_2411, 0);
    V v_a_2413 = heff_field(v_a_2411, 1);
    V v_ru_24a_2411_24MkPair = heff_take_reuse_n(v_a_2411, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_2411_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_2412}), v_a_2413});
  }
  default: return heff_nomatch(v_a_2411);
  }
}
V g_prelude_2etraverse_24s1254646865x1442622806_lam2(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2419 = (g_prelude_2etraverse_24s1254646865x1442622806(v_xs_243));
    V v_x2_2420 = heff_tr(heff_call(v_t_2419, 1, (V[]){v_n_2418}));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_n_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_Cons, 2, (V[]){v_x_2417, v_x_2421}), v_n_2422});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_prelude_2etraverse_24s1232682027x654714928_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1232682027x654714928_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1232682027x654714928_lam0, 1, 0};
V g_prelude_2etraverse_24s1232682027x654714928_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1232682027x654714928_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1232682027x654714928_entry, 1, 0};

V g_prelude_2etraverse_24s1232682027x654714928(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1232682027x654714928_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2escalars_2ewithVars(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s1232682027x654714928_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1232682027x654714928_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1232682027x654714928(a[0]);
}
V g_prelude_2etraverse_24s1232682027x654714928_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1232682027x654714928_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = (g_prelude_2etraverse_24s1232682027x654714928(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_t_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s205209257x1087869143_str0, 1, "$");
V g_prelude_2etraverse_24s205209257x1087869143_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s205209257x1087869143_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s205209257x1087869143_lam0, 1, 0};
V g_prelude_2etraverse_24s205209257x1087869143_lam1(V self, V *args);
V g_prelude_2etraverse_24s205209257x1087869143_lam2(V self, V *args);
V g_prelude_2etraverse_24s205209257x1087869143_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s205209257x1087869143_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s205209257x1087869143_entry, 2, 0};

V g_prelude_2etraverse_24s205209257x1087869143(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((V)&g_prelude_2etraverse_24s205209257x1087869143_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_dup(v_lit_240);
    V v_e_246 = v_x_243;
    V v_t_2446;
    switch (heff_tag_of(v_e_246)) {
    case TAG_EVar: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_246);
    }
    V v_m_2454;
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_x_245);
      heff_drop(v_t_2446);
      v_m_2454 = heff_clo_n(g_prelude_2etraverse_24s205209257x1087869143_lam1, 1, 1, (V[]){v_e_246});
    } else {
      heff_drop(v_t_2446);
      V v_base_2449 = ({ V a_0 = v_x_245; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eir_2ebaseGo(a_0, a_1)); heff_drop(v_x_245); r_; });
      v_m_2454 = heff_clo_n(g_prelude_2etraverse_24s205209257x1087869143_lam2, 1, 2, (V[]){v_base_2449, v_e_246});
    }
    return heff_clo_n(g_prelude_2etraverse_24s205209257x1087869143_lam3, 1, 3, (V[]){v_m_2454, v_lit_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s205209257x1087869143_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s205209257x1087869143(a[0], a[1]);
}
V g_prelude_2etraverse_24s205209257x1087869143_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s205209257x1087869143_lam1(V self, V *args) {
  V v_n_2447 = args[0];
  V v_e_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_rec_n(2, shape_bound__atom, (V[]){NTAG(TAG_Nothing), v_e_246});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_n_2447});
}
V g_prelude_2etraverse_24s205209257x1087869143_lam2(V self, V *args) {
  V v_n_2450 = args[0];
  V v_base_2449 = heff_env(self)[0];
  V v_e_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2451 = heff_strAppend(heff_strAppend(v_base_2449, ((V)&g_prelude_2etraverse_24s205209257x1087869143_str0)), heff_intShow(heff_dup(v_n_2450)));
  V v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2451), v_e_246})});
  V v_t_2453 = heff_rec_n(2, shape_bound__atom, (V[]){v_t_2452, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2451})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, heff_intAdd(v_n_2450, MK_INT(1LL))});
}
V g_prelude_2etraverse_24s205209257x1087869143_lam3(V self, V *args) {
  V v_n_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2456 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_n_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_n_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    V v_t_2459 = (g_prelude_2etraverse_24s205209257x1087869143(v_lit_240, v_xs_244));
    V v_x2_2460 = heff_tr(heff_call(v_t_2459, 1, (V[]){v_n_2458}));
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_MkPair: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      V v_n_2462 = heff_field(v_x2_2460, 1);
      V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_Cons, 2, (V[]){v_x_2457, v_x_2461}), v_n_2462});
    }
    default: return heff_nomatch(v_x2_2460);
    }
  }
  default: return heff_nomatch(v_x2_2456);
  }
}

HeffT2 g_prelude_2etraverse_24s1442653311x1678194035_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2escalars_2eslotsOf(NTAG(TAG_OfRecords), heff_dup(v_x_242)));
    V v_m_245 = (g_heff_2ecompile_2escalars_2efoundWith(NTAG(TAG_OfRecords), heff_dup(v_x_242), heff_rec_n(2, shape_def__slots, (V[]){v_x_242, v_t_244})));
    V v_x2_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_n_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
      HeffT2 v_t_2410 = (g_prelude_2etraverse_24s1442653311x1678194035_24dps_24cpr(v_xs_243, v_n_248, v_cell_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v__5f_2413 = v_field_2411;
        heff_drop(v__5f_2413);
        V v_n_2414 = v_field_2412;
        return ((HeffT2){{v_cell_249, v_n_2414}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s379292819x1163591097_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_def_244 = heff_take_field(v_x_242, 0);
    V v_slots_245 = heff_get_n(v_x_242, 1, 2);
    V v_m_246 = (g_heff_2ecompile_2escalars_2edefWith(NTAG(TAG_OfRecords), v_def_244, v_slots_245));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_n_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
      HeffT2 v_t_2411 = (g_prelude_2etraverse_24s379292819x1163591097_24dps_24cpr(v_xs_243, v_n_249, v_cell_2410));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v__5f_2414 = v_field_2412;
        heff_drop(v__5f_2414);
        V v_n_2415 = v_field_2413;
        return ((HeffT2){{v_cell_2410, v_n_2415}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s993801089x502291790_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_def_244 = heff_take_field(v_x_242, 0);
    V v_slots_245 = heff_get_n(v_x_242, 1, 2);
    V v_m_246 = (g_heff_2ecompile_2escalars_2edefWith(NTAG(TAG_OfTags), v_def_244, v_slots_245));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_n_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
      HeffT2 v_t_2411 = (g_prelude_2etraverse_24s993801089x502291790_24dps_24cpr(v_xs_243, v_n_249, v_cell_2410));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v__5f_2414 = v_field_2412;
        heff_drop(v__5f_2414);
        V v_n_2415 = v_field_2413;
        return ((HeffT2){{v_cell_2410, v_n_2415}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_prelude_2etraverse_24s544736993x1914601267_str0, 2, "f$");
V g_prelude_2etraverse_24s544736993x1914601267_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s544736993x1914601267_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s544736993x1914601267_lam0, 1, 0};
V g_prelude_2etraverse_24s544736993x1914601267_lam1(V self, V *args);
V g_prelude_2etraverse_24s544736993x1914601267_lam2(V self, V *args);
V g_prelude_2etraverse_24s544736993x1914601267_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s544736993x1914601267_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s544736993x1914601267_entry, 1, 0};

V g_prelude_2etraverse_24s544736993x1914601267(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s544736993x1914601267_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_e_244 = v_x_242;
    V v_t_245 = (g_heff_2ecompile_2eir_2eisValue(v_e_244));
    V v_m_2412;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s544736993x1914601267_lam1, 1, 1, (V[]){v_e_244});
    } else {
      heff_drop(v_t_245);
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s544736993x1914601267_lam2, 1, 1, (V[]){v_e_244});
    }
    return heff_clo_n(g_prelude_2etraverse_24s544736993x1914601267_lam3, 1, 2, (V[]){v_m_2412, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s544736993x1914601267_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s544736993x1914601267(a[0]);
}
V g_prelude_2etraverse_24s544736993x1914601267_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s544736993x1914601267_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_244});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_n_246});
}
V g_prelude_2etraverse_24s544736993x1914601267_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_249 = heff_strAppend(((V)&g_prelude_2etraverse_24s544736993x1914601267_str0), heff_intShow(heff_dup(v_n_248)));
  heff_clo_take(self, 1);
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_249), v_e_244}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, heff_tag_n(TAG_EVar, 1, (V[]){v_x_249})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, heff_intAdd(v_n_248, MK_INT(1LL))});
}
V g_prelude_2etraverse_24s544736993x1914601267_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = (g_prelude_2etraverse_24s544736993x1914601267(v_xs_243));
    V v_x2_2418 = heff_tr(heff_call(v_t_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}

HeffT2 g_prelude_2etraverse_24s1882351740x242225671_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2etrmc_2edefT(v_x_245));
    V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_n_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
      V v_u_2412 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2411);
      V t_0 = v_xs_246;
      V t_1 = v_n_2410;
      V t_2 = v_u_2412;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1362847681x1386678580_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1362847681x1386678580_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1362847681x1386678580_lam0, 1, 0};
V g_prelude_2etraverse_24s1362847681x1386678580_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1362847681x1386678580_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1362847681x1386678580_entry, 2, 0};

V g_prelude_2etraverse_24s1362847681x1386678580(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1362847681x1386678580_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1362847681x1386678580_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1362847681x1386678580(a[0], a[1]);
}
V g_prelude_2etraverse_24s1362847681x1386678580_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s1362847681x1386678580_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s1099455515x1225465224_lam1(V self, V *args);
V g_prelude_2etraverse_24s1099455515x1225465224_lam0(V self, V *args);
Clo g_prelude_2etraverse_24s1099455515x1225465224_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1099455515x1225465224_entry, 3, 0};

V g_prelude_2etraverse_24s1099455515x1225465224(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_z_241);
    return heff_tail(v_z_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(v_x_243));
    return heff_tail(v_a_245, 2, (V[]){heff_dup(v_z_241), heff_clo_n(g_prelude_2etraverse_24s1099455515x1225465224_lam0, 1, 3, (V[]){v_xs_244, v_z_241, v_z_242})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1099455515x1225465224_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1099455515x1225465224(a[0], a[1], a[2]);
}
V g_prelude_2etraverse_24s1099455515x1225465224_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_246, v_a_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1099455515x1225465224_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_prelude_2etraverse_24s1099455515x1225465224(v_xs_244, v_z_241, heff_clo_n(g_prelude_2etraverse_24s1099455515x1225465224_lam1, 1, 2, (V[]){v_z_242, v_a_246})));
}
V g_prelude_2etraverse_24s1963041714x1343204084_lam0(V self, V *args);
V g_prelude_2etraverse_24s1963041714x1343204084_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1963041714x1343204084_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1963041714x1343204084_entry, 3, 0};

V g_prelude_2etraverse_24s1963041714x1343204084(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tail(v_p_241, 2, (V[]){NTAG(TAG_Nil), v_p_242});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_245 = v_x_243;
    V v_p_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply0, 2, (V[]){v_xs_244, v_p_241});
    V v_p_247 = v_p_242;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_At: {
      V v_x11_248 = heff_field(v_x1_245, 0);
      V v_sp_249 = heff_field(v_x1_245, 1);
      V v_ru_24x1_245_24At = heff_take_reuse_n(v_x1_245, 3ULL, 2);
      switch (heff_tag_of(v_x11_248)) {
      case TAG_ExplicitParam: {
        V v_x_2410 = heff_field(v_x11_248, 0);
        V v_t_2412 = heff_field(v_x11_248, 2);
        heff_take_n(v_x11_248, 5ULL, 3);
        V v_n_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_n_2413 = heff_field(v_t_2412, 0);
          V v_sp_2414 = heff_field(v_t_2412, 1);
          heff_take_n(v_t_2412, 3ULL, 2);
          v_n_2415 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x1_245_24At, v_sp_2414, v_n_2413));
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        V v_t_2416 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2415));
        return heff_tail(v_t_2416, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_prelude_2etraverse_24s1963041714x1343204084_lam0, 1, 3, (V[]){v_sp_249, v_x_2410, v_p_246}), v_p_247});
      }
      case TAG_ImplicitParam: {
        V v_x_2419 = heff_field(v_x11_248, 0);
        V v_t_2421 = heff_field(v_x11_248, 2);
        heff_take_n(v_x11_248, 5ULL, 3);
        V v_n_2424;
        switch (heff_tag_of(v_t_2421)) {
        case TAG_At: {
          V v_n_2422 = heff_field(v_t_2421, 0);
          V v_sp_2423 = heff_field(v_t_2421, 1);
          heff_take_n(v_t_2421, 3ULL, 2);
          v_n_2424 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x1_245_24At, v_sp_2423, v_n_2422));
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
        V v_t_2425 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2424));
        return heff_tail(v_t_2425, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_prelude_2etraverse_24s1963041714x1343204084_lam1, 1, 3, (V[]){v_sp_249, v_x_2419, v_p_246}), v_p_247});
      }
      default: return heff_nomatch(v_x11_248);
      }
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1963041714x1343204084_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1963041714x1343204084(a[0], a[1], a[2]);
}
V g_prelude_2etraverse_24s1963041714x1343204084_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_sp_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_249, v_x_2410, v_x_2417, NTAG(TAG_Expl)});
  return (g_prelude_2etraverse_24s1310917876x950458632_24apply0(v_p_246, v_t_2418));
}
V g_prelude_2etraverse_24s1963041714x1343204084_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_sp_249 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_249, v_x_2419, v_x_2426, NTAG(TAG_Impl)});
  return (g_prelude_2etraverse_24s1310917876x950458632_24apply0(v_p_246, v_t_2427));
}
Clo g_prelude_2etraverse_24s1310917876x950458632_24apply1_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1310917876x950458632_24apply1_entry, 2, 0};

V g_prelude_2etraverse_24s1310917876x950458632_24apply1(V v_k_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply1: {
    V v_xs_242 = heff_field(v_k_240, 0);
    V v_p_243 = heff_field(v_k_240, 1);
    V v_ru_24k_240_24Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply1 = heff_take_reuse_n(v_k_240, 3ULL, 2);
    HEFF_LAST return g_prelude_2etraverse_24s1310917876x950458632(v_xs_242, heff_tag_at_n(v_ru_24k_240_24Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply1, TAG_Lam1_24prelude_2etraverse_24s1310917876x950458632_24apply2, 2, (V[]){v_p_243, v_z_241}));
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_prelude_2etraverse_24s1310917876x950458632_24apply1_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1310917876x950458632_24apply1(a[0], a[1]);
}
V g_prelude_2einstanceOrderPair_24s566030815x71064266_lam0(V self, V *args); static Clo g_prelude_2einstanceOrderPair_24s566030815x71064266_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceOrderPair_24s566030815x71064266_lam0, 2, 0};
V g_prelude_2einstanceOrderPair_24s566030815x71064266_lam1(V self, V *args);
V g_prelude_2einstanceOrderPair_24s566030815x71064266_lam2(V self, V *args);

static V g_prelude_2einstanceOrderPair_24s566030815x71064266_val;
static HEFF_ONCE g_prelude_2einstanceOrderPair_24s566030815x71064266_st;
static V g_prelude_2einstanceOrderPair_24s566030815x71064266_init(void) {
  V v_t_240 = heff_dup(g_prelude_2einstanceOrderPair_24s369861572x2077527721_get());
  V v_cmp_241 = heff_tr(heff_call(((V)&g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285_clo), 1, (V[]){v_t_240}));
  return heff_rec_n(4, shape_eq__compare__lt__le, (V[]){heff_rec_n(1, shape_equal, (V[]){((V)&g_prelude_2einstanceOrderPair_24s566030815x71064266_lam0_clo)}), heff_dup(v_cmp_241), heff_clo_n(g_prelude_2einstanceOrderPair_24s566030815x71064266_lam1, 2, 1, (V[]){heff_dup(v_cmp_241)}), heff_clo_n(g_prelude_2einstanceOrderPair_24s566030815x71064266_lam2, 2, 1, (V[]){v_cmp_241})});
}
V g_prelude_2einstanceOrderPair_24s566030815x71064266_get(void) {
  if (HEFF_DONE(g_prelude_2einstanceOrderPair_24s566030815x71064266_st)) return g_prelude_2einstanceOrderPair_24s566030815x71064266_val;
  return heff_global(&g_prelude_2einstanceOrderPair_24s566030815x71064266_val, &g_prelude_2einstanceOrderPair_24s566030815x71064266_st, g_prelude_2einstanceOrderPair_24s566030815x71064266_init);
}
V g_prelude_2einstanceOrderPair_24s566030815x71064266_lam0(V self, V *args) {
  V v_x1_27_242 = args[0];
  V v_x2_27_243 = args[1];
  switch (heff_tag_of(v_x1_27_242)) {
  case TAG_MkPair: {
    V v_x1_244 = heff_field(v_x1_27_242, 0);
    V v_y1_245 = heff_field(v_x1_27_242, 1);
    heff_take_n(v_x1_27_242, 3ULL, 2);
    switch (heff_tag_of(v_x2_27_243)) {
    case TAG_MkPair: {
      V v_x2_246 = heff_field(v_x2_27_243, 0);
      V v_y2_247 = heff_field(v_x2_27_243, 1);
      heff_take_n(v_x2_27_243, 3ULL, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(g_prelude_2eorderByCompare_24s1329979559x1043691411_get(), 0)), 0, 1);
      V v_t_249 = heff_tr(heff_call(v_t_248, 2, (V[]){v_x1_244, v_x2_246}));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(g_prelude_2einstanceOrderPair_24s369861572x2077527721_get(), 0)), 0, 1);
        V f_ = v_t_2410;
        args[0] = v_y1_245;
        args[1] = v_y2_247;
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      } else {
        heff_drop(v_y1_245);
        heff_drop(v_y2_247);
        heff_drop(v_t_249);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_27_243);
    }
  }
  default: return heff_nomatch(v_x1_27_242);
  }
}
V g_prelude_2einstanceOrderPair_24s566030815x71064266_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_y_2412 = args[1];
  V v_cmp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2413 = heff_tr(heff_call(v_cmp_241, 2, (V[]){v_x_2411, v_y_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_LT: {
    return NTAG(TAG_True);
  }
  case TAG_EQ: {
    return NTAG(TAG_False);
  }
  case TAG_GT: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_prelude_2einstanceOrderPair_24s566030815x71064266_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_y_2415 = args[1];
  V v_cmp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = heff_tr(heff_call(v_cmp_241, 2, (V[]){v_x_2414, v_y_2415}));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_LT: {
    return NTAG(TAG_True);
  }
  case TAG_EQ: {
    return NTAG(TAG_True);
  }
  case TAG_GT: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_243 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24At = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_245, ((V)&g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_str0), 2)) {
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_x_245);
        return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
      } else {
        V v_t_246 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, NTAG(TAG_Nil), heff_dup(v_ys_240)));
        return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_t_246}));
      }
    }
    case TAG_PatTag: {
      V v_ps_249 = heff_field(v_x11_243, 2);
      heff_take_n(v_x11_243, 4ULL, 3);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_249));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2411, heff_dup(v_ys_240)));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2412);
    }
    case TAG_PatOp: {
      V v_ps_2415 = heff_field(v_x11_243, 2);
      heff_take_n(v_x11_243, 4ULL, 3);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2415));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2416); r_; });
      V v_t_2418 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2417, heff_dup(v_ys_240)));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2418);
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatString: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatRecord: {
      V v_fs_2424 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_t_2427 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_241_24At, v_t_2426, heff_dup(v_ys_240)));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2427);
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatAs: {
      V v_x_2429 = heff_field(v_x11_243, 0);
      V v_q_2431 = heff_field(v_x11_243, 2);
      heff_take_n(v_x11_243, 5ULL, 3);
      V v_cell_2432 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2429, heff_hole()});
      V v_u_2433 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2432);
      V t_0 = v_ys_240;
      V t_1 = v_q_2431;
      V t_2 = v_u_2433;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f339900781x1605227681_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f339900781x1605227681_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f339900781x1605227681_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = heff_tag_n(TAG_SDecl, 1, (V[]){v_x_243});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_247;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f339900781x1605227681_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f339900781x1605227681_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f1583460153x999201201_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1583460153x999201201_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1583460153x999201201(V v_ys_240, V v_f_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    heff_drop(v_x3_243);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_f_241);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      heff_take_n(v_x3_243, 3ULL, 2);
      V v_x_248 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){v_x_244, v_y_246}));
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_248, heff_hole()});
      V v_u_2410 = ({ V a_0 = v_ys_240; V a_1 = v_f_241; V a_2 = v_xs_245; V a_3 = v_ys_247; V a_4 = v_cell_249; V r_ = (g_prelude_2e_2b_2b_24f1583460153x999201201_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ys_240); heff_drop(v_f_241); r_; });
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1583460153x999201201_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1583460153x999201201(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f1583460153x999201201_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1583460153x999201201_24dps_entry, 5, 0};

V g_prelude_2e_2b_2b_24f1583460153x999201201_24dps(V v_ys_240, V v_f_241, V v_x2_242, V v_x3_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_x3_243);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_242, 0);
    V v_xs_246 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return heff_setField(heff_dup(v_d_244), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_243, 0);
      V v_ys_248 = heff_field(v_x3_243, 1);
      heff_take_n(v_x3_243, 3ULL, 2);
      V v_x_249 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){v_x_245, v_y_247}));
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
      V v_u_2411 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2410);
      V t_0 = v_ys_240;
      V t_1 = v_f_241;
      V t_2 = v_xs_246;
      V t_3 = v_ys_248;
      V t_4 = v_u_2411;
      v_ys_240 = t_0;
      v_f_241 = t_1;
      v_x2_242 = t_2;
      v_x3_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1583460153x999201201_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_prelude_2e_2b_2b_24f1583460153x999201201_24dps(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1589519835x26889547_str0, 3, "Lam");
HEFF_LIT(g_prelude_2e_2b_2b_24f1589519835x26889547_str1, 1, "$");
Clo g_prelude_2e_2b_2b_24f1589519835x26889547_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1589519835x26889547_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1589519835x26889547(V v_ys_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_c_246 = heff_dup(v_lit_241);
    V v_a_247 = heff_dup(v_lit_242);
    V v_x3_248 = v_x_244;
    V v_x_2421;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_MkPair: {
      V v_j_249 = heff_field(v_x3_248, 0);
      V v_l_2410 = heff_field(v_x3_248, 1);
      V v_ru_24x3_248_24MkPair = heff_take_reuse_n(v_x3_248, 3ULL, 2);
      HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_c_246, 4, 5); V a_1 = v_l_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        V v_t_2418;
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2413;
          V v_params_2415 = heff_take_field(v_x_2414, 0);
          V v_body_2416 = heff_get_n(v_x_2414, 1, 2);
          V v_xs_2417 = heff_tr(g_heff_2ecompile_2elift_2efreeGo(v_params_2415, v_body_2416, NTAG(TAG_Nil)));
          v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
        } else {
          heff_drop(v_field_2413);
          v_t_2418 = NTAG(TAG_Nil);
        }
        V v_t_2419 = heff_strAppend(((V)&g_prelude_2e_2b_2b_24f1589519835x26889547_str0), heff_intShow(v_j_249));
        V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_prelude_2e_2b_2b_24f1589519835x26889547_str1)), heff_get_n(v_a_247, 0, 3));
        v_x_2421 = heff_tag_at_n(v_ru_24x3_248_24MkPair, TAG_MkPair, 2, (V[]){v_l_2410, heff_rec_n(2, shape_tag__fvs, (V[]){v_t_2420, v_t_2418})});
      }
      break;
    }
    default: heff_nomatch(v_x3_248);
    }
    V v_cell_2422 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_2421, heff_hole()});
    V v_u_2423 = ({ V a_0 = v_ys_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_245; V a_4 = v_cell_2422; V r_ = (g_prelude_2e_2b_2b_24f1589519835x26889547_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ys_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    heff_drop(v_u_2423);
    return v_cell_2422;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2e_2b_2b_24f1589519835x26889547_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1589519835x26889547(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_str0, 3, "Lam");
HEFF_LIT(g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_str1, 1, "$");
Clo g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_entry, 5, 0};

V g_prelude_2e_2b_2b_24f1589519835x26889547_24dps(V v_ys_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_c_247 = heff_dup(v_lit_241);
    V v_a_248 = heff_dup(v_lit_242);
    V v_x3_249 = v_x_245;
    V v_x_2422;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_MkPair: {
      V v_j_2410 = heff_field(v_x3_249, 0);
      V v_l_2411 = heff_field(v_x3_249, 1);
      V v_ru_24x3_249_24MkPair = heff_take_reuse_n(v_x3_249, 3ULL, 2);
      HeffT2 v_t_2412 = ({ V b_0 = heff_get_n(v_c_247, 4, 5); V a_1 = v_l_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        V v_t_2419;
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2415 = v_field_2414;
          V v_params_2416 = heff_take_field(v_x_2415, 0);
          V v_body_2417 = heff_get_n(v_x_2415, 1, 2);
          V v_xs_2418 = heff_tr(g_heff_2ecompile_2elift_2efreeGo(v_params_2416, v_body_2417, NTAG(TAG_Nil)));
          v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
        } else {
          heff_drop(v_field_2414);
          v_t_2419 = NTAG(TAG_Nil);
        }
        V v_t_2420 = heff_strAppend(((V)&g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_str0), heff_intShow(v_j_2410));
        V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_str1)), heff_get_n(v_a_248, 0, 3));
        v_x_2422 = heff_tag_at_n(v_ru_24x3_249_24MkPair, TAG_MkPair, 2, (V[]){v_l_2411, heff_rec_n(2, shape_tag__fvs, (V[]){v_t_2421, v_t_2419})});
      }
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_2422, heff_hole()});
    V v_u_2424 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2423);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_2424;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2e_2b_2b_24f1589519835x26889547_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_prelude_2e_2b_2b_24f1589519835x26889547_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_prelude_2e_2b_2b_24f354580856x2119298159_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f354580856x2119298159_entry, 4, 0};

V g_prelude_2e_2b_2b_24f354580856x2119298159(V v_ys_240, V v_lit_241, V v_x1_242, V v_ys_243) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    V v_t_244 = (g_list_2emap_24s231073986x752637537(v_lit_241, v_ys_243));
    return (g_prelude_2e_2b_2b(v_t_244, v_ys_240));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_242, 0);
    V v_xs_246 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    V v_x_247 = heff_strAppend(heff_dup(v_lit_241), v_x_245);
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_242_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = ({ V a_0 = v_ys_240; V a_1 = v_lit_241; V a_2 = v_xs_246; V a_3 = v_ys_243; V a_4 = v_cell_248; V r_ = (g_prelude_2e_2b_2b_24f354580856x2119298159_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ys_240); heff_drop(v_lit_241); heff_drop(v_ys_243); r_; });
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_prelude_2e_2b_2b_24f354580856x2119298159_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f354580856x2119298159(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_entry, 5, 0};

V g_prelude_2e_2b_2b_24f354580856x2119298159_24dps(V v_ys_240, V v_lit_241, V v_x1_242, V v_ys_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    V v_t_245 = (g_list_2emap_24s231073986x752637537(heff_dup(v_lit_241), heff_dup(v_ys_243)));
    V v_t_246 = (g_prelude_2e_2b_2b(v_t_245, heff_dup(v_ys_240)));
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), v_t_246);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_242, 0);
    V v_xs_248 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    V v_x_249 = heff_strAppend(heff_dup(v_lit_241), v_x_247);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x1_242_24Cons, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2410);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_248;
    V t_3 = v_ys_243;
    V t_4 = v_u_2411;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x1_242 = t_2;
    v_ys_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V r = g_prelude_2e_2b_2b_24f354580856x2119298159_24dps(a0, a1, a[2], a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_entry, 5, 0};

V g_prelude_2e_2b_2b_24f132290754x1091834184_24dps(V v_ys_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_x_247 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), heff_dup(v_lit_242)), heff_intShow(v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_248);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_249;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_prelude_2e_2b_2b_24f132290754x1091834184_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_prelude_2e_2b_2b_24f227594336x1851497670_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f227594336x1851497670_entry, 3, 0};

V g_prelude_2e_2b_2b_24f227594336x1851497670(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_241), heff_hole()});
    V v_u_246 = ({ V a_0 = v_ys_240; V a_1 = v_lit_241; V a_2 = v_xs_244; V a_3 = v_cell_245; V r_ = (g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_ys_240); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f227594336x1851497670_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f227594336x1851497670(a[0], a[1], a[2]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(V v_ys_240, V v_p_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_243 = heff_field(v_p_241, 0);
    V v_p2_244 = heff_field(v_p_241, 1);
    V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_245, ((V)&g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_str0), 2)) {
        heff_drop(v_p2_244);
        heff_drop_cell(v_ru_24p_241_24At, 2);
        heff_drop(v_x_245);
        return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
      } else {
        V v_x_246 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_245, v_p2_244, NTAG(TAG_False)});
        V v_t_247 = (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, NTAG(TAG_Nil), heff_dup(v_ys_240)));
        return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_t_247}));
      }
    }
    case TAG_PatTag: {
      V v_ps_2410 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop(v_p2_244);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_t_2413 = (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, v_t_2412, heff_dup(v_ys_240)));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2413);
    }
    case TAG_PatOp: {
      V v_ps_2416 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop(v_p2_244);
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2416));
      V v_t_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2417); r_; });
      V v_t_2419 = (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, v_t_2418, heff_dup(v_ys_240)));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2419);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatString: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatBinary: {
      V v_segs_2423 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop(v_p2_244);
      V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2423));
      V v_t_2425 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2424); r_; });
      V v_t_2426 = (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, v_t_2425, heff_dup(v_ys_240)));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2426);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatRecord: {
      V v_fs_2428 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop(v_p2_244);
      V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2428));
      V v_t_2430 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2429; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2429); r_; });
      V v_t_2431 = (g_prelude_2e_2b_2b_24tok2(v_ru_24p_241_24At, v_t_2430, heff_dup(v_ys_240)));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2431);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_PatAs: {
      V v_x_2433 = heff_field(v_p1_243, 0);
      V v_sp_2434 = heff_field(v_p1_243, 1);
      V v_q_2435 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 7ULL, 3);
      heff_drop(v_p2_244);
      V v_x_2436 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2433, v_sp_2434, NTAG(TAG_False)});
      V v_cell_2437 = heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_2436, heff_hole()});
      V v_u_2438 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2437);
      V t_0 = v_ys_240;
      V t_1 = v_q_2435;
      V t_2 = v_u_2438;
      v_ys_240 = t_0;
      v_p_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_p1_243);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f58476578x2140998212_entry, 3, 0};

V g_prelude_2e_2b_2b_24f58476578x2140998212(V v_ys_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = ({ V a_0 = v_ys_240; V a_1 = v_f_241; V a_2 = v_xs_244; V a_3 = v_cell_246; V r_ = (g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_ys_240); heff_drop(v_f_241); r_; });
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f58476578x2140998212(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(V v_ys_240, V v_f_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = v_ys_240;
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_248;
    v_ys_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_str0, 2, "--");
HEFF_LIT(g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_str1, 2, "--");
Clo g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_entry, 9, 0};

V g_prelude_2e_2b_2b_24f1960751014x547354513_24dps(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_src_245, V v_name_246, V v_i_247, V v_d_248) {
top: ;
  V v_j_249 = heff_strFind_lent(v_name_246, v_src_245, v_i_247, 4);
  if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
    heff_drop(v_j_249);
    return heff_setField(heff_dup(v_d_248), MK_INT(1LL), heff_dup(v_ys_240));
  } else {
    V v_t_2411;
    if (heff_intEq_c_lent(v_j_249, MK_INT(0LL), 2)) {
      v_t_2411 = NTAG(TAG_True);
    } else {
      V v_c_2410 = heff_strByteAt_lent(v_src_245, heff_intSub_lent(v_j_249, MK_INT(1LL), 2), 2);
      v_t_2411 = heff_bool(((heff_peek_word(v_c_2410) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_2410) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_2410) == ((int64_t)46ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_2410)) && (heff_peek_word(v_c_2410) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_2410)) && (heff_peek_word(v_c_2410) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_2410)) ? !(heff_peek_word(v_c_2410) <= ((int64_t)57ULL)) : 1)))))));
      heff_drop(v_c_2410);
    }
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_intAdd_lent(v_j_249, heff_strLength_lent(v_name_246, 0), 2);
      if (heff_intLe_c(heff_strLength_lent(v_src_245, 0), v_t_2412)) {
        V v_t_2413 = (g_heff_2ebuild_2edriver_2elineStart(v_src_245, heff_dup(v_j_249)));
        V v_s_2414 = heff_strSlice_lent(v_src_245, v_t_2413, v_j_249, 2);
        if (!heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_str0), v_s_2414, MK_INT(0LL), 5))) {
          heff_drop(v_s_2414);
          V v_t_2415 = heff_intAdd_lent(v_j_249, heff_strLength_lent(v_lit_243, 0), 2);
          V v_x_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_241), NTAG(TAG_SWarning), heff_dup(v_lit_242), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_j_249), v_t_2415}), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_lit_244)})});
          V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, heff_hole()});
          V v_u_2418 = heff_setFieldPeek(v_d_248, MK_INT(1LL), v_cell_2417);
          V v_t_2419 = heff_intAdd(v_j_249, heff_strLength_lent(v_name_246, 0));
          V t_0 = v_ys_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_lit_243;
          V t_4 = v_lit_244;
          V t_5 = v_src_245;
          V t_6 = v_name_246;
          V t_7 = v_t_2419;
          V t_8 = v_u_2418;
          v_ys_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_lit_243 = t_3;
          v_lit_244 = t_4;
          v_src_245 = t_5;
          v_name_246 = t_6;
          v_i_247 = t_7;
          v_d_248 = t_8;
          goto top;
        } else {
          heff_drop(v_s_2414);
          V t_0 = v_ys_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_lit_243;
          V t_4 = v_lit_244;
          V t_5 = v_src_245;
          V t_6 = v_name_246;
          V t_7 = heff_intAdd(v_j_249, MK_INT(1LL));
          V t_8 = v_d_248;
          v_ys_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_lit_243 = t_3;
          v_lit_244 = t_4;
          v_src_245 = t_5;
          v_name_246 = t_6;
          v_i_247 = t_7;
          v_d_248 = t_8;
          goto top;
        }
      } else {
        V v_t_2420 = heff_intAdd_lent(v_j_249, heff_strLength_lent(v_name_246, 0), 2);
        V v_c_2421 = heff_strByteAt_lent(v_src_245, v_t_2420, 2);
        if (((heff_peek_word(v_c_2421) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_2421) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_2421) == ((int64_t)46ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_2421)) && (heff_peek_word(v_c_2421) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_2421)) && (heff_peek_word(v_c_2421) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_2421)) ? !(heff_peek_word(v_c_2421) <= ((int64_t)57ULL)) : 1))))))) {
          heff_drop(v_c_2421);
          V v_t_2422 = (g_heff_2ebuild_2edriver_2elineStart(v_src_245, heff_dup(v_j_249)));
          V v_s_2423 = heff_strSlice_lent(v_src_245, v_t_2422, v_j_249, 2);
          if (!heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_str1), v_s_2423, MK_INT(0LL), 5))) {
            heff_drop(v_s_2423);
            V v_t_2424 = heff_intAdd_lent(v_j_249, heff_strLength_lent(v_lit_243, 0), 2);
            V v_x_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_241), NTAG(TAG_SWarning), heff_dup(v_lit_242), heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_j_249), v_t_2424}), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_lit_244)})});
            V v_cell_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2425, heff_hole()});
            V v_u_2427 = heff_setFieldPeek(v_d_248, MK_INT(1LL), v_cell_2426);
            V v_t_2428 = heff_intAdd(v_j_249, heff_strLength_lent(v_name_246, 0));
            V t_0 = v_ys_240;
            V t_1 = v_lit_241;
            V t_2 = v_lit_242;
            V t_3 = v_lit_243;
            V t_4 = v_lit_244;
            V t_5 = v_src_245;
            V t_6 = v_name_246;
            V t_7 = v_t_2428;
            V t_8 = v_u_2427;
            v_ys_240 = t_0;
            v_lit_241 = t_1;
            v_lit_242 = t_2;
            v_lit_243 = t_3;
            v_lit_244 = t_4;
            v_src_245 = t_5;
            v_name_246 = t_6;
            v_i_247 = t_7;
            v_d_248 = t_8;
            goto top;
          } else {
            heff_drop(v_s_2423);
            V t_0 = v_ys_240;
            V t_1 = v_lit_241;
            V t_2 = v_lit_242;
            V t_3 = v_lit_243;
            V t_4 = v_lit_244;
            V t_5 = v_src_245;
            V t_6 = v_name_246;
            V t_7 = heff_intAdd(v_j_249, MK_INT(1LL));
            V t_8 = v_d_248;
            v_ys_240 = t_0;
            v_lit_241 = t_1;
            v_lit_242 = t_2;
            v_lit_243 = t_3;
            v_lit_244 = t_4;
            v_src_245 = t_5;
            v_name_246 = t_6;
            v_i_247 = t_7;
            v_d_248 = t_8;
            goto top;
          }
        } else {
          heff_drop(v_c_2421);
          V t_0 = v_ys_240;
          V t_1 = v_lit_241;
          V t_2 = v_lit_242;
          V t_3 = v_lit_243;
          V t_4 = v_lit_244;
          V t_5 = v_src_245;
          V t_6 = v_name_246;
          V t_7 = heff_intAdd(v_j_249, MK_INT(1LL));
          V t_8 = v_d_248;
          v_ys_240 = t_0;
          v_lit_241 = t_1;
          v_lit_242 = t_2;
          v_lit_243 = t_3;
          v_lit_244 = t_4;
          v_src_245 = t_5;
          v_name_246 = t_6;
          v_i_247 = t_7;
          v_d_248 = t_8;
          goto top;
        }
      }
    } else {
      heff_drop(v_t_2411);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_src_245;
      V t_6 = v_name_246;
      V t_7 = heff_intAdd(v_j_249, MK_INT(1LL));
      V t_8 = v_d_248;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_src_245 = t_5;
      v_name_246 = t_6;
      v_i_247 = t_7;
      v_d_248 = t_8;
      goto top;
    }
  }
}
V g_prelude_2e_2b_2b_24f1960751014x547354513_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a8 = a[8]; V r = g_prelude_2e_2b_2b_24f1960751014x547354513_24dps(a0, a1, a2, a3, a4, a5, a6, a[7], a8); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a8); return r;
}
Clo g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps_entry, 6, 0};

V g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps(V v_ys_240, V v_owner_241, V v_launch_242, V v_i_243, V v_x4_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_i_243);
    return heff_setField(heff_dup(v_d_245), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_244, 0);
    V v_rest_247 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_name_248 = heff_field(v_x41_246, 0);
      V v_limit_249 = heff_field(v_x41_246, 1);
      V v_ru_24x41_246_24MkPair = heff_take_reuse_n(v_x41_246, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_243), NTAG(TAG_Nil)});
      V v_x_2411 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(v_owner_241), heff_dup(v_launch_242), v_t_2410, v_name_248, NTAG(TAG_Nil), v_limit_249});
      V v_cell_2412 = heff_tag_at_n(v_ru_24x41_246_24MkPair, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_245, MK_INT(1LL), v_cell_2412);
      V t_0 = v_ys_240;
      V t_1 = v_owner_241;
      V t_2 = v_launch_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      V t_4 = v_rest_247;
      V t_5 = v_u_2413;
      v_ys_240 = t_0;
      v_owner_241 = t_1;
      v_launch_242 = t_2;
      v_i_243 = t_3;
      v_x4_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a5 = a[5]; V r = g_prelude_2e_2b_2b_24f1876770336x1656095219_24dps(a0, a1, a2, a[3], a[4], a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a5); return r;
}
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2_lam0(V self, V *args);
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1963041714x1343204084_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1963041714x1343204084_24tok2_entry, 4, 0};

V g_prelude_2etraverse_24s1963041714x1343204084_24tok2(V v_tok_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return heff_tail(v_p_242, 2, (V[]){NTAG(TAG_Nil), v_p_243});
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_246 = v_x_244;
    V v_p_247 = heff_tag_at_n(v_tok_240, TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply0, 2, (V[]){v_xs_245, v_p_242});
    V v_p_248 = v_p_243;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_At: {
      V v_x11_249 = heff_field(v_x1_246, 0);
      V v_sp_2410 = heff_field(v_x1_246, 1);
      heff_take_n(v_x1_246, 3ULL, 2);
      switch (heff_tag_of(v_x11_249)) {
      case TAG_ExplicitParam: {
        V v_x_2411 = heff_field(v_x11_249, 0);
        V v_t_2413 = heff_field(v_x11_249, 2);
        heff_take_n(v_x11_249, 5ULL, 3);
        V v_n_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_n_2414 = heff_field(v_t_2413, 0);
          V v_sp_2415 = heff_field(v_t_2413, 1);
          heff_take_n(v_t_2413, 3ULL, 2);
          v_n_2416 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x2_241_24Cons, v_sp_2415, v_n_2414));
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        V v_t_2417 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2416));
        return heff_tail(v_t_2417, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_prelude_2etraverse_24s1963041714x1343204084_24tok2_lam0, 1, 3, (V[]){v_sp_2410, v_x_2411, v_p_247}), v_p_248});
      }
      case TAG_ImplicitParam: {
        V v_x_2420 = heff_field(v_x11_249, 0);
        V v_t_2422 = heff_field(v_x11_249, 2);
        heff_take_n(v_x11_249, 5ULL, 3);
        V v_n_2425;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_At: {
          V v_n_2423 = heff_field(v_t_2422, 0);
          V v_sp_2424 = heff_field(v_t_2422, 1);
          heff_take_n(v_t_2422, 3ULL, 2);
          v_n_2425 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x2_241_24Cons, v_sp_2424, v_n_2423));
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2426 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2425));
        return heff_tail(v_t_2426, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_prelude_2etraverse_24s1963041714x1343204084_24tok2_lam1, 1, 3, (V[]){v_sp_2410, v_x_2420, v_p_247}), v_p_248});
      }
      default: return heff_nomatch(v_x11_249);
      }
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1963041714x1343204084_24tok2(a[0], a[1], a[2], a[3]);
}
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_sp_2410 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_2410, v_x_2411, v_x_2418, NTAG(TAG_Expl)});
  return (g_prelude_2etraverse_24s1310917876x950458632_24apply0(v_p_247, v_t_2419));
}
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  V v_sp_2410 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_2410, v_x_2420, v_x_2427, NTAG(TAG_Impl)});
  return (g_prelude_2etraverse_24s1310917876x950458632_24apply0(v_p_247, v_t_2428));
}