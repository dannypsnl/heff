// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Hole 35555
#define TAG_MkArm 55352
#define TAG_SetField 47531
#define LBL_arity 294440695
#define LBL_count 296209705
#define LBL_key 315609
#define LBL_underLam 296337946
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_clo;
V g_heff_2ecompile_2etrmc_2eappendEnds(V, V);
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo;
V g_heff_2ecompile_2etrmc_2earound(V, V);
V g_heff_2ecompile_2etrmc_2earound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2earound_clo;
V g_heff_2ecompile_2etrmc_2echainHole(V);
V g_heff_2ecompile_2etrmc_2echainHole_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2echainHole_clo;
V g_heff_2ecompile_2etrmc_2echainTo(V, V, V);
V g_heff_2ecompile_2etrmc_2echainTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2echainTo_clo;
V g_heff_2ecompile_2etrmc_2econsEnds(V, V);
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2econsEnds_clo;
V g_heff_2ecompile_2etrmc_2egather(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egather_clo;
V g_heff_2ecompile_2etrmc_2ehole_get(void);
V g_heff_2ecompile_2etrmc_2eholesAt(V, V);
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eholesAt_clo;
V g_heff_2ecompile_2etrmc_2einitOf(V);
V g_heff_2ecompile_2etrmc_2einitOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2einitOf_clo;
V g_heff_2ecompile_2etrmc_2einitOf_24dps(V, V);
V g_heff_2ecompile_2etrmc_2einitOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2einitOf_24dps_clo;
V g_heff_2ecompile_2etrmc_2eletsAround_24dps(V, V, V);
V g_heff_2ecompile_2etrmc_2eletsAround_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eletsAround_24dps_clo;
HeffT2 g_heff_2ecompile_2etrmc_2eprodCall_24cpr(V, V, V);
V g_heff_2ecompile_2etrmc_2eprodStart(V, V, V, V);
V g_heff_2ecompile_2etrmc_2eprodStart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eprodStart_clo;
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327(V, V, V, V, V);
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_clo;
V g_heff_2ecompile_2etrmc_2eprodWays(V, V);
V g_heff_2ecompile_2etrmc_2eprodWays_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eprodWays_clo;
V g_heff_2ecompile_2etrmc_2eselfCall(V, V);
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eselfCall_clo;
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void);
V g_heff_2ecompile_2etrmc_2estartAcc(V, V, V);
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartAcc_clo;
V g_heff_2ecompile_2etrmc_2eunbound(V, V);
V g_heff_2ecompile_2etrmc_2eunbound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eunbound_clo;
V g_heff_2ecompile_2etrmc_2eunbound_24dps(V, V, V);
V g_heff_2ecompile_2etrmc_2eunbound_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eunbound_24dps_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;

static V g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2esetFieldPrim_st;
static V g_heff_2ecompile_2etrmc_2esetFieldPrim_init(void) {
  return NTAG(TAG_SetField);
}
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2esetFieldPrim_st)) return g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2esetFieldPrim_val, &g_heff_2ecompile_2etrmc_2esetFieldPrim_st, g_heff_2ecompile_2etrmc_2esetFieldPrim_init);
}
HEFF_TAG_LIT(g_heff_2ecompile_2etrmc_2ehole_lit0, TAG_EPrimCall, 2, NTAG(TAG_Hole), NTAG(TAG_Nil));

static V g_heff_2ecompile_2etrmc_2ehole_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2ehole_st;
static V g_heff_2ecompile_2etrmc_2ehole_init(void) {
  return ((V)&g_heff_2ecompile_2etrmc_2ehole_lit0);
}
V g_heff_2ecompile_2etrmc_2ehole_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2ehole_st)) return g_heff_2ecompile_2etrmc_2ehole_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2ehole_val, &g_heff_2ecompile_2etrmc_2ehole_st, g_heff_2ecompile_2etrmc_2ehole_init);
}
Clo g_heff_2ecompile_2etrmc_2einitOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2einitOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2einitOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
      V t_0 = v_x12_243;
      V t_1 = v_u_247;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2etrmc_2einitOf_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2einitOf_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2etrmc_2eselfCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eselfCall_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eselfCall(V v_s_240, V v_x2_241) {
top: ;
  V v_key_242 = heff_take_field(v_s_240, 0);
  V v_arity_243 = heff_get_n(v_s_240, 1, 2);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_g_2427 = heff_field(v_x2_241, 0);
    V v_args_2428 = heff_field(v_x2_241, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_g_2427, v_key_242, 0) && ({ V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2428)); int c_ = heff_intEq_c_lent(v_t_2443, v_arity_243, 0); heff_drop(v_t_2443); c_; })));
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return v_ret_24bool;
  }
  case TAG_EInt: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_242);
    heff_drop(v_arity_243);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2eselfCall(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2etrmc_2econsEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2econsEnds_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2econsEnds(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2418));
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 2);
      V v_t_2423 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_x_2421));
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_x_2421);
        heff_drop(v_t_2423);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2423);
        V t_0 = v_s_240;
        V t_1 = v_x_2421;
        v_s_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x1_2420);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2etrmc_2econsEnds(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2etrmc_2eholesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eholesAt_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eholesAt(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2418)));
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      heff_drop(v_args_2418);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24Cons = heff_take_reuse_n(v_x1_2420, 1ULL, 2);
      V v_t_2423 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_x_2421));
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_x_2421);
        heff_drop(v_t_2423);
        V v_t_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2418; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2418); r_; });
        return heff_tag_at_n(v_ru_24x1_2420_24Cons, TAG_Cons, 2, (V[]){heff_intSub(v_t_2424, MK_INT(1LL)), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_args_2418);
        heff_drop_cell(v_ru_24x1_2420_24Cons, 2);
        heff_drop(v_t_2423);
        V v_t_2425 = (g_heff_2ecompile_2etrmc_2econsEnds(v_s_240, heff_dup(v_x_2421)));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_t_2425);
          V t_0 = v_s_240;
          V t_1 = v_x_2421;
          v_s_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_x_2421);
          heff_drop(v_t_2425);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_x1_2420);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2etrmc_2eholesAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartAcc_str0, 2, "s$");
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2estartAcc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2estartAcc_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2estartAcc(V v_s_240, V v_ak_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2etrmc_2eappendEnds(v_s_240, v_e_242));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_e_242)) {
    case TAG_EPrimCall: {
      V v_it2_245 = heff_dup(heff_field(v_e_242, 1));
      switch (heff_tag_of(v_it2_245)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam0, 1, 1, (V[]){v_e_242});
      }
      case TAG_Cons: {
        V v_a_247 = heff_field(v_it2_245, 0);
        V v_it22_248 = heff_field(v_it2_245, 1);
        heff_take_n(v_it2_245, 3ULL, 2);
        switch (heff_tag_of(v_it22_248)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          heff_drop(v_ak_241);
          heff_drop(v_a_247);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam1, 1, 1, (V[]){v_e_242});
        }
        case TAG_Cons: {
          V v_r_2410 = heff_field(v_it22_248, 0);
          V v_it222_2411 = heff_field(v_it22_248, 1);
          heff_take_n(v_it22_248, 3ULL, 2);
          switch (heff_tag_of(v_it222_2411)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 2);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam2, 1, 4, (V[]){v_s_240, v_ak_241, v_r_2410, v_a_247});
          }
          case TAG_Cons: {
            heff_take_n(v_it222_2411, 0ULL, 2);
            heff_drop(v_s_240);
            heff_drop(v_ak_241);
            heff_drop(v_a_247);
            heff_drop(v_r_2410);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam3, 1, 1, (V[]){v_e_242});
          }
          default: return heff_nomatch(v_it222_2411);
          }
        }
        default: return heff_nomatch(v_it22_248);
        }
      }
      default: return heff_nomatch(v_it2_245);
      }
    }
    default: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam4, 1, 1, (V[]){v_e_242});
    }
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_ak_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam5, 1, 1, (V[]){v_e_242});
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2estartAcc(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_246});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_249});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_ak_241 = heff_env(self)[1];
  V v_r_2410 = heff_env(self)[2];
  V v_a_247 = heff_env(self)[3];
  V v_x_2413 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartAcc_str0), heff_intShow(heff_dup(v_n_2412)));
  heff_clo_take(self, 4);
  V v_m_2414 = (g_heff_2ecompile_2etrmc_2egather(v_s_240, v_ak_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2413)}), v_r_2410));
  V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){heff_intAdd(v_n_2412, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2413, v_a_247, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2420});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args) {
  V v_n_2421 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2421});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args) {
  V v_n_2422 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2422});
}
V g_heff_2ecompile_2etrmc_2echainTo_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2echainTo_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2echainTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2echainTo_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2echainTo(V v_v_240, V v_vs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_take_n(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_e_242, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2419 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 2ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2etrmc_2einitOf(heff_dup(v_args_2419)));
    V v_t_2430 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2echainTo_lam0, 1, 1, (V[]){heff_dup(v_vs_241)}); V a_1 = v_t_2421; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2421); r_; });
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      V v_x1_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2419));
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x_2432 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 2);
        V v_t_2473;
        switch (heff_tag_of(v_x_2432)) {
        case TAG_EVar: {
          V v_w_2434 = heff_dup(heff_field(v_x_2432, 0));
          v_t_2473 = heff_bool(heff_strEq_c_lent(v_v_240, v_w_2434, 0));
          heff_drop(v_w_2434);
          break;
        }
        case TAG_EGlobal: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_ELam: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EApp: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_ELet: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_ERecord: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EProj: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EMatch: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrim: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EPrimCall: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_ECall: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EFloat: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EStr: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EBytes: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EFixed: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EFloat32: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EAbandon: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EBool: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_ESet: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EValues: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        case TAG_EFix: {
          v_t_2473 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x_2432);
        }
        if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
          heff_drop(v_x_2432);
          heff_drop(v_t_2473);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2473);
          V t_0 = v_v_240;
          V t_1 = v_vs_241;
          V t_2 = v_x_2432;
          v_v_240 = t_0;
          v_vs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
      }
      default: return heff_nomatch(v_x1_2431);
      }
    } else {
      heff_drop(v_args_2419);
      heff_drop(v_t_2430);
      return NTAG(TAG_False);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_e_242, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2etrmc_2echainTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2echainTo(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2etrmc_2echainTo_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_e_2422 = heff_env(self)[0];
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2422), NTAG(TAG_Nil)});
  V v_t_2426 = (g_heff_2ecompile_2eir_2ecountW(v_x_2424, MK_INT(0LL), v_t_2425));
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2422, NTAG(TAG_Nil)});
  V v_t_2428 = ({ V a_0 = v_x_2424; V a_1 = v_t_2427; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2424); r_; });
  V v_t_2429 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2426, v_t_2428}), 0, 2);
  V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_t_2429, MK_INT(0LL), 2));
  heff_drop(v_t_2429);
  return v_ret_24bool;
}
V g_heff_2ecompile_2etrmc_2echainTo_lam0(V self, V *args) {
  V v_e_2422 = args[0];
  V v_vs_241 = heff_env(self)[0];
  V v_t_2423 = (g_heff_2ecompile_2eir_2eisValue(v_e_2422));
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_t_2423);
    heff_clo_take(self, 1);
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2echainTo_lam1, 1, 1, (V[]){v_e_2422}); V a_1 = v_vs_241; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_vs_241); r_; });
  } else {
    heff_drop(v_e_2422);
    heff_drop(self);
    heff_drop(v_t_2423);
    return NTAG(TAG_False);
  }
}
Clo g_heff_2ecompile_2etrmc_2echainHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2echainHole_entry, 1, 0};

V g_heff_2ecompile_2etrmc_2echainHole(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return MK_INT(0LL);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    V v_args_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 3);
    V v_x1_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2417)));
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nil: {
      heff_drop(v_args_2417);
      return MK_INT(0LL);
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x1_2419, 0);
      heff_take_n(v_x1_2419, 1ULL, 2);
      V v_t_2461;
      switch (heff_tag_of(v_x_2420)) {
      case TAG_EVar: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2461 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2420);
      }
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop(v_args_2417);
        heff_drop(v_t_2461);
        V t_0 = v_x_2420;
        v_e_240 = t_0;
        goto top;
      } else {
        heff_drop(v_x_2420);
        heff_drop(v_t_2461);
        V v_t_2462 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2417; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2417); r_; });
        return heff_intSub(v_t_2462, MK_INT(1LL));
      }
    }
    default: return heff_nomatch(v_x1_2419);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_e_240, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    return MK_INT(0LL);
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return MK_INT(0LL);
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2etrmc_2echainHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2echainHole(a[0]);
}
V g_heff_2ecompile_2etrmc_2eprodWays_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eprodWays_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eprodWays_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eprodWays(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_s_240;
    V t_1 = v_b_2410;
    v_s_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EMatch: {
    V v_c_2420 = heff_field(v_e_241, 0);
    V v_arms_2421 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    HeffT2 v_t_2422 = (g_heff_2ecompile_2etrmc_2eprodCall_24cpr(heff_dup(v_s_240), v_c_2420, v_arms_2421));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_x11_2425 = v_field_2424;
        heff_drop(v_x11_2425);
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, 3ULL, (V[]){v_c_2420, v_arms_2421}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_c_2420);
        heff_drop_cell(v_ru_24e_241_24EMatch, 2);
        heff_drop(v_field_2424);
        V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2421));
        return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2eprodWays_lam0, 2, 1, (V[]){heff_dup(v_s_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2426); r_; });
      }
    }
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EBool: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_ESet: {
    V v_b_2449 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_s_240;
    V t_1 = v_b_2449;
    v_s_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_EValues: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eprodWays_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2etrmc_2eprodWays(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2etrmc_2eprodWays_lam0(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_s_240 = heff_env(self)[0];
  V v_t_2432;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_x_2428, 2);
    heff_take_n(v_x_2428, 4ULL, 3);
    v_t_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  heff_clo_take(self, 1);
  V v_t_2433 = ({ V a_0 = v_s_240; V a_1 = v_t_2432; V r_ = (g_heff_2ecompile_2etrmc_2eprodWays(a_0, a_1)); heff_drop(v_s_240); r_; });
  return (g_prelude_2e_2b_2b(v_t_2433, v_acc_2427));
}
Clo g_heff_2ecompile_2etrmc_2eletsAround_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eletsAround_24dps_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2eletsAround_24dps(V v_x1_240, V v_b_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), heff_dup(v_b_241));
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_243, 0);
      V v_e_246 = heff_field(v_x11_243, 1);
      V v_cell_247 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_245), heff_dup(v_e_246), heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(2LL), v_cell_247);
      V t_0 = v_rest_244;
      V t_1 = v_b_241;
      V t_2 = v_u_248;
      v_x1_240 = t_0;
      v_b_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2etrmc_2eletsAround_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2etrmc_2eletsAround_24dps(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2etrmc_2eunbound_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eunbound_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eunbound_24dps_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2eunbound_24dps(V v_s_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EGlobal: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_ELam: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EApp: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_ELet: {
    V v_r_249 = heff_field(v_e_241, 0);
    V v_a_2410 = heff_field(v_e_241, 1);
    V v_b_2411 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_s_2412 = heff_dup(v_s_240);
    V v_r_2413 = v_r_249;
    V v_a_2414 = v_a_2410;
    V v_b_2415 = (g_heff_2ecompile_2etrmc_2eunbound(v_s_240, v_b_2411));
    V v_t_2416 = (g_heff_2ecompile_2etrmc_2eselfCall(v_s_2412, v_a_2414));
    if (((heff_dup(v_t_2416) == NTAG(TAG_True)) && ({ V v_c_2460 = (g_heff_2ecompile_2etrmc_2earound(v_r_2413, heff_dup(v_b_2415))); int c_ = ((heff_dup(v_c_2460) == NTAG(TAG_True)) && ({ V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2415), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2418 = (g_heff_2ecompile_2eir_2ecountW(v_r_2413, MK_INT(0LL), heff_dup(v_t_2417))); int c_ = ({ V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2415), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2420 = (g_heff_2ecompile_2eir_2elamW(v_r_2413, heff_dup(v_t_2419))); int c_ = ({ V v_t_2461 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2418), heff_dup(v_t_2420)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_2461, MK_INT(1LL), 2); heff_drop(v_t_2461); c_; }); heff_drop(v_t_2420); c_; }); heff_drop(v_t_2419); c_; }); heff_drop(v_t_2418); c_; }); heff_drop(v_t_2417); c_; })); heff_drop(v_c_2460); c_; }))) {
      heff_drop(v_t_2416);
      V v_t_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = v_r_2413; V a_2 = v_a_2414; V a_3 = v_b_2415; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_r_2413); heff_drop(v_a_2414); r_; });
      return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2421);
    } else {
      heff_drop(v_t_2416);
      return heff_setField(heff_dup(v_d_242), MK_INT(2LL), heff_tag_n(TAG_ELet, 3, (V[]){v_r_2413, v_a_2414, v_b_2415}));
    }
  }
  case TAG_ERecord: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EProj: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_ETag: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EMatch: {
    V v_c_2431 = heff_field(v_e_241, 0);
    V v_arms_2432 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2438 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2etrmc_2eunbound_24dps_lam0, 1, 1, (V[]){heff_dup(v_s_240)}), v_arms_2432));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_c_2431, v_t_2438}));
  }
  case TAG_EPrim: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EPrimCall: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_ECall: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EInt: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EStr: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EBytes: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EFixed: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EFloat32: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EAbandon: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EBool: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_ESet: {
    V v_xs_2452 = heff_field(v_e_241, 0);
    V v_a_2453 = heff_field(v_e_241, 1);
    V v_b_2454 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2455 = heff_tag_re_n(v_ru_24e_241_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2452, v_a_2453, heff_hole()});
    V v_u_2456 = heff_setFieldPeek(v_d_242, MK_INT(2LL), v_cell_2455);
    V t_0 = v_s_240;
    V t_1 = v_b_2454;
    V t_2 = v_u_2456;
    v_s_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_EValues: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  case TAG_EFix: {
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eunbound_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2etrmc_2eunbound_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2etrmc_2eunbound_24dps_lam0(V self, V *args) {
  V v_x2_2433 = args[0];
  V v_s_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkArm: {
    V v_t_2434 = heff_field(v_x2_2433, 0);
    V v_vs_2435 = heff_field(v_x2_2433, 1);
    V v_b_2436 = heff_field(v_x2_2433, 2);
    V v_ru_24x2_2433_24MkArm = heff_take_reuse_n(v_x2_2433, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2437 = ({ V a_0 = v_s_240; V a_1 = v_b_2436; V r_ = (g_heff_2ecompile_2etrmc_2eunbound(a_0, a_1)); heff_drop(v_s_240); r_; });
    return heff_tag_re_n(v_ru_24x2_2433_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2434, v_vs_2435, v_t_2437});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam4(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_entry, 5, 0};

V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327(V v_lit_240, V v_lit_241, V v_lit_242, V v_s_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EGlobal: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_ELet: {
    V v_x_2411 = heff_field(v_e_244, 0);
    V v_a_2412 = heff_field(v_e_244, 1);
    V v_b_2413 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    V v_m_2414 = (g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327(v_lit_240, v_lit_241, v_lit_242, v_s_243, v_b_2413));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam0, 1, 3, (V[]){v_m_2414, v_x_2411, v_a_2412});
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EMatch: {
    V v_c_2428 = heff_field(v_e_244, 0);
    V v_arms_2429 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EMatch = heff_take_reuse_n(v_e_244, 3ULL, 2);
    HeffT2 v_t_2430 = (g_heff_2ecompile_2etrmc_2eprodCall_24cpr(heff_dup(v_s_243), v_c_2428, v_arms_2429));
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_x11_2433 = v_field_2432;
        heff_drop(v_x11_2433);
        return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_tag_re_n(v_ru_24e_244_24EMatch, TAG_EMatch, 2, 3ULL, (V[]){v_c_2428, v_arms_2429})));
      } else {
        heff_drop_cell(v_ru_24e_244_24EMatch, 2);
        heff_drop(v_field_2432);
        V v_m_2443 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam1, 1, 4, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_s_243)}), v_arms_2429));
        return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam3, 1, 2, (V[]){v_m_2443, v_c_2428});
      }
    }
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EBytes: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EBool: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_ESet: {
    V v_xs_2461 = heff_field(v_e_244, 0);
    V v_a_2462 = heff_field(v_e_244, 1);
    V v_b_2463 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    V v_m_2464 = (g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327(v_lit_240, v_lit_241, v_lit_242, v_s_243, v_b_2463));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam4, 1, 3, (V[]){v_m_2464, v_xs_2461, v_a_2462});
  }
  case TAG_EValues: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2etrmc_2eprodStart(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_e_244));
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327(a0, a1, a2, a3, a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam0(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_a_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2411, v_a_2412, v_x_2417}), v_n_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam2(V self, V *args) {
  V v_n_2439 = args[0];
  V v_m_2438 = heff_env(self)[0];
  V v_t_2435 = heff_env(self)[1];
  V v_vs_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2440 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_n_2439}));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_n_2442 = heff_field(v_x2_2440, 1);
    V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2435, v_vs_2436, v_x_2441}), v_n_2442});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam1(V self, V *args) {
  V v_x2_2434 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_s_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkArm: {
    V v_t_2435 = heff_field(v_x2_2434, 0);
    V v_vs_2436 = heff_field(v_x2_2434, 1);
    V v_b_2437 = heff_field(v_x2_2434, 2);
    heff_take_n(v_x2_2434, 7ULL, 3);
    heff_clo_take(self, 4);
    V v_m_2438 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_s_243; V a_4 = v_b_2437; V r_ = (g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); heff_drop(v_s_243); r_; });
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam2, 1, 3, (V[]){v_m_2438, v_t_2435, v_vs_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam3(V self, V *args) {
  V v_n_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_c_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_n_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_n_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_c_2428, v_x_2446}), v_n_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_lam4(V self, V *args) {
  V v_n_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_xs_2461 = heff_env(self)[1];
  V v_a_2462 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_n_2465}));
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_n_2468 = heff_field(v_x2_2466, 1);
    V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2461, v_a_2462, v_x_2467}), v_n_2468});
  }
  default: return heff_nomatch(v_x2_2466);
  }
}