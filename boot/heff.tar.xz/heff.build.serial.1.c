// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
HeffT3 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT3 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo;
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps(V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
HeffT3 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
HeffT3 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT3 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
HeffT3 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
HeffT3 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V, V, V, V);
HeffT3 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V, V, V);
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2eprimitive_2eprimOfName(V);
V g_heff_2eelab_2eprimitive_2eprimOfName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimOfName_clo;
double g_heff_2esyntax_2esurface_2efloatOfText_w(V);
V g_heff_2esyntax_2esurface_2efloatOfText(V);
V g_heff_2esyntax_2esurface_2efloatOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfText_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, heff_dup(v_lit_240)), v_x_243);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = ({ V a_0 = v_lit_240; V a_1 = v_xs_244; V a_2 = v_rest_242; V a_3 = v_cell_247; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_rest_242); r_; });
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(v_rest_242);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(v_lit_240, v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = ({ V a_0 = v_a_247; V a_1 = v_a_245; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_a_247); r_; });
      V v_t_249 = heff_intShow(heff_strLength_lent(v_a_246, 0));
      V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, heff_dup(v_lit_240)), v_a_246);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_t_248});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_dup(v_rest_241);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_x_242, v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SmallU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1), v_rest_241})});
    }
    case TAG_LargeU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3), v_rest_241})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_x2_240, 0);
    V v_t_244 = ({ V a_0 = heff_dup(v_e_243); V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4), v_t_244});
  }
  case TAG_SFunction: {
    V v_level_245 = heff_field(v_x2_240, 0);
    V v_dom_246 = heff_field(v_x2_240, 1);
    V v_cod_247 = heff_field(v_x2_240, 2);
    V v_implicit_248 = heff_field(v_x2_240, 3);
    V v_dflt_249 = heff_field(v_x2_240, 4);
    V v_t_2410;
    switch (heff_tag_of(v_level_245)) {
    case TAG_Small: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5);
      break;
    }
    case TAG_Large: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7);
      break;
    }
    default: heff_nomatch(v_level_245);
    }
    V v_t_2411;
    switch (heff_tag_of(v_implicit_248)) {
    case TAG_Expl: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10);
      break;
    }
    default: heff_nomatch(v_implicit_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_dflt_249)) {
    case TAG_Nothing: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2412 = heff_field(v_dflt_249, 0);
      V v_t_2413 = ({ V a_0 = heff_dup(v_d_2412); V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12), v_t_2413});
      break;
    }
    default: heff_nomatch(v_dflt_249);
    }
    V v_rest_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2414});
    V v_rest_2423;
    switch (heff_tag_of(v_cod_247)) {
    case TAG_MkAbs: {
      V v_x_2416 = heff_field(v_cod_247, 0);
      V v_e_2417 = heff_field(v_cod_247, 1);
      V v_t_2418 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2417, v_rest_2415));
      V v_t_2419 = heff_intShow(heff_strLength_lent(v_x_2416, 0));
      V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13)), heff_dup(v_x_2416));
      v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2418})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2421 = heff_field(v_cod_247, 0);
      V v_t_2422 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2421, v_rest_2415));
      v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15), v_t_2422});
      break;
    }
    default: heff_nomatch(v_cod_247);
    }
    V v_cell_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16), heff_hole()});
    V v_cell_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2426 = heff_setField(heff_dup(v_cell_2424), MK_INT(1LL), v_cell_2425);
    V v_u_2427 = ({ V a_0 = v_dom_246; V a_1 = v_rest_2423; V a_2 = v_u_2426; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(a_0, a_1, a_2)); heff_drop(v_u_2426); r_; });
    heff_drop(v_u_2427);
    return v_cell_2424;
  }
  case TAG_SRecord: {
    V v_level_2428 = heff_field(v_x2_240, 0);
    V v_fs_2429 = heff_field(v_x2_240, 1);
    V v_ds_2430 = heff_field(v_x2_240, 2);
    V v_keys_2431 = heff_dup(heff_rfield(v_ds_2430, 0));
    V v_values_2432 = heff_dup(heff_rfield(v_ds_2430, 2));
    V v_keys_2433 = heff_dup(heff_rfield(v_fs_2429, 0));
    V v_values_2434 = heff_dup(heff_rfield(v_fs_2429, 2));
    V v_t_2435;
    switch (heff_tag_of(v_level_2428)) {
    case TAG_Small: {
      v_t_2435 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17);
      break;
    }
    case TAG_Large: {
      v_t_2435 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2435 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19);
      break;
    }
    default: heff_nomatch(v_level_2428);
    }
    V v_xs_2436 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2431), heff_arrayToList(v_values_2432)));
    V v_i_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2436));
    V v_t_2438 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20); V a_1 = v_xs_2436; V a_2 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(a_0, a_1, a_2)); heff_drop(v_rest_241); r_; });
    V v_rest_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2437), v_t_2438});
    V v_xs_2440 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2433), heff_arrayToList(v_values_2434)));
    V v_i_2441 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2440));
    V v_t_2442 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21); V a_1 = v_xs_2440; V a_2 = v_rest_2439; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(a_0, a_1, a_2)); heff_drop_tag(v_rest_2439, 2); r_; });
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2441), v_t_2442});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2443})});
  }
  case TAG_SSum: {
    V v_vs_2444 = heff_field(v_x2_240, 0);
    V v_keys_2445 = heff_dup(heff_rfield(v_vs_2444, 0));
    V v_values_2446 = heff_dup(heff_rfield(v_vs_2444, 2));
    V v_xs_2447 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2445), heff_arrayToList(v_values_2446)));
    V v_i_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2447));
    V v_t_2449 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_xs_2447; V a_4 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_241); r_; });
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2448), v_t_2449});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24), v_t_2450});
  }
  case TAG_SIsTy: {
    V v_t2_2451 = heff_field(v_x2_240, 0);
    V v_cell_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25), heff_hole()});
    V v_u_2453 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(v_t2_2451, v_rest_241, v_cell_2452));
    heff_drop(v_u_2453);
    return v_cell_2452;
  }
  case TAG_SPrimInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26), v_rest_241});
  }
  case TAG_SPrimFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27), v_rest_241});
  }
  case TAG_SPrimString: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28), v_rest_241});
  }
  case TAG_SPrimRune: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29), v_rest_241});
  }
  case TAG_SPrimArray: {
    V v_t2_2454 = heff_field(v_x2_240, 0);
    V v_cell_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30), heff_hole()});
    V v_u_2456 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(v_t2_2454, v_rest_241, v_cell_2455));
    heff_drop(v_u_2456);
    return v_cell_2455;
  }
  case TAG_SFixed: {
    V v_w_2457 = heff_field(v_x2_240, 0);
    V v_t_2458;
    switch (heff_tag_of(v_w_2457)) {
    case TAG_I8: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31);
      break;
    }
    case TAG_I16: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32);
      break;
    }
    case TAG_I32: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33);
      break;
    }
    case TAG_I64: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34);
      break;
    }
    case TAG_U8: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35);
      break;
    }
    case TAG_U16: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36);
      break;
    }
    case TAG_U32: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37);
      break;
    }
    case TAG_U64: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38);
      break;
    }
    case TAG_F32: {
      v_t_2458 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39);
      break;
    }
    default: heff_nomatch(v_w_2457);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str54, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str55, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_242), heff_dup(v_rest_241)});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0), v_t_243});
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_244, 0));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1)), v_x_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_dup(v_rest_241)})});
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = heff_dup(v_rest_241); V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_247); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3), v_t_248});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_x2_240, 0);
    V v_a_2410 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2411 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2410, v_rest_241));
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24SApp, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4), heff_hole()});
    V v_u_2413 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_f_249, v_rest_2411, v_cell_2412));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_SLam: {
    V v_t_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2423;
    switch (heff_tag_of(v_b_2415)) {
    case TAG_MkAbs: {
      V v_x_2416 = heff_field(v_b_2415, 0);
      V v_e_2417 = heff_field(v_b_2415, 1);
      V v_ru_24b_2415_24MkAbs = heff_take_reuse_n(v_b_2415, 3ULL, 2);
      V v_t_2418 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2417, v_rest_241));
      V v_t_2419 = heff_intShow(heff_strLength_lent(v_x_2416, 0));
      V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5)), v_x_2416);
      v_rest_2423 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6), heff_tag_at_n(v_ru_24b_2415_24MkAbs, TAG_Cons, 2, (V[]){v_t_2420, v_t_2418})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2421 = heff_field(v_b_2415, 0);
      heff_take_n(v_b_2415, 1ULL, 1);
      V v_t_2422 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2421, v_rest_241));
      v_rest_2423 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7), v_t_2422});
      break;
    }
    default: heff_nomatch(v_b_2415);
    }
    V v_t_2424 = ({ V a_0 = v_t_2414; V a_1 = v_rest_2423; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8), v_t_2424});
  }
  case TAG_SCons: {
    V v_d_2425 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_keys_2426 = heff_take_field(v_d_2425, 0);
    V v_values_2427 = heff_get_n(v_d_2425, 2, 3);
    V v_xs_2428 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2426), heff_arrayToList(v_values_2427)));
    V v_i_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2428));
    V v_t_2430 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9), v_xs_2428, v_rest_241));
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2429), v_t_2430});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10), v_t_2431});
  }
  case TAG_SProj: {
    V v_e2_2432 = heff_field(v_x2_240, 0);
    V v_l_2433 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2434 = heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11), heff_hole()});
    V v_t_2435 = heff_intShow(heff_strLength_lent(v_l_2433, 0));
    V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12)), v_l_2433);
    V v_u_2437 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, heff_dup(v_rest_241)}), v_cell_2434));
    heff_drop(v_u_2437);
    return v_cell_2434;
  }
  case TAG_STag: {
    V v_t_2438 = heff_field(v_x2_240, 0);
    V v_args_2439 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_xs_2440 = heff_arrayToList(v_args_2439);
    V v_i_2441 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2440));
    V v_t_2442 = ({ V a_0 = v_xs_2440; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2440); r_; });
    V v_t_2443 = heff_intShow(heff_strLength_lent(v_t_2438, 0));
    V v_t_2444 = heff_strAppend(heff_strAppend(v_t_2443, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13)), v_t_2438);
    V v_t_2445 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2441), v_t_2442});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, v_t_2445})});
  }
  case TAG_SMatch: {
    V v_e2_2446 = heff_field(v_x2_240, 0);
    V v_cs_2447 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_keys_2448 = heff_take_field(v_cs_2447, 0);
    V v_values_2449 = heff_get_n(v_cs_2447, 2, 3);
    V v_xs_2450 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2448), heff_arrayToList(v_values_2449)));
    V v_i_2451 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2450));
    V v_t_2452 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16), v_xs_2450, v_rest_241));
    V v_rest_2453 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2451), v_t_2452});
    V v_cell_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17), heff_hole()});
    V v_u_2455 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2446, v_rest_2453, v_cell_2454));
    heff_drop(v_u_2455);
    return v_cell_2454;
  }
  case TAG_SSpecialize: {
    V v_e2_2456 = heff_field(v_x2_240, 0);
    V v_l_2457 = heff_field(v_x2_240, 1);
    V v_v_2458 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2459 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_v_2458, v_rest_241));
    V v_t_2460 = heff_intShow(heff_strLength_lent(v_l_2457, 0));
    V v_t_2461 = heff_strAppend(heff_strAppend(v_t_2460, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18)), v_l_2457);
    V v_rest_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, v_t_2459});
    V v_cell_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19), heff_hole()});
    V v_u_2464 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2456, v_rest_2462, v_cell_2463));
    heff_drop(v_u_2464);
    return v_cell_2463;
  }
  case TAG_SIs: {
    V v_e2_2465 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20), heff_hole()});
    V v_u_2467 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2465, heff_dup(v_rest_241), v_cell_2466));
    heff_drop(v_u_2467);
    return v_cell_2466;
  }
  case TAG_SOpaque: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21), heff_dup(v_rest_241)});
  }
  case TAG_SAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22), heff_dup(v_rest_241)});
  }
  case TAG_SRec: {
    V v_e2_2468 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2469 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23), heff_hole()});
    V v_u_2470 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2468, heff_dup(v_rest_241), v_cell_2469));
    heff_drop(v_u_2470);
    return v_cell_2469;
  }
  case TAG_SFix: {
    V v_t_2471 = heff_field(v_x2_240, 0);
    V v_b_2472 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2480;
    switch (heff_tag_of(v_b_2472)) {
    case TAG_MkAbs: {
      V v_x_2473 = heff_field(v_b_2472, 0);
      V v_e_2474 = heff_field(v_b_2472, 1);
      V v_ru_24b_2472_24MkAbs = heff_take_reuse_n(v_b_2472, 3ULL, 2);
      V v_t_2475 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2474, v_rest_241));
      V v_t_2476 = heff_intShow(heff_strLength_lent(v_x_2473, 0));
      V v_t_2477 = heff_strAppend(heff_strAppend(v_t_2476, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24)), v_x_2473);
      v_rest_2480 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25), heff_tag_at_n(v_ru_24b_2472_24MkAbs, TAG_Cons, 2, (V[]){v_t_2477, v_t_2475})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2478 = heff_field(v_b_2472, 0);
      heff_take_n(v_b_2472, 1ULL, 1);
      V v_t_2479 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2478, v_rest_241));
      v_rest_2480 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26), v_t_2479});
      break;
    }
    default: heff_nomatch(v_b_2472);
    }
    V v_t_2481 = ({ V a_0 = v_t_2471; V a_1 = v_rest_2480; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2471); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27), v_t_2481});
  }
  case TAG_SImplicit: {
    V v_x_2482 = heff_field(v_x2_240, 0);
    V v_e2_2483 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2484 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28), heff_hole()});
    V v_t_2485 = heff_intShow(heff_strLength_lent(v_x_2482, 0));
    V v_t_2486 = heff_strAppend(heff_strAppend(v_t_2485, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29)), v_x_2482);
    V v_cell_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, heff_hole()});
    V v_u_2488 = heff_setField(heff_dup(v_cell_2484), MK_INT(1LL), v_cell_2487);
    V v_u_2489 = ({ V a_0 = v_e2_2483; V a_1 = heff_dup(v_rest_241); V a_2 = v_u_2488; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(a_0, a_1, a_2)); heff_drop(v_u_2488); r_; });
    heff_drop(v_u_2489);
    return v_cell_2484;
  }
  case TAG_SPrim: {
    V v_x_2490 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2491 = ({ V a_0 = v_x_2490; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_x_2490); r_; });
    V v_t_2492 = heff_intShow(heff_strLength_lent(v_s_2491, 0));
    V v_t_2493 = heff_strAppend(heff_strAppend(v_t_2492, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30)), v_s_2491);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2493, heff_dup(v_rest_241)})});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32), heff_dup(v_rest_241)});
  }
  case TAG_SLitInt: {
    V v_i_2497 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2498 = heff_intShow(v_i_2497);
    V v_t_2499 = heff_intShow(heff_strLength_lent(v_s_2498, 0));
    V v_t_24100 = heff_strAppend(heff_strAppend(v_t_2499, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33)), v_s_2498);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24100, heff_dup(v_rest_241)})});
  }
  case TAG_SLitFloat: {
    V v_x_24101 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24102 = heff_floatShow(v_x_24101);
    V v_t_24103 = heff_intShow(heff_strLength_lent(v_s_24102, 0));
    V v_t_24104 = heff_strAppend(heff_strAppend(v_t_24103, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35)), v_s_24102);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24104, heff_dup(v_rest_241)})});
  }
  case TAG_SLitString: {
    V v_s_24105 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24106 = heff_intShow(heff_strLength_lent(v_s_24105, 0));
    V v_t_24107 = heff_strAppend(heff_strAppend(v_t_24106, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37)), v_s_24105);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, heff_dup(v_rest_241)})});
  }
  case TAG_SLitBytes: {
    V v_s_24108 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24109 = heff_intShow(heff_strLength_lent(v_s_24108, 0));
    V v_t_24110 = heff_strAppend(heff_strAppend(v_t_24109, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39)), v_s_24108);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, heff_dup(v_rest_241)})});
  }
  case TAG_SLitRune: {
    V v_c_24111 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24112 = heff_intShow(v_c_24111);
    V v_t_24113 = heff_intShow(heff_strLength_lent(v_s_24112, 0));
    V v_t_24114 = heff_strAppend(heff_strAppend(v_t_24113, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41)), v_s_24112);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24114, heff_dup(v_rest_241)})});
  }
  case TAG_SLitFixed: {
    V v_w_24115 = heff_field(v_x2_240, 0);
    V v_n_24116 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24117;
    switch (heff_tag_of(v_w_24115)) {
    case TAG_I8: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43);
      break;
    }
    case TAG_I16: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44);
      break;
    }
    case TAG_I32: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45);
      break;
    }
    case TAG_I64: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46);
      break;
    }
    case TAG_U8: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47);
      break;
    }
    case TAG_U16: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48);
      break;
    }
    case TAG_U32: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49);
      break;
    }
    case TAG_U64: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50);
      break;
    }
    case TAG_F32: {
      v_t_24117 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51);
      break;
    }
    default: heff_nomatch(v_w_24115);
    }
    V v_s_24118 = heff_intShow(v_n_24116);
    V v_t_24119 = heff_intShow(heff_strLength_lent(v_s_24118, 0));
    V v_t_24120 = heff_strAppend(heff_strAppend(v_t_24119, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52)), v_s_24118);
    V v_t_24121 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_24117, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24120, heff_dup(v_rest_241)})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53), v_t_24121});
  }
  case TAG_SLitFloat32: {
    V v_x_24122 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24123 = heff_floatShow(v_x_24122);
    V v_t_24124 = heff_intShow(heff_strLength_lent(v_s_24123, 0));
    V v_t_24125 = heff_strAppend(heff_strAppend(v_t_24124, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str54)), v_s_24123);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24125, heff_dup(v_rest_241)})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str11, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str12, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str28, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str29, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str40, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str41, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str42, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str43, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str44, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str45, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str46, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str47, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str48, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str49, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str50, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str51, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str53, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str54, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str55, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_243 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_243), v_rest_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str0), v_t_244}));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_x_245, 0));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str1)), v_x_245);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_248);
  }
  case TAG_SCode: {
    V v_t_249 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_249); r_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str3), v_t_2410}));
  }
  case TAG_SApp: {
    V v_f_2411 = heff_field(v_x2_240, 0);
    V v_a_2412 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2413 = ({ V a_0 = v_a_2412; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24SApp, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str4), heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2414);
    V t_0 = v_f_2411;
    V t_1 = v_rest_2413;
    V t_2 = v_u_2415;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SLam: {
    V v_t_2416 = heff_field(v_x2_240, 0);
    V v_b_2417 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2425;
    switch (heff_tag_of(v_b_2417)) {
    case TAG_MkAbs: {
      V v_x_2418 = heff_field(v_b_2417, 0);
      V v_e_2419 = heff_field(v_b_2417, 1);
      V v_ru_24b_2417_24MkAbs = heff_take_reuse_n(v_b_2417, 3ULL, 2);
      V v_t_2420 = ({ V a_0 = v_e_2419; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
      V v_t_2421 = heff_intShow(heff_strLength_lent(v_x_2418, 0));
      V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str5)), v_x_2418);
      v_rest_2425 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str6), heff_tag_at_n(v_ru_24b_2417_24MkAbs, TAG_Cons, 2, (V[]){v_t_2422, v_t_2420})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2423 = heff_field(v_b_2417, 0);
      heff_take_n(v_b_2417, 1ULL, 1);
      V v_t_2424 = ({ V a_0 = v_e_2423; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
      v_rest_2425 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str7), v_t_2424});
      break;
    }
    default: heff_nomatch(v_b_2417);
    }
    V v_t_2426 = ({ V a_0 = v_t_2416; V a_1 = v_rest_2425; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2416); r_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str8), v_t_2426}));
  }
  case TAG_SCons: {
    V v_d_2427 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_keys_2428 = heff_take_field(v_d_2427, 0);
    V v_values_2429 = heff_get_n(v_d_2427, 2, 3);
    V v_xs_2430 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2428), heff_arrayToList(v_values_2429)));
    V v_i_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2430));
    V v_t_2432 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str9); V a_1 = v_xs_2430; V a_2 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(a_0, a_1, a_2)); heff_drop(v_rest_241); r_; });
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2431), v_t_2432});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str10), v_t_2433}));
  }
  case TAG_SProj: {
    V v_e2_2434 = heff_field(v_x2_240, 0);
    V v_l_2435 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2436 = heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str11), heff_hole()});
    V v_u_2437 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2436);
    V v_t_2438 = heff_intShow(heff_strLength_lent(v_l_2435, 0));
    V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str12)), v_l_2435);
    V t_0 = v_e2_2434;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_rest_241});
    V t_2 = v_u_2437;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_STag: {
    V v_t_2440 = heff_field(v_x2_240, 0);
    V v_args_2441 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_xs_2442 = heff_arrayToList(v_args_2441);
    V v_i_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2442));
    V v_t_2444 = ({ V a_0 = v_xs_2442; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2442); heff_drop(v_rest_241); r_; });
    V v_t_2445 = heff_intShow(heff_strLength_lent(v_t_2440, 0));
    V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str13)), v_t_2440);
    V v_t_2447 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2443), v_t_2444});
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_t_2447})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2448);
  }
  case TAG_SMatch: {
    V v_e2_2449 = heff_field(v_x2_240, 0);
    V v_cs_2450 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_keys_2451 = heff_take_field(v_cs_2450, 0);
    V v_values_2452 = heff_get_n(v_cs_2450, 2, 3);
    V v_xs_2453 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2451), heff_arrayToList(v_values_2452)));
    V v_i_2454 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2453));
    V v_t_2455 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str15); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str16); V a_4 = v_xs_2453; V a_5 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_241); r_; });
    V v_rest_2456 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2454), v_t_2455});
    V v_cell_2457 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str17), heff_hole()});
    V v_u_2458 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2457);
    V t_0 = v_e2_2449;
    V t_1 = v_rest_2456;
    V t_2 = v_u_2458;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SSpecialize: {
    V v_e2_2459 = heff_field(v_x2_240, 0);
    V v_l_2460 = heff_field(v_x2_240, 1);
    V v_v_2461 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2462 = ({ V a_0 = v_v_2461; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
    V v_t_2463 = heff_intShow(heff_strLength_lent(v_l_2460, 0));
    V v_t_2464 = heff_strAppend(heff_strAppend(v_t_2463, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str18)), v_l_2460);
    V v_rest_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, v_t_2462});
    V v_cell_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str19), heff_hole()});
    V v_u_2467 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2466);
    V t_0 = v_e2_2459;
    V t_1 = v_rest_2465;
    V t_2 = v_u_2467;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SIs: {
    V v_e2_2468 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2469 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str20), heff_hole()});
    V v_u_2470 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2469);
    V t_0 = v_e2_2468;
    V t_1 = v_rest_241;
    V t_2 = v_u_2470;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str21), v_rest_241}));
  }
  case TAG_SAbandon: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str22), v_rest_241}));
  }
  case TAG_SRec: {
    V v_e2_2471 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2472 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str23), heff_hole()});
    V v_u_2473 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2472);
    V t_0 = v_e2_2471;
    V t_1 = v_rest_241;
    V t_2 = v_u_2473;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFix: {
    V v_t_2474 = heff_field(v_x2_240, 0);
    V v_b_2475 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2483;
    switch (heff_tag_of(v_b_2475)) {
    case TAG_MkAbs: {
      V v_x_2476 = heff_field(v_b_2475, 0);
      V v_e_2477 = heff_field(v_b_2475, 1);
      V v_ru_24b_2475_24MkAbs = heff_take_reuse_n(v_b_2475, 3ULL, 2);
      V v_t_2478 = ({ V a_0 = v_e_2477; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
      V v_t_2479 = heff_intShow(heff_strLength_lent(v_x_2476, 0));
      V v_t_2480 = heff_strAppend(heff_strAppend(v_t_2479, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str24)), v_x_2476);
      v_rest_2483 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str25), heff_tag_at_n(v_ru_24b_2475_24MkAbs, TAG_Cons, 2, (V[]){v_t_2480, v_t_2478})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2481 = heff_field(v_b_2475, 0);
      heff_take_n(v_b_2475, 1ULL, 1);
      V v_t_2482 = ({ V a_0 = v_e_2481; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
      v_rest_2483 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str26), v_t_2482});
      break;
    }
    default: heff_nomatch(v_b_2475);
    }
    V v_t_2484 = ({ V a_0 = v_t_2474; V a_1 = v_rest_2483; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2474); r_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str27), v_t_2484}));
  }
  case TAG_SImplicit: {
    V v_x_2485 = heff_field(v_x2_240, 0);
    V v_e2_2486 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2487 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str28), heff_hole()});
    V v_u_2488 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2487);
    V v_t_2489 = heff_intShow(heff_strLength_lent(v_x_2485, 0));
    V v_t_2490 = heff_strAppend(heff_strAppend(v_t_2489, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str29)), v_x_2485);
    V v_cell_2491 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, heff_hole()});
    V v_u_2492 = heff_setFieldPeek(v_u_2488, MK_INT(1LL), v_cell_2491);
    V t_0 = v_e2_2486;
    V t_1 = v_rest_241;
    V t_2 = v_u_2492;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_2493 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2494 = ({ V a_0 = v_x_2493; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_x_2493); r_; });
    V v_t_2495 = heff_intShow(heff_strLength_lent(v_s_2494, 0));
    V v_t_2496 = heff_strAppend(heff_strAppend(v_t_2495, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str30)), v_s_2494);
    V v_t_2497 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2496, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2497);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str32), v_rest_241}));
  }
  case TAG_SLitInt: {
    V v_i_24101 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24102 = heff_intShow(v_i_24101);
    V v_t_24103 = heff_intShow(heff_strLength_lent(v_s_24102, 0));
    V v_t_24104 = heff_strAppend(heff_strAppend(v_t_24103, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str33)), v_s_24102);
    V v_t_24105 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24104, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_24105);
  }
  case TAG_SLitFloat: {
    V v_x_24106 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24107 = heff_floatShow(v_x_24106);
    V v_t_24108 = heff_intShow(heff_strLength_lent(v_s_24107, 0));
    V v_t_24109 = heff_strAppend(heff_strAppend(v_t_24108, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str35)), v_s_24107);
    V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_24110);
  }
  case TAG_SLitString: {
    V v_s_24111 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24112 = heff_intShow(heff_strLength_lent(v_s_24111, 0));
    V v_t_24113 = heff_strAppend(heff_strAppend(v_t_24112, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str37)), v_s_24111);
    V v_t_24114 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_24114);
  }
  case TAG_SLitBytes: {
    V v_s_24115 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24116 = heff_intShow(heff_strLength_lent(v_s_24115, 0));
    V v_t_24117 = heff_strAppend(heff_strAppend(v_t_24116, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str39)), v_s_24115);
    V v_t_24118 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_24118);
  }
  case TAG_SLitRune: {
    V v_c_24119 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24120 = heff_intShow(v_c_24119);
    V v_t_24121 = heff_intShow(heff_strLength_lent(v_s_24120, 0));
    V v_t_24122 = heff_strAppend(heff_strAppend(v_t_24121, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str41)), v_s_24120);
    V v_t_24123 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24122, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_24123);
  }
  case TAG_SLitFixed: {
    V v_w_24124 = heff_field(v_x2_240, 0);
    V v_n_24125 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24126;
    switch (heff_tag_of(v_w_24124)) {
    case TAG_I8: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str43);
      break;
    }
    case TAG_I16: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str44);
      break;
    }
    case TAG_I32: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str45);
      break;
    }
    case TAG_I64: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str46);
      break;
    }
    case TAG_U8: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str47);
      break;
    }
    case TAG_U16: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str48);
      break;
    }
    case TAG_U32: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str49);
      break;
    }
    case TAG_U64: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str50);
      break;
    }
    case TAG_F32: {
      v_t_24126 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str51);
      break;
    }
    default: heff_nomatch(v_w_24124);
    }
    V v_s_24127 = heff_intShow(v_n_24125);
    V v_t_24128 = heff_intShow(heff_strLength_lent(v_s_24127, 0));
    V v_t_24129 = heff_strAppend(heff_strAppend(v_t_24128, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str52)), v_s_24127);
    V v_t_24130 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_24126, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24129, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str53), v_t_24130}));
  }
  case TAG_SLitFloat32: {
    V v_x_24131 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24132 = heff_floatShow(v_x_24131);
    V v_t_24133 = heff_intShow(heff_strLength_lent(v_s_24132, 0));
    V v_t_24134 = heff_strAppend(heff_strAppend(v_t_24133, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str54)), v_s_24132);
    V v_t_24135 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24134, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_24135);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_24cpr_str1, 1, "_");

HeffT3 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V v_d_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2eabsOf_24cpr_str0), 2)) {
    HeffT3 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        V v_j_249 = v_field_247;
        V v_x3_2410 = heff_tr(heff_call(v_d_240, 2, (V[]){v_z_242, v_j_249}));
        switch (heff_tag_of(v_x3_2410)) {
        case TAG_Nothing: {
          heff_drop(v_x_248);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2411 = heff_field(v_x3_2410, 0);
          heff_take_n(v_x3_2410, 1ULL, 1);
          switch (heff_tag_of(v_x31_2411)) {
          case TAG_MkPair: {
            V v_x_2412 = heff_field(v_x31_2411, 0);
            V v_j_2413 = heff_field(v_x31_2411, 1);
            V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkAbs, 2, (V[]){v_x_248, v_x_2412}), v_j_2413}});
          }
          default: return ((HeffT3){{heff_nomatch(v_x31_2411)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x3_2410)}});
        }
      } else {
        heff_drop(v_d_240);
        heff_drop(v_z_242);
        heff_drop(v_field_246);
        heff_drop(v_field_247);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2eabsOf_24cpr_str1), 2)) {
      V v_x3_2414 = heff_tr(heff_call(v_d_240, 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_Nothing: {
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_2415 = heff_field(v_x3_2414, 0);
        V v_ru_24x3_2414_24Just = heff_take_reuse_n(v_x3_2414, 1ULL, 1);
        switch (heff_tag_of(v_x31_2415)) {
        case TAG_MkPair: {
          V v_x_2416 = heff_field(v_x31_2415, 0);
          V v_j_2417 = heff_field(v_x31_2415, 1);
          heff_take_n(v_x31_2415, 3ULL, 2);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_2414_24Just, TAG_AbsConst, 1, (V[]){v_x_2416}), v_j_2417}});
        }
        default: return ((HeffT3){{heff_nomatch(v_x31_2415)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x3_2414)}});
      }
    } else {
      heff_drop(v_d_240);
      return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etermOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etermOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT3 v_t_244 = (g_heff_2ebuild_2eserial_2etermOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_field_246, v_field_247})});
    } else {
      heff_drop(v_field_246);
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2etermOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str1, 1, "n");
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args);
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_lam1, 2, 0};
Clo g_heff_2ebuild_2eserial_2edefaultOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_entry, 2, 0};

V g_heff_2ebuild_2eserial_2edefaultOf(V v_k_240, V v_x2_241) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str0), 2)) {
    return heff_clo_n(g_heff_2ebuild_2eserial_2edefaultOf_lam0, 2, 1, (V[]){v_k_240});
  } else {
    heff_drop_rec(v_k_240, 2);
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str1), 2)) {
      return ((V)&g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo);
    } else {
      return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2edefaultOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_244 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_242, v_i_243}));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_244, 0);
    V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_245, 0);
      V v_j_247 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_t_248 = heff_tag_re_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){v_x_246}), v_j_247});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_i_2410 = args[1];
  heff_drop(v_s_249);
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_i_2410});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
}
Clo g_heff_2ebuild_2eserial_2etakeFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeFields_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeFields(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      V v_j_248 = v_field_246;
      HeffT3 v_t_249 = ({ V b_0 = heff_get_n(v_k_240, 1, 2); V a_1 = v_x_247; V a_2 = v_s_241; V a_3 = v_j_248; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        V v_field_2412 = v_t_249.f[2];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2411;
          V v_j_2414 = v_field_2412;
          V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2413), v_j_2414});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
        } else {
          heff_drop(v_field_2411);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2etakeFields(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2eserial_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etypeOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT3 v_t_244 = (g_heff_2ebuild_2eserial_2etypeOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_field_246, v_field_247})});
    } else {
      heff_drop(v_field_246);
      heff_drop(v_field_247);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2etypeOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23, 3, "f32");

HeffT3 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_z_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SLocal, 1, (V[]){v_x_247}), v_j_248}});
      } else {
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
      {
        V v_field_2411 = v_t_249.f[1];
        V v_field_2412 = v_t_249.f[2];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2411;
          V v_j_2414 = v_field_2412;
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2413}), v_j_2414}});
        } else {
          heff_drop(v_field_2411);
          heff_drop(v_field_2412);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT3 v_t_2415 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
        {
          V v_field_2417 = v_t_2415.f[1];
          V v_field_2418 = v_t_2415.f[2];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_x_2419 = v_field_2417;
            V v_j_2420 = v_field_2418;
            HeffT3 v_t_2421 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2419, v_z_241, v_j_2420));
            {
              V v_field_2423 = v_t_2421.f[1];
              V v_field_2424 = v_t_2421.f[2];
              int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
              if ((v_tag_2422 == ((int64_t)0ULL))) {
                V v_x_2425 = v_field_2423;
                V v_j_2426 = v_field_2424;
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SCode, 1, (V[]){v_x_2425}), v_j_2426}});
              } else {
                heff_drop(v_field_2423);
                heff_drop(v_field_2424);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_field_2417);
            heff_drop(v_field_2418);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT3 v_t_2427 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
          {
            V v_field_2429 = v_t_2427.f[1];
            V v_field_2430 = v_t_2427.f[2];
            int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
            if ((v_tag_2428 == ((int64_t)0ULL))) {
              V v_x_2431 = v_field_2429;
              V v_j_2432 = v_field_2430;
              HeffT3 v_t_2433 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2431, v_z_241, v_j_2432));
              {
                V v_field_2435 = v_t_2433.f[1];
                V v_field_2436 = v_t_2433.f[2];
                int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                if ((v_tag_2434 == ((int64_t)0ULL))) {
                  V v_x_2437 = v_field_2435;
                  V v_j_2438 = v_field_2436;
                  HeffT3 v_t_2439 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2438));
                  {
                    V v_field_2441 = v_t_2439.f[1];
                    V v_field_2442 = v_t_2439.f[2];
                    int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
                    if ((v_tag_2440 == ((int64_t)0ULL))) {
                      V v_x_2443 = v_field_2441;
                      V v_j_2444 = v_field_2442;
                      HeffT3 v_t_2445 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2443, v_z_241, v_j_2444));
                      {
                        V v_field_2447 = v_t_2445.f[1];
                        V v_field_2448 = v_t_2445.f[2];
                        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
                        if ((v_tag_2446 == ((int64_t)0ULL))) {
                          V v_x_2449 = v_field_2447;
                          V v_j_2450 = v_field_2448;
                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SApp, 2, (V[]){v_x_2437, v_x_2449}), v_j_2450}});
                        } else {
                          heff_drop(v_x_2437);
                          heff_drop(v_field_2447);
                          heff_drop(v_field_2448);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_x_2437);
                      heff_drop(v_field_2441);
                      heff_drop(v_field_2442);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_field_2435);
                  heff_drop(v_field_2436);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_field_2429);
              heff_drop(v_field_2430);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            HeffT3 v_t_2451 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
            {
              V v_field_2453 = v_t_2451.f[1];
              V v_field_2454 = v_t_2451.f[2];
              int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
              if ((v_tag_2452 == ((int64_t)0ULL))) {
                V v_x_2455 = v_field_2453;
                V v_j_2456 = v_field_2454;
                HeffT3 v_t_2457 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2455, v_z_241, v_j_2456));
                {
                  V v_field_2459 = v_t_2457.f[1];
                  V v_field_2460 = v_t_2457.f[2];
                  int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
                  if ((v_tag_2458 == ((int64_t)0ULL))) {
                    V v_x_2461 = v_field_2459;
                    V v_j_2462 = v_field_2460;
                    HeffT3 v_t_2463 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2462));
                    {
                      V v_field_2465 = v_t_2463.f[1];
                      V v_field_2466 = v_t_2463.f[2];
                      int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
                      if ((v_tag_2464 == ((int64_t)0ULL))) {
                        V v_x_2467 = v_field_2465;
                        V v_j_2468 = v_field_2466;
                        HeffT3 v_t_2469 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_2467; V a_2 = heff_dup(v_z_241); V a_3 = v_j_2468; HeffT3 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2467); r_; });
                        {
                          V v_field_2471 = v_t_2469.f[1];
                          V v_field_2472 = v_t_2469.f[2];
                          int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                          if ((v_tag_2470 == ((int64_t)0ULL))) {
                            V v_x_2473 = v_field_2471;
                            V v_j_2474 = v_field_2472;
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SLam, 2, (V[]){v_x_2461, v_x_2473}), v_j_2474}});
                          } else {
                            heff_drop(v_x_2461);
                            heff_drop(v_field_2471);
                            heff_drop(v_field_2472);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        heff_drop(v_x_2461);
                        heff_drop(v_field_2465);
                        heff_drop(v_field_2466);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    heff_drop(v_field_2459);
                    heff_drop(v_field_2460);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              } else {
                heff_drop(v_field_2453);
                heff_drop(v_field_2454);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT3 v_t_2475 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_z_242));
              {
                V v_field_2477 = v_t_2475.f[1];
                V v_field_2478 = v_t_2475.f[2];
                int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
                if ((v_tag_2476 == ((int64_t)0ULL))) {
                  V v_x_2479 = v_field_2477;
                  V v_j_2480 = v_field_2478;
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SCons, 1, (V[]){v_x_2479}), v_j_2480}});
                } else {
                  heff_drop(v_field_2477);
                  heff_drop(v_field_2478);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                HeffT3 v_t_2481 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                {
                  V v_field_2483 = v_t_2481.f[1];
                  V v_field_2484 = v_t_2481.f[2];
                  int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
                  if ((v_tag_2482 == ((int64_t)0ULL))) {
                    V v_x_2485 = v_field_2483;
                    V v_j_2486 = v_field_2484;
                    HeffT3 v_t_2487 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2485, v_z_241, v_j_2486));
                    {
                      V v_field_2489 = v_t_2487.f[1];
                      V v_field_2490 = v_t_2487.f[2];
                      int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
                      if ((v_tag_2488 == ((int64_t)0ULL))) {
                        V v_x_2491 = v_field_2489;
                        V v_j_2492 = v_field_2490;
                        HeffT3 v_t_2493 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_j_2492));
                        {
                          V v_field_2495 = v_t_2493.f[1];
                          V v_field_2496 = v_t_2493.f[2];
                          int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
                          if ((v_tag_2494 == ((int64_t)0ULL))) {
                            V v_x_2497 = v_field_2495;
                            V v_j_2498 = v_field_2496;
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SProj, 2, (V[]){v_x_2491, v_x_2497}), v_j_2498}});
                          } else {
                            heff_drop(v_x_2491);
                            heff_drop(v_field_2495);
                            heff_drop(v_field_2496);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        heff_drop(v_field_2489);
                        heff_drop(v_field_2490);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    heff_drop(v_field_2483);
                    heff_drop(v_field_2484);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  HeffT3 v_t_2499 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                  {
                    V v_field_24101 = v_t_2499.f[1];
                    V v_field_24102 = v_t_2499.f[2];
                    int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
                    if ((v_tag_24100 == ((int64_t)0ULL))) {
                      V v_x_24103 = v_field_24101;
                      V v_j_24104 = v_field_24102;
                      HeffT3 v_t_24105 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_j_24104));
                      {
                        V v_field_24107 = v_t_24105.f[1];
                        V v_field_24108 = v_t_24105.f[2];
                        int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
                        if ((v_tag_24106 == ((int64_t)0ULL))) {
                          V v_x_24109 = v_field_24107;
                          V v_j_24110 = v_field_24108;
                          HeffT3 v_t_24111 = ({ V b_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_24109; V a_2 = v_z_241; V a_3 = v_j_24110; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
                          {
                            V v_field_24113 = v_t_24111.f[1];
                            V v_field_24114 = v_t_24111.f[2];
                            int64_t v_tag_24112 = ((int64_t)v_t_24111.f[0]);
                            if ((v_tag_24112 == ((int64_t)0ULL))) {
                              V v_x_24115 = v_field_24113;
                              V v_j_24116 = v_field_24114;
                              V v_f_24117 = heff_tag_n(TAG_STag, 2, (V[]){v_x_24103, heff_arrayFromList(v_x_24115)});
                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_24117, v_j_24116}});
                            } else {
                              heff_drop(v_x_24103);
                              heff_drop(v_field_24113);
                              heff_drop(v_field_24114);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_x_24103);
                          heff_drop(v_field_24107);
                          heff_drop(v_field_24108);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_field_24101);
                      heff_drop(v_field_24102);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    HeffT3 v_t_24118 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                    {
                      V v_field_24120 = v_t_24118.f[1];
                      V v_field_24121 = v_t_24118.f[2];
                      int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
                      if ((v_tag_24119 == ((int64_t)0ULL))) {
                        V v_x_24122 = v_field_24120;
                        V v_j_24123 = v_field_24121;
                        HeffT3 v_t_24124 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24122, v_z_241, v_j_24123));
                        {
                          V v_field_24126 = v_t_24124.f[1];
                          V v_field_24127 = v_t_24124.f[2];
                          int64_t v_tag_24125 = ((int64_t)v_t_24124.f[0]);
                          if ((v_tag_24125 == ((int64_t)0ULL))) {
                            V v_x_24128 = v_field_24126;
                            V v_j_24129 = v_field_24127;
                            V v_s_24130 = heff_dup(v_z_241);
                            V v_i_24131 = v_j_24129;
                            HeffT3 v_t_24132 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_24130, v_i_24131));
                            {
                              V v_field_24134 = v_t_24132.f[1];
                              V v_field_24135 = v_t_24132.f[2];
                              int64_t v_tag_24133 = ((int64_t)v_t_24132.f[0]);
                              V v_x3_24148;
                              if ((v_tag_24133 == ((int64_t)0ULL))) {
                                V v_x_24136 = v_field_24134;
                                V v_j_24137 = v_field_24135;
                                HeffT3 v_t_24138 = ({ V a_0 = v_x_24136; V a_1 = v_s_24130; V a_2 = v_j_24137; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(a_0, a_1, a_2)); heff_drop(v_s_24130); r_; });
                                {
                                  V v_field_24140 = v_t_24138.f[1];
                                  V v_field_24141 = v_t_24138.f[2];
                                  int64_t v_tag_24139 = ((int64_t)v_t_24138.f[0]);
                                  if ((v_tag_24139 == ((int64_t)0ULL))) {
                                    V v_x_24142 = v_field_24140;
                                    V v_j_24143 = v_field_24141;
                                    V v_t_24144 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_24142)));
                                    V v_t_24145 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_24142));
                                    V v_t_24146 = (g_list_2emap_24s1173914895x100384474(v_x_24142));
                                    V v_x_24147 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_24144), v_t_24145, heff_arrayFromList(v_t_24146)});
                                    v_x3_24148 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24147, v_j_24143})});
                                  } else {
                                    heff_drop(v_field_24140);
                                    heff_drop(v_field_24141);
                                    v_x3_24148 = NTAG(TAG_Nothing);
                                  }
                                }
                              } else {
                                heff_drop(v_s_24130);
                                heff_drop(v_field_24134);
                                heff_drop(v_field_24135);
                                v_x3_24148 = NTAG(TAG_Nothing);
                              }
                              switch (heff_tag_of(v_x3_24148)) {
                              case TAG_Nothing: {
                                heff_drop(v_x_24128);
                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24149 = heff_field(v_x3_24148, 0);
                                heff_take_n(v_x3_24148, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24149)) {
                                case TAG_MkPair: {
                                  V v_x_24150 = heff_field(v_x31_24149, 0);
                                  V v_j_24151 = heff_field(v_x31_24149, 1);
                                  V v_ru_24x31_24149_24MkPair = heff_take_reuse_n(v_x31_24149, 3ULL, 2);
                                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24149_24MkPair, TAG_SMatch, 2, (V[]){v_x_24128, v_x_24150}), v_j_24151}});
                                }
                                default: return ((HeffT3){{heff_nomatch(v_x31_24149)}});
                                }
                              }
                              default: return ((HeffT3){{heff_nomatch(v_x3_24148)}});
                              }
                            }
                          } else {
                            heff_drop(v_field_24126);
                            heff_drop(v_field_24127);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        heff_drop(v_field_24120);
                        heff_drop(v_field_24121);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      HeffT3 v_t_24152 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                      {
                        V v_field_24154 = v_t_24152.f[1];
                        V v_field_24155 = v_t_24152.f[2];
                        int64_t v_tag_24153 = ((int64_t)v_t_24152.f[0]);
                        if ((v_tag_24153 == ((int64_t)0ULL))) {
                          V v_x_24156 = v_field_24154;
                          V v_j_24157 = v_field_24155;
                          HeffT3 v_t_24158 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24156, v_z_241, v_j_24157));
                          {
                            V v_field_24160 = v_t_24158.f[1];
                            V v_field_24161 = v_t_24158.f[2];
                            int64_t v_tag_24159 = ((int64_t)v_t_24158.f[0]);
                            if ((v_tag_24159 == ((int64_t)0ULL))) {
                              V v_x_24162 = v_field_24160;
                              V v_j_24163 = v_field_24161;
                              HeffT3 v_t_24164 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_j_24163));
                              {
                                V v_field_24166 = v_t_24164.f[1];
                                V v_field_24167 = v_t_24164.f[2];
                                int64_t v_tag_24165 = ((int64_t)v_t_24164.f[0]);
                                if ((v_tag_24165 == ((int64_t)0ULL))) {
                                  V v_x_24168 = v_field_24166;
                                  V v_j_24169 = v_field_24167;
                                  HeffT3 v_t_24170 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24169));
                                  {
                                    V v_field_24172 = v_t_24170.f[1];
                                    V v_field_24173 = v_t_24170.f[2];
                                    int64_t v_tag_24171 = ((int64_t)v_t_24170.f[0]);
                                    if ((v_tag_24171 == ((int64_t)0ULL))) {
                                      V v_x_24174 = v_field_24172;
                                      V v_j_24175 = v_field_24173;
                                      HeffT3 v_t_24176 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24174, v_z_241, v_j_24175));
                                      {
                                        V v_field_24178 = v_t_24176.f[1];
                                        V v_field_24179 = v_t_24176.f[2];
                                        int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
                                        if ((v_tag_24177 == ((int64_t)0ULL))) {
                                          V v_x_24180 = v_field_24178;
                                          V v_j_24181 = v_field_24179;
                                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24162, v_x_24168, v_x_24180}), v_j_24181}});
                                        } else {
                                          heff_drop(v_x_24162);
                                          heff_drop(v_x_24168);
                                          heff_drop(v_field_24178);
                                          heff_drop(v_field_24179);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_x_24162);
                                      heff_drop(v_x_24168);
                                      heff_drop(v_field_24172);
                                      heff_drop(v_field_24173);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_x_24162);
                                  heff_drop(v_field_24166);
                                  heff_drop(v_field_24167);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_field_24160);
                              heff_drop(v_field_24161);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_field_24154);
                          heff_drop(v_field_24155);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT3 v_t_24182 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                        {
                          V v_field_24184 = v_t_24182.f[1];
                          V v_field_24185 = v_t_24182.f[2];
                          int64_t v_tag_24183 = ((int64_t)v_t_24182.f[0]);
                          if ((v_tag_24183 == ((int64_t)0ULL))) {
                            V v_x_24186 = v_field_24184;
                            V v_j_24187 = v_field_24185;
                            HeffT3 v_t_24188 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24186, v_z_241, v_j_24187));
                            {
                              V v_field_24190 = v_t_24188.f[1];
                              V v_field_24191 = v_t_24188.f[2];
                              int64_t v_tag_24189 = ((int64_t)v_t_24188.f[0]);
                              if ((v_tag_24189 == ((int64_t)0ULL))) {
                                V v_x_24192 = v_field_24190;
                                V v_j_24193 = v_field_24191;
                                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SIs, 1, (V[]){v_x_24192}), v_j_24193}});
                              } else {
                                heff_drop(v_field_24190);
                                heff_drop(v_field_24191);
                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                              }
                            }
                          } else {
                            heff_drop(v_field_24184);
                            heff_drop(v_field_24185);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11), 2)) {
                          heff_drop(v_x2_240);
                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SOpaque), v_z_242}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12), 2)) {
                            heff_drop(v_x2_240);
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SAbandon), v_z_242}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13), 2)) {
                              heff_drop(v_x2_240);
                              HeffT3 v_t_24194 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                              {
                                V v_field_24196 = v_t_24194.f[1];
                                V v_field_24197 = v_t_24194.f[2];
                                int64_t v_tag_24195 = ((int64_t)v_t_24194.f[0]);
                                if ((v_tag_24195 == ((int64_t)0ULL))) {
                                  V v_x_24198 = v_field_24196;
                                  V v_j_24199 = v_field_24197;
                                  HeffT3 v_t_24200 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24198, v_z_241, v_j_24199));
                                  {
                                    V v_field_24202 = v_t_24200.f[1];
                                    V v_field_24203 = v_t_24200.f[2];
                                    int64_t v_tag_24201 = ((int64_t)v_t_24200.f[0]);
                                    if ((v_tag_24201 == ((int64_t)0ULL))) {
                                      V v_x_24204 = v_field_24202;
                                      V v_j_24205 = v_field_24203;
                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SRec, 1, (V[]){v_x_24204}), v_j_24205}});
                                    } else {
                                      heff_drop(v_field_24202);
                                      heff_drop(v_field_24203);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_field_24196);
                                  heff_drop(v_field_24197);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14), 2)) {
                                heff_drop(v_x2_240);
                                HeffT3 v_t_24206 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                                {
                                  V v_field_24208 = v_t_24206.f[1];
                                  V v_field_24209 = v_t_24206.f[2];
                                  int64_t v_tag_24207 = ((int64_t)v_t_24206.f[0]);
                                  if ((v_tag_24207 == ((int64_t)0ULL))) {
                                    V v_x_24210 = v_field_24208;
                                    V v_j_24211 = v_field_24209;
                                    HeffT3 v_t_24212 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24210, v_z_241, v_j_24211));
                                    {
                                      V v_field_24214 = v_t_24212.f[1];
                                      V v_field_24215 = v_t_24212.f[2];
                                      int64_t v_tag_24213 = ((int64_t)v_t_24212.f[0]);
                                      if ((v_tag_24213 == ((int64_t)0ULL))) {
                                        V v_x_24216 = v_field_24214;
                                        V v_j_24217 = v_field_24215;
                                        HeffT3 v_t_24218 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24217));
                                        {
                                          V v_field_24220 = v_t_24218.f[1];
                                          V v_field_24221 = v_t_24218.f[2];
                                          int64_t v_tag_24219 = ((int64_t)v_t_24218.f[0]);
                                          if ((v_tag_24219 == ((int64_t)0ULL))) {
                                            V v_x_24222 = v_field_24220;
                                            V v_j_24223 = v_field_24221;
                                            HeffT3 v_t_24224 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_24222; V a_2 = heff_dup(v_z_241); V a_3 = v_j_24223; HeffT3 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_24222); r_; });
                                            {
                                              V v_field_24226 = v_t_24224.f[1];
                                              V v_field_24227 = v_t_24224.f[2];
                                              int64_t v_tag_24225 = ((int64_t)v_t_24224.f[0]);
                                              if ((v_tag_24225 == ((int64_t)0ULL))) {
                                                V v_x_24228 = v_field_24226;
                                                V v_j_24229 = v_field_24227;
                                                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SFix, 2, (V[]){v_x_24216, v_x_24228}), v_j_24229}});
                                              } else {
                                                heff_drop(v_x_24216);
                                                heff_drop(v_field_24226);
                                                heff_drop(v_field_24227);
                                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            heff_drop(v_x_24216);
                                            heff_drop(v_field_24220);
                                            heff_drop(v_field_24221);
                                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        heff_drop(v_field_24214);
                                        heff_drop(v_field_24215);
                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    heff_drop(v_field_24208);
                                    heff_drop(v_field_24209);
                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15), 2)) {
                                  heff_drop(v_x2_240);
                                  HeffT3 v_t_24230 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                  {
                                    V v_field_24232 = v_t_24230.f[1];
                                    V v_field_24233 = v_t_24230.f[2];
                                    int64_t v_tag_24231 = ((int64_t)v_t_24230.f[0]);
                                    if ((v_tag_24231 == ((int64_t)0ULL))) {
                                      V v_x_24234 = v_field_24232;
                                      V v_j_24235 = v_field_24233;
                                      HeffT3 v_t_24236 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24235));
                                      {
                                        V v_field_24238 = v_t_24236.f[1];
                                        V v_field_24239 = v_t_24236.f[2];
                                        int64_t v_tag_24237 = ((int64_t)v_t_24236.f[0]);
                                        if ((v_tag_24237 == ((int64_t)0ULL))) {
                                          V v_x_24240 = v_field_24238;
                                          V v_j_24241 = v_field_24239;
                                          HeffT3 v_t_24242 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24240, v_z_241, v_j_24241));
                                          {
                                            V v_field_24244 = v_t_24242.f[1];
                                            V v_field_24245 = v_t_24242.f[2];
                                            int64_t v_tag_24243 = ((int64_t)v_t_24242.f[0]);
                                            if ((v_tag_24243 == ((int64_t)0ULL))) {
                                              V v_x_24246 = v_field_24244;
                                              V v_j_24247 = v_field_24245;
                                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24234, v_x_24246}), v_j_24247}});
                                            } else {
                                              heff_drop(v_x_24234);
                                              heff_drop(v_field_24244);
                                              heff_drop(v_field_24245);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          heff_drop(v_x_24234);
                                          heff_drop(v_field_24238);
                                          heff_drop(v_field_24239);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_field_24232);
                                      heff_drop(v_field_24233);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16), 2)) {
                                    heff_drop(v_x2_240);
                                    HeffT3 v_t_24248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                    {
                                      V v_field_24250 = v_t_24248.f[1];
                                      V v_field_24251 = v_t_24248.f[2];
                                      int64_t v_tag_24249 = ((int64_t)v_t_24248.f[0]);
                                      if ((v_tag_24249 == ((int64_t)0ULL))) {
                                        V v_x_24252 = v_field_24250;
                                        V v_j_24253 = v_field_24251;
                                        V v_x1_24254 = ({ V a_0 = v_x_24252; V r_ = (g_heff_2eelab_2eprimitive_2eprimOfName(a_0)); heff_drop(v_x_24252); r_; });
                                        switch (heff_tag_of(v_x1_24254)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_j_24253);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x_24255 = heff_field(v_x1_24254, 0);
                                          V v_ru_24x1_24254_24Just = heff_take_reuse_n(v_x1_24254, 1ULL, 1);
                                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_24254_24Just, TAG_SPrim, 1, (V[]){v_x_24255}), v_j_24253}});
                                        }
                                        default: return ((HeffT3){{heff_nomatch(v_x1_24254)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24250);
                                        heff_drop(v_field_24251);
                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17), 2)) {
                                      heff_drop(v_x2_240);
                                      HeffT3 v_t_24256 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                      {
                                        V v_field_24258 = v_t_24256.f[1];
                                        V v_field_24259 = v_t_24256.f[2];
                                        int64_t v_tag_24257 = ((int64_t)v_t_24256.f[0]);
                                        if ((v_tag_24257 == ((int64_t)0ULL))) {
                                          V v_x_24260 = v_field_24258;
                                          V v_j_24261 = v_field_24259;
                                          V v_t_24262 = ({ V a_0 = v_x_24260; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24260); r_; });
                                          V v_x_24263 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24262});
                                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24263, v_j_24261}});
                                        } else {
                                          heff_drop(v_field_24258);
                                          heff_drop(v_field_24259);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18), 2)) {
                                        heff_drop(v_x2_240);
                                        HeffT3 v_t_24264 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                        {
                                          V v_field_24266 = v_t_24264.f[1];
                                          V v_field_24267 = v_t_24264.f[2];
                                          int64_t v_tag_24265 = ((int64_t)v_t_24264.f[0]);
                                          if ((v_tag_24265 == ((int64_t)0ULL))) {
                                            V v_x_24268 = v_field_24266;
                                            V v_j_24269 = v_field_24267;
                                            double v_t_24270 = ({ V a_0 = v_x_24268; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24268); r_; });
                                            V v_x_24271 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24270)});
                                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24271, v_j_24269}});
                                          } else {
                                            heff_drop(v_field_24266);
                                            heff_drop(v_field_24267);
                                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19), 2)) {
                                          heff_drop(v_x2_240);
                                          HeffT3 v_t_24272 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                          {
                                            V v_field_24274 = v_t_24272.f[1];
                                            V v_field_24275 = v_t_24272.f[2];
                                            int64_t v_tag_24273 = ((int64_t)v_t_24272.f[0]);
                                            if ((v_tag_24273 == ((int64_t)0ULL))) {
                                              V v_x_24276 = v_field_24274;
                                              V v_j_24277 = v_field_24275;
                                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24276}), v_j_24277}});
                                            } else {
                                              heff_drop(v_field_24274);
                                              heff_drop(v_field_24275);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20), 2)) {
                                            heff_drop(v_x2_240);
                                            HeffT3 v_t_24278 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                            {
                                              V v_field_24280 = v_t_24278.f[1];
                                              V v_field_24281 = v_t_24278.f[2];
                                              int64_t v_tag_24279 = ((int64_t)v_t_24278.f[0]);
                                              if ((v_tag_24279 == ((int64_t)0ULL))) {
                                                V v_x_24282 = v_field_24280;
                                                V v_j_24283 = v_field_24281;
                                                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24282}), v_j_24283}});
                                              } else {
                                                heff_drop(v_field_24280);
                                                heff_drop(v_field_24281);
                                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21), 2)) {
                                              heff_drop(v_x2_240);
                                              HeffT3 v_t_24284 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                              {
                                                V v_field_24286 = v_t_24284.f[1];
                                                V v_field_24287 = v_t_24284.f[2];
                                                int64_t v_tag_24285 = ((int64_t)v_t_24284.f[0]);
                                                if ((v_tag_24285 == ((int64_t)0ULL))) {
                                                  V v_x_24288 = v_field_24286;
                                                  V v_j_24289 = v_field_24287;
                                                  V v_t_24290 = ({ V a_0 = v_x_24288; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24288); r_; });
                                                  V v_x_24291 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24290});
                                                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24291, v_j_24289}});
                                                } else {
                                                  heff_drop(v_field_24286);
                                                  heff_drop(v_field_24287);
                                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22), 2)) {
                                                heff_drop(v_x2_240);
                                                HeffT3 v_t_24292 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_241, v_z_242));
                                                {
                                                  V v_field_24294 = v_t_24292.f[1];
                                                  V v_field_24295 = v_t_24292.f[2];
                                                  int64_t v_tag_24293 = ((int64_t)v_t_24292.f[0]);
                                                  if ((v_tag_24293 == ((int64_t)0ULL))) {
                                                    V v_x_24296 = v_field_24294;
                                                    V v_j_24297 = v_field_24295;
                                                    HeffT3 v_t_24298 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_j_24297));
                                                    {
                                                      V v_field_24300 = v_t_24298.f[1];
                                                      V v_field_24301 = v_t_24298.f[2];
                                                      int64_t v_tag_24299 = ((int64_t)v_t_24298.f[0]);
                                                      if ((v_tag_24299 == ((int64_t)0ULL))) {
                                                        V v_x_24302 = v_field_24300;
                                                        V v_j_24303 = v_field_24301;
                                                        V v_t_24304 = ({ V a_0 = v_x_24302; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24302); r_; });
                                                        V v_x_24305 = heff_tag_n(TAG_SLitFixed, 2, (V[]){v_x_24296, v_t_24304});
                                                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24305, v_j_24303}});
                                                      } else {
                                                        heff_drop(v_x_24296);
                                                        heff_drop(v_field_24300);
                                                        heff_drop(v_field_24301);
                                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                      }
                                                    }
                                                  } else {
                                                    heff_drop(v_field_24294);
                                                    heff_drop(v_field_24295);
                                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23))) {
                                                  HeffT3 v_t_24306 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                                  {
                                                    V v_field_24308 = v_t_24306.f[1];
                                                    V v_field_24309 = v_t_24306.f[2];
                                                    int64_t v_tag_24307 = ((int64_t)v_t_24306.f[0]);
                                                    if ((v_tag_24307 == ((int64_t)0ULL))) {
                                                      V v_x_24310 = v_field_24308;
                                                      V v_j_24311 = v_field_24309;
                                                      double v_t_24312 = ({ V a_0 = v_x_24310; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24310); r_; });
                                                      V v_x_24313 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24312)});
                                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24313, v_j_24311}});
                                                    } else {
                                                      heff_drop(v_field_24308);
                                                      heff_drop(v_field_24309);
                                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11, 2, "px");

HeffT3 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    return (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(v_z_241, v_z_242));
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
      {
        V v_field_245 = v_t_243.f[1];
        V v_field_246 = v_t_243.f[2];
        int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          V v_x_247 = v_field_245;
          V v_j_248 = v_field_246;
          HeffT3 v_t_249 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_247, v_z_241, v_j_248));
          {
            V v_field_2411 = v_t_249.f[1];
            V v_field_2412 = v_t_249.f[2];
            int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
            if ((v_tag_2410 == ((int64_t)0ULL))) {
              V v_x_2413 = v_field_2411;
              V v_j_2414 = v_field_2412;
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2413}), v_j_2414}});
            } else {
              heff_drop(v_field_2411);
              heff_drop(v_field_2412);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_field_245);
          heff_drop(v_field_246);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT3 v_t_2415 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_241, v_z_242));
        {
          V v_field_2417 = v_t_2415.f[1];
          V v_field_2418 = v_t_2415.f[2];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_x_2419 = v_field_2417;
            V v_j_2420 = v_field_2418;
            HeffT3 v_t_2421 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2420));
            {
              V v_field_2423 = v_t_2421.f[1];
              V v_field_2424 = v_t_2421.f[2];
              int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
              if ((v_tag_2422 == ((int64_t)0ULL))) {
                V v_x_2425 = v_field_2423;
                V v_j_2426 = v_field_2424;
                HeffT3 v_t_2427 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2425, v_z_241, v_j_2426));
                {
                  V v_field_2429 = v_t_2427.f[1];
                  V v_field_2430 = v_t_2427.f[2];
                  int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
                  if ((v_tag_2428 == ((int64_t)0ULL))) {
                    V v_x_2431 = v_field_2429;
                    V v_j_2432 = v_field_2430;
                    HeffT3 v_t_2433 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2432));
                    {
                      V v_field_2435 = v_t_2433.f[1];
                      V v_field_2436 = v_t_2433.f[2];
                      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                      if ((v_tag_2434 == ((int64_t)0ULL))) {
                        V v_x_2437 = v_field_2435;
                        V v_j_2438 = v_field_2436;
                        HeffT3 v_t_2439 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)); V a_1 = v_x_2437; V a_2 = heff_dup(v_z_241); V a_3 = v_j_2438; HeffT3 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2437); r_; });
                        {
                          V v_field_2441 = v_t_2439.f[1];
                          V v_field_2442 = v_t_2439.f[2];
                          int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
                          if ((v_tag_2440 == ((int64_t)0ULL))) {
                            V v_x_2443 = v_field_2441;
                            V v_j_2444 = v_field_2442;
                            HeffT3 v_t_2445 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(v_z_241, v_j_2444));
                            {
                              V v_field_2447 = v_t_2445.f[1];
                              V v_field_2448 = v_t_2445.f[2];
                              int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
                              if ((v_tag_2446 == ((int64_t)0ULL))) {
                                V v_x_2449 = v_field_2447;
                                V v_j_2450 = v_field_2448;
                                V v_s_2451 = heff_dup(v_z_241);
                                V v_i_2452 = v_j_2450;
                                HeffT3 v_t_2453 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2451, v_i_2452));
                                {
                                  V v_field_2455 = v_t_2453.f[1];
                                  V v_field_2456 = v_t_2453.f[2];
                                  int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                                  V v_x3_2459;
                                  if ((v_tag_2454 == ((int64_t)0ULL))) {
                                    V v_x_2457 = v_field_2455;
                                    V v_j_2458 = v_field_2456;
                                    v_x3_2459 = ({ V a_0 = v_x_2457; V a_1 = v_s_2451; V a_2 = v_j_2458; V r_ = (g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(a_0, a_1, a_2)); heff_drop(v_x_2457); heff_drop(v_s_2451); r_; });
                                  } else {
                                    heff_drop(v_s_2451);
                                    heff_drop(v_field_2455);
                                    heff_drop(v_field_2456);
                                    v_x3_2459 = NTAG(TAG_Nothing);
                                  }
                                  switch (heff_tag_of(v_x3_2459)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_x_2419);
                                    heff_drop(v_x_2431);
                                    heff_drop(v_x_2443);
                                    heff_drop(v_x_2449);
                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                  }
                                  case TAG_Just: {
                                    V v_x31_2460 = heff_field(v_x3_2459, 0);
                                    heff_take_n(v_x3_2459, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_2460)) {
                                    case TAG_MkPair: {
                                      V v_x_2461 = heff_field(v_x31_2460, 0);
                                      V v_j_2462 = heff_field(v_x31_2460, 1);
                                      heff_take_n(v_x31_2460, 3ULL, 2);
                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2419, v_x_2431, v_x_2443, v_x_2449, v_x_2461}), v_j_2462}});
                                    }
                                    default: return ((HeffT3){{heff_nomatch(v_x31_2460)}});
                                    }
                                  }
                                  default: return ((HeffT3){{heff_nomatch(v_x3_2459)}});
                                  }
                                }
                              } else {
                                heff_drop(v_x_2419);
                                heff_drop(v_x_2431);
                                heff_drop(v_x_2443);
                                heff_drop(v_field_2447);
                                heff_drop(v_field_2448);
                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                              }
                            }
                          } else {
                            heff_drop(v_x_2419);
                            heff_drop(v_x_2431);
                            heff_drop(v_field_2441);
                            heff_drop(v_field_2442);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        heff_drop(v_x_2419);
                        heff_drop(v_x_2431);
                        heff_drop(v_field_2435);
                        heff_drop(v_field_2436);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    heff_drop(v_x_2419);
                    heff_drop(v_field_2429);
                    heff_drop(v_field_2430);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              } else {
                heff_drop(v_x_2419);
                heff_drop(v_field_2423);
                heff_drop(v_field_2424);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_field_2417);
            heff_drop(v_field_2418);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT3 v_t_2463 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_241, v_z_242));
          {
            V v_field_2465 = v_t_2463.f[1];
            V v_field_2466 = v_t_2463.f[2];
            int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
            if ((v_tag_2464 == ((int64_t)0ULL))) {
              V v_x_2467 = v_field_2465;
              V v_j_2468 = v_field_2466;
              HeffT3 v_t_2469 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_z_241, v_j_2468));
              {
                V v_field_2471 = v_t_2469.f[1];
                V v_field_2472 = v_t_2469.f[2];
                int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                if ((v_tag_2470 == ((int64_t)0ULL))) {
                  V v_x_2473 = v_field_2471;
                  V v_j_2474 = v_field_2472;
                  HeffT3 v_t_2475 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_j_2474));
                  {
                    V v_field_2477 = v_t_2475.f[1];
                    V v_field_2478 = v_t_2475.f[2];
                    int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
                    if ((v_tag_2476 == ((int64_t)0ULL))) {
                      V v_x_2479 = v_field_2477;
                      V v_j_2480 = v_field_2478;
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2467, v_x_2473, v_x_2479}), v_j_2480}});
                    } else {
                      heff_drop(v_x_2467);
                      heff_drop(v_x_2473);
                      heff_drop(v_field_2477);
                      heff_drop(v_field_2478);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_x_2467);
                  heff_drop(v_field_2471);
                  heff_drop(v_field_2472);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_field_2465);
              heff_drop(v_field_2466);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            V v_s_2481 = heff_dup(v_z_241);
            V v_i_2482 = v_z_242;
            HeffT3 v_t_2483 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2481, v_i_2482));
            {
              V v_field_2485 = v_t_2483.f[1];
              V v_field_2486 = v_t_2483.f[2];
              int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
              V v_x3_2499;
              if ((v_tag_2484 == ((int64_t)0ULL))) {
                V v_x_2487 = v_field_2485;
                V v_j_2488 = v_field_2486;
                HeffT3 v_t_2489 = ({ V a_0 = v_x_2487; V a_1 = v_s_2481; V a_2 = v_j_2488; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(a_0, a_1, a_2)); heff_drop(v_s_2481); r_; });
                {
                  V v_field_2491 = v_t_2489.f[1];
                  V v_field_2492 = v_t_2489.f[2];
                  int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
                  if ((v_tag_2490 == ((int64_t)0ULL))) {
                    V v_x_2493 = v_field_2491;
                    V v_j_2494 = v_field_2492;
                    V v_t_2495 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2493)));
                    V v_t_2496 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2493));
                    V v_t_2497 = (g_list_2emap_24s1173914895x100384474(v_x_2493));
                    V v_x_2498 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2495), v_t_2496, heff_arrayFromList(v_t_2497)});
                    v_x3_2499 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2498, v_j_2494})});
                  } else {
                    heff_drop(v_field_2491);
                    heff_drop(v_field_2492);
                    v_x3_2499 = NTAG(TAG_Nothing);
                  }
                }
              } else {
                heff_drop(v_s_2481);
                heff_drop(v_field_2485);
                heff_drop(v_field_2486);
                v_x3_2499 = NTAG(TAG_Nothing);
              }
              switch (heff_tag_of(v_x3_2499)) {
              case TAG_Nothing: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_24100 = heff_field(v_x3_2499, 0);
                V v_ru_24x3_2499_24Just = heff_take_reuse_n(v_x3_2499, 1ULL, 1);
                switch (heff_tag_of(v_x31_24100)) {
                case TAG_MkPair: {
                  V v_x_24101 = heff_field(v_x31_24100, 0);
                  V v_j_24102 = heff_field(v_x31_24100, 1);
                  heff_take_n(v_x31_24100, 3ULL, 2);
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_2499_24Just, TAG_SSum, 1, (V[]){v_x_24101}), v_j_24102}});
                }
                default: return ((HeffT3){{heff_nomatch(v_x31_24100)}});
                }
              }
              default: return ((HeffT3){{heff_nomatch(v_x3_2499)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT3 v_t_24103 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
              {
                V v_field_24105 = v_t_24103.f[1];
                V v_field_24106 = v_t_24103.f[2];
                int64_t v_tag_24104 = ((int64_t)v_t_24103.f[0]);
                if ((v_tag_24104 == ((int64_t)0ULL))) {
                  V v_x_24107 = v_field_24105;
                  V v_j_24108 = v_field_24106;
                  HeffT3 v_t_24109 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24107, v_z_241, v_j_24108));
                  {
                    V v_field_24111 = v_t_24109.f[1];
                    V v_field_24112 = v_t_24109.f[2];
                    int64_t v_tag_24110 = ((int64_t)v_t_24109.f[0]);
                    if ((v_tag_24110 == ((int64_t)0ULL))) {
                      V v_x_24113 = v_field_24111;
                      V v_j_24114 = v_field_24112;
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_24113}), v_j_24114}});
                    } else {
                      heff_drop(v_field_24111);
                      heff_drop(v_field_24112);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_field_24105);
                  heff_drop(v_field_24106);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SPrimInt), v_z_242}});
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SPrimFloat), v_z_242}});
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SPrimString), v_z_242}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SPrimRune), v_z_242}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT3 v_t_24115 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                        {
                          V v_field_24117 = v_t_24115.f[1];
                          V v_field_24118 = v_t_24115.f[2];
                          int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
                          if ((v_tag_24116 == ((int64_t)0ULL))) {
                            V v_x_24119 = v_field_24117;
                            V v_j_24120 = v_field_24118;
                            HeffT3 v_t_24121 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24119, v_z_241, v_j_24120));
                            {
                              V v_field_24123 = v_t_24121.f[1];
                              V v_field_24124 = v_t_24121.f[2];
                              int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
                              if ((v_tag_24122 == ((int64_t)0ULL))) {
                                V v_x_24125 = v_field_24123;
                                V v_j_24126 = v_field_24124;
                                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_24125}), v_j_24126}});
                              } else {
                                heff_drop(v_field_24123);
                                heff_drop(v_field_24124);
                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                              }
                            }
                          } else {
                            heff_drop(v_field_24117);
                            heff_drop(v_field_24118);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11))) {
                          HeffT3 v_t_24127 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_241, v_z_242));
                          {
                            V v_field_24129 = v_t_24127.f[1];
                            V v_field_24130 = v_t_24127.f[2];
                            int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
                            if ((v_tag_24128 == ((int64_t)0ULL))) {
                              V v_x_24131 = v_field_24129;
                              V v_j_24132 = v_field_24130;
                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SFixed, 1, (V[]){v_x_24131}), v_j_24132}});
                            } else {
                              heff_drop(v_field_24129);
                              heff_drop(v_field_24130);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}