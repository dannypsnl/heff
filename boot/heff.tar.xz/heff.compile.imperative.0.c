// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_BocGiven 26228
#define TAG_BocNew 29139
#define TAG_BocTaken 53948
#define TAG_BocWhen 59622
#define TAG_CustodianDue 8759
#define TAG_CustodyIn 58670
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FuelTick 47424
#define TAG_FuelTicks 28388
#define TAG_IntShl 35657
#define TAG_IntShr 35663
#define TAG_Keep 49586
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_Panic 15447
#define TAG_PartVal 41444
#define TAG_Perform 19235
#define TAG_PerformAt 64592
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_cond 9554921
#define LBL_full 9650006
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_simple 1044855005
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_tl 10463
#define LBL_toDest 1077793512
#define LBL_val 326043
static uint32_t shape_full__simple__tail__bindTo__toDest__atom__op__pred[] = {LBL_full, LBL_simple, LBL_tail, LBL_bindTo, LBL_toDest, LBL_atom, LBL_op, LBL_pred};
HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo;
V g_heff_2ecompile_2eimperative_2econdIf(V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_clo;
V g_heff_2ecompile_2eimperative_2econdIf_24dps(V, V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_24dps_clo;
V g_heff_2ecompile_2eimperative_2econdPred(V, V);
V g_heff_2ecompile_2eimperative_2econdPred_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdPred_clo;
V g_heff_2ecompile_2eimperative_2econdShaped(V);
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdShaped_clo;
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
HeffT8 g_heff_2ecompile_2eimperative_2egenOf_24cpr(V);
V g_heff_2ecompile_2eimperative_2eisSimple(V);
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisSimple_clo;
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284(V);
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_clo;
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps(V, V);
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps_clo;
V g_heff_2ecompile_2eimperative_2eonceK_get(void);
V g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(V);
V g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_clo;
V g_heff_2ecompile_2eimperative_2eonceSt(V, V);
V g_heff_2ecompile_2eimperative_2eonceSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSt_clo;
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(V, V);
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_clo;
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(V);
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_clo;
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps(V, V);
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps_clo;
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(V);
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(V, V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_clo;
V g_heff_2ecompile_2eimperative_2eopOf(V, V);
V g_heff_2ecompile_2eimperative_2eopOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopOf_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eimperative_2epartsVal(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epredAny(V, V);
V g_heff_2ecompile_2eimperative_2epredAny_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredAny_clo;
V g_heff_2ecompile_2eimperative_2epredLets(V, V);
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_clo;
HeffT2 g_heff_2ecompile_2eimperative_2epredLets_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2epredLets_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epredLets_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epredValue(V, V);
V g_heff_2ecompile_2eimperative_2epredValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredValue_clo;
HeffT2 g_heff_2ecompile_2eimperative_2esinkTest_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1155474388x1593011685(V);
V g_list_2emap_24s1155474388x1593011685_entry(V self, V *a);
extern Clo g_list_2emap_24s1155474388x1593011685_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s419081849x11460228(V);
V g_list_2emap_24s419081849x11460228_entry(V self, V *a);
extern Clo g_list_2emap_24s419081849x11460228_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_LIT(g_heff_2ecompile_2eimperative_2econdShaped_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2econdShaped_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2econdShaped_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2econdShaped_str3, 5, "False");
Clo g_heff_2ecompile_2eimperative_2econdShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdShaped_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2econdShaped(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    V v_e2_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 3);
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eimperative_2econdShaped_str0), 2) || heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eimperative_2econdShaped_str1), 2)));
      heff_drop(v_t_2416);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2422));
    if (heff_intEq_c(v_t_2423, MK_INT(2LL))) {
      HeffT2 v_t_2424 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2econdShaped_str2), v_arms_2422));
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_t_2427 = v_field_2426;
          HeffT2 v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2eimperative_2econdShaped_str3); V a_1 = v_arms_2422; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(a_0, a_1)); heff_drop(v_arms_2422); r_; });
          {
            V v_field_2430 = v_t_2428.f[1];
            int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
            if ((v_tag_2429 == ((int64_t)0ULL))) {
              V v_f_2431 = v_field_2430;
              V v_t_2432 = v_t_2427;
              V v_f_2433 = v_f_2431;
              V v_t_2434 = (g_heff_2ecompile_2eimperative_2econdShaped(v_t_2432));
              if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
                heff_drop(v_t_2434);
                V t_0 = v_f_2433;
                v_e_240 = t_0;
                goto top;
              } else {
                heff_drop(v_f_2433);
                heff_drop(v_t_2434);
                return NTAG(TAG_False);
              }
            } else {
              heff_drop(v_t_2427);
              heff_drop(v_field_2430);
              return NTAG(TAG_False);
            }
          }
        } else {
          heff_drop(v_arms_2422);
          heff_drop(v_field_2426);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_arms_2422);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2436 = heff_field(v_e_240, 0);
    V v_e2_2437 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2437)) {
    case TAG_Nil: {
      heff_drop(v_p_2436);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2439 = heff_field(v_e2_2437, 1);
      heff_take_n(v_e2_2437, 2ULL, 2);
      switch (heff_tag_of(v_e22_2439)) {
      case TAG_Nil: {
        heff_drop(v_p_2436);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2441 = heff_field(v_e22_2439, 1);
        heff_take_n(v_e22_2439, 2ULL, 2);
        switch (heff_tag_of(v_e222_2441)) {
        case TAG_Nil: {
          return ({ V a_0 = v_p_2436; V r_ = (g_heff_2ecompile_2eir_2eisRel(a_0)); heff_drop(v_p_2436); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2441, 0ULL, 2);
          heff_drop(v_p_2436);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2441);
        }
      }
      default: return heff_nomatch(v_e22_2439);
      }
    }
    default: return heff_nomatch(v_e2_2437);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2econdShaped(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2econdIf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdIf_24dps_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2econdIf_24dps(V v_x1_240, V v_t_241, V v_e_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_t_241);
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_e_242);
  }
  case TAG_PNot: {
    V v_c_244 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_c_244;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    V t_3 = v_d_243;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PIf: {
    V v_a_245 = heff_field(v_x1_240, 0);
    V v_b_246 = heff_field(v_x1_240, 1);
    V v_c_247 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2441;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_PRel: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_PBool: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    case TAG_PLet: {
      v_t_2441 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x1_240_24PIf, 3);
      heff_drop(v_t_2441);
      V v_t_2442 = (g_heff_2ecompile_2eimperative_2econdIf(v_b_246, heff_dup(v_t_241), heff_dup(v_e_242)));
      V v_t_2443 = (g_heff_2ecompile_2eimperative_2econdIf(v_c_247, v_t_241, v_e_242));
      V t_0 = v_a_245;
      V t_1 = v_t_2442;
      V t_2 = v_t_2443;
      V t_3 = v_d_243;
      v_x1_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2441);
      V v_t_2444 = heff_tag_at_n(v_ru_24x1_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_245, v_b_246, v_c_247}), v_t_241, v_e_242});
      return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_t_2444);
    }
  }
  case TAG_PLet: {
    V v_x_2445 = heff_field(v_x1_240, 0);
    V v_o_2446 = heff_field(v_x1_240, 1);
    V v_c_2447 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PLet = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_cell_2448 = heff_tag_re_n(v_ru_24x1_240_24PLet, TAG_PLet, 3, 3ULL, (V[]){v_x_2445, v_o_2446, heff_hole()});
    V v_u_2449 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_cell_2448);
    V t_0 = v_c_2447;
    V t_1 = v_t_241;
    V t_2 = v_e_242;
    V t_3 = v_u_2449;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PFalse: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_x1_240);
      }
      case TAG_PRel: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PNot, 1, (V[]){v_x1_240}));
      }
      case TAG_PFalse: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PRel: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PBool: {
      return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PNot: {
      return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PIf: {
      return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    case TAG_PLet: {
      return heff_setField(heff_dup(v_d_243), MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242}));
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  }
}
V g_heff_2ecompile_2eimperative_2econdIf_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eimperative_2econdIf_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredValue_str0, 2, "c$");
V g_heff_2ecompile_2eimperative_2epredValue_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epredValue_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epredValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredValue_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredValue(V v_g_240, V v_e_241) {
top: ;
  V v_simple_242 = heff_take_field(v_g_240, 1);
  V v_bindTo_243 = heff_get_n(v_g_240, 3, 8);
  V v_t_244 = (g_heff_2ecompile_2eimperative_2eisSimple(v_e_241));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_bindTo_243);
    heff_drop(v_t_244);
    V v_m_245 = heff_tr(heff_call(v_simple_242, 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2epredValue_lam0, 1, 1, (V[]){v_m_245});
  } else {
    heff_drop(v_simple_242);
    heff_drop(v_t_244);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2epredValue_lam1, 1, 2, (V[]){v_bindTo_243, v_e_241});
  }
}
V g_heff_2ecompile_2eimperative_2epredValue_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epredValue(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2epredValue_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_PBool, 1, (V[]){v_x_248})});
    return heff_tag_re_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2410, v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2eimperative_2epredValue_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_bindTo_243 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_x_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eimperative_2epredValue_str0), heff_intShow(heff_dup(v_n_2411)));
  heff_clo_take(self, 2);
  V v_m_2413 = heff_tr(heff_call(v_bindTo_243, 2, (V[]){heff_dup(v_x_2412), v_e_241}));
  V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){heff_intAdd(v_n_2411, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = heff_tag_n(TAG_PBool, 1, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_x_2412})});
    V v_x_2418 = ({ V a_0 = v_x_2415; V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2eimperative_2epredLets(a_0, a_1)); heff_drop(v_x_2415); heff_drop_tag(v_t_2417, 1); r_; });
    return heff_tag_re_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2418, v_n_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredAny_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredAny_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredAny_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2epredAny_str3, 5, "False");
V g_heff_2ecompile_2eimperative_2epredAny_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epredAny_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epredAny_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredAny_lam1, 1, 0};
V g_heff_2ecompile_2eimperative_2epredAny_lam2(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epredAny_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredAny_lam2, 1, 0};
V g_heff_2ecompile_2eimperative_2epredAny_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2epredAny_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2epredAny_lam5(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epredAny_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredAny_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredAny(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    HeffT2 v_t_2411 = (g_heff_2ecompile_2eimperative_2esinkTest_24cpr(v_x_248, heff_dup(v_a_249), heff_dup(v_b_2410)));
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        heff_drop(v_x_248);
        heff_drop(v_a_249);
        heff_drop(v_b_2410);
        V v_e2_2414 = v_field_2413;
        return heff_tail(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_e2_2414});
      } else {
        heff_drop(v_field_2413);
        V v_m_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_x_248, v_a_249}));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2epredAny_lam0, 1, 3, (V[]){v_m_2415, v_g_240, v_b_2410});
      }
    }
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_ETag: {
    V v_e2_27_2433 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_27_2433)) {
    case TAG_Nil: {
      heff_drop_rec(v_g_240, 8);
      switch (heff_tag_of(v_e_241)) {
      case TAG_ETag: {
        V v_t_2435 = heff_field(v_e_241, 0);
        heff_take_n(v_e_241, 1ULL, 3);
        if (heff_strEq_c_lent(v_t_2435, ((V)&g_heff_2ecompile_2eimperative_2epredAny_str0), 2)) {
          heff_drop(v_t_2435);
          return ((V)&g_heff_2ecompile_2eimperative_2epredAny_lam1_clo);
        } else {
          if (heff_strEq_c_lent(v_t_2435, ((V)&g_heff_2ecompile_2eimperative_2epredAny_str1), 2)) {
            heff_drop(v_t_2435);
            return ((V)&g_heff_2ecompile_2eimperative_2epredAny_lam2_clo);
          } else {
            return heff_clo_n(g_heff_2ecompile_2eimperative_2epredAny_lam3, 1, 1, (V[]){v_t_2435});
          }
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_e2_27_2433, 0ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
    }
    default: return heff_nomatch(v_e2_27_2433);
    }
  }
  case TAG_EMatch: {
    V v_s_2447 = heff_dup(heff_field(v_e_241, 0));
    V v_arms_2448 = heff_dup(heff_field(v_e_241, 1));
    V v_t_2449 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2448));
    if (heff_intEq_c(v_t_2449, MK_INT(2LL))) {
      HeffT2 v_t_2450 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2epredAny_str2), v_arms_2448));
      {
        V v_field_2452 = v_t_2450.f[1];
        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
        if ((v_tag_2451 == ((int64_t)0ULL))) {
          V v_t_2453 = v_field_2452;
          HeffT2 v_t_2454 = ({ V a_0 = ((V)&g_heff_2ecompile_2eimperative_2epredAny_str3); V a_1 = v_arms_2448; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(a_0, a_1)); heff_drop(v_arms_2448); r_; });
          {
            V v_field_2456 = v_t_2454.f[1];
            int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
            if ((v_tag_2455 == ((int64_t)0ULL))) {
              heff_drop_tag(v_e_241, 2);
              V v_f_2457 = v_field_2456;
              V v_t_2458 = v_t_2453;
              V v_f_2459 = v_f_2457;
              V v_m_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_s_2447}));
              return heff_clo_n(g_heff_2ecompile_2eimperative_2epredAny_lam4, 1, 4, (V[]){v_m_2460, v_g_240, v_t_2458, v_f_2459});
            } else {
              heff_drop(v_s_2447);
              heff_drop(v_t_2453);
              heff_drop(v_field_2456);
              HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
            }
          }
        } else {
          heff_drop(v_s_2447);
          heff_drop(v_arms_2448);
          heff_drop(v_field_2452);
          HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
        }
      }
    } else {
      heff_drop(v_s_2447);
      heff_drop(v_arms_2448);
      HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
    }
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EPrimCall: {
    V v_p_2479 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_27_2480 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_27_2480)) {
    case TAG_Nil: {
      heff_drop(v_p_2479);
      HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
    }
    case TAG_Cons: {
      V v_a_2481 = heff_field(v_e2_27_2480, 0);
      V v_e2_272_2482 = heff_field(v_e2_27_2480, 1);
      heff_take_n(v_e2_27_2480, 3ULL, 2);
      switch (heff_tag_of(v_e2_272_2482)) {
      case TAG_Nil: {
        heff_drop(v_p_2479);
        heff_drop(v_a_2481);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
      }
      case TAG_Cons: {
        V v_b_2483 = heff_field(v_e2_272_2482, 0);
        V v_e2_2722_2484 = heff_field(v_e2_272_2482, 1);
        heff_take_n(v_e2_272_2482, 3ULL, 2);
        switch (heff_tag_of(v_e2_2722_2484)) {
        case TAG_Nil: {
          V v_t_2485 = (g_heff_2ecompile_2eir_2eisRel(v_p_2479));
          if ((heff_dup(v_t_2485) == NTAG(TAG_True))) {
            heff_drop_tag(v_e_241, 2);
            heff_drop(v_t_2485);
            V v_m_2486 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_a_2481}));
            return heff_clo_n(g_heff_2ecompile_2eimperative_2epredAny_lam5, 1, 4, (V[]){v_m_2486, v_g_240, v_b_2483, v_p_2479});
          } else {
            heff_drop(v_p_2479);
            heff_drop(v_a_2481);
            heff_drop(v_b_2483);
            heff_drop(v_t_2485);
            HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e2_2722_2484, 0ULL, 2);
          heff_drop(v_p_2479);
          heff_drop(v_a_2481);
          heff_drop(v_b_2483);
          HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
        }
        default: return heff_nomatch(v_e2_2722_2484);
        }
      }
      default: return heff_nomatch(v_e2_272_2482);
      }
    }
    default: return heff_nomatch(v_e2_27_2480);
    }
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EBool: {
    V v_c_24120 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    return ({ V a_0 = v_g_240; V a_1 = v_c_24120; V r_ = (g_heff_2ecompile_2eimperative_2econdPred(a_0, a_1)); heff_drop_rec(v_g_240, 8); r_; });
  }
  case TAG_ESet: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epredValue(v_g_240, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eimperative_2epredAny_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epredAny(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2epredAny_lam0(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_b_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_m_2420 = heff_tr(heff_call(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_b_2410}));
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_n_2419}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_n_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      V v_x_2425;
      switch (heff_tag_of(v_x_2422)) {
      case TAG_Nothing: {
        heff_drop(v_x_2418);
        v_x_2425 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_q_2424 = heff_field(v_x_2422, 0);
        V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
        v_x_2425 = ({ V a_0 = v_ru_24x_2422_24Just; V a_1 = v_x_2418; V a_2 = v_q_2424; V r_ = (g_heff_2ecompile_2eimperative_2epredLets_24tok1(a_0, a_1, a_2)); heff_drop(v_x_2418); heff_drop(v_q_2424); r_; });
        break;
      }
      default: heff_nomatch(v_x_2422);
      }
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2425, v_n_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eimperative_2epredAny_lam1(V self, V *args) {
  V v_n_2438 = args[0];
  V v_t_2439 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_PTrue)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, v_n_2438});
}
V g_heff_2ecompile_2eimperative_2epredAny_lam2(V self, V *args) {
  V v_n_2440 = args[0];
  V v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_PFalse)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_n_2440});
}
V g_heff_2ecompile_2eimperative_2epredAny_lam3(V self, V *args) {
  V v_n_2442 = args[0];
  V v_t_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tag_n(TAG_STag, 3, (V[]){v_t_2435, NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2444 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_PBool, 1, (V[]){v_t_2443})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, v_n_2442});
}
V g_heff_2ecompile_2eimperative_2epredAny_lam4(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_2458 = heff_env(self)[2];
  V v_f_2459 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
    V v_m_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_t_2458}));
    V v_x2_2466 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_n_2464}));
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_MkPair: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_n_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      V v_m_2469 = heff_tr(heff_call(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_f_2459}));
      V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_n_2468}));
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_MkPair: {
        V v_x_2471 = heff_field(v_x2_2470, 0);
        V v_n_2472 = heff_field(v_x2_2470, 1);
        heff_take_n(v_x2_2470, 3ULL, 2);
        V v_x_2477;
        switch (heff_tag_of(v_x_2463)) {
        case TAG_Nothing: {
          heff_drop(v_x_2467);
          heff_drop(v_x_2471);
          v_x_2477 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_cs_2473 = heff_field(v_x_2463, 0);
          V v_ru_24x_2463_24Just = heff_take_reuse_n(v_x_2463, 1ULL, 1);
          switch (heff_tag_of(v_x_2467)) {
          case TAG_Nothing: {
            heff_drop(v_x_2471);
            heff_drop(v_cs_2473);
            heff_drop_cell(v_ru_24x_2463_24Just, 1);
            v_x_2477 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_ct_2474 = heff_field(v_x_2467, 0);
            heff_take_n(v_x_2467, 1ULL, 1);
            switch (heff_tag_of(v_x_2471)) {
            case TAG_Nothing: {
              heff_drop(v_cs_2473);
              heff_drop_cell(v_ru_24x_2463_24Just, 1);
              heff_drop(v_ct_2474);
              v_x_2477 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_cf_2475 = heff_field(v_x_2471, 0);
              heff_take_n(v_x_2471, 1ULL, 1);
              V v_t_2476 = (g_heff_2ecompile_2eimperative_2econdIf(v_cs_2473, v_ct_2474, v_cf_2475));
              v_x_2477 = heff_tag_at_n(v_ru_24x_2463_24Just, TAG_Just, 1, (V[]){v_t_2476});
              break;
            }
            default: heff_nomatch(v_x_2471);
            }
            break;
          }
          default: heff_nomatch(v_x_2467);
          }
          break;
        }
        default: heff_nomatch(v_x_2463);
        }
        return heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){v_x_2477, v_n_2472});
      }
      default: return heff_nomatch(v_x2_2470);
      }
    }
    default: return heff_nomatch(v_x2_2466);
    }
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2eimperative_2epredAny_lam5(V self, V *args) {
  V v_n_2487 = args[0];
  V v_m_2486 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_b_2483 = heff_env(self)[2];
  V v_p_2479 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2488 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_n_2487}));
  switch (heff_tag_of(v_x2_2488)) {
  case TAG_MkPair: {
    V v_x_2489 = heff_field(v_x2_2488, 0);
    V v_n_2490 = heff_field(v_x2_2488, 1);
    V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
    V v_m_2491 = heff_tr(heff_call(heff_get_n(v_g_240, 5, 8), 1, (V[]){v_b_2483}));
    V v_x2_2492 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_n_2490}));
    switch (heff_tag_of(v_x2_2492)) {
    case TAG_MkPair: {
      V v_x_2493 = heff_field(v_x2_2492, 0);
      V v_n_2494 = heff_field(v_x2_2492, 1);
      V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
      V v_t_2497;
      switch (heff_tag_of(v_x_2489)) {
      case TAG_MkPair: {
        V v_x_2495 = heff_dup(heff_field(v_x_2489, 0));
        v_t_2497 = v_x_2495;
        break;
      }
      default: heff_nomatch(v_x_2489);
      }
      V v_t_24100;
      switch (heff_tag_of(v_x_2493)) {
      case TAG_MkPair: {
        V v_x_2498 = heff_dup(heff_field(v_x_2493, 0));
        v_t_24100 = v_x_2498;
        break;
      }
      default: heff_nomatch(v_x_2493);
      }
      V v_t_24101 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2492_24MkPair, v_t_2497, v_t_24100));
      V v_t_24104;
      switch (heff_tag_of(v_x_2489)) {
      case TAG_MkPair: {
        V v_y_24103 = heff_field(v_x_2489, 1);
        heff_take_n(v_x_2489, 2ULL, 2);
        v_t_24104 = v_y_24103;
        break;
      }
      default: heff_nomatch(v_x_2489);
      }
      V v_t_24107;
      switch (heff_tag_of(v_x_2493)) {
      case TAG_MkPair: {
        V v_y_24106 = heff_field(v_x_2493, 1);
        heff_take_n(v_x_2493, 2ULL, 2);
        v_t_24107 = v_y_24106;
        break;
      }
      default: heff_nomatch(v_x_2493);
      }
      V v_x_24108 = ({ V a_0 = v_t_24101; V b_1 = heff_tag_n(TAG_PRel, 3, (V[]){v_p_2479, v_t_24104, v_t_24107}); V r_ = (g_heff_2ecompile_2eimperative_2epredLets(a_0, b_1)); heff_drop(v_t_24101); heff_drop(b_1); r_; });
      return heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_MkPair, 2, (V[]){v_x_24108, v_n_2494});
    }
    default: return heff_nomatch(v_x2_2492);
    }
  }
  default: return heff_nomatch(v_x2_2488);
  }
}
V g_heff_2ecompile_2eimperative_2eatomsOf_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eatomsOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eatomsOf_lam0, 1, 0};
V g_heff_2ecompile_2eimperative_2eatomsOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eatomsOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eatomsOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2eatomsOf_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_e_244}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eatomsOf_lam1, 1, 3, (V[]){v_m_246, v_g_240, v_es_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eatomsOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eatomsOf_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_n_242});
}
V g_heff_2ecompile_2eimperative_2eatomsOf_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_es_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_es_245));
    V v_x2_2412 = heff_tr(heff_call(v_t_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_dup(heff_field(v_x_249, 0));
        v_t_2417 = v_x_2415;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_dup(heff_field(v_x_2413, 0));
        v_t_2420 = v_x_2418;
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_y_2423 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2424 = v_y_2423;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_2413, 1);
        heff_take_n(v_x_2413, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_x_2428 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2427})});
      return heff_tag_re_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2428, v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2eopOf_lam6(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eopOf_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopOf_lam6, 1, 0};
V g_heff_2ecompile_2eimperative_2eopOf_lam7(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2eopOf_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopOf_lam7, 1, 0};
V g_heff_2ecompile_2eimperative_2eopOf_lam8(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eopOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eopOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EApp: {
    V v_f_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_242, v_args_243})));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam0, 1, 1, (V[]){v_m_244});
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x2_241, 0);
    V v_ts_2416 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2417 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x2_241_24ERecord, heff_dup(v_fs_2415)));
    V v_m_2418 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_t_2417));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam1, 1, 3, (V[]){v_m_2418, v_fs_2415, v_ts_2416});
  }
  case TAG_EProj: {
    V v_e_2428 = heff_field(v_x2_241, 0);
    V v_l_2429 = heff_field(v_x2_241, 1);
    V v_sh_2430 = heff_field(v_x2_241, 2);
    V v_t_2431 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2428, NTAG(TAG_Nil)});
    V v_m_2433 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_t_2432));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam2, 1, 4, (V[]){v_m_2433, v_l_2429, v_sh_2430, v_t_2431});
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_x2_241, 0);
    V v_args_2445 = heff_field(v_x2_241, 1);
    V v_ts_2446 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2447 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_args_2445));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam3, 1, 3, (V[]){v_m_2447, v_t_2444, v_ts_2446});
  }
  case TAG_EPrimCall: {
    V v_p_2456 = heff_field(v_x2_241, 0);
    V v_args_2457 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2458 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_args_2457));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam4, 1, 2, (V[]){v_m_2458, v_p_2456});
  }
  case TAG_ECall: {
    V v_k_2469 = heff_field(v_x2_241, 0);
    V v_args_2470 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2471 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_args_2470));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam5, 1, 2, (V[]){v_m_2471, v_k_2469});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2eopOf_lam6_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2eopOf_lam7_clo);
  }
  default: {
    V v_m_2485 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2eopOf_lam8, 1, 1, (V[]){v_m_2485});
  }
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eopOf_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_ss_249 = heff_field(v_x_247, 0);
      V v_vs_2410 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24MkPair = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_vs_2410)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x_247_24MkPair, 2);
        v_t_2413 = NTAG(TAG_OAbandon);
        break;
      }
      case TAG_Cons: {
        V v_fv_2411 = heff_field(v_vs_2410, 0);
        V v_avs_2412 = heff_field(v_vs_2410, 1);
        heff_take_n(v_vs_2410, 3ULL, 2);
        v_t_2413 = heff_tag_at_n(v_ru_24x_247_24MkPair, TAG_OApply, 2, (V[]){v_fv_2411, v_avs_2412});
        break;
      }
      default: heff_nomatch(v_vs_2410);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_ss_249, v_t_2413});
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_n_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam1(V self, V *args) {
  V v_n_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_fs_2415 = heff_env(self)[1];
  V v_ts_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_n_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    V v_x_2427;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_MkPair: {
      V v_ss_2423 = heff_field(v_x_2421, 0);
      V v_vs_2424 = heff_field(v_x_2421, 1);
      V v_ru_24x_2421_24MkPair = heff_take_reuse_n(v_x_2421, 3ULL, 2);
      V v_t_2425 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2415, v_vs_2424));
      V v_t_2426 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_at_n(v_ru_24x_2421_24MkPair, TAG_SRec, 2, (V[]){v_t_2425, v_ts_2416})});
      v_x_2427 = heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2423, v_t_2426});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_n_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam2(V self, V *args) {
  V v_n_2434 = args[0];
  V v_m_2433 = heff_env(self)[0];
  V v_l_2429 = heff_env(self)[1];
  V v_sh_2430 = heff_env(self)[2];
  V v_t_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2435 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2434}));
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkPair: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_n_2437 = heff_field(v_x2_2435, 1);
    V v_ru_24x2_2435_24MkPair = heff_take_reuse_n(v_x2_2435, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_2436)) {
    case TAG_MkPair: {
      V v_ss_2438 = heff_field(v_x_2436, 0);
      V v_vs_2439 = heff_field(v_x_2436, 1);
      heff_take_n(v_x_2436, 3ULL, 2);
      V v_t_2442;
      switch (heff_tag_of(v_vs_2439)) {
      case TAG_Nil: {
        heff_drop(v_l_2429);
        heff_drop(v_sh_2430);
        heff_drop(v_t_2431);
        v_t_2442 = NTAG(TAG_OAbandon);
        break;
      }
      case TAG_Cons: {
        V v_v_2440 = heff_field(v_vs_2439, 0);
        heff_take_n(v_vs_2439, 1ULL, 2);
        v_t_2442 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_n(TAG_SProj, 4, (V[]){v_v_2440, v_l_2429, v_sh_2430, v_t_2431})});
        break;
      }
      default: heff_nomatch(v_vs_2439);
      }
      v_t_2443 = heff_tag_at_n(v_ru_24x2_2435_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2438, v_t_2442});
      break;
    }
    default: heff_nomatch(v_x_2436);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_n_2437});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam3(V self, V *args) {
  V v_n_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_t_2444 = heff_env(self)[1];
  V v_ts_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_n_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_n_2451 = heff_field(v_x2_2449, 1);
    V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
    V v_t_2455;
    switch (heff_tag_of(v_x_2450)) {
    case TAG_MkPair: {
      V v_ss_2452 = heff_field(v_x_2450, 0);
      V v_vs_2453 = heff_field(v_x_2450, 1);
      heff_take_n(v_x_2450, 3ULL, 2);
      V v_t_2454 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_n(TAG_STag, 3, (V[]){v_t_2444, v_vs_2453, v_ts_2446})});
      v_t_2455 = heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2452, v_t_2454});
      break;
    }
    default: heff_nomatch(v_x_2450);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2455, v_n_2451});
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam4(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_p_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    V v_t_2468;
    switch (heff_tag_of(v_x_2461)) {
    case TAG_MkPair: {
      V v_ss_2463 = heff_field(v_x_2461, 0);
      V v_vs_2464 = heff_field(v_x_2461, 1);
      V v_ru_24x_2461_24MkPair = heff_take_reuse_n(v_x_2461, 3ULL, 2);
      V v_t_2466;
      switch (heff_tag_of(v_p_2456)) {
      case TAG_IntShl: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShr: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_ArrayIndex: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_ArrayGenerate: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_Keep: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_Panic: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_Perform: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_PerformAt: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_BocWhen: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_BocNew: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_BocTaken: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_BocGiven: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_ArrayIndexIn: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_FuelTick: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_FuelTicks: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_CustodianDue: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      case TAG_CustodyIn: {
        v_t_2466 = NTAG(TAG_True);
        break;
      }
      default: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      }
      V v_t_2467;
      if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
        heff_drop(v_t_2466);
        v_t_2467 = heff_tag_at_n(v_ru_24x_2461_24MkPair, TAG_OPrim, 2, (V[]){v_p_2456, v_vs_2464});
      } else {
        heff_drop(v_t_2466);
        v_t_2467 = heff_tag_n(TAG_OSimple, 1, (V[]){heff_tag_at_n(v_ru_24x_2461_24MkPair, TAG_SPrim, 2, (V[]){v_p_2456, v_vs_2464})});
      }
      v_t_2468 = heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2463, v_t_2467});
      break;
    }
    default: heff_nomatch(v_x_2461);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_n_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam5(V self, V *args) {
  V v_n_2472 = args[0];
  V v_m_2471 = heff_env(self)[0];
  V v_k_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2473 = heff_tr(heff_call(v_m_2471, 1, (V[]){v_n_2472}));
  switch (heff_tag_of(v_x2_2473)) {
  case TAG_MkPair: {
    V v_x_2474 = heff_field(v_x2_2473, 0);
    V v_n_2475 = heff_field(v_x2_2473, 1);
    V v_ru_24x2_2473_24MkPair = heff_take_reuse_n(v_x2_2473, 3ULL, 2);
    V v_t_2478;
    switch (heff_tag_of(v_x_2474)) {
    case TAG_MkPair: {
      V v_ss_2476 = heff_field(v_x_2474, 0);
      V v_vs_2477 = heff_field(v_x_2474, 1);
      V v_ru_24x_2474_24MkPair = heff_take_reuse_n(v_x_2474, 3ULL, 2);
      v_t_2478 = heff_tag_at_n(v_ru_24x2_2473_24MkPair, TAG_MkPair, 2, (V[]){v_ss_2476, heff_tag_at_n(v_ru_24x_2474_24MkPair, TAG_OCall, 2, (V[]){v_k_2469, v_vs_2477})});
      break;
    }
    default: heff_nomatch(v_x_2474);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, v_n_2475});
  }
  default: return heff_nomatch(v_x2_2473);
  }
}
V g_heff_2ecompile_2eimperative_2eopOf_lam6(V self, V *args) {
  V v_n_2479 = args[0];
  V v_t_2480 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_OAbandon)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2480, v_n_2479});
}
V g_heff_2ecompile_2eimperative_2eopOf_lam7(V self, V *args) {
  V v_n_2483 = args[0];
  V v_t_2484 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_OAbandon)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2484, v_n_2483});
}
V g_heff_2ecompile_2eimperative_2eopOf_lam8(V self, V *args) {
  V v_n_2486 = args[0];
  V v_m_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2487 = heff_tr(heff_call(v_m_2485, 1, (V[]){v_n_2486}));
  switch (heff_tag_of(v_x2_2487)) {
  case TAG_MkPair: {
    V v_x_2488 = heff_field(v_x2_2487, 0);
    V v_n_2489 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    V v_t_2490 = heff_tag_at_n(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_tag_n(TAG_OSimple, 1, (V[]){v_x_2488})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2490, v_n_2489});
  }
  default: return heff_nomatch(v_x2_2487);
  }
}
Clo g_heff_2ecompile_2eimperative_2egenOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2egenOf_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2egenOf(V v_full_240) {
top: ;
  HeffT8 v_t_241 = (g_heff_2ecompile_2eimperative_2egenOf_24cpr(v_full_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    V v_field_245 = v_t_241.f[3];
    V v_field_246 = v_t_241.f[4];
    V v_field_247 = v_t_241.f[5];
    V v_field_248 = v_t_241.f[6];
    V v_field_249 = v_t_241.f[7];
    return heff_rec_n(8, shape_full__simple__tail__bindTo__toDest__atom__op__pred, (V[]){v_field_242, v_field_243, v_field_244, v_field_245, v_field_246, v_field_247, v_field_248, v_field_249});
  }
}
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2egenOf(a[0]);
}
V g_heff_2ecompile_2eimperative_2epartsVal_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsVal_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsVal_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epartsVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsVal(V v_r_240, V v_v_241, V v_acc_242) {
top: ;
  V v_tl_243 = heff_take_field(v_r_240, 4);
  V v_val_244 = heff_get_n(v_r_240, 0, 5);
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SGlobal: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SInt: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFloat: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SStr: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SBytes: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFixed: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFloat32: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SPrimFn: {
    heff_drop(v_tl_243);
    heff_drop(v_val_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SLam: {
    V v_v2_2416 = heff_dup(heff_field(v_v_241, 1));
    heff_drop(v_val_244);
    switch (heff_tag_of(v_v2_2416)) {
    case TAG_MkBlock: {
      V v_t_2417 = heff_field(v_v2_2416, 0);
      V v_ru_24v2_2416_24MkBlock = heff_take_reuse_n(v_v2_2416, 1ULL, 1);
      V v_t_2418 = heff_tr(heff_call(v_tl_243, 2, (V[]){v_t_2417, v_acc_242}));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2416_24MkBlock, TAG_PartVal, 1, (V[]){v_v_241}), v_t_2418});
    }
    default: return heff_nomatch(v_v2_2416);
    }
  }
  case TAG_STag: {
    V v_args_2420 = heff_dup(heff_field(v_v_241, 1));
    heff_drop(v_tl_243);
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2420));
    V v_t_2425 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsVal_lam0, 2, 1, (V[]){v_val_244}); V a_1 = v_acc_242; V a_2 = v_t_2422; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2422); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2425});
  }
  case TAG_SRec: {
    V v_fs_2426 = heff_dup(heff_field(v_v_241, 0));
    heff_drop(v_tl_243);
    V v_t_2428 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2426));
    V v_t_2431 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsVal_lam1, 2, 1, (V[]){v_val_244}); V a_1 = v_acc_242; V a_2 = v_t_2428; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2428); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2431});
  }
  case TAG_SProj: {
    V v_w_2432 = heff_dup(heff_field(v_v_241, 0));
    heff_drop(v_tl_243);
    V v_t_2436 = heff_tr(heff_call(v_val_244, 2, (V[]){v_w_2432, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2436});
  }
  case TAG_SPrim: {
    V v_args_2438 = heff_dup(heff_field(v_v_241, 1));
    heff_drop(v_tl_243);
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2438));
    V v_t_2442 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsVal_lam2, 2, 1, (V[]){v_val_244}); V a_1 = v_acc_242; V a_2 = v_t_2439; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2439); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_241}), v_t_2442});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsVal(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2epartsVal_lam0(V self, V *args) {
  V v_acc_2423 = args[0];
  V v_x_2424 = args[1];
  V v_val_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_val_244;
  args[0] = v_x_2424;
  args[1] = v_acc_2423;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsVal_lam1(V self, V *args) {
  V v_acc_2429 = args[0];
  V v_x_2430 = args[1];
  V v_val_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_val_244;
  args[0] = v_x_2430;
  args[1] = v_acc_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsVal_lam2(V self, V *args) {
  V v_acc_2440 = args[0];
  V v_x_2441 = args[1];
  V v_val_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_val_244;
  args[0] = v_x_2441;
  args[1] = v_acc_2440;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2eonceSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eonceSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceSt_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eonceSt(V v_k_240, V v_st_241) {
top: ;
  V v_op_242 = heff_take_field(v_k_240, 1);
  V v_cond_243 = heff_take_field(v_k_240, 2);
  V v_sts_244 = heff_take_field(v_k_240, 3);
  V v_val_245 = heff_get_n(v_k_240, 0, 5);
  switch (heff_tag_of(v_st_241)) {
  case TAG_SLet: {
    V v_x_246 = heff_field(v_st_241, 0);
    V v_o_247 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SLet = heff_take_reuse_n(v_st_241, 3ULL, 2);
    heff_drop(v_cond_243);
    heff_drop(v_sts_244);
    heff_drop(v_val_245);
    V v_t_248 = heff_tr(heff_call(v_op_242, 1, (V[]){v_o_247}));
    return heff_tag_re_n(v_ru_24st_241_24SLet, TAG_SLet, 2, 1ULL, (V[]){v_x_246, v_t_248});
  }
  case TAG_SOnce: {
    V v_x_249 = heff_field(v_st_241, 0);
    V v_o_2410 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SOnce = heff_take_reuse_n(v_st_241, 3ULL, 2);
    heff_drop(v_cond_243);
    heff_drop(v_sts_244);
    heff_drop(v_val_245);
    V v_t_2411 = heff_tr(heff_call(v_op_242, 1, (V[]){v_o_2410}));
    return heff_tag_re_n(v_ru_24st_241_24SOnce, TAG_SOnce, 2, 1ULL, (V[]){v_x_249, v_t_2411});
  }
  case TAG_SDecl: {
    heff_drop(v_op_242);
    heff_drop(v_cond_243);
    heff_drop(v_sts_244);
    heff_drop(v_val_245);
    return v_st_241;
  }
  case TAG_SSet: {
    V v_x_2413 = heff_field(v_st_241, 0);
    V v_o_2414 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SSet = heff_take_reuse_n(v_st_241, 3ULL, 2);
    heff_drop(v_cond_243);
    heff_drop(v_sts_244);
    heff_drop(v_val_245);
    V v_t_2415 = heff_tr(heff_call(v_op_242, 1, (V[]){v_o_2414}));
    return heff_tag_re_n(v_ru_24st_241_24SSet, TAG_SSet, 2, 1ULL, (V[]){v_x_2413, v_t_2415});
  }
  case TAG_SIf: {
    V v_c_2416 = heff_field(v_st_241, 0);
    V v_ts_2417 = heff_field(v_st_241, 1);
    V v_fs_2418 = heff_field(v_st_241, 2);
    V v_ru_24st_241_24SIf = heff_take_reuse_n(v_st_241, 7ULL, 3);
    heff_drop(v_op_242);
    heff_drop(v_val_245);
    V v_t_2419 = heff_tr(heff_call(v_cond_243, 1, (V[]){v_c_2416}));
    V v_t_2420 = heff_tr(heff_call(heff_dup(v_sts_244), 2, (V[]){v_ts_2417, NTAG(TAG_Nothing)}));
    V v_t_2421 = heff_tr(heff_call(v_sts_244, 2, (V[]){v_fs_2418, NTAG(TAG_Nothing)}));
    return heff_tag_at_n(v_ru_24st_241_24SIf, TAG_SIf, 3, (V[]){v_t_2419, v_t_2420, v_t_2421});
  }
  case TAG_SCase: {
    V v_v_2422 = heff_field(v_st_241, 0);
    V v_arms_2423 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SCase = heff_take_reuse_n(v_st_241, 3ULL, 2);
    heff_drop(v_op_242);
    heff_drop(v_cond_243);
    V v_t_2424 = heff_tr(heff_call(v_val_245, 1, (V[]){v_v_2422}));
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eimperative_2eonceSt_lam0, 1, 1, (V[]){v_sts_244}), v_arms_2423));
    return heff_tag_at_n(v_ru_24st_241_24SCase, TAG_SCase, 2, (V[]){v_t_2424, v_t_2430});
  }
  default: return heff_nomatch(v_st_241);
  }
}
V g_heff_2ecompile_2eimperative_2eonceSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceSt(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eonceSt_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_sts_244 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkArm: {
    V v_tag_2426 = heff_field(v_x2_2425, 0);
    V v_vs_2427 = heff_field(v_x2_2425, 1);
    V v_b_2428 = heff_field(v_x2_2425, 2);
    V v_ru_24x2_2425_24MkArm = heff_take_reuse_n(v_x2_2425, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2429 = heff_tr(heff_call(v_sts_244, 2, (V[]){v_b_2428, NTAG(TAG_Nothing)}));
    return heff_tag_re_n(v_ru_24x2_2425_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_tag_2426, v_vs_2427, v_t_2429});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
Clo g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SVar: {
    return v_x2_240;
  }
  case TAG_SGlobal: {
    return v_x2_240;
  }
  case TAG_SInt: {
    return v_x2_240;
  }
  case TAG_SFloat: {
    return v_x2_240;
  }
  case TAG_SStr: {
    return v_x2_240;
  }
  case TAG_SBytes: {
    return v_x2_240;
  }
  case TAG_SFixed: {
    return v_x2_240;
  }
  case TAG_SFloat32: {
    return v_x2_240;
  }
  case TAG_SPrimFn: {
    return v_x2_240;
  }
  case TAG_SLam: {
    V v_xs_2411 = heff_field(v_x2_240, 0);
    V v_x22_2412 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x22_2412)) {
    case TAG_MkBlock: {
      V v_t_2413 = heff_field(v_x22_2412, 0);
      V v_ru_24x22_2412_24MkBlock = heff_take_reuse_n(v_x22_2412, 1ULL, 1);
      V v_t_2414 = (g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(v_t_2413));
      return heff_tag_re_n(v_ru_24x2_240_24SLam, TAG_SLam, 2, 1ULL, (V[]){v_xs_2411, heff_tag_at_n(v_ru_24x22_2412_24MkBlock, TAG_MkBlock, 1, (V[]){v_t_2414})});
    }
    default: return heff_nomatch(v_x22_2412);
    }
  }
  case TAG_STag: {
    V v_tag_2415 = heff_field(v_x2_240, 0);
    V v_args_2416 = heff_field(v_x2_240, 1);
    V v_ts_2417 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2418 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), v_args_2416));
    return heff_tag_re_n(v_ru_24x2_240_24STag, TAG_STag, 3, 5ULL, (V[]){v_tag_2415, v_t_2418, v_ts_2417});
  }
  case TAG_SRec: {
    V v_fs_2419 = heff_field(v_x2_240, 0);
    V v_ts_2420 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SRec = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2421 = (g_list_2emap_24s419081849x11460228(v_fs_2419));
    return heff_tag_re_n(v_ru_24x2_240_24SRec, TAG_SRec, 2, 2ULL, (V[]){v_t_2421, v_ts_2420});
  }
  case TAG_SProj: {
    V v_v_2422 = heff_field(v_x2_240, 0);
    V v_l_2423 = heff_field(v_x2_240, 1);
    V v_ls_2424 = heff_field(v_x2_240, 2);
    V v_t_2425 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2426 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_v_2422));
    return heff_tag_re_n(v_ru_24x2_240_24SProj, TAG_SProj, 4, 14ULL, (V[]){v_t_2426, v_l_2423, v_ls_2424, v_t_2425});
  }
  case TAG_SPrim: {
    V v_p_2427 = heff_field(v_x2_240, 0);
    V v_args_2428 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SPrim = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), v_args_2428));
    return heff_tag_re_n(v_ru_24x2_240_24SPrim, TAG_SPrim, 2, 1ULL, (V[]){v_p_2427, v_t_2429});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PTrue: {
    return heff_setField(heff_dup(v_d_241), MK_INT(0LL), v_x2_240);
  }
  case TAG_PFalse: {
    return heff_setField(heff_dup(v_d_241), MK_INT(0LL), v_x2_240);
  }
  case TAG_PRel: {
    V v_p_242 = heff_field(v_x2_240, 0);
    V v_a_243 = heff_field(v_x2_240, 1);
    V v_b_244 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_245 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_a_243));
    V v_t_246 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_b_244));
    return heff_setField(heff_dup(v_d_241), MK_INT(0LL), heff_tag_n(TAG_PRel, 3, (V[]){v_p_242, v_t_245, v_t_246}));
  }
  case TAG_PBool: {
    V v_v_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_248 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_v_247));
    return heff_setField(heff_dup(v_d_241), MK_INT(0LL), heff_tag_n(TAG_PBool, 1, (V[]){v_t_248}));
  }
  case TAG_PNot: {
    V v_c_249 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PNot = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24PNot, TAG_PNot, 1, (V[]){heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_241, MK_INT(0LL), v_cell_2410);
    V t_0 = v_c_249;
    V t_1 = v_u_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2412 = heff_field(v_x2_240, 0);
    V v_b_2413 = heff_field(v_x2_240, 1);
    V v_c_2414 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_a_2412}));
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_b_2413}));
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_c_2414}));
    return heff_setField(heff_dup(v_d_241), MK_INT(0LL), heff_tag_n(TAG_PIf, 3, (V[]){v_t_2415, v_t_2416, v_t_2417}));
  }
  case TAG_PLet: {
    V v_x_2418 = heff_field(v_x2_240, 0);
    V v_o_2419 = heff_field(v_x2_240, 1);
    V v_c_2420 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 1)), 1, (V[]){v_o_2419}));
    V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_c_2420}));
    return heff_setField(heff_dup(v_d_241), MK_INT(0LL), heff_tag_n(TAG_PLet, 3, (V[]){v_x_2418, v_t_2421, v_t_2422}));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(V v_o_240) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_241 = heff_field(v_o_240, 0);
    V v_ru_24o_240_24OSimple = heff_take_reuse_n(v_o_240, 1ULL, 1);
    V v_t_242 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_v_241));
    return heff_tag_at_n(v_ru_24o_240_24OSimple, TAG_OSimple, 1, (V[]){v_t_242});
  }
  case TAG_OCall: {
    V v_g_243 = heff_field(v_o_240, 0);
    V v_args_244 = heff_field(v_o_240, 1);
    V v_ru_24o_240_24OCall = heff_take_reuse_n(v_o_240, 3ULL, 2);
    V v_t_245 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), v_args_244));
    return heff_tag_re_n(v_ru_24o_240_24OCall, TAG_OCall, 2, 1ULL, (V[]){v_g_243, v_t_245});
  }
  case TAG_OApply: {
    V v_f_246 = heff_field(v_o_240, 0);
    V v_args_247 = heff_field(v_o_240, 1);
    V v_ru_24o_240_24OApply = heff_take_reuse_n(v_o_240, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_f_246));
    V v_t_249 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), v_args_247));
    return heff_tag_at_n(v_ru_24o_240_24OApply, TAG_OApply, 2, (V[]){v_t_248, v_t_249});
  }
  case TAG_OPrim: {
    V v_p_2410 = heff_field(v_o_240, 0);
    V v_args_2411 = heff_field(v_o_240, 1);
    V v_ru_24o_240_24OPrim = heff_take_reuse_n(v_o_240, 3ULL, 2);
    V v_t_2412 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), v_args_2411));
    return heff_tag_re_n(v_ru_24o_240_24OPrim, TAG_OPrim, 2, 1ULL, (V[]){v_p_2410, v_t_2412});
  }
  case TAG_OAbandon: {
    return v_o_240;
  }
  case TAG_OBool: {
    V v_c_2413 = heff_field(v_o_240, 0);
    V v_ru_24o_240_24OBool = heff_take_reuse_n(v_o_240, 1ULL, 1);
    V v_t_2414 = (g_heff_2ecompile_2eimperative_2eonceCond_24s850750852x1339472284(v_c_2413));
    return heff_tag_at_n(v_ru_24o_240_24OBool, TAG_OBool, 1, (V[]){v_t_2414});
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_TSeq: {
    V v_ss_241 = heff_field(v_x2_240, 0);
    V v_t_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24TSeq = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(v_ss_241, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_t_242)})));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24TSeq, TAG_TSeq, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_24dps(v_t_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  case TAG_TReturn: {
    V v_o_246 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24TReturn = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_247 = (g_heff_2ecompile_2eimperative_2eonceOp_24s1315731183x405745434(v_o_246));
    return heff_tag_at_n(v_ru_24x2_240_24TReturn, TAG_TReturn, 1, (V[]){v_t_247});
  }
  case TAG_TLoop: {
    V v_vs_248 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24TLoop = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_249 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), v_vs_248));
    return heff_tag_at_n(v_ru_24x2_240_24TLoop, TAG_TLoop, 1, (V[]){v_t_249});
  }
  case TAG_TIf: {
    V v_c_2410 = heff_field(v_x2_240, 0);
    V v_t_2411 = heff_field(v_x2_240, 1);
    V v_e_2412 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24TIf = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 2)), 1, (V[]){v_c_2410}));
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 4)), 1, (V[]){v_t_2411}));
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 4)), 1, (V[]){v_e_2412}));
    return heff_tag_at_n(v_ru_24x2_240_24TIf, TAG_TIf, 3, (V[]){v_t_2413, v_t_2414, v_t_2415});
  }
  case TAG_TCase: {
    V v_v_2416 = heff_field(v_x2_240, 0);
    V v_arms_2417 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24TCase = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2eonceK_get(), 0)), 1, (V[]){v_v_2416}));
    V v_t_2419 = (g_list_2emap_24s1155474388x1593011685(v_arms_2417));
    return heff_tag_at_n(v_ru_24x2_240_24TCase, TAG_TCase, 2, (V[]){v_t_2418, v_t_2419});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceTl_24s1495404283x91590768(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(V v_tok_240, V v_o_241) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_v_242 = heff_field(v_o_241, 0);
    heff_take_n(v_o_241, 1ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    return ({ V a_0 = v_v_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_242); r_; });
  }
  case TAG_OCall: {
    V v_args_244 = heff_field(v_o_241, 1);
    heff_take_n(v_o_241, 2ULL, 2);
    heff_drop_cell(v_tok_240, 2);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_244));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_245); r_; });
  }
  case TAG_OApply: {
    V v_f_246 = heff_field(v_o_241, 0);
    V v_args_247 = heff_field(v_o_241, 1);
    heff_take_n(v_o_241, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_f_246, v_args_247})));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_248); r_; });
  }
  case TAG_OPrim: {
    V v_args_2410 = heff_field(v_o_241, 1);
    heff_take_n(v_o_241, 2ULL, 2);
    heff_drop_cell(v_tok_240, 2);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2410));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2411); r_; });
  }
  case TAG_OAbandon: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    heff_take_n(v_o_241, 0ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V v_tok_240, V v_v_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SGlobal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SBytes: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SPrimFn: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_acc_242});
  }
  case TAG_SLam: {
    V v_v2_2414 = heff_dup(heff_field(v_v_241, 1));
    switch (heff_tag_of(v_v2_2414)) {
    case TAG_MkBlock: {
      V v_t_2415 = heff_field(v_v2_2414, 0);
      heff_take_n(v_v2_2414, 1ULL, 1);
      V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_acc_242; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_t_2416});
    }
    default: return heff_nomatch(v_v2_2414);
    }
  }
  case TAG_STag: {
    V v_args_2418 = heff_dup(heff_field(v_v_241, 1));
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2418));
    V v_t_2421 = ({ V a_0 = v_acc_242; V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2420); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_t_2421});
  }
  case TAG_SRec: {
    V v_fs_2422 = heff_dup(heff_field(v_v_241, 0));
    V v_t_2424 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2422));
    V v_t_2425 = ({ V a_0 = v_acc_242; V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2424); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_t_2425});
  }
  case TAG_SProj: {
    V v_w_2426 = heff_dup(heff_field(v_v_241, 0));
    V v_cell_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), heff_hole()});
    V v_u_2431 = ({ V a_0 = v_w_2426; V a_1 = v_acc_242; V a_2 = v_cell_2430; V r_ = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(a_0, a_1, a_2)); heff_drop(v_acc_242); r_; });
    heff_drop(v_u_2431);
    return v_cell_2430;
  }
  case TAG_SPrim: {
    V v_args_2433 = heff_dup(heff_field(v_v_241, 1));
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2433));
    V v_t_2435 = ({ V a_0 = v_acc_242; V a_1 = v_t_2434; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2434); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartVal, 1, (V[]){v_v_241}), v_t_2435});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eimperative_2epredLets_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredLets_24tok1_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epredLets_24tok1(V v_tok_240, V v_x1_241, V v_p_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eimperative_2epredLets_24cpr(v_x1_241, v_p_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eimperative_2epredLets_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eimperative_2epredLets_24tok1(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}