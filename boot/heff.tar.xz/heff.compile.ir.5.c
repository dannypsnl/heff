// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_m 327
#define LBL_n 328
#define LBL_xs 10594
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
V g_heff_2ecompile_2efuel_2enextOf(V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2enextOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2enextOf_clo;
V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029(V);
V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_clo;
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eallList(V, V);
V g_heff_2ecompile_2eir_2eallList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallList_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V, V);
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2econdExpr(V);
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdExpr_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24dps_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24dps_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ehasDefault(V);
V g_heff_2ecompile_2eir_2ehasDefault_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ehasDefault_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2enubI_24dps(V, V);
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_24dps_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886(V, V, V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_clo;
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1158390340x316106132_24cpr(V, V);
V g_prelude_2etraverse_24s1254646865x1442622806(V);
V g_prelude_2etraverse_24s1254646865x1442622806_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1254646865x1442622806_clo;
V g_prelude_2etraverse_24s130657301x1556233528(V);
V g_prelude_2etraverse_24s130657301x1556233528_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s130657301x1556233528_clo;
V g_prelude_2etraverse_24s1360711314x1560806682(V, V);
V g_prelude_2etraverse_24s1360711314x1560806682_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1360711314x1560806682_clo;
V g_prelude_2etraverse_24s1587080482x1917521257(V, V);
V g_prelude_2etraverse_24s1587080482x1917521257_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1587080482x1917521257_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);

HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_a_242, 0);
      v_t_247 = heff_dup(v_t_244);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_t_240, 1)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_a_242)}});
    } else {
      V v_t_2411;
      switch (heff_tag_of(v_a_242)) {
      case TAG_MkArm: {
        V v_t_248 = heff_field(v_a_242, 0);
        v_t_2411 = heff_bool(heff_strEq_c(heff_dup(v_t_248), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
        break;
      }
      default: heff_nomatch(v_a_242);
      }
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_a_242)}});
      } else {
        heff_drop(v_t_2411);
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eir_2eappendI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_entry, 2, 0};

V g_heff_2ecompile_2eir_2eappendI(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = ({ V a_0 = v_xs_243; V a_1 = v_ys_241; V a_2 = v_cell_244; V r_ = (g_heff_2ecompile_2eir_2eappendI_24dps(a_0, a_1, a_2)); heff_drop(v_ys_241); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2enubI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_entry, 1, 0};

V g_heff_2ecompile_2eir_2enubI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s930188071x496633547(v_x_241, v_xs_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eir_2enubI_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2enubI(a[0]);
}
Clo g_heff_2ecompile_2eir_2epushFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushFields(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_e2_245 = heff_field(v_p_242, 1);
      heff_take_n(v_p_242, 2ULL, 2);
      v_t_246 = v_e2_245;
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = ({ V a_0 = v_fs_243; V a_1 = v_rest_241; V a_2 = v_cell_247; V r_ = (g_heff_2ecompile_2eir_2epushFields_24dps(a_0, a_1, a_2)); heff_drop(v_rest_241); r_; });
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epartsOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epartsOnto_entry, 2, 0};

V g_heff_2ecompile_2eir_2epartsOnto(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){v_b_245, v_rest_241});
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x1_240, 0);
    V v_args_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2eir_2eappendI(v_args_247, v_rest_241));
    return heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_t_248});
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_a_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, v_rest_241})});
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x1_240_24ERecord, v_fs_2412, v_rest_241));
  }
  case TAG_EProj: {
    V v_e_2414 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 4);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2414, v_rest_241});
  }
  case TAG_ETag: {
    V v_args_2419 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    HEFF_LAST return g_heff_2ecompile_2eir_2eappendI(v_args_2419, v_rest_241);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_x1_240, 0);
    V v_arms_2422 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2423 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2422, v_rest_241));
    return heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2421, v_t_2423});
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EPrimCall: {
    V v_args_2426 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EPrimCall, v_args_2426, v_rest_241));
  }
  case TAG_ECall: {
    V v_args_2428 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24ECall, v_args_2428, v_rest_241));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_rest_241;
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EAbandon: {
    return v_rest_241;
  }
  case TAG_EBool: {
    V v_c_2436 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ({ V a_0 = v_c_2436; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2436); r_; });
  }
  case TAG_ESet: {
    V v_a_2438 = heff_field(v_x1_240, 1);
    V v_b_2439 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_a_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2439, v_rest_241})});
  }
  case TAG_EValues: {
    V v_es_2440 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eir_2eappendI(v_es_2440, v_rest_241);
  }
  case TAG_EFix: {
    V v_b_2442 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_Cons, 2, (V[]){v_b_2442, v_rest_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epartsOnto(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2eallList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallList_entry, 2, 0};

V g_heff_2ecompile_2eir_2eallList(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_es_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), heff_dup(v_e_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_f_240;
      V t_1 = v_es_243;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2eallList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eir_2eallList(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_fs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkPair: {
      V v_e_244 = heff_field(v_x21_241, 1);
      V v_a_245 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_e_244)));
      if (!(heff_dup(v_a_245) == NTAG(TAG_True))) {
        heff_drop(v_a_245);
        V t_0 = v_fs_242;
        v_x2_240 = t_0;
        goto top;
      } else {
        heff_drop(v_a_245);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_CTrue: {
    return ((HeffT2){{NTAG(TAG_CTrue), v_n_241}});
  }
  case TAG_CFalse: {
    return ((HeffT2){{NTAG(TAG_CFalse), v_n_241}});
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x4_242, 0);
    V v_x_244 = heff_field(v_x4_242, 1);
    V v_y_245 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24CRel = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_246 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_x_244));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_27_249 = v_field_247;
      V v_n1_2410 = v_field_248;
      HeffT2 v_t_2411 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n1_2410, v_y_245));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_y_27_2414 = v_field_2412;
        V v_n2_2415 = v_field_2413;
        return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24CRel, TAG_CRel, 3, 1ULL, (V[]){v_p_243, v_x_27_249, v_y_27_2414}), v_n2_2415}});
      }
    }
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CTest = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2417 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_x_2416));
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      V v_x_27_2420 = v_field_2418;
      V v_n1_2421 = v_field_2419;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CTest, TAG_CTest, 1, (V[]){v_x_27_2420}), v_n1_2421}});
    }
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CNot = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_cell_2423 = heff_tag_at_n(v_ru_24x4_242_24CNot, TAG_CNot, 1, (V[]){heff_hole()});
    HeffT2 v_t_2424 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24dps_24cpr(v_m_240, v_n_241, v_c_2422, v_cell_2423, MK_INT(0LL)));
    {
      V v_field_2425 = v_t_2424.f[0];
      V v_field_2426 = v_t_2424.f[1];
      V v__5f_2427 = v_field_2425;
      heff_drop(v__5f_2427);
      V v_n_2428 = v_field_2426;
      return ((HeffT2){{v_cell_2423, v_n_2428}});
    }
  }
  case TAG_CIf: {
    V v_a_2429 = heff_field(v_x4_242, 0);
    V v_b_2430 = heff_field(v_x4_242, 1);
    V v_c_2431 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24CIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2432 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(v_m_240, v_n_241, v_a_2429));
    {
      V v_field_2433 = v_t_2432.f[0];
      V v_field_2434 = v_t_2432.f[1];
      V v_c_2435 = v_field_2433;
      V v_n_2436 = v_field_2434;
      HeffT2 v_t_2437 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(v_m_240, v_n_2436, v_b_2430));
      {
        V v_field_2438 = v_t_2437.f[0];
        V v_field_2439 = v_t_2437.f[1];
        V v_c_2440 = v_field_2438;
        V v_n_2441 = v_field_2439;
        V v_cell_2442 = heff_tag_at_n(v_ru_24x4_242_24CIf, TAG_CIf, 3, (V[]){v_c_2435, v_c_2440, heff_hole()});
        HeffT2 v_t_2443 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24dps_24cpr(v_m_240, v_n_2441, v_c_2431, v_cell_2442, MK_INT(2LL)));
        {
          V v_field_2444 = v_t_2443.f[0];
          V v_field_2445 = v_t_2443.f[1];
          V v__5f_2446 = v_field_2444;
          heff_drop(v__5f_2446);
          V v_n_2447 = v_field_2445;
          return ((HeffT2){{v_cell_2442, v_n_2447}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24dps_24cpr_str0, 1, "$");

HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24dps_24cpr(V v_m_240, V v_n_241, V v_e_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_245 = ({ V a_0 = v_m_240; V a_1 = v_x_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_240); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_249;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_244);
        V v_y_248 = v_field_247;
        v_t_249 = v_y_248;
      } else {
        heff_drop(v_field_247);
        v_t_249 = v_x_244;
      }
      V v_u_2410 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EVar, 1, (V[]){v_t_249}));
      V v_f_2411 = heff_hole();
      return ((HeffT2){{v_f_2411, v_n_241}});
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    V v_u_2413 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_2414 = heff_hole();
    return ((HeffT2){{v_f_2414, v_n_241}});
  }
  case TAG_ELam: {
    V v_xs_2415 = heff_field(v_e_242, 0);
    V v_b_2416 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2417 = heff_rec_n(3, shape_m__n__xs, (V[]){v_m_240, v_n_241, NTAG(TAG_Nil)});
    V v_v_2418 = (g_list_2efoldl_24s690313412x1307839513(v_t_2417, v_xs_2415));
    V v_m_2419 = heff_take_field(v_v_2418, 0);
    V v_n_2420 = heff_take_field(v_v_2418, 1);
    V v_xs_2421 = heff_get_n(v_v_2418, 2, 3);
    HeffT2 v_t_2422 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2419, v_n_2420, v_b_2416));
    {
      V v_field_2423 = v_t_2422.f[0];
      V v_field_2424 = v_t_2422.f[1];
      V v_b_27_2425 = v_field_2423;
      V v_n_27_2426 = v_field_2424;
      V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
      V v_u_2428 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2427, v_b_27_2425}));
      V v_f_2429 = heff_hole();
      return ((HeffT2){{v_f_2429, v_n_27_2426}});
    }
  }
  case TAG_EApp: {
    V v_f_2430 = heff_field(v_e_242, 0);
    V v_args_2431 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2432 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_f_2430));
    {
      V v_field_2433 = v_t_2432.f[0];
      V v_field_2434 = v_t_2432.f[1];
      V v_f_27_2435 = v_field_2433;
      V v_n1_2436 = v_field_2434;
      HeffT2 v_t_2437 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n1_2436, v_args_2431));
      {
        V v_field_2438 = v_t_2437.f[0];
        V v_field_2439 = v_t_2437.f[1];
        V v_args_27_2440 = v_field_2438;
        V v_n2_2441 = v_field_2439;
        V v_u_2442 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_2435, v_args_27_2440}));
        V v_f_2443 = heff_hole();
        return ((HeffT2){{v_f_2443, v_n2_2441}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2444 = heff_field(v_e_242, 0);
    V v_a_2445 = heff_field(v_e_242, 1);
    V v_b_2446 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2447 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_a_2445));
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      V v_a_27_2450 = v_field_2448;
      V v_n1_2451 = v_field_2449;
      V v_base_2452 = (g_heff_2ecompile_2eir_2ebaseGo(v_x_2444, MK_INT(0LL)));
      V v_x_27_2453 = heff_strAppend(heff_strAppend(v_base_2452, ((V)&g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24dps_24cpr_str0)), heff_intShow(heff_dup(v_n1_2451)));
      V v_m_2454 = ({ V a_0 = v_m_240; V a_1 = v_x_2444; V a_2 = v_x_27_2453; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_x_2444); r_; });
      V v_cell_2455 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_27_2453, v_a_27_2450, heff_hole()});
      V v_u_2456 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_cell_2455);
      V t_0 = v_m_2454;
      V t_1 = heff_intAdd(v_n1_2451, MK_INT(1LL));
      V t_2 = v_b_2446;
      V t_3 = v_u_2456;
      v_m_240 = t_0;
      v_n_241 = t_1;
      v_e_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  case TAG_ERecord: {
    V v_fs_2457 = heff_field(v_e_242, 0);
    V v_ts_2458 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2459 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(v_m_240, v_n_241, v_fs_2457));
    {
      V v_field_2460 = v_t_2459.f[0];
      V v_field_2461 = v_t_2459.f[1];
      V v_fs_27_2462 = v_field_2460;
      V v_n1_2463 = v_field_2461;
      V v_u_2464 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_27_2462, v_ts_2458}));
      V v_f_2465 = heff_hole();
      return ((HeffT2){{v_f_2465, v_n1_2463}});
    }
  }
  case TAG_EProj: {
    V v_e2_2466 = heff_field(v_e_242, 0);
    V v_l_2467 = heff_field(v_e_242, 1);
    V v_sh_2468 = heff_field(v_e_242, 2);
    V v_t_2469 = heff_field(v_e_242, 3);
    heff_take_n(v_e_242, 15ULL, 4);
    HeffT2 v_t_2470 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_e2_2466));
    {
      V v_field_2471 = v_t_2470.f[0];
      V v_field_2472 = v_t_2470.f[1];
      V v_e_27_2473 = v_field_2471;
      V v_n1_2474 = v_field_2472;
      V v_u_2475 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EProj, 4, (V[]){v_e_27_2473, v_l_2467, v_sh_2468, v_t_2469}));
      V v_f_2476 = heff_hole();
      return ((HeffT2){{v_f_2476, v_n1_2474}});
    }
  }
  case TAG_ETag: {
    V v_t_2477 = heff_field(v_e_242, 0);
    V v_args_2478 = heff_field(v_e_242, 1);
    V v_ts_2479 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2480 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2478));
    {
      V v_field_2481 = v_t_2480.f[0];
      V v_field_2482 = v_t_2480.f[1];
      V v_args_27_2483 = v_field_2481;
      V v_n1_2484 = v_field_2482;
      V v_u_2485 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ETag, 3, (V[]){v_t_2477, v_args_27_2483, v_ts_2479}));
      V v_f_2486 = heff_hole();
      return ((HeffT2){{v_f_2486, v_n1_2484}});
    }
  }
  case TAG_EMatch: {
    V v_s_2487 = heff_field(v_e_242, 0);
    V v_arms_2488 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2489 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_s_2487));
    {
      V v_field_2490 = v_t_2489.f[0];
      V v_field_2491 = v_t_2489.f[1];
      V v_s_27_2492 = v_field_2490;
      V v_n1_2493 = v_field_2491;
      HeffT2 v_t_2494 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(v_m_240, v_n1_2493, v_arms_2488));
      {
        V v_field_2495 = v_t_2494.f[0];
        V v_field_2496 = v_t_2494.f[1];
        V v_arms_27_2497 = v_field_2495;
        V v_n2_2498 = v_field_2496;
        V v_u_2499 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_2492, v_arms_27_2497}));
        V v_f_24100 = heff_hole();
        return ((HeffT2){{v_f_24100, v_n2_2498}});
      }
    }
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    V v_u_24102 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24103 = heff_hole();
    return ((HeffT2){{v_f_24103, v_n_241}});
  }
  case TAG_EPrimCall: {
    V v_p_24104 = heff_field(v_e_242, 0);
    V v_args_24105 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_24106 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_24105));
    {
      V v_field_24107 = v_t_24106.f[0];
      V v_field_24108 = v_t_24106.f[1];
      V v_args_27_24109 = v_field_24107;
      V v_n1_24110 = v_field_24108;
      V v_u_24111 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_24104, v_args_27_24109}));
      V v_f_24112 = heff_hole();
      return ((HeffT2){{v_f_24112, v_n1_24110}});
    }
  }
  case TAG_ECall: {
    V v_g_24113 = heff_field(v_e_242, 0);
    V v_args_24114 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_24115 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_24114));
    {
      V v_field_24116 = v_t_24115.f[0];
      V v_field_24117 = v_t_24115.f[1];
      V v_args_27_24118 = v_field_24116;
      V v_n1_24119 = v_field_24117;
      V v_u_24120 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ECall, 2, (V[]){v_g_24113, v_args_27_24118}));
      V v_f_24121 = heff_hole();
      return ((HeffT2){{v_f_24121, v_n1_24119}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    V v_u_24123 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24124 = heff_hole();
    return ((HeffT2){{v_f_24124, v_n_241}});
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    V v_u_24126 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24127 = heff_hole();
    return ((HeffT2){{v_f_24127, v_n_241}});
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    V v_u_24129 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24130 = heff_hole();
    return ((HeffT2){{v_f_24130, v_n_241}});
  }
  case TAG_EBytes: {
    heff_drop(v_m_240);
    V v_u_24132 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24133 = heff_hole();
    return ((HeffT2){{v_f_24133, v_n_241}});
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    V v_u_24136 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24137 = heff_hole();
    return ((HeffT2){{v_f_24137, v_n_241}});
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    V v_u_24139 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24140 = heff_hole();
    return ((HeffT2){{v_f_24140, v_n_241}});
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    V v_u_24141 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24142 = heff_hole();
    return ((HeffT2){{v_f_24142, v_n_241}});
  }
  case TAG_EBool: {
    V v_c_24143 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_24144 = ({ V a_0 = v_m_240; V a_1 = v_n_241; V a_2 = v_c_24143; HeffT2 r_ = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(a_0, a_1, a_2)); heff_drop(v_m_240); r_; });
    {
      V v_field_24145 = v_t_24144.f[0];
      V v_field_24146 = v_t_24144.f[1];
      V v_c_27_24147 = v_field_24145;
      V v_n1_24148 = v_field_24146;
      V v_u_24149 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EBool, 1, (V[]){v_c_27_24147}));
      V v_f_24150 = heff_hole();
      return ((HeffT2){{v_f_24150, v_n1_24148}});
    }
  }
  case TAG_ESet: {
    V v_xs_24151 = heff_field(v_e_242, 0);
    V v_a_24152 = heff_field(v_e_242, 1);
    V v_b_24153 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_24154 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_a_24152));
    {
      V v_field_24155 = v_t_24154.f[0];
      V v_field_24156 = v_t_24154.f[1];
      V v_a_27_24157 = v_field_24155;
      V v_n1_24158 = v_field_24156;
      V v_t_24159 = heff_rec_n(3, shape_m__n__xs, (V[]){v_m_240, v_n1_24158, NTAG(TAG_Nil)});
      V v_v_24160 = (g_list_2efoldl_24s690313412x1307839513(v_t_24159, v_xs_24151));
      V v_m_24161 = heff_take_field(v_v_24160, 0);
      V v_n_24162 = heff_take_field(v_v_24160, 1);
      V v_xs_24163 = heff_get_n(v_v_24160, 2, 3);
      HeffT2 v_t_24164 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_24161, v_n_24162, v_b_24153));
      {
        V v_field_24165 = v_t_24164.f[0];
        V v_field_24166 = v_t_24164.f[1];
        V v_b_27_24167 = v_field_24165;
        V v_n2_24168 = v_field_24166;
        V v_t_24169 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24163));
        V v_u_24170 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_ESet, 3, (V[]){v_t_24169, v_a_27_24157, v_b_27_24167}));
        V v_f_24171 = heff_hole();
        return ((HeffT2){{v_f_24171, v_n2_24168}});
      }
    }
  }
  case TAG_EValues: {
    V v_es_24172 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_24173 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_es_24172));
    {
      V v_field_24174 = v_t_24173.f[0];
      V v_field_24175 = v_t_24173.f[1];
      V v_es_27_24176 = v_field_24174;
      V v_n1_24177 = v_field_24175;
      V v_u_24178 = heff_setFieldPeek(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EValues, 1, (V[]){v_es_27_24176}));
      V v_f_24179 = heff_hole();
      return ((HeffT2){{v_f_24179, v_n1_24177}});
    }
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    V v_u_24182 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_e_242);
    V v_f_24183 = heff_hole();
    return ((HeffT2){{v_f_24183, v_n_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2eisValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eisValue_entry, 1, 0};

V g_heff_2ecompile_2eir_2eisValue(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    V v_t_2412 = (g_list_2emap_24s1044393341x1523302351(heff_dup(v_fs_2410)));
    return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x1_240, 1);
    V v_t_2420 = (g_list_2emap_24s584454411x1006678865(heff_dup(v_args_2418)));
    return ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_2435 = heff_field(v_x1_240, 0);
    V v_t_2436 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2435, NTAG(TAG_Nil)));
    V v_t_2437 = (g_list_2emap_24s584454411x1006678865(v_t_2436));
    return ({ V a_0 = v_t_2437; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2437); r_; });
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eisValue(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str2, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str3, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str7, 5, "False");
Clo g_heff_2ecompile_2eir_2econdExpr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdExpr_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdExpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str0), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_CFalse: {
    return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str1), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_CRel: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_a_242 = heff_field(v_x1_240, 1);
    V v_b_243 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_241, heff_tag_n(TAG_Cons, 2, (V[]){v_a_242, v_t_244})});
  }
  case TAG_CTest: {
    V v_e_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_e_245;
  }
  case TAG_CNot: {
    V v_c_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_247 = (g_heff_2ecompile_2eir_2econdExpr(v_c_246));
    V v_t_248 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str2), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str3), NTAG(TAG_Nil), v_t_248});
    V v_t_2410 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str4), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str5), NTAG(TAG_Nil), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412})});
  }
  case TAG_CIf: {
    V v_a_2413 = heff_field(v_x1_240, 0);
    V v_b_2414 = heff_field(v_x1_240, 1);
    V v_c_2415 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2416 = (g_heff_2ecompile_2eir_2econdExpr(v_a_2413));
    V v_t_2417 = (g_heff_2ecompile_2eir_2econdExpr(v_b_2414));
    V v_f_2418 = (g_heff_2ecompile_2eir_2econdExpr(v_c_2415));
    V v_t_2419 = heff_tag_at_n(v_ru_24x1_240_24CIf, TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str6), NTAG(TAG_Nil), v_t_2417});
    V v_t_2420 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str7), NTAG(TAG_Nil), v_f_2418});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2421})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdExpr(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_246 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_244));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam2, 1, 3, (V[]){v_m_246, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2415 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2416 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam3, 1, 1, (V[]){v_m_2416});
  }
  case TAG_CNot: {
    V v_c_2421 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2422 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_c_2421));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam4, 1, 1, (V[]){v_m_2422});
  }
  case TAG_CIf: {
    V v_a_2427 = heff_field(v_x2_27_240, 0);
    V v_b_2428 = heff_field(v_x2_27_240, 1);
    V v_c_2429 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2430 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_a_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam5, 1, 3, (V[]){v_m_2430, v_b_2428, v_c_2429});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_y_245));
    V v_x2_2412 = heff_tr(heff_call(v_t_2411, 1, (V[]){v_s_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_249, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2419}), v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2425}), v_s_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_b_2428 = heff_env(self)[1];
  V v_c_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_b_2428));
    V v_x2_2436 = heff_tr(heff_call(v_t_2435, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_s_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_t_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_c_2429));
      V v_x2_2440 = heff_tr(heff_call(v_t_2439, 1, (V[]){v_s_2438}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_s_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2433, v_x_2437, v_x_2441}), v_s_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam22(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam23(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam24(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_entry, 5, 0};

V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam0, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam1, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_ELam: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam2, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EApp: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam3, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_e_244, 0);
    V v_a_2416 = heff_field(v_e_244, 1);
    V v_b_2417 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    V v_m_2418 = (g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_b_2417));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam4, 1, 3, (V[]){v_m_2418, v_x_2415, v_a_2416});
  }
  case TAG_ERecord: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam5, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EProj: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam6, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_ETag: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam7, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EMatch: {
    V v_s_2435 = heff_field(v_e_244, 0);
    V v_arms_2436 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    V v_m_2446 = (g_prelude_2etraverse_24s1587080482x1917521257(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam8, 1, 4, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243)}), v_arms_2436));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam10, 1, 2, (V[]){v_m_2446, v_s_2435});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam11, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EPrimCall: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam12, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_ECall: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam13, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam14, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam15, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam16, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam17, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam18, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam19, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam20, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EBool: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam21, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_ESet: {
    V v_xs_2475 = heff_field(v_e_244, 0);
    V v_a_2476 = heff_field(v_e_244, 1);
    V v_b_2477 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    V v_m_2478 = (g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_b_2477));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam22, 1, 3, (V[]){v_m_2478, v_xs_2475, v_a_2476});
  }
  case TAG_EValues: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam23, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  case TAG_EFix: {
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam24, 1, 5, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_e_244});
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886(a0, a1, a2, a3, a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_246; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_248; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam2(V self, V *args) {
  V v_a_2411 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2411; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam3(V self, V *args) {
  V v_a_2414 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2414; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam4(V self, V *args) {
  V v_n_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_a_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2419}));
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_n_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2415, v_a_2416, v_x_2421}), v_n_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam5(V self, V *args) {
  V v_a_2425 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2425; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam6(V self, V *args) {
  V v_a_2430 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2430; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam7(V self, V *args) {
  V v_a_2434 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2434; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam9(V self, V *args) {
  V v_n_2442 = args[0];
  V v_m_2441 = heff_env(self)[0];
  V v_t_2438 = heff_env(self)[1];
  V v_vs_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2443 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_n_2442}));
  switch (heff_tag_of(v_x2_2443)) {
  case TAG_MkPair: {
    V v_x_2444 = heff_field(v_x2_2443, 0);
    V v_n_2445 = heff_field(v_x2_2443, 1);
    V v_ru_24x2_2443_24MkPair = heff_take_reuse_n(v_x2_2443, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2443_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2438, v_vs_2439, v_x_2444}), v_n_2445});
  }
  default: return heff_nomatch(v_x2_2443);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam8(V self, V *args) {
  V v_x2_2437 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkArm: {
    V v_t_2438 = heff_field(v_x2_2437, 0);
    V v_vs_2439 = heff_field(v_x2_2437, 1);
    V v_b_2440 = heff_field(v_x2_2437, 2);
    heff_take_n(v_x2_2437, 7ULL, 3);
    heff_clo_take(self, 4);
    V v_m_2441 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_b_2440; V r_ = (g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); heff_drop(v_lit_243); r_; });
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam9, 1, 3, (V[]){v_m_2441, v_t_2438, v_vs_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam10(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_s_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2435, v_x_2449}), v_n_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam11(V self, V *args) {
  V v_a_2452 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2452; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam12(V self, V *args) {
  V v_a_2455 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2455; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam13(V self, V *args) {
  V v_a_2458 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2458; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam14(V self, V *args) {
  V v_a_2460 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2460; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam15(V self, V *args) {
  V v_a_2462 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2462; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam16(V self, V *args) {
  V v_a_2464 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2464; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam17(V self, V *args) {
  V v_a_2466 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2466; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam18(V self, V *args) {
  V v_a_2469 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2469; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam19(V self, V *args) {
  V v_a_2471 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2471; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam20(V self, V *args) {
  V v_a_2472 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2472; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam21(V self, V *args) {
  V v_a_2474 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2474; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam22(V self, V *args) {
  V v_n_2479 = args[0];
  V v_m_2478 = heff_env(self)[0];
  V v_xs_2475 = heff_env(self)[1];
  V v_a_2476 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2480 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_n_2479}));
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_MkPair: {
    V v_x_2481 = heff_field(v_x2_2480, 0);
    V v_n_2482 = heff_field(v_x2_2480, 1);
    V v_ru_24x2_2480_24MkPair = heff_take_reuse_n(v_x2_2480, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2480_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2475, v_a_2476, v_x_2481}), v_n_2482});
  }
  default: return heff_nomatch(v_x2_2480);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam23(V self, V *args) {
  V v_a_2484 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2484; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2ewaysM_24s2031237956x217920886_lam24(V self, V *args) {
  V v_a_2487 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_e_244; V a_5 = v_a_2487; V r_ = (g_heff_2ecompile_2efuel_2enextOf(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); r_; });
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam22(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam23(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam24(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam25(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam26(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_entry, 2, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_246), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_g_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2415 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_2413}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam3, 1, 3, (V[]){v_m_2415, v_f_240, v_args_2414});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x2_241, 0);
    V v_a_2426 = heff_field(v_x2_241, 1);
    V v_b_2427 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2428 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2426}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam4, 1, 4, (V[]){v_m_2428, v_x_2425, v_f_240, v_b_2427});
  }
  case TAG_ERecord: {
    V v_fs_2438 = heff_field(v_x2_241, 0);
    V v_ts_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2448 = (g_prelude_2etraverse_24s1360711314x1560806682(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam5, 1, 1, (V[]){v_f_240}), v_fs_2438));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam7, 1, 2, (V[]){v_m_2448, v_ts_2439});
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x2_241, 0);
    V v_l_2454 = heff_field(v_x2_241, 1);
    V v_sh_2455 = heff_field(v_x2_241, 2);
    V v_t_2456 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2457 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2453}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam8, 1, 4, (V[]){v_m_2457, v_l_2454, v_sh_2455, v_t_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_x2_241, 0);
    V v_args_2463 = heff_field(v_x2_241, 1);
    V v_ts_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2465 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2466 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_2465, v_args_2463));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam9, 1, 3, (V[]){v_m_2466, v_t_2462, v_ts_2464});
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_x2_241, 0);
    V v_arms_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2473 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2471}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam10, 1, 3, (V[]){v_m_2473, v_f_240, v_arms_2472});
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam13, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2493 = heff_field(v_x2_241, 0);
    V v_args_2494 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2496 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_2495, v_args_2494));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam14, 1, 2, (V[]){v_m_2496, v_p_2493});
  }
  case TAG_ECall: {
    V v_g_24101 = heff_field(v_x2_241, 0);
    V v_args_24102 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24103 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24104 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_24103, v_args_24102));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam15, 1, 2, (V[]){v_m_24104, v_g_24101});
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam22, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBool: {
    V v_c_24123 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24124 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24125 = ({ V a_0 = v_t_24124; V a_1 = v_c_24123; V r_ = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(a_0, a_1)); heff_drop(v_t_24124); r_; });
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam23, 1, 1, (V[]){v_m_24125});
  }
  case TAG_ESet: {
    V v_xs_24130 = heff_field(v_x2_241, 0);
    V v_a_24131 = heff_field(v_x2_241, 1);
    V v_b_24132 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24133 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_24131}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam24, 1, 4, (V[]){v_m_24133, v_f_240, v_xs_24130, v_b_24132});
  }
  case TAG_EValues: {
    V v_es_24142 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24143 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24144 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_24143, v_es_24142));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam25, 1, 1, (V[]){v_m_24144});
  }
  case TAG_EFix: {
    V v_x_24149 = heff_field(v_x2_241, 0);
    V v_b_24150 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24151 = heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_x_24149), NTAG(TAG_Nil)});
    V v_m_24152 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_24151, v_b_24150}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam26, 1, 2, (V[]){v_m_24152, v_x_24149});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_243});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_245});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam3(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_args_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2421 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_2420, v_args_2414));
    V v_x2_2422 = heff_tr(heff_call(v_t_2421, 1, (V[]){v_s_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_s_2424 = heff_field(v_x2_2422, 1);
      V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_EApp, 2, (V[]){v_x_2418, v_x_2423}), v_s_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_b_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_Nil)});
    V v_m_2434 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2433, v_b_2427}));
    V v_x2_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_s_2432}));
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_s_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2425, v_x_2431, v_x_2436}), v_s_2437});
    }
    default: return heff_nomatch(v_x2_2435);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam6(V self, V *args) {
  V v_s_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_s_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2441, v_x_2446}), v_s_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam5(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_l_2441 = heff_field(v_x2_2440, 0);
    V v_e_2442 = heff_field(v_x2_2440, 1);
    heff_take_n(v_x2_2440, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_m_2443 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2442}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam6, 1, 2, (V[]){v_m_2443, v_l_2441});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam7(V self, V *args) {
  V v_s_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_ts_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_s_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2451, v_ts_2439}), v_s_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam8(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2454 = heff_env(self)[1];
  V v_sh_2455 = heff_env(self)[2];
  V v_t_2456 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2460, v_l_2454, v_sh_2455, v_t_2456}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam9(V self, V *args) {
  V v_s_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  V v_ts_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_s_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_s_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2462, v_x_2469, v_ts_2464}), v_s_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam12(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_t_2479 = heff_env(self)[1];
  V v_vs_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2479, v_vs_2480, v_x_2485}), v_s_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam11(V self, V *args) {
  V v_x2_2478 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkArm: {
    V v_t_2479 = heff_field(v_x2_2478, 0);
    V v_vs_2480 = heff_field(v_x2_2478, 1);
    V v_b_2481 = heff_field(v_x2_2478, 2);
    heff_take_n(v_x2_2478, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_m_2482 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_vs_2480), v_b_2481}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam12, 1, 3, (V[]){v_m_2482, v_t_2479, v_vs_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam10(V self, V *args) {
  V v_s_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_arms_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_s_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_s_2477 = heff_field(v_x2_2475, 1);
    V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
    V v_t_2487 = (g_prelude_2etraverse_24s1360711314x1560806682(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam11, 1, 1, (V[]){v_f_240}), v_arms_2472));
    V v_x2_2488 = heff_tr(heff_call(v_t_2487, 1, (V[]){v_s_2477}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_s_2490 = heff_field(v_x2_2488, 1);
      V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_EMatch, 2, (V[]){v_x_2476, v_x_2489}), v_s_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam13(V self, V *args) {
  V v_s_2492 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_2492});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam14(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_p_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2493, v_x_2499}), v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam15(V self, V *args) {
  V v_s_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  V v_g_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_s_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_s_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24101, v_x_24107}), v_s_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam16(V self, V *args) {
  V v_s_24110 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24110});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam17(V self, V *args) {
  V v_s_24112 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24112});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam18(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24114});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam19(V self, V *args) {
  V v_s_24116 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24116});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam20(V self, V *args) {
  V v_s_24119 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24119});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam21(V self, V *args) {
  V v_s_24121 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24121});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam22(V self, V *args) {
  V v_s_24122 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24122});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam23(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24128}), v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam24(V self, V *args) {
  V v_s_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_24130 = heff_env(self)[2];
  V v_b_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_s_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_s_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_m_24138 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_24130), v_b_24132}));
    V v_x2_24139 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_s_24137}));
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_s_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24130, v_x_24136, v_x_24140}), v_s_24141});
    }
    default: return heff_nomatch(v_x2_24139);
    }
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam25(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24147}), v_s_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam26(V self, V *args) {
  V v_s_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_x_24149 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_s_24153}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_MkPair: {
    V v_x_24155 = heff_field(v_x2_24154, 0);
    V v_s_24156 = heff_field(v_x2_24154, 1);
    V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24149, v_x_24155}), v_s_24156});
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam2, 1, 4, (V[]){v_m_247, heff_dup(v_f_240), v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(v_f_240, v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam5, 1, 4, (V[]){v_m_2431, heff_dup(v_f_240), v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_t_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(v_f_240, v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_t_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_t_2440 = ({ V a_0 = v_f_240; V a_1 = v_c_2430; V r_ = (g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(a_0, a_1)); heff_drop(v_f_240); r_; });
      V v_x2_2441 = heff_tr(heff_call(v_t_2440, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_s_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_s_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam22(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry, 1, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_240, 0);
    V v_b_246 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_g_2415 = heff_field(v_x2_240, 0);
    V v_args_2416 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2417 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_g_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam3, 1, 2, (V[]){v_m_2417, v_args_2416});
  }
  case TAG_ELet: {
    V v_x_2429 = heff_field(v_x2_240, 0);
    V v_a_2430 = heff_field(v_x2_240, 1);
    V v_b_2431 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2432 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_a_2430));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam4, 1, 3, (V[]){v_m_2432, v_b_2431, v_x_2429});
  }
  case TAG_ERecord: {
    V v_fs_2447 = heff_field(v_x2_240, 0);
    V v_ts_2448 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2449 = (g_prelude_2etraverse_24s1254646865x1442622806(v_fs_2447));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam5, 1, 2, (V[]){v_m_2449, v_ts_2448});
  }
  case TAG_EProj: {
    V v_e_2454 = heff_field(v_x2_240, 0);
    V v_l_2455 = heff_field(v_x2_240, 1);
    V v_sh_2456 = heff_field(v_x2_240, 2);
    V v_t_2457 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_m_2458 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_e_2454));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam6, 1, 4, (V[]){v_m_2458, v_l_2455, v_sh_2456, v_t_2457});
  }
  case TAG_ETag: {
    V v_t_2466 = heff_field(v_x2_240, 0);
    V v_args_2467 = heff_field(v_x2_240, 1);
    V v_ts_2468 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2469 = (g_prelude_2etraverse_24s130657301x1556233528(v_args_2467));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam7, 1, 3, (V[]){v_m_2469, v_t_2466, v_ts_2468});
  }
  case TAG_EMatch: {
    V v_s_2474 = heff_field(v_x2_240, 0);
    V v_arms_2475 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2476 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_s_2474));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam8, 1, 2, (V[]){v_m_2476, v_arms_2475});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EPrimCall: {
    V v_p_2491 = heff_field(v_x2_240, 0);
    V v_args_2492 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2493 = (g_prelude_2etraverse_24s130657301x1556233528(v_args_2492));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam10, 1, 2, (V[]){v_m_2493, v_p_2491});
  }
  case TAG_ECall: {
    V v_g_2498 = heff_field(v_x2_240, 0);
    V v_args_2499 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24100 = (g_prelude_2etraverse_24s130657301x1556233528(v_args_2499));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam11, 1, 2, (V[]){v_m_24100, v_g_2498});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam12, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBool: {
    V v_c_24119 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24120 = (g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(v_c_24119));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam19, 1, 1, (V[]){v_m_24120});
  }
  case TAG_ESet: {
    V v_xs_24125 = heff_field(v_x2_240, 0);
    V v_a_24126 = heff_field(v_x2_240, 1);
    V v_b_24127 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_24128 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_a_24126));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam20, 1, 3, (V[]){v_m_24128, v_b_24127, v_xs_24125});
  }
  case TAG_EValues: {
    V v_es_24143 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24144 = (g_prelude_2etraverse_24s130657301x1556233528(v_es_24143));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam21, 1, 1, (V[]){v_m_24144});
  }
  case TAG_EFix: {
    V v_x_24149 = heff_field(v_x2_240, 0);
    V v_b_24150 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24151 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_b_24150));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam22, 1, 2, (V[]){v_m_24151, v_x_24149});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(a[0]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_242});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_244});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  V v_x2_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    v_x2_2412 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_249_24MkPair, v_x_2410, v_n_2411));
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2413}), v_n_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_args_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  V v_x2_2422;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    v_x2_2422 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2419_24MkPair, v_x_2420, v_n_2421));
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_n_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    V v_t_2425 = (g_prelude_2etraverse_24s130657301x1556233528(v_args_2416));
    V v_x2_2426 = heff_tr(heff_call(v_t_2425, 1, (V[]){v_n_2424}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_n_2428 = heff_field(v_x2_2426, 1);
      V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_EApp, 2, (V[]){v_x_2423, v_x_2427}), v_n_2428});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam4(V self, V *args) {
  V v_n_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_b_2431 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2433}));
  V v_x2_2437;
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_n_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    v_x2_2437 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2434_24MkPair, v_x_2435, v_n_2436));
    break;
  }
  default: heff_nomatch(v_x2_2434);
  }
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_n_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    V v_t_2440 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_b_2431));
    V v_x2_2441 = heff_tr(heff_call(v_t_2440, 1, (V[]){v_n_2439}));
    V v_x2_2444;
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_MkPair: {
      V v_x_2442 = heff_field(v_x2_2441, 0);
      V v_n_2443 = heff_field(v_x2_2441, 1);
      V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
      v_x2_2444 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2441_24MkPair, v_x_2442, v_n_2443));
      break;
    }
    default: heff_nomatch(v_x2_2441);
    }
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_MkPair: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      V v_n_2446 = heff_field(v_x2_2444, 1);
      heff_take_n(v_x2_2444, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2429, v_x_2438, v_x_2445}), v_n_2446});
    }
    default: return heff_nomatch(v_x2_2444);
    }
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam5(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_ts_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2452, v_ts_2448}), v_n_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam6(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_l_2455 = heff_env(self)[1];
  V v_sh_2456 = heff_env(self)[2];
  V v_t_2457 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  V v_x2_2463;
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    v_x2_2463 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2460_24MkPair, v_x_2461, v_n_2462));
    break;
  }
  default: heff_nomatch(v_x2_2460);
  }
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_n_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2464, v_l_2455, v_sh_2456, v_t_2457}), v_n_2465});
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam7(V self, V *args) {
  V v_n_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_t_2466 = heff_env(self)[1];
  V v_ts_2468 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_n_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_n_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2466, v_x_2472, v_ts_2468}), v_n_2473});
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam8(V self, V *args) {
  V v_n_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_arms_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_n_2477}));
  V v_x2_2481;
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_n_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    v_x2_2481 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2478_24MkPair, v_x_2479, v_n_2480));
    break;
  }
  default: heff_nomatch(v_x2_2478);
  }
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    V v_n_2483 = heff_field(v_x2_2481, 1);
    V v_ru_24x2_2481_24MkPair = heff_take_reuse_n(v_x2_2481, 3ULL, 2);
    HeffT2 v_t_2484 = (g_prelude_2etraverse_24s1158390340x316106132_24cpr(v_arms_2475, v_n_2483));
    {
      V v_field_2485 = v_t_2484.f[0];
      V v_field_2486 = v_t_2484.f[1];
      V v_x_2487 = v_field_2485;
      V v_n_2488 = v_field_2486;
      return heff_tag_at_n(v_ru_24x2_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2482, v_x_2487}), v_n_2488});
    }
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam9(V self, V *args) {
  V v_n_2490 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2490});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam10(V self, V *args) {
  V v_n_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  V v_p_2491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2495 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_n_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_n_2497 = heff_field(v_x2_2495, 1);
    V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2491, v_x_2496}), v_n_2497});
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam11(V self, V *args) {
  V v_n_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  V v_g_2498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_n_24101}));
  switch (heff_tag_of(v_x2_24102)) {
  case TAG_MkPair: {
    V v_x_24103 = heff_field(v_x2_24102, 0);
    V v_n_24104 = heff_field(v_x2_24102, 1);
    V v_ru_24x2_24102_24MkPair = heff_take_reuse_n(v_x2_24102, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24102_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2498, v_x_24103}), v_n_24104});
  }
  default: return heff_nomatch(v_x2_24102);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam12(V self, V *args) {
  V v_n_24106 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24106});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam13(V self, V *args) {
  V v_n_24108 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24108});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam14(V self, V *args) {
  V v_n_24110 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24110});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam15(V self, V *args) {
  V v_n_24112 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24112});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam16(V self, V *args) {
  V v_n_24115 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24115});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam17(V self, V *args) {
  V v_n_24117 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24117});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam18(V self, V *args) {
  V v_n_24118 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24118});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam19(V self, V *args) {
  V v_n_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_n_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_n_24124 = heff_field(v_x2_24122, 1);
    V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24123}), v_n_24124});
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam20(V self, V *args) {
  V v_n_24129 = args[0];
  V v_m_24128 = heff_env(self)[0];
  V v_b_24127 = heff_env(self)[1];
  V v_xs_24125 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24130 = heff_tr(heff_call(v_m_24128, 1, (V[]){v_n_24129}));
  V v_x2_24133;
  switch (heff_tag_of(v_x2_24130)) {
  case TAG_MkPair: {
    V v_x_24131 = heff_field(v_x2_24130, 0);
    V v_n_24132 = heff_field(v_x2_24130, 1);
    V v_ru_24x2_24130_24MkPair = heff_take_reuse_n(v_x2_24130, 3ULL, 2);
    v_x2_24133 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_24130_24MkPair, v_x_24131, v_n_24132));
    break;
  }
  default: heff_nomatch(v_x2_24130);
  }
  switch (heff_tag_of(v_x2_24133)) {
  case TAG_MkPair: {
    V v_x_24134 = heff_field(v_x2_24133, 0);
    V v_n_24135 = heff_field(v_x2_24133, 1);
    V v_ru_24x2_24133_24MkPair = heff_take_reuse_n(v_x2_24133, 3ULL, 2);
    V v_t_24136 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_b_24127));
    V v_x2_24137 = heff_tr(heff_call(v_t_24136, 1, (V[]){v_n_24135}));
    V v_x2_24140;
    switch (heff_tag_of(v_x2_24137)) {
    case TAG_MkPair: {
      V v_x_24138 = heff_field(v_x2_24137, 0);
      V v_n_24139 = heff_field(v_x2_24137, 1);
      V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
      v_x2_24140 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_24137_24MkPair, v_x_24138, v_n_24139));
      break;
    }
    default: heff_nomatch(v_x2_24137);
    }
    switch (heff_tag_of(v_x2_24140)) {
    case TAG_MkPair: {
      V v_x_24141 = heff_field(v_x2_24140, 0);
      V v_n_24142 = heff_field(v_x2_24140, 1);
      heff_take_n(v_x2_24140, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24133_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24125, v_x_24134, v_x_24141}), v_n_24142});
    }
    default: return heff_nomatch(v_x2_24140);
    }
  }
  default: return heff_nomatch(v_x2_24133);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam21(V self, V *args) {
  V v_n_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_n_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_n_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24147}), v_n_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam22(V self, V *args) {
  V v_n_24152 = args[0];
  V v_m_24151 = heff_env(self)[0];
  V v_x_24149 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24153 = heff_tr(heff_call(v_m_24151, 1, (V[]){v_n_24152}));
  V v_x2_24156;
  switch (heff_tag_of(v_x2_24153)) {
  case TAG_MkPair: {
    V v_x_24154 = heff_field(v_x2_24153, 0);
    V v_n_24155 = heff_field(v_x2_24153, 1);
    V v_ru_24x2_24153_24MkPair = heff_take_reuse_n(v_x2_24153, 3ULL, 2);
    v_x2_24156 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_24153_24MkPair, v_x_24154, v_n_24155));
    break;
  }
  default: heff_nomatch(v_x2_24153);
  }
  switch (heff_tag_of(v_x2_24156)) {
  case TAG_MkPair: {
    V v_x_24157 = heff_field(v_x2_24156, 0);
    V v_n_24158 = heff_field(v_x2_24156, 1);
    V v_ru_24x2_24156_24MkPair = heff_take_reuse_n(v_x2_24156, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24156_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24149, v_x_24157}), v_n_24158});
  }
  default: return heff_nomatch(v_x2_24156);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_entry, 6, 0};

V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243, V v_d_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_x_246 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_a_247 = heff_strCompare_lent(v_x_246, v_lit_241, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_a_247);
      return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EVar, 1, (V[]){v_x_246}));
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        heff_drop(v_x_246);
        return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_lit_242)}));
      } else {
        return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EVar, 1, (V[]){v_x_246}));
      }
    }
  }
  case TAG_EGlobal: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_243, 0);
    V v_b_2410 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_cell_2411 = heff_tag_re_n(v_ru_24e_243_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_249, heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_244, heff_dup(v_i_245), v_cell_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2410;
    V t_4 = v_u_2412;
    V t_5 = MK_INT(1LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_243, 0);
    V v_args_2414 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2415 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_f_2413));
    V v_t_2417 = (g_list_2emap_24tok2(v_ru_24e_243_24EApp, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam0, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_args_2414));
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EApp, 2, (V[]){v_t_2415, v_t_2417}));
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_e_243, 0);
    V v_a_2419 = heff_field(v_e_243, 1);
    V v_b_2420 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ELet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_a_2419));
    V v_cell_2422 = heff_tag_re_n(v_ru_24e_243_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2418, v_t_2421, heff_hole()});
    V v_u_2423 = heff_setFieldPeek(v_d_244, heff_dup(v_i_245), v_cell_2422);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2420;
    V t_4 = v_u_2423;
    V t_5 = MK_INT(2LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_e_243, 0);
    V v_ts_2425 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24tok2(v_ru_24e_243_24ERecord, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam1, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_fs_2424));
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2430, v_ts_2425}));
  }
  case TAG_EProj: {
    V v_e2_2431 = heff_field(v_e_243, 0);
    V v_l_2432 = heff_field(v_e_243, 1);
    V v_sh_2433 = heff_field(v_e_243, 2);
    V v_t_2434 = heff_field(v_e_243, 3);
    heff_take_n(v_e_243, 15ULL, 4);
    V v_t_2435 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_e2_2431));
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EProj, 4, (V[]){v_t_2435, v_l_2432, v_sh_2433, v_t_2434}));
  }
  case TAG_ETag: {
    V v_t_2436 = heff_field(v_e_243, 0);
    V v_args_2437 = heff_field(v_e_243, 1);
    V v_ts_2438 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam2, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_args_2437));
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_ETag, 3, (V[]){v_t_2436, v_t_2440, v_ts_2438}));
  }
  case TAG_EMatch: {
    V v_s_2441 = heff_field(v_e_243, 0);
    V v_arms_2442 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2443 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_s_2441));
    V v_t_2449 = (g_list_2emap_24tok2(v_ru_24e_243_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam3, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_arms_2442));
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2443, v_t_2449}));
  }
  case TAG_EPrim: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_EPrimCall: {
    V v_p_2451 = heff_field(v_e_243, 0);
    V v_args_2452 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2454 = (g_list_2emap_24tok2(v_ru_24e_243_24EPrimCall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam4, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_args_2452));
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2451, v_t_2454}));
  }
  case TAG_ECall: {
    V v_g_2455 = heff_field(v_e_243, 0);
    V v_args_2456 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2458 = (g_list_2emap_24tok2(v_ru_24e_243_24ECall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam5, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_args_2456));
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_ECall, 2, (V[]){v_g_2455, v_t_2458}));
  }
  case TAG_EInt: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_EFloat: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_EStr: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_EBytes: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_EFixed: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_EFloat32: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_EAbandon: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  case TAG_EBool: {
    V v_c_2466 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2468 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam6, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}); V a_1 = v_c_2466; V r_ = (g_heff_2ecompile_2eir_2econdMap(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EBool, 1, (V[]){v_t_2468}));
  }
  case TAG_ESet: {
    V v_xs_2469 = heff_field(v_e_243, 0);
    V v_a_2470 = heff_field(v_e_243, 1);
    V v_b_2471 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ESet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2472 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_a_2470));
    V v_cell_2473 = heff_tag_re_n(v_ru_24e_243_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_2469, v_t_2472, heff_hole()});
    V v_u_2474 = heff_setFieldPeek(v_d_244, heff_dup(v_i_245), v_cell_2473);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2471;
    V t_4 = v_u_2474;
    V t_5 = MK_INT(2LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2475 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2477 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam7, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_es_2475));
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), heff_tag_n(TAG_EValues, 1, (V[]){v_t_2477}));
  }
  case TAG_EFix: {
    return heff_setField(heff_dup(v_d_244), heff_dup(v_i_245), v_e_243);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(a0, a1, a2, a[3], a4, a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam0(V self, V *args) {
  V v_a_2416 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2416; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam1(V self, V *args) {
  V v_p_2426 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  switch (heff_tag_of(v_p_2426)) {
  case TAG_MkPair: {
    V v_l_2427 = heff_field(v_p_2426, 0);
    V v_e2_2428 = heff_field(v_p_2426, 1);
    V v_ru_24p_2426_24MkPair = heff_take_reuse_n(v_p_2426, 3ULL, 2);
    heff_clo_take(self, 3);
    V v_t_2429 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_e2_2428; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    return heff_tag_re_n(v_ru_24p_2426_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_2427, v_t_2429});
  }
  default: return heff_nomatch(v_p_2426);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam2(V self, V *args) {
  V v_a_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2439; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam3(V self, V *args) {
  V v_a_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_field(v_a_2444, 0);
    V v_vs_2446 = heff_field(v_a_2444, 1);
    V v_b_2447 = heff_field(v_a_2444, 2);
    V v_ru_24a_2444_24MkArm = heff_take_reuse_n(v_a_2444, 7ULL, 3);
    heff_clo_take(self, 3);
    V v_t_2448 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_b_2447; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    return heff_tag_re_n(v_ru_24a_2444_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2445, v_vs_2446, v_t_2448});
  }
  default: return heff_nomatch(v_a_2444);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam4(V self, V *args) {
  V v_a_2453 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2453; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam5(V self, V *args) {
  V v_a_2457 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2457; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam6(V self, V *args) {
  V v_a_2467 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2467; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam7(V self, V *args) {
  V v_a_2476 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2476; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}