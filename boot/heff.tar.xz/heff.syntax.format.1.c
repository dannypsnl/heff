// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IntWord 51777
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkBinding 51651
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_Right 62770
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StringWord 15530
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_blank 295177582
#define LBL_claim 296100950
#define LBL_cmt 308164
#define LBL_col 308218
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_digits 615232529
#define LBL_e 319
#define LBL_end 310101
#define LBL_env 310119
#define LBL_err 310239
#define LBL_error 298143266
#define LBL_exponent 966452320
#define LBL_exposes 1070285678
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lead 9813027
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_listed 844633320
#define LBL_name 9869138
#define LBL_negative 1666250321
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_offset 927361982
#define LBL_out 319944
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_raw 322210
#define LBL_span 10032145
#define LBL_src 323678
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_trail 311979552
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__decls__diags[] = {LBL_imports, LBL_decls, LBL_diags};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_line__offset__out[] = {LBL_line, LBL_offset, LBL_out};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019(V, V, V, V, V);
V g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_entry(V self, V *a);
extern Clo g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_clo;
HeffT2 g_heff_2esyntax_2ecst_2eprogramGo_24cpr(V, V);
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get(void);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo;
V g_heff_2esyntax_2eformat_2ekeyTermF(V, V);
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo;
V g_heff_2esyntax_2eformat_2ekeys_get(void);
V g_heff_2esyntax_2eformat_2elamKey(V, V);
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2elamKey_clo;
V g_heff_2esyntax_2eformat_2emeaning(V);
V g_heff_2esyntax_2eformat_2emeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaning_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2epiKey(V, V);
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epiKey_clo;
HeffT2 g_heff_2esyntax_2eformat_2esameMeaning_24cpr(V, V, V, V);
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
HeffT2 g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_24cpr(V, V);
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
HeffT5 g_heff_2esyntax_2esurface_2ereadRun_24cpr(V, V, V, V, V, V);
V g_list_2eascending_24s1547370222x166817322(V, V, V);
V g_list_2eascending_24s1547370222x166817322_entry(V self, V *a);
extern Clo g_list_2eascending_24s1547370222x166817322_clo;
V g_list_2eascending_24s946492440x1788863194(V, V, V);
V g_list_2eascending_24s946492440x1788863194_entry(V self, V *a);
extern Clo g_list_2eascending_24s946492440x1788863194_clo;
V g_list_2edescending_24s1432586697x321478004(V, V, V);
V g_list_2edescending_24s1432586697x321478004_entry(V self, V *a);
extern Clo g_list_2edescending_24s1432586697x321478004_clo;
V g_list_2edescending_24s1706700342x2062518382(V, V, V);
V g_list_2edescending_24s1706700342x2062518382_entry(V self, V *a);
extern Clo g_list_2edescending_24s1706700342x2062518382_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1872971975x1696014049(V, V, V);
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1872971975x1696014049_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1055307687x247454614(V, V);
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_clo;
V g_list_2emap_24s1099021180x1702355548(V, V);
V g_list_2emap_24s1099021180x1702355548_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_clo;
V g_list_2emap_24s1152414072x2935301(V, V);
V g_list_2emap_24s1152414072x2935301_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_clo;
V g_list_2emap_24s135291903x1031656159(V, V);
V g_list_2emap_24s135291903x1031656159_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_clo;
V g_list_2emap_24s1409451498x400757684(V);
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_clo;
V g_list_2emap_24s179832492x431904054(V);
V g_list_2emap_24s179832492x431904054_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s1975257801x764827799(V);
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_clo;
V g_list_2emap_24s228910449x1110031924(V, V);
V g_list_2emap_24s228910449x1110031924_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s32026788x2029987799(V);
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s354283597x484250159(V, V);
V g_list_2emap_24s354283597x484250159_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_clo;
V g_list_2emap_24s510830240x893896831(V, V);
V g_list_2emap_24s510830240x893896831_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s900318151x1569363206(V, V, V);
V g_list_2emap_24s900318151x1569363206_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s1839386886x1884977030(V, V);
V g_list_2emergeRuns_24s1839386886x1884977030_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1839386886x1884977030_clo;
V g_list_2emergeRuns_24s2052062657x972894659(V, V);
V g_list_2emergeRuns_24s2052062657x972894659_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s2052062657x972894659_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2edisplay_2edisplayInto_240(V, V);
V g_std_2edoc_2edisplay_2edisplayInto_240_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplay_2edisplayInto_240_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str3, 6, "(named");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str8, 9, "(implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str13, 9, "(implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str18, 9, "(instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str23, 5, "(anon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str24, 1, ")");
Clo g_heff_2esyntax_2eformat_2epiKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epiKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2epiKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_244)}));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_parts_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_t_246});
    V v_x2_248 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str0), v_parts_247));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str3), v_t_2411), ((V)&g_heff_2esyntax_2eformat_2epiKey_str4));
  }
  case TAG_PiImplicit: {
    V v_x_2412 = heff_field(v_x2_241, 0);
    V v_t_2415 = heff_field(v_x2_241, 3);
    V v_x25_2416 = heff_field(v_x2_241, 4);
    switch (heff_tag_of(v_x25_2416)) {
    case TAG_Nothing: {
      V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2415)}));
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str5), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str7); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str8), v_t_2423), ((V)&g_heff_2esyntax_2eformat_2epiKey_str9));
    }
    case TAG_Just: {
      V v_d_2424 = heff_field(v_x25_2416, 0);
      V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2415)}));
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_d_2424)}));
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
      V v_parts_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2427})});
      V v_x2_2429 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str10), v_parts_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str12); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str13), v_t_2432), ((V)&g_heff_2esyntax_2eformat_2epiKey_str14));
    }
    default: return heff_nomatch(v_x25_2416);
    }
  }
  case TAG_PiInstance: {
    V v_x_2433 = heff_field(v_x2_241, 0);
    V v_t_2436 = heff_field(v_x2_241, 3);
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2436)}));
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
    V v_parts_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2433), v_t_2438});
    V v_x2_2440 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str15), v_parts_2439));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str17); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str18), v_t_2443), ((V)&g_heff_2esyntax_2eformat_2epiKey_str19));
  }
  case TAG_PiAnon: {
    V v_t_2444 = heff_field(v_x2_241, 0);
    V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2444)}));
    V v_parts_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    V v_x2_2447 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str20), v_parts_2446));
    V v_t_2450;
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_Nil: {
      v_t_2450 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_xs_2449 = heff_field(v_x2_2447, 1);
      heff_take_n(v_x2_2447, 3ULL, 2);
      v_t_2450 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str22); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2447);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str23), v_t_2450), ((V)&g_heff_2esyntax_2eformat_2epiKey_str24));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2epiKey(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str0, 4, "(var");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str2, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str3, 9, "(implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str6, 9, "(notation");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str9, 4, "(tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str15, 4, "(int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str20, 6, "(float");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str23, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str25, 7, "(string");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str26, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str27, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str28, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str29, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str30, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str31, 3, "utf");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str32, 7, "default");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str33, 1, "*");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str34, 4, "true");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str35, 5, "false");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str36, 4, "true");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str37, 5, "false");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str41, 8, "(segment");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str42, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str43, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str44, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str45, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str46, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str48, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str49, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str50, 7, "(binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str51, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str53, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str54, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str55, 5, "(rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str56, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str57, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str58, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str59, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str60, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str61, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str62, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str63, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str64, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str65, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str66, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str67, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str68, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str69, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str70, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str71, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str72, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str74, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str75, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str76, 5, "(word");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str77, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str78, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str79, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str80, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str81, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str83, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str84, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str85, 4, "(app");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str86, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str88, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str89, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str90, 8, "(project");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str91, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str93, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str94, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str95, 6, "(named");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str96, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str98, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str99, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str100, 3, "(pi");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str101, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str103, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str104, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str105, 4, "(lam");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str106, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str108, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str109, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str110, 4, "(ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str111, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str112, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str113, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str114, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str115, 5, "(spec");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str116, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str117, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str118, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str119, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str120, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str121, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str122, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str123, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str124, 4, "(sig");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str125, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str126, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str127, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str128, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str129, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str131, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str132, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str133, 4, "(sum");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str134, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str135, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str136, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str137, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str138, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str139, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str140, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str141, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str142, 7, "(struct");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str143, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str144, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str145, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str146, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str147, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str148, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str149, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str150, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str151, 7, "(update");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str152, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str153, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str154, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str155, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str156, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str157, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str158, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str159, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str160, 6, "(match");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str161, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str162, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str163, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str164, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str165, 4, "(let");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str166, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str167, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str168, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str169, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str170, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str171, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str172, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str173, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str174, 3, "(do");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str175, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str176, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str177, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str178, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str179, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str180, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str181, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str182, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str183, 6, "(local");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str184, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str185, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str186, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str187, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str188, 8, "(invalid");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str189, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str190, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str191, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str192, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str193, 7, "(assign");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str194, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str195, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str196, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str197, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str198, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str199, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str200, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str201, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str202, 6, "(while");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str203, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str204, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str205, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str206, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str207, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str208, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str209, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str210, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str211, 4, "(for");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str212, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str213, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str214, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str215, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str216, 7, "(ifthen");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str217, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str218, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str219, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str220, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str221, 6, "(break");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str222, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str223, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str224, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str225, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str226, 9, "(continue");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str227, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str228, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str229, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str230, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str231, 7, "(return");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str232, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str233, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str234, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str235, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str236, 5, "(nest");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str237, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str238, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str239, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str240, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str241, 5, "(lazy");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str242, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str243, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str244, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str245, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str246, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str247, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str248, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str249, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str250, 6, "(tuple");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str251, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str252, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str253, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str254, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str255, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str256, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str257, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str258, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str259, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str260, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str261, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str262, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str263, 6, "(catch");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str264, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str265, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str266, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str267, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str268, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str269, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str270, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str271, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str272, 4, "(try");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str273, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str274, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str275, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str276, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str277, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str278, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str279, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str280, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str281, 5, "(with");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str282, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str283, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str284, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str285, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str286, 8, "(binding");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str287, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str288, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str289, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str290, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str291, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str292, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str293, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str294, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str295, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str296, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str297, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str298, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str299, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str300, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str301, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str302, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str303, 10, "(withbound");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str304, 1, ")");
V g_heff_2esyntax_2eformat_2ekeyTermF_lam0(V self, V *args);
V g_heff_2esyntax_2eformat_2ekeyTermF_lam1(V self, V *args);
Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyTermF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str0), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str1), v_x_244));
      return heff_strAppend(v_t_245, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str2));
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str4), v_x_246));
      return heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str5));
    }
    case TAG_ENotationVar: {
      V v_x_248 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 3);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str6), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str7), v_x_248));
      return heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str8));
    }
    case TAG_ETag: {
      V v_x_2412 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str10), v_x_2412));
      return heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str11));
    }
    case TAG_EInt: {
      V v_i_2414 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_i_2414), NTAG(TAG_Nil)});
      V v_x2_2416 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str12), v_t_2415));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str14); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str15), v_t_2419), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str16));
    }
    case TAG_EFloat: {
      V v_x_2420 = heff_tget_v(v_x21_242, 0);
      heff_take_nf(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_negative_2421 = heff_take_field(v_x_2420, 0);
      V v_digits_2422 = heff_take_field(v_x_2420, 1);
      V v_exponent_2423 = heff_get_n(v_x_2420, 2, 3);
      V v_t_2424 = v_negative_2421;
      double v_t_2426;
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_t_2424);
        double v_x_2425 = ({ V a_0 = v_digits_2422; V a_1 = v_exponent_2423; double r_ = (g_std_2emath_2efromDecimal_w(a_0, a_1)); heff_drop(v_exponent_2423); r_; });
        v_t_2426 = ((-1.0) * v_x_2425);
      } else {
        heff_drop(v_t_2424);
        v_t_2426 = ({ V a_0 = v_digits_2422; V a_1 = v_exponent_2423; double r_ = (g_std_2emath_2efromDecimal_w(a_0, a_1)); heff_drop(v_exponent_2423); r_; });
      }
      V v_parts_2427 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_floatShow(heff_box_f64(v_t_2426)), NTAG(TAG_Nil)});
      V v_x2_2428 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str17), v_parts_2427));
      V v_t_2431;
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_Nil: {
        v_t_2431 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str18);
        break;
      }
      case TAG_Cons: {
        V v_x_2429 = heff_field(v_x2_2428, 0);
        V v_xs_2430 = heff_field(v_x2_2428, 1);
        heff_take_n(v_x2_2428, 3ULL, 2);
        v_t_2431 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str19); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2428);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str20), v_t_2431), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str21));
    }
    case TAG_EString: {
      V v_x_2432 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2433 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
      V v_x2_2434 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str22), v_t_2433));
      V v_t_2437;
      switch (heff_tag_of(v_x2_2434)) {
      case TAG_Nil: {
        v_t_2437 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str23);
        break;
      }
      case TAG_Cons: {
        V v_x_2435 = heff_field(v_x2_2434, 0);
        V v_xs_2436 = heff_field(v_x2_2434, 1);
        heff_take_n(v_x2_2434, 3ULL, 2);
        v_t_2437 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str24); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2434);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str25), v_t_2437), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str26));
    }
    case TAG_EBinary: {
      V v_segs_2438 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_2466 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam0, 1, 1, (V[]){v_r_240}), v_segs_2438));
      V v_t_2469;
      switch (heff_tag_of(v_x2_2466)) {
      case TAG_Nil: {
        v_t_2469 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str43);
        break;
      }
      case TAG_Cons: {
        V v_x_2467 = heff_field(v_x2_2466, 0);
        V v_xs_2468 = heff_field(v_x2_2466, 1);
        heff_take_n(v_x2_2466, 3ULL, 2);
        v_t_2469 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str44); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2466);
      }
      V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str45), v_t_2469), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str46));
      V v_parts_2471 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
      V v_x2_2472 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str47), v_parts_2471));
      V v_t_2475;
      switch (heff_tag_of(v_x2_2472)) {
      case TAG_Nil: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str48);
        break;
      }
      case TAG_Cons: {
        V v_x_2473 = heff_field(v_x2_2472, 0);
        V v_xs_2474 = heff_field(v_x2_2472, 1);
        heff_take_n(v_x2_2472, 3ULL, 2);
        v_t_2475 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str49); V a_1 = v_x_2473; V a_2 = v_xs_2474; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2474); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2472);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str50), v_t_2475), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str51));
    }
    case TAG_ERune: {
      V v_c_2476 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2477 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_c_2476), NTAG(TAG_Nil)});
      V v_x2_2478 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str52), v_t_2477));
      V v_t_2481;
      switch (heff_tag_of(v_x2_2478)) {
      case TAG_Nil: {
        v_t_2481 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str53);
        break;
      }
      case TAG_Cons: {
        V v_x_2479 = heff_field(v_x2_2478, 0);
        V v_xs_2480 = heff_field(v_x2_2478, 1);
        heff_take_n(v_x2_2478, 3ULL, 2);
        v_t_2481 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str54); V a_1 = v_x_2479; V a_2 = v_xs_2480; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2480); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2478);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str55), v_t_2481), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str56));
    }
    case TAG_EWord: {
      V v_w_2482 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2484;
      switch (heff_tag_of(v_w_2482)) {
      case TAG_TypeWord: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str57);
        break;
      }
      case TAG_IntWord: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str58);
        break;
      }
      case TAG_FloatWord: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str59);
        break;
      }
      case TAG_StringWord: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str60);
        break;
      }
      case TAG_RuneWord: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str61);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str62);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str63);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2483 = heff_field(v_w_2482, 0);
        heff_take_n(v_w_2482, 1ULL, 1);
        switch (heff_tag_of(v_w_2483)) {
        case TAG_I8: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str64);
          break;
        }
        case TAG_I16: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str65);
          break;
        }
        case TAG_I32: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str66);
          break;
        }
        case TAG_I64: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str67);
          break;
        }
        case TAG_U8: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str68);
          break;
        }
        case TAG_U16: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str69);
          break;
        }
        case TAG_U32: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str70);
          break;
        }
        case TAG_U64: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str71);
          break;
        }
        case TAG_F32: {
          v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str72);
          break;
        }
        default: heff_nomatch(v_w_2483);
        }
        break;
      }
      default: heff_nomatch(v_w_2482);
      }
      V v_t_2485 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
      V v_x2_2486 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str73), v_t_2485));
      V v_t_2489;
      switch (heff_tag_of(v_x2_2486)) {
      case TAG_Nil: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str74);
        break;
      }
      case TAG_Cons: {
        V v_x_2487 = heff_field(v_x2_2486, 0);
        V v_xs_2488 = heff_field(v_x2_2486, 1);
        heff_take_n(v_x2_2486, 3ULL, 2);
        v_t_2489 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str75); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2486);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str76), v_t_2489), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str77));
    }
    case TAG_EApp: {
      V v_h_2490 = heff_field(v_x21_242, 0);
      V v_args_2491 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2492 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_2490}));
      V v_x2_2493 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_2491));
      V v_t_2496;
      switch (heff_tag_of(v_x2_2493)) {
      case TAG_Nil: {
        v_t_2496 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str78);
        break;
      }
      case TAG_Cons: {
        V v_x_2494 = heff_field(v_x2_2493, 0);
        V v_xs_2495 = heff_field(v_x2_2493, 1);
        heff_take_n(v_x2_2493, 3ULL, 2);
        v_t_2496 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str79); V a_1 = v_x_2494; V a_2 = v_xs_2495; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2495); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2493);
      }
      V v_t_2497 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str80), v_t_2496), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str81));
      V v_t_2498 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
      V v_parts_2499 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_Cons, 2, (V[]){v_t_2492, v_t_2498});
      V v_x2_24100 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str82), v_parts_2499));
      V v_t_24103;
      switch (heff_tag_of(v_x2_24100)) {
      case TAG_Nil: {
        v_t_24103 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str83);
        break;
      }
      case TAG_Cons: {
        V v_x_24101 = heff_field(v_x2_24100, 0);
        V v_xs_24102 = heff_field(v_x2_24100, 1);
        heff_take_n(v_x2_24100, 3ULL, 2);
        v_t_24103 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str84); V a_1 = v_x_24101; V a_2 = v_xs_24102; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24102); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24100);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str85), v_t_24103), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str86));
    }
    case TAG_EProject: {
      V v_x_24104 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24105 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_24104, NTAG(TAG_Nil)});
      V v_x2_24106 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str87), v_t_24105));
      V v_t_24109;
      switch (heff_tag_of(v_x2_24106)) {
      case TAG_Nil: {
        v_t_24109 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str88);
        break;
      }
      case TAG_Cons: {
        V v_x_24107 = heff_field(v_x2_24106, 0);
        V v_xs_24108 = heff_field(v_x2_24106, 1);
        heff_take_n(v_x2_24106, 3ULL, 2);
        v_t_24109 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str89); V a_1 = v_x_24107; V a_2 = v_xs_24108; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24108); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24106);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str90), v_t_24109), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str91));
    }
    case TAG_ENamed: {
      V v_x_24110 = heff_field(v_x21_242, 0);
      V v_e_24111 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24112 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24111}));
      V v_t_24113 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24112, NTAG(TAG_Nil)});
      V v_parts_24114 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_Cons, 2, (V[]){v_x_24110, v_t_24113});
      V v_x2_24115 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str92), v_parts_24114));
      V v_t_24118;
      switch (heff_tag_of(v_x2_24115)) {
      case TAG_Nil: {
        v_t_24118 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str93);
        break;
      }
      case TAG_Cons: {
        V v_x_24116 = heff_field(v_x2_24115, 0);
        V v_xs_24117 = heff_field(v_x2_24115, 1);
        heff_take_n(v_x2_24115, 3ULL, 2);
        v_t_24118 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str94); V a_1 = v_x_24116; V a_2 = v_xs_24117; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24117); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24115);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str95), v_t_24118), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str96));
    }
    case TAG_EPi: {
      V v_b_24119 = heff_field(v_x21_242, 0);
      V v_cod_24120 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24121 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_b_24119; V r_ = (g_heff_2esyntax_2eformat_2epiKey(a_0, a_1)); heff_drop(v_b_24119); r_; });
      V v_t_24122 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_24120}));
      V v_t_24123 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24122, NTAG(TAG_Nil)});
      V v_parts_24124 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_Cons, 2, (V[]){v_t_24121, v_t_24123});
      V v_x2_24125 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str97), v_parts_24124));
      V v_t_24128;
      switch (heff_tag_of(v_x2_24125)) {
      case TAG_Nil: {
        v_t_24128 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str98);
        break;
      }
      case TAG_Cons: {
        V v_x_24126 = heff_field(v_x2_24125, 0);
        V v_xs_24127 = heff_field(v_x2_24125, 1);
        heff_take_n(v_x2_24125, 3ULL, 2);
        v_t_24128 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str99); V a_1 = v_x_24126; V a_2 = v_xs_24127; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24127); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24125);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str100), v_t_24128), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str101));
    }
    case TAG_ELam: {
      V v_b_24129 = heff_field(v_x21_242, 0);
      V v_body_24130 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24131 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_b_24129; V r_ = (g_heff_2esyntax_2eformat_2elamKey(a_0, a_1)); heff_drop(v_b_24129); r_; });
      V v_t_24132 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_24130}));
      V v_t_24133 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
      V v_parts_24134 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_Cons, 2, (V[]){v_t_24131, v_t_24133});
      V v_x2_24135 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str102), v_parts_24134));
      V v_t_24138;
      switch (heff_tag_of(v_x2_24135)) {
      case TAG_Nil: {
        v_t_24138 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str103);
        break;
      }
      case TAG_Cons: {
        V v_x_24136 = heff_field(v_x2_24135, 0);
        V v_xs_24137 = heff_field(v_x2_24135, 1);
        heff_take_n(v_x2_24135, 3ULL, 2);
        v_t_24138 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str104); V a_1 = v_x_24136; V a_2 = v_xs_24137; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24137); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24135);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str105), v_t_24138), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str106));
    }
    case TAG_EAnn: {
      V v_e_24139 = heff_field(v_x21_242, 0);
      V v_t_24140 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24141 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24139}));
      V v_t_24142 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24140}));
      V v_t_24143 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24142, NTAG(TAG_Nil)});
      V v_parts_24144 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_Cons, 2, (V[]){v_t_24141, v_t_24143});
      V v_x2_24145 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str107), v_parts_24144));
      V v_t_24148;
      switch (heff_tag_of(v_x2_24145)) {
      case TAG_Nil: {
        v_t_24148 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str108);
        break;
      }
      case TAG_Cons: {
        V v_x_24146 = heff_field(v_x2_24145, 0);
        V v_xs_24147 = heff_field(v_x2_24145, 1);
        heff_take_n(v_x2_24145, 3ULL, 2);
        v_t_24148 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str109); V a_1 = v_x_24146; V a_2 = v_xs_24147; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24147); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24145);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str110), v_t_24148), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str111));
    }
    case TAG_ESpec: {
      V v_acc_24149 = heff_field(v_x21_242, 0);
      V v_x_24150 = heff_field(v_x21_242, 1);
      V v_v_24152 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      V v_t_24153 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_acc_24149}));
      V v_t_24154 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24152}));
      V v_t_24155 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24154, NTAG(TAG_Nil)});
      V v_parts_24156 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24153, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24150, v_t_24155})});
      V v_x2_24157 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str112), v_parts_24156));
      V v_t_24160;
      switch (heff_tag_of(v_x2_24157)) {
      case TAG_Nil: {
        v_t_24160 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str113);
        break;
      }
      case TAG_Cons: {
        V v_x_24158 = heff_field(v_x2_24157, 0);
        V v_xs_24159 = heff_field(v_x2_24157, 1);
        heff_take_n(v_x2_24157, 3ULL, 2);
        v_t_24160 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str114); V a_1 = v_x_24158; V a_2 = v_xs_24159; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24159); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24157);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str115), v_t_24160), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str116));
    }
    case TAG_ESig: {
      V v_fs_24161 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24162 = (g_list_2emap_24s135291903x1031656159(v_r_240, v_fs_24161));
      V v_t_24165;
      switch (heff_tag_of(v_x2_24162)) {
      case TAG_Nil: {
        v_t_24165 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str117);
        break;
      }
      case TAG_Cons: {
        V v_x_24163 = heff_field(v_x2_24162, 0);
        V v_xs_24164 = heff_field(v_x2_24162, 1);
        heff_take_n(v_x2_24162, 3ULL, 2);
        v_t_24165 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str118); V a_1 = v_x_24163; V a_2 = v_xs_24164; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24164); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24162);
      }
      V v_t_24166 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str119), v_t_24165), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str120));
      V v_parts_24167 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24166, NTAG(TAG_Nil)});
      V v_x2_24168 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str121), v_parts_24167));
      V v_t_24171;
      switch (heff_tag_of(v_x2_24168)) {
      case TAG_Nil: {
        v_t_24171 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str122);
        break;
      }
      case TAG_Cons: {
        V v_x_24169 = heff_field(v_x2_24168, 0);
        V v_xs_24170 = heff_field(v_x2_24168, 1);
        heff_take_n(v_x2_24168, 3ULL, 2);
        v_t_24171 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str123); V a_1 = v_x_24169; V a_2 = v_xs_24170; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24170); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24168);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str124), v_t_24171), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str125));
    }
    case TAG_ESum: {
      V v_vs_24172 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24173 = (g_list_2emap_24s354283597x484250159(v_r_240, v_vs_24172));
      V v_t_24176;
      switch (heff_tag_of(v_x2_24173)) {
      case TAG_Nil: {
        v_t_24176 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str126);
        break;
      }
      case TAG_Cons: {
        V v_x_24174 = heff_field(v_x2_24173, 0);
        V v_xs_24175 = heff_field(v_x2_24173, 1);
        heff_take_n(v_x2_24173, 3ULL, 2);
        v_t_24176 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str127); V a_1 = v_x_24174; V a_2 = v_xs_24175; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24175); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24173);
      }
      V v_t_24177 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str128), v_t_24176), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str129));
      V v_parts_24178 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24177, NTAG(TAG_Nil)});
      V v_x2_24179 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str130), v_parts_24178));
      V v_t_24182;
      switch (heff_tag_of(v_x2_24179)) {
      case TAG_Nil: {
        v_t_24182 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str131);
        break;
      }
      case TAG_Cons: {
        V v_x_24180 = heff_field(v_x2_24179, 0);
        V v_xs_24181 = heff_field(v_x2_24179, 1);
        heff_take_n(v_x2_24179, 3ULL, 2);
        v_t_24182 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str132); V a_1 = v_x_24180; V a_2 = v_xs_24181; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24181); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24179);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str133), v_t_24182), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str134));
    }
    case TAG_EStruct: {
      V v_fs_24183 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24184 = (g_list_2emap_24s1099021180x1702355548(v_r_240, v_fs_24183));
      V v_t_24187;
      switch (heff_tag_of(v_x2_24184)) {
      case TAG_Nil: {
        v_t_24187 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str135);
        break;
      }
      case TAG_Cons: {
        V v_x_24185 = heff_field(v_x2_24184, 0);
        V v_xs_24186 = heff_field(v_x2_24184, 1);
        heff_take_n(v_x2_24184, 3ULL, 2);
        v_t_24187 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str136); V a_1 = v_x_24185; V a_2 = v_xs_24186; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24186); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24184);
      }
      V v_t_24188 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str137), v_t_24187), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str138));
      V v_parts_24189 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24188, NTAG(TAG_Nil)});
      V v_x2_24190 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str139), v_parts_24189));
      V v_t_24193;
      switch (heff_tag_of(v_x2_24190)) {
      case TAG_Nil: {
        v_t_24193 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str140);
        break;
      }
      case TAG_Cons: {
        V v_x_24191 = heff_field(v_x2_24190, 0);
        V v_xs_24192 = heff_field(v_x2_24190, 1);
        heff_take_n(v_x2_24190, 3ULL, 2);
        v_t_24193 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str141); V a_1 = v_x_24191; V a_2 = v_xs_24192; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24192); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24190);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str142), v_t_24193), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str143));
    }
    case TAG_EUpdate: {
      V v_a_24194 = heff_field(v_x21_242, 0);
      V v_fs_24195 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24196 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24194}));
      V v_x2_24197 = (g_list_2emap_24s510830240x893896831(v_r_240, v_fs_24195));
      V v_t_24200;
      switch (heff_tag_of(v_x2_24197)) {
      case TAG_Nil: {
        v_t_24200 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str144);
        break;
      }
      case TAG_Cons: {
        V v_x_24198 = heff_field(v_x2_24197, 0);
        V v_xs_24199 = heff_field(v_x2_24197, 1);
        heff_take_n(v_x2_24197, 3ULL, 2);
        v_t_24200 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str145); V a_1 = v_x_24198; V a_2 = v_xs_24199; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24199); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24197);
      }
      V v_t_24201 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str146), v_t_24200), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str147));
      V v_t_24202 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24201, NTAG(TAG_Nil)});
      V v_parts_24203 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_Cons, 2, (V[]){v_t_24196, v_t_24202});
      V v_x2_24204 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str148), v_parts_24203));
      V v_t_24207;
      switch (heff_tag_of(v_x2_24204)) {
      case TAG_Nil: {
        v_t_24207 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str149);
        break;
      }
      case TAG_Cons: {
        V v_x_24205 = heff_field(v_x2_24204, 0);
        V v_xs_24206 = heff_field(v_x2_24204, 1);
        heff_take_n(v_x2_24204, 3ULL, 2);
        v_t_24207 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str150); V a_1 = v_x_24205; V a_2 = v_xs_24206; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24206); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24204);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str151), v_t_24207), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str152));
    }
    case TAG_EMatch: {
      V v_s_24208 = heff_field(v_x21_242, 0);
      V v_alts_24209 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24210 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24208}));
      V v_x2_24211 = (g_list_2emap_24s1152414072x2935301(v_r_240, v_alts_24209));
      V v_t_24214;
      switch (heff_tag_of(v_x2_24211)) {
      case TAG_Nil: {
        v_t_24214 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str153);
        break;
      }
      case TAG_Cons: {
        V v_x_24212 = heff_field(v_x2_24211, 0);
        V v_xs_24213 = heff_field(v_x2_24211, 1);
        heff_take_n(v_x2_24211, 3ULL, 2);
        v_t_24214 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str154); V a_1 = v_x_24212; V a_2 = v_xs_24213; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24213); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24211);
      }
      V v_t_24215 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str155), v_t_24214), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str156));
      V v_t_24216 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24215, NTAG(TAG_Nil)});
      V v_parts_24217 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_Cons, 2, (V[]){v_t_24210, v_t_24216});
      V v_x2_24218 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str157), v_parts_24217));
      V v_t_24221;
      switch (heff_tag_of(v_x2_24218)) {
      case TAG_Nil: {
        v_t_24221 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str158);
        break;
      }
      case TAG_Cons: {
        V v_x_24219 = heff_field(v_x2_24218, 0);
        V v_xs_24220 = heff_field(v_x2_24218, 1);
        heff_take_n(v_x2_24218, 3ULL, 2);
        v_t_24221 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str159); V a_1 = v_x_24219; V a_2 = v_xs_24220; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24220); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24218);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str160), v_t_24221), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str161));
    }
    case TAG_ELetIn: {
      V v_rhs_24222 = heff_field(v_x21_242, 0);
      V v_x212_24223 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x212_24223)) {
      case TAG_At: {
        V v_x2121_24224 = heff_field(v_x212_24223, 0);
        V v_ru_24x212_24223_24At = heff_take_reuse_n(v_x212_24223, 1ULL, 2);
        switch (heff_tag_of(v_x2121_24224)) {
        case TAG_MkAlt: {
          V v_p_24226 = heff_field(v_x2121_24224, 0);
          V v_e_24227 = heff_field(v_x2121_24224, 1);
          heff_take_n(v_x2121_24224, 3ULL, 2);
          V v_t_24228 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24222}));
          V v_t_24229 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24226));
          V v_t_24230 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24227}));
          V v_t_24231 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24230, NTAG(TAG_Nil)});
          V v_parts_24232 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_Cons, 2, (V[]){v_t_24228, heff_tag_at_n(v_ru_24x212_24223_24At, TAG_Cons, 2, (V[]){v_t_24229, v_t_24231})});
          V v_x2_24233 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str162), v_parts_24232));
          V v_t_24236;
          switch (heff_tag_of(v_x2_24233)) {
          case TAG_Nil: {
            v_t_24236 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str163);
            break;
          }
          case TAG_Cons: {
            V v_x_24234 = heff_field(v_x2_24233, 0);
            V v_xs_24235 = heff_field(v_x2_24233, 1);
            heff_take_n(v_x2_24233, 3ULL, 2);
            v_t_24236 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str164); V a_1 = v_x_24234; V a_2 = v_xs_24235; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24235); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24233);
          }
          return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str165), v_t_24236), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str166));
        }
        default: return heff_nomatch(v_x2121_24224);
        }
      }
      default: return heff_nomatch(v_x212_24223);
      }
    }
    case TAG_EDo: {
      V v_stmts_24237 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24238 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24239 = (g_list_2emap(v_t_24238, v_stmts_24237));
      V v_t_24242;
      switch (heff_tag_of(v_x2_24239)) {
      case TAG_Nil: {
        v_t_24242 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str167);
        break;
      }
      case TAG_Cons: {
        V v_x_24240 = heff_field(v_x2_24239, 0);
        V v_xs_24241 = heff_field(v_x2_24239, 1);
        heff_take_n(v_x2_24239, 3ULL, 2);
        v_t_24242 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str168); V a_1 = v_x_24240; V a_2 = v_xs_24241; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24241); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24239);
      }
      V v_t_24243 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str169), v_t_24242), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str170));
      V v_parts_24244 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24243, NTAG(TAG_Nil)});
      V v_x2_24245 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str171), v_parts_24244));
      V v_t_24248;
      switch (heff_tag_of(v_x2_24245)) {
      case TAG_Nil: {
        v_t_24248 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str172);
        break;
      }
      case TAG_Cons: {
        V v_x_24246 = heff_field(v_x2_24245, 0);
        V v_xs_24247 = heff_field(v_x2_24245, 1);
        heff_take_n(v_x2_24245, 3ULL, 2);
        v_t_24248 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str173); V a_1 = v_x_24246; V a_2 = v_xs_24247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24247); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24245);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str174), v_t_24248), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str175));
    }
    case TAG_ELocal: {
      V v_body_24249 = heff_field(v_x21_242, 0);
      V v_ds_24250 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24251 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24249}));
      V v_x2_24252 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24250));
      V v_t_24255;
      switch (heff_tag_of(v_x2_24252)) {
      case TAG_Nil: {
        v_t_24255 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str176);
        break;
      }
      case TAG_Cons: {
        V v_x_24253 = heff_field(v_x2_24252, 0);
        V v_xs_24254 = heff_field(v_x2_24252, 1);
        heff_take_n(v_x2_24252, 3ULL, 2);
        v_t_24255 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str177); V a_1 = v_x_24253; V a_2 = v_xs_24254; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24254); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24252);
      }
      V v_t_24256 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str178), v_t_24255), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str179));
      V v_t_24257 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24256, NTAG(TAG_Nil)});
      V v_parts_24258 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_Cons, 2, (V[]){v_t_24251, v_t_24257});
      V v_x2_24259 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str180), v_parts_24258));
      V v_t_24262;
      switch (heff_tag_of(v_x2_24259)) {
      case TAG_Nil: {
        v_t_24262 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str181);
        break;
      }
      case TAG_Cons: {
        V v_x_24260 = heff_field(v_x2_24259, 0);
        V v_xs_24261 = heff_field(v_x2_24259, 1);
        heff_take_n(v_x2_24259, 3ULL, 2);
        v_t_24262 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str182); V a_1 = v_x_24260; V a_2 = v_xs_24261; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24261); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24259);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str183), v_t_24262), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str184));
    }
    case TAG_EInvalid: {
      V v_why_24263 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24264 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_why_24263, NTAG(TAG_Nil)});
      V v_x2_24265 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str185), v_t_24264));
      V v_t_24268;
      switch (heff_tag_of(v_x2_24265)) {
      case TAG_Nil: {
        v_t_24268 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str186);
        break;
      }
      case TAG_Cons: {
        V v_x_24266 = heff_field(v_x2_24265, 0);
        V v_xs_24267 = heff_field(v_x2_24265, 1);
        heff_take_n(v_x2_24265, 3ULL, 2);
        v_t_24268 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str187); V a_1 = v_x_24266; V a_2 = v_xs_24267; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24267); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24265);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str188), v_t_24268), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str189));
    }
    case TAG_EAssign: {
      V v_x_24269 = heff_field(v_x21_242, 0);
      V v_e_24271 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_24272 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24271}));
      V v_t_24273 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24272, NTAG(TAG_Nil)});
      V v_parts_24274 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24269, v_t_24273});
      V v_x2_24275 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str190), v_parts_24274));
      V v_t_24278;
      switch (heff_tag_of(v_x2_24275)) {
      case TAG_Nil: {
        v_t_24278 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str191);
        break;
      }
      case TAG_Cons: {
        V v_x_24276 = heff_field(v_x2_24275, 0);
        V v_xs_24277 = heff_field(v_x2_24275, 1);
        heff_take_n(v_x2_24275, 3ULL, 2);
        v_t_24278 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str192); V a_1 = v_x_24276; V a_2 = v_xs_24277; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24277); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24275);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str193), v_t_24278), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str194));
    }
    case TAG_EWhile: {
      V v_c_24279 = heff_field(v_x21_242, 0);
      V v_body_24280 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EWhile = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24281 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24279}));
      V v_t_24282 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24283 = (g_list_2emap(v_t_24282, v_body_24280));
      V v_t_24286;
      switch (heff_tag_of(v_x2_24283)) {
      case TAG_Nil: {
        v_t_24286 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str195);
        break;
      }
      case TAG_Cons: {
        V v_x_24284 = heff_field(v_x2_24283, 0);
        V v_xs_24285 = heff_field(v_x2_24283, 1);
        heff_take_n(v_x2_24283, 3ULL, 2);
        v_t_24286 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str196); V a_1 = v_x_24284; V a_2 = v_xs_24285; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24285); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24283);
      }
      V v_t_24287 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str197), v_t_24286), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str198));
      V v_t_24288 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24287, NTAG(TAG_Nil)});
      V v_parts_24289 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_Cons, 2, (V[]){v_t_24281, v_t_24288});
      V v_x2_24290 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str199), v_parts_24289));
      V v_t_24293;
      switch (heff_tag_of(v_x2_24290)) {
      case TAG_Nil: {
        v_t_24293 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str200);
        break;
      }
      case TAG_Cons: {
        V v_x_24291 = heff_field(v_x2_24290, 0);
        V v_xs_24292 = heff_field(v_x2_24290, 1);
        heff_take_n(v_x2_24290, 3ULL, 2);
        v_t_24293 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str201); V a_1 = v_x_24291; V a_2 = v_xs_24292; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24292); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24290);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str202), v_t_24293), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str203));
    }
    case TAG_EFor: {
      V v_p_24294 = heff_field(v_x21_242, 0);
      V v_c_24295 = heff_field(v_x21_242, 1);
      V v_body_24296 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_24297 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24294));
      V v_t_24298 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24295}));
      V v_t_24299 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24300 = (g_list_2emap(v_t_24299, v_body_24296));
      V v_t_24303;
      switch (heff_tag_of(v_x2_24300)) {
      case TAG_Nil: {
        v_t_24303 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str204);
        break;
      }
      case TAG_Cons: {
        V v_x_24301 = heff_field(v_x2_24300, 0);
        V v_xs_24302 = heff_field(v_x2_24300, 1);
        heff_take_n(v_x2_24300, 3ULL, 2);
        v_t_24303 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str205); V a_1 = v_x_24301; V a_2 = v_xs_24302; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24302); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24300);
      }
      V v_t_24304 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str206), v_t_24303), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str207));
      V v_t_24305 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24304, NTAG(TAG_Nil)});
      V v_parts_24306 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24297, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24298, v_t_24305})});
      V v_x2_24307 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str208), v_parts_24306));
      V v_t_24310;
      switch (heff_tag_of(v_x2_24307)) {
      case TAG_Nil: {
        v_t_24310 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str209);
        break;
      }
      case TAG_Cons: {
        V v_x_24308 = heff_field(v_x2_24307, 0);
        V v_xs_24309 = heff_field(v_x2_24307, 1);
        heff_take_n(v_x2_24307, 3ULL, 2);
        v_t_24310 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str210); V a_1 = v_x_24308; V a_2 = v_xs_24309; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24309); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24307);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str211), v_t_24310), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str212));
    }
    case TAG_EIfThen: {
      V v_c_24311 = heff_field(v_x21_242, 0);
      V v_a_24312 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EIfThen = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24313 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24311}));
      V v_t_24314 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_24312}));
      V v_t_24315 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24314, NTAG(TAG_Nil)});
      V v_parts_24316 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_Cons, 2, (V[]){v_t_24313, v_t_24315});
      V v_x2_24317 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str213), v_parts_24316));
      V v_t_24320;
      switch (heff_tag_of(v_x2_24317)) {
      case TAG_Nil: {
        v_t_24320 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str214);
        break;
      }
      case TAG_Cons: {
        V v_x_24318 = heff_field(v_x2_24317, 0);
        V v_xs_24319 = heff_field(v_x2_24317, 1);
        heff_take_n(v_x2_24317, 3ULL, 2);
        v_t_24320 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str215); V a_1 = v_x_24318; V a_2 = v_xs_24319; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24319); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24317);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str216), v_t_24320), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str217));
    }
    case TAG_EBreak: {
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_x2_24321 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str218), NTAG(TAG_Nil)));
      V v_t_24324;
      switch (heff_tag_of(v_x2_24321)) {
      case TAG_Nil: {
        v_t_24324 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str219);
        break;
      }
      case TAG_Cons: {
        V v_x_24322 = heff_field(v_x2_24321, 0);
        V v_xs_24323 = heff_field(v_x2_24321, 1);
        heff_take_n(v_x2_24321, 3ULL, 2);
        v_t_24324 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str220); V a_1 = v_x_24322; V a_2 = v_xs_24323; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24323); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24321);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str221), v_t_24324), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str222));
    }
    case TAG_EContinue: {
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_x2_24325 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str223), NTAG(TAG_Nil)));
      V v_t_24328;
      switch (heff_tag_of(v_x2_24325)) {
      case TAG_Nil: {
        v_t_24328 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str224);
        break;
      }
      case TAG_Cons: {
        V v_x_24326 = heff_field(v_x2_24325, 0);
        V v_xs_24327 = heff_field(v_x2_24325, 1);
        heff_take_n(v_x2_24325, 3ULL, 2);
        v_t_24328 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str225); V a_1 = v_x_24326; V a_2 = v_xs_24327; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24327); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24325);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str226), v_t_24328), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str227));
    }
    case TAG_EReturn: {
      V v_e_24329 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24330 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24329}));
      V v_parts_24331 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24330, NTAG(TAG_Nil)});
      V v_x2_24332 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str228), v_parts_24331));
      V v_t_24335;
      switch (heff_tag_of(v_x2_24332)) {
      case TAG_Nil: {
        v_t_24335 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str229);
        break;
      }
      case TAG_Cons: {
        V v_x_24333 = heff_field(v_x2_24332, 0);
        V v_xs_24334 = heff_field(v_x2_24332, 1);
        heff_take_n(v_x2_24332, 3ULL, 2);
        v_t_24335 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str230); V a_1 = v_x_24333; V a_2 = v_xs_24334; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24334); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24332);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str231), v_t_24335), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str232));
    }
    case TAG_ENest: {
      V v_e_24336 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24337 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24336}));
      V v_parts_24338 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24337, NTAG(TAG_Nil)});
      V v_x2_24339 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str233), v_parts_24338));
      V v_t_24342;
      switch (heff_tag_of(v_x2_24339)) {
      case TAG_Nil: {
        v_t_24342 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str234);
        break;
      }
      case TAG_Cons: {
        V v_x_24340 = heff_field(v_x2_24339, 0);
        V v_xs_24341 = heff_field(v_x2_24339, 1);
        heff_take_n(v_x2_24339, 3ULL, 2);
        v_t_24342 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str235); V a_1 = v_x_24340; V a_2 = v_xs_24341; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24341); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24339);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str236), v_t_24342), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str237));
    }
    case TAG_ELazy: {
      V v_e_24343 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24344 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24343}));
      V v_parts_24345 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24344, NTAG(TAG_Nil)});
      V v_x2_24346 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str238), v_parts_24345));
      V v_t_24349;
      switch (heff_tag_of(v_x2_24346)) {
      case TAG_Nil: {
        v_t_24349 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str239);
        break;
      }
      case TAG_Cons: {
        V v_x_24347 = heff_field(v_x2_24346, 0);
        V v_xs_24348 = heff_field(v_x2_24346, 1);
        heff_take_n(v_x2_24346, 3ULL, 2);
        v_t_24349 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str240); V a_1 = v_x_24347; V a_2 = v_xs_24348; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24348); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24346);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str241), v_t_24349), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str242));
    }
    case TAG_ETuple: {
      V v_es_24350 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24351 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_es_24350));
      V v_t_24354;
      switch (heff_tag_of(v_x2_24351)) {
      case TAG_Nil: {
        v_t_24354 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str243);
        break;
      }
      case TAG_Cons: {
        V v_x_24352 = heff_field(v_x2_24351, 0);
        V v_xs_24353 = heff_field(v_x2_24351, 1);
        heff_take_n(v_x2_24351, 3ULL, 2);
        v_t_24354 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str244); V a_1 = v_x_24352; V a_2 = v_xs_24353; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24353); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24351);
      }
      V v_t_24355 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str245), v_t_24354), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str246));
      V v_parts_24356 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24355, NTAG(TAG_Nil)});
      V v_x2_24357 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str247), v_parts_24356));
      V v_t_24360;
      switch (heff_tag_of(v_x2_24357)) {
      case TAG_Nil: {
        v_t_24360 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str248);
        break;
      }
      case TAG_Cons: {
        V v_x_24358 = heff_field(v_x2_24357, 0);
        V v_xs_24359 = heff_field(v_x2_24357, 1);
        heff_take_n(v_x2_24357, 3ULL, 2);
        v_t_24360 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str249); V a_1 = v_x_24358; V a_2 = v_xs_24359; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24359); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24357);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str250), v_t_24360), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str251));
    }
    case TAG_ETry: {
      V v_x211_24361 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x211_24361)) {
      case TAG_MkTry: {
        V v_ty_24362 = heff_field(v_x211_24361, 0);
        V v_body_24363 = heff_field(v_x211_24361, 1);
        V v_c_24364 = heff_field(v_x211_24361, 2);
        heff_take_n(v_x211_24361, 7ULL, 3);
        V v_t_24366;
        switch (heff_tag_of(v_ty_24362)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_24366 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_24365 = heff_field(v_ty_24362, 0);
          heff_take_n(v_ty_24362, 1ULL, 1);
          v_t_24366 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_24365, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_ty_24362);
        }
        V v_x2_24367 = (g_list_2emap(heff_dup(heff_rfield(v_r_240, 0)), v_t_24366));
        V v_t_24370;
        switch (heff_tag_of(v_x2_24367)) {
        case TAG_Nil: {
          v_t_24370 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str252);
          break;
        }
        case TAG_Cons: {
          V v_x_24368 = heff_field(v_x2_24367, 0);
          V v_xs_24369 = heff_field(v_x2_24367, 1);
          heff_take_n(v_x2_24367, 3ULL, 2);
          v_t_24370 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str253); V a_1 = v_x_24368; V a_2 = v_xs_24369; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24369); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24367);
        }
        V v_t_24371 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){heff_dup(v_r_240)}));
        V v_x2_24372 = (g_list_2emap(v_t_24371, v_body_24363));
        V v_t_24375;
        switch (heff_tag_of(v_x2_24372)) {
        case TAG_Nil: {
          v_t_24375 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str254);
          break;
        }
        case TAG_Cons: {
          V v_x_24373 = heff_field(v_x2_24372, 0);
          V v_xs_24374 = heff_field(v_x2_24372, 1);
          heff_take_n(v_x2_24372, 3ULL, 2);
          v_t_24375 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str255); V a_1 = v_x_24373; V a_2 = v_xs_24374; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24374); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24372);
        }
        V v_r_24376 = v_r_240;
        V v_x2_24377 = v_c_24364;
        V v_t_24393;
        switch (heff_tag_of(v_x2_24377)) {
        case TAG_MkCatchArm: {
          V v_b_24378 = heff_field(v_x2_24377, 0);
          V v_ss_24379 = heff_field(v_x2_24377, 1);
          V v_ru_24x2_24377_24MkCatchArm = heff_take_reuse_n(v_x2_24377, 3ULL, 2);
          V v_t_24380 = ({ V a_0 = heff_dup(v_r_24376); V a_1 = v_b_24378; V r_ = (g_heff_2esyntax_2eformat_2elamKey(a_0, a_1)); heff_drop(v_b_24378); r_; });
          V v_t_24381 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_24376}));
          V v_x2_24382 = (g_list_2emap(v_t_24381, v_ss_24379));
          V v_t_24385;
          switch (heff_tag_of(v_x2_24382)) {
          case TAG_Nil: {
            v_t_24385 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str256);
            break;
          }
          case TAG_Cons: {
            V v_x_24383 = heff_field(v_x2_24382, 0);
            V v_xs_24384 = heff_field(v_x2_24382, 1);
            heff_take_n(v_x2_24382, 3ULL, 2);
            v_t_24385 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str257); V a_1 = v_x_24383; V a_2 = v_xs_24384; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24384); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24382);
          }
          V v_t_24386 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str258), v_t_24385), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str259));
          V v_t_24387 = heff_tag_at_n(v_ru_24x2_24377_24MkCatchArm, TAG_Cons, 2, (V[]){v_t_24386, NTAG(TAG_Nil)});
          V v_parts_24388 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24380, v_t_24387});
          V v_x2_24389 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str260), v_parts_24388));
          V v_t_24392;
          switch (heff_tag_of(v_x2_24389)) {
          case TAG_Nil: {
            v_t_24392 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str261);
            break;
          }
          case TAG_Cons: {
            V v_x_24390 = heff_field(v_x2_24389, 0);
            V v_xs_24391 = heff_field(v_x2_24389, 1);
            heff_take_n(v_x2_24389, 3ULL, 2);
            v_t_24392 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str262); V a_1 = v_x_24390; V a_2 = v_xs_24391; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24391); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24389);
          }
          v_t_24393 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str263), v_t_24392), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str264));
          break;
        }
        default: heff_nomatch(v_x2_24377);
        }
        V v_t_24394 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str265), v_t_24370), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str266));
        V v_t_24395 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str267), v_t_24375), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str268));
        V v_t_24396 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24393, NTAG(TAG_Nil)});
        V v_parts_24397 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24394, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24395, v_t_24396})});
        V v_x2_24398 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str269), v_parts_24397));
        V v_t_24401;
        switch (heff_tag_of(v_x2_24398)) {
        case TAG_Nil: {
          v_t_24401 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str270);
          break;
        }
        case TAG_Cons: {
          V v_x_24399 = heff_field(v_x2_24398, 0);
          V v_xs_24400 = heff_field(v_x2_24398, 1);
          heff_take_n(v_x2_24398, 3ULL, 2);
          v_t_24401 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str271); V a_1 = v_x_24399; V a_2 = v_xs_24400; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24400); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24398);
        }
        return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str272), v_t_24401), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str273));
      }
      default: return heff_nomatch(v_x211_24361);
      }
    }
    case TAG_EWith: {
      V v_w_24402 = heff_field(v_x21_242, 0);
      V v_x_24403 = heff_field(v_x21_242, 1);
      V v_body_24405 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      V v_t_24406 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_w_24402}));
      V v_t_24407 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24408 = (g_list_2emap(v_t_24407, v_body_24405));
      V v_t_24411;
      switch (heff_tag_of(v_x2_24408)) {
      case TAG_Nil: {
        v_t_24411 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str274);
        break;
      }
      case TAG_Cons: {
        V v_x_24409 = heff_field(v_x2_24408, 0);
        V v_xs_24410 = heff_field(v_x2_24408, 1);
        heff_take_n(v_x2_24408, 3ULL, 2);
        v_t_24411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str275); V a_1 = v_x_24409; V a_2 = v_xs_24410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24408);
      }
      V v_t_24412 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str276), v_t_24411), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str277));
      V v_t_24413 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24412, NTAG(TAG_Nil)});
      V v_parts_24414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24406, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24403, v_t_24413})});
      V v_x2_24415 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str278), v_parts_24414));
      V v_t_24418;
      switch (heff_tag_of(v_x2_24415)) {
      case TAG_Nil: {
        v_t_24418 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str279);
        break;
      }
      case TAG_Cons: {
        V v_x_24416 = heff_field(v_x2_24415, 0);
        V v_xs_24417 = heff_field(v_x2_24415, 1);
        heff_take_n(v_x2_24415, 3ULL, 2);
        v_t_24418 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str280); V a_1 = v_x_24416; V a_2 = v_xs_24417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24417); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24415);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str281), v_t_24418), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str282));
    }
    case TAG_EWithBound: {
      V v_bs_24419 = heff_field(v_x21_242, 0);
      V v_w_24420 = heff_field(v_x21_242, 1);
      V v_body_24421 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_x2_24435 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam1, 1, 1, (V[]){heff_dup(v_r_240)}), v_bs_24419));
      V v_t_24438;
      switch (heff_tag_of(v_x2_24435)) {
      case TAG_Nil: {
        v_t_24438 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str288);
        break;
      }
      case TAG_Cons: {
        V v_x_24436 = heff_field(v_x2_24435, 0);
        V v_xs_24437 = heff_field(v_x2_24435, 1);
        heff_take_n(v_x2_24435, 3ULL, 2);
        v_t_24438 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str289); V a_1 = v_x_24436; V a_2 = v_xs_24437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24437); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24435);
      }
      V v_t_24440;
      switch (heff_tag_of(v_w_24420)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_24439 = heff_field(v_w_24420, 0);
        heff_take_n(v_w_24420, 1ULL, 1);
        v_t_24440 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_24439, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_w_24420);
      }
      V v_x2_24441 = (g_list_2emap(heff_dup(heff_rfield(v_r_240, 0)), v_t_24440));
      V v_t_24444;
      switch (heff_tag_of(v_x2_24441)) {
      case TAG_Nil: {
        v_t_24444 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str290);
        break;
      }
      case TAG_Cons: {
        V v_x_24442 = heff_field(v_x2_24441, 0);
        V v_xs_24443 = heff_field(v_x2_24441, 1);
        heff_take_n(v_x2_24441, 3ULL, 2);
        v_t_24444 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str291); V a_1 = v_x_24442; V a_2 = v_xs_24443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24443); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24441);
      }
      V v_t_24445 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24446 = (g_list_2emap(v_t_24445, v_body_24421));
      V v_t_24449;
      switch (heff_tag_of(v_x2_24446)) {
      case TAG_Nil: {
        v_t_24449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str292);
        break;
      }
      case TAG_Cons: {
        V v_x_24447 = heff_field(v_x2_24446, 0);
        V v_xs_24448 = heff_field(v_x2_24446, 1);
        heff_take_n(v_x2_24446, 3ULL, 2);
        v_t_24449 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str293); V a_1 = v_x_24447; V a_2 = v_xs_24448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24448); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24446);
      }
      V v_t_24450 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str294), v_t_24438), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str295));
      V v_t_24451 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str296), v_t_24444), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str297));
      V v_t_24452 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str298), v_t_24449), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str299));
      V v_t_24453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24452, NTAG(TAG_Nil)});
      V v_parts_24454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24450, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24451, v_t_24453})});
      V v_x2_24455 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str300), v_parts_24454));
      V v_t_24458;
      switch (heff_tag_of(v_x2_24455)) {
      case TAG_Nil: {
        v_t_24458 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str301);
        break;
      }
      case TAG_Cons: {
        V v_x_24456 = heff_field(v_x2_24455, 0);
        V v_xs_24457 = heff_field(v_x2_24455, 1);
        heff_take_n(v_x2_24455, 3ULL, 2);
        v_t_24458 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str302); V a_1 = v_x_24456; V a_2 = v_xs_24457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24457); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24455);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str303), v_t_24458), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str304));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyTermF(a[0], a[1]);
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam0(V self, V *args) {
  V v_m_2439 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_f_2440 = heff_get_n(v_r_240, 0, 2);
  V v_x2_2441 = v_m_2439;
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_At: {
    V v_x21_2442 = heff_field(v_x2_2441, 0);
    V v_ru_24x2_2441_24At = heff_take_reuse_n(v_x2_2441, 1ULL, 2);
    switch (heff_tag_of(v_x21_2442)) {
    case TAG_MkSegment: {
      V v_v_2444 = heff_field(v_x21_2442, 0);
      V v_ty_2445 = heff_field(v_x21_2442, 1);
      V v_size_2446 = heff_field(v_x21_2442, 2);
      V v_little_2447 = heff_field(v_x21_2442, 3);
      V v_signed_2448 = heff_field(v_x21_2442, 4);
      heff_take_n(v_x21_2442, 31ULL, 5);
      V v_t_2449 = heff_tr(heff_call(v_f_2440, 1, (V[]){v_v_2444}));
      V v_t_2451;
      switch (heff_tag_of(v_ty_2445)) {
      case TAG_SegmentInteger: {
        v_t_2451 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str27);
        break;
      }
      case TAG_SegmentBinary: {
        v_t_2451 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str28);
        break;
      }
      case TAG_SegmentBits: {
        v_t_2451 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str29);
        break;
      }
      case TAG_SegmentFloat: {
        v_t_2451 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str30);
        break;
      }
      case TAG_SegmentUtf: {
        V v_n_2450 = heff_field(v_ty_2445, 0);
        heff_take_n(v_ty_2445, 1ULL, 1);
        v_t_2451 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str31), heff_intShow(v_n_2450));
        break;
      }
      default: heff_nomatch(v_ty_2445);
      }
      V v_t_2456;
      switch (heff_tag_of(v_size_2446)) {
      case TAG_SizeDefault: {
        v_t_2456 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str32);
        break;
      }
      case TAG_SizeNumber: {
        V v_n_2452 = heff_field(v_size_2446, 0);
        heff_take_n(v_size_2446, 1ULL, 1);
        v_t_2456 = heff_intShow(v_n_2452);
        break;
      }
      case TAG_SizeName: {
        V v_x_2453 = heff_field(v_size_2446, 0);
        V v_unit_2455 = heff_field(v_size_2446, 2);
        heff_take_n(v_size_2446, 5ULL, 3);
        v_t_2456 = heff_strAppend(heff_strAppend(v_x_2453, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str33)), heff_intShow(v_unit_2455));
        break;
      }
      default: heff_nomatch(v_size_2446);
      }
      V v_t_2457;
      if ((heff_dup(v_little_2447) == NTAG(TAG_True))) {
        heff_drop(v_little_2447);
        v_t_2457 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str34);
      } else {
        heff_drop(v_little_2447);
        v_t_2457 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str35);
      }
      V v_t_2458;
      if ((heff_dup(v_signed_2448) == NTAG(TAG_True))) {
        heff_drop(v_signed_2448);
        v_t_2458 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str36);
      } else {
        heff_drop(v_signed_2448);
        v_t_2458 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str37);
      }
      V v_t_2459 = heff_tag_at_n(v_ru_24x2_2441_24At, TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
      V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_t_2459})});
      V v_parts_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2460})});
      V v_x2_2462 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str38), v_parts_2461));
      V v_t_2465;
      switch (heff_tag_of(v_x2_2462)) {
      case TAG_Nil: {
        v_t_2465 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str39);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_field(v_x2_2462, 0);
        V v_xs_2464 = heff_field(v_x2_2462, 1);
        heff_take_n(v_x2_2462, 3ULL, 2);
        v_t_2465 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str40); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2462);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str41), v_t_2465), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str42));
    }
    default: return heff_nomatch(v_x21_2442);
    }
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam1(V self, V *args) {
  V v_b_24422 = args[0];
  V v_r_240 = heff_env(self)[0];
  switch (heff_tag_of(v_b_24422)) {
  case TAG_At: {
    V v_it1_24423 = heff_field(v_b_24422, 0);
    V v_ru_24b_24422_24At = heff_take_reuse_n(v_b_24422, 1ULL, 2);
    switch (heff_tag_of(v_it1_24423)) {
    case TAG_MkBinding: {
      V v_p_24425 = heff_field(v_it1_24423, 0);
      V v_m_24426 = heff_field(v_it1_24423, 1);
      V v_ru_24it1_24423_24MkBinding = heff_take_reuse_n(v_it1_24423, 3ULL, 2);
      V v_t_24427 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24425));
      heff_clo_take(self, 1);
      V v_t_24428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_m_24426}));
      V v_t_24429 = heff_tag_at_n(v_ru_24b_24422_24At, TAG_Cons, 2, (V[]){v_t_24428, NTAG(TAG_Nil)});
      V v_parts_24430 = heff_tag_at_n(v_ru_24it1_24423_24MkBinding, TAG_Cons, 2, (V[]){v_t_24427, v_t_24429});
      V v_x2_24431 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str283), v_parts_24430));
      V v_t_24434;
      switch (heff_tag_of(v_x2_24431)) {
      case TAG_Nil: {
        v_t_24434 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str284);
        break;
      }
      case TAG_Cons: {
        V v_x_24432 = heff_field(v_x2_24431, 0);
        V v_xs_24433 = heff_field(v_x2_24431, 1);
        heff_take_n(v_x2_24431, 3ULL, 2);
        v_t_24434 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str285); V a_1 = v_x_24432; V a_2 = v_xs_24433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24433); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24431);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str286), v_t_24434), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str287));
    }
    default: return heff_nomatch(v_it1_24423);
    }
  }
  default: return heff_nomatch(v_b_24422);
  }
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str0, 10, "definition");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str3, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str4, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str5, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str9, 10, "(equations");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str12, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str13, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str14, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str18, 7, "(define");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str21, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str22, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str23, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str27, 7, "(theory");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str28, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str30, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str31, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str32, 10, "(primitive");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str33, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str34, 5, "(test");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str38, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str40, 6, "(watch");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str41, 1, ")");
Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyDeclF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_t_249;
      switch (heff_tag_of(v_declared_246)) {
      case TAG_AsDefinition: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str0);
        break;
      }
      case TAG_AsInstance: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str1);
        break;
      }
      default: heff_nomatch(v_declared_246);
      }
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_x2_2411 = (g_list_2emap_24s1055307687x247454614(v_r_240, v_eqs_248));
      V v_t_2414;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_xs_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str4), v_t_2414), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str5));
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2416})});
      V v_parts_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_244, v_t_2417});
      V v_x2_2419 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str6), v_parts_2418));
      V v_t_2422;
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Nil: {
        v_t_2422 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_xs_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        v_t_2422 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str8); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2419);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str9), v_t_2422), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str10));
    }
    case TAG_DeclDefine: {
      V v_x_2423 = heff_field(v_x21_242, 0);
      V v_ps_2425 = heff_field(v_x21_242, 2);
      V v_u_2426 = heff_field(v_x21_242, 3);
      V v_body_2427 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_x2_2428 = (g_list_2emap_24s228910449x1110031924(heff_dup(v_r_240), v_ps_2425));
      V v_t_2431;
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_Nil: {
        v_t_2431 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2429 = heff_field(v_x2_2428, 0);
        V v_xs_2430 = heff_field(v_x2_2428, 1);
        heff_take_n(v_x2_2428, 3ULL, 2);
        v_t_2431 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str12); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2428);
      }
      V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2426}));
      V v_t_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2427}));
      V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str13), v_t_2431), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str14));
      V v_t_2435 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2435})});
      V v_parts_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2423, v_t_2436});
      V v_x2_2438 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str15), v_parts_2437));
      V v_t_2441;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nil: {
        v_t_2441 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        V v_xs_2440 = heff_field(v_x2_2438, 1);
        heff_take_n(v_x2_2438, 3ULL, 2);
        v_t_2441 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str17); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str18), v_t_2441), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str19));
    }
    case TAG_DeclTheory: {
      V v_x_2442 = heff_field(v_x21_242, 0);
      V v_ps_2444 = heff_field(v_x21_242, 2);
      V v_body_2445 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_x2_2446 = (g_list_2emap_24s228910449x1110031924(heff_dup(v_r_240), v_ps_2444));
      V v_t_2449;
      switch (heff_tag_of(v_x2_2446)) {
      case TAG_Nil: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_2447 = heff_field(v_x2_2446, 0);
        V v_xs_2448 = heff_field(v_x2_2446, 1);
        heff_take_n(v_x2_2446, 3ULL, 2);
        v_t_2449 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str21); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2446);
      }
      V v_t_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2445}));
      V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str22), v_t_2449), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str23));
      V v_t_2452 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
      V v_parts_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2442, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2452})});
      V v_x2_2454 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str24), v_parts_2453));
      V v_t_2457;
      switch (heff_tag_of(v_x2_2454)) {
      case TAG_Nil: {
        v_t_2457 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str25);
        break;
      }
      case TAG_Cons: {
        V v_x_2455 = heff_field(v_x2_2454, 0);
        V v_xs_2456 = heff_field(v_x2_2454, 1);
        heff_take_n(v_x2_2454, 3ULL, 2);
        v_t_2457 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str26); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2454);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str27), v_t_2457), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str28));
    }
    case TAG_DeclPrimitive: {
      V v_x_2458 = heff_field(v_x21_242, 0);
      V v_t_2460 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
      V v_t_2462 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
      V v_parts_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2458, v_t_2462});
      V v_x2_2464 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str29), v_parts_2463));
      V v_t_2467;
      switch (heff_tag_of(v_x2_2464)) {
      case TAG_Nil: {
        v_t_2467 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str30);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x2_2464, 0);
        V v_xs_2466 = heff_field(v_x2_2464, 1);
        heff_take_n(v_x2_2464, 3ULL, 2);
        v_t_2467 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str31); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2464);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str32), v_t_2467), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str33));
    }
    case TAG_DeclTest: {
      V v_x_2468 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2470 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str34), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str35), v_x_2468));
      return heff_strAppend(v_t_2470, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str36));
    }
    case TAG_DeclWatch: {
      V v_e_2471 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2471}));
      V v_parts_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
      V v_x2_2474 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str37), v_parts_2473));
      V v_t_2477;
      switch (heff_tag_of(v_x2_2474)) {
      case TAG_Nil: {
        v_t_2477 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str38);
        break;
      }
      case TAG_Cons: {
        V v_x_2475 = heff_field(v_x2_2474, 0);
        V v_xs_2476 = heff_field(v_x2_2474, 1);
        heff_take_n(v_x2_2474, 3ULL, 2);
        v_t_2477 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str39); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2474);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str40), v_t_2477), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str41));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyDeclF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str3, 2, " (");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str5, 4, "(..)");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str7, 7, "module ");
Clo g_heff_2esyntax_2eformat_2emeaning_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2emeaning_entry, 1, 0};

V g_heff_2esyntax_2eformat_2emeaning(V v_s_240) {
top: ;
  V v_h_241 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_s_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_h_242 = heff_dup(v_h_241);
  V v_claim_243 = heff_take_field(v_h_242, 2);
  V v_imports_244 = heff_get_n(v_h_242, 0, 4);
  V v_text_245 = heff_get_n(v_h_241, 3, 4);
  V v_lit_246 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str0);
  V v_lit_247 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str1);
  V v_src_248 = heff_dup(v_text_245);
  V v_t_249 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_2410 = ({ V a_0 = v_text_245; V a_1 = v_t_249; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); HeffT3 r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_245); r_; });
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[2]);
    V v_ltoks_2414 = heff_arrayFromList(heff_dup(v_field_2411));
    V v_t_2415 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), v_field_2411));
    V v_toks_2416 = heff_arrayFromList(v_t_2415);
    V v_lexDiags_2417 = (g_list_2emap_24s338694954x1326523169(v_field_2412));
    V v_t_2418 = (g_heff_2esyntax_2esurface_2eprescanGo(v_ltoks_2414, MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nil)));
    V v_t_2419 = ({ V a_0 = v_ltoks_2414; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2efixDecls(a_0, a_1, a_2)); heff_drop(v_ltoks_2414); r_; });
    V v_t_2420 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(heff_dup(v_lit_246), v_t_2419));
    V v_t_2421 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){((V)&g_heff_2esyntax_2esurface_2enoKnown_clo), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), NTAG(TAG_True), v_lit_246, v_lit_247});
    HeffT5 v_t_2422 = (g_heff_2esyntax_2esurface_2ereadRun_24cpr(v_src_248, v_t_2421, v_toks_2416, v_lexDiags_2417, v_t_2418, v_t_2420));
    {
      V v_field_2423 = v_t_2422.f[0];
      V v_field_2424 = v_t_2422.f[1];
      heff_drop(v_t_2422.f[2]);
      heff_drop(v_t_2422.f[3]);
      heff_drop(v_t_2422.f[4]);
      V v_t_2428 = v_claim_243;
      V v_t_2440;
      switch (heff_tag_of(v_t_2428)) {
      case TAG_Nothing: {
        v_t_2440 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_h_2429 = heff_field(v_t_2428, 0);
        heff_take_n(v_t_2428, 1ULL, 1);
        V v_name_2430 = heff_take_field(v_h_2429, 0);
        V v_listed_2431 = heff_take_field(v_h_2429, 1);
        V v_exposes_2432 = heff_get_n(v_h_2429, 2, 5);
        V v_t_2433 = v_name_2430;
        V v_t_2435;
        switch (heff_tag_of(v_t_2433)) {
        case TAG_Nothing: {
          v_t_2435 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str2);
          break;
        }
        case TAG_Just: {
          V v_x_2434 = heff_field(v_t_2433, 0);
          heff_take_n(v_t_2433, 1ULL, 1);
          v_t_2435 = v_x_2434;
          break;
        }
        default: heff_nomatch(v_t_2433);
        }
        V v_t_2436 = v_listed_2431;
        V v_t_2437;
        if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
          heff_drop(v_t_2436);
          v_t_2437 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str3);
        } else {
          heff_drop(v_t_2436);
          v_t_2437 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str4);
        }
        V v_t_2438 = (g_list_2emap_24s900318151x1569363206(((V)&g_heff_2esyntax_2eformat_2emeaning_str5), ((V)&g_heff_2esyntax_2eformat_2emeaning_str6), v_exposes_2432));
        V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2emeaning_str7), v_t_2435), v_t_2437);
        v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_t_2438});
        break;
      }
      default: heff_nomatch(v_t_2428);
      }
      V v_t_2441 = (g_list_2emap_24s1817208647x1282894070(v_imports_244));
      V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2441));
      V v_t_2443 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2eformat_2ekeys_get(), 1)), v_field_2423));
      V v_t_2444 = (g_list_2emap_24s179832492x431904054(v_field_2424));
      return heff_rec_n(3, shape_imports__decls__diags, (V[]){v_t_2442, v_t_2443, v_t_2444});
    }
  }
}
V g_heff_2esyntax_2eformat_2emeaning_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2eformat_2emeaning(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str0, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str1, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str3, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str4, 2, " (");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str6, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str7, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str9, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str10, 2, " (");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str12, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str13, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str15, 5, "\012  , ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str16, 5, "\012  ( ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str17, 4, "\012  )");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str18, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str19, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str21, 6, "import");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str22, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str23, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str26, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str27, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str28, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str30, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str32, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str33, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V v_f_240, V v_src_241) {
top: ;
  V v_claim_242 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_241, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_f_243 = v_f_240;
  V v_src_244 = heff_dup(v_src_241);
  V v_claim_245 = heff_dup(v_claim_242);
  V v_claim_246 = heff_take_field(v_claim_245, 2);
  V v_imports_247 = heff_get_n(v_claim_245, 0, 4);
  V v_t_248 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_249 = ({ V b_0 = heff_get_n(v_claim_242, 3, 4); V a_1 = v_t_248; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); HeffT3 r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_t_2413 = v_field_2411;
    V v_t_24120;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      V v_src_2414 = v_src_244;
      V v_x1_2415 = v_claim_246;
      V v_t_2449;
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_Nothing: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_h_2416 = heff_field(v_x1_2415, 0);
        heff_take_n(v_x1_2415, 1ULL, 1);
        V v_error_2417 = heff_take_field(v_h_2416, 4);
        V v_name_2418 = heff_take_field(v_h_2416, 0);
        V v_listed_2419 = heff_take_field(v_h_2416, 1);
        V v_exposes_2420 = heff_take_field(v_h_2416, 2);
        V v_span_2421 = heff_get_n(v_h_2416, 3, 5);
        V v_t_2422 = v_error_2417;
        V v_t_2447;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          V v_name_2423 = v_name_2418;
          V v_x2_2424 = v_listed_2419;
          V v_es_2425 = (g_list_2emap_24s1975257801x764827799(v_exposes_2420));
          if ((heff_dup(v_x2_2424) == NTAG(TAG_True))) {
            heff_drop(v_x2_2424);
            V v_t_2427;
            switch (heff_tag_of(v_name_2423)) {
            case TAG_Nothing: {
              v_t_2427 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str0);
              break;
            }
            case TAG_Just: {
              V v_name_2426 = heff_dup(heff_field(v_name_2423, 0));
              v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str1), v_name_2426);
              break;
            }
            default: heff_nomatch(v_name_2423);
            }
            V v_t_2430;
            switch (heff_tag_of(v_es_2425)) {
            case TAG_Nil: {
              v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str2);
              break;
            }
            case TAG_Cons: {
              V v_x_2428 = heff_dup(heff_field(v_es_2425, 0));
              V v_xs_2429 = heff_dup(heff_field(v_es_2425, 1));
              v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str3); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
              break;
            }
            default: heff_nomatch(v_es_2425);
            }
            V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str4)), v_t_2430);
            V v_t_2432 = heff_strLength(heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str5)));
            if ((heff_unbox_word(v_t_2432) <= ((int64_t)80ULL))) {
              V v_t_2434;
              switch (heff_tag_of(v_name_2423)) {
              case TAG_Nothing: {
                v_t_2434 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str6);
                break;
              }
              case TAG_Just: {
                V v_name_2433 = heff_field(v_name_2423, 0);
                heff_take_n(v_name_2423, 1ULL, 1);
                v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str7), v_name_2433);
                break;
              }
              default: heff_nomatch(v_name_2423);
              }
              V v_t_2437;
              switch (heff_tag_of(v_es_2425)) {
              case TAG_Nil: {
                v_t_2437 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str8);
                break;
              }
              case TAG_Cons: {
                V v_x_2435 = heff_field(v_es_2425, 0);
                V v_xs_2436 = heff_field(v_es_2425, 1);
                heff_take_n(v_es_2425, 3ULL, 2);
                v_t_2437 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str9); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
                break;
              }
              default: heff_nomatch(v_es_2425);
              }
              V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str10)), v_t_2437);
              v_t_2447 = heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str11));
            } else {
              V v_t_2440;
              switch (heff_tag_of(v_name_2423)) {
              case TAG_Nothing: {
                v_t_2440 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str12);
                break;
              }
              case TAG_Just: {
                V v_name_2439 = heff_field(v_name_2423, 0);
                heff_take_n(v_name_2423, 1ULL, 1);
                v_t_2440 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str13), v_name_2439);
                break;
              }
              default: heff_nomatch(v_name_2423);
              }
              V v_t_2443;
              switch (heff_tag_of(v_es_2425)) {
              case TAG_Nil: {
                v_t_2443 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str14);
                break;
              }
              case TAG_Cons: {
                V v_x_2441 = heff_field(v_es_2425, 0);
                V v_xs_2442 = heff_field(v_es_2425, 1);
                heff_take_n(v_es_2425, 3ULL, 2);
                v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str15); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
                break;
              }
              default: heff_nomatch(v_es_2425);
              }
              V v_t_2444 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str16)), v_t_2443);
              v_t_2447 = heff_strAppend(v_t_2444, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str17));
            }
          } else {
            heff_drop(v_x2_2424);
            heff_drop(v_es_2425);
            switch (heff_tag_of(v_name_2423)) {
            case TAG_Nothing: {
              v_t_2447 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str18);
              break;
            }
            case TAG_Just: {
              V v_name_2445 = heff_field(v_name_2423, 0);
              heff_take_n(v_name_2423, 1ULL, 1);
              v_t_2447 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str19), v_name_2445);
              break;
            }
            default: heff_nomatch(v_name_2423);
            }
          }
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2422, 0ULL, 1);
          heff_drop(v_name_2418);
          heff_drop(v_listed_2419);
          heff_drop(v_exposes_2420);
          v_t_2447 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str20);
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        V v_t_2448 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str21), v_t_2447, heff_take_field(v_span_2421, 0), heff_get_n(v_span_2421, 1, 2), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
        v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_x1_2415);
      }
      V v_t_2450 = (g_list_2emap_24s1845612977x612508518(v_imports_247));
      V v_x2_2451 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_field_2410, v_t_2449, v_t_2450));
      V v_toks_2460;
      switch (heff_tag_of(v_x2_2451)) {
      case TAG_Nil: {
        v_toks_2460 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_x_2452 = heff_field(v_x2_2451, 0);
        V v_xs_2453 = heff_field(v_x2_2451, 1);
        V v_ru_24x2_2451_24Cons = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
        V v_t_2459;
        switch (heff_tag_of(v_xs_2453)) {
        case TAG_Nil: {
          V v_t_2454 = heff_tag_re_n(v_ru_24x2_2451_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2452, NTAG(TAG_Nil)});
          v_t_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          V v_y_2455 = heff_field(v_xs_2453, 0);
          V v_ys_2456 = heff_field(v_xs_2453, 1);
          V v_ru_24xs_2453_24Cons = heff_take_reuse_n(v_xs_2453, 3ULL, 2);
          if (heff_intLe_c(heff_dup(heff_rfield(v_x_2452, 2)), heff_dup(heff_rfield(v_y_2455, 2)))) {
            V v_t_2457 = heff_tag_re_n(v_ru_24x2_2451_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2452, NTAG(TAG_Nil)});
            v_t_2459 = (g_list_2eascending_24s946492440x1788863194(heff_dup(v_y_2455), heff_tag_re_n(v_ru_24xs_2453_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2455, v_t_2457}), v_ys_2456));
          } else {
            V v_t_2458 = heff_tag_re_n(v_ru_24x2_2451_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2452, NTAG(TAG_Nil)});
            v_t_2459 = (g_list_2edescending_24s1432586697x321478004(heff_dup(v_y_2455), heff_tag_re_n(v_ru_24xs_2453_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2455, v_t_2458}), v_ys_2456));
          }
          break;
        }
        default: heff_nomatch(v_xs_2453);
        }
        v_toks_2460 = (g_list_2emergeRuns_24s2052062657x972894659(NTAG(TAG_Nil), v_t_2459));
        break;
      }
      default: heff_nomatch(v_x2_2451);
      }
      V v_comments_2461 = v_field_2412;
      V v_t_2462 = (g_list_2emap_24s1409451498x400757684(v_toks_2460));
      V v_t_2463 = (g_list_2emap_24s32026788x2029987799(v_comments_2461));
      V v_x2_2464 = (g_prelude_2e_2b_2b(v_t_2462, v_t_2463));
      V v_es_2473;
      switch (heff_tag_of(v_x2_2464)) {
      case TAG_Nil: {
        v_es_2473 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x2_2464, 0);
        V v_xs_2466 = heff_field(v_x2_2464, 1);
        V v_ru_24x2_2464_24Cons = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
        V v_t_2472;
        switch (heff_tag_of(v_xs_2466)) {
        case TAG_Nil: {
          V v_t_2467 = heff_tag_re_n(v_ru_24x2_2464_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2465, NTAG(TAG_Nil)});
          v_t_2472 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          V v_y_2468 = heff_field(v_xs_2466, 0);
          V v_ys_2469 = heff_field(v_xs_2466, 1);
          V v_ru_24xs_2466_24Cons = heff_take_reuse_n(v_xs_2466, 3ULL, 2);
          if (heff_intLe_c(heff_dup(heff_rfield(v_x_2465, 0)), heff_dup(heff_rfield(v_y_2468, 0)))) {
            V v_t_2470 = heff_tag_re_n(v_ru_24x2_2464_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2465, NTAG(TAG_Nil)});
            v_t_2472 = (g_list_2eascending_24s1547370222x166817322(heff_dup(v_y_2468), heff_tag_re_n(v_ru_24xs_2466_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2468, v_t_2470}), v_ys_2469));
          } else {
            V v_t_2471 = heff_tag_re_n(v_ru_24x2_2464_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2465, NTAG(TAG_Nil)});
            v_t_2472 = (g_list_2edescending_24s1706700342x2062518382(heff_dup(v_y_2468), heff_tag_re_n(v_ru_24xs_2466_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2468, v_t_2471}), v_ys_2469));
          }
          break;
        }
        default: heff_nomatch(v_xs_2466);
        }
        v_es_2473 = (g_list_2emergeRuns_24s1839386886x1884977030(NTAG(TAG_Nil), v_t_2472));
        break;
      }
      default: heff_nomatch(v_x2_2464);
      }
      V v_t_2474 = heff_rec_n(3, shape_line__offset__out, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)});
      V v_l_2475 = (g_list_2efoldl_24s1872971975x1696014049(v_src_2414, v_t_2474, v_es_2473));
      V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_l_2475, 2, 3)));
      V v_elems_2477 = heff_arrayFromList(v_t_2476);
      V v_r_2478 = ({ V a_0 = v_src_2414; V a_1 = v_elems_2477; V a_2 = v_elems_2477; V a_3 = MK_INT(0LL); V a_4 = heff_dup(g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get()); V r_ = (g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_elems_2477); r_; });
      V v_toks_2479 = heff_take_field(v_r_2478, 2);
      V v_lead_2480 = heff_take_field(v_r_2478, 5);
      V v_inline_2481 = heff_take_field(v_r_2478, 6);
      V v_trail_2482 = heff_get_n(v_r_2478, 7, 10);
      V v_t_2483 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_toks_2479));
      V v_at_2484 = heff_rec_n(2, shape_toks__env, (V[]){heff_arrayFromList(v_t_2483), heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_src_2414, v_lead_2480, v_inline_2481, v_trail_2482, MK_INT(-1LL), MK_INT(-1LL), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get())})});
      V v_t_2485 = heff_get_n(heff_dup(heff_rfield(v_at_2484, 1)), 0, 7);
      V v_t_2486 = heff_get_n(heff_dup(heff_rfield(v_at_2484, 1)), 1, 7);
      V v_t_2487 = heff_get_n(heff_dup(heff_rfield(v_at_2484, 1)), 2, 7);
      V v_t_2488 = heff_get_n(heff_dup(heff_rfield(v_at_2484, 1)), 3, 7);
      V v_t_2489 = heff_get_n(heff_dup(heff_rfield(v_at_2484, 1)), 4, 7);
      V v_t_2490 = heff_get_n(heff_dup(heff_rfield(v_at_2484, 1)), 5, 7);
      V v_at_2491 = ({ V rv_1 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_t_2485, v_t_2486, v_t_2487, v_t_2488, v_t_2489, v_t_2490, v_f_243}); V rr_ = heff_rec_reuse_nf(v_at_2484, 1ULL, 2, shape_toks__env, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_toks_2492 = heff_take_field(v_at_2491, 0);
      V v_env_2493 = heff_get_n(v_at_2491, 1, 2);
      V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2495 = (g_heff_2esyntax_2ecst_2eprogramGo_24cpr(heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(v_toks_2492), MK_INT(0LL), MK_INT(0LL), v_t_2494, MK_INT(0LL)}), NTAG(TAG_Nil)));
      {
        V v_field_2497 = v_t_2495.f[1];
        int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
        if ((v_tag_2496 == ((int64_t)0ULL))) {
          heff_drop(v_toks_2492);
          heff_drop(v_env_2493);
          V v_e_2498 = v_field_2497;
          v_t_24120 = heff_tag_n(TAG_Left, 1, (V[]){v_e_2498});
        } else {
          V v_ds_2499 = v_field_2497;
          V v_ts_24100 = v_toks_2492;
          int64_t v_i_24101 = (heff_unbox_word(heff_arrayLength_lent(v_ts_24100, 0)) - ((int64_t)1ULL));
          V v_eof_24103;
          if (((((int64_t)0ULL) <= v_i_24101) && (v_i_24101 < heff_unbox_word(heff_arrayLength_lent(v_ts_24100, 0))))) {
            V v_t_24102 = heff_arrayIndexIn(v_ts_24100, heff_box_word(v_i_24101));
            v_eof_24103 = v_t_24102;
          } else {
            heff_drop(v_ts_24100);
            v_eof_24103 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str22), ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str23), ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str24), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
          }
          V v_d_24104 = ({ V a_0 = v_env_2493; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_False); V a_3 = v_eof_24103; V a_4 = v_ds_2499; V r_ = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_eof_24103); r_; });
          V v_t_24105 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_24104}), NTAG(TAG_Nil)});
          V v_s_24106 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_24105));
          V v_s_24107 = (g_std_2edoc_2edisplay_2edisplayInto_240(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str25), v_s_24106));
          V v_t_24108 = ({ V a_0 = v_s_24107; V a_1 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str26); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str27), v_s_24107, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_24107); r_; });
          V v_t_24109 = (g_list_2emap_24s725725455x1186198702(v_t_24108));
          V v_x2_24110 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_24109));
          V v_s_24113;
          switch (heff_tag_of(v_x2_24110)) {
          case TAG_Nil: {
            v_s_24113 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str28);
            break;
          }
          case TAG_Cons: {
            V v_x_24111 = heff_field(v_x2_24110, 0);
            V v_xs_24112 = heff_field(v_x2_24110, 1);
            heff_take_n(v_x2_24110, 3ULL, 2);
            v_s_24113 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str29); V a_1 = v_x_24111; V a_2 = v_xs_24112; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24112); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24110);
          }
          V v_t_24117;
          if ((heff_unbox_word(heff_strLength(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()))) == ((int64_t)0ULL))) {
            v_t_24117 = v_s_24113;
          } else {
            V v_x2_24114 = ({ V a_0 = v_s_24113; V b_1 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_2 = MK_INT(0LL); V a_3 = heff_strFind(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), heff_dup(v_s_24113), MK_INT(0LL)); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_24113); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_x2_24114)) {
            case TAG_Nil: {
              v_t_24117 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str30);
              break;
            }
            case TAG_Cons: {
              V v_x_24115 = heff_field(v_x2_24114, 0);
              V v_xs_24116 = heff_field(v_x2_24114, 1);
              heff_take_n(v_x2_24114, 3ULL, 2);
              v_t_24117 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str31); V a_1 = v_x_24115; V a_2 = v_xs_24116; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24116); r_; });
              break;
            }
            default: heff_nomatch(v_x2_24114);
            }
          }
          v_t_24120 = heff_tag_n(TAG_Right, 1, (V[]){heff_strAppend(v_t_24117, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str32))});
        }
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2413, 0ULL, 2);
      heff_drop(v_f_243);
      heff_drop(v_src_244);
      heff_drop(v_claim_246);
      heff_drop(v_imports_247);
      heff_drop(v_field_2410);
      heff_drop(v_field_2412);
      v_t_24120 = heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str33)});
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    switch (heff_tag_of(v_t_24120)) {
    case TAG_Left: {
      V v_why_24121 = heff_field(v_t_24120, 0);
      heff_take_n(v_t_24120, 1ULL, 1);
      heff_drop(v_src_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_24121}});
    }
    case TAG_Right: {
      V v_out_24122 = heff_field(v_t_24120, 0);
      heff_take_n(v_t_24120, 1ULL, 1);
      V v_t_24123 = (g_heff_2esyntax_2eformat_2emeaning(v_src_241));
      V v_t_24124 = (g_heff_2esyntax_2eformat_2emeaning(v_out_24122));
      return ({ V a_0 = v_src_241; V a_1 = v_out_24122; V a_2 = v_t_24123; V a_3 = v_t_24124; HeffT2 r_ = (g_heff_2esyntax_2eformat_2esameMeaning_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_src_241); r_; });
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24120)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eformat_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V v_src_240) {
top: ;
  V v_t_241 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_src_242 = heff_get_n(v_t_241, 3, 4);
  V v_t_243 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_244 = ({ V a_0 = v_src_242; V a_1 = v_t_243; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); HeffT3 r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_242); r_; });
  {
    V v_field_245 = v_t_244.f[0];
    heff_drop(v_t_244.f[1]);
    heff_drop(v_t_244.f[2]);
    V v_ts_248 = heff_arrayFromList(v_field_245);
    V v_t_249 = ({ V a_0 = v_ts_248; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2efixDecls(a_0, a_1, a_2)); heff_drop(v_ts_248); r_; });
    HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_24cpr(((V)&g_heff_2esyntax_2eformat_2eformat_24cpr_str0), v_t_249));
    {
      V v_field_2411 = v_t_2410.f[0];
      heff_drop(v_t_2410.f[1]);
      return (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_field_2411, v_src_240));
    }
  }
}