// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Now 25954
#define TAG_Quit 47258
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Send 26077
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_current 1358797751
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_errors 652506774
#define LBL_kept 9783717
#define LBL_lib 316671
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_paths 307797256
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_root__names__program__current__kept[] = {LBL_root, LBL_names, LBL_program, LBL_current, LBL_kept};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
static uint32_t shape_uri__text[] = {LBL_uri, LBL_text};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_24rec0_get(void);
V g_heff_2ebuild_2esession_2ecachedGo_24s1948589117x1986437027(V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s1948589117x1986437027_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s1948589117x1986437027_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_clo;
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400(V, V, V, V);
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_clo;
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(V, V);
V g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619(V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(V);
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_clo;
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377(V, V, V);
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_clo;
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2elinesFrom(V, V);
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_clo;
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846(V, V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_clo;
V g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594(V, V);
V g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594_clo;
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_clo;
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s446714453x706785629_24cpr(V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_entry, 2, 0};

V g_heff_2elsp_2elsp_2elinesFrom(V v_src_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_src_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  } else {
    V v_d_242 = heff_strLength_lent(v_src_240, 0);
    V v_j_243 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str0), v_src_240, v_i_241, 1);
    V v_t_244;
    if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
      heff_drop(v_j_243);
      v_t_244 = v_d_242;
    } else {
      heff_drop(v_d_242);
      v_t_244 = v_j_243;
    }
    V v_d_245 = heff_strLength_lent(v_src_240, 0);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_str1), v_src_240, v_i_241, 1);
    V v_t_247;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_247 = v_d_245;
    } else {
      heff_drop(v_d_245);
      v_t_247 = v_j_246;
    }
    V v_t_248 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_244, 6)});
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2elsp_2elsp_2elinesFrom_24dps(v_src_240, heff_intAdd(v_t_247, MK_INT(1LL)), v_cell_249));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elinesFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str0, 4, "data");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str1, 4, "type");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str2, 6, "theory");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str3, 8, "instance");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str4, 6, "mutual");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str5, 5, "infix");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str6, 6, "infixl");
HEFF_LIT(g_heff_2elsp_2elsp_2enamedIn_24cpr_str7, 6, "infixr");

HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V v_l_240) {
top: ;
  V v_t_241 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
  V v_w_242 = heff_strSlice_lent(v_l_240, MK_INT(0LL), v_t_241, 6);
  if ((heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str0), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str1), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str2), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str3), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str4), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str5), v_w_242, 1) || (heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str6), v_w_242, 1) || heff_strEq_c_lent(((V)&g_heff_2elsp_2elsp_2enamedIn_24cpr_str7), v_w_242, 1))))))))) {
    heff_drop(v_w_242);
    V v_t_243 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_t_244 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_243));
    V v_x_245 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_244));
    V v_t_246 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_y_247 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_246));
    if (heff_intLt_c(v_y_247, v_x_245)) {
      V v_t_248 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_s_249 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_248));
      V v_t_2410 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_t_2411 = (g_heff_2elsp_2elsp_2espaceEnd(v_l_240, v_t_2410));
      V v_e_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, v_t_2411));
      return ((HeffT2){{v_s_249, v_e_2412}});
    } else {
      V v_y_2413 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
      V v_t_2414;
      if (heff_intLe_c_lent(MK_INT(1LL), v_y_2413, 1)) {
        v_t_2414 = v_y_2413;
      } else {
        heff_drop(v_y_2413);
        v_t_2414 = MK_INT(1LL);
      }
      return ((HeffT2){{MK_INT(0LL), v_t_2414}});
    }
  } else {
    heff_drop(v_w_242);
    V v_y_2415 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_240, MK_INT(0LL)));
    V v_t_2416;
    if (heff_intLe_c_lent(MK_INT(1LL), v_y_2415, 1)) {
      v_t_2416 = v_y_2415;
    } else {
      heff_drop(v_y_2415);
      v_t_2416 = MK_INT(1LL);
    }
    return ((HeffT2){{MK_INT(0LL), v_t_2416}});
  }
}
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_lam0, 1, 0};
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_entry, 4, 0};

V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400(V v_x1_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_x2_241);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Just: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nothing: {
      heff_drop(v_z_242);
      heff_drop(v_f_244);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_text_245 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_f_244));
      V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
      V v_a_249 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_lam0_clo)});
      V v_t_2410 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_InR, 1, (V[]){v_a_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2414, v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_lam1, 1, 2, (V[]){v_z_243, v_text_245})));
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_text_245 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    heff_take_n(v_x_2415, 0ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_text_245);
    V f_ = v_z_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      heff_take_n(v_y_2417, 0ULL, 1);
      heff_clo_take(self, 2);
      heff_drop(v_text_245);
      V f_ = v_z_243;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      V v_t_2420 = heff_bool(heff_strEq_c_lent(v_x_2419, v_text_245, 0));
      heff_clo_take(self, 2);
      heff_drop(v_text_245);
      heff_drop(v_x_2419);
      V f_ = v_z_243;
      args[0] = v_t_2420;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam6(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_entry, 6, 0};

V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008(V v_st_240, V v_f_241, V v_d_242, V v_cut_243, V v_z_244, V v_z_245) {
top: ;
  V v_docs_246 = heff_take_field(v_st_240, 0);
  V v_lib_247 = heff_get_n(v_st_240, 6, 7);
  V v_c_2435 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365998876x100255905(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam0, 1, 4, (V[]){heff_dup(v_f_241), heff_dup(v_d_242), heff_dup(v_cut_243), v_docs_246}), v_lib_247, v_f_241));
  return heff_tail(v_c_2435, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam6, 1, 3, (V[]){v_z_244, v_d_242, v_z_245})});
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_d_242 = heff_env(self)[0];
  V v_cut_243 = heff_env(self)[1];
  heff_drop(v_hd_249);
  heff_clo_take(self, 2);
  V v_t_2411 = heff_strSlice(heff_get_n(v_d_242, 1, 2), MK_INT(0LL), v_cut_243);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_d_2415 = heff_env(self)[0];
  heff_drop(v_hd_2416);
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2415, 1, 2)});
  V f_ = v_k_2417;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam3(V self, V *args) {
  V v_r_2421 = args[0];
  return v_r_2421;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2424 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2424;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    switch (heff_tag_of(v_y_2432)) {
    case TAG_Left: {
      heff_take_n(v_y_2432, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2424;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_y_2432, 0);
      heff_take_n(v_y_2432, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2424;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2434});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2432);
    }
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_a_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2429, v_hd_2423, heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam5, 1, 1, (V[]){v_k_2424})));
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_cut_243 = heff_env(self)[2];
  V v_docs_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_p_248, v_f_241, 2)) {
    heff_drop(v_p_248);
    heff_drop(v_docs_246);
    return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam1, 2, 2, (V[]){v_d_242, v_cut_243});
  } else {
    heff_drop_rec(v_d_242, 2);
    heff_drop(v_cut_243);
    HeffT2 v_t_2412 = ({ V a_0 = v_docs_246; V a_1 = v_p_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_246); r_; });
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop(v_p_248);
        V v_d_2415 = v_field_2414;
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam2, 2, 1, (V[]){v_d_2415});
      } else {
        heff_drop(v_field_2414);
        V v_path_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_248));
        V v_t_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2419; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2419); r_; });
        V v_a_2422 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2420, ((V)&g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam3_clo)});
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam4, 2, 1, (V[]){v_a_2422});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_x_2446; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam7(V self, V *args) {
  V v_x_2441 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_errors_2439 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_full_2442 = heff_get_n(v_x_2441, 0, 2);
  V v_program_2443 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2442)));
  V v_t_2444 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2442));
  heff_clo_take(self, 3);
  V v_t_2445 = (g_heff_2elsp_2elsp_2ediagsOf(heff_rfield(v_d_242, 1), v_t_2444, v_errors_2439));
  V v_diags_2447 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam8, 1, 1, (V[]){v_d_242}), v_t_2445));
  V f_ = v_z_245;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2443, v_diags_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_paths_2437 = heff_take_field(v_x_2436, 2);
  V v_sources_2438 = heff_take_field(v_x_2436, 0);
  V v_errors_2439 = heff_get_n(v_x_2436, 1, 5);
  V v_t_2440 = (g_heff_2ebuild_2esession_2ecachedGo_24s1948589117x1986437027(v_paths_2437, v_sources_2438, heff_dup(g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_24rec0_get())));
  heff_clo_take(self, 3);
  V f_ = v_t_2440;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_lam7, 1, 3, (V[]){v_d_242, v_errors_2439, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str0, 4, "exit");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str1, 11, "initialized");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str2, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str3, 31, "workspace/didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str4, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str5, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str6, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str7, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str8, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str11, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str12, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str13, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str14, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str15, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str16, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str17, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str18, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str19, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str20, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str22, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str23, 22, "textDocument/didChange");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str24, 14, "contentChanges");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str25, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str26, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str27, 21, "textDocument/didClose");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str28, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str29, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str30, 31, "textDocument/publishDiagnostics");
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam2, 1, 0};
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam4, 2, 0};
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_entry, 5, 0};

V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846(V v_st_240, V v_m_241, V v_p_242, V v_z_243, V v_z_244) {
top: ;
  V v_c_245 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(heff_dup(v_p_242)));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam0, 1, 5, (V[]){heff_dup(v_m_241), v_st_240, v_z_243, v_z_244, v_p_242})});
}
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_2420);
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam2(V self, V *args) {
  V v_n_24100 = args[0];
  return v_n_24100;
}
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam3(V self, V *args) {
  V v_x_24105 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2423 = heff_env(self)[1];
  V v_text_2499 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_t_24106 = ({ V a_0 = heff_dup(heff_rfield(v_st_240, 2)); V a_1 = v_f_2423; V b_2 = heff_intAdd(v_x_24105, MK_INT(200LL)); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  heff_clo_take(self, 4);
  V v_st_24107 = v_st_240;
  V v_f_24108 = v_f_2423;
  V v_text_24109 = v_text_2499;
  HeffT2 v_t_24110 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_24107, 0), v_f_24108));
  {
    V v_field_24112 = v_t_24110.f[1];
    int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
    V v_s_24121;
    if ((v_tag_24111 == ((int64_t)0ULL))) {
      V v_d_24113 = v_field_24112;
      V v_t_24114 = ({ V rv_1 = v_text_24109; V rr_ = heff_rec_reuse_nf(v_d_24113, 1ULL, 2, shape_uri__text, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_d_24115 = ({ V a_0 = heff_take_field(v_st_24107, 0); V a_1 = v_f_24108; V a_2 = v_t_24114; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_f_24108); heff_drop_rec(v_t_24114, 2); r_; });
      V v_due_24116 = heff_take_field(v_st_24107, 2);
      V v_project_24117 = heff_take_field(v_st_24107, 3);
      V v_watch_24118 = heff_take_field(v_st_24107, 4);
      V v_shutdown_24119 = heff_take_field(v_st_24107, 5);
      V v_lib_24120 = heff_take_field(v_st_24107, 6);
      v_s_24121 = ({ V rv_0 = v_d_24115; V rv_2 = v_due_24116; V rv_3 = v_project_24117; V rv_4 = v_watch_24118; V rv_5 = v_shutdown_24119; V rv_6 = v_lib_24120; V rr_ = heff_rec_reuse_nf(v_st_24107, 2ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
    } else {
      heff_drop(v_f_24108);
      heff_drop(v_text_24109);
      heff_drop(v_field_24112);
      v_s_24121 = v_st_24107;
    }
    V v_project_24122 = heff_take_field(v_s_24121, 3);
    V v_watch_24123 = heff_take_field(v_s_24121, 4);
    V v_shutdown_24124 = heff_take_field(v_s_24121, 5);
    V v_lib_24125 = heff_take_field(v_s_24121, 6);
    V v_t_24126 = ({ V rv_2 = v_t_24106; V rv_3 = v_project_24122; V rv_4 = v_watch_24123; V rv_5 = v_shutdown_24124; V rv_6 = v_lib_24125; V rr_ = heff_rec_reuse_nf(v_s_24121, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
    V f_ = v_z_244;
    args[0] = v_t_24126;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam4(V self, V *args) {
  V v_hd_24136 = args[0];
  V v_k_24137 = args[1];
  heff_drop(v_hd_24136);
  V f_ = v_k_24137;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam5(V self, V *args) {
  V v_x_24139 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_2423 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  heff_drop(v_x_24139);
  heff_clo_take(self, 3);
  V v_st_24140 = v_st_240;
  V v_f_24141 = v_f_2423;
  V v_t_24142 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_st_24140, 2), v_f_24141));
  V v_c_24143 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_st_24140, 1), v_f_24141));
  V v_d_24144 = ({ V a_0 = heff_take_field(v_st_24140, 0); V a_1 = v_f_24141; V r_ = (g_std_2eordmap_2edelete_24s2135745297x1725920174(a_0, a_1)); heff_drop(v_f_24141); r_; });
  V v_project_24145 = heff_take_field(v_st_24140, 3);
  V v_watch_24146 = heff_take_field(v_st_24140, 4);
  V v_shutdown_24147 = heff_take_field(v_st_24140, 5);
  V v_x_24148 = ({ V rv_0 = v_d_24144; V rv_1 = v_c_24143; V rv_2 = v_t_24142; V rv_3 = v_project_24145; V rv_4 = v_watch_24146; V rv_5 = v_shutdown_24147; V rr_ = heff_rec_reuse_nf(v_st_24140, 64ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12288u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V f_ = v_z_244;
  args[0] = v_x_24148;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str0), 2)) {
    heff_drop(v_x_246);
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop(v_p_242);
    V v_t_247 = heff_get_n(v_st_240, 5, 7);
    V v_t_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_t_248 = MK_INT(0LL);
    } else {
      heff_drop(v_t_247);
      v_t_248 = MK_INT(1LL);
    }
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_z_243, v_z_244));
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str1), 2)) {
      heff_drop(v_x_246);
      heff_clo_take(self, 5);
      heff_drop(v_m_241);
      heff_drop(v_p_242);
      V v_t_2413 = heff_dup(heff_rfield(v_st_240, 4));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str2); V b_1 = heff_dup(g_heff_2elsp_2elsp_2eregistration_get()); V r_ = (g_json_2estringify_2ewriteInto_240(a_0, b_1)); heff_drop(b_1); r_; });
        V v_a_2415 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
        V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
        V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
        V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
        V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
        return (g_co_2eop_24s535099379x685970669(v_t_2419, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam1, 1, 2, (V[]){v_z_244, v_st_240})));
      } else {
        heff_drop(v_z_243);
        heff_drop(v_t_2413);
        V f_ = v_z_244;
        args[0] = v_st_240;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str3), 2)) {
        heff_drop(v_x_246);
        heff_clo_take(self, 5);
        heff_drop(v_m_241);
        heff_drop(v_p_242);
        V v_t_2421 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
        V v_t_2422 = (g_list_2emap_24s1415906091x1371825187(v_t_2421));
        return ({ V a_0 = v_st_240; V a_1 = v_t_2422; V a_2 = v_z_243; V a_3 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s261276739x1271652214(a_0, a_1, a_2, a_3)); heff_drop(v_t_2422); r_; });
      } else {
        switch (heff_tag_of(v_x_246)) {
        case TAG_Nothing: {
          heff_clo_take(self, 5);
          heff_drop(v_m_241);
          heff_drop(v_z_243);
          heff_drop(v_p_242);
          V f_ = v_z_244;
          args[0] = v_st_240;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_f_2423 = heff_field(v_x_246, 0);
          V v_ru_24x_246_24Just = heff_take_reuse_n(v_x_246, 1ULL, 1);
          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str4), 2)) {
            heff_clo_take(self, 5);
            heff_drop(v_m_241);
            heff_drop_cell(v_ru_24x_246_24Just, 1);
            V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str5), NTAG(TAG_Nil)});
            HeffT2 v_t_2425 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str6), v_t_2424}); V a_1 = heff_dup(v_p_242); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_2427 = v_t_2425.f[1];
              int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
              V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str7), NTAG(TAG_Nil)});
              HeffT2 v_t_2429 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str8), v_t_2428}); V a_1 = v_p_242; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2431 = v_t_2429.f[1];
                int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                V v_t_2439;
                if ((v_tag_2426 == ((int64_t)0ULL))) {
                  V v_it1_2432 = v_field_2427;
                  switch (heff_tag_of(v_it1_2432)) {
                  case TAG_JNull: {
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str9);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str10);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str11);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str12);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2436 = heff_field(v_it1_2432, 0);
                    heff_take_n(v_it1_2432, 1ULL, 1);
                    v_t_2439 = v_s_2436;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str13);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2432, 0ULL, 1);
                    v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str14);
                    break;
                  }
                  default: heff_nomatch(v_it1_2432);
                  }
                } else {
                  heff_drop(v_field_2427);
                  v_t_2439 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str15);
                }
                V v_t_2447;
                if ((v_tag_2430 == ((int64_t)0ULL))) {
                  V v_it1_2440 = v_field_2431;
                  switch (heff_tag_of(v_it1_2440)) {
                  case TAG_JNull: {
                    v_t_2447 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str16);
                    break;
                  }
                  case TAG_JBool: {
                    heff_take_n(v_it1_2440, 0ULL, 1);
                    v_t_2447 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str17);
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2440, 0ULL, 1);
                    v_t_2447 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str18);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2440, 0ULL, 1);
                    v_t_2447 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str19);
                    break;
                  }
                  case TAG_JString: {
                    V v_s_2444 = heff_field(v_it1_2440, 0);
                    heff_take_n(v_it1_2440, 1ULL, 1);
                    v_t_2447 = v_s_2444;
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2440, 0ULL, 1);
                    v_t_2447 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str20);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2440, 0ULL, 1);
                    v_t_2447 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str21);
                    break;
                  }
                  default: heff_nomatch(v_it1_2440);
                  }
                } else {
                  heff_drop(v_field_2431);
                  v_t_2447 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str22);
                }
                V v_d_2448 = ({ V a_0 = heff_take_field(v_st_240, 0); V a_1 = v_f_2423; V b_2 = heff_rec_n(2, shape_uri__text, (V[]){v_t_2439, v_t_2447}); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                V v_due_2449 = heff_take_field(v_st_240, 2);
                V v_project_2450 = heff_take_field(v_st_240, 3);
                V v_watch_2451 = heff_take_field(v_st_240, 4);
                V v_shutdown_2452 = heff_take_field(v_st_240, 5);
                V v_lib_2453 = heff_take_field(v_st_240, 6);
                V v_t_2454 = ({ V rv_0 = v_d_2448; V rv_2 = v_due_2449; V rv_3 = v_project_2450; V rv_4 = v_watch_2451; V rv_5 = v_shutdown_2452; V rv_6 = v_lib_2453; V rr_ = heff_rec_reuse_nf(v_st_240, 2ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
                V v_t_2455 = (g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619(v_t_2454, v_f_2423));
                V f_ = v_t_2455;
                heff_room[0] = v_z_243;
                heff_room[1] = v_z_244;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str23), 2)) {
              heff_clo_take(self, 5);
              heff_drop(v_m_241);
              V v_p_2456 = v_p_242;
              V v_t_2498;
              switch (heff_tag_of(v_p_2456)) {
              case TAG_JNull: {
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2498 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_p_2456, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2498 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_p_2456, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2498 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_p_2456, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2498 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_p_2456, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2498 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_p_2456, 0ULL, 1);
                heff_drop_cell(v_ru_24x_246_24Just, 1);
                v_t_2498 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_JObject: {
                V v_fs_2462 = heff_field(v_p_2456, 0);
                heff_take_n(v_p_2456, 1ULL, 1);
                HeffT2 v_t_2463 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str24); V a_1 = v_fs_2462; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2462); r_; });
                {
                  V v_field_2465 = v_t_2463.f[1];
                  int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
                  if ((v_tag_2464 == ((int64_t)0ULL))) {
                    V v_p_2466 = v_field_2465;
                    V v_t_2469;
                    switch (heff_tag_of(v_p_2466)) {
                    case TAG_MkPair: {
                      V v_y_2468 = heff_field(v_p_2466, 1);
                      heff_take_n(v_p_2466, 2ULL, 2);
                      v_t_2469 = v_y_2468;
                      break;
                    }
                    default: heff_nomatch(v_p_2466);
                    }
                    switch (heff_tag_of(v_t_2469)) {
                    case TAG_JNull: {
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2498 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JBool: {
                      heff_take_n(v_t_2469, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2498 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JInt: {
                      heff_take_n(v_t_2469, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2498 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JFloat: {
                      heff_take_na(v_t_2469, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2498 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JString: {
                      heff_take_n(v_t_2469, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2498 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_JArray: {
                      V v_xs_2474 = heff_field(v_t_2469, 0);
                      heff_take_n(v_t_2469, 1ULL, 1);
                      V v_x1_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2474));
                      switch (heff_tag_of(v_x1_2475)) {
                      case TAG_Nil: {
                        heff_drop_cell(v_ru_24x_246_24Just, 1);
                        v_t_2498 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Cons: {
                        V v_x_2476 = heff_field(v_x1_2475, 0);
                        heff_take_n(v_x1_2475, 1ULL, 2);
                        switch (heff_tag_of(v_x_2476)) {
                        case TAG_JNull: {
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2498 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JBool: {
                          heff_take_n(v_x_2476, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2498 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JInt: {
                          heff_take_n(v_x_2476, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2498 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JFloat: {
                          heff_take_na(v_x_2476, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2498 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JString: {
                          heff_take_n(v_x_2476, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2498 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JArray: {
                          heff_take_n(v_x_2476, 0ULL, 1);
                          heff_drop_cell(v_ru_24x_246_24Just, 1);
                          v_t_2498 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_JObject: {
                          V v_fs_2483 = heff_field(v_x_2476, 0);
                          heff_take_n(v_x_2476, 1ULL, 1);
                          HeffT2 v_t_2484 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str25); V a_1 = v_fs_2483; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2483); r_; });
                          {
                            V v_field_2486 = v_t_2484.f[1];
                            int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
                            if ((v_tag_2485 == ((int64_t)0ULL))) {
                              V v_p_2487 = v_field_2486;
                              V v_t_2490;
                              switch (heff_tag_of(v_p_2487)) {
                              case TAG_MkPair: {
                                V v_y_2489 = heff_field(v_p_2487, 1);
                                heff_take_n(v_p_2487, 2ULL, 2);
                                v_t_2490 = v_y_2489;
                                break;
                              }
                              default: heff_nomatch(v_p_2487);
                              }
                              switch (heff_tag_of(v_t_2490)) {
                              case TAG_JNull: {
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2498 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JBool: {
                                heff_take_n(v_t_2490, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2498 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JInt: {
                                heff_take_n(v_t_2490, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2498 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JFloat: {
                                heff_take_na(v_t_2490, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2498 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JString: {
                                V v_s_2494 = heff_field(v_t_2490, 0);
                                heff_take_n(v_t_2490, 1ULL, 1);
                                v_t_2498 = heff_tag_at_n(v_ru_24x_246_24Just, TAG_Just, 1, (V[]){v_s_2494});
                                break;
                              }
                              case TAG_JArray: {
                                heff_take_n(v_t_2490, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2498 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_JObject: {
                                heff_take_n(v_t_2490, 0ULL, 1);
                                heff_drop_cell(v_ru_24x_246_24Just, 1);
                                v_t_2498 = NTAG(TAG_Nothing);
                                break;
                              }
                              default: heff_nomatch(v_t_2490);
                              }
                            } else {
                              heff_drop_cell(v_ru_24x_246_24Just, 1);
                              heff_drop(v_field_2486);
                              v_t_2498 = NTAG(TAG_Nothing);
                            }
                          }
                          break;
                        }
                        default: heff_nomatch(v_x_2476);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x1_2475);
                      }
                      break;
                    }
                    case TAG_JObject: {
                      heff_take_n(v_t_2469, 0ULL, 1);
                      heff_drop_cell(v_ru_24x_246_24Just, 1);
                      v_t_2498 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_t_2469);
                    }
                  } else {
                    heff_drop_cell(v_ru_24x_246_24Just, 1);
                    heff_drop(v_field_2465);
                    v_t_2498 = NTAG(TAG_Nothing);
                  }
                }
                break;
              }
              default: heff_nomatch(v_p_2456);
              }
              switch (heff_tag_of(v_t_2498)) {
              case TAG_Nothing: {
                heff_drop(v_z_243);
                heff_drop(v_f_2423);
                V f_ = v_z_244;
                args[0] = v_st_240;
                if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                return heff_tail(f_, 1, args);
              }
              case TAG_Just: {
                V v_text_2499 = heff_field(v_t_2498, 0);
                V v_ru_24t_2498_24Just = heff_take_reuse_n(v_t_2498, 1ULL, 1);
                V v_t_24101 = heff_tag_at_n(v_ru_24t_2498_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam2_clo)})});
                V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
                V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
                V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})});
                return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24104}), v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam3, 1, 4, (V[]){v_st_240, v_f_2423, v_text_2499, v_z_244})));
              }
              default: return heff_nomatch(v_t_2498);
              }
            } else {
              heff_clo_take(self, 5);
              heff_drop(v_p_242);
              heff_drop_cell(v_ru_24x_246_24Just, 1);
              if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str26), 2)) {
                heff_drop(v_m_241);
                V v_t_24127 = (g_heff_2elsp_2elsp_2echeckNow_24s1389097912x880736619(v_st_240, v_f_2423));
                V f_ = v_t_24127;
                heff_room[0] = v_z_243;
                heff_room[1] = v_z_244;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              } else {
                if (heff_strEq_c(v_m_241, ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str27))) {
                  HeffT2 v_t_24128 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_2423));
                  {
                    V v_field_24130 = v_t_24128.f[1];
                    int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
                    V v_c_24138;
                    if ((v_tag_24129 == ((int64_t)0ULL))) {
                      V v_d_24131 = v_field_24130;
                      V v_t_24132 = heff_tag_n(TAG_JString, 1, (V[]){heff_get_n(v_d_24131, 0, 2)});
                      V v_t_24133 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
                      V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str28), v_t_24133}), NTAG(TAG_Nil)});
                      V v_t_24135 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str29), v_t_24132}), v_t_24134});
                      v_c_24138 = heff_tr(g_heff_2elsp_2elsp_2enotify_24s125722774x1265587594(((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_str30), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24135})));
                    } else {
                      heff_drop(v_field_24130);
                      v_c_24138 = ((V)&g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam4_clo);
                    }
                    V f_ = v_c_24138;
                    heff_room[0] = v_z_243;
                    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846_lam5, 1, 3, (V[]){v_st_240, v_f_2423, v_z_244});
                    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                  }
                } else {
                  heff_drop(v_z_243);
                  heff_drop(v_f_2423);
                  V f_ = v_z_244;
                  args[0] = v_st_240;
                  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                  return heff_tail(f_, 1, args);
                }
              }
            }
          }
        }
        default: return heff_nomatch(v_x_246);
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_str1, 0, "");
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(v_p_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam0, 2, 2, (V[]){v_c_242, v_st_240});
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_d_2411 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2426 = heff_get_n(v_d_2411, 1, 2);
  HeffT2 v_t_2427 = ({ V a_0 = heff_rfield(v_x_2425, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    V v_x_2433;
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      V v_c_2430 = v_field_2429;
      V v_text_2431 = heff_take_field(v_c_2430, 0);
      V v_program_2432 = heff_get_n(v_c_2430, 1, 2);
      if (heff_strEq_c_lent(v_text_2431, v_text_2426, 1)) {
        v_x_2433 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2425, v_text_2426, v_program_2432});
      } else {
        heff_drop(v_program_2432);
        v_x_2433 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2425, v_text_2426, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2429);
      v_x_2433 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2425, v_text_2426, NTAG(TAG_Nil)});
    }
    V f_ = v_k_244;
    args[0] = v_x_2433;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_d_2411 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2436 = heff_get_n(v_d_2411, 1, 2);
  HeffT2 v_t_2437 = ({ V a_0 = heff_rfield(v_x_2435, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    V v_x_2443;
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      V v_c_2440 = v_field_2439;
      V v_text_2441 = heff_take_field(v_c_2440, 0);
      V v_program_2442 = heff_get_n(v_c_2440, 1, 2);
      if (heff_strEq_c_lent(v_text_2441, v_text_2436, 1)) {
        v_x_2443 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2435, v_text_2436, v_program_2442});
      } else {
        heff_drop(v_program_2442);
        v_x_2443 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2435, v_text_2436, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2439);
      v_x_2443 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2435, v_text_2436, NTAG(TAG_Nil)});
    }
    V f_ = v_k_244;
    args[0] = v_x_2443;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_clo_take(self, 3);
    heff_drop(v_hd_243);
    V v_t_246 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_str0), NTAG(TAG_Nil)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_d_2411 = v_field_2410;
        HeffT2 v_t_2412 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 1), v_f_247));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_c_2415 = v_field_2414;
            if (heff_strEq_c(heff_get_n(v_c_2415, 0, 2), heff_dup(heff_rfield(v_d_2411, 1)))) {
              heff_clo_take(self, 3);
              heff_drop(v_hd_243);
              V v_text_2416 = heff_get_n(v_d_2411, 1, 2);
              HeffT2 v_t_2417 = ({ V a_0 = heff_rfield(v_st_240, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
              {
                V v_field_2419 = v_t_2417.f[1];
                int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
                V v_x_2423;
                if ((v_tag_2418 == ((int64_t)0ULL))) {
                  V v_c_2420 = v_field_2419;
                  V v_text_2421 = heff_take_field(v_c_2420, 0);
                  V v_program_2422 = heff_get_n(v_c_2420, 1, 2);
                  if (heff_strEq_c_lent(v_text_2421, v_text_2416, 1)) {
                    v_x_2423 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2416, v_program_2422});
                  } else {
                    heff_drop(v_program_2422);
                    v_x_2423 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2416, NTAG(TAG_Nil)});
                  }
                } else {
                  heff_drop(v_field_2419);
                  v_x_2423 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2416, NTAG(TAG_Nil)});
                }
                V f_ = v_k_244;
                args[0] = v_x_2423;
                if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                return heff_tail(f_, 1, args);
              }
            } else {
              heff_clo_take(self, 3);
              V v_t_2424 = (g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(v_st_240, heff_dup(v_f_247)));
              V f_ = v_t_2424;
              heff_room[0] = v_hd_243;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam2, 1, 3, (V[]){v_d_2411, v_f_247, v_k_244});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          } else {
            heff_drop(v_field_2414);
            heff_clo_take(self, 3);
            V v_t_2434 = (g_heff_2elsp_2elsp_2echeck_24s1124990915x105563713(v_st_240, heff_dup(v_f_247)));
            V f_ = v_t_2434;
            heff_room[0] = v_hd_243;
            heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam3, 1, 3, (V[]){v_d_2411, v_f_247, v_k_244});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      } else {
        heff_clo_take(self, 3);
        heff_drop(v_hd_243);
        heff_drop(v_f_247);
        heff_drop(v_field_2410);
        V v_t_2444 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_str1), NTAG(TAG_Nil)});
        V f_ = v_k_244;
        args[0] = v_t_2444;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_lam1, 1, 3, (V[]){v_st_240, v_k_244, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str17, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str19, 11, "placeholder");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str20, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str21, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str22, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str23, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str24, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str25, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str26, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str27, 21, "` is not written here");
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_entry, 4, 0};

V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147(V v_id_240, V v_tg_241, V v_z_242, V v_z_243) {
top: ;
  V v_target_244 = heff_take_field(v_tg_241, 2);
  V v_st_245 = heff_take_field(v_tg_241, 0);
  V v_off_246 = heff_get_n(v_tg_241, 1, 3);
  V v_t_247 = v_target_244;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_off_246);
    V v_t_248 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str0), ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str1), MK_INT(0LL)));
    V v_acc_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str2)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str3));
    V v_t_2410 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str4), heff_strAppend(v_acc_249, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str5)), MK_INT(0LL)));
    V v_acc_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str6));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_acc_2411, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str7)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str8));
    V v_t_2413 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str9), v_t_2412, MK_INT(0LL)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str10)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str11));
    V v_acc_2415 = ({ V a_0 = v_t_2414; V a_1 = v_id_240; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_240); r_; });
    V v_t_2416 = heff_strAppend(heff_strAppend(v_acc_2415, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str12)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str13));
    V v_t_2417 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str14), v_t_2416, MK_INT(0LL)));
    V v_acc_2418 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str15)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str16));
    V v_t_2419 = heff_strAppend(heff_strAppend(v_acc_2418, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str17)), ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str18));
    V v_a_2420 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s535099379x685970669(v_t_2424, v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam0, 1, 2, (V[]){v_z_243, v_st_245})));
  }
  case TAG_Just: {
    V v_t_2426 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    HeffT2 v_t_2427 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2426, 1)), heff_dup(heff_rfield(v_t_2426, 2)), heff_dup(heff_rfield(v_t_2426, 2))));
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        heff_drop(v_off_246);
        heff_drop_rec(v_t_2426, 4);
        V v_why_2430 = v_field_2429;
        V v_c_2431 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(v_ru_24t_247_24Just, v_id_240, MK_INT(-32803LL), v_why_2430));
        return heff_tail(v_c_2431, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam1, 1, 2, (V[]){v_z_243, v_st_245})});
      } else {
        heff_drop(v_field_2429);
        HeffT2 v_t_2433 = ({ V a_0 = v_t_2426; V a_1 = v_off_246; V a_2 = heff_rfield(v_t_2426, 3); HeffT2 r_ = (g_list_2efind_24s446714453x706785629_24cpr(a_0, a_1, a_2)); heff_drop(v_off_246); r_; });
        {
          V v_field_2435 = v_t_2433.f[1];
          int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
          if ((v_tag_2434 == ((int64_t)0ULL))) {
            V v_o_2436 = v_field_2435;
            V v_source_2437 = heff_take_field(v_o_2436, 1);
            V v_span_2438 = heff_get_n(v_o_2436, 2, 4);
            V v_t_2439 = ({ V a_0 = v_source_2437; V a_1 = v_span_2438; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_2437); r_; });
            V v_t_2440 = heff_tag_at_n(v_ru_24t_247_24Just, TAG_JString, 1, (V[]){heff_get_n(v_t_2426, 2, 4)});
            V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str19), v_t_2440}), NTAG(TAG_Nil)});
            V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str20), v_t_2439}), v_t_2441});
            V v_result_2443 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2442});
            V v_t_2444 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str21), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str22)})});
            V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str23), v_result_2443}), NTAG(TAG_Nil)});
            V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str24), v_id_240}), v_t_2445});
            V v_t_2447 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, v_t_2446})});
            V v_t_2448 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str25); V a_1 = v_t_2447; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_2447, 1); r_; });
            V v_a_2449 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2448, NTAG(TAG_MkUnit)});
            V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2449})});
            V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
            V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
            V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
            return (g_co_2eop_24s535099379x685970669(v_t_2453, v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam2, 1, 2, (V[]){v_z_243, v_st_245})));
          } else {
            heff_drop(v_field_2435);
            V v_t_2455 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str26), heff_get_n(v_t_2426, 2, 4));
            V v_c_2456 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(v_ru_24t_247_24Just, v_id_240, MK_INT(-32803LL), heff_strAppend(v_t_2455, ((V)&g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_str27))));
            return heff_tail(v_c_2456, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam3, 1, 2, (V[]){v_z_243, v_st_245})});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  heff_drop(v_x_2425);
  heff_clo_take(self, 2);
  V f_ = v_z_243;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam1(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  heff_drop(v_x_2432);
  heff_clo_take(self, 2);
  V f_ = v_z_243;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam2(V self, V *args) {
  V v_x_2454 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  heff_drop(v_x_2454);
  heff_clo_take(self, 2);
  V f_ = v_z_243;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_lam3(V self, V *args) {
  V v_x_2457 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_245 = heff_env(self)[1];
  heff_drop(v_x_2457);
  heff_clo_take(self, 2);
  V f_ = v_z_243;
  args[0] = v_st_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str0, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str1, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str2, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str3, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str4, 9, "shut down");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str5, 6, "params");
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_entry, 4, 0};

V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043(V v_st_240, V v_msg_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_2423;
  switch (heff_tag_of(v_msg_241)) {
  case TAG_JNull: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_249 = heff_dup(heff_field(v_msg_241, 0));
    HeffT2 v_t_2410 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str0); V a_1 = v_fs_249; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_249); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_p_2413 = v_field_2412;
        V v_t_2416;
        switch (heff_tag_of(v_p_2413)) {
        case TAG_MkPair: {
          V v_y_2415 = heff_field(v_p_2413, 1);
          heff_take_n(v_p_2413, 2ULL, 2);
          v_t_2416 = v_y_2415;
          break;
        }
        default: heff_nomatch(v_p_2413);
        }
        switch (heff_tag_of(v_t_2416)) {
        case TAG_JNull: {
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2420 = heff_field(v_t_2416, 0);
          V v_ru_24t_2416_24JString = heff_take_reuse_n(v_t_2416, 1ULL, 1);
          v_t_2423 = heff_tag_at_n(v_ru_24t_2416_24JString, TAG_Just, 1, (V[]){v_s_2420});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2416);
        }
      } else {
        heff_drop(v_field_2412);
        v_t_2423 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_msg_241);
  }
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nothing: {
    heff_drop(v_msg_241);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_m_2424 = heff_field(v_t_2423, 0);
    V v_ru_24t_2423_24Just = heff_take_reuse_n(v_t_2423, 1ULL, 1);
    V v_t_2438;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2430 = heff_dup(heff_field(v_msg_241, 0));
      HeffT2 v_t_2431 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str1); V a_1 = v_fs_2430; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2430); r_; });
      {
        V v_field_2433 = v_t_2431.f[1];
        int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
        if ((v_tag_2432 == ((int64_t)0ULL))) {
          V v_p_2434 = v_field_2433;
          V v_t_2437;
          switch (heff_tag_of(v_p_2434)) {
          case TAG_MkPair: {
            V v_y_2436 = heff_field(v_p_2434, 1);
            heff_take_n(v_p_2434, 2ULL, 2);
            v_t_2437 = v_y_2436;
            break;
          }
          default: heff_nomatch(v_p_2434);
          }
          v_t_2438 = heff_tag_at_n(v_ru_24t_2423_24Just, TAG_Just, 1, (V[]){v_t_2437});
        } else {
          heff_drop_cell(v_ru_24t_2423_24Just, 1);
          heff_drop(v_field_2433);
          v_t_2438 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Nothing: {
      V v_p_2451;
      switch (heff_tag_of(v_msg_241)) {
      case TAG_JNull: {
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JObject: {
        V v_fs_2444 = heff_field(v_msg_241, 0);
        heff_take_n(v_msg_241, 1ULL, 1);
        HeffT2 v_t_2445 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str2); V a_1 = v_fs_2444; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2444); r_; });
        {
          V v_field_2447 = v_t_2445.f[1];
          int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
          if ((v_tag_2446 == ((int64_t)0ULL))) {
            V v_p_2448 = v_field_2447;
            switch (heff_tag_of(v_p_2448)) {
            case TAG_MkPair: {
              V v_y_2450 = heff_field(v_p_2448, 1);
              heff_take_n(v_p_2448, 2ULL, 2);
              v_p_2451 = v_y_2450;
              break;
            }
            default: heff_nomatch(v_p_2448);
            }
          } else {
            heff_drop(v_field_2447);
            v_p_2451 = NTAG(TAG_JNull);
          }
        }
        break;
      }
      default: heff_nomatch(v_msg_241);
      }
      V v_c_2452 = (g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377(heff_dup(v_st_240), v_m_2424, heff_dup(v_p_2451)));
      return heff_tail(v_c_2452, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_lam0, 1, 5, (V[]){v_st_240, v_m_2424, v_p_2451, v_z_242, v_z_243})});
    }
    case TAG_Just: {
      V v_id_2465 = heff_field(v_t_2438, 0);
      V v_ru_24t_2438_24Just = heff_take_reuse_n(v_t_2438, 1ULL, 1);
      if (((heff_dup(heff_rfield(v_st_240, 5)) == NTAG(TAG_True)) && !heff_strEq_c_lent(v_m_2424, ((V)&g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str3), 2))) {
        heff_drop(v_msg_241);
        heff_drop(v_m_2424);
        V v_c_2466 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(v_ru_24t_2438_24Just, v_id_2465, MK_INT(-32600LL), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str4)));
        return heff_tail(v_c_2466, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_lam1, 1, 2, (V[]){v_z_243, v_st_240})});
      } else {
        heff_drop_cell(v_ru_24t_2438_24Just, 1);
        V v_t_2480;
        switch (heff_tag_of(v_msg_241)) {
        case TAG_JNull: {
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JObject: {
          V v_fs_2473 = heff_field(v_msg_241, 0);
          heff_take_n(v_msg_241, 1ULL, 1);
          HeffT2 v_t_2474 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_str5); V a_1 = v_fs_2473; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2473); r_; });
          {
            V v_field_2476 = v_t_2474.f[1];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            if ((v_tag_2475 == ((int64_t)0ULL))) {
              V v_p_2477 = v_field_2476;
              switch (heff_tag_of(v_p_2477)) {
              case TAG_MkPair: {
                V v_y_2479 = heff_field(v_p_2477, 1);
                heff_take_n(v_p_2477, 2ULL, 2);
                v_t_2480 = v_y_2479;
                break;
              }
              default: heff_nomatch(v_p_2477);
              }
            } else {
              heff_drop(v_field_2476);
              v_t_2480 = NTAG(TAG_JNull);
            }
          }
          break;
        }
        default: heff_nomatch(v_msg_241);
        }
        return (g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837(v_st_240, v_m_2424, v_id_2465, v_t_2480, v_z_242, v_z_243));
      }
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_lam0(V self, V *args) {
  V v_x_2453 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_m_2424 = heff_env(self)[1];
  V v_p_2451 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  V v_t_2464;
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_2453) == NTAG(TAG_True))) {
    heff_drop(v_x_2453);
    v_t_2464 = v_st_240;
  } else {
    heff_drop(v_x_2453);
    V v_s_2454 = v_st_240;
    V v_t_2455 = heff_dup(heff_rfield(v_s_2454, 3));
    switch (heff_tag_of(v_t_2455)) {
    case TAG_Nothing: {
      v_t_2464 = v_s_2454;
      break;
    }
    case TAG_Just: {
      V v_pr_2456 = heff_field(v_t_2455, 0);
      heff_take_n(v_t_2455, 1ULL, 1);
      V v_due_2457 = heff_take_field(v_s_2454, 2);
      V v_watch_2458 = heff_take_field(v_s_2454, 4);
      V v_shutdown_2459 = heff_take_field(v_s_2454, 5);
      V v_lib_2460 = heff_take_field(v_s_2454, 6);
      V v_program_2461 = heff_take_field(v_pr_2456, 2);
      V v_kept_2462 = heff_take_field(v_pr_2456, 4);
      V v_t_2463 = ({ V rv_2 = v_program_2461; V rv_3 = NTAG(TAG_False); V rv_4 = v_kept_2462; V rr_ = heff_rec_reuse_nf(v_pr_2456, 3ULL, 5, shape_root__names__program__current__kept, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
      v_t_2464 = ({ V rv_2 = v_due_2457; V rv_3 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2463}); V rv_4 = v_watch_2458; V rv_5 = v_shutdown_2459; V rv_6 = v_lib_2460; V rr_ = heff_rec_reuse_nf(v_s_2454, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
      break;
    }
    default: heff_nomatch(v_t_2455);
    }
  }
  return ({ V a_0 = v_t_2464; V a_1 = v_m_2424; V a_2 = v_p_2451; V a_3 = v_z_242; V a_4 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2enotified_24s813668416x2035511846(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_m_2424); r_; });
}
V g_heff_2elsp_2elsp_2ehandle_24s1273991236x1843643043_lam1(V self, V *args) {
  V v_x_2467 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_2467);
  heff_clo_take(self, 2);
  V f_ = v_z_243;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}