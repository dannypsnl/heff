// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Begin 41697
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_Finish 61316
#define TAG_Holds 53574
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_RealPath 18882
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_TemporaryDirectory 61563
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_at 9882
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_fmap 9641981
#define LBL_fuel 9649789
#define LBL_hmap 9701563
#define LBL_implicit 319715269
#define LBL_integrations 139286697
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_line 9817275
#define LBL_loaded 849622832
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_other 307428138
#define LBL_outcomes 803130769
#define LBL_owner 307523277
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_place 308106529
#define LBL_program 2069953735
#define LBL_renames 1324191545
#define LBL_reports 1326460931
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_update 1108295668
#define LBL_value 313331083
#define LBL_watch 314261737
#define LBL_wrong 314763719
static uint32_t shape_at__pending__launch[] = {LBL_at, LBL_pending, LBL_launch};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_program__env[] = {LBL_program, LBL_env};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void);
V g_co_2eop_24s1412293101x300983667(V, V, V);
V g_co_2eop_24s1412293101x300983667_entry(V self, V *a);
extern Clo g_co_2eop_24s1412293101x300983667_clo;
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s197845728x1944963205(V, V, V);
V g_co_2eop_24s197845728x1944963205_entry(V self, V *a);
extern Clo g_co_2eop_24s197845728x1944963205_clo;
V g_co_2eop_24s2022167152x294629972_24rec0_get(void);
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_clo;
V g_heff_2ebuild_2edriver_2etestsOf(V);
V g_heff_2ebuild_2edriver_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestsOf_clo;
V g_heff_2ebuild_2etesting_2ebrokenJob(V, V);
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo;
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_clo;
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2etesting_2efilesSaid(V);
V g_heff_2ebuild_2etesting_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2efilesSaid_clo;
HeffT3 g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_clo;
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_clo;
V g_heff_2ebuild_2etesting_2egoldenPath(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenPath_clo;
V g_heff_2ebuild_2etesting_2eintegrationMainName_get(void);
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2epassedOver(V, V);
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2epassedOver_clo;
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_clo;
HeffT2 g_heff_2ebuild_2etesting_2equalifierOf_24cpr(V);
V g_heff_2ebuild_2etesting_2eranJob_24s1838814540x686653986(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2eranJob_24s1838814540x686653986_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eranJob_24s1838814540x686653986_clo;
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_clo;
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2etesting_2etestArgs(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestArgs_clo;
V g_heff_2ebuild_2etesting_2etestDir(V, V);
V g_heff_2ebuild_2etesting_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestDir_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506(V, V, V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0(V, V, V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353_clo;
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_clo;
V g_heff_2ebuild_2etesting_2etestsHeld(V, V, V);
V g_heff_2ebuild_2etesting_2etestsHeld_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestsHeld_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_clo;
HeffT3 g_heff_2elsp_2ereport_2emismatch_24cpr(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_list_2eany_24s1287956370x756381573(V, V);
V g_list_2eany_24s1287956370x756381573_entry(V self, V *a);
extern Clo g_list_2eany_24s1287956370x756381573_clo;
HeffT2 g_list_2efind_24s595925281x993936542_24cpr(V, V);
V g_list_2efoldl_24s1300477078x2058851060(V, V);
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1300477078x2058851060_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s458067099x815639923(V);
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1681408447x1763680441(V, V, V);
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceDebugString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceDebugString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceDebugString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2elevelsOf_2ecut_240(V, V, V, V, V, V);
V g_regex_2elevelsOf_2ecut_240_entry(V self, V *a);
extern Clo g_regex_2elevelsOf_2ecut_240_clo;
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465(V);
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s141698176x1512134465_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_REC_LIT(g_heff_2ebuild_2etesting_2enoRes_lit0, 8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL));

static V g_heff_2ebuild_2etesting_2enoRes_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2enoRes_st;
static V g_heff_2ebuild_2etesting_2enoRes_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2enoRes_lit0);
}
V g_heff_2ebuild_2etesting_2enoRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2enoRes_st)) return g_heff_2ebuild_2etesting_2enoRes_val;
  return heff_global(&g_heff_2ebuild_2etesting_2enoRes_val, &g_heff_2ebuild_2etesting_2enoRes_st, g_heff_2ebuild_2etesting_2enoRes_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eexpectErrorsLine_str0, 22, "-- test: expect errors");

static V g_heff_2ebuild_2etesting_2eexpectErrorsLine_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eexpectErrorsLine_st;
static V g_heff_2ebuild_2etesting_2eexpectErrorsLine_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eexpectErrorsLine_str0);
}
V g_heff_2ebuild_2etesting_2eexpectErrorsLine_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eexpectErrorsLine_st)) return g_heff_2ebuild_2etesting_2eexpectErrorsLine_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eexpectErrorsLine_val, &g_heff_2ebuild_2etesting_2eexpectErrorsLine_st, g_heff_2ebuild_2etesting_2eexpectErrorsLine_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenPath_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenPath_str1, 7, ".golden");
Clo g_heff_2ebuild_2etesting_2egoldenPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenPath_entry, 3, 0};

V g_heff_2ebuild_2etesting_2egoldenPath(V v_st_240, V v_f_241, V v_name_242) {
top: ;
  int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
  V v_t_244 = heff_strSlice_lent(v_f_241, heff_box_word(v_t_243), heff_strLength_lent(v_f_241, 0), 6);
  V v_t_246;
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2etesting_2egoldenPath_str0))) {
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_f_241, 0)) - ((int64_t)3ULL));
    v_t_246 = heff_strSlice(v_f_241, MK_INT(0LL), heff_box_word(v_t_245));
  } else {
    v_t_246 = v_f_241;
  }
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2etesting_2egoldenPath_str1))));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_name_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  return ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2etesting_2egoldenPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2egoldenPath(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_str1, 3, " / ");
Clo g_heff_2ebuild_2etesting_2esubtestJobs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2esubtestJobs_entry, 4, 0};

V g_heff_2ebuild_2etesting_2esubtestJobs(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_k_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_n_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_s_246 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_247 = ({ V a_0 = v_s_246; V a_1 = ((V)&g_heff_2ebuild_2etesting_2esubtestJobs_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2esubtestJobs_str1), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_246); r_; });
    V v_t_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_244), NTAG(TAG_Nil)});
    V v_t_249 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_248, v_t_247, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2410 = ({ V a_0 = v_sel_240; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2etesting_2elevelsSelected(a_0, a_1)); heff_drop(v_t_249); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2411));
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_244, NTAG(TAG_Nil)});
      V v_t_2414 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2413));
      V v_t_2415 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2412, heff_dup(heff_rfield(v_j_241, 3)), v_t_2414, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = (g_heff_2ebuild_2etesting_2esubtestJobs_24dps(v_sel_240, v_j_241, heff_intAdd(v_k_242, MK_INT(1LL)), v_rest_245, v_cell_2416));
      heff_drop(v_u_2417);
      return v_cell_2416;
    } else {
      heff_drop(v_n_244);
      heff_drop(v_t_2410);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_245;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2etesting_2esubtestJobs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2esubtestJobs(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2epassedOver_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2epassedOver_str1, 0, "");
Clo g_heff_2ebuild_2etesting_2epassedOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2epassedOver_entry, 2, 0};

V g_heff_2ebuild_2etesting_2epassedOver(V v_opts_240, V v_os_241) {
top: ;
  if (!heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2etesting_2epassedOver_str0))) {
    V v_x1_242 = (g_list_2ekeepIf_24s458067099x815639923(heff_dup(v_os_241)));
    switch (heff_tag_of(v_x1_242)) {
    case TAG_Nil: {
      V v_p_243 = heff_get_n(v_opts_240, 1, 5);
      V v_t_2411;
      if (heff_strEq_c_lent(v_p_243, ((V)&g_heff_2ebuild_2etesting_2epassedOver_str1), 2)) {
        heff_drop(v_p_243);
        v_t_2411 = NTAG(TAG_Nil);
      } else {
        V v_t_244 = ({ V a_0 = v_p_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_False); V a_4 = MK_INT(0LL); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2elevelsOf_2ecut_240(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_243); r_; });
        V v_t_245 = (g_list_2emap_24s1007499915x73800978(v_t_244));
        HeffT2 v_t_246 = (g_regex_2eallRead_24cpr(v_t_245));
        {
          V v_field_248 = v_t_246.f[1];
          int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            V v_why_249 = v_field_248;
            heff_drop(v_why_249);
            v_t_2411 = NTAG(TAG_Nil);
          } else {
            V v_sel_2410 = v_field_248;
            v_t_2411 = v_sel_2410;
          }
        }
      }
      V v_x1_2412 = ({ V a_0 = v_t_2411; V a_1 = v_os_241; V r_ = (g_list_2eany_24s1287956370x756381573(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_os_241); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
      heff_drop(v_x1_2412);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_242, 0ULL, 2);
      heff_drop_rec(v_opts_240, 5);
      heff_drop(v_os_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_242);
    }
  } else {
    heff_drop_rec(v_opts_240, 5);
    heff_drop(v_os_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2etesting_2epassedOver_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2epassedOver(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2efilesSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efilesSaid_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2etesting_2efilesSaid_str2, 22, " with expected errors)");
HEFF_LIT(g_heff_2ebuild_2etesting_2efilesSaid_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2efilesSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2efilesSaid_str5, 27, " files check as they should");
Clo g_heff_2ebuild_2etesting_2efilesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2efilesSaid_entry, 1, 0};

V g_heff_2ebuild_2etesting_2efilesSaid(V v_r_240) {
top: ;
  V v_unchecked_241 = heff_take_field(v_r_240, 4);
  V v_expectErrors_242 = heff_take_field(v_r_240, 1);
  V v_files_243 = heff_get_n(v_r_240, 0, 8);
  V v_t_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_unchecked_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_unchecked_241); r_; });
  V v_t_246;
  if (heff_intEq_c_lent(v_expectErrors_242, MK_INT(0LL), 2)) {
    heff_drop(v_expectErrors_242);
    v_t_246 = ((V)&g_heff_2ebuild_2etesting_2efilesSaid_str0);
  } else {
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2efilesSaid_str1), heff_intShow(v_expectErrors_242));
    v_t_246 = heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2etesting_2efilesSaid_str2));
  }
  V v_t_247 = heff_intShow(heff_intSub_lent(v_files_243, v_t_244, 2));
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2efilesSaid_str3), v_t_247), ((V)&g_heff_2ebuild_2etesting_2efilesSaid_str4));
  V v_t_249 = heff_strAppend(v_t_248, heff_intShow(v_files_243));
  return heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2etesting_2efilesSaid_str5)), v_t_246);
}
V g_heff_2ebuild_2etesting_2efilesSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2efilesSaid(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str0, 6, "--seed");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str1, 5, "--run");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str2, 6, "--jobs");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str3, 6, "--fuel");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestArgs_str4, 4, "test");
Clo g_heff_2ebuild_2etesting_2etestArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestArgs_entry, 5, 0};

V g_heff_2ebuild_2etesting_2etestArgs(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_fuel_243, V v_given_244) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_247 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_245 = heff_field(v_seed_240, 0);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_245), NTAG(TAG_Nil)});
    v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str0), v_t_246});
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2410;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_248 = heff_field(v_pattern_241, 0);
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_248), NTAG(TAG_Nil)});
    v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str1), v_t_249});
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2413;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_2411 = heff_field(v_jobs_242, 0);
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_2411), NTAG(TAG_Nil)});
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str2), v_t_2412});
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_t_2414;
  if ((heff_dup(v_fuel_243) == NTAG(TAG_True))) {
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str3), NTAG(TAG_Nil)});
  } else {
    v_t_2414 = NTAG(TAG_Nil);
  }
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2414, v_given_244));
  V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2415));
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2416));
  V v_t_2418 = (g_prelude_2e_2b_2b(v_t_247, v_t_2417));
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestArgs_str4), v_t_2418});
}
V g_heff_2ebuild_2etesting_2etestArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2etesting_2etestArgs(a0, a1, a2, a3, a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_str0, 3, "src");
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_entry, 3, 0};

V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506(V v_given_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_str0)));
    V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_246 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam0_clo)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    HEFF_LAST return g_co_2eop_24s1896221640x2141527803(v_t_2411, heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam1, 1, 3, (V[]){v_z_241, v_z_242, v_path_243}));
  }
  case TAG_Cons: {
    V v_t_2423 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    V v_t_2424 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_t_2423, NTAG(TAG_Nil)));
    return heff_tail(v_t_2424, 2, (V[]){v_z_241, v_z_242});
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam2(V self, V *args) {
  V v_n_2417 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2417));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_243, v_t_2418));
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_x_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_path_243);
    return (g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0(v_z_241, v_z_242, heff_tag_re_n(v_ru_24x_2412_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2413})));
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2414)) {
    case TAG_Left: {
      V v_err_2415 = heff_field(v_y_2414, 0);
      V v_ru_24y_2414_24Left = heff_take_reuse_n(v_y_2414, 1ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_path_243);
      heff_drop_cell(v_ru_24x_2412_24Right, 1);
      return (g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0(v_z_241, v_z_242, heff_tag_re_n(v_ru_24y_2414_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2415})));
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_y_2414, 0);
      heff_take_n(v_y_2414, 1ULL, 1);
      heff_clo_take(self, 3);
      V v_x_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_lam2, 1, 1, (V[]){v_path_243}), v_x_2416));
      V v_x_2420 = (g_list_2emap_24s219049803x1458391381(v_x_2419));
      return (g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0(v_z_241, v_z_242, heff_tag_at_n(v_ru_24x_2412_24Right, TAG_Right, 1, (V[]){v_x_2420})));
    }
    default: return heff_nomatch(v_y_2414);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str0, 10, "heff-test-");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str2, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str5, 21, "no directory for it: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str6, 5, "win32");
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_entry, 6, 0};

V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095(V v_ex_240, V v_cu_241, V v_sel_242, V v_j_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s535099379x685970669(v_t_2412, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam1, 1, 6, (V[]){v_hd_244, v_j_243, v_k_245, v_ex_240, v_cu_241, heff_dup(v_sel_242)})));
}
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam0(V self, V *args) {
  V v_s_246 = args[0];
  return v_s_246;
}
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam2(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_j_243 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_ex_240 = heff_env(self)[3];
  V v_cu_241 = heff_env(self)[4];
  V v_sel_242 = heff_env(self)[5];
  V v_hd_244 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_err_2424 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_x_2413);
    heff_drop(v_ex_240);
    heff_drop(v_cu_241);
    heff_drop(v_sel_242);
    heff_drop(v_hd_244);
    V v_other_2425 = heff_take_field(v_err_2424, 4);
    V v_path_2426 = heff_take_field(v_err_2424, 3);
    V v_name_2427 = heff_take_field(v_err_2424, 1);
    V v_message_2428 = heff_get_n(v_err_2424, 2, 5);
    V v_t_2429 = v_other_2425;
    V v_t_2431;
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      v_t_2431 = ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str1);
      break;
    }
    case TAG_Just: {
      V v_x_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      v_t_2431 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str2), v_x_2430);
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(v_path_2426, v_t_2431), ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str3));
    V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, v_name_2427), ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str4));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str5), heff_strAppend(v_t_2433, v_message_2428));
    V v_x_2435 = (g_heff_2ebuild_2etesting_2ebrokenJob(v_j_243, v_t_2434));
    V f_ = v_k_245;
    args[0] = v_x_2435;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_dir_2436 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    V v_t_2437;
    heff_clo_take(self, 7);
    if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str6))) {
      v_t_2437 = NTAG(TAG_Windows);
    } else {
      v_t_2437 = NTAG(TAG_Posix);
    }
    V v_t_2438 = ({ V a_0 = v_t_2437; V a_1 = v_dir_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2437); heff_drop(v_dir_2436); r_; });
    return ({ V a_0 = v_ex_240; V a_1 = v_cu_241; V a_2 = v_sel_242; V a_3 = v_j_243; V a_4 = v_t_2438; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2ebuild_2etesting_2eranJob_24s1838814540x686653986(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sel_242); r_; });
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_j_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_ex_240 = heff_env(self)[3];
  V v_cu_241 = heff_env(self)[4];
  V v_sel_242 = heff_env(self)[5];
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_TemporaryDirectory, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_str0), ((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(((V)&g_co_2eop_24s197845728x1944963205_clo), 1, (V[]){v_t_2420}));
  V v_t_2422 = heff_tr(g_std_2efilesystem_2efromSystem_24s141698176x1512134465(v_t_2421));
  heff_clo_take(self, 6);
  V f_ = v_t_2422;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_lam3, 1, 7, (V[]){v_j_243, v_k_245, v_x_2413, v_ex_240, v_cu_241, v_sel_242, v_hd_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam1(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam1, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam3(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam3, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam8(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam8, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam11(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam11, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam10(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam10, 1, 0};
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam12(V self, V *args);
Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_entry, 11, 0};

V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(V v_lit_240, V v_ex_241, V v_rx_242, V v_cu_243, V v_sel_244, V v_jobs_245, V v_x4_246, V v_pending_247, V v_done_248, V v_z_249, V v_z_2410) {
top: ;
  switch (heff_tag_of(v_x4_246)) {
  case TAG_Nil: {
    if (heff_intEq_c_lent(v_pending_247, MK_INT(0LL), 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_ex_241);
      heff_drop(v_rx_242);
      heff_drop(v_cu_243);
      heff_drop(v_sel_244);
      heff_drop(v_jobs_245);
      heff_drop(v_pending_247);
      heff_drop(v_z_249);
      return heff_tail(v_z_2410, 1, (V[]){v_done_248});
    } else {
      V v_t_2413 = heff_tag_n(TAG_Finish, 3, (V[]){heff_dup(v_lit_240), NTAG(TAG_True), ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam0_clo)});
      V v_t_2414 = heff_tr(heff_call(heff_dup(v_rx_242), 1, (V[]){v_t_2413}));
      return (g_co_2eop_24s535099379x685970669(v_t_2414, heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam2, 1, 10, (V[]){v_done_248, v_lit_240, v_ex_241, v_rx_242, v_cu_243, v_sel_244, v_jobs_245, v_pending_247, v_z_249, v_z_2410})));
    }
  }
  case TAG_Cons: {
    V v_j_2420 = heff_field(v_x4_246, 0);
    V v_rest_2421 = heff_field(v_x4_246, 1);
    heff_take_n(v_x4_246, 3ULL, 2);
    if (heff_intLt_c_lent(v_pending_247, v_jobs_245, 0)) {
      V v_lit_2422 = heff_dup(v_lit_240);
      V v_rx_2423 = heff_dup(v_rx_242);
      V v_c_2424 = heff_tr(heff_call(((V)&g_heff_2ebuild_2etesting_2erunJob_24s1330029059x1777493095_clo), 4, (V[]){heff_dup(v_ex_241), heff_dup(v_cu_243), heff_dup(v_sel_244), v_j_2420}));
      V v_t_2426 = heff_tr(heff_call(heff_dup(v_rx_2423), 1, (V[]){heff_tag_n(TAG_Begin, 2, (V[]){heff_dup(v_lit_2422), ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam3_clo)})}));
      V v_c_2434 = heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam4, 2, 4, (V[]){v_t_2426, v_c_2424, v_rx_2423, v_lit_2422});
      return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam9, 1, 11, (V[]){v_lit_240, v_ex_241, v_rx_242, v_cu_243, v_sel_244, v_jobs_245, v_rest_2421, v_pending_247, v_done_248, v_z_249, v_z_2410})});
    } else {
      V v_t_2440 = heff_tag_n(TAG_Finish, 3, (V[]){heff_dup(v_lit_240), NTAG(TAG_True), ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam10_clo)});
      V v_t_2441 = heff_tr(heff_call(heff_dup(v_rx_242), 1, (V[]){v_t_2440}));
      return (g_co_2eop_24s535099379x685970669(v_t_2441, heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam12, 1, 12, (V[]){v_rest_2421, v_done_248, v_lit_240, v_ex_241, v_rx_242, v_cu_243, v_sel_244, v_jobs_245, v_j_2420, v_pending_247, v_z_249, v_z_2410})));
    }
  }
  default: return heff_nomatch(v_x4_246);
  }
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam1(V self, V *args) {
  V v_l_2412 = args[0];
  return v_l_2412;
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam0(V self, V *args) {
  V v_use_2411 = args[0];
  V f_ = v_use_2411;
  args[0] = ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam1_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_done_248 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_ex_241 = heff_env(self)[2];
  V v_rx_242 = heff_env(self)[3];
  V v_cu_243 = heff_env(self)[4];
  V v_sel_244 = heff_env(self)[5];
  V v_jobs_245 = heff_env(self)[6];
  V v_pending_247 = heff_env(self)[7];
  V v_z_249 = heff_env(self)[8];
  V v_z_2410 = heff_env(self)[9];
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2415)));
  V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2415));
  heff_clo_take(self, 10);
  V v_t_2419 = (g_prelude_2e_2b_2b(v_x_2415, v_done_248));
  return (g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(v_lit_240, v_ex_241, v_rx_242, v_cu_243, v_sel_244, v_jobs_245, v_t_2417, heff_intSub(v_pending_247, v_t_2418), v_t_2419, v_z_249, v_z_2410));
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam3(V self, V *args) {
  V v_b_2425 = args[0];
  return v_b_2425;
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam8(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam7(V self, V *args) {
  V v_use_2431 = args[0];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_use_2431;
  heff_room[0] = v_x_2430;
  heff_room[1] = ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam8_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_rx_2423 = heff_env(self)[0];
  V v_lit_2422 = heff_env(self)[1];
  V v_hd_2427 = heff_env(self)[2];
  V v_k_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2433 = heff_tr(heff_call(v_rx_2423, 1, (V[]){heff_tag_n(TAG_End, 2, (V[]){v_lit_2422, heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam7, 1, 1, (V[]){v_x_2430})})}));
  return (g_co_2eop_24s535099379x685970669(v_t_2433, v_hd_2427, v_k_2428));
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_c_2424 = heff_env(self)[0];
  V v_hd_2427 = heff_env(self)[1];
  V v_rx_2423 = heff_env(self)[2];
  V v_lit_2422 = heff_env(self)[3];
  V v_k_2428 = heff_env(self)[4];
  if ((heff_dup(v_x_2429) == NTAG(TAG_True))) {
    heff_drop(v_x_2429);
    heff_clo_take(self, 5);
    V f_ = v_c_2424;
    heff_room[0] = heff_dup(v_hd_2427);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam6, 1, 4, (V[]){v_rx_2423, v_lit_2422, v_hd_2427, v_k_2428});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2429);
    heff_clo_take(self, 5);
    heff_drop(v_c_2424);
    heff_drop(v_hd_2427);
    heff_drop(v_rx_2423);
    heff_drop(v_lit_2422);
    V f_ = v_k_2428;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_t_2426 = heff_env(self)[0];
  V v_c_2424 = heff_env(self)[1];
  V v_rx_2423 = heff_env(self)[2];
  V v_lit_2422 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2426, heff_dup(v_hd_2427), heff_clo_n(g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam5, 1, 5, (V[]){v_c_2424, v_hd_2427, v_rx_2423, v_lit_2422, v_k_2428})));
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam9(V self, V *args) {
  V v_x_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_ex_241 = heff_env(self)[1];
  V v_rx_242 = heff_env(self)[2];
  V v_cu_243 = heff_env(self)[3];
  V v_sel_244 = heff_env(self)[4];
  V v_jobs_245 = heff_env(self)[5];
  V v_rest_2421 = heff_env(self)[6];
  V v_pending_247 = heff_env(self)[7];
  V v_done_248 = heff_env(self)[8];
  V v_z_249 = heff_env(self)[9];
  V v_z_2410 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Nothing: {
    heff_clo_take(self, 11);
    return (g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(v_lit_240, v_ex_241, v_rx_242, v_cu_243, v_sel_244, v_jobs_245, v_rest_2421, heff_intAdd(v_pending_247, MK_INT(1LL)), v_done_248, v_z_249, v_z_2410));
  }
  case TAG_Just: {
    V v_f_2436 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 1);
    heff_clo_take(self, 11);
    V v_t_2437 = (g_prelude_2e_2b_2b(v_rest_2421, heff_dup(heff_rfield(v_f_2436, 3))));
    return (g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(v_lit_240, v_ex_241, v_rx_242, v_cu_243, v_sel_244, v_jobs_245, v_t_2437, v_pending_247, heff_tag_n(TAG_Cons, 2, (V[]){v_f_2436, v_done_248}), v_z_249, v_z_2410));
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam11(V self, V *args) {
  V v_l_2439 = args[0];
  return v_l_2439;
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam10(V self, V *args) {
  V v_use_2438 = args[0];
  V f_ = v_use_2438;
  args[0] = ((V)&g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam11_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_lam12(V self, V *args) {
  V v_x_2442 = args[0];
  V v_rest_2421 = heff_env(self)[0];
  V v_done_248 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_ex_241 = heff_env(self)[3];
  V v_rx_242 = heff_env(self)[4];
  V v_cu_243 = heff_env(self)[5];
  V v_sel_244 = heff_env(self)[6];
  V v_jobs_245 = heff_env(self)[7];
  V v_j_2420 = heff_env(self)[8];
  V v_pending_247 = heff_env(self)[9];
  V v_z_249 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2442)));
  V v_ys_2444 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2443; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2443); r_; });
  heff_clo_take(self, 12);
  V v_t_2445 = (g_prelude_2e_2b_2b(v_rest_2421, v_ys_2444));
  V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2442));
  V v_t_2447 = (g_prelude_2e_2b_2b(v_x_2442, v_done_248));
  return (g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(v_lit_240, v_ex_241, v_rx_242, v_cu_243, v_sel_244, v_jobs_245, heff_tag_n(TAG_Cons, 2, (V[]){v_j_2420, v_t_2445}), heff_intSub(v_pending_247, v_t_2446), v_t_2447, v_z_249, v_z_2410));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str3, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str10, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str11, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str12, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str13, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str14, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str15, 1, "\"");
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_entry, 7, 0};

V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487(V v_lit_240, V v_update_241, V v_dir_242, V v_path_243, V v_text_244, V v_z_245, V v_z_246) {
top: ;
  if (heff_strEq_c_lent(v_lit_240, v_text_244, 0)) {
    heff_drop(v_path_243);
    heff_drop(v_text_244);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_Holds)});
  } else {
    if ((heff_dup(v_update_241) == NTAG(TAG_True))) {
      V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_243)));
      V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
      V v_a_2410 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_248, v_text_244, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_lam0_clo)});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2415, v_z_245, heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_lam1, 1, 2, (V[]){v_path_243, v_z_246})));
    } else {
      heff_drop(v_z_245);
      V v_t_2423 = (g_prelude_2esplit_2esplitFrom_240(v_lit_240, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str4), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str5), v_lit_240, MK_INT(0LL), 5), NTAG(TAG_Nil)));
      V v_t_2424 = ({ V a_0 = v_text_244; V a_1 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str7), v_text_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_244); r_; });
      HeffT3 v_t_2425 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2423; V a_2 = v_t_2424; HeffT3 r_ = (g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2423); heff_drop(v_t_2424); r_; });
      {
        V v_field_2426 = v_t_2425.f[0];
        V v_field_2427 = v_t_2425.f[1];
        V v_field_2428 = v_t_2425.f[2];
        V v_n_2429 = v_field_2426;
        V v_kept_2430 = v_field_2427;
        V v_text_2431 = v_field_2428;
        V v_t_2432 = ({ V a_0 = v_kept_2430; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str8); V r_ = (g_prelude_2einstanceDebugString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2430); r_; });
        V v_t_2433 = ({ V a_0 = v_text_2431; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str9); V r_ = (g_prelude_2einstanceDebugString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2431); r_; });
        V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str10), v_path_243), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str11));
        V v_t_2435 = heff_strAppend(v_t_2434, heff_intShow(v_n_2429));
        V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str12), v_t_2432), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str13));
        V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str14), v_t_2433), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str15));
        V v_x_2438 = heff_tag_n(TAG_Wrong, 2, (V[]){v_t_2435, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2436, v_t_2437})});
        return heff_tail(v_z_246, 1, (V[]){v_x_2438});
      }
    }
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487(a0, a1, a2, a[3], a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 0ULL, 1);
    heff_clo_take(self, 2);
    V v_t_2418 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str0), v_path_243), heff_tag_at_n(v_ru_24x_2416_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str1)})});
    V f_ = v_z_246;
    args[0] = v_t_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2419 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2419)) {
    case TAG_Left: {
      heff_take_n(v_y_2419, 0ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2421 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str2), v_path_243), heff_tag_at_n(v_ru_24x_2416_24Right, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_str3)})});
      V f_ = v_z_246;
      args[0] = v_t_2421;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2419, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2416_24Right, 1);
      heff_clo_take(self, 2);
      V f_ = v_z_246;
      args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_243});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2419);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str2, 2, " (");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str3, 1, ")");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str4, 5, "FAIL ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str7, 12, "\012  expected ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str8, 12, "\012  but got  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str9, 12, "\012  diff     ");
HEFF_LIT(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str10, 1, "\012");
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_entry, 5, 0};

V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025(V v_f_240, V v_color_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_color_241);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_f_247 = heff_dup(v_f_240);
    V v_r_248 = heff_dup(v_r_245);
    V v_owner_249 = heff_take_field(v_r_248, 0);
    V v_line_2410 = heff_take_field(v_r_248, 1);
    V v_watch_2411 = heff_get_n(v_r_248, 2, 3);
    V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 5, 10);
    V v_t_2414;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      v_t_2414 = ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2415 = heff_get_n(heff_get_n(v_r_245, 2, 3), 4, 10);
    HeffT3 v_t_2416 = ({ V a_0 = v_color_241; V a_1 = v_t_2414; V a_2 = v_t_2415; HeffT3 r_ = (g_heff_2elsp_2ereport_2emismatch_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2414); heff_drop(v_t_2415); r_; });
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_field_2419 = v_t_2416.f[2];
      V v_t_2420 = v_owner_249;
      V v_t_2422;
      switch (heff_tag_of(v_t_2420)) {
      case TAG_Nothing: {
        v_t_2422 = ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str1);
        break;
      }
      case TAG_Just: {
        V v_n_2421 = heff_field(v_t_2420, 0);
        heff_take_n(v_t_2420, 1ULL, 1);
        v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str2), v_n_2421), ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str3));
        break;
      }
      default: heff_nomatch(v_t_2420);
      }
      V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str4), v_f_247), ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str5));
      V v_t_2424 = heff_strAppend(v_t_2423, heff_intShow(v_line_2410));
      V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, v_t_2422), ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str6));
      V v_t_2426 = heff_strAppend(v_t_2425, heff_get_n(v_watch_2411, 2, 10));
      V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str7)), v_field_2417);
      V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str8)), v_field_2418);
      V v_str_2429 = heff_strAppend(heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str9)), v_field_2419);
      V v_lit_2430 = v_f_240;
      V v_lit_2431 = v_color_241;
      V v_lit_2432 = v_rest_246;
      V v_lit_2433 = heff_dup(v_z_243);
      V v_lit_2434 = v_z_244;
      V v_t_2435 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_str_2429, ((V)&g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_str10)), NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
      V v_p_2441 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2440});
      V v_hd_2442 = v_z_243;
      V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam0, 2, 1, (V[]){heff_dup(v_hd_2442)})}), heff_clo_n(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam2, 1, 1, (V[]){heff_dup(v_hd_2442)}), v_p_2441}));
      V v_t_2449 = heff_tr(heff_call(heff_take_field(v_hd_2442, 2), 1, (V[]){v_t_2448}));
      return heff_tail(heff_get_n(v_hd_2442, 1, 3), 2, (V[]){v_t_2449, heff_clo_n(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam3, 1, 5, (V[]){v_lit_2430, v_lit_2431, v_lit_2432, v_lit_2433, v_lit_2434})});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam1(V self, V *args) {
  V v_x_2445 = args[0];
  V v_g_2443 = heff_env(self)[0];
  V v_hd_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tr(heff_call(v_g_2443, 1, (V[]){v_x_2445}));
  V f_ = heff_get_n(v_hd_2442, 0, 3);
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam0(V self, V *args) {
  V v_g_2443 = args[0];
  V v_m_2444 = args[1];
  V v_hd_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2442, 1));
  args[0] = v_m_2444;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam1, 1, 2, (V[]){v_g_2443, v_hd_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam2(V self, V *args) {
  V v_c_2447 = args[0];
  V v_hd_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2447;
  heff_room[0] = heff_dup(v_hd_2442);
  heff_room[1] = heff_get_n(v_hd_2442, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025_lam3(V self, V *args) {
  V v_a_2450 = args[0];
  V v_lit_2430 = heff_env(self)[0];
  V v_lit_2431 = heff_env(self)[1];
  V v_lit_2432 = heff_env(self)[2];
  V v_lit_2433 = heff_env(self)[3];
  V v_lit_2434 = heff_env(self)[4];
  heff_drop(v_a_2450);
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2etesting_2eprintFails_24s1530828639x948122025(v_lit_2430, v_lit_2431, v_lit_2432, v_lit_2433, v_lit_2434));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str0, 40, "files that do not check as they should:\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str3, 27, "heff test: no tests match '");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str4, 1, "'");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str6, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str7, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str9, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str10, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str11, 1, "\012");
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_entry, 4, 0};

V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796(V v_opts_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  V v_ws_244 = heff_dup(heff_rfield(v_acc_241, 4));
  V v_t_2419;
  switch (heff_tag_of(v_ws_244)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam0_clo);
    break;
  }
  case TAG_Cons: {
    v_t_2419 = heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam1, 2, 1, (V[]){v_ws_244});
    break;
  }
  default: heff_nomatch(v_ws_244);
  }
  return heff_tail(v_t_2419, 2, (V[]){heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam3, 1, 4, (V[]){v_opts_240, v_acc_241, v_p_242, v_p_243})});
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ws_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_drop(v_x_2417);
  heff_clo_take(self, 3);
  V v_t_2418 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str1), v_ws_244));
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633(v_t_2418, v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_ws_244 = heff_env(self)[0];
  V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str0), NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  heff_clo_take(self, 1);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam2, 1, 3, (V[]){v_ws_244, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam6(V self, V *args) {
  V v_x_2450 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_drop(v_x_2450);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 3)))) {
    heff_clo_take(self, 3);
    heff_drop_rec(v_acc_241, 8);
    V v_t_2451 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), v_p_242, v_p_243));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 6)))) {
      heff_clo_take(self, 3);
      heff_drop_rec(v_acc_241, 8);
      V v_t_2457 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2462}), v_p_242, v_p_243));
    } else {
      heff_clo_take(self, 3);
      V v_t_2463 = heff_get_n(v_acc_241, 4, 8);
      switch (heff_tag_of(v_t_2463)) {
      case TAG_Nil: {
        heff_drop(v_p_242);
        V f_ = v_p_243;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2463_24Cons = heff_take_reuse_n(v_t_2463, 0ULL, 2);
        V v_t_2466 = heff_tag_at_n(v_ru_24t_2463_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
        V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
        V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
        V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
        V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_p_242, v_p_243));
      }
      default: return heff_nomatch(v_t_2463);
      }
    }
  }
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_drop(v_x_2436);
  V v_t_2437 = (g_heff_2ebuild_2etesting_2etestsHeld(heff_dup(heff_rfield(v_acc_241, 5)), heff_dup(heff_rfield(v_acc_241, 6)), heff_dup(heff_rfield(v_acc_241, 7))));
  V v_t_2438 = (g_heff_2ebuild_2etesting_2efilesSaid(heff_dup(v_acc_241)));
  V v_t_2439 = heff_intSub(heff_dup(heff_rfield(v_acc_241, 2)), heff_dup(heff_rfield(v_acc_241, 3)));
  V v_t_2440 = heff_strAppend(heff_intShow(v_t_2439), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str6));
  V v_t_2441 = heff_intShow(heff_dup(heff_rfield(v_acc_241, 2)));
  V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2440, v_t_2441), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str7));
  V v_str_2443 = heff_strAppend(heff_strAppend(v_t_2442, v_t_2437), v_t_2438);
  V v_t_2444 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2443, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str8)), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam6, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243})));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam5, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243})));
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam7(V self, V *args) {
  V v_x_2485 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_drop(v_x_2485);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 3)))) {
    heff_clo_take(self, 3);
    heff_drop_rec(v_acc_241, 8);
    V v_t_2486 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2491}), v_p_242, v_p_243));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_241, 6)))) {
      heff_clo_take(self, 3);
      heff_drop_rec(v_acc_241, 8);
      V v_t_2492 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
      V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
      V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
      V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2497}), v_p_242, v_p_243));
    } else {
      heff_clo_take(self, 3);
      V v_t_2498 = heff_get_n(v_acc_241, 4, 8);
      switch (heff_tag_of(v_t_2498)) {
      case TAG_Nil: {
        heff_drop(v_p_242);
        V f_ = v_p_243;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2498_24Cons = heff_take_reuse_n(v_t_2498, 0ULL, 2);
        V v_t_24101 = heff_tag_at_n(v_ru_24t_2498_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
        V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
        V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
        V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
        V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24106}), v_p_242, v_p_243));
      }
      default: return heff_nomatch(v_t_2498);
      }
    }
  }
}
V g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_drop(v_x_2420);
  if ((heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str2)) ? 0 : heff_intEq_c(heff_dup(heff_rfield(v_acc_241, 5)), MK_INT(0LL)))) {
    heff_clo_take(self, 4);
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str3), heff_get_n(v_opts_240, 1, 5));
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str4)), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str5));
    V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam4, 1, 3, (V[]){v_p_242, v_acc_241, v_p_243})));
  } else {
    heff_clo_take(self, 4);
    heff_drop_rec(v_opts_240, 5);
    V v_t_2472 = (g_heff_2ebuild_2etesting_2etestsHeld(heff_dup(heff_rfield(v_acc_241, 5)), heff_dup(heff_rfield(v_acc_241, 6)), heff_dup(heff_rfield(v_acc_241, 7))));
    V v_t_2473 = (g_heff_2ebuild_2etesting_2efilesSaid(heff_dup(v_acc_241)));
    V v_t_2474 = heff_intSub(heff_dup(heff_rfield(v_acc_241, 2)), heff_dup(heff_rfield(v_acc_241, 3)));
    V v_t_2475 = heff_strAppend(heff_intShow(v_t_2474), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str9));
    V v_t_2476 = heff_intShow(heff_dup(heff_rfield(v_acc_241, 2)));
    V v_t_2477 = heff_strAppend(heff_strAppend(v_t_2475, v_t_2476), ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str10));
    V v_str_2478 = heff_strAppend(heff_strAppend(v_t_2477, v_t_2472), v_t_2473);
    V v_t_2479 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2478, ((V)&g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_str11)), NTAG(TAG_MkUnit)});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2484}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestSummary_24s1483831505x2008121796_lam7, 1, 3, (V[]){v_acc_241, v_p_242, v_p_243})));
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str2, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str3, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str4, 13, "Integrations\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str5, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str6, 17, "integrationMain [");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str7, 2, "]\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str8, 19, ": integration tests");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str9, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str10, 4, "main");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str11, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str12, 4, "main");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str13, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str14, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str15, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str16, 9, "heff test");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str18, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str19, 1, "1");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str20, 14, "HEFF_TEST_ROOT");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str21, 4, "HEFF");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str22, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str23, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str24, 45, "its file does not import check, which runs it");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str25, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str26, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str27, 34, "its file is not among those loaded");
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam12(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam12, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam14(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam14, 1, 0};
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam16(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam15(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam13(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam11(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam21(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam20(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam19(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam18(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam17(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam23(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam22(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam25(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam24(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam27(V self, V *args);
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam26(V self, V *args);
Clo g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_entry, 6, 0};

V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891(V v_opts_240, V v_at_241, V v_p_242, V v_k_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_242, 5)), 0, 5);
  HeffT2 v_t_247 = ({ V a_0 = v_p_242; V a_1 = v_t_246; HeffT2 r_ = (g_list_2efind_24s595925281x993936542_24cpr(a_0, a_1)); heff_drop(v_t_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_src_2410 = v_field_249;
      V v_p_2411 = heff_dup(v_p_242);
      V v_loaded_2412 = heff_take_field(v_p_2411, 5);
      V v_checked_2413 = heff_get_n(v_p_2411, 6, 7);
      V v_src_2414 = v_src_2410;
      V v_implicit_2415 = heff_take_field(v_src_2414, 6);
      V v_source_2416 = heff_take_field(v_src_2414, 4);
      V v_renames_2417 = heff_get_n(v_src_2414, 5, 8);
      V v_t_2418 = ({ V a_0 = v_implicit_2415; V a_1 = v_source_2416; V r_ = (g_heff_2esyntax_2eimport_2eimportsOf(a_0, a_1)); heff_drop(v_source_2416); r_; });
      HeffT4 v_t_2419 = ({ V a_0 = v_renames_2417; V a_1 = v_t_2418; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(a_0, a_1)); heff_drop(v_renames_2417); r_; });
      {
        V v_field_2420 = v_t_2419.f[0];
        heff_drop(v_t_2419.f[1]);
        heff_drop(v_t_2419.f[2]);
        heff_drop(v_t_2419.f[3]);
        HeffT2 v_t_2424 = ({ V a_0 = v_field_2420; HeffT2 r_ = (g_heff_2ebuild_2etesting_2equalifierOf_24cpr(a_0)); heff_drop(v_field_2420); r_; });
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            V v_q_2427 = v_field_2426;
            V v_l_2428 = heff_dup(v_loaded_2412);
            V v_q_2429 = v_q_2427;
            V v_ts_2430 = (g_heff_2ebuild_2edriver_2etestsOf(heff_dup(v_checked_2413)));
            V v_x2_2431 = (g_list_2emap_24s467798769x1763085075(v_ts_2430));
            V v_t_2434;
            switch (heff_tag_of(v_x2_2431)) {
            case TAG_Nil: {
              v_t_2434 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str0);
              break;
            }
            case TAG_Cons: {
              V v_x_2432 = heff_field(v_x2_2431, 0);
              V v_xs_2433 = heff_field(v_x2_2431, 1);
              heff_take_n(v_x2_2431, 3ULL, 2);
              v_t_2434 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str1); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2431);
            }
            V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str2), heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str3));
            V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, heff_dup(v_q_2429)), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str4));
            V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str5));
            V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, v_q_2429), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str6));
            V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2438, v_t_2434), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str7));
            V v_sources_2440 = ({ V b_0 = heff_get_n(v_checked_2413, 0, 14); V a_1 = v_t_2439; V a_2 = heff_get_n(v_loaded_2412, 0, 5); V r_ = (g_list_2emap_24s1681408447x1763680441(b_0, a_1, a_2)); heff_drop(b_0); r_; });
            V v_l_2441 = ({ V rv_0 = v_sources_2440; V rr_ = heff_rec_reuse_nf(v_l_2428, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2442 = heff_strAppend(heff_dup(heff_rfield(v_p_242, 0)), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str8));
            V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2442, MK_INT(2LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam0_clo)})});
            V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
            return (g_co_2eop_24s535099379x685970669(v_t_2445, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam1, 1, 7, (V[]){v_z_244, v_l_2441, v_p_242, v_opts_240, v_k_243, v_at_241, v_z_245})));
          } else {
            heff_drop(v_at_241);
            heff_drop_rec(v_loaded_2412, 5);
            heff_drop_rec(v_checked_2413, 14);
            heff_drop(v_field_2426);
            V v_why_24147 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str24);
            V v_more_24148 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str25), v_why_24147, MK_INT(0LL), heff_dup(heff_rfield(v_p_242, 4))));
            V v_t_24149 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_242, 3)), v_more_24148));
            V v_c_24150 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(heff_rfield(v_p_242, 0)), v_t_24149));
            return heff_tail(v_c_24150, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam24, 1, 5, (V[]){v_opts_240, v_k_243, v_z_244, v_z_245, v_p_242})});
          }
        }
      }
    } else {
      heff_drop(v_at_241);
      heff_drop(v_field_249);
      V v_more_24154 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str26), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str27), MK_INT(0LL), heff_dup(heff_rfield(v_p_242, 4))));
      V v_t_24155 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_242, 3)), v_more_24154));
      V v_c_24156 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(heff_rfield(v_p_242, 0)), v_t_24155));
      return heff_tail(v_c_24156, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam26, 1, 5, (V[]){v_opts_240, v_k_243, v_z_244, v_z_245, v_p_242})});
    }
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam0(V self, V *args) {
  V v_t_2443 = args[0];
  return v_t_2443;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam2(V self, V *args) {
  V v_t_2447 = args[0];
  return v_t_2447;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam4(V self, V *args) {
  V v_r_2471 = args[0];
  return v_r_2471;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam8(V self, V *args) {
  V v_x_2487 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_hd_2477 = heff_env(self)[1];
  V v_k_2478 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2487});
  heff_room[1] = v_hd_2477;
  heff_room[2] = v_k_2478;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam7(V self, V *args) {
  V v_x_2485 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_hd_2477 = heff_env(self)[2];
  V v_k_2478 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2486 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_240, heff_dup(v_x_2485)));
  if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
    heff_drop(v_x_2485);
    heff_drop_rec(v_p_242, 7);
    heff_drop(v_t_2486);
    V f_ = v_k_243;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_hd_2477;
    heff_room[2] = v_k_2478;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2486);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1)), heff_get_n(v_p_242, 2, 7), v_x_2485, heff_dup(v_hd_2477), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam8, 1, 3, (V[]){v_k_243, v_hd_2477, v_k_2478})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam6(V self, V *args) {
  V v_x_2481 = args[0];
  V v_why_2476 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_hd_2477 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_k_2478 = heff_env(self)[5];
  heff_drop(v_x_2481);
  heff_clo_take(self, 6);
  V v_more_2482 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str15), v_why_2476, MK_INT(0LL), heff_dup(heff_rfield(v_p_242, 4))));
  V v_t_2483 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_242, 3)), v_more_2482));
  V v_t_2484 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(heff_rfield(v_p_242, 0)), v_t_2483));
  V f_ = v_t_2484;
  heff_room[0] = heff_dup(v_hd_2477);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam7, 1, 5, (V[]){v_opts_240, v_k_243, v_hd_2477, v_k_2478, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam5(V self, V *args) {
  V v_why_2476 = args[0];
  V v_hd_2477 = args[1];
  V v_k_2478 = args[2];
  V v_x_2446 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2479 = heff_tag_n(TAG_End, 2, (V[]){v_x_2446, NTAG(TAG_MkUnit)});
  V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2480}), heff_dup(v_hd_2477), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam6, 1, 6, (V[]){v_why_2476, v_p_242, v_opts_240, v_hd_2477, v_k_243, v_k_2478})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam12(V self, V *args) {
  V v_r_2494 = args[0];
  return v_r_2494;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam14(V self, V *args) {
  V v_r_24102 = args[0];
  return v_r_24102;
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam16(V self, V *args) {
  V v_x_24109 = args[0];
  V v_x_2490 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  V v_x_2498 = heff_env(self)[2];
  V v_x_2491 = heff_env(self)[3];
  V v_x_24106 = heff_env(self)[4];
  V v_at_241 = heff_env(self)[5];
  V v_p_242 = heff_env(self)[6];
  V v_k_243 = heff_env(self)[7];
  V v_hd_2488 = heff_env(self)[8];
  V v_k_2489 = heff_env(self)[9];
  heff_drop(v_x_24109);
  V v_t_24113;
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2490)) {
  case TAG_Left: {
    heff_take_n(v_x_2490, 0ULL, 1);
    v_t_24113 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str17);
    break;
  }
  case TAG_Right: {
    V v_real_24111 = heff_field(v_x_2490, 0);
    heff_take_n(v_x_2490, 1ULL, 1);
    V v_t_24112 = heff_get_n(heff_dup(heff_rfield(v_l_2441, 2)), 5, 6);
    v_t_24113 = ({ V a_0 = v_t_24112; V a_1 = v_real_24111; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24112); heff_drop(v_real_24111); r_; });
    break;
  }
  default: heff_nomatch(v_x_2490);
  }
  V v_t_24117;
  switch (heff_tag_of(v_x_2498)) {
  case TAG_Left: {
    heff_take_n(v_x_2498, 0ULL, 1);
    v_t_24117 = v_x_2491;
    break;
  }
  case TAG_Right: {
    V v_real_24115 = heff_field(v_x_2498, 0);
    heff_take_n(v_x_2498, 1ULL, 1);
    heff_drop(v_x_2491);
    V v_t_24116 = heff_get_n(heff_dup(heff_rfield(v_l_2441, 2)), 5, 6);
    v_t_24117 = ({ V a_0 = v_t_24116; V a_1 = v_real_24115; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24116); heff_drop(v_real_24115); r_; });
    break;
  }
  default: heff_nomatch(v_x_2498);
  }
  V v_t_24121;
  switch (heff_tag_of(v_x_24106)) {
  case TAG_Left: {
    heff_take_n(v_x_24106, 0ULL, 1);
    v_t_24121 = heff_get_n(heff_get_n(v_l_2441, 2, 5), 0, 6);
    break;
  }
  case TAG_Right: {
    V v_real_24119 = heff_field(v_x_24106, 0);
    heff_take_n(v_x_24106, 1ULL, 1);
    V v_t_24120 = heff_get_n(heff_get_n(v_l_2441, 2, 5), 5, 6);
    v_t_24121 = ({ V a_0 = v_t_24120; V a_1 = v_real_24119; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24120); heff_drop(v_real_24119); r_; });
    break;
  }
  default: heff_nomatch(v_x_24106);
  }
  V v_t_24122 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str18), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str19)}), NTAG(TAG_Nil)});
  V v_t_24123 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str20), v_t_24121}), v_t_24122});
  V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str21), v_t_24117}), v_t_24123});
  V v_t_24125 = heff_rec_n(3, shape_at__pending__launch, (V[]){v_at_241, v_p_242, heff_rec_n(2, shape_program__env, (V[]){v_t_24113, v_t_24124})});
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Later, 1, (V[]){v_t_24125});
  heff_room[1] = v_hd_2488;
  heff_room[2] = v_k_2489;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam15(V self, V *args) {
  V v_x_24106 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_hd_2488 = heff_env(self)[1];
  V v_x_2490 = heff_env(self)[2];
  V v_l_2441 = heff_env(self)[3];
  V v_x_2498 = heff_env(self)[4];
  V v_x_2491 = heff_env(self)[5];
  V v_at_241 = heff_env(self)[6];
  V v_p_242 = heff_env(self)[7];
  V v_k_243 = heff_env(self)[8];
  V v_k_2489 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_24107 = heff_tag_n(TAG_End, 2, (V[]){v_x_2446, NTAG(TAG_MkUnit)});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24108}), heff_dup(v_hd_2488), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam16, 1, 10, (V[]){v_x_2490, v_l_2441, v_x_2498, v_x_2491, v_x_24106, v_at_241, v_p_242, v_k_243, v_hd_2488, v_k_2489})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam13(V self, V *args) {
  V v_x_2498 = args[0];
  V v_l_2441 = heff_env(self)[0];
  V v_hd_2488 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  V v_x_2490 = heff_env(self)[3];
  V v_x_2491 = heff_env(self)[4];
  V v_at_241 = heff_env(self)[5];
  V v_p_242 = heff_env(self)[6];
  V v_k_243 = heff_env(self)[7];
  V v_k_2489 = heff_env(self)[8];
  V v_t_2499 = heff_get_n(heff_dup(heff_rfield(v_l_2441, 2)), 0, 6);
  V v_path_24100 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_t_2499));
  V v_t_24101 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24100; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24100); r_; });
  V v_p_231000_24103 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_24101, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam14_clo)});
  V v_t_24104 = heff_tr(heff_call(((V)&g_co_2eop_24s1412293101x300983667_clo), 1, (V[]){v_p_231000_24103}));
  V v_t_24105 = heff_tr(g_std_2efilesystem_2efromSystem_24s141698176x1512134465(v_t_24104));
  heff_clo_take(self, 9);
  V f_ = v_t_24105;
  heff_room[0] = heff_dup(v_hd_2488);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam15, 1, 10, (V[]){v_x_2446, v_hd_2488, v_x_2490, v_l_2441, v_x_2498, v_x_2491, v_at_241, v_p_242, v_k_243, v_k_2489});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam11(V self, V *args) {
  V v_x_2491 = args[0];
  V v_hd_2488 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  V v_x_2490 = heff_env(self)[3];
  V v_at_241 = heff_env(self)[4];
  V v_p_242 = heff_env(self)[5];
  V v_k_243 = heff_env(self)[6];
  V v_k_2489 = heff_env(self)[7];
  V v_path_2492 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2491)));
  V v_t_2493 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2492; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2492); r_; });
  V v_p_231000_2495 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2493, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam12_clo)});
  V v_t_2496 = heff_tr(heff_call(((V)&g_co_2eop_24s1412293101x300983667_clo), 1, (V[]){v_p_231000_2495}));
  V v_t_2497 = heff_tr(g_std_2efilesystem_2efromSystem_24s141698176x1512134465(v_t_2496));
  heff_clo_take(self, 8);
  V f_ = v_t_2497;
  heff_room[0] = heff_dup(v_hd_2488);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam13, 1, 9, (V[]){v_l_2441, v_hd_2488, v_x_2446, v_x_2490, v_x_2491, v_at_241, v_p_242, v_k_243, v_k_2489});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam10(V self, V *args) {
  V v_x_2490 = args[0];
  V v_hd_2488 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  V v_at_241 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  V v_k_2489 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(heff_dup(v_hd_2488), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam11, 1, 8, (V[]){v_hd_2488, v_l_2441, v_x_2446, v_x_2490, v_at_241, v_p_242, v_k_243, v_k_2489})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam9(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2474 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  V v_at_241 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2474;
  args[0] = heff_dup(v_hd_2488);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam10, 1, 7, (V[]){v_hd_2488, v_l_2441, v_x_2446, v_at_241, v_p_242, v_k_243, v_k_2489});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam21(V self, V *args) {
  V v_x_24141 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_hd_24128 = heff_env(self)[1];
  V v_k_24129 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24141});
  heff_room[1] = v_hd_24128;
  heff_room[2] = v_k_24129;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam20(V self, V *args) {
  V v_x_24139 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_hd_24128 = heff_env(self)[2];
  V v_k_24129 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24140 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_240, heff_dup(v_x_24139)));
  if ((heff_dup(v_t_24140) == NTAG(TAG_True))) {
    heff_drop(v_x_24139);
    heff_drop_rec(v_p_242, 7);
    heff_drop(v_t_24140);
    V f_ = v_k_243;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_hd_24128;
    heff_room[2] = v_k_24129;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24140);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1)), heff_get_n(v_p_242, 2, 7), v_x_24139, heff_dup(v_hd_24128), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam21, 1, 3, (V[]){v_k_243, v_hd_24128, v_k_24129})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam19(V self, V *args) {
  V v_x_24135 = args[0];
  V v_why_24127 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_hd_24128 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_k_24129 = heff_env(self)[5];
  heff_drop(v_x_24135);
  heff_clo_take(self, 6);
  V v_more_24136 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str22), v_why_24127, MK_INT(0LL), heff_dup(heff_rfield(v_p_242, 4))));
  V v_t_24137 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_242, 3)), v_more_24136));
  V v_t_24138 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(heff_dup(heff_rfield(v_opts_240, 3)), heff_dup(heff_rfield(v_p_242, 0)), v_t_24137));
  V f_ = v_t_24138;
  heff_room[0] = heff_dup(v_hd_24128);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam20, 1, 5, (V[]){v_opts_240, v_k_243, v_hd_24128, v_k_24129, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam18(V self, V *args) {
  V v_x_24132 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_hd_24128 = heff_env(self)[1];
  V v_why_24127 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_opts_240 = heff_env(self)[4];
  V v_k_243 = heff_env(self)[5];
  V v_k_24129 = heff_env(self)[6];
  heff_drop(v_x_24132);
  heff_clo_take(self, 7);
  V v_t_24133 = heff_tag_n(TAG_End, 2, (V[]){v_x_2446, NTAG(TAG_MkUnit)});
  V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24134}), heff_dup(v_hd_24128), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam19, 1, 6, (V[]){v_why_24127, v_p_242, v_opts_240, v_hd_24128, v_k_243, v_k_24129})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam17(V self, V *args) {
  V v_why_24127 = args[0];
  V v_hd_24128 = args[1];
  V v_k_24129 = args[2];
  V v_x_2450 = heff_env(self)[0];
  V v_x_2446 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24130 = heff_tag_n(TAG_End, 2, (V[]){v_x_2450, NTAG(TAG_MkUnit)});
  V v_t_24131 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24131}), heff_dup(v_hd_24128), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam18, 1, 7, (V[]){v_x_2446, v_hd_24128, v_why_24127, v_p_242, v_opts_240, v_k_243, v_k_24129})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam23(V self, V *args) {
  V v_x_24146 = args[0];
  V v_next_24126 = heff_env(self)[0];
  V v_hd_24142 = heff_env(self)[1];
  V v_k_24143 = heff_env(self)[2];
  heff_drop(v_x_24146);
  heff_clo_take(self, 3);
  V f_ = v_next_24126;
  heff_room[0] = v_hd_24142;
  heff_room[1] = v_k_24143;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam22(V self, V *args) {
  V v_hd_24142 = args[0];
  V v_k_24143 = args[1];
  V v_x_2450 = heff_env(self)[0];
  V v_next_24126 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24144 = heff_tag_n(TAG_End, 2, (V[]){v_x_2450, NTAG(TAG_MkUnit)});
  V v_t_24145 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24145}), heff_dup(v_hd_24142), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam23, 1, 3, (V[]){v_next_24126, v_hd_24142, v_k_24143})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam3(V self, V *args) {
  V v_x_2450 = args[0];
  V v_l_2441 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_at_241 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  V v_z_245 = heff_env(self)[7];
  V v_t_2451 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2441, 2)), heff_dup(heff_rfield(v_p_242, 0))));
  V v_dir_2452 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2441, 2)), heff_dup(heff_rfield(v_p_242, 0))));
  V v_d_2453 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2441, 2)), heff_dup(heff_rfield(v_p_242, 0))));
  V v_st_2454 = heff_get_n(heff_dup(heff_rfield(v_l_2441, 2)), 5, 6);
  V v_t_2455 = (g_std_2epath_2eparse(heff_dup(v_st_2454), v_d_2453));
  V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_l_2441, 2)), 5, 6);
  V v_t_2457;
  switch (heff_tag_of(v_t_2456)) {
  case TAG_Posix: {
    v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str10);
    break;
  }
  case TAG_Windows: {
    v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str11);
    break;
  }
  default: heff_nomatch(v_t_2456);
  }
  V v_t_2458 = (g_std_2epath_2eparse(heff_dup(v_st_2454), v_t_2457));
  V v_t_2459 = (g_std_2epath_2ejoin(v_t_2455, v_t_2458));
  V v_out_2460 = ({ V a_0 = v_st_2454; V a_1 = v_t_2459; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2454); heff_drop(v_t_2459); r_; });
  V v_d_2461 = (g_heff_2ebuild_2etesting_2etestDir(heff_dup(heff_rfield(v_l_2441, 2)), heff_dup(heff_rfield(v_p_242, 0))));
  V v_st_2462 = heff_get_n(heff_dup(heff_rfield(v_l_2441, 2)), 5, 6);
  V v_t_2463 = (g_std_2epath_2eparse(heff_dup(v_st_2462), v_d_2461));
  V v_t_2464 = heff_get_n(heff_dup(heff_rfield(v_l_2441, 2)), 5, 6);
  V v_t_2465;
  switch (heff_tag_of(v_t_2464)) {
  case TAG_Posix: {
    v_t_2465 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str12);
    break;
  }
  case TAG_Windows: {
    v_t_2465 = ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str13);
    break;
  }
  default: heff_nomatch(v_t_2464);
  }
  V v_t_2466 = (g_std_2epath_2eparse(heff_dup(v_st_2462), v_t_2465));
  V v_t_2467 = (g_std_2epath_2ejoin(v_t_2463, v_t_2466));
  V v_s_2468 = ({ V a_0 = v_st_2462; V a_1 = v_t_2467; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2462); heff_drop(v_t_2467); r_; });
  V v_path_2469 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2468));
  V v_t_2470 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2469; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2469); r_; });
  V v_p_231000_2472 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2470, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam4_clo)});
  V v_t_2473 = heff_tr(heff_call(((V)&g_co_2eop_24s1412293101x300983667_clo), 1, (V[]){v_p_231000_2472}));
  V v_c_2474 = heff_tr(g_std_2efilesystem_2efromSystem_24s141698176x1512134465(v_t_2473));
  V v_t_2475 = heff_get_n(heff_dup(heff_rfield(v_l_2441, 2)), 5, 6);
  heff_clo_take(self, 8);
  V v_next_24126 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092(((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str14), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam5, 3, 4, (V[]){heff_dup(v_x_2446), heff_dup(v_p_242), heff_dup(v_opts_240), heff_dup(v_k_243)}), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str16), v_t_2475, heff_dup(v_x_2446), v_dir_2452, v_out_2460, heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam9, 2, 6, (V[]){v_c_2474, heff_dup(v_l_2441), heff_dup(v_x_2446), v_at_241, heff_dup(v_p_242), heff_dup(v_k_243)})));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228(heff_dup(heff_rfield(v_opts_240, 4)), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam17, 3, 5, (V[]){heff_dup(v_x_2450), v_x_2446, heff_dup(v_p_242), v_opts_240, v_k_243}), v_l_2441, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2eintegrationMainName_get())}), heff_strAppend(v_t_2451, ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str23)), heff_get_n(v_p_242, 0, 7), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam22, 2, 2, (V[]){v_x_2450, v_next_24126}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam1(V self, V *args) {
  V v_x_2446 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_at_241 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2446), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_str9), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam2_clo)})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s535099379x685970669(v_t_2449, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam3, 1, 8, (V[]){v_l_2441, v_p_242, v_x_2446, v_opts_240, v_k_243, v_at_241, v_z_244, v_z_245})));
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam25(V self, V *args) {
  V v_x_24153 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24153});
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam24(V self, V *args) {
  V v_x_24151 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24152 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_240, heff_dup(v_x_24151)));
  if ((heff_dup(v_t_24152) == NTAG(TAG_True))) {
    heff_drop(v_x_24151);
    heff_drop_rec(v_p_242, 7);
    heff_drop(v_t_24152);
    V f_ = v_k_243;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_z_244;
    heff_room[2] = v_z_245;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24152);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1)), heff_get_n(v_p_242, 2, 7), v_x_24151, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam25, 1, 3, (V[]){v_k_243, v_z_244, v_z_245})));
  }
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam27(V self, V *args) {
  V v_x_24159 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24159});
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam26(V self, V *args) {
  V v_x_24157 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24158 = (g_heff_2ebuild_2etesting_2epassedOver(v_opts_240, heff_dup(v_x_24157)));
  if ((heff_dup(v_t_24158) == NTAG(TAG_True))) {
    heff_drop(v_x_24157);
    heff_drop_rec(v_p_242, 7);
    heff_drop(v_t_24158);
    V f_ = v_k_243;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())});
    heff_room[1] = v_z_244;
    heff_room[2] = v_z_245;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24158);
    return (g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1)), heff_get_n(v_p_242, 2, 7), v_x_24157, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2ebuildIntegrations_24s999844863x1954803891_lam27, 1, 3, (V[]){v_k_243, v_z_244, v_z_245})));
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str3, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str10, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str11, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str12, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str13, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str14, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str15, 1, "\"");
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_entry, 8, 0};

V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1(V v_tok_240, V v_lit_241, V v_update_242, V v_dir_243, V v_path_244, V v_text_245, V v_z_246, V v_z_247) {
top: ;
  if (heff_strEq_c_lent(v_lit_241, v_text_245, 0)) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_path_244);
    heff_drop(v_text_245);
    heff_drop(v_z_246);
    return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_Holds)});
  } else {
    if ((heff_dup(v_update_242) == NTAG(TAG_True))) {
      V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_244)));
      V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
      V v_a_2411 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_249, v_text_245, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_lam0_clo)});
      V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2416, v_z_246, heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_lam1, 1, 2, (V[]){v_path_244, v_z_247})));
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_z_246);
      V v_t_2424 = (g_prelude_2esplit_2esplitFrom_240(v_lit_241, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str4), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str5), v_lit_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
      V v_t_2425 = ({ V a_0 = v_text_245; V a_1 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str7), v_text_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_245); r_; });
      HeffT3 v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2424; V a_2 = v_t_2425; HeffT3 r_ = (g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2424); heff_drop(v_t_2425); r_; });
      {
        V v_field_2427 = v_t_2426.f[0];
        V v_field_2428 = v_t_2426.f[1];
        V v_field_2429 = v_t_2426.f[2];
        V v_n_2430 = v_field_2427;
        V v_kept_2431 = v_field_2428;
        V v_text_2432 = v_field_2429;
        V v_t_2433 = ({ V a_0 = v_kept_2431; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str8); V r_ = (g_prelude_2einstanceDebugString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2431); r_; });
        V v_t_2434 = ({ V a_0 = v_text_2432; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str9); V r_ = (g_prelude_2einstanceDebugString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2432); r_; });
        V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str10), v_path_244), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str11));
        V v_t_2436 = heff_strAppend(v_t_2435, heff_intShow(v_n_2430));
        V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str12), v_t_2433), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str13));
        V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str14), v_t_2434), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str15));
        V v_x_2439 = heff_tag_n(TAG_Wrong, 2, (V[]){v_t_2436, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2437, v_t_2438})});
        return heff_tail(v_z_247, 1, (V[]){v_x_2439});
      }
    }
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1(a[0], a1, a2, a3, a[4], a[5], a[6], a[7]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 0ULL, 1);
    heff_clo_take(self, 2);
    V v_t_2419 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str0), v_path_244), heff_tag_at_n(v_ru_24x_2417_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str1)})});
    V f_ = v_z_247;
    args[0] = v_t_2419;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2420 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    switch (heff_tag_of(v_y_2420)) {
    case TAG_Left: {
      heff_take_n(v_y_2420, 0ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2422 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str2), v_path_244), heff_tag_at_n(v_ru_24x_2417_24Right, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_str3)})});
      V f_ = v_z_247;
      args[0] = v_t_2422;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2420, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2417_24Right, 1);
      heff_clo_take(self, 2);
      V f_ = v_z_247;
      args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_244});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2420);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}