// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EMatch 41631
#define TAG_EVar 52881
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_prelude_2etraverse_24s1796722286x1908752336(V, V);
V g_prelude_2etraverse_24s1796722286x1908752336_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1796722286x1908752336_clo;
Clo g_heff_2ecompile_2erematch_2ematchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erematch_2ematchOf_entry, 2, 0};

V g_heff_2ecompile_2erematch_2ematchOf(V v_e_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EMatch: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_EMatch: {
        V v_arms_246 = heff_field(v_e_240, 1);
        V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 2ULL, 2);
        V v_m_247 = (g_prelude_2etraverse_24s1796722286x1908752336(heff_dup(v_x_244), v_arms_246));
        V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_241}));
        switch (heff_tag_of(v_x2_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x2_248, 0);
          V v_n_2410 = heff_field(v_x2_248, 1);
          V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_re_n(v_ru_24e1_242_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_244}), v_x_249});
          return heff_tag_re_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2411, v_n_2410});
        }
        default: return heff_nomatch(v_x2_248);
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    default: {
      heff_drop(v_e1_242);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_z_241});
    }
    }
  }
  default: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_z_241});
  }
  }
}
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erematch_2ematchOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry, 3, 0};

V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V v_tok_240, V v_e_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EMatch: {
    V v_e1_243 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EVar: {
      V v_x_245 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EVar = heff_take_reuse_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EMatch: {
        V v_arms_247 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_m_248 = (g_prelude_2etraverse_24s1796722286x1908752336(heff_dup(v_x_245), v_arms_247));
        V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x2_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x2_249, 0);
          V v_n_2411 = heff_field(v_x2_249, 1);
          heff_take_n(v_x2_249, 3ULL, 2);
          V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){heff_tag_re_n(v_ru_24e1_243_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_245}), v_x_2410});
          return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_MkPair, 2, (V[]){v_t_2412, v_n_2411});
        }
        default: return heff_nomatch(v_x2_249);
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: {
      heff_drop(v_e1_243);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_e_241, v_z_242});
    }
    }
  }
  default: {
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_e_241, v_z_242});
  }
  }
}
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erematch_2ematchOf_24tok2(a[0], a[1], a[2]);
}