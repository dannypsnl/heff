// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_ProjectFiles 9175
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_analysis 1868176469
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_current 1358797751
#define LBL_cut 308412
#define LBL_deps 9575179
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_kept 9783717
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_names 305943394
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_st 10440
#define LBL_text 10052084
#define LBL_watch 314261737
static uint32_t shape_analysis__at[] = {LBL_analysis, LBL_at};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_root__names__program__current__kept[] = {LBL_root, LBL_names, LBL_program, LBL_current, LBL_kept};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
V g_heff_2ebuild_2esession_2ecachedWhere_24s1751167845x260829144(V, V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedWhere_24s1751167845x260829144_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedWhere_24s1751167845x260829144_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008_clo;
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400(V, V, V, V);
V g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(V);
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_clo;
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377(V, V, V);
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167_clo;
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787(V, V, V);
V g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_get(void);
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s1836353438x580818415(V, V);
V g_list_2eany_24s1836353438x580818415_entry(V self, V *a);
extern Clo g_list_2eany_24s1836353438x580818415_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str1, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str2, 9, "character");
Clo g_heff_2elsp_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_x_242 = heff_strLength_lent(v_src_240, 0);
  V v_y_243;
  if (heff_intLe_c_lent(v_x_242, v_i_241, 0)) {
    v_y_243 = v_x_242;
  } else {
    heff_drop(v_x_242);
    v_y_243 = heff_dup(v_i_241);
  }
  V v_i_244;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_243, 1)) {
    v_i_244 = v_y_243;
  } else {
    heff_drop(v_y_243);
    v_i_244 = MK_INT(0LL);
  }
  V v_x_245 = heff_strLength_lent(v_src_240, 0);
  V v_y_246;
  if (heff_intLe_c_lent(v_x_245, v_i_241, 0)) {
    heff_drop(v_i_241);
    v_y_246 = v_x_245;
  } else {
    heff_drop(v_x_245);
    v_y_246 = v_i_241;
  }
  V v_t_247;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
    v_t_247 = v_y_246;
  } else {
    heff_drop(v_y_246);
    v_t_247 = MK_INT(0LL);
  }
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eposition_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_249;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_249 = NTAG(TAG_Nothing);
  } else {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
  }
  HeffT3 v_t_2410 = ({ V a_0 = v_src_240; V a_1 = v_t_247; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_249; HeffT3 r_ = (g_heff_2elsp_2erender_2elineColAt_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_247); r_; });
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[2]);
    V v_t_2414 = ({ V a_0 = v_src_240; V a_1 = heff_intSub_lent(v_i_244, v_field_2412, 2); V a_2 = v_i_244; V a_3 = MK_INT(0LL); V r_ = (g_heff_2elsp_2elsp_2eunits16Go(a_0, a_1, a_2, a_3)); heff_drop(v_i_244); r_; });
    V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_field_2411})});
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_t_2414})});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2417})});
  }
}
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eposition(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s930188071x496633547(v_x_241, v_xs_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
    V v_u_245 = (g_heff_2elsp_2elsp_2enubPaths_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths(a[0]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V v_changed_240, V v_mods_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = (g_list_2eany_24s1836353438x580818415(v_c_244, v_changed_240));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_244, 1)), heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_244, 0, 14), v_mods_241});
      V t_0 = v_changed_240;
      V t_1 = v_t_249;
      V t_2 = v_rest_245;
      V t_3 = v_u_248;
      v_changed_240 = t_0;
      v_mods_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V v_t_2411 = ({ V b_0 = heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}); V a_1 = heff_rfield(v_c_244, 8); V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_244, 1)), heff_hole()});
        V v_u_2413 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2412);
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_244, 0, 14), v_mods_241});
        V t_0 = v_changed_240;
        V t_1 = v_t_2414;
        V t_2 = v_rest_245;
        V t_3 = v_u_2413;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_rec(v_c_244, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2411);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_245;
        V t_3 = v_d_243;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2elsp_2elsp_2eaffectedGo_24dps(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args) {
  V v_d_2410 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_2410; V a_1 = v_mods_241; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_d_2410); heff_drop(v_mods_241); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str0, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str1, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str2, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str4, 21, "textDocument/didClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str5, 13, "textDocument/");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str6, 31, "workspace/didChangeWatchedFiles");
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_entry, 3, 0};

V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str0), 2)) {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_p_242);
    return ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam0_clo);
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str1), 2)) {
      heff_drop_rec(v_st_240, 7);
      V v_c_245 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(heff_dup(v_p_242)));
      return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam1, 2, 2, (V[]){v_c_245, v_p_242});
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str4), 2)) {
        V v_c_2421 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(v_p_242));
        return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam3, 2, 2, (V[]){v_c_2421, v_st_240});
      } else {
        heff_drop_rec(v_st_240, 7);
        heff_drop(v_p_242);
        return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam5, 2, 1, (V[]){heff_dup(v_m_241)});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str2), NTAG(TAG_Nil)});
  heff_clo_take(self, 3);
  HeffT2 v_t_2410 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str3), v_t_249}); V a_1 = v_p_242; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_t_2420;
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_it1_2413 = v_field_2412;
      switch (heff_tag_of(v_it1_2413)) {
      case TAG_JNull: {
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2417 = heff_field(v_it1_2413, 0);
        V v_ru_24it1_2413_24JString = heff_take_reuse_n(v_it1_2413, 1ULL, 1);
        v_t_2420 = heff_tag_at_n(v_ru_24it1_2413_24JString, TAG_Just, 1, (V[]){v_s_2417});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2413);
      }
    } else {
      heff_drop(v_field_2412);
      v_t_2420 = NTAG(TAG_Nothing);
    }
    return (g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400(v_x_248, v_t_2420, v_hd_246, v_k_247));
  }
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam2, 1, 3, (V[]){v_p_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  V v_t_2430;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_240, 7);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_f_2425 = heff_dup(heff_field(v_x_2424, 0));
    HeffT2 v_t_2426 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_f_2425; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_f_2425); r_; });
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_d_2429 = v_field_2428;
        v_t_2430 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2429, 1, 2)});
      } else {
        heff_drop(v_field_2428);
        v_t_2430 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  return (g_heff_2elsp_2elsp_2easOnDisk_24s713753977x1661949400(v_x_2424, v_t_2430, v_hd_2422, v_k_2423));
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam4, 1, 3, (V[]){v_st_240, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_m_241 = heff_env(self)[0];
  heff_drop(v_hd_2431);
  V v_t_2433 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_m_241, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str5)) ? 0 : !heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s472115020x479425377_str6), 2)));
  heff_drop(self);
  V f_ = v_k_2432;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam4, 1, 0};
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_entry, 7, 0};

V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020(V v_st_240, V v_f_241, V v_d_242, V v_ds_243, V v_lo_244, V v_hi_245, V v_a_246) {
top: ;
  if (heff_intLe_c(heff_intSub_lent(v_hi_245, v_lo_244, 0), MK_INT(1LL))) {
    heff_drop(v_st_240);
    heff_drop(v_f_241);
    heff_drop_rec(v_d_242, 2);
    heff_drop(v_hi_245);
    HeffT3 v_t_247 = (g_list_2edrop_24cpr(v_lo_244, v_ds_243));
    {
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      V v_tag_248 = heff_box_i64(((int64_t)v_t_247.f[0]));
      return heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam0, 2, 4, (V[]){v_tag_248, v_field_249, v_field_2410, v_a_246});
    }
  } else {
    return heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam1, 2, 7, (V[]){v_lo_244, v_hi_245, heff_dup(v_ds_243), v_d_242, v_st_240, v_f_241, v_a_246});
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_tag_248 = heff_env(self)[0];
  V v_field_249 = heff_env(self)[1];
  V v_field_2410 = heff_env(self)[2];
  V v_a_246 = heff_env(self)[3];
  heff_drop(v_hd_2411);
  V v_t_2415;
  heff_clo_take(self, 4);
  if ((heff_unbox_i64(v_tag_248) == ((int64_t)0ULL))) {
    V v_x_2413 = v_field_249;
    V v_x12_2414 = v_field_2410;
    heff_drop(v_x12_2414);
    v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2413});
  } else {
    heff_drop(v_field_249);
    heff_drop(v_field_2410);
    v_t_2415 = NTAG(TAG_Nothing);
  }
  V f_ = v_k_2412;
  args[0] = heff_rec_n(2, shape_analysis__at, (V[]){v_a_246, v_t_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_lo_244 = heff_env(self)[0];
  V v_hi_245 = heff_env(self)[1];
  V v_ds_243 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_f_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = heff_intDiv(heff_intAdd(v_lo_244, v_hi_245), MK_INT(2LL));
  HeffT3 v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = v_ds_243; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_243); r_; });
  {
    V v_field_2424 = v_t_2422.f[1];
    V v_field_2425 = v_t_2422.f[2];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    V v_t_2428;
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_x_2426 = v_field_2424;
      V v_x12_2427 = v_field_2425;
      heff_drop(v_x12_2427);
      v_t_2428 = heff_get_n(v_x_2426, 0, 2);
    } else {
      heff_drop(v_field_2424);
      heff_drop(v_field_2425);
      v_t_2428 = heff_strLength(heff_dup(heff_rfield(v_d_242, 1)));
    }
    return ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_t_2428; V a_4 = v_hd_2419; V a_5 = v_k_2420; V r_ = (g_heff_2elsp_2elsp_2eanalysedUpTo_24s1897312429x182781008(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2428); r_; });
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam4(V self, V *args) {
  V v_r_2429 = args[0];
  return v_r_2429;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam2(V self, V *args) {
  V v_use_2418 = args[0];
  V v_lo_244 = heff_env(self)[0];
  V v_hi_245 = heff_env(self)[1];
  V v_ds_243 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_f_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_use_2418;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam3, 2, 6, (V[]){v_lo_244, v_hi_245, v_ds_243, v_d_242, v_st_240, v_f_241});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam4_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_lo_244 = heff_env(self)[0];
  V v_hi_245 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_ds_243 = heff_env(self)[5];
  V v_a_246 = heff_env(self)[6];
  V v_hd_2416 = heff_env(self)[7];
  V v_k_2417 = heff_env(self)[8];
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    heff_take_n(v_x_2434, 0ULL, 1);
    heff_clo_take(self, 9);
    V v_t_2436 = heff_intDiv(heff_intAdd_lent(v_lo_244, v_hi_245, 2), MK_INT(2LL));
    V v_t_2437 = ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_ds_243; V a_4 = v_lo_244; V a_5 = v_t_2436; V a_6 = v_a_246; V r_ = (g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_ds_243); r_; });
    V f_ = v_t_2437;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2438 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 1);
    heff_clo_take(self, 9);
    heff_drop(v_a_246);
    V v_t_2439 = heff_intDiv(heff_intAdd_lent(v_lo_244, v_hi_245, 1), MK_INT(2LL));
    V v_t_2440 = ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_ds_243; V a_4 = v_t_2439; V a_5 = v_hi_245; V a_6 = v_y_2438; V r_ = (g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_ds_243); r_; });
    V f_ = v_t_2440;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_lo_244 = heff_env(self)[0];
  V v_hi_245 = heff_env(self)[1];
  V v_ds_243 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_f_241 = heff_env(self)[5];
  V v_a_246 = heff_env(self)[6];
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam2, 1, 6, (V[]){heff_dup(v_lo_244), heff_dup(v_hi_245), heff_dup(v_ds_243), heff_dup(v_d_242), heff_dup(v_st_240), heff_dup(v_f_241)})})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_hd_2416), heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s92392464x1052204020_lam5, 1, 9, (V[]){v_lo_244, v_hi_245, v_st_240, v_f_241, v_d_242, v_ds_243, v_a_246, v_hd_2416, v_k_2417})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam2, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam8, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam14(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam14, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam15(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_entry, 6, 0};

V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(V v_st_240, V v_root_241, V v_f_242, V v_names_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam0, 1, 4, (V[]){heff_dup(v_root_241), heff_dup(v_names_243), heff_dup(v_st_240), v_f_242})})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), v_hd_244, heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam15, 1, 4, (V[]){v_st_240, v_root_241, v_names_243, v_k_245})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam2(V self, V *args) {
  V v_fs_249 = args[0];
  return v_fs_249;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam4(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_x_2414 = heff_env(self)[0];
  heff_drop(v_hd_2415);
  heff_clo_take(self, 1);
  V f_ = v_k_2416;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam7(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_d_2433 = heff_env(self)[0];
  heff_drop(v_hd_2434);
  heff_clo_take(self, 1);
  V v_t_2436 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2433, 1, 2)});
  V f_ = v_k_2435;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam8(V self, V *args) {
  V v_r_2439 = args[0];
  return v_r_2439;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam10(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2442 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2448)) {
  case TAG_Left: {
    heff_take_n(v_x_2448, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2442;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2450 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    switch (heff_tag_of(v_y_2450)) {
    case TAG_Left: {
      heff_take_n(v_y_2450, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2442;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2452 = heff_field(v_y_2450, 0);
      heff_take_n(v_y_2450, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2442;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2452});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2450);
    }
  }
  default: return heff_nomatch(v_x_2448);
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam9(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_a_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2440})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2447, v_hd_2441, heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam10, 1, 1, (V[]){v_k_2442})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam6(V self, V *args) {
  V v_p_2429 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2430 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_2429; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2432 = v_t_2430.f[1];
    int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
    if ((v_tag_2431 == ((int64_t)0ULL))) {
      heff_drop(v_p_2429);
      V v_d_2433 = v_field_2432;
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam7, 2, 1, (V[]){v_d_2433});
    } else {
      heff_drop(v_field_2432);
      V v_path_2437 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_2429));
      V v_t_2438 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2437; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2437); r_; });
      V v_a_2440 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2438, ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam8_clo)});
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam9, 2, 1, (V[]){v_a_2440});
    }
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam13(V self, V *args) {
  V v_s_2457 = args[0];
  V v_names_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_names_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_2457, 8);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_names_2458 = heff_field(v_names_243, 0);
    heff_take_n(v_names_243, 1ULL, 1);
    return ({ V a_0 = MK_INT(0LL); V b_1 = heff_get_n(v_s_2457, 4, 8); V a_2 = MK_INT(0LL); V a_3 = v_names_2458; V r_ = (g_list_2eany_24s1027174601x1571638094(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_names_2458); r_; });
  }
  default: return heff_nomatch(v_names_243);
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam12(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2453 = heff_env(self)[0];
  V v_names_243 = heff_env(self)[1];
  V v_kept_2425 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2456 = (g_heff_2elsp_2elsp_2enubSources(v_x_2453));
  return ({ V b_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam13, 1, 1, (V[]){v_names_243}); V a_1 = v_kept_2425; V a_2 = v_x_2455; V a_3 = v_t_2456; V a_4 = v_hd_247; V a_5 = v_k_248; V r_ = (g_heff_2ebuild_2esession_2ecachedWhere_24s1751167845x260829144(b_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam11(V self, V *args) {
  V v_x_2453 = args[0];
  V v_lib_2420 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_names_243 = heff_env(self)[3];
  V v_kept_2425 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2454 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(v_lib_2420, v_f_242));
  V f_ = v_t_2454;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam12, 1, 5, (V[]){v_x_2453, v_names_243, v_kept_2425, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_names_243 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_lib_2420 = heff_dup(heff_rfield(v_st_240, 6));
  V v_t_2421 = heff_dup(heff_rfield(v_st_240, 3));
  V v_kept_2425;
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    heff_drop(v_root_241);
    v_kept_2425 = heff_dup(g_std_2eordmap_2eempty_get());
    break;
  }
  case TAG_Just: {
    V v_pr_2422 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    V v_root_2423 = heff_take_field(v_pr_2422, 0);
    V v_kept_2424 = heff_get_n(v_pr_2422, 4, 5);
    if (heff_strEq_c(v_root_2423, v_root_241)) {
      v_kept_2425 = v_kept_2424;
    } else {
      heff_drop(v_kept_2424);
      v_kept_2425 = heff_dup(g_std_2eordmap_2eempty_get());
    }
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_files_2427 = (g_prelude_2e_2b_2b(v_x_2419, v_t_2426));
  V v_t_2428 = (g_heff_2elsp_2elsp_2enubPaths(v_files_2427));
  return ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam6, 1, 1, (V[]){v_st_240}); V a_1 = heff_dup(v_lib_2420); V a_2 = v_t_2428; V a_3 = heff_dup(v_hd_247); V a_4 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam11, 1, 6, (V[]){v_lib_2420, v_f_242, v_hd_247, v_names_243, v_kept_2425, v_k_248}); V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s925879680x2025863167(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2428); r_; });
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_names_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_c_2418;
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_names_243)) {
  case TAG_Nothing: {
    v_c_2418 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam4, 2, 1, (V[]){v_x_2414});
    break;
  }
  case TAG_Just: {
    V v_names_2417 = heff_dup(heff_field(v_names_243, 0));
    v_c_2418 = ({ V a_0 = heff_dup(v_st_240); V a_1 = v_names_2417; V a_2 = v_x_2414; V r_ = (g_heff_2elsp_2elsp_2ementionedIn_24s1138654223x137826787(a_0, a_1, a_2)); heff_drop(v_names_2417); r_; });
    break;
  }
  default: heff_nomatch(v_names_243);
  }
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam5, 1, 6, (V[]){v_st_240, v_root_241, v_f_242, v_hd_247, v_names_243, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_root_241 = heff_env(self)[0];
  V v_names_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProjectFiles, 2, (V[]){heff_dup(v_root_241), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_247), heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam3, 1, 6, (V[]){v_names_243, v_st_240, v_hd_247, v_root_241, v_f_242, v_k_248})));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam14(V self, V *args) {
  V v_r_2459 = args[0];
  return v_r_2459;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam0(V self, V *args) {
  V v_use_246 = args[0];
  V v_root_241 = heff_env(self)[0];
  V v_names_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_use_246;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam1, 2, 4, (V[]){v_root_241, v_names_243, v_st_240, v_f_242});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam14_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_lam15(V self, V *args) {
  V v_x_2464 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_names_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_e_2467;
  switch (heff_tag_of(v_x_2464)) {
  case TAG_Left: {
    heff_take_n(v_x_2464, 0ULL, 1);
    v_e_2467 = heff_dup(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_get());
    break;
  }
  case TAG_Right: {
    V v_e_2466 = heff_field(v_x_2464, 0);
    heff_take_n(v_x_2464, 1ULL, 1);
    v_e_2467 = v_e_2466;
    break;
  }
  default: heff_nomatch(v_x_2464);
  }
  V v_program_2468 = heff_take_field(v_e_2467, 0);
  V v_kept_2469 = heff_get_n(v_e_2467, 1, 2);
  V v_t_2470 = heff_dup(v_program_2468);
  V v_kept_2477;
  switch (heff_tag_of(v_t_2470)) {
  case TAG_Nil: {
    heff_drop(v_kept_2469);
    V v_t_2471 = heff_dup(heff_rfield(v_st_240, 3));
    switch (heff_tag_of(v_t_2471)) {
    case TAG_Nothing: {
      v_kept_2477 = heff_dup(g_std_2eordmap_2eempty_get());
      break;
    }
    case TAG_Just: {
      V v_pr_2472 = heff_field(v_t_2471, 0);
      heff_take_n(v_t_2471, 1ULL, 1);
      V v_root_2473 = heff_take_field(v_pr_2472, 0);
      V v_kept_2474 = heff_get_n(v_pr_2472, 4, 5);
      if (heff_strEq_c_lent(v_root_2473, v_root_241, 1)) {
        v_kept_2477 = v_kept_2474;
      } else {
        heff_drop(v_kept_2474);
        v_kept_2477 = heff_dup(g_std_2eordmap_2eempty_get());
      }
      break;
    }
    default: heff_nomatch(v_t_2471);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2470, 0ULL, 2);
    v_kept_2477 = v_kept_2469;
    break;
  }
  default: heff_nomatch(v_t_2470);
  }
  heff_clo_take(self, 4);
  V v_due_2478 = heff_take_field(v_st_240, 2);
  V v_watch_2479 = heff_take_field(v_st_240, 4);
  V v_shutdown_2480 = heff_take_field(v_st_240, 5);
  V v_lib_2481 = heff_take_field(v_st_240, 6);
  V v_t_2482 = heff_rec_n(5, shape_root__names__program__current__kept, (V[]){v_root_241, v_names_243, heff_dup(v_program_2468), NTAG(TAG_True), v_kept_2477});
  V v_t_2483 = ({ V rv_2 = v_due_2478; V rv_3 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2482}); V rv_4 = v_watch_2479; V rv_5 = v_shutdown_2480; V rv_6 = v_lib_2481; V rr_ = heff_rec_reuse_nf(v_st_240, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_k_245;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_t_2483, v_program_2468});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}