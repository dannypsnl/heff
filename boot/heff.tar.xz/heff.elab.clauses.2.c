// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291 3888
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648 39892
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156 11512
#define TAG_ExplicitParam 63083
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_Right 62770
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define LBL_anys 9494734
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bad 306815
#define LBL_bits 9519565
#define LBL_bound 295286168
#define LBL_chk 308000
#define LBL_decl 9574769
#define LBL_end 310101
#define LBL_flags 298871457
#define LBL_go 10063
#define LBL_inf 313947
#define LBL_len 316559
#define LBL_msg 317947
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_row 322644
#define LBL_rows 10002080
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tag 324116
#define LBL_terms 311608737
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_used 10094724
#define LBL_v 336
#define LBL_value 313331083
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_bits__terms[] = {LBL_bits, LBL_terms};
static uint32_t shape_go[] = {LBL_go};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_row__bad__rows[] = {LBL_row, LBL_bad, LBL_rows};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2eelab_2eclauses_2eallC(V, V);
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eallC_clo;
V g_heff_2eelab_2eclauses_2eandC(V, V, V);
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_clo;
V g_heff_2eelab_2eclauses_2eandC_24tok3(V, V, V, V);
V g_heff_2eelab_2eclauses_2eandC_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_24tok3_clo;
V g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762(V, V);
V g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762_clo;
V g_heff_2eelab_2eclauses_2eanyIn(V, V, V);
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyIn_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24dps_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps_clo;
V g_heff_2eelab_2eclauses_2eappendC_24tok2(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24tok2_clo;
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo;
V g_heff_2eelab_2eclauses_2ebare(V);
V g_heff_2eelab_2eclauses_2ebare_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebare_clo;
V g_heff_2eelab_2eclauses_2ebinBindGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinBindGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBindGo_clo;
V g_heff_2eelab_2eclauses_2ebinTest(V);
V g_heff_2eelab_2eclauses_2ebinTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTest_clo;
HeffT1 g_heff_2eelab_2eclauses_2ebinTest_24cpr(V);
V g_heff_2eelab_2eclauses_2ebinTestGo(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestGo_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecolNames(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolNames_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_get(void);
HeffT2 g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo;
HeffT2 g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2edropAt(V, V);
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_clo;
V g_heff_2eelab_2eclauses_2edropAt_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2edropAt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_24dps_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
HeffT2 g_heff_2eelab_2eclauses_2efindTagLit_24cpr(V, V);
V g_heff_2eelab_2eclauses_2efits(V, V, V, V);
V g_heff_2eelab_2eclauses_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efits_clo;
V g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005(V, V, V);
V g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_clo;
HeffT2 g_heff_2eelab_2eclauses_2eforC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidents_get(void);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo;
V g_heff_2eelab_2eclauses_2eidentsDeclF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24dps_clo;
V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(V, V, V, V);
V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_clo;
HeffT2 g_heff_2eelab_2eclauses_2elitChecks_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitNo(V, V, V);
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNo_clo;
V g_heff_2eelab_2eclauses_2elitYes(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYes_clo;
HeffT2 g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC(V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo;
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(V, V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_clo;
V g_heff_2eelab_2eclauses_2enameFits(V, V, V);
V g_heff_2eelab_2eclauses_2enameFits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enameFits_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s176108235x1918046964(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s176108235x1918046964_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s176108235x1918046964_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s985293991x1511639658(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s985293991x1511639658_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s985293991x1511639658_clo;
HeffT2 g_heff_2eelab_2eclauses_2enoRecMix_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24tok2(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24tok2_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24dps_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24tok2(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24tok2_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epatVars_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo;
HeffT2 g_heff_2eelab_2eclauses_2epeelAs_24cpr(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
HeffT2 g_heff_2eelab_2eclauses_2epeelCols_24cpr(V, V, V);
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2eelab_2eclauses_2erenameField(V, V);
V g_heff_2eelab_2eclauses_2erenameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameField_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s1032981255x303617189(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s1032981255x303617189_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s1032981255x303617189_clo;
V g_heff_2eelab_2eclauses_2erenameTypF(V, V);
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameTypF_clo;
HeffT5 g_heff_2eelab_2eclauses_2erenamer_24cpr(V, V);
V g_heff_2eelab_2eclauses_2esegBind(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegBind_clo;
V g_heff_2eelab_2eclauses_2esegBind_24tok2(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegBind_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegBind_24tok2_clo;
V g_heff_2eelab_2eclauses_2esegRead(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegRead_clo;
V g_heff_2eelab_2eclauses_2esizeOk(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esizeOk_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esizeOk_clo;
V g_heff_2eelab_2eclauses_2esoleBin(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esoleBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esoleBin_clo;
V g_heff_2eelab_2eclauses_2etagColAt(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColAt_clo;
V g_heff_2eelab_2eclauses_2etagColGo(V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColGo_clo;
HeffT2 g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2eupToGo(V, V);
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_clo;
V g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116(V, V, V, V);
V g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_clo;
V g_heff_2eelab_2eclauses_2eutfWidth(V, V, V, V);
V g_heff_2eelab_2eclauses_2eutfWidth_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eutfWidth_clo;
HeffT2 g_heff_2eelab_2eclauses_2ewholeSeg_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewidthBy_clo;
V g_heff_2eelab_2eclauses_2ezipC(V, V);
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_clo;
V g_heff_2eelab_2eclauses_2ezipC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24f450671696x846133639(V, V, V, V, V);
V g_list_2efoldl_24f450671696x846133639_entry(V self, V *a);
extern Clo g_list_2efoldl_24f450671696x846133639_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1437740164x269163243(V, V);
V g_list_2efoldl_24s1437740164x269163243_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1437740164x269163243_clo;
V g_list_2efoldl_24s547379716x1342911792(V, V, V);
V g_list_2efoldl_24s547379716x1342911792_entry(V self, V *a);
extern Clo g_list_2efoldl_24s547379716x1342911792_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s871632021x1241775640(V, V, V, V);
V g_list_2efoldl_24s871632021x1241775640_entry(V self, V *a);
extern Clo g_list_2efoldl_24s871632021x1241775640_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1539731936x1117725130(V, V, V);
V g_list_2emap_24f1539731936x1117725130_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1778157750x1229378888_24cpr(V);
HeffT2 g_prelude_2etraverse_24s1807059150x502333573_24cpr(V, V);
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2eelab_2eclauses_2esoleBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esoleBin_entry, 5, 0};

V g_heff_2eelab_2eclauses_2esoleBin(V v_s_240, V v_v_241, V v_ty_242, V v_size_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_At: {
    V v_v1_245 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24At = heff_take_reuse_n(v_v_241, 1ULL, 2);
    switch (heff_tag_of(v_v1_245)) {
    case TAG_PatVar: {
      V v_x_247 = heff_field(v_v1_245, 0);
      V v_ru_24v1_245_24PatVar = heff_take_reuse_n(v_v1_245, 1ULL, 1);
      switch (heff_tag_of(v_ty_242)) {
      case TAG_SegmentInteger: {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_248 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_248, v_sp_244});
      }
      case TAG_SegmentBinary: {
        switch (heff_tag_of(v_size_243)) {
        case TAG_SizeDefault: {
          heff_drop(v_s_240);
          heff_drop(v_sp_244);
          heff_drop_cell(v_ru_24v_241_24At, 2);
          return heff_tag_at_n(v_ru_24v1_245_24PatVar, TAG_PVar, 1, (V[]){v_x_247});
        }
        case TAG_SizeNumber: {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
          V v_t_2410 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2410, v_sp_244});
        }
        case TAG_SizeName: {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
          V v_t_2414 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2414, v_sp_244});
        }
        default: return heff_nomatch(v_size_243);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_2415 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2415, v_sp_244});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_2416 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2416, v_sp_244});
      }
      case TAG_SegmentUtf: {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24v1_245_24PatVar, 1);
        V v_t_2418 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2418, v_sp_244});
      }
      default: return heff_nomatch(v_ty_242);
      }
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_245, 0ULL, 3);
      V v_t_2422 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2422, v_sp_244});
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_245, 0ULL, 3);
      V v_t_2426 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2426, v_sp_244});
    }
    case TAG_PatInt: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2428 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2428, v_sp_244});
    }
    case TAG_PatFloat: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2430 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2430, v_sp_244});
    }
    case TAG_PatString: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2432 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2432, v_sp_244});
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2434 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2434, v_sp_244});
    }
    case TAG_PatRune: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2436 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2436, v_sp_244});
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2438 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2438, v_sp_244});
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_245, 0ULL, 1);
      V v_t_2440 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2440, v_sp_244});
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_245, 0ULL, 3);
      V v_t_2444 = heff_tag_at_n(v_ru_24v_241_24At, TAG_Cons, 2, (V[]){v_s_240, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_PBin, 2, (V[]){v_t_2444, v_sp_244});
    }
    default: return heff_nomatch(v_v1_245);
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2eelab_2eclauses_2esoleBin_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2esoleBin(a[0], a[1], a2, a3, a[4]); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2eclauses_2eappendC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eappendC(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = ({ V a_0 = v_xs_243; V a_1 = v_ys_241; V a_2 = v_cell_244; V r_ = (g_heff_2eelab_2eclauses_2eappendC_24dps(a_0, a_1, a_2)); heff_drop(v_ys_241); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eappendC_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_241));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2eappendC_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2eelab_2eclauses_2eforC_24cpr(V v_x1_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_245}});
    }
    case TAG_Right: {
      heff_take_n(v_x1_244, 0ULL, 1);
      V t_0 = v_xs_243;
      V t_1 = v_f_241;
      v_x1_240 = t_0;
      v_f_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2emapWithIndexC_entry, 3, 0};

V g_heff_2eelab_2eclauses_2emapWithIndexC(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = ({ V a_0 = heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))); V a_1 = v_f_241; V a_2 = v_xs_244; V a_3 = v_cell_246; V r_ = (g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_f_241); r_; });
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2emapWithIndexC(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry, 4, 0};

V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(V v_i_240, V v_f_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_248;
    v_i_240 = t_0;
    v_f_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2emapWithIndexC_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2emapWithIndexC_24dps(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2eclauses_2ezipC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ezipC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ezipC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2eelab_2eclauses_2ezipC_24dps(v_xs_243, v_ys_245, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ezipC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eallC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eallC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eallC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eallC(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropAt_entry, 2, 0};

V g_heff_2eelab_2eclauses_2edropAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_xs_243;
    } else {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eclauses_2edropAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropAt(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eelab_2eclauses_2epatVars(v_t_245));
    V v_t_247 = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatVars_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatVars_24dps_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatVars_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_243);
  }
  case TAG_PTag: {
    V v_ps_245 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    V v_t_247 = ({ V a_0 = v_ps_245; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_245); r_; });
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_247);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_PRec: {
    V v_fps_249 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V v_t_2411 = ({ V a_0 = v_fps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_249); r_; });
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2411);
  }
  case TAG_PAs: {
    V v_x_2412 = heff_field(v_x1_240, 0);
    V v_p_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24PAs = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24PAs, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2414);
    V t_0 = v_p_2413;
    V t_1 = v_u_2415;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_PBin: {
    V v_segs_2416 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24PBin = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_t_2418 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_2416)));
    V v_t_2419 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2418));
    V v_t_2420 = (g_list_2emap_24s939813003x1383013550(v_segs_2416));
    V v_t_2421 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2420));
    V v_t_2422 = (g_heff_2eelab_2eclauses_2eappendC_24tok2(v_ru_24x1_240_24PBin, v_t_2419, v_t_2421));
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2422);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epatVars_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2epatVars_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_x_242), v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatIdents_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatIdents(V v_p_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_244, v_acc_241});
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_247; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_247); r_; });
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_242, 0);
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_t_2411 = ({ V a_0 = v_ps_2410; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_2410); r_; });
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_248, v_t_2411});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatBinary: {
      V v_segs_2415 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s176108235x1918046964(v_segs_2415, v_acc_241);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatRecord: {
      V v_fs_2417 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(v_fs_2417, v_acc_241);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatAs: {
      V v_x_2419 = heff_field(v_p1_242, 0);
      V v_q_2421 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      V v_cell_2422 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2419, heff_hole()});
      V v_u_2423 = ({ V a_0 = v_q_2421; V a_1 = v_acc_241; V a_2 = v_cell_2422; V r_ = (g_heff_2eelab_2eclauses_2epatIdents_24dps(a_0, a_1, a_2)); heff_drop(v_acc_241); r_; });
      heff_drop(v_u_2423);
      return v_cell_2422;
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatIdents(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsTypF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsTypF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsTypF(V v_r_240, V v_n_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_243 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_n1_243)) {
    case TAG_TPi: {
      V v_b_245 = heff_field(v_n1_243, 0);
      V v_cod_246 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      V v_r_247 = heff_dup(v_r_240);
      V v_typ_248 = heff_take_field(v_r_247, 2);
      V v_chk_249 = heff_get_n(v_r_247, 1, 4);
      V v_x2_2410 = v_b_245;
      V v_acc_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_cod_246, v_acc_242}));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_PiNamed: {
        V v_x_2412 = heff_field(v_x2_2410, 0);
        V v_t_2414 = heff_field(v_x2_2410, 2);
        heff_take_n(v_x2_2410, 5ULL, 3);
        heff_drop(v_chk_249);
        V v_t_2415 = heff_tr(heff_call(v_typ_248, 2, (V[]){v_t_2414, v_acc_2411}));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2412, v_t_2415});
      }
      case TAG_PiImplicit: {
        V v_x_2416 = heff_field(v_x2_2410, 0);
        V v_t_2419 = heff_field(v_x2_2410, 3);
        V v_d_2420 = heff_field(v_x2_2410, 4);
        heff_take_n(v_x2_2410, 25ULL, 5);
        V v_t_2422;
        switch (heff_tag_of(v_d_2420)) {
        case TAG_Nothing: {
          heff_drop(v_chk_249);
          v_t_2422 = v_acc_2411;
          break;
        }
        case TAG_Just: {
          V v_c_2421 = heff_field(v_d_2420, 0);
          heff_take_n(v_d_2420, 1ULL, 1);
          v_t_2422 = heff_tr(heff_call(v_chk_249, 2, (V[]){v_c_2421, v_acc_2411}));
          break;
        }
        default: heff_nomatch(v_d_2420);
        }
        V v_t_2423 = heff_tr(heff_call(v_typ_248, 2, (V[]){v_t_2419, v_t_2422}));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2416, v_t_2423});
      }
      case TAG_PiInstance: {
        V v_x_2424 = heff_field(v_x2_2410, 0);
        V v_t_2427 = heff_field(v_x2_2410, 3);
        heff_take_n(v_x2_2410, 9ULL, 4);
        heff_drop(v_chk_249);
        V v_t_2428 = heff_tr(heff_call(v_typ_248, 2, (V[]){v_t_2427, v_acc_2411}));
        return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2424, v_t_2428});
      }
      case TAG_PiAnon: {
        V v_d_2429 = heff_field(v_x2_2410, 0);
        heff_take_n(v_x2_2410, 1ULL, 1);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        heff_drop(v_chk_249);
        return heff_tail(v_typ_248, 2, (V[]){v_d_2429, v_acc_2411});
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    case TAG_TSig: {
      V v_fs_2430 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return ({ V b_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsTypF_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_fs_2430; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_fs_2430); r_; });
    }
    case TAG_TSum: {
      V v_vs_2443 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return ({ V b_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsTypF_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_vs_2443; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_vs_2443); r_; });
    }
    case TAG_TType: {
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_TInt: {
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_TFloat: {
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_TString: {
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_TRune: {
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_TArray: {
      V v_a_2452 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_a_2452, v_acc_242});
    }
    case TAG_TFixed: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_TInf: {
      V v_i_2454 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_2454, v_acc_242});
    }
    case TAG_TChk: {
      V v_c_2455 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2455, v_acc_242});
    }
    case TAG_TNominal: {
      V v_t_2456 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2456, v_acc_242});
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsTypF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam0(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_acc_2432 = args[1];
  V v_r_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_At: {
    V v_x21_2433 = heff_field(v_x2_2431, 0);
    V v_ru_24x2_2431_24At = heff_take_reuse_n(v_x2_2431, 1ULL, 2);
    switch (heff_tag_of(v_x21_2433)) {
    case TAG_DeclareField: {
      V v_x_2435 = heff_field(v_x21_2433, 0);
      V v_t_2437 = heff_field(v_x21_2433, 2);
      V v_d_2438 = heff_field(v_x21_2433, 3);
      heff_take_n(v_x21_2433, 13ULL, 4);
      V v_t_2440;
      switch (heff_tag_of(v_d_2438)) {
      case TAG_Nothing: {
        v_t_2440 = v_acc_2432;
        break;
      }
      case TAG_Just: {
        V v_c_2439 = heff_field(v_d_2438, 0);
        heff_take_n(v_d_2438, 1ULL, 1);
        v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_c_2439, v_acc_2432}));
        break;
      }
      default: heff_nomatch(v_d_2438);
      }
      heff_clo_take(self, 1);
      V v_t_2441 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2437, v_t_2440}));
      return heff_tag_at_n(v_ru_24x2_2431_24At, TAG_Cons, 2, (V[]){v_x_2435, v_t_2441});
    }
    case TAG_BadFieldDecl: {
      V v_e_2442 = heff_field(v_x21_2433, 0);
      heff_take_n(v_x21_2433, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2431_24At, 2);
      heff_clo_take(self, 1);
      V f_ = heff_get_n(v_r_240, 2, 4);
      args[0] = v_e_2442;
      args[1] = v_acc_2432;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2433);
    }
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam1(V self, V *args) {
  V v_x2_2444 = args[0];
  V v_acc_2445 = args[1];
  V v_r_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_At: {
    V v_x21_2446 = heff_field(v_x2_2444, 0);
    heff_take_n(v_x2_2444, 1ULL, 2);
    switch (heff_tag_of(v_x21_2446)) {
    case TAG_TagVariant: {
      V v_args_2450 = heff_field(v_x21_2446, 2);
      heff_take_n(v_x21_2446, 4ULL, 3);
      heff_clo_take(self, 1);
      return ({ V b_0 = heff_get_n(v_r_240, 2, 4); V a_1 = v_args_2450; V a_2 = v_acc_2445; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_args_2450); r_; });
    }
    case TAG_BadVariant: {
      V v_e_2451 = heff_field(v_x21_2446, 0);
      heff_take_n(v_x21_2446, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = heff_get_n(v_r_240, 2, 4);
      args[0] = v_e_2451;
      args[1] = v_acc_2445;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2446);
    }
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsDeclF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsDeclF(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  V v_chk_243 = heff_take_field(v_r_240, 1);
  V v_typ_244 = heff_get_n(v_r_240, 2, 4);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_DeclEquations: {
      V v_f_247 = heff_field(v_x21_245, 0);
      V v_ty_2410 = heff_field(v_x21_245, 3);
      V v_eqs_2411 = heff_field(v_x21_245, 4);
      heff_take_n(v_x21_245, 25ULL, 5);
      V v_t_2422 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam0, 2, 1, (V[]){v_chk_243}); V a_1 = v_eqs_2411; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_eqs_2411); r_; });
      V v_t_2423 = heff_tr(heff_call(v_typ_244, 2, (V[]){v_ty_2410, v_t_2422}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_f_247, v_t_2423});
    }
    case TAG_DeclDefine: {
      V v_x_2424 = heff_field(v_x21_245, 0);
      V v_ps_2426 = heff_field(v_x21_245, 2);
      V v_u_2427 = heff_field(v_x21_245, 3);
      V v_body_2428 = heff_field(v_x21_245, 4);
      heff_take_n(v_x21_245, 29ULL, 5);
      V v_t_2429 = heff_tr(heff_call(v_chk_243, 2, (V[]){v_body_2428, v_acc_242}));
      V v_t_2430 = heff_tr(heff_call(heff_dup(v_typ_244), 2, (V[]){v_u_2427, v_t_2429}));
      V v_t_2443 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam1, 2, 1, (V[]){v_typ_244}); V a_1 = v_ps_2426; V a_2 = v_t_2430; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_ps_2426); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2424, v_t_2443});
    }
    case TAG_DeclTheory: {
      V v_x_2444 = heff_field(v_x21_245, 0);
      V v_ps_2446 = heff_field(v_x21_245, 2);
      V v_body_2447 = heff_field(v_x21_245, 3);
      heff_take_n(v_x21_245, 13ULL, 4);
      V v_t_2448 = heff_tr(heff_call(v_chk_243, 2, (V[]){v_body_2447, v_acc_242}));
      V v_t_2461 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam2, 2, 1, (V[]){v_typ_244}); V a_1 = v_ps_2446; V a_2 = v_t_2448; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_ps_2446); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2444, v_t_2461});
    }
    case TAG_DeclPrimitive: {
      V v_x_2462 = heff_field(v_x21_245, 0);
      V v_t_2464 = heff_field(v_x21_245, 2);
      heff_take_n(v_x21_245, 5ULL, 3);
      heff_drop(v_chk_243);
      V v_t_2465 = heff_tr(heff_call(v_typ_244, 2, (V[]){v_t_2464, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2462, v_t_2465});
    }
    case TAG_DeclTest: {
      V v_x_2466 = heff_field(v_x21_245, 0);
      heff_take_n(v_x21_245, 1ULL, 2);
      heff_drop(v_chk_243);
      heff_drop(v_typ_244);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2466, v_acc_242});
    }
    case TAG_DeclWatch: {
      V v_e_2468 = heff_field(v_x21_245, 0);
      heff_take_n(v_x21_245, 1ULL, 1);
      heff_drop(v_typ_244);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(v_chk_243, 2, (V[]){v_e_2468, v_acc_242});
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsDeclF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam0(V self, V *args) {
  V v_m_2412 = args[0];
  V v_a_2413 = args[1];
  V v_chk_243 = heff_env(self)[0];
  switch (heff_tag_of(v_m_2412)) {
  case TAG_At: {
    V v_x21_2414 = heff_field(v_m_2412, 0);
    V v_ru_24m_2412_24At = heff_take_reuse_n(v_m_2412, 1ULL, 2);
    switch (heff_tag_of(v_x21_2414)) {
    case TAG_MkEquation: {
      V v_f_2416 = heff_field(v_x21_2414, 0);
      V v_ps_2418 = heff_field(v_x21_2414, 2);
      V v_rhs_2419 = heff_field(v_x21_2414, 3);
      heff_take_n(v_x21_2414, 13ULL, 4);
      heff_clo_take(self, 1);
      V v_t_2420 = heff_tr(heff_call(v_chk_243, 2, (V[]){v_rhs_2419, v_a_2413}));
      V v_t_2421 = ({ V a_0 = v_ps_2418; V a_1 = v_t_2420; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(a_0, a_1)); heff_drop(v_ps_2418); r_; });
      return heff_tag_at_n(v_ru_24m_2412_24At, TAG_Cons, 2, (V[]){v_f_2416, v_t_2421});
    }
    default: return heff_nomatch(v_x21_2414);
    }
  }
  default: return heff_nomatch(v_m_2412);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam1(V self, V *args) {
  V v_m_2431 = args[0];
  V v_a_2432 = args[1];
  V v_typ_244 = heff_env(self)[0];
  switch (heff_tag_of(v_m_2431)) {
  case TAG_At: {
    V v_x21_2433 = heff_field(v_m_2431, 0);
    V v_ru_24m_2431_24At = heff_take_reuse_n(v_m_2431, 1ULL, 2);
    switch (heff_tag_of(v_x21_2433)) {
    case TAG_ExplicitParam: {
      V v_x_2435 = heff_field(v_x21_2433, 0);
      V v_t_2437 = heff_field(v_x21_2433, 2);
      heff_take_n(v_x21_2433, 5ULL, 3);
      heff_clo_take(self, 1);
      V v_t_2438 = heff_tr(heff_call(v_typ_244, 2, (V[]){v_t_2437, v_a_2432}));
      return heff_tag_at_n(v_ru_24m_2431_24At, TAG_Cons, 2, (V[]){v_x_2435, v_t_2438});
    }
    case TAG_ImplicitParam: {
      V v_x_2439 = heff_field(v_x21_2433, 0);
      V v_t_2441 = heff_field(v_x21_2433, 2);
      heff_take_n(v_x21_2433, 5ULL, 3);
      heff_clo_take(self, 1);
      V v_t_2442 = heff_tr(heff_call(v_typ_244, 2, (V[]){v_t_2441, v_a_2432}));
      return heff_tag_at_n(v_ru_24m_2431_24At, TAG_Cons, 2, (V[]){v_x_2439, v_t_2442});
    }
    default: return heff_nomatch(v_x21_2433);
    }
  }
  default: return heff_nomatch(v_m_2431);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam2(V self, V *args) {
  V v_m_2449 = args[0];
  V v_a_2450 = args[1];
  V v_typ_244 = heff_env(self)[0];
  switch (heff_tag_of(v_m_2449)) {
  case TAG_At: {
    V v_x21_2451 = heff_field(v_m_2449, 0);
    V v_ru_24m_2449_24At = heff_take_reuse_n(v_m_2449, 1ULL, 2);
    switch (heff_tag_of(v_x21_2451)) {
    case TAG_ExplicitParam: {
      V v_x_2453 = heff_field(v_x21_2451, 0);
      V v_t_2455 = heff_field(v_x21_2451, 2);
      heff_take_n(v_x21_2451, 5ULL, 3);
      heff_clo_take(self, 1);
      V v_t_2456 = heff_tr(heff_call(v_typ_244, 2, (V[]){v_t_2455, v_a_2450}));
      return heff_tag_at_n(v_ru_24m_2449_24At, TAG_Cons, 2, (V[]){v_x_2453, v_t_2456});
    }
    case TAG_ImplicitParam: {
      V v_x_2457 = heff_field(v_x21_2451, 0);
      V v_t_2459 = heff_field(v_x21_2451, 2);
      heff_take_n(v_x21_2451, 5ULL, 3);
      heff_clo_take(self, 1);
      V v_t_2460 = heff_tr(heff_call(v_typ_244, 2, (V[]){v_t_2459, v_a_2450}));
      return heff_tag_at_n(v_ru_24m_2449_24At, TAG_Cons, 2, (V[]){v_x_2457, v_t_2460});
    }
    default: return heff_nomatch(v_x21_2451);
    }
  }
  default: return heff_nomatch(v_m_2449);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str7, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str8, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str9, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str10, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str11, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str12, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str13, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str14, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str15, 0, "");
Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_entry, 7, 0};

V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle(V v_tag_240, V v_n_241, V v_acc_242, V v_n_243, V v_acc_244, V v_x2_245, V v_acc_246) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156: {
    top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156: ;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_n1_247 = heff_field(v_n_241, 0);
      V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 1ULL, 2);
      switch (heff_tag_of(v_n1_247)) {
      case TAG_TPi: {
        V v_b_249 = heff_field(v_n1_247, 0);
        V v_cod_2410 = heff_field(v_n1_247, 1);
        heff_take_n(v_n1_247, 3ULL, 2);
        V v_x2_2411 = v_b_249;
        V v_acc_2412 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_cod_2410, v_acc_242));
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_PiNamed: {
          V v_x_2413 = heff_field(v_x2_2411, 0);
          V v_t_2415 = heff_field(v_x2_2411, 2);
          heff_take_n(v_x2_2411, 5ULL, 3);
          heff_drop(v_n_243);
          heff_drop(v_acc_244);
          heff_drop(v_x2_245);
          heff_drop(v_acc_246);
          V v_cell_2416 = heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2413, heff_hole()});
          V v_u_2417 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24dps(v_t_2415, v_acc_2412, v_cell_2416));
          heff_drop(v_u_2417);
          return v_cell_2416;
        }
        case TAG_PiImplicit: {
          V v_x_2418 = heff_field(v_x2_2411, 0);
          V v_t_2421 = heff_field(v_x2_2411, 3);
          V v_d_2422 = heff_field(v_x2_2411, 4);
          heff_take_n(v_x2_2411, 25ULL, 5);
          heff_drop(v_n_243);
          heff_drop(v_acc_244);
          heff_drop(v_x2_245);
          heff_drop(v_acc_246);
          V v_acc_2424;
          switch (heff_tag_of(v_d_2422)) {
          case TAG_Nothing: {
            v_acc_2424 = v_acc_2412;
            break;
          }
          case TAG_Just: {
            V v_c_2423 = heff_field(v_d_2422, 0);
            heff_take_n(v_d_2422, 1ULL, 1);
            v_acc_2424 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_c_2423, v_acc_2412));
            break;
          }
          default: heff_nomatch(v_d_2422);
          }
          V v_cell_2425 = heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2418, heff_hole()});
          V v_u_2426 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24dps(v_t_2421, v_acc_2424, v_cell_2425));
          heff_drop(v_u_2426);
          return v_cell_2425;
        }
        case TAG_PiInstance: {
          V v_x_2427 = heff_field(v_x2_2411, 0);
          V v_t_2430 = heff_field(v_x2_2411, 3);
          heff_take_n(v_x2_2411, 9ULL, 4);
          heff_drop(v_n_243);
          heff_drop(v_acc_244);
          heff_drop(v_x2_245);
          heff_drop(v_acc_246);
          V v_cell_2431 = heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2427, heff_hole()});
          V v_u_2432 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24dps(v_t_2430, v_acc_2412, v_cell_2431));
          heff_drop(v_u_2432);
          return v_cell_2431;
        }
        case TAG_PiAnon: {
          V v_d_2433 = heff_field(v_x2_2411, 0);
          heff_take_n(v_x2_2411, 1ULL, 1);
          heff_drop_cell(v_ru_24n_241_24At, 2);
          V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156);
          V t_1 = v_d_2433;
          V t_2 = v_acc_2412;
          V t_3 = v_n_243;
          V t_4 = v_acc_244;
          V t_5 = v_x2_245;
          V t_6 = v_acc_246;
          v_tag_240 = t_0;
          v_n_241 = t_1;
          v_acc_242 = t_2;
          v_n_243 = t_3;
          v_acc_244 = t_4;
          v_x2_245 = t_5;
          v_acc_246 = t_6;
          goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156;
        }
        default: return heff_nomatch(v_x2_2411);
        }
      }
      case TAG_TSig: {
        V v_fs_2434 = heff_field(v_n1_247, 0);
        heff_take_n(v_n1_247, 1ULL, 1);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return (g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(v_fs_2434, v_acc_242));
      }
      case TAG_TSum: {
        V v_vs_2435 = heff_field(v_n1_247, 0);
        heff_take_n(v_n1_247, 1ULL, 1);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return ({ V a_0 = v_vs_2435; V a_1 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(a_0, a_1)); heff_drop(v_vs_2435); r_; });
      }
      case TAG_TType: {
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_acc_242;
      }
      case TAG_TInt: {
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_acc_242;
      }
      case TAG_TFloat: {
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_acc_242;
      }
      case TAG_TString: {
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_acc_242;
      }
      case TAG_TRune: {
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_acc_242;
      }
      case TAG_TArray: {
        V v_a_2436 = heff_field(v_n1_247, 0);
        heff_take_n(v_n1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156);
        V t_1 = v_a_2436;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_x2_245;
        V t_6 = v_acc_246;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156;
      }
      case TAG_TFixed: {
        heff_take_n(v_n1_247, 0ULL, 1);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_acc_242;
      }
      case TAG_TInf: {
        V v_i_2438 = heff_field(v_n1_247, 0);
        heff_take_n(v_n1_247, 1ULL, 1);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str0);
        V t_2 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str1);
        V t_3 = v_i_2438;
        V t_4 = v_acc_242;
        V t_5 = v_x2_245;
        V t_6 = v_acc_246;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_TChk: {
        V v_c_2439 = heff_field(v_n1_247, 0);
        heff_take_n(v_n1_247, 1ULL, 1);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str2);
        V t_2 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str3);
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_c_2439;
        V t_6 = v_acc_242;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      case TAG_TNominal: {
        V v_t_2440 = heff_field(v_n1_247, 0);
        heff_take_n(v_n1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156);
        V t_1 = v_t_2440;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_x2_245;
        V t_6 = v_acc_246;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156;
      }
      default: return heff_nomatch(v_n1_247);
      }
    }
    default: return heff_nomatch(v_n_241);
    }
  }
  case TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648: {
    top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648: ;
    switch (heff_tag_of(v_n_243)) {
    case TAG_At: {
      V v_n1_2441 = heff_field(v_n_243, 0);
      V v_ru_24n_243_24At = heff_take_reuse_n(v_n_243, 1ULL, 2);
      switch (heff_tag_of(v_n1_2441)) {
      case TAG_IVar: {
        V v_x_2443 = heff_field(v_n1_2441, 0);
        heff_take_n(v_n1_2441, 1ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        return heff_tag_at_n(v_ru_24n_243_24At, TAG_Cons, 2, (V[]){v_x_2443, v_acc_244});
      }
      case TAG_INotationVar: {
        heff_take_n(v_n1_2441, 0ULL, 3);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        return v_acc_244;
      }
      case TAG_IInt: {
        heff_take_n(v_n1_2441, 0ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        return v_acc_244;
      }
      case TAG_IFloat: {
        heff_take_n(v_n1_2441, 0ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        return v_acc_244;
      }
      case TAG_IString: {
        heff_take_n(v_n1_2441, 0ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        return v_acc_244;
      }
      case TAG_IBytes: {
        heff_take_n(v_n1_2441, 0ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        return v_acc_244;
      }
      case TAG_IPrim: {
        heff_take_n(v_n1_2441, 0ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        return v_acc_244;
      }
      case TAG_IRune: {
        heff_take_n(v_n1_2441, 0ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        return v_acc_244;
      }
      case TAG_IApp: {
        V v_h_2453 = heff_field(v_n1_2441, 0);
        V v_args_2454 = heff_field(v_n1_2441, 1);
        heff_take_n(v_n1_2441, 3ULL, 2);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        V v_acc_2455 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s985293991x1511639658(v_args_2454, v_acc_244));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_h_2453;
        V t_4 = v_acc_2455;
        V t_5 = v_x2_245;
        V t_6 = v_acc_246;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_IAnn: {
        V v_c_2456 = heff_field(v_n1_2441, 0);
        V v_t_2457 = heff_field(v_n1_2441, 1);
        heff_take_n(v_n1_2441, 3ULL, 2);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        V v_acc_2458 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2457, v_acc_244));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str4);
        V t_4 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str5);
        V t_5 = v_c_2456;
        V t_6 = v_acc_2458;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      case TAG_ISpec: {
        V v_a_2459 = heff_field(v_n1_2441, 0);
        V v_v_2462 = heff_field(v_n1_2441, 3);
        heff_take_n(v_n1_2441, 9ULL, 4);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        V v_acc_2463 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_v_2462, v_acc_244));
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_a_2459;
        V t_4 = v_acc_2463;
        V t_5 = v_x2_245;
        V t_6 = v_acc_246;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_IUpdate: {
        V v_a_2464 = heff_field(v_n1_2441, 0);
        V v_fs_2465 = heff_field(v_n1_2441, 1);
        heff_take_n(v_n1_2441, 3ULL, 2);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        V v_acc_2466 = ({ V a_0 = v_fs_2465; V a_1 = v_acc_244; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(a_0, a_1)); heff_drop(v_fs_2465); r_; });
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_a_2464;
        V t_4 = v_acc_2466;
        V t_5 = v_x2_245;
        V t_6 = v_acc_246;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_IAnnLam: {
        V v_x_2467 = heff_field(v_n1_2441, 0);
        V v_t_2469 = heff_field(v_n1_2441, 2);
        V v_b_2470 = heff_field(v_n1_2441, 3);
        heff_take_n(v_n1_2441, 13ULL, 4);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        V v_acc_2471 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_b_2470, v_acc_244));
        V v_t_2472 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2469, v_acc_2471));
        return heff_tag_at_n(v_ru_24n_243_24At, TAG_Cons, 2, (V[]){v_x_2467, v_t_2472});
      }
      case TAG_IInvalid: {
        heff_take_n(v_n1_2441, 0ULL, 3);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        return v_acc_244;
      }
      case TAG_INominal: {
        V v_i_2476 = heff_field(v_n1_2441, 0);
        heff_take_n(v_n1_2441, 1ULL, 1);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_i_2476;
        V t_4 = v_acc_244;
        V t_5 = v_x2_245;
        V t_6 = v_acc_246;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_ILitEq: {
        V v_x_2477 = heff_field(v_n1_2441, 0);
        V v_eq_2479 = heff_field(v_n1_2441, 2);
        V v_lit_2480 = heff_field(v_n1_2441, 3);
        heff_take_n(v_n1_2441, 13ULL, 4);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        V v_t_2481 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_lit_2480, v_acc_244));
        return heff_tag_at_n(v_ru_24n_243_24At, TAG_Cons, 2, (V[]){v_x_2477, heff_tag_n(TAG_Cons, 2, (V[]){v_eq_2479, v_t_2481})});
      }
      case TAG_ILazy: {
        V v_c_2482 = heff_field(v_n1_2441, 0);
        heff_take_n(v_n1_2441, 1ULL, 1);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str6);
        V t_4 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str7);
        V t_5 = v_c_2482;
        V t_6 = v_acc_244;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      case TAG_ITuple: {
        V v_cs_2483 = heff_field(v_n1_2441, 0);
        heff_take_n(v_n1_2441, 1ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_x2_245);
        heff_drop(v_acc_246);
        heff_drop_cell(v_ru_24n_243_24At, 2);
        V v_t_2484 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_cs_2483));
        return ({ V a_0 = v_acc_244; V a_1 = v_t_2484; V r_ = (g_list_2efoldl_24s1437740164x269163243(a_0, a_1)); heff_drop(v_t_2484); r_; });
      }
      default: return heff_nomatch(v_n1_2441);
      }
    }
    default: return heff_nomatch(v_n_243);
    }
  }
  case TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291: {
    top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291: ;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_2485 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 1ULL, 2);
      switch (heff_tag_of(v_x21_2485)) {
      case TAG_CInf: {
        V v_i_2487 = heff_field(v_x21_2485, 0);
        heff_take_n(v_x21_2485, 1ULL, 1);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_i_2487;
        V t_4 = v_acc_246;
        V t_5 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str8);
        V t_6 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str9);
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_CType: {
        V v_t_2488 = heff_field(v_x21_2485, 0);
        heff_take_n(v_x21_2485, 1ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156);
        V t_1 = v_t_2488;
        V t_2 = v_acc_246;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str10);
        V t_6 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str11);
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156;
      }
      case TAG_CLam: {
        V v_x_2489 = heff_field(v_x21_2485, 0);
        V v_b_2491 = heff_field(v_x21_2485, 2);
        heff_take_n(v_x21_2485, 5ULL, 3);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        V v_cell_2492 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_x_2489, heff_hole()});
        V v_u_2493 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(v_b_2491, v_acc_246, v_cell_2492));
        heff_drop(v_u_2493);
        return v_cell_2492;
      }
      case TAG_CImplicitLam: {
        V v_x_2494 = heff_field(v_x21_2485, 0);
        V v_b_2496 = heff_field(v_x21_2485, 2);
        heff_take_n(v_x21_2485, 5ULL, 3);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        V v_cell_2497 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_x_2494, heff_hole()});
        V v_u_2498 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(v_b_2496, v_acc_246, v_cell_2497));
        heff_drop(v_u_2498);
        return v_cell_2497;
      }
      case TAG_CAnnLam: {
        V v_x_2499 = heff_field(v_x21_2485, 0);
        V v_t_24101 = heff_field(v_x21_2485, 2);
        V v_b_24102 = heff_field(v_x21_2485, 3);
        heff_take_n(v_x21_2485, 13ULL, 4);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        V v_acc_24103 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_24102, v_acc_246));
        V v_t_24104 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_24101, v_acc_24103));
        return heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_x_2499, v_t_24104});
      }
      case TAG_CTag: {
        V v_args_24107 = heff_field(v_x21_2485, 2);
        heff_take_n(v_x21_2485, 4ULL, 3);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        return ({ V b_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 1)); V a_1 = v_args_24107; V a_2 = v_acc_246; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_args_24107); r_; });
      }
      case TAG_CStruct: {
        V v_fs_24108 = heff_field(v_x21_2485, 0);
        heff_take_n(v_x21_2485, 1ULL, 1);
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        return (g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(v_fs_24108, v_acc_246));
      }
      case TAG_CMatch: {
        V v_s_24109 = heff_field(v_x21_2485, 0);
        V v_alts_24110 = heff_field(v_x21_2485, 1);
        heff_take_n(v_x21_2485, 3ULL, 2);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        V v_acc_24111 = ({ V a_0 = v_alts_24110; V a_1 = v_acc_246; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a_0, a_1)); heff_drop(v_alts_24110); r_; });
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_s_24109;
        V t_4 = v_acc_24111;
        V t_5 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str12);
        V t_6 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str13);
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_CLetIn: {
        V v_rhs_24112 = heff_field(v_x21_2485, 0);
        V v_a_24113 = heff_field(v_x21_2485, 1);
        heff_take_n(v_x21_2485, 3ULL, 2);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        V v_acc_24119;
        switch (heff_tag_of(v_a_24113)) {
        case TAG_At: {
          V v_x21_24114 = heff_field(v_a_24113, 0);
          heff_take_n(v_a_24113, 1ULL, 2);
          switch (heff_tag_of(v_x21_24114)) {
          case TAG_MkAlt: {
            V v_p_24116 = heff_field(v_x21_24114, 0);
            V v_b_24117 = heff_field(v_x21_24114, 1);
            heff_take_n(v_x21_24114, 3ULL, 2);
            V v_t_24118 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_24117, v_acc_246));
            v_acc_24119 = (g_heff_2eelab_2eclauses_2epatIdents_24tok2(v_ru_24x2_245_24At, v_p_24116, v_t_24118));
            break;
          }
          default: heff_nomatch(v_x21_24114);
          }
          break;
        }
        default: heff_nomatch(v_a_24113);
        }
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_rhs_24112;
        V t_4 = v_acc_24119;
        V t_5 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str14);
        V t_6 = ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_str15);
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648;
      }
      case TAG_CLocal: {
        V v_body_24120 = heff_field(v_x21_2485, 0);
        V v_ds_24121 = heff_field(v_x21_2485, 1);
        heff_take_n(v_x21_2485, 3ULL, 2);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        V v_acc_24122 = ({ V b_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 3)); V a_1 = v_ds_24121; V a_2 = v_acc_246; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_ds_24121); r_; });
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_body_24120;
        V t_6 = v_acc_24122;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      case TAG_CAbandon: {
        heff_drop(v_n_241);
        heff_drop(v_acc_242);
        heff_drop(v_n_243);
        heff_drop(v_acc_244);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        return v_acc_246;
      }
      case TAG_CNominal: {
        V v_c_24123 = heff_field(v_x21_2485, 0);
        heff_take_n(v_x21_2485, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_245_24At, 2);
        V t_0 = NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291);
        V t_1 = v_n_241;
        V t_2 = v_acc_242;
        V t_3 = v_n_243;
        V t_4 = v_acc_244;
        V t_5 = v_c_24123;
        V t_6 = v_acc_246;
        v_tag_240 = t_0;
        v_n_241 = t_1;
        v_acc_242 = t_2;
        v_n_243 = t_3;
        v_acc_244 = t_4;
        v_x2_245 = t_5;
        v_acc_246 = t_6;
        goto top_TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291;
      }
      default: return heff_nomatch(v_x21_2485);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_24cycle(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_t_248 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_a_246)));
        V v_t_249 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), v_acc_241));
        v_t_2410 = (g_prelude_2e_2b_2b(v_t_248, v_t_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s1827228259x1963388956(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        heff_take_n(v_a_244, 5ULL, 3);
        V v_t_249 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_248, v_acc_241));
        v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_246, v_t_249});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2410 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_2410, v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2411;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkSegment: {
        V v_a_245 = heff_field(v_a_243, 0);
        v_t_2410 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_a_245)));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411 = (g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2erenameAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameAlt_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameAlt(V v_r_240, V v_x2_241) {
top: ;
  V v_x_242 = heff_take_field(v_r_240, 0);
  V v_chk_243 = heff_get_n(v_r_240, 3, 5);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_sp_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkAlt: {
      V v_p_246 = heff_field(v_x21_244, 0);
      V v_b_247 = heff_field(v_x21_244, 1);
      V v_ru_24x21_244_24MkAlt = heff_take_reuse_n(v_x21_244, 3ULL, 2);
      V v_xs_248 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_p_246)));
      V v_t_249 = ({ V a_0 = v_x_242; V a_1 = v_xs_248; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_242); heff_drop(v_xs_248); r_; });
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_chk_243);
        heff_drop(v_t_249);
        return heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_244_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_246, v_b_247}), v_sp_245});
      } else {
        heff_drop(v_t_249);
        V v_t_2410 = heff_tr(heff_call(v_chk_243, 1, (V[]){v_b_247}));
        return heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_244_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_246, v_t_2410}), v_sp_245});
      }
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameAlt(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2erenameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameField_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameField(V v_r_240, V v_x2_241) {
top: ;
  V v_typ_242 = heff_take_field(v_r_240, 4);
  V v_chk_243 = heff_get_n(v_r_240, 3, 5);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_sp_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_DeclareField: {
      V v_y_246 = heff_field(v_x21_244, 0);
      V v_ysp_247 = heff_field(v_x21_244, 1);
      V v_t_248 = heff_field(v_x21_244, 2);
      V v_d_249 = heff_field(v_x21_244, 3);
      V v_ru_24x21_244_24DeclareField = heff_take_reuse_n(v_x21_244, 15ULL, 4);
      V v_t_2410 = heff_tr(heff_call(v_typ_242, 1, (V[]){v_t_248}));
      V v_t_2413;
      switch (heff_tag_of(v_d_249)) {
      case TAG_Nothing: {
        heff_drop(v_chk_243);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_c_2411 = heff_field(v_d_249, 0);
        V v_ru_24d_249_24Just = heff_take_reuse_n(v_d_249, 1ULL, 1);
        V v_t_2412 = heff_tr(heff_call(v_chk_243, 1, (V[]){v_c_2411}));
        v_t_2413 = heff_tag_at_n(v_ru_24d_249_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_d_249);
      }
      return heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_244_24DeclareField, TAG_DeclareField, 4, 3ULL, (V[]){v_y_246, v_ysp_247, v_t_2410, v_t_2413}), v_sp_245});
    }
    case TAG_BadFieldDecl: {
      V v_e_2414 = heff_field(v_x21_244, 0);
      V v_ru_24x21_244_24BadFieldDecl = heff_take_reuse_n(v_x21_244, 1ULL, 1);
      heff_drop(v_chk_243);
      V v_t_2415 = heff_tr(heff_call(v_typ_242, 1, (V[]){v_e_2414}));
      return heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_244_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2415}), v_sp_245});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameField(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_246 = heff_field(v_a_244, 0);
        v_t_2412 = heff_bool(heff_strEq_c_lent(v_lit_240, v_a_246, 0));
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2412 = heff_bool(heff_strEq_c_lent(v_lit_240, v_a_249, 0));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eanyC_24s77926680x1031377762(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameTypF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameTypF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_TPi: {
      V v_b_244 = heff_field(v_n1_242, 0);
      V v_cod_245 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24TPi = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_247 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_r_248 = heff_dup(v_r_240);
        V v_typ_249 = heff_take_field(v_r_248, 4);
        V v_chk_2410 = heff_get_n(v_r_248, 3, 5);
        V v_x2_2411 = heff_dup(v_b_244);
        V v_t_2432;
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_PiNamed: {
          V v_y_2412 = heff_field(v_x2_2411, 0);
          V v_ysp_2413 = heff_field(v_x2_2411, 1);
          V v_t_2414 = heff_field(v_x2_2411, 2);
          V v_ru_24x2_2411_24PiNamed = heff_take_reuse_n(v_x2_2411, 7ULL, 3);
          heff_drop(v_chk_2410);
          V v_t_2415 = heff_tr(heff_call(v_typ_249, 1, (V[]){v_t_2414}));
          v_t_2432 = heff_tag_re_n(v_ru_24x2_2411_24PiNamed, TAG_PiNamed, 3, 3ULL, (V[]){v_y_2412, v_ysp_2413, v_t_2415});
          break;
        }
        case TAG_PiImplicit: {
          V v_y_2416 = heff_field(v_x2_2411, 0);
          V v_ysp_2417 = heff_field(v_x2_2411, 1);
          V v_bsp_2418 = heff_field(v_x2_2411, 2);
          V v_t_2419 = heff_field(v_x2_2411, 3);
          V v_d_2420 = heff_field(v_x2_2411, 4);
          V v_ru_24x2_2411_24PiImplicit = heff_take_reuse_n(v_x2_2411, 31ULL, 5);
          V v_t_2421 = heff_tr(heff_call(v_typ_249, 1, (V[]){v_t_2419}));
          V v_t_2424;
          switch (heff_tag_of(v_d_2420)) {
          case TAG_Nothing: {
            heff_drop(v_chk_2410);
            v_t_2424 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_c_2422 = heff_field(v_d_2420, 0);
            V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
            V v_t_2423 = heff_tr(heff_call(v_chk_2410, 1, (V[]){v_c_2422}));
            v_t_2424 = heff_tag_at_n(v_ru_24d_2420_24Just, TAG_Just, 1, (V[]){v_t_2423});
            break;
          }
          default: heff_nomatch(v_d_2420);
          }
          v_t_2432 = heff_tag_re_n(v_ru_24x2_2411_24PiImplicit, TAG_PiImplicit, 5, 7ULL, (V[]){v_y_2416, v_ysp_2417, v_bsp_2418, v_t_2421, v_t_2424});
          break;
        }
        case TAG_PiInstance: {
          V v_y_2425 = heff_field(v_x2_2411, 0);
          V v_ysp_2426 = heff_field(v_x2_2411, 1);
          V v_bsp_2427 = heff_field(v_x2_2411, 2);
          V v_t_2428 = heff_field(v_x2_2411, 3);
          V v_ru_24x2_2411_24PiInstance = heff_take_reuse_n(v_x2_2411, 15ULL, 4);
          heff_drop(v_chk_2410);
          V v_t_2429 = heff_tr(heff_call(v_typ_249, 1, (V[]){v_t_2428}));
          v_t_2432 = heff_tag_re_n(v_ru_24x2_2411_24PiInstance, TAG_PiInstance, 4, 7ULL, (V[]){v_y_2425, v_ysp_2426, v_bsp_2427, v_t_2429});
          break;
        }
        case TAG_PiAnon: {
          V v_d_2430 = heff_field(v_x2_2411, 0);
          V v_ru_24x2_2411_24PiAnon = heff_take_reuse_n(v_x2_2411, 1ULL, 1);
          heff_drop(v_chk_2410);
          V v_t_2431 = heff_tr(heff_call(v_typ_249, 1, (V[]){v_d_2430}));
          v_t_2432 = heff_tag_at_n(v_ru_24x2_2411_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2431});
          break;
        }
        default: heff_nomatch(v_x2_2411);
        }
        V v_x_2433 = heff_take_field(v_r_240, 0);
        V v_t_2447;
        switch (heff_tag_of(v_b_244)) {
        case TAG_PiNamed: {
          V v_y_2434 = heff_field(v_b_244, 0);
          heff_take_n(v_b_244, 1ULL, 3);
          if (heff_strEq_c(v_x_2433, v_y_2434)) {
            heff_drop_rec(v_r_240, 5);
            v_t_2447 = v_cod_245;
          } else {
            v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
          }
          break;
        }
        case TAG_PiImplicit: {
          V v_y_2437 = heff_field(v_b_244, 0);
          heff_take_n(v_b_244, 1ULL, 5);
          if (heff_strEq_c(v_x_2433, v_y_2437)) {
            heff_drop_rec(v_r_240, 5);
            v_t_2447 = v_cod_245;
          } else {
            v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
          }
          break;
        }
        case TAG_PiInstance: {
          V v_y_2442 = heff_field(v_b_244, 0);
          heff_take_n(v_b_244, 1ULL, 4);
          if (heff_strEq_c(v_x_2433, v_y_2442)) {
            heff_drop_rec(v_r_240, 5);
            v_t_2447 = v_cod_245;
          } else {
            v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
          }
          break;
        }
        case TAG_PiAnon: {
          heff_take_n(v_b_244, 0ULL, 1);
          heff_drop(v_x_2433);
          v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
          break;
        }
        default: heff_nomatch(v_b_244);
        }
        return heff_tag_re_n(v_ru_24n_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24n1_242_24TPi, TAG_TPi, 2, (V[]){v_t_2432, v_t_2447}), v_sp_247});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_TSig: {
      V v_fs_2448 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TSig = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2450 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameField_clo), 1, (V[]){heff_dup(v_r_240)}));
        V v_t_2452 = ({ V a_0 = v_r_240; V a_1 = v_t_2451; V a_2 = v_fs_2448; V r_ = (g_heff_2eelab_2eclauses_2erenameSeq_24s1032981255x303617189(a_0, a_1, a_2)); heff_drop_rec(v_r_240, 5); heff_drop(v_t_2451); r_; });
        return heff_tag_re_n(v_ru_24n_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24n1_242_24TSig, TAG_TSig, 1, (V[]){v_t_2452}), v_sp_2450});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_TSum: {
      V v_vs_2453 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TSum = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2455 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2465 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameTypF_lam0, 1, 1, (V[]){v_r_240}), v_vs_2453));
        return heff_tag_re_n(v_ru_24n_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24n1_242_24TSum, TAG_TSum, 1, (V[]){v_t_2465}), v_sp_2455});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_TType: {
      heff_drop_rec(v_r_240, 5);
      return v_n_241;
    }
    case TAG_TInt: {
      heff_drop_rec(v_r_240, 5);
      return v_n_241;
    }
    case TAG_TFloat: {
      heff_drop_rec(v_r_240, 5);
      return v_n_241;
    }
    case TAG_TString: {
      heff_drop_rec(v_r_240, 5);
      return v_n_241;
    }
    case TAG_TRune: {
      heff_drop_rec(v_r_240, 5);
      return v_n_241;
    }
    case TAG_TArray: {
      V v_a_2466 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TArray = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2468 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2469 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_a_2466}));
        return heff_tag_re_n(v_ru_24n_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24n1_242_24TArray, TAG_TArray, 1, (V[]){v_t_2469}), v_sp_2468});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_TFixed: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      return v_n_241;
    }
    case TAG_TInf: {
      V v_i_2471 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TInf = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2473 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_2471}));
        return heff_tag_re_n(v_ru_24n_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24n1_242_24TInf, TAG_TInf, 1, (V[]){v_t_2474}), v_sp_2473});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_TChk: {
      V v_c_2475 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TChk = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2477 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2475}));
        return heff_tag_re_n(v_ru_24n_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24n1_242_24TChk, TAG_TChk, 1, (V[]){v_t_2478}), v_sp_2477});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    case TAG_TNominal: {
      V v_t_2479 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TNominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_sp_2481 = heff_field(v_n_241, 1);
        V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 2ULL, 2);
        V v_t_2482 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2479}));
        return heff_tag_re_n(v_ru_24n_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24n1_242_24TNominal, TAG_TNominal, 1, (V[]){v_t_2482}), v_sp_2481});
      }
      default: return heff_nomatch(v_n_241);
      }
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameTypF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam0(V self, V *args) {
  V v_x2_2456 = args[0];
  V v_r_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_At: {
    V v_x21_2457 = heff_field(v_x2_2456, 0);
    V v_sp_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24At = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    switch (heff_tag_of(v_x21_2457)) {
    case TAG_TagVariant: {
      V v_t_2459 = heff_field(v_x21_2457, 0);
      V v_tsp_2460 = heff_field(v_x21_2457, 1);
      V v_args_2461 = heff_field(v_x21_2457, 2);
      V v_ru_24x21_2457_24TagVariant = heff_take_reuse_n(v_x21_2457, 7ULL, 3);
      heff_clo_take(self, 1);
      V v_t_2462 = (g_list_2emap(heff_get_n(v_r_240, 4, 5), v_args_2461));
      return heff_tag_re_n(v_ru_24x2_2456_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_2457_24TagVariant, TAG_TagVariant, 3, 3ULL, (V[]){v_t_2459, v_tsp_2460, v_t_2462}), v_sp_2458});
    }
    case TAG_BadVariant: {
      V v_e_2463 = heff_field(v_x21_2457, 0);
      V v_ru_24x21_2457_24BadVariant = heff_take_reuse_n(v_x21_2457, 1ULL, 1);
      heff_clo_take(self, 1);
      V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_e_2463}));
      return heff_tag_re_n(v_ru_24x2_2456_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_2457_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2464}), v_sp_2458});
    }
    default: return heff_nomatch(v_x21_2457);
    }
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eanyIn_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2eanyIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyIn_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eanyIn(V v_c_240, V v_n_241, V v_a_242) {
top: ;
  V v_ys_243 = (g_list_2emap_24f1539731936x1117725130(((V)&g_heff_2eelab_2eclauses_2eanyIn_str0), MK_INT(0LL), v_n_241));
  V v_xs_244 = heff_take_field(v_a_242, 0);
  V v_t_245 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_244)));
  V v_t_246 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_244));
  V v_t_247 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_243, v_t_246));
  V v_pats_248 = (g_heff_2eelab_2eclauses_2eappendC(v_t_245, v_t_247));
  return ({ V rv_0 = v_pats_248; V rr_ = heff_rec_reuse_nf(v_a_242, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
}
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eanyIn(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColGo_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2etagColGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagColGo_entry, 4, 0};

V g_heff_2eelab_2eclauses_2etagColGo(V v_c_240, V v_v_241, V v_col_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_col_242;
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    HeffT2 v_t_246 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_rfield(v_r_244, 0), heff_dup(v_c_240)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2410;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_p_249 = v_field_248;
        v_t_2410 = v_p_249;
      } else {
        heff_drop(v_field_248);
        v_t_2410 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2etagColGo_str0)});
      }
      V v_t_2411 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_v_241); V a_2 = v_col_242; V a_3 = heff_dup(v_r_244); V a_4 = v_t_2410; V r_ = (g_heff_2eelab_2eclauses_2etagColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2410); r_; });
      V t_0 = v_c_240;
      V t_1 = v_v_241;
      V t_2 = v_t_2411;
      V t_3 = v_rest_245;
      v_c_240 = t_0;
      v_v_241 = t_1;
      v_col_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2etagColGo(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str0, 6, "intAdd");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str1, 6, "intAdd");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str2, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str3, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str4, 6, "intAdd");
HEFF_LIT(g_heff_2eelab_2eclauses_2esizeOk_str5, 5, "intLe");
Clo g_heff_2eelab_2eclauses_2esizeOk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esizeOk_entry, 5, 0};

V g_heff_2eelab_2eclauses_2esizeOk(V v_k_240, V v_ty_241, V v_size_242, V v_w_243, V v_rest_244) {
top: ;
  V v_bits_245 = heff_take_field(v_w_243, 0);
  V v_terms_246 = heff_get_n(v_w_243, 1, 2);
  switch (heff_tag_of(v_ty_241)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_bits_245);
      heff_drop(v_terms_246);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_bits_245);
      heff_drop(v_terms_246);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_sp_2411 = heff_dup(heff_rfield(v_k_240, 6));
      V v_sp_2412 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_bits_245)}), heff_dup(v_sp_2412)});
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), heff_dup(v_sp_2412)});
      V v_t_2415 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2esizeOk_str0); V a_1 = v_sp_2412; V a_2 = v_t_2414; V a_3 = heff_dup(v_terms_246); V r_ = (g_list_2efoldl_24s871632021x1241775640(a_0, a_1, a_2, a_3)); heff_drop(v_sp_2412); r_; });
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2411)});
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2416}), v_sp_2411});
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      V v_args_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2418});
      V v_sp_2420 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2421 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2420), v_args_2419));
      V v_sp_2422 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_bits_245}), heff_dup(v_sp_2422)});
      V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2423}), heff_dup(v_sp_2422)});
      V v_t_2425 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2esizeOk_str1); V a_1 = v_sp_2422; V a_2 = v_t_2424; V a_3 = v_terms_246; V r_ = (g_list_2efoldl_24s871632021x1241775640(a_0, a_1, a_2, a_3)); heff_drop(v_sp_2422); r_; });
      V v_sp_2426 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(64LL)}), heff_dup(v_sp_2426)});
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2427}), v_sp_2426});
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2429});
      V v_sp_2431 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2432 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2431), v_args_2430));
      V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str2)}), heff_dup(v_sp_2431)});
      V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2433, v_t_2432}), v_sp_2431});
      V v_t_2435 = (g_heff_2eelab_2eclauses_2eandC(v_t_2434, v_rest_244, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str3)}), heff_dup(v_sp_2420)});
      V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2436, v_t_2421}), v_sp_2420});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2437, v_t_2435, heff_get_n(v_k_240, 6, 7)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  default: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_bits_245);
      heff_drop(v_terms_246);
      return v_rest_244;
    }
    case TAG_SizeNumber: {
      heff_drop_rec(v_k_240, 7);
      heff_drop(v_bits_245);
      heff_drop(v_terms_246);
      return v_rest_244;
    }
    case TAG_SizeName: {
      V v_sp_2442 = heff_dup(heff_rfield(v_k_240, 6));
      V v_sp_2443 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_bits_245}), heff_dup(v_sp_2443)});
      V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2444}), heff_dup(v_sp_2443)});
      V v_t_2446 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2esizeOk_str4); V a_1 = v_sp_2443; V a_2 = v_t_2445; V a_3 = v_terms_246; V r_ = (g_list_2efoldl_24s871632021x1241775640(a_0, a_1, a_2, a_3)); heff_drop(v_sp_2443); r_; });
      V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2442)});
      V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2447}), v_sp_2442});
      V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
      V v_args_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2449});
      V v_sp_2451 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2452 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2451), v_args_2450));
      V v_t_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esizeOk_str5)}), heff_dup(v_sp_2451)});
      V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2453, v_t_2452}), v_sp_2451});
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2454, v_rest_244, heff_get_n(v_k_240, 6, 7)));
    }
    default: return heff_nomatch(v_size_242);
    }
  }
  }
}
V g_heff_2eelab_2eclauses_2esizeOk_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2esizeOk(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efits_str0, 6, "intAdd");
HEFF_LIT(g_heff_2eelab_2eclauses_2efits_str1, 5, "intLe");
Clo g_heff_2eelab_2eclauses_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efits_entry, 4, 0};

V g_heff_2eelab_2eclauses_2efits(V v_k_240, V v_off_241, V v_w_242, V v_rest_243) {
top: ;
  V v_bits_244 = heff_take_field(v_w_242, 0);
  V v_terms_245 = heff_get_n(v_w_242, 1, 2);
  V v_bits_246 = heff_take_field(v_off_241, 0);
  V v_terms_247 = heff_get_n(v_off_241, 1, 2);
  V v_span_248 = heff_take_field(v_k_240, 6);
  V v_len_249 = heff_get_n(v_k_240, 2, 7);
  V v_t_2410 = heff_intAdd(v_bits_246, v_bits_244);
  V v_sp_2411 = heff_dup(v_span_248);
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_t_2410}), heff_dup(v_sp_2411)});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2412}), heff_dup(v_sp_2411)});
  V v_t_2414 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2efits_str0); V a_1 = v_sp_2411; V a_2 = v_t_2413; V a_3 = v_terms_247; V a_4 = v_terms_245; V r_ = (g_list_2efoldl_24f450671696x846133639(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sp_2411); heff_drop(v_terms_245); r_; });
  V v_x_2415 = v_len_249;
  V v_sp_2416 = heff_dup(v_span_248);
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2415}), heff_dup(v_sp_2416)});
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_2416});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_args_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2419});
  V v_sp_2421 = heff_dup(v_span_248);
  V v_t_2422 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2421), v_args_2420));
  V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2efits_str1)}), heff_dup(v_sp_2421)});
  V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2423, v_t_2422}), v_sp_2421});
  return (g_heff_2eelab_2eclauses_2eandC(v_t_2424, v_rest_243, v_span_248));
}
V g_heff_2eelab_2eclauses_2efits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2efits(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str0, 9, "bitsIntAt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str1, 10, "bytesIntAt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str2, 6, "intAdd");
Clo g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(V v_lit_240, V v_k_241, V v_off_242, V v_flags_243) {
top: ;
  V v_bits_244 = heff_take_field(v_off_242, 0);
  V v_terms_245 = heff_get_n(v_off_242, 1, 2);
  V v_bits_246 = heff_take_field(v_k_241, 1);
  V v_v_247 = heff_take_field(v_k_241, 0);
  V v_span_248 = heff_get_n(v_k_241, 6, 7);
  V v_t_249 = v_bits_246;
  V v_p_2410;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    v_p_2410 = ((V)&g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str0);
  } else {
    heff_drop(v_t_249);
    v_p_2410 = ((V)&g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str1);
  }
  V v_x_2411 = v_v_247;
  V v_sp_2412 = heff_dup(v_span_248);
  V v_sp_2413 = heff_dup(v_span_248);
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_bits_244}), heff_dup(v_sp_2413)});
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2414}), heff_dup(v_sp_2413)});
  V v_t_2416 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_str2); V a_1 = v_sp_2413; V a_2 = v_t_2415; V a_3 = v_terms_245; V r_ = (g_list_2efoldl_24s871632021x1241775640(a_0, a_1, a_2, a_3)); heff_drop(v_sp_2413); r_; });
  V v_sp_2417 = heff_dup(v_span_248);
  V v_sp_2418 = heff_dup(v_span_248);
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2411}), heff_dup(v_sp_2412)});
  V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2419}), v_sp_2412});
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_lit_240}), heff_dup(v_sp_2417)});
  V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), v_sp_2417});
  V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_flags_243}), heff_dup(v_sp_2418)});
  V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2423}), v_sp_2418});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2425})});
  V v_args_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2426});
  V v_sp_2428 = v_span_248;
  V v_t_2429 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2428), v_args_2427));
  V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_p_2410}), heff_dup(v_sp_2428)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2429}), v_sp_2428});
}
V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2ebinTest_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2eclauses_2ebinTest_24cpr(V v_k_240) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2eclauses_2ebinTest_24cpr_lam0, 4, 1, (V[]){v_k_240})}});
}
V g_heff_2eelab_2eclauses_2ebinTest_24cpr_lam0(V self, V *args) {
  V v_env_241 = args[0];
  V v_i_242 = args[1];
  V v_off_243 = args[2];
  V v_segs_244 = args[3];
  V v_k_240 = heff_env(self)[0];
  V v_t_245 = (g_heff_2eelab_2eclauses_2ebinTest(heff_dup(v_k_240)));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_245; V a_1 = v_k_240; V a_2 = v_env_241; V a_3 = v_i_242; V a_4 = v_off_243; V a_5 = v_segs_244; V r_ = (g_heff_2eelab_2eclauses_2ebinTestGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_segs_244); r_; });
}
Clo g_heff_2eelab_2eclauses_2ebinTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinTest_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ebinTest(V v_k_240) {
top: ;
  HeffT1 v_t_241 = (g_heff_2eelab_2eclauses_2ebinTest_24cpr(v_k_240));
  {
    V v_field_242 = v_t_241.f[0];
    return heff_rec_n(1, shape_go, (V[]){v_field_242});
  }
}
V g_heff_2eelab_2eclauses_2ebinTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinTest(a[0]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str3, 0, "");

HeffT2 g_heff_2eelab_2eclauses_2ewholeSeg_24cpr(V v_s_240, V v_ty_241, V v_size_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_ty_241)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      switch (heff_tag_of(v_v_243)) {
      case TAG_At: {
        V v_v1_244 = heff_field(v_v_243, 0);
        switch (heff_tag_of(v_v1_244)) {
        case TAG_PatVar: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatTag: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatOp: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatInt: {
          V v_n_2413 = heff_field(v_v1_244, 0);
          V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
          V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
          V v_t_2417 = heff_intAdd(heff_intMod_lent(v_n_2413, v_t_2414, 2), v_t_2415);
          V v_b_2418 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_box_word((((int64_t)8ULL) / ((int64_t)8ULL))), heff_intMod(v_t_2417, v_t_2416), ((V)&g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str0)));
          V v_t_2419 = heff_intMod(heff_get_n(v_s_240, 3, 5), MK_INT(2LL));
          V v_t_2420;
          if ((heff_unbox_word(v_t_2419) == ((int64_t)1ULL))) {
            v_t_2420 = ({ V a_0 = v_b_2418; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str1); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2418); r_; });
          } else {
            v_t_2420 = v_b_2418;
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
        }
        case TAG_PatFloat: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatString: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatBinary: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRune: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRecord: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatWord: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatAs: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v1_244)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_v_243)}});
      }
    }
    case TAG_SizeNumber: {
      V v_m_2430 = heff_field(v_size_242, 0);
      switch (heff_tag_of(v_v_243)) {
      case TAG_At: {
        V v_v1_2431 = heff_field(v_v_243, 0);
        switch (heff_tag_of(v_v1_2431)) {
        case TAG_PatVar: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatTag: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatOp: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatInt: {
          V v_n_2440 = heff_field(v_v1_2431, 0);
          V v_t_2441 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_m_2430)));
          V v_t_2442 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_m_2430)));
          V v_t_2443 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_m_2430)));
          V v_t_2444 = heff_intAdd(heff_intMod_lent(v_n_2440, v_t_2441, 2), v_t_2442);
          V v_b_2445 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv_lent(v_m_2430, MK_INT(8LL), 2), heff_intMod(v_t_2444, v_t_2443), ((V)&g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str2)));
          V v_t_2446 = heff_intMod(heff_get_n(v_s_240, 3, 5), MK_INT(2LL));
          V v_t_2447;
          if ((heff_unbox_word(v_t_2446) == ((int64_t)1ULL))) {
            v_t_2447 = ({ V a_0 = v_b_2445; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2eelab_2eclauses_2ewholeSeg_24cpr_str3); V r_ = (g_heff_2esyntax_2epresyntax_2ereversedBytes(a_0, a_1, a_2)); heff_drop(v_b_2445); r_; });
          } else {
            v_t_2447 = v_b_2445;
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2447}});
        }
        case TAG_PatFloat: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatString: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatBinary: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRune: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRecord: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatWord: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatAs: {
          heff_drop_rec(v_s_240, 5);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v1_2431)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_v_243)}});
      }
    }
    case TAG_SizeName: {
      heff_drop_rec(v_s_240, 5);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_size_242)}});
    }
  }
  case TAG_SegmentBinary: {
    heff_drop_rec(v_s_240, 5);
    switch (heff_tag_of(v_size_242)) {
    case TAG_SizeDefault: {
      switch (heff_tag_of(v_v_243)) {
      case TAG_At: {
        V v_v1_2460 = heff_field(v_v_243, 0);
        switch (heff_tag_of(v_v1_2460)) {
        case TAG_PatVar: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatTag: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatOp: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatInt: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatString: {
          V v_str_2471 = heff_field(v_v1_2460, 0);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_str_2471)}});
        }
        case TAG_PatBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRune: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatRecord: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatWord: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_PatAs: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_v1_2460)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_v_243)}});
      }
    }
    case TAG_SizeNumber: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeName: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_size_242)}});
    }
  }
  case TAG_SegmentBits: {
    heff_drop_rec(v_s_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SegmentFloat: {
    heff_drop_rec(v_s_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SegmentUtf: {
    heff_drop_rec(v_s_240, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_ty_241)}});
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str0, 18, "prelude.bitsUtf8At");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str1, 19, "prelude.bytesUtf8At");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str2, 6, "intAdd");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str3, 19, "prelude.bitsUtf16At");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str4, 20, "prelude.bytesUtf16At");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str5, 6, "intAdd");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str6, 11, "runeFromInt");
Clo g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116(V v_lit_240, V v_k_241, V v_off_242, V v_s_243) {
top: ;
  if (heff_intEq_c_lent(v_lit_240, MK_INT(8LL), 2)) {
    heff_drop(v_lit_240);
    heff_drop_rec(v_s_243, 5);
    V v_t_244 = heff_take_field(v_k_241, 1);
    V v_p_245;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_p_245 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str0);
    } else {
      heff_drop(v_t_244);
      v_p_245 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str1);
    }
    V v_x_246 = heff_take_field(v_k_241, 0);
    V v_sp_247 = heff_dup(heff_rfield(v_k_241, 6));
    V v_sp_248 = heff_dup(heff_rfield(v_k_241, 6));
    V v_t_249 = heff_tag_n(TAG_IInt, 1, (V[]){heff_take_field(v_off_242, 0)});
    V v_t_2410 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_248)})});
    V v_t_2411 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str2); V a_1 = v_sp_248; V a_2 = heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_248)}); V a_3 = heff_get_n(v_off_242, 1, 2); V r_ = (g_list_2efoldl_24s871632021x1241775640(a_0, a_1, a_2, a_3)); heff_drop(v_sp_248); r_; });
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_sp_247)});
    V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2412}), v_sp_247});
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_args_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2414});
    V v_sp_2416 = heff_get_n(v_k_241, 6, 7);
    V v_t_2417 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2416), v_args_2415));
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_p_245}), heff_dup(v_sp_2416)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2418, v_t_2417}), v_sp_2416});
  } else {
    if (heff_intEq_c(v_lit_240, MK_INT(16LL))) {
      V v_t_2419 = heff_take_field(v_k_241, 1);
      V v_p_2420;
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_t_2419);
        v_p_2420 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str3);
      } else {
        heff_drop(v_t_2419);
        v_p_2420 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str4);
      }
      V v_x_2421 = heff_take_field(v_k_241, 0);
      V v_sp_2422 = heff_dup(heff_rfield(v_k_241, 6));
      V v_sp_2423 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2424 = heff_tag_n(TAG_IInt, 1, (V[]){heff_take_field(v_off_242, 0)});
      V v_t_2425 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_2423)})});
      V v_t_2426 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str5); V a_1 = v_sp_2423; V a_2 = heff_tag_n(TAG_At, 2, (V[]){v_t_2425, heff_dup(v_sp_2423)}); V a_3 = heff_get_n(v_off_242, 1, 2); V r_ = (g_list_2efoldl_24s871632021x1241775640(a_0, a_1, a_2, a_3)); heff_drop(v_sp_2423); r_; });
      V v_sp_2427 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2421}), heff_dup(v_sp_2422)});
      V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2428}), v_sp_2422});
      V v_t_2430 = heff_tag_n(TAG_IInt, 1, (V[]){heff_get_n(v_s_243, 3, 5)});
      V v_t_2431 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2430, heff_dup(v_sp_2427)})});
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, v_sp_2427}), NTAG(TAG_Nil)});
      V v_args_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2432})});
      V v_sp_2434 = heff_get_n(v_k_241, 6, 7);
      V v_t_2435 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2434), v_args_2433));
      V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_p_2420}), heff_dup(v_sp_2434)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2436, v_t_2435}), v_sp_2434});
    } else {
      V v_i_2437 = (g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(MK_INT(32LL), heff_dup(v_k_241), v_off_242, heff_get_n(v_s_243, 3, 5)));
      V v_t_2440;
      switch (heff_tag_of(v_i_2437)) {
      case TAG_At: {
        V v_s_2439 = heff_dup(heff_field(v_i_2437, 1));
        v_t_2440 = v_s_2439;
        break;
      }
      default: heff_nomatch(v_i_2437);
      }
      V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2437}), v_t_2440});
      V v_args_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
      V v_sp_2443 = heff_get_n(v_k_241, 6, 7);
      V v_t_2444 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2443), v_args_2442));
      V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_str6)}), heff_dup(v_sp_2443)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2445, v_t_2444}), v_sp_2443});
    }
  }
}
V g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eutfRead_24s754287528x1187868116(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eclauses_2esegBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esegBind_entry, 11, 0};

V g_heff_2eelab_2eclauses_2esegBind(V v_b_240, V v_k_241, V v_env_242, V v_i_243, V v_x5_244, V v_off_245, V v_s_246, V v_rest_247, V v_body_248, V v_w_249, V v_x11_2410) {
top: ;
  switch (heff_tag_of(v_x11_2410)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_241, 7);
    heff_drop_rec(v_s_246, 5);
    V v_t_2411 = (g_heff_2eelab_2eclauses_2eappendC(heff_take_field(v_off_245, 1), heff_take_field(v_w_249, 1)));
    V v_t_2412 = heff_intAdd(heff_get_n(v_off_245, 0, 2), heff_take_field(v_w_249, 0));
    return heff_tail(heff_get_n(v_b_240, 0, 1), 6, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_x5_244, ({ V rv_0 = v_t_2412; V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_w_249, 0ULL, 2, shape_bits__terms, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; }), v_rest_247, v_body_248});
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x11_2410, 0);
    V v_ru_24x11_2410_24Just = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop_rec(v_b_240, 1);
      heff_drop_rec(v_k_241, 7);
      heff_drop(v_env_242);
      heff_drop(v_i_243);
      heff_drop_rec(v_off_245, 2);
      heff_drop_rec(v_s_246, 5);
      heff_drop(v_rest_247);
      heff_drop_rec(v_w_249, 2);
      heff_drop(v_x_2413);
      heff_drop_cell(v_ru_24x11_2410_24Just, 1);
      return v_body_248;
    }
    case TAG_Cons: {
      V v_y_2414 = heff_field(v_x5_244, 0);
      V v_ys_2415 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_rhs_2416 = ({ V a_0 = heff_dup(v_k_241); V a_1 = heff_dup(v_off_245); V a_2 = heff_dup(v_w_249); V a_3 = heff_dup(v_s_246); V b_4 = heff_dup(heff_rfield(v_s_246, 1)); V a_5 = heff_get_n(v_s_246, 2, 5); V r_ = (g_heff_2eelab_2eclauses_2esegRead(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
      V v_t_2417 = (g_heff_2eelab_2eclauses_2eappendC(heff_take_field(v_off_245, 1), heff_take_field(v_w_249, 1)));
      V v_t_2418 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, heff_dup(v_y_2414)}), v_env_242});
      V v_t_2419 = heff_intAdd(heff_get_n(v_off_245, 0, 2), heff_take_field(v_w_249, 0));
      V v_body_2420 = heff_tr(heff_call(heff_get_n(v_b_240, 0, 1), 6, (V[]){v_t_2418, heff_intAdd(v_i_243, MK_INT(1LL)), v_ys_2415, ({ V rv_0 = v_t_2419; V rv_1 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_w_249, 0ULL, 2, shape_bits__terms, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; }), v_rest_247, v_body_248}));
      V v_sp_2421 = heff_get_n(v_k_241, 6, 7);
      V v_t_2424;
      switch (heff_tag_of(v_body_2420)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_body_2420, 1));
        v_t_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_body_2420);
      }
      V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Just, TAG_PatVar, 1, (V[]){v_y_2414}), heff_dup(v_sp_2421)});
      V v_t_2426 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2421, 0)); V rr_ = heff_rec_reuse_nf(v_t_2424, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2425, v_body_2420}), v_t_2426});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2416, v_t_2427}), v_sp_2421});
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x11_2410);
  }
}
V g_heff_2eelab_2eclauses_2esegBind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2esegBind(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str0, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str1, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinBindGo_str3, 1, "_");
Clo g_heff_2eelab_2eclauses_2ebinBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinBindGo_entry, 8, 0};

V g_heff_2eelab_2eclauses_2ebinBindGo(V v_b_240, V v_k_241, V v_env_242, V v_i_243, V v_ys_244, V v_off_245, V v_x7_246, V v_body_247) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop_rec(v_k_241, 7);
    heff_drop(v_env_242);
    heff_drop(v_i_243);
    heff_drop(v_ys_244);
    heff_drop(v_off_245);
    return v_body_247;
  }
  case TAG_Cons: {
    V v_s_248 = heff_field(v_x7_246, 0);
    V v_rest_249 = heff_field(v_x7_246, 1);
    V v_ru_24x7_246_24Cons = heff_take_reuse_n(v_x7_246, 3ULL, 2);
    V v_t_2410 = heff_dup(heff_rfield(v_s_248, 1));
    V v_t_2412;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_SegmentInteger: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_SegmentBinary: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_SegmentBits: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_SegmentFloat: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_SegmentUtf: {
      V v_x11_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      v_t_2412 = heff_bool((heff_intEq_c_lent(v_x11_2411, MK_INT(8LL), 2) || heff_intEq_c_lent(v_x11_2411, MK_INT(16LL), 2)));
      heff_drop(v_x11_2411);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      V v_t_2413 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), ((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str0));
      V v_t_2414 = heff_intShow(heff_intAdd_lent(v_i_243, MK_INT(1LL), 2));
      V v_x_2415 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), heff_strAppend(v_t_2413, v_t_2414)));
      V v_rhs_2416 = (g_heff_2eelab_2eclauses_2eutfWidth(heff_dup(v_k_241), heff_dup(v_off_245), heff_dup(v_s_248), heff_dup(heff_rfield(v_s_248, 1))));
      V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), ((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str1));
      V v_t_2418 = heff_intShow(heff_intAdd_lent(v_i_243, MK_INT(1LL), 2));
      V v_x_2419 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), heff_strAppend(v_t_2417, v_t_2418)));
      V v_sp_2420 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2421 = heff_dup(heff_rfield(v_s_248, 0));
      V v_t_2441;
      switch (heff_tag_of(v_t_2421)) {
      case TAG_At: {
        V v_x11_2422 = heff_field(v_t_2421, 0);
        heff_take_n(v_t_2421, 1ULL, 2);
        switch (heff_tag_of(v_x11_2422)) {
        case TAG_PatVar: {
          V v_x_2424 = heff_field(v_x11_2422, 0);
          V v_ru_24x11_2422_24PatVar = heff_take_reuse_n(v_x11_2422, 1ULL, 1);
          if (heff_strEq_c_lent(v_x_2424, ((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str2), 2)) {
            heff_drop(v_x_2424);
            heff_drop_cell(v_ru_24x11_2422_24PatVar, 1);
            v_t_2441 = NTAG(TAG_Nothing);
          } else {
            v_t_2441 = heff_tag_at_n(v_ru_24x11_2422_24PatVar, TAG_Just, 1, (V[]){v_x_2424});
          }
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2422, 0ULL, 3);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2422, 0ULL, 3);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatInt: {
          heff_take_n(v_x11_2422, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatFloat: {
          heff_take_n(v_x11_2422, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2422, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2422, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2422, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2422, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2422, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2422, 0ULL, 3);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x11_2422);
        }
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      V v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2419}), heff_dup(v_sp_2420)});
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2442}), v_sp_2420});
      V v_t_2444 = heff_tag_at_n(v_ru_24x7_246_24Cons, TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
      V v_body_2445 = heff_tr(g_heff_2eelab_2eclauses_2esegBind(v_b_240, heff_dup(v_k_241), v_env_242, v_i_243, v_ys_244, v_off_245, v_s_248, v_rest_249, v_body_247, heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2444}), v_t_2441));
      V v_sp_2446 = heff_get_n(v_k_241, 6, 7);
      V v_t_2449;
      switch (heff_tag_of(v_body_2445)) {
      case TAG_At: {
        V v_s_2448 = heff_dup(heff_field(v_body_2445, 1));
        v_t_2449 = v_s_2448;
        break;
      }
      default: heff_nomatch(v_body_2445);
      }
      V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2415}), heff_dup(v_sp_2446)});
      V v_t_2451 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2446, 0)); V rr_ = heff_rec_reuse_nf(v_t_2449, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2450, v_body_2445}), v_t_2451});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2416, v_t_2452}), v_sp_2446});
    } else {
      heff_drop(v_t_2412);
      V v_t_2453 = (g_heff_2eelab_2eclauses_2ewidthBy(v_env_242, heff_dup(heff_rfield(v_s_248, 4)), heff_dup(heff_rfield(v_s_248, 1)), heff_rfield(v_s_248, 2), heff_rfield(v_s_248, 0)));
      V v_t_2454 = heff_dup(heff_rfield(v_s_248, 0));
      V v_t_2474;
      switch (heff_tag_of(v_t_2454)) {
      case TAG_At: {
        V v_x11_2455 = heff_field(v_t_2454, 0);
        heff_take_n(v_t_2454, 1ULL, 2);
        switch (heff_tag_of(v_x11_2455)) {
        case TAG_PatVar: {
          V v_x_2457 = heff_field(v_x11_2455, 0);
          V v_ru_24x11_2455_24PatVar = heff_take_reuse_n(v_x11_2455, 1ULL, 1);
          if (heff_strEq_c_lent(v_x_2457, ((V)&g_heff_2eelab_2eclauses_2ebinBindGo_str3), 2)) {
            heff_drop(v_x_2457);
            heff_drop_cell(v_ru_24x11_2455_24PatVar, 1);
            v_t_2474 = NTAG(TAG_Nothing);
          } else {
            v_t_2474 = heff_tag_at_n(v_ru_24x11_2455_24PatVar, TAG_Just, 1, (V[]){v_x_2457});
          }
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2455, 0ULL, 3);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2455, 0ULL, 3);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatInt: {
          heff_take_n(v_x11_2455, 0ULL, 1);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatFloat: {
          heff_take_n(v_x11_2455, 0ULL, 1);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2455, 0ULL, 1);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2455, 0ULL, 1);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2455, 0ULL, 1);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2455, 0ULL, 1);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2455, 0ULL, 1);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2455, 0ULL, 3);
          v_t_2474 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x11_2455);
        }
        break;
      }
      default: heff_nomatch(v_t_2454);
      }
      return (g_heff_2eelab_2eclauses_2esegBind_24tok2(v_ru_24x7_246_24Cons, v_b_240, v_k_241, v_env_242, v_i_243, v_ys_244, v_off_245, v_s_248, v_rest_249, v_body_247, v_t_2453, v_t_2474));
    }
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2eclauses_2ebinBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinBindGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epeelAs_24cpr_str0, 1, "_");

HeffT2 g_heff_2eelab_2eclauses_2epeelAs_24cpr(V v_v_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PVar: {
    return ((HeffT2){{heff_dup(v_x2_241), v_e_242}});
  }
  case TAG_PTag: {
    return ((HeffT2){{heff_dup(v_x2_241), v_e_242}});
  }
  case TAG_PLit: {
    return ((HeffT2){{heff_dup(v_x2_241), v_e_242}});
  }
  case TAG_PRec: {
    return ((HeffT2){{heff_dup(v_x2_241), v_e_242}});
  }
  case TAG_PAs: {
    V v_x_2410 = heff_field(v_x2_241, 0);
    V v_p_2411 = heff_field(v_x2_241, 1);
    V v_t_2418;
    if ((heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2eelab_2eclauses_2epeelAs_24cpr_str0), 2) ? 0 : !heff_strEq_c_lent(v_x_2410, v_v_240, 0))) {
      HeffT5 v_t_2412 = (g_heff_2eelab_2eclauses_2erenamer_24cpr(heff_dup(v_x_2410), heff_dup(v_v_240)));
      {
        V v_field_2416 = v_t_2412.f[3];
        heff_drop(v_t_2412.f[0]);
        heff_drop(v_t_2412.f[1]);
        heff_drop(v_t_2412.f[2]);
        heff_drop(v_t_2412.f[4]);
        v_t_2418 = heff_tr(heff_call(v_field_2416, 1, (V[]){v_e_242}));
      }
    } else {
      v_t_2418 = v_e_242;
    }
    V t_0 = v_v_240;
    V t_1 = v_p_2411;
    V t_2 = v_t_2418;
    v_v_240 = t_0;
    v_x2_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_PBin: {
    return ((HeffT2){{heff_dup(v_x2_241), v_e_242}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2eelab_2eclauses_2epeelCols_24cpr(V v_x1_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{v_x2_241, v_e_242}});
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x1_240, 0);
    V v_vs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_v_243);
      heff_drop(v_vs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{v_x2_241, v_e_242}});
    }
    case TAG_Cons: {
      V v_p_245 = heff_field(v_x2_241, 0);
      V v_ps_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      HeffT2 v_t_247 = ({ V a_0 = v_v_243; V a_1 = v_p_245; V a_2 = v_e_242; HeffT2 r_ = (g_heff_2eelab_2eclauses_2epeelAs_24cpr(a_0, a_1, a_2)); heff_drop(v_v_243); heff_drop(v_p_245); r_; });
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_p_27_2410 = v_field_248;
        V v_e_27_2411 = v_field_249;
        HeffT2 v_t_2412 = (g_heff_2eelab_2eclauses_2epeelCols_24cpr(v_vs_244, v_ps_246, v_e_27_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_27_2410, v_field_2413}), v_field_2414}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str2, 1, "_");
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2(V self, V *args); static Clo g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2, 1, 0};
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_rest_246) {
top: ;
  switch (heff_tag_of(v_rest_246)) {
  case TAG_Nil: {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop_rec(v_sp_242, 2);
    heff_drop(v_vars_243);
    heff_drop(v_c_245);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_vars_249 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_rows_2444 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam0, 1, 2, (V[]){v_c_245, v_vars_243}), v_rest_246));
    V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam3, 1, 1, (V[]){heff_dup(v_vars_249)}), v_rows_2444));
    HeffT2 v_t_2449 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_241, heff_dup(v_sp_242), v_vars_249, v_t_2448));
    {
      V v_field_2451 = v_t_2449.f[1];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        heff_drop_rec(v_sp_242, 2);
        V v_e_2452 = v_field_2451;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2452}});
      } else {
        V v_x_2453 = v_field_2451;
        V v_t_2456;
        switch (heff_tag_of(v_x_2453)) {
        case TAG_At: {
          V v_s_2455 = heff_dup(heff_field(v_x_2453, 1));
          v_t_2456 = v_s_2455;
          break;
        }
        default: heff_nomatch(v_x_2453);
        }
        V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str2)}), heff_dup(v_sp_242)});
        V v_t_2458 = ({ V rv_1 = heff_get_n(v_t_2456, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_242, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2457, v_x_2453}), v_t_2458});
        V v_f_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2460}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_rest_246)}});
  }
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam1(V self, V *args) {
  V v_e_2423 = args[0];
  V v_p_2422 = heff_env(self)[0];
  V v_v_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_PVar: {
    V v_x_2424 = heff_field(v_p_2422, 0);
    heff_take_n(v_p_2422, 1ULL, 1);
    if ((heff_strEq_c_lent(v_x_2424, ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str1), 2) ? 0 : !heff_strEq_c_lent(v_x_2424, v_v_2418, 0))) {
      HeffT5 v_t_2425 = (g_heff_2eelab_2eclauses_2erenamer_24cpr(v_x_2424, v_v_2418));
      {
        V v_field_2429 = v_t_2425.f[3];
        heff_drop(v_t_2425.f[0]);
        heff_drop(v_t_2425.f[1]);
        heff_drop(v_t_2425.f[2]);
        heff_drop(v_t_2425.f[4]);
        V f_ = v_field_2429;
        args[0] = v_e_2423;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      heff_drop(v_v_2418);
      heff_drop(v_x_2424);
      return v_e_2423;
    }
  }
  case TAG_PTag: {
    heff_take_n(v_p_2422, 0ULL, 3);
    heff_drop(v_v_2418);
    return v_e_2423;
  }
  case TAG_PLit: {
    heff_take_n(v_p_2422, 0ULL, 1);
    heff_drop(v_v_2418);
    return v_e_2423;
  }
  case TAG_PRec: {
    heff_take_n(v_p_2422, 0ULL, 2);
    heff_drop(v_v_2418);
    return v_e_2423;
  }
  case TAG_PAs: {
    heff_take_n(v_p_2422, 0ULL, 2);
    heff_drop(v_v_2418);
    return v_e_2423;
  }
  case TAG_PBin: {
    heff_take_n(v_p_2422, 0ULL, 2);
    heff_drop(v_v_2418);
    return v_e_2423;
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2(V self, V *args) {
  V v_e_2441 = args[0];
  return v_e_2441;
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam0(V self, V *args) {
  V v_row_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_vars_243 = heff_env(self)[1];
  V v_pats_2411 = heff_take_field(v_row_2410, 0);
  V v_rhs_2412 = heff_take_field(v_row_2410, 1);
  V v_pats_2413 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_pats_2411)));
  heff_clo_take(self, 2);
  HeffT2 v_t_2414 = ({ V a_0 = v_vars_243; V a_1 = heff_dup(v_c_245); HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(a_0, a_1)); heff_drop(v_vars_243); r_; });
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    V v_v_2418;
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_v_2417 = v_field_2416;
      v_v_2418 = v_v_2417;
    } else {
      heff_drop(v_field_2416);
      v_v_2418 = ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_str0);
    }
    HeffT2 v_t_2419 = ({ V a_0 = v_pats_2411; V a_1 = v_c_245; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(a_0, a_1)); heff_drop(v_pats_2411); r_; });
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      V v_t_2442;
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_p_2422 = v_field_2421;
        v_t_2442 = heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam1, 1, 2, (V[]){v_p_2422, v_v_2418});
      } else {
        heff_drop(v_v_2418);
        heff_drop(v_field_2421);
        v_t_2442 = ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam2_clo);
      }
      V v_rhs_2443 = heff_tr(heff_call(v_t_2442, 1, (V[]){v_rhs_2412}));
      return ({ V rv_0 = v_pats_2413; V rv_1 = v_rhs_2443; V rr_ = heff_rec_reuse_nf(v_row_2410, 0ULL, 2, shape_pats__rhs, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
  }
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr_lam3(V self, V *args) {
  V v_row_2445 = args[0];
  V v_vars_249 = heff_env(self)[0];
  V v_pats_2446 = heff_take_field(v_row_2445, 0);
  V v_rhs_2447 = heff_get_n(v_row_2445, 1, 2);
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_249, v_pats_2446, v_rhs_2447));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str0, 43, "a literal and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str1, 42, "a binary and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str4, 1, "_");
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_col_246) {
top: ;
  V v_order_247 = heff_take_field(v_col_246, 1);
  V v_arms_248 = heff_get_n(v_col_246, 0, 3);
  HeffT2 v_t_249 = (g_heff_2eelab_2eclauses_2enoRecMix_24cpr(v_rows_244, heff_dup(v_c_245)));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop(v_order_247);
      heff_drop(v_arms_248);
      V v_e_2412 = v_field_2411;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2412}});
    } else {
      V v_x_2413 = v_field_2411;
      heff_drop(v_x_2413);
      V v_c_2414 = heff_dup(v_c_245);
      V v_rows_2415 = heff_dup(v_rows_244);
      HeffT2 v_t_2435 = ({ V a_0 = v_rows_2415; V b_1 = heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam0, 1, 1, (V[]){v_c_2414}); HeffT2 r_ = (g_heff_2eelab_2eclauses_2eforC_24cpr(a_0, b_1)); heff_drop(v_rows_2415); heff_drop(b_1); r_; });
      {
        V v_field_2437 = v_t_2435.f[1];
        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
        if ((v_tag_2436 == ((int64_t)0ULL))) {
          heff_drop(v_used_240);
          heff_drop(v_bound_241);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_rows_244);
          heff_drop(v_c_245);
          heff_drop(v_order_247);
          heff_drop(v_arms_248);
          V v_e_2438 = v_field_2437;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2438}});
        } else {
          V v_x_2439 = v_field_2437;
          heff_drop(v_x_2439);
          V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_order_247));
          HeffT2 v_t_2493 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam1, 1, 6, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), v_arms_248, heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242)}); V a_1 = v_t_2440; HeffT2 r_ = (g_prelude_2etraverse_24s1807059150x502333573_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2495 = v_t_2493.f[1];
            int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
            if ((v_tag_2494 == ((int64_t)0ULL))) {
              heff_drop(v_used_240);
              heff_drop(v_bound_241);
              heff_drop(v_sp_242);
              heff_drop(v_vars_243);
              heff_drop(v_rows_244);
              heff_drop(v_c_245);
              V v_e_2496 = v_field_2495;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2496}});
            } else {
              V v_x_2497 = v_field_2495;
              V v_t_24114 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam3, 1, 1, (V[]){heff_dup(v_c_245)}); V a_1 = heff_dup(v_rows_244); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
              HeffT2 v_t_24115 = ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = heff_dup(v_sp_242); V a_3 = heff_dup(v_vars_243); V a_4 = v_rows_244; V a_5 = heff_dup(v_c_245); V a_6 = v_t_24114; HeffT2 r_ = (g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
              {
                V v_field_24117 = v_t_24115.f[1];
                int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
                if ((v_tag_24116 == ((int64_t)0ULL))) {
                  heff_drop(v_sp_242);
                  heff_drop(v_vars_243);
                  heff_drop(v_c_245);
                  heff_drop(v_x_2497);
                  V v_e_24118 = v_field_24117;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_24118}});
                } else {
                  V v_x_24119 = v_field_24117;
                  HeffT2 v_t_24120 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(a_0, a_1)); heff_drop(v_vars_243); r_; });
                  {
                    V v_field_24122 = v_t_24120.f[1];
                    int64_t v_tag_24121 = ((int64_t)v_t_24120.f[0]);
                    V v_t_24124;
                    if ((v_tag_24121 == ((int64_t)0ULL))) {
                      V v_v_24123 = v_field_24122;
                      v_t_24124 = v_v_24123;
                    } else {
                      heff_drop(v_field_24122);
                      v_t_24124 = ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str4);
                    }
                    V v_t_24125 = (g_heff_2eelab_2eclauses_2eappendC(v_x_2497, v_x_24119));
                    V v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_t_24124}), heff_dup(v_sp_242)});
                    V v_t_24127 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24126, v_t_24125}), v_sp_242});
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_24127}});
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam0(V self, V *args) {
  V v_row_2416 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2417 = ({ V b_0 = heff_get_n(v_row_2416, 0, 2); V a_1 = v_c_2414; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_p_2420 = v_field_2419;
      switch (heff_tag_of(v_p_2420)) {
      case TAG_PVar: {
        V v_ru_24p_2420_24PVar = heff_take_reuse_n(v_p_2420, 0ULL, 1);
        return heff_tag_at_n(v_ru_24p_2420_24PVar, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PTag: {
        heff_take_n(v_p_2420, 0ULL, 3);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PLit: {
        V v_l_2425 = heff_field(v_p_2420, 0);
        V v_ru_24p_2420_24PLit = heff_take_reuse_n(v_p_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_l_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_field(v_l_2425, 1);
          heff_take_n(v_l_2425, 2ULL, 2);
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_l_2425);
        }
        return heff_tag_at_n(v_ru_24p_2420_24PLit, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_t_2428, ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str0)})});
      }
      case TAG_PRec: {
        heff_take_n(v_p_2420, 0ULL, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PAs: {
        heff_take_n(v_p_2420, 0ULL, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PBin: {
        V v_bsp_2434 = heff_field(v_p_2420, 1);
        heff_take_n(v_p_2420, 2ULL, 2);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_bsp_2434, ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str1)})});
      }
      default: return heff_nomatch(v_p_2420);
      }
    } else {
      heff_drop(v_field_2419);
      return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
  }
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam2(V self, V *args) {
  V v_i_2454 = args[0];
  V v_used_240 = heff_env(self)[0];
  V v_bound_241 = heff_env(self)[1];
  V v_arm_2451 = heff_env(self)[2];
  V v_c_245 = heff_env(self)[3];
  V v_t_2452 = heff_env(self)[4];
  V v_v_2446 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_used_2455 = v_used_240;
  V v_bound_2456 = v_bound_241;
  V v_rows_2457 = heff_get_n(v_arm_2451, 2, 3);
  V v_c_2458 = v_c_245;
  V v_t_2459 = v_t_2452;
  V v_v_2460 = v_v_2446;
  V v_i_2461 = v_i_2454;
  HeffT2 v_t_2462 = ({ V b_0 = heff_get_n(v_t_2459, 2, 4); V a_1 = heff_dup(v_i_2461); HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2464 = v_t_2462.f[1];
    int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
    if ((v_tag_2463 == ((int64_t)0ULL))) {
      V v_p_2465 = v_field_2464;
      V v_used_2466 = v_used_2455;
      V v_bound_2467 = v_bound_2456;
      V v_rows_2468 = v_rows_2457;
      V v_c_2469 = v_c_2458;
      V v_v_2470 = v_v_2460;
      V v_i_2471 = v_i_2461;
      V v_x7_2483;
      switch (heff_tag_of(v_p_2465)) {
      case TAG_PVar: {
        V v_x_2472 = heff_field(v_p_2465, 0);
        V v_ru_24p_2465_24PVar = heff_take_reuse_n(v_p_2465, 1ULL, 1);
        v_x7_2483 = heff_tag_at_n(v_ru_24p_2465_24PVar, TAG_Just, 1, (V[]){v_x_2472});
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_p_2465, 0ULL, 3);
        v_x7_2483 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_p_2465, 0ULL, 1);
        v_x7_2483 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PRec: {
        heff_take_n(v_p_2465, 0ULL, 2);
        v_x7_2483 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PAs: {
        V v_x_2479 = heff_field(v_p_2465, 0);
        heff_take_n(v_p_2465, 1ULL, 2);
        v_x7_2483 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2479});
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_p_2465, 0ULL, 2);
        v_x7_2483 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_p_2465);
      }
      switch (heff_tag_of(v_x7_2483)) {
      case TAG_Nothing: {
        heff_drop(v_rows_2468);
        heff_drop(v_c_2469);
        V v_t_2484 = heff_intShow(heff_intAdd(v_i_2471, MK_INT(1LL)));
        return ({ V a_0 = v_used_2466; V a_1 = v_bound_2467; V a_2 = heff_strAppend(v_v_2470, v_t_2484); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2466); heff_drop(v_bound_2467); r_; });
      }
      case TAG_Just: {
        V v_x_2485 = heff_field(v_x7_2483, 0);
        heff_take_n(v_x7_2483, 1ULL, 1);
        if (!heff_strEq_c_lent(v_x_2485, ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str3), 2)) {
          V v_x1_2486 = (g_list_2eany_24s1006624359x760861690(v_x_2485, v_bound_2467));
          if (!(heff_dup(v_x1_2486) == NTAG(TAG_True))) {
            heff_drop(v_x1_2486);
            V v_t_2487 = ({ V a_0 = v_x_2485; V a_1 = heff_intAdd_lent(v_c_2469, v_i_2471, 1); V a_2 = v_rows_2468; V r_ = (g_heff_2eelab_2eclauses_2enameFits(a_0, a_1, a_2)); heff_drop(v_rows_2468); r_; });
            if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
              heff_drop(v_used_2466);
              heff_drop(v_bound_2467);
              heff_drop(v_v_2470);
              heff_drop(v_i_2471);
              heff_drop(v_t_2487);
              return v_x_2485;
            } else {
              heff_drop(v_x_2485);
              heff_drop(v_t_2487);
              V v_t_2488 = heff_intShow(heff_intAdd(v_i_2471, MK_INT(1LL)));
              return ({ V a_0 = v_used_2466; V a_1 = v_bound_2467; V a_2 = heff_strAppend(v_v_2470, v_t_2488); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2466); heff_drop(v_bound_2467); r_; });
            }
          } else {
            heff_drop(v_rows_2468);
            heff_drop(v_c_2469);
            heff_drop(v_x_2485);
            heff_drop(v_x1_2486);
            V v_t_2489 = heff_intShow(heff_intAdd(v_i_2471, MK_INT(1LL)));
            return ({ V a_0 = v_used_2466; V a_1 = v_bound_2467; V a_2 = heff_strAppend(v_v_2470, v_t_2489); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2466); heff_drop(v_bound_2467); r_; });
          }
        } else {
          heff_drop(v_rows_2468);
          heff_drop(v_c_2469);
          heff_drop(v_x_2485);
          V v_t_2490 = heff_intShow(heff_intAdd(v_i_2471, MK_INT(1LL)));
          return ({ V a_0 = v_used_2466; V a_1 = v_bound_2467; V a_2 = heff_strAppend(v_v_2470, v_t_2490); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2466); heff_drop(v_bound_2467); r_; });
        }
      }
      default: return heff_nomatch(v_x7_2483);
      }
    } else {
      heff_drop(v_rows_2457);
      heff_drop(v_c_2458);
      heff_drop(v_field_2464);
      V v_t_2491 = heff_intShow(heff_intAdd(v_i_2461, MK_INT(1LL)));
      return ({ V a_0 = v_used_2455; V a_1 = v_bound_2456; V a_2 = heff_strAppend(v_v_2460, v_t_2491); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_2455); heff_drop(v_bound_2456); r_; });
    }
  }
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam1(V self, V *args) {
  V v_t_2441 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_arms_248 = heff_env(self)[2];
  V v_used_240 = heff_env(self)[3];
  V v_bound_241 = heff_env(self)[4];
  V v_sp_242 = heff_env(self)[5];
  HeffT2 v_t_2442 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, heff_dup(v_c_245)));
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    V v_v_2446;
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_v_2445 = v_field_2444;
      v_v_2446 = v_v_2445;
    } else {
      heff_drop(v_field_2444);
      v_v_2446 = ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_str2);
    }
    heff_clo_take(self, 6);
    HeffT2 v_t_2447 = ({ V a_0 = v_arms_248; V a_1 = heff_rfield(v_t_2441, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_arms_248); r_; });
    {
      V v_field_2449 = v_t_2447.f[1];
      int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
      V v_arm_2451;
      if ((v_tag_2448 == ((int64_t)0ULL))) {
        heff_drop_rec(v_t_2441, 4);
        V v_arm_2450 = v_field_2449;
        v_arm_2451 = v_arm_2450;
      } else {
        heff_drop(v_field_2449);
        v_arm_2451 = heff_rec_n(3, shape_row__bad__rows, (V[]){v_t_2441, NTAG(TAG_False), NTAG(TAG_Nil)});
      }
      V v_t_2452 = heff_dup(heff_rfield(v_arm_2451, 0));
      V v_t_2453 = (g_heff_2eelab_2eclauses_2eupToGo(MK_INT(0LL), heff_dup(heff_rfield(v_t_2452, 1))));
      V v_t_2492 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam2, 1, 6, (V[]){heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_arm_2451), heff_dup(v_c_245), v_t_2452, v_v_2446}), v_t_2453));
      return (g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_c_245, v_arm_2451, v_t_2492));
    }
  }
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr_lam3(V self, V *args) {
  V v_row_2498 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2499 = ({ V b_0 = heff_get_n(v_row_2498, 0, 2); V a_1 = v_c_245; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_24101 = v_t_2499.f[1];
    int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
    if ((v_tag_24100 == ((int64_t)0ULL))) {
      V v_p_24102 = v_field_24101;
      switch (heff_tag_of(v_p_24102)) {
      case TAG_PVar: {
        heff_take_n(v_p_24102, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_PTag: {
        heff_take_n(v_p_24102, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_PLit: {
        heff_take_n(v_p_24102, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_PRec: {
        heff_take_n(v_p_24102, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_PAs: {
        heff_take_n(v_p_24102, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_PBin: {
        heff_take_n(v_p_24102, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_p_24102);
      }
    } else {
      heff_drop(v_field_24101);
      return NTAG(TAG_True);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str2, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str3, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str4, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str5, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str6, 7, "floatEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str7, 5, "strEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str8, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str9, 6, "runeEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str10, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str11, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str12, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str13, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str14, 5, "False");
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_l_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2elitChecks_24cpr(v_sp_242, v_vars_243, v_rows_244, heff_dup(v_c_245), v_l_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_used_240);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop(v_l_246);
      V v_e_2410 = v_field_249;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2410}});
    } else {
      V v_x_2411 = v_field_249;
      heff_drop(v_x_2411);
      V v_vars_2412 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
      HeffT2 v_t_2413 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, heff_dup(v_c_245)));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        V v_t_2417;
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_v_2416 = v_field_2415;
          v_t_2417 = v_v_2416;
        } else {
          heff_drop(v_field_2415);
          v_t_2417 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str0);
        }
        V v_rows_2418 = ({ V a_0 = v_c_245; V a_1 = v_l_246; V a_2 = v_t_2417; V a_3 = heff_dup(v_rows_244); V r_ = (g_heff_2eelab_2eclauses_2elitYes(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
        V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam0, 1, 1, (V[]){heff_dup(v_vars_2412)}), v_rows_2418));
        HeffT2 v_t_2423 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242), v_vars_2412, v_t_2422));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            heff_drop(v_used_240);
            heff_drop(v_bound_241);
            heff_drop(v_sp_242);
            heff_drop(v_vars_243);
            heff_drop(v_rows_244);
            heff_drop(v_c_245);
            heff_drop(v_l_246);
            V v_e_2426 = v_field_2425;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2426}});
          } else {
            V v_x_2427 = v_field_2425;
            V v_rows_2428 = (g_heff_2eelab_2eclauses_2elitNo(v_c_245, v_l_246, v_rows_244));
            V v_t_2432 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam1, 1, 1, (V[]){heff_dup(v_vars_243)}), v_rows_2428));
            HeffT2 v_t_2433 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_t_2432));
            {
              V v_field_2435 = v_t_2433.f[1];
              int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
              if ((v_tag_2434 == ((int64_t)0ULL))) {
                heff_drop(v_sp_242);
                heff_drop(v_vars_243);
                heff_drop(v_c_245);
                heff_drop(v_l_246);
                heff_drop(v_x_2427);
                V v_e_2436 = v_field_2435;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2436}});
              } else {
                V v_x_2437 = v_field_2435;
                HeffT2 v_t_2438 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(a_0, a_1)); heff_drop(v_vars_243); r_; });
                {
                  V v_field_2440 = v_t_2438.f[1];
                  int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                  V v_t_2442;
                  if ((v_tag_2439 == ((int64_t)0ULL))) {
                    V v_v_2441 = v_field_2440;
                    v_t_2442 = v_v_2441;
                  } else {
                    heff_drop(v_field_2440);
                    v_t_2442 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str1);
                  }
                  V v_t_2462;
                  switch (heff_tag_of(v_l_246)) {
                  case TAG_At: {
                    V v_x11_2443 = heff_dup(heff_field(v_l_246, 0));
                    switch (heff_tag_of(v_x11_2443)) {
                    case TAG_PatVar: {
                      heff_take_n(v_x11_2443, 0ULL, 1);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str2);
                      break;
                    }
                    case TAG_PatTag: {
                      heff_take_n(v_x11_2443, 0ULL, 3);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str3);
                      break;
                    }
                    case TAG_PatOp: {
                      heff_take_n(v_x11_2443, 0ULL, 3);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str4);
                      break;
                    }
                    case TAG_PatInt: {
                      heff_take_n(v_x11_2443, 0ULL, 1);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str5);
                      break;
                    }
                    case TAG_PatFloat: {
                      heff_take_n(v_x11_2443, 0ULL, 1);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str6);
                      break;
                    }
                    case TAG_PatString: {
                      heff_take_n(v_x11_2443, 0ULL, 1);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str7);
                      break;
                    }
                    case TAG_PatBinary: {
                      heff_take_n(v_x11_2443, 0ULL, 1);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str8);
                      break;
                    }
                    case TAG_PatRune: {
                      heff_take_n(v_x11_2443, 0ULL, 1);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str9);
                      break;
                    }
                    case TAG_PatRecord: {
                      heff_take_n(v_x11_2443, 0ULL, 1);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str10);
                      break;
                    }
                    case TAG_PatWord: {
                      heff_take_n(v_x11_2443, 0ULL, 1);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str11);
                      break;
                    }
                    case TAG_PatAs: {
                      heff_take_n(v_x11_2443, 0ULL, 3);
                      v_t_2462 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str12);
                      break;
                    }
                    default: heff_nomatch(v_x11_2443);
                    }
                    break;
                  }
                  default: heff_nomatch(v_l_246);
                  }
                  V v_x1_2463 = heff_dup(v_l_246);
                  V v_t_2487;
                  switch (heff_tag_of(v_x1_2463)) {
                  case TAG_At: {
                    V v_x11_2464 = heff_field(v_x1_2463, 0);
                    V v_sp_2465 = heff_field(v_x1_2463, 1);
                    V v_ru_24x1_2463_24At = heff_take_reuse_n(v_x1_2463, 3ULL, 2);
                    switch (heff_tag_of(v_x11_2464)) {
                    case TAG_PatVar: {
                      heff_take_n(v_x11_2464, 0ULL, 1);
                      v_t_2487 = heff_tag_re_n(v_ru_24x1_2463_24At, TAG_At, 2, 2ULL, (V[]){NTAG(TAG_CAbandon), v_sp_2465});
                      break;
                    }
                    case TAG_PatTag: {
                      heff_take_n(v_x11_2464, 0ULL, 3);
                      v_t_2487 = heff_tag_re_n(v_ru_24x1_2463_24At, TAG_At, 2, 2ULL, (V[]){NTAG(TAG_CAbandon), v_sp_2465});
                      break;
                    }
                    case TAG_PatOp: {
                      heff_take_n(v_x11_2464, 0ULL, 3);
                      v_t_2487 = heff_tag_re_n(v_ru_24x1_2463_24At, TAG_At, 2, 2ULL, (V[]){NTAG(TAG_CAbandon), v_sp_2465});
                      break;
                    }
                    case TAG_PatInt: {
                      V v_x_2473 = heff_field(v_x11_2464, 0);
                      V v_ru_24x11_2464_24PatInt = heff_take_reuse_n(v_x11_2464, 1ULL, 1);
                      V v_t_2474 = heff_tag_at_n(v_ru_24x1_2463_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2464_24PatInt, TAG_IInt, 1, (V[]){v_x_2473}), heff_dup(v_sp_2465)});
                      v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2474}), v_sp_2465});
                      break;
                    }
                    case TAG_PatFloat: {
                      V v_x_2475 = heff_field(v_x11_2464, 0);
                      V v_ru_24x11_2464_24PatFloat = heff_take_reuse_n(v_x11_2464, 1ULL, 1);
                      V v_t_2476 = heff_tag_at_n(v_ru_24x1_2463_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2464_24PatFloat, TAG_IFloat, 1, (V[]){v_x_2475}), heff_dup(v_sp_2465)});
                      v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2476}), v_sp_2465});
                      break;
                    }
                    case TAG_PatString: {
                      V v_x_2477 = heff_field(v_x11_2464, 0);
                      V v_ru_24x11_2464_24PatString = heff_take_reuse_n(v_x11_2464, 1ULL, 1);
                      V v_t_2478 = heff_tag_at_n(v_ru_24x1_2463_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2464_24PatString, TAG_IString, 1, (V[]){v_x_2477}), heff_dup(v_sp_2465)});
                      v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2478}), v_sp_2465});
                      break;
                    }
                    case TAG_PatBinary: {
                      heff_take_n(v_x11_2464, 0ULL, 1);
                      v_t_2487 = heff_tag_re_n(v_ru_24x1_2463_24At, TAG_At, 2, 2ULL, (V[]){NTAG(TAG_CAbandon), v_sp_2465});
                      break;
                    }
                    case TAG_PatRune: {
                      V v_x_2480 = heff_field(v_x11_2464, 0);
                      V v_ru_24x11_2464_24PatRune = heff_take_reuse_n(v_x11_2464, 1ULL, 1);
                      V v_t_2481 = heff_tag_at_n(v_ru_24x1_2463_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2464_24PatRune, TAG_IRune, 1, (V[]){v_x_2480}), heff_dup(v_sp_2465)});
                      v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2481}), v_sp_2465});
                      break;
                    }
                    case TAG_PatRecord: {
                      heff_take_n(v_x11_2464, 0ULL, 1);
                      v_t_2487 = heff_tag_re_n(v_ru_24x1_2463_24At, TAG_At, 2, 2ULL, (V[]){NTAG(TAG_CAbandon), v_sp_2465});
                      break;
                    }
                    case TAG_PatWord: {
                      heff_take_n(v_x11_2464, 0ULL, 1);
                      v_t_2487 = heff_tag_re_n(v_ru_24x1_2463_24At, TAG_At, 2, 2ULL, (V[]){NTAG(TAG_CAbandon), v_sp_2465});
                      break;
                    }
                    case TAG_PatAs: {
                      heff_take_n(v_x11_2464, 0ULL, 3);
                      v_t_2487 = heff_tag_re_n(v_ru_24x1_2463_24At, TAG_At, 2, 2ULL, (V[]){NTAG(TAG_CAbandon), v_sp_2465});
                      break;
                    }
                    default: heff_nomatch(v_x11_2464);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x1_2463);
                  }
                  V v_t_2490;
                  switch (heff_tag_of(v_l_246)) {
                  case TAG_At: {
                    V v_s_2489 = heff_dup(heff_field(v_l_246, 1));
                    v_t_2490 = v_s_2489;
                    break;
                  }
                  default: heff_nomatch(v_l_246);
                  }
                  V v_tsp_2493;
                  switch (heff_tag_of(v_l_246)) {
                  case TAG_At: {
                    V v_s_2492 = heff_dup(heff_field(v_l_246, 1));
                    v_tsp_2493 = v_s_2492;
                    break;
                  }
                  default: heff_nomatch(v_l_246);
                  }
                  V v_t_2494 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_tsp_2493, 0)), heff_dup(heff_rfield(v_tsp_2493, 1))});
                  V v_t_2497;
                  switch (heff_tag_of(v_x_2427)) {
                  case TAG_At: {
                    V v_s_2496 = heff_dup(heff_field(v_x_2427, 1));
                    v_t_2497 = v_s_2496;
                    break;
                  }
                  default: heff_nomatch(v_x_2427);
                  }
                  V v_tsp_24100;
                  switch (heff_tag_of(v_l_246)) {
                  case TAG_At: {
                    V v_s_2499 = heff_dup(heff_field(v_l_246, 1));
                    v_tsp_24100 = v_s_2499;
                    break;
                  }
                  default: heff_nomatch(v_l_246);
                  }
                  V v_t_24101 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_tsp_24100, 0)), heff_dup(heff_rfield(v_tsp_24100, 1))});
                  V v_t_24104;
                  switch (heff_tag_of(v_x_2437)) {
                  case TAG_At: {
                    V v_s_24103 = heff_dup(heff_field(v_x_2437, 1));
                    v_t_24104 = v_s_24103;
                    break;
                  }
                  default: heff_nomatch(v_x_2437);
                  }
                  V v_t_24107;
                  switch (heff_tag_of(v_l_246)) {
                  case TAG_At: {
                    V v_s_24106 = heff_field(v_l_246, 1);
                    heff_take_n(v_l_246, 2ULL, 2);
                    v_t_24107 = v_s_24106;
                    break;
                  }
                  default: heff_nomatch(v_l_246);
                  }
                  V v_t_24108 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ILitEq, 4, (V[]){v_t_2442, v_sp_242, v_t_2462, v_t_2487}), v_t_2490});
                  V v_t_24109 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str13), v_tsp_2493, NTAG(TAG_Nil)});
                  V v_t_24110 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24109, heff_dup(v_t_2494)}), v_x_2427});
                  V v_t_24111 = ({ V rv_1 = heff_get_n(v_t_2497, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2494, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                  V v_t_24112 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_str14), v_tsp_24100, NTAG(TAG_Nil)});
                  V v_t_24113 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24112, heff_dup(v_t_24101)}), v_x_2437});
                  V v_t_24114 = ({ V rv_1 = heff_get_n(v_t_24104, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24101, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                  V v_t_24115 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24113, v_t_24114}), NTAG(TAG_Nil)});
                  V v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24110, v_t_24111}), v_t_24115});
                  V v_f_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24108, v_t_24116}), v_t_24107});
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24117}});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam0(V self, V *args) {
  V v_row_2419 = args[0];
  V v_vars_2412 = heff_env(self)[0];
  V v_pats_2420 = heff_take_field(v_row_2419, 0);
  V v_rhs_2421 = heff_get_n(v_row_2419, 1, 2);
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2412, v_pats_2420, v_rhs_2421));
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr_lam1(V self, V *args) {
  V v_row_2429 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_pats_2430 = heff_take_field(v_row_2429, 0);
  V v_rhs_2431 = heff_get_n(v_row_2429, 1, 2);
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_243, v_pats_2430, v_rhs_2431));
}

static V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_val;
static HEFF_ONCE g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_st;
static V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_init(void) {
  return heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_st)) return g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_val;
  return heff_global(&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_val, &g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_st, g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_24rec0_init);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr_str1, 1, "_");

HeffT2 g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244) {
top: ;
  switch (heff_tag_of(v_rows_244)) {
  case TAG_Nil: {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_vars_243);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_245}});
  }
  case TAG_Cons: {
    V v_row_246 = heff_dup(heff_field(v_rows_244, 0));
    V v_pats_248 = heff_take_field(v_row_246, 0);
    V v_rhs_249 = heff_get_n(v_row_246, 1, 2);
    HeffT2 v_t_2410 = (g_heff_2eelab_2eclauses_2efindTagLit_24cpr(v_pats_248, MK_INT(0LL)));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        heff_drop(v_rhs_249);
        V v_c_2413 = v_field_2412;
        HeffT2 v_t_2414 = ({ V a_0 = v_pats_248; V a_1 = heff_dup(v_c_2413); HeffT2 r_ = (g_heff_2eelab_2eclauses_2enthC_24cpr(a_0, a_1)); heff_drop(v_pats_248); r_; });
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          V v_t_2418;
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_p_2417 = v_field_2416;
            v_t_2418 = v_p_2417;
          } else {
            heff_drop(v_field_2416);
            v_t_2418 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr_str0)});
          }
          return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_2413; V a_6 = v_t_2418; HeffT2 r_ = (g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2418); r_; });
        }
      } else {
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_sp_242);
        heff_drop_tag(v_rows_244, 2);
        heff_drop(v_field_2412);
        V v_t_2419 = (g_heff_2eelab_2eclauses_2ezipC(v_vars_243, v_pats_248));
        V v_t_2420 = ({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr_str1); V a_1 = v_rhs_249; V a_2 = v_t_2419; V r_ = (g_list_2efoldl_24s547379716x1342911792(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2420}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_rows_244)}});
  }
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_rhs_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_pats_245 = heff_dup(heff_rfield(v_x_242, 0));
    V v_t_246 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_rhs_244, v_acc_241));
    V v_t_247 = ({ V a_0 = v_pats_245; V a_1 = v_t_246; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(a_0, a_1)); heff_drop(v_pats_245); r_; });
    V t_0 = v_xs_243;
    V t_1 = v_t_247;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str0, 43, "a definition by equations needs an equation");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str1, 19, "every equation of `");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str2, 6, "` has ");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str3, 11, " pattern(s)");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str4, 18, "the equations of `");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_24cpr_str5, 37, "` match fewer arguments than it names");
V g_heff_2eelab_2eclauses_2edesugar_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edesugar_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V v_f_240, V v_params_241, V v_eqNs_242, V v_sp_243) {
top: ;
  HeffT2 v_t_244 = (g_prelude_2etraverse_24s1778157750x1229378888_24cpr(v_eqNs_242));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_f_240);
      heff_drop(v_params_241);
      heff_drop(v_sp_243);
      V v_e_247 = v_field_246;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_247}});
    } else {
      V v_x_248 = v_field_246;
      switch (heff_tag_of(v_x_248)) {
      case TAG_Nil: {
        heff_drop(v_f_240);
        heff_drop(v_params_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_sp_243, ((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str0)})}});
      }
      case TAG_Cons: {
        V v_r_249 = heff_dup(heff_field(v_x_248, 0));
        V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_r_249, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        HeffT2 v_t_2424 = ({ V a_0 = v_x_248; V b_1 = heff_clo_n(g_heff_2eelab_2eclauses_2edesugar_24cpr_lam0, 1, 2, (V[]){heff_dup(v_t_2411), heff_dup(v_f_240)}); HeffT2 r_ = (g_heff_2eelab_2eclauses_2eforC_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            heff_drop(v_f_240);
            heff_drop(v_params_241);
            heff_drop(v_sp_243);
            heff_drop_tag(v_x_248, 2);
            heff_drop(v_t_2411);
            V v_e_2427 = v_field_2426;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2427}});
          } else {
            V v_x_2428 = v_field_2426;
            heff_drop(v_x_2428);
            V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_241));
            if (heff_intLt_c_lent(v_t_2411, v_t_2429, 2)) {
              heff_drop(v_params_241);
              heff_drop_tag(v_x_248, 2);
              heff_drop(v_t_2411);
              V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str4), v_f_240), ((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str5));
              V v_f_2431 = heff_rec_n(2, shape_span__msg, (V[]){v_sp_243, v_t_2430});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2431}});
            } else {
              V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, NTAG(TAG_Nil)});
              V v_t_2433 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_params_241), v_t_2432));
              V v_used_2434 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(v_x_248, v_t_2433));
              V v_params_2435 = heff_dup(v_params_241);
              V v_sp_2436 = v_sp_243;
              V v_rows_2437 = heff_dup(v_x_248);
              V v_used_2438 = heff_dup(v_used_2434);
              V v_cols_2439 = ({ V a_0 = v_used_2434; V a_1 = v_params_241; V a_2 = v_x_248; V a_3 = MK_INT(0LL); V a_4 = v_t_2411; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2eelab_2eclauses_2ecolNames(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_params_241); r_; });
              V v_t_2443 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edesugar_24cpr_lam1, 1, 1, (V[]){heff_dup(v_cols_2439)}), v_rows_2437));
              HeffT2 v_t_2444 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_2438, heff_dup(v_cols_2439), heff_dup(v_sp_2436), heff_dup(v_cols_2439), v_t_2443));
              {
                V v_field_2446 = v_t_2444.f[1];
                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                if ((v_tag_2445 == ((int64_t)0ULL))) {
                  heff_drop(v_params_2435);
                  heff_drop(v_sp_2436);
                  heff_drop(v_cols_2439);
                  V v_e_2447 = v_field_2446;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2447}});
                } else {
                  V v_x_2448 = v_field_2446;
                  V v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_params_2435; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_params_2435); r_; });
                  V v_t_2450 = (g_heff_2eelab_2eclauses_2edropC(v_t_2449, v_cols_2439));
                  V v_t_2451 = ({ V a_0 = v_sp_2436; V a_1 = v_x_2448; V a_2 = v_t_2450; V r_ = (g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005(a_0, a_1, a_2)); heff_drop(v_sp_2436); heff_drop(v_x_2448); r_; });
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2451}});
                }
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x_248)}});
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2edesugar_24cpr_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  V v_t_2411 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_pats_2413 = heff_take_field(v_r_2412, 0);
  V v_rhs_2414 = heff_get_n(v_r_2412, 1, 2);
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_pats_2413; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_pats_2413); r_; });
  V v_x1_2416 = heff_bool(heff_intEq_c_lent(v_t_2415, v_t_2411, 0));
  heff_drop(v_t_2415);
  if (!(heff_dup(v_x1_2416) == NTAG(TAG_True))) {
    heff_drop(v_x1_2416);
    V v_t_2417 = v_rhs_2414;
    V v_t_2420;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_At: {
      V v_s_2419 = heff_field(v_t_2417, 1);
      heff_take_n(v_t_2417, 2ULL, 2);
      v_t_2420 = v_s_2419;
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    heff_clo_take(self, 2);
    V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str1), v_f_240), ((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str2));
    V v_t_2422 = heff_strAppend(v_t_2421, heff_intShow(v_t_2411));
    V v_t_2423 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2420, heff_strAppend(v_t_2422, ((V)&g_heff_2eelab_2eclauses_2edesugar_24cpr_str3))});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2423});
  } else {
    heff_drop(self);
    heff_drop(v_rhs_2414);
    heff_drop(v_x1_2416);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
}
V g_heff_2eelab_2eclauses_2edesugar_24cpr_lam1(V self, V *args) {
  V v_row_2440 = args[0];
  V v_cols_2439 = heff_env(self)[0];
  V v_pats_2441 = heff_take_field(v_row_2440, 0);
  V v_rhs_2442 = heff_get_n(v_row_2440, 1, 2);
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_cols_2439, v_pats_2441, v_rhs_2442));
}
Clo g_heff_2eelab_2eclauses_2ebare_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebare_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ebare(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    return v_x1_240;
  }
  case TAG_PTag: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_sp_244 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PTag = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_245 = (g_list_2emap(((V)&g_heff_2eelab_2eclauses_2ebare_clo), v_ps_243));
    return heff_tag_re_n(v_ru_24x1_240_24PTag, TAG_PTag, 3, 5ULL, (V[]){v_t_242, v_t_245, v_sp_244});
  }
  case TAG_PLit: {
    return v_x1_240;
  }
  case TAG_PRec: {
    return v_x1_240;
  }
  case TAG_PAs: {
    V v_p_2410 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_p_2410;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PBin: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ebare_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebare(a[0]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps_entry, 5, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps(V v_ys_240, V v_lit_241, V v_i_242, V v_n_243, V v_d_244) {
top: ;
  if (heff_intLe_c_lent(v_n_243, v_i_242, 0)) {
    heff_drop(v_i_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), heff_dup(v_ys_240));
  } else {
    V v_x_245 = heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_241)});
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_246);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_n_243;
    V t_4 = v_u_247;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_i_242 = t_2;
    v_n_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2eappendC_24f1215097166x1062713514_24dps(a0, a1, a[2], a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_heff_2eelab_2eclauses_2esegBind_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esegBind_24tok2_entry, 12, 0};

V g_heff_2eelab_2eclauses_2esegBind_24tok2(V v_tok_240, V v_b_241, V v_k_242, V v_env_243, V v_i_244, V v_x5_245, V v_off_246, V v_s_247, V v_rest_248, V v_body_249, V v_w_2410, V v_x11_2411) {
top: ;
  switch (heff_tag_of(v_x11_2411)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop_rec(v_k_242, 7);
    heff_drop_rec(v_s_247, 5);
    V v_t_2412 = (g_heff_2eelab_2eclauses_2eappendC(heff_take_field(v_off_246, 1), heff_take_field(v_w_2410, 1)));
    V v_t_2413 = heff_intAdd(heff_get_n(v_off_246, 0, 2), heff_take_field(v_w_2410, 0));
    return heff_tail(heff_get_n(v_b_241, 0, 1), 6, (V[]){v_env_243, heff_intAdd(v_i_244, MK_INT(1LL)), v_x5_245, ({ V rv_0 = v_t_2413; V rv_1 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_w_2410, 0ULL, 2, shape_bits__terms, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; }), v_rest_248, v_body_249});
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x11_2411, 0);
    V v_ru_24x11_2411_24Just = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
    switch (heff_tag_of(v_x5_245)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop_rec(v_b_241, 1);
      heff_drop_rec(v_k_242, 7);
      heff_drop(v_env_243);
      heff_drop(v_i_244);
      heff_drop_rec(v_off_246, 2);
      heff_drop_rec(v_s_247, 5);
      heff_drop(v_rest_248);
      heff_drop_rec(v_w_2410, 2);
      heff_drop(v_x_2414);
      heff_drop_cell(v_ru_24x11_2411_24Just, 1);
      return v_body_249;
    }
    case TAG_Cons: {
      V v_y_2415 = heff_field(v_x5_245, 0);
      V v_ys_2416 = heff_field(v_x5_245, 1);
      V v_ru_24x5_245_24Cons = heff_take_reuse_n(v_x5_245, 3ULL, 2);
      V v_rhs_2417 = ({ V a_0 = heff_dup(v_k_242); V a_1 = heff_dup(v_off_246); V a_2 = heff_dup(v_w_2410); V a_3 = heff_dup(v_s_247); V b_4 = heff_dup(heff_rfield(v_s_247, 1)); V a_5 = heff_get_n(v_s_247, 2, 5); V r_ = (g_heff_2eelab_2eclauses_2esegRead(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(b_4); r_; });
      V v_t_2418 = (g_heff_2eelab_2eclauses_2eappendC(heff_take_field(v_off_246, 1), heff_take_field(v_w_2410, 1)));
      V v_t_2419 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x5_245_24Cons, TAG_MkPair, 2, (V[]){v_x_2414, heff_dup(v_y_2415)}), v_env_243});
      V v_t_2420 = heff_intAdd(heff_get_n(v_off_246, 0, 2), heff_take_field(v_w_2410, 0));
      V v_body_2421 = heff_tr(heff_call(heff_get_n(v_b_241, 0, 1), 6, (V[]){v_t_2419, heff_intAdd(v_i_244, MK_INT(1LL)), v_ys_2416, ({ V rv_0 = v_t_2420; V rv_1 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_w_2410, 0ULL, 2, shape_bits__terms, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; }), v_rest_248, v_body_249}));
      V v_sp_2422 = heff_get_n(v_k_242, 6, 7);
      V v_t_2425;
      switch (heff_tag_of(v_body_2421)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_body_2421, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_body_2421);
      }
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2411_24Just, TAG_PatVar, 1, (V[]){v_y_2415}), heff_dup(v_sp_2422)});
      V v_t_2427 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2422, 0)); V rr_ = heff_rec_reuse_nf(v_t_2425, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2426, v_body_2421}), v_t_2427});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2417, v_t_2428}), v_sp_2422});
    }
    default: return heff_nomatch(v_x5_245);
    }
  }
  default: return heff_nomatch(v_x11_2411);
  }
}
V g_heff_2eelab_2eclauses_2esegBind_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2esegBind_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}