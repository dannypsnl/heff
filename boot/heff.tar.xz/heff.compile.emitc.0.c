// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_F32 16337
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Leaf 13717
#define TAG_MkWrapper 39179
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Plus 9189
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_ctype 296362551
#define LBL_end 310101
#define LBL_entry 298026124
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lent 9813446
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_shapes 1043573789
#define LBL_strs 10036521
#define LBL_tag 324116
#define LBL_tuples 1084651734
#define LBL_wrapper 1827365593
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
V g_heff_2ecompile_2eemitc_2eargC(V, V, V);
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargC_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2ecallLent(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallLent_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V, V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
HeffT6 g_heff_2ecompile_2eemitc_2eckOf_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2econvOf(V, V, V);
V g_heff_2ecompile_2eemitc_2econvOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2econvOf_clo;
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
V g_heff_2ecompile_2eemitc_2edefC(V, V, V);
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefC_clo;
HeffT2 g_heff_2ecompile_2eemitc_2edefC_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
HeffT2 g_heff_2ecompile_2eemitc_2efunDef_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2eglueCallOf(V);
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2eintU(V, V, V);
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eintU_clo;
V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsWith(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsWith_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2eresultDecl(V);
V g_heff_2ecompile_2eemitc_2eresultDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eresultDecl_clo;
V g_heff_2ecompile_2eemitc_2eresultLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eresultLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eresultLines_clo;
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_clo;
V g_heff_2ecompile_2eemitc_2etupleRead(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleRead_clo;
V g_heff_2ecompile_2eemitc_2ewordAs(V, V);
V g_heff_2ecompile_2eemitc_2ewordAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewordAs_clo;
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
HeffT2 g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2econcatMap(V, V);
V g_list_2econcatMap_entry(V self, V *a);
extern Clo g_list_2econcatMap_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f1882859809x1518778929(V, V, V);
V g_list_2efoldl_24f1882859809x1518778929_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1882859809x1518778929_clo;
V g_list_2efoldl_24s1071292119x112543158(V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1071292119x112543158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1071292119x112543158_clo;
V g_list_2efoldl_24s1325692678x1256705229(V, V);
V g_list_2efoldl_24s1325692678x1256705229_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325692678x1256705229_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s1894035205x969464323(V, V, V);
V g_list_2efoldl_24s1894035205x969464323_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1894035205x969464323_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str0, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str1, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emangleChar_str2, 1, "_");
Clo g_heff_2ecompile_2eemitc_2emangleChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleChar_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2emangleChar(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((((((int64_t)97ULL) <= v_c_240) && (v_c_240 <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= v_c_240) && (v_c_240 <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))))) {
    return heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_c_240))));
  } else {
    int64_t v_d_241 = (heff_word_mod(v_c_240, ((int64_t)256ULL)) / ((int64_t)16ULL));
    int64_t v_d_242 = heff_word_mod(v_c_240, ((int64_t)16ULL));
    V v_t_243 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str0), heff_box_word(v_d_241), heff_box_word((v_d_241 + ((int64_t)1ULL))));
    V v_t_244 = heff_strSlice(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str1), heff_box_word(v_d_242), heff_box_word((v_d_242 + ((int64_t)1ULL))));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2emangleChar_str2), v_t_243), v_t_244);
  }
}
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emangleChar(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesInGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2enamesInGo(V v_pre_240, V v_text_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = heff_strSlice_lent(v_text_241, v_i_242, heff_strLength_lent(v_text_241, 0), 4);
  V v_j_245 = heff_strFind_lent(v_pre_240, v_t_244, MK_INT(0LL), 6);
  if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
    heff_drop(v_i_242);
    heff_drop(v_j_245);
    return v_acc_243;
  } else {
    V v_t_246 = heff_intAdd(heff_intAdd_lent(v_i_242, v_j_245, 0), heff_strLength_lent(v_pre_240, 0));
    V v_t_247 = heff_intAdd(heff_intAdd_lent(v_i_242, v_j_245, 0), heff_strLength_lent(v_pre_240, 0));
    V v_t_248 = ({ V a_0 = v_text_241; V a_1 = v_t_246; V a_2 = v_t_247; V r_ = (g_heff_2ecompile_2eemitc_2eidentAt(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
    V v_t_249 = heff_intAdd(heff_intAdd(v_i_242, v_j_245), heff_strLength_lent(v_pre_240, 0));
    V t_0 = v_pre_240;
    V t_1 = v_text_241;
    V t_2 = v_t_249;
    V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_acc_243});
    v_pre_240 = t_0;
    v_text_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesInGo(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecBytesGo_str0, 2, "\\\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecBytesGo_str1, 2, "\\\\");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecBytesGo_str2, 2, "\\\?");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecBytesGo_str3, 1, "\\");
Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecBytesGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ecBytesGo(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_s_243 = heff_dup(v_s_240);
    int64_t v_i_244 = v_i_241;
    V v_b_245 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
    V v_t_2410;
    if ((heff_peek_word(v_b_245) == ((int64_t)34ULL))) {
      heff_drop(v_s_243);
      heff_drop(v_b_245);
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecBytesGo_str0);
    } else {
      if ((heff_peek_word(v_b_245) == ((int64_t)92ULL))) {
        heff_drop(v_s_243);
        heff_drop(v_b_245);
        v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecBytesGo_str1);
      } else {
        if ((heff_peek_word(v_b_245) == ((int64_t)63ULL))) {
          heff_drop(v_s_243);
          heff_drop(v_b_245);
          v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2ecBytesGo_str2);
        } else {
          if (((((int64_t)32ULL) <= heff_peek_word(v_b_245)) && (heff_peek_word(v_b_245) < ((int64_t)127ULL)))) {
            heff_drop(v_b_245);
            v_t_2410 = heff_strSlice(v_s_243, heff_box_word(v_i_244), heff_box_word((v_i_244 + ((int64_t)1ULL))));
          } else {
            heff_drop(v_s_243);
            V v_t_246 = heff_intShow(heff_box_word(heff_word_div(heff_peek_word(v_b_245), ((int64_t)64ULL))));
            int64_t v_t_247 = heff_word_mod(heff_word_div(heff_peek_word(v_b_245), ((int64_t)8ULL)), ((int64_t)8ULL));
            V v_t_248 = heff_strAppend(v_t_246, heff_intShow(heff_box_word(v_t_247)));
            V v_t_249 = heff_intShow(heff_box_word(heff_word_mod(heff_unbox_word(v_b_245), ((int64_t)8ULL))));
            v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecBytesGo_str3), heff_strAppend(v_t_248, v_t_249));
          }
        }
      }
    }
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_acc_242, v_t_2410);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2ecBytesGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimLit_str0, 10, "((V)&prim_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprimLit_str1, 5, "_clo)");
Clo g_heff_2ecompile_2eemitc_2eprimLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprimLit_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eprimLit(V v_p_240, V v_s_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_240));
  V v_o_243 = heff_dup(heff_rfield(v_s_241, 0));
  V v_k_244 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_240));
  V v_ps_245 = heff_take_field(v_s_241, 7);
  V v_t_246 = (g_heff_2ecompile_2eemitc_2eownHas(v_o_243, v_k_244, v_ps_245));
  V v_t_247;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_o_243);
    heff_drop(v_k_244);
    heff_drop(v_t_246);
    v_t_247 = v_ps_245;
  } else {
    heff_drop(v_t_246);
    v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_o_243, v_k_244}), v_ps_245});
  }
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eprimLit_str0), v_t_242), ((V)&g_heff_2ecompile_2eemitc_2eprimLit_str1));
  V v_t_249 = ({ V rv_7 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_241, 127ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_t_249});
}
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eprimLit(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str0, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str1, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str2, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str3, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str4, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str5, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str6, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str7, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str8, 4, "uint");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str9, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedType_str10, 2, "_t");
Clo g_heff_2ecompile_2eemitc_2efixedType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedType_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efixedType(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecompile_2eemitc_2efixedType_str0);
  } else {
    heff_drop(v_t_241);
    V v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str1);
      break;
    }
    case TAG_I16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str2);
      break;
    }
    case TAG_I32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str3);
      break;
    }
    case TAG_I64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str4);
      break;
    }
    case TAG_U8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str5);
      break;
    }
    case TAG_U16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str6);
      break;
    }
    case TAG_U32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str7);
      break;
    }
    case TAG_U64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str8);
      break;
    }
    case TAG_F32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedType_str9);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_244 = heff_strAppend(v_t_242, heff_intShow(v_t_243));
    return heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2efixedType_str10));
  }
}
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedType(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str0, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str1, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str2, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str3, 9, "heff_div_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str8, 9, "heff_rem_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str10, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str13, 9, "heff_shl_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str15, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str18, 9, "heff_shr_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str20, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str23, 14, "heff_from_int_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str25, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str26, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str28, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str30, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str31, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str32, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str33, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str34, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str35, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str36, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str37, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str38, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str39, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str40, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str41, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str42, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str43, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str44, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str45, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str46, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str47, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str49, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str50, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str51, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str52, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str53, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str54, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str55, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str56, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str57, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str58, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str59, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str60, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eintU_str61, 1, ")");
Clo g_heff_2ecompile_2eemitc_2eintU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eintU_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eintU(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  switch (heff_tag_of(v_op_241)) {
  case TAG_OpAdd: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str0), v_vs_242);
  }
  case TAG_OpSub: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str1), v_vs_242);
  }
  case TAG_OpMul: {
    HEFF_LAST return g_heff_2ecompile_2eemitc_2ewrapped(v_w_240, ((V)&g_heff_2ecompile_2eemitc_2eintU_str2), v_vs_242);
  }
  case TAG_OpDiv: {
    V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str3), v_t_243);
    V v_t_247;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_vs_242, 0);
      V v_xs_246 = heff_field(v_vs_242, 1);
      v_t_247 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str5), heff_dup(v_x_245), v_xs_246));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_248 = heff_strAppend(heff_strAppend(v_f_244, ((V)&g_heff_2ecompile_2eemitc_2eintU_str6)), v_t_247);
    return heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eintU_str7));
  }
  case TAG_OpRem: {
    V v_t_249 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str8), v_t_249);
    V v_t_2413;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_vs_242, 0);
      V v_xs_2412 = heff_field(v_vs_242, 1);
      v_t_2413 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str10), heff_dup(v_x_2411), v_xs_2412));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2414 = heff_strAppend(heff_strAppend(v_f_2410, ((V)&g_heff_2ecompile_2eemitc_2eintU_str11)), v_t_2413);
    return heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2eintU_str12));
  }
  case TAG_OpShl: {
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str13), v_t_2415);
    V v_t_2419;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_vs_242, 0);
      V v_xs_2418 = heff_field(v_vs_242, 1);
      v_t_2419 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str15), heff_dup(v_x_2417), v_xs_2418));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(v_f_2416, ((V)&g_heff_2ecompile_2eemitc_2eintU_str16)), v_t_2419);
    return heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2eintU_str17));
  }
  case TAG_OpShr: {
    V v_t_2421 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str18), v_t_2421);
    V v_t_2425;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_vs_242, 0);
      V v_xs_2424 = heff_field(v_vs_242, 1);
      v_t_2425 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str20), heff_dup(v_x_2423), v_xs_2424));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2426 = heff_strAppend(heff_strAppend(v_f_2422, ((V)&g_heff_2ecompile_2eemitc_2eintU_str21)), v_t_2425);
    return heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2eintU_str22));
  }
  case TAG_OpFromInt: {
    V v_t_2427 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str23), v_t_2427);
    V v_t_2431;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str24);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_vs_242, 0);
      V v_xs_2430 = heff_field(v_vs_242, 1);
      v_t_2431 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str25), heff_dup(v_x_2429), v_xs_2430));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(v_f_2428, ((V)&g_heff_2ecompile_2eemitc_2eintU_str26)), v_t_2431);
    return heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2eintU_str27));
  }
  case TAG_OpToInt: {
    V v_t_2433 = (g_heff_2ecompile_2eemitc_2efixedSuffix(v_w_240));
    V v_f_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str28), v_t_2433);
    V v_t_2437;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2437 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str29);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_vs_242, 0);
      V v_xs_2436 = heff_field(v_vs_242, 1);
      v_t_2437 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eintU_str30), heff_dup(v_x_2435), v_xs_2436));
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2438 = heff_strAppend(heff_strAppend(v_f_2434, ((V)&g_heff_2ecompile_2eemitc_2eintU_str31)), v_t_2437);
    return heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2eintU_str32));
  }
  default: {
    V v_t_2439 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
    V v_t_2442;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str33);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_vs_242, 0);
      v_t_2442 = heff_dup(v_x_2440);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_2443;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str34);
      break;
    }
    case TAG_OpSub: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str35);
      break;
    }
    case TAG_OpMul: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str36);
      break;
    }
    case TAG_OpDiv: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str37);
      break;
    }
    case TAG_OpRem: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str38);
      break;
    }
    case TAG_OpEq: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str39);
      break;
    }
    case TAG_OpLt: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str40);
      break;
    }
    case TAG_OpLe: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str41);
      break;
    }
    case TAG_OpAnd: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str42);
      break;
    }
    case TAG_OpOr: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str43);
      break;
    }
    case TAG_OpXor: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str44);
      break;
    }
    case TAG_OpShl: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str45);
      break;
    }
    case TAG_OpShr: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str46);
      break;
    }
    case TAG_OpShow: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str47);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str48);
      break;
    }
    case TAG_OpToInt: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str49);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str50);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str51);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str52);
      break;
    }
    case TAG_OpFloor: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str53);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_2444 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    {
      V v_field_2446 = v_t_2444.f[1];
      V v_field_2447 = v_t_2444.f[2];
      int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
      V v_t_2450;
      if ((v_tag_2445 == ((int64_t)0ULL))) {
        V v_x_2448 = v_field_2446;
        V v_x12_2449 = v_field_2447;
        heff_drop(v_x12_2449);
        v_t_2450 = v_x_2448;
      } else {
        heff_drop(v_field_2446);
        heff_drop(v_field_2447);
        v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2eintU_str54);
      }
      V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str55), v_t_2439), ((V)&g_heff_2ecompile_2eemitc_2eintU_str56));
      V v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eintU_str57), v_t_2442), ((V)&g_heff_2ecompile_2eemitc_2eintU_str58));
      V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2452, v_t_2443), ((V)&g_heff_2ecompile_2eemitc_2eintU_str59));
      V v_t_2454 = heff_strAppend(heff_strAppend(v_t_2453, v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2eintU_str60));
      return heff_strAppend(heff_strAppend(v_t_2451, v_t_2454), ((V)&g_heff_2ecompile_2eemitc_2eintU_str61));
    }
  }
  }
}
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eintU(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str0, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str1, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str2, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str3, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallLent_str4, 7, "int64_t");
V g_heff_2ecompile_2eemitc_2ecallLent_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ecallLent_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ecallLent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallLent_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallLent(V v_k_240, V v_g_241, V v_tr_242, V v_w_243, V v_args_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_244));
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(v_args_244, v_t_246));
  V v_m_2415 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_clo_n(g_heff_2ecompile_2eemitc_2ecallLent_lam0, 1, 1, (V[]){heff_dup(v_k_240)}), v_t_247));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2ecallLent_lam1, 1, 5, (V[]){v_m_2415, v_k_240, heff_dup(v_g_241), heff_dup(v_w_243), heff_dup(v_tr_242)});
}
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallLent(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_t_2411;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_dup(heff_field(v_p_248, 1));
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eemitc_2eargC(v_k_240, v_t_2411, v_t_2414));
}
V g_heff_2ecompile_2eemitc_2ecallLent_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_w_243 = heff_env(self)[3];
  V v_tr_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    HeffT2 v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_k_240, 3), v_g_241));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      V v_t_2424;
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_x_2423 = v_field_2422;
        v_t_2424 = v_x_2423;
      } else {
        heff_drop(v_field_2422);
        v_t_2424 = MK_INT(0LL);
      }
      V v_t_2432;
      if (heff_intLt_c(MK_INT(0LL), v_t_2424)) {
        HeffT2 v_t_2425 = ({ V b_0 = heff_get_n(v_k_240, 3, 6); V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          V v_t_2429;
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            V v_x_2428 = v_field_2427;
            v_t_2429 = v_x_2428;
          } else {
            heff_drop(v_field_2427);
            v_t_2429 = MK_INT(0LL);
          }
          v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallLent_str0), heff_intShow(v_t_2429));
        }
      } else {
        heff_drop_rec(v_k_240, 6);
        switch (heff_tag_of(v_w_243)) {
        case TAG_Nothing: {
          v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str1);
          break;
        }
        case TAG_Just: {
          V v_r_2430 = heff_dup(heff_field(v_w_243, 0));
          switch (heff_tag_of(v_r_2430)) {
          case TAG_RepV: {
            v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str2);
            break;
          }
          case TAG_RepFix: {
            V v_w_2431 = heff_field(v_r_2430, 0);
            heff_take_n(v_r_2430, 1ULL, 1);
            v_t_2432 = ({ V a_0 = v_w_2431; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2431); r_; });
            break;
          }
          case TAG_RepF64: {
            v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str3);
            break;
          }
          case TAG_RepInt: {
            v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2ecallLent_str4);
            break;
          }
          default: heff_nomatch(v_r_2430);
          }
          break;
        }
        default: heff_nomatch(v_w_243);
        }
      }
      V v_x_2433 = ({ V a_0 = v_t_2432; V a_1 = v_g_241; V a_2 = v_tr_242; V a_3 = v_w_243; V a_4 = v_x_2418; V r_ = (g_heff_2ecompile_2eemitc_2ecallBound(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_241); heff_drop(v_tr_242); heff_drop(v_w_243); r_; });
      return heff_tag_re_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2433, v_s_2419});
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str2, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str3, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str4, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str5, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str6, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str7, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str10, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str11, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str12, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str14, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str15, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleRead_str16, 1, ";");
Clo g_heff_2ecompile_2eemitc_2etupleRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleRead_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etupleRead(V v_k_240, V v_sv_241, V v_kinds_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_v_244 = heff_field(v_x4_243, 0);
    V v_x42_245 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x42_245)) {
    case TAG_MkPair: {
      V v_i_246 = heff_field(v_x42_245, 0);
      V v_r_247 = heff_field(v_x42_245, 1);
      V v_t_248 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_v_244)}));
      V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(v_v_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str0)));
      V v_t_2418;
      switch (heff_tag_of(v_r_247)) {
      case TAG_RepV: {
        HeffT3 v_t_2410 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        {
          V v_field_2412 = v_t_2410.f[1];
          V v_field_2413 = v_t_2410.f[2];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_x_2414 = v_field_2412;
            V v_x12_2415 = v_field_2413;
            heff_drop(v_x12_2415);
            switch (heff_tag_of(v_x_2414)) {
            case TAG_RepV: {
              v_t_2418 = NTAG(TAG_False);
              break;
            }
            case TAG_RepFix: {
              heff_take_n(v_x_2414, 0ULL, 1);
              v_t_2418 = NTAG(TAG_True);
              break;
            }
            case TAG_RepF64: {
              v_t_2418 = NTAG(TAG_True);
              break;
            }
            case TAG_RepInt: {
              v_t_2418 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_x_2414);
            }
          } else {
            heff_drop(v_field_2412);
            heff_drop(v_field_2413);
            v_t_2418 = NTAG(TAG_False);
          }
        }
        break;
      }
      case TAG_RepFix: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_r_247);
      }
      V v_t_2445;
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        HeffT3 v_t_2419 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        {
          V v_field_2421 = v_t_2419.f[1];
          V v_field_2422 = v_t_2419.f[2];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          V v_t_2426;
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_x_2423 = v_field_2421;
            V v_x12_2424 = v_field_2422;
            heff_drop(v_x12_2424);
            switch (heff_tag_of(v_x_2423)) {
            case TAG_RepV: {
              v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str1);
              break;
            }
            case TAG_RepFix: {
              V v_w_2425 = heff_field(v_x_2423, 0);
              heff_take_n(v_x_2423, 1ULL, 1);
              v_t_2426 = ({ V a_0 = v_w_2425; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_2425); r_; });
              break;
            }
            case TAG_RepF64: {
              v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str2);
              break;
            }
            case TAG_RepInt: {
              v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str3);
              break;
            }
            default: heff_nomatch(v_x_2423);
            }
          } else {
            heff_drop(v_field_2421);
            heff_drop(v_field_2422);
            v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str4);
          }
          HeffT3 v_t_2427 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
          {
            V v_field_2429 = v_t_2427.f[1];
            V v_field_2430 = v_t_2427.f[2];
            int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
            V v_t_2433;
            if ((v_tag_2428 == ((int64_t)0ULL))) {
              V v_x_2431 = v_field_2429;
              V v_x12_2432 = v_field_2430;
              heff_drop(v_x12_2432);
              v_t_2433 = v_x_2431;
            } else {
              heff_drop(v_field_2429);
              heff_drop(v_field_2430);
              v_t_2433 = NTAG(TAG_RepV);
            }
            V v_t_2434 = heff_strAppend(heff_strAppend(v_sv_241, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str5)), heff_intShow(heff_dup(v_i_246)));
            V v_t_2435 = ({ V a_0 = v_t_2433; V a_1 = heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str6)); V r_ = (g_heff_2ecompile_2eemitc_2ewordAs(a_0, a_1)); heff_drop(v_t_2433); r_; });
            V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str7), v_t_2426), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str8));
            v_t_2445 = heff_strAppend(heff_strAppend(v_t_2436, v_t_2435), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str9));
          }
        }
      } else {
        heff_drop(v_t_2418);
        HeffT3 v_t_2437 = (g_list_2edrop_24cpr(heff_dup(v_i_246), v_kinds_242));
        {
          V v_field_2439 = v_t_2437.f[1];
          V v_field_2440 = v_t_2437.f[2];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          V v_t_2443;
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            V v_x_2441 = v_field_2439;
            V v_x12_2442 = v_field_2440;
            heff_drop(v_x12_2442);
            v_t_2443 = v_x_2441;
          } else {
            heff_drop(v_field_2439);
            heff_drop(v_field_2440);
            v_t_2443 = NTAG(TAG_RepV);
          }
          V v_t_2444 = heff_strAppend(heff_strAppend(v_sv_241, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str10)), heff_intShow(heff_dup(v_i_246)));
          v_t_2445 = ({ V a_0 = v_t_2443; V a_1 = heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str11)); V r_ = (g_heff_2ecompile_2eemitc_2ewordAs(a_0, a_1)); heff_drop(v_t_2443); r_; });
        }
      }
      V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str12), v_t_248), ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str13));
      V v_t_2447 = heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleRead_str14), v_t_249));
      V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str15)), v_t_2445);
      return heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2etupleRead_str16));
    }
    default: return heff_nomatch(v_x42_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2etupleRead(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str1, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str2, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str4, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str5, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str11, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str12, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str13, 11, "static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str14, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str15, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str16, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str17, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str18, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str19, 21, "_entry(V self, V *a);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str20, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str21, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str22, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str23, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str24, 6, "top: ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str25, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str26, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str27, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str28, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str29, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str30, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str31, 13, "  (void)self;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str32, 22, "_entry(V self, V *a) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str33, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str34, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_24cpr_str35, 0, "");

HeffT2 g_heff_2ecompile_2eemitc_2efunDef_24cpr(V v_tu_240, V v_f_241, V v_z_242) {
top: ;
  V v_reprs_243 = heff_take_field(v_f_241, 5);
  V v_entry_244 = heff_take_field(v_f_241, 3);
  V v_body_245 = heff_take_field(v_f_241, 4);
  V v_key_246 = heff_take_field(v_f_241, 0);
  V v_wrapper_247 = heff_take_field(v_f_241, 7);
  V v_ret_248 = heff_take_field(v_f_241, 6);
  V v_params_249 = heff_take_field(v_f_241, 1);
  V v_lent_2410 = heff_get_n(v_f_241, 2, 8);
  HeffT6 v_t_2411 = (g_heff_2ecompile_2eemitc_2eckOf_24cpr(v_reprs_243, heff_dup(v_tu_240), MK_INT(0LL)));
  {
    V v_field_2413 = v_t_2411.f[1];
    heff_drop(v_t_2411.f[0]);
    heff_drop(v_t_2411.f[2]);
    heff_drop(v_t_2411.f[3]);
    heff_drop(v_t_2411.f[4]);
    heff_drop(v_t_2411.f[5]);
    V v_m_2418 = heff_tr(heff_call(v_field_2413, 1, (V[]){v_entry_244}));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_s_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      HeffT6 v_t_2422 = (g_heff_2ecompile_2eemitc_2eckOf_24cpr(v_reprs_243, heff_dup(v_tu_240), MK_INT(0LL)));
      {
        V v_field_2424 = v_t_2422.f[1];
        heff_drop(v_t_2422.f[0]);
        heff_drop(v_t_2422.f[2]);
        heff_drop(v_t_2422.f[3]);
        heff_drop(v_t_2422.f[4]);
        heff_drop(v_t_2422.f[5]);
        V v_m_2429 = heff_tr(heff_call(v_field_2424, 1, (V[]){v_body_245}));
        V v_x2_2430 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_s_2421}));
        switch (heff_tag_of(v_x2_2430)) {
        case TAG_MkPair: {
          V v_x_2431 = heff_field(v_x2_2430, 0);
          V v_s_2432 = heff_field(v_x2_2430, 1);
          V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
          HeffT2 v_t_2433 = (g_heff_2ecompile_2eemitc_2ewrapperCode_24cpr(v_tu_240, v_key_246, v_reprs_243, v_wrapper_247, v_s_2432));
          {
            V v_field_2434 = v_t_2433.f[0];
            V v_field_2435 = v_t_2433.f[1];
            V v_x_2436 = v_field_2434;
            V v_s_2437 = v_field_2435;
            V v_t_2438 = heff_dup(v_ret_248);
            V v_t_2440;
            switch (heff_tag_of(v_t_2438)) {
            case TAG_RepV: {
              v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str0);
              break;
            }
            case TAG_RepFix: {
              V v_w_2439 = heff_field(v_t_2438, 0);
              heff_take_n(v_t_2438, 1ULL, 1);
              v_t_2440 = ({ V a_0 = v_w_2439; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2439); r_; });
              break;
            }
            case TAG_RepF64: {
              v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str1);
              break;
            }
            case TAG_RepInt: {
              v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str2);
              break;
            }
            default: heff_nomatch(v_t_2438);
            }
            V v_t_2441 = heff_dup(v_wrapper_247);
            V v_t_2443;
            switch (heff_tag_of(v_t_2441)) {
            case TAG_Nothing: {
              v_t_2443 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_t_2441, 0ULL, 1);
              v_t_2443 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_t_2441);
            }
            V v_t_2444 = ({ V a_0 = v_key_246; V a_1 = heff_dup(v_params_249); V a_2 = v_reprs_243; V a_3 = v_t_2440; V a_4 = v_t_2443; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2443); r_; });
            V v_key_2445 = heff_dup(v_key_246);
            V v_rs_2446 = heff_dup(v_reprs_243);
            V v_x3_2447 = heff_dup(v_wrapper_247);
            V v_t_2456;
            switch (heff_tag_of(v_x3_2447)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x2_2419_24MkPair, 2);
              heff_drop(v_key_2445);
              heff_drop(v_rs_2446);
              v_t_2456 = NTAG(TAG_Nil);
              break;
            }
            case TAG_Just: {
              V v_x31_2448 = heff_field(v_x3_2447, 0);
              heff_take_n(v_x3_2447, 1ULL, 1);
              switch (heff_tag_of(v_x31_2448)) {
              case TAG_MkWrapper: {
                V v_ws_2449 = heff_field(v_x31_2448, 0);
                heff_take_n(v_x31_2448, 1ULL, 2);
                V v_t_2451 = ({ V a_0 = v_key_2445; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str3); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2445); r_; });
                V v_t_2452 = ({ V a_0 = v_rs_2446; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_2446); r_; });
                V v_t_2453 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_2452, v_ws_2449));
                V v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str4), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str5), v_t_2451));
                V v_t_2455 = heff_strAppend(heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str6)), v_t_2453);
                v_t_2456 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str7)), NTAG(TAG_Nil)});
                break;
              }
              default: heff_nomatch(v_x31_2448);
              }
              break;
            }
            default: heff_nomatch(v_x3_2447);
            }
            V v_t_2457 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str8)));
            V v_t_2458 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str9)));
            V v_t_2459 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str10)));
            V v_t_2460 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_249));
            V v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str11), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str12), v_t_2457));
            V v_t_2462 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str13), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str14), v_t_2458));
            V v_t_2463 = heff_strAppend(heff_strAppend(v_t_2462, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str15)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str16), v_t_2459));
            V v_t_2464 = heff_strAppend(heff_strAppend(v_t_2463, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str17)), heff_intShow(v_t_2460));
            V v_t_2465 = heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str18)), NTAG(TAG_Nil)});
            V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str19)), v_t_2465});
            V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2456, v_t_2466));
            V v_t_2468 = v_ret_248;
            V v_t_2470;
            switch (heff_tag_of(v_t_2468)) {
            case TAG_RepV: {
              v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str20);
              break;
            }
            case TAG_RepFix: {
              V v_w_2469 = heff_field(v_t_2468, 0);
              heff_take_n(v_t_2468, 1ULL, 1);
              v_t_2470 = ({ V a_0 = v_w_2469; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2469); r_; });
              break;
            }
            case TAG_RepF64: {
              v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str21);
              break;
            }
            case TAG_RepInt: {
              v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str22);
              break;
            }
            default: heff_nomatch(v_t_2468);
            }
            V v_t_2471 = v_wrapper_247;
            V v_t_2473;
            switch (heff_tag_of(v_t_2471)) {
            case TAG_Nothing: {
              v_t_2473 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              heff_take_n(v_t_2471, 0ULL, 1);
              v_t_2473 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_t_2471);
            }
            V v_t_2474 = ({ V a_0 = v_key_246; V a_1 = heff_dup(v_params_249); V a_2 = v_reprs_243; V a_3 = v_t_2470; V a_4 = v_t_2473; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_reprs_243); heff_drop(v_t_2473); r_; });
            V v_t_2475 = heff_strAppend(v_t_2474, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str23));
            V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str24), NTAG(TAG_Nil)});
            V v_t_2477 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2476, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str25), v_x_2420));
            V v_t_2478 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str26), v_x_2431));
            V v_t_2479 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str27)));
            V v_t_2480 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_params_249; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_params_249); r_; });
            V v_t_2481 = ({ V a_0 = v_key_246; V a_1 = v_lent_2410; V a_2 = v_t_2480; V r_ = (g_heff_2ecompile_2eemitc_2eentryCall(a_0, a_1, a_2)); heff_drop(v_key_246); r_; });
            V v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str28), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str29), v_t_2479));
            V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str30), NTAG(TAG_Nil)});
            V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2481, v_t_2483})});
            V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2482, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str32)), v_t_2484});
            V v_t_2486 = (g_prelude_2e_2b_2b(v_x_2436, v_t_2485));
            V v_ys_2487 = (g_prelude_2e_2b_2b(v_t_2478, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str33), v_t_2486})));
            V v_t_2488 = (g_prelude_2e_2b_2b(v_t_2477, v_ys_2487));
            V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str34)), v_t_2467});
            V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_24cpr_str35), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_t_2488})});
            V v_x_2491 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2489, v_t_2490});
            return ((HeffT2){{v_x_2491, v_s_2437}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2430)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2419)}});
    }
  }
}
Clo g_heff_2ecompile_2eemitc_2edefC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edefC_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2edefC(V v_tu_240, V v_x2_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eemitc_2edefC_24cpr(v_tu_240, v_x2_241, v_z_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2edefC(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str2, 22, "static V heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str3, 34, "(V p, V k) { return heff_provider_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str4, 9, "(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str5, 22, "static V heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str6, 120, "(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l \? heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str7, 22, "(q, k) : heff_perform_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str8, 9, "(q, k); }");

HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V v_x1_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_243 = (g_prelude_2esplit_2esplitFrom_240(v_k_242, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str1), v_k_242, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_t_244 = ({ V a_0 = v_k_242; V a_1 = v_t_243; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_242); heff_drop(v_t_243); r_; });
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str2), heff_intShow(heff_dup(v_n_241)));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str3)), v_t_244);
    V v_f_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str4)), NTAG(TAG_Nil)});
    V v_f_248 = heff_intAdd(v_n_241, MK_INT(1LL));
    return ((HeffT2){{v_f_247, v_f_248}});
  }
  case TAG_Plus: {
    V v_a_249 = heff_field(v_x1_240, 0);
    V v_b_2410 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Plus = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_2411 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(v_a_249, heff_intAdd_lent(v_n_241, MK_INT(1LL), 2)));
    {
      V v_field_2412 = v_t_2411.f[0];
      V v_field_2413 = v_t_2411.f[1];
      V v_la_2414 = v_field_2412;
      V v_na_2415 = v_field_2413;
      V v_n_2416 = v_n_241;
      V v_la_2417 = v_la_2414;
      V v_na_2418 = heff_dup(v_na_2415);
      HeffT2 v_t_2419 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(v_b_2410, v_na_2415));
      {
        V v_field_2420 = v_t_2419.f[0];
        V v_field_2421 = v_t_2419.f[1];
        V v_lb_2422 = v_field_2420;
        V v_nb_2423 = v_field_2421;
        V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str5), heff_intShow(heff_dup(v_n_2416)));
        V v_t_2425 = heff_intShow(heff_intAdd(v_n_2416, MK_INT(1LL)));
        V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str6)), v_t_2425);
        V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str7)), heff_intShow(v_na_2418));
        V v_t_2428 = heff_tag_at_n(v_ru_24x1_240_24Plus, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2eperformNodes_24cpr_str8)), NTAG(TAG_Nil)});
        V v_t_2429 = (g_prelude_2e_2b_2b(v_lb_2422, v_t_2428));
        V v_t_2430 = (g_prelude_2e_2b_2b(v_la_2417, v_t_2429));
        return ((HeffT2){{v_t_2430, v_nb_2423}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_t_243)) {
    case TAG_CInteger: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CDouble: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CBool: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CString: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_CText: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_COwnedString: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CBytes: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CPointer: {
      heff_take_n(v_t_243, 0ULL, 2);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_CVoid: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
      V v_u_2410 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_249);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_u_2410;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str0, 20, "heff_int((int64_t)c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str1, 19, "heff_flt((double)c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str2, 30, "NTAG(c \? TAG_True : TAG_False)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str3, 37, "heff_str_bytes(c, (int64_t)strlen(c))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str4, 16, "heff_str_text(c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str5, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str6, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str7, 5, "owned");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str8, 3, "(c)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str9, 28, "heff_bytes_in(c, (int64_t)n)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str10, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str11, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str12, 11, "owned_bytes");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str13, 6, "(c, n)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str14, 7, "let_go_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str15, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str16, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str17, 16, "heff_foreign(c, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2econvOf_str19, 16, "NTAG(TAG_MkUnit)");
Clo g_heff_2ecompile_2eemitc_2econvOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2econvOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2econvOf(V v_leaf_240, V v_ptrs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CInteger: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str0);
  }
  case TAG_CDouble: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str1);
  }
  case TAG_CBool: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str2);
  }
  case TAG_CString: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str3);
  }
  case TAG_CText: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str4);
  }
  case TAG_COwnedString: {
    V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str5), v_leaf_240), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str6));
    return heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2econvOf_str7)), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str8));
  }
  case TAG_CBytes: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str9);
  }
  case TAG_COwnedBytes: {
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str10), v_leaf_240), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str11));
    return heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2econvOf_str12)), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str13));
  }
  case TAG_CPointer: {
    V v_t_246 = heff_field(v_x3_242, 0);
    V v_r_247 = heff_field(v_x3_242, 1);
    V v_t_248 = (g_heff_2ecompile_2eemitc_2eletGoIndexGo(MK_INT(0LL), v_ptrs_241, v_t_246, v_r_247));
    V v_what_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str14), heff_intShow(v_t_248));
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str15), v_leaf_240), ((V)&g_heff_2ecompile_2eemitc_2econvOf_str16));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2econvOf_str17), heff_strAppend(v_t_2410, v_what_249));
    return heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2econvOf_str18));
  }
  case TAG_CVoid: {
    heff_drop(v_leaf_240);
    return ((V)&g_heff_2ecompile_2eemitc_2econvOf_str19);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2econvOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2econvOf(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str0, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str1, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str2, 27, "      r = NTAG(TAG_MkUnit);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str3, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str4, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str5, 25, "      if (!c) heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str6, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str7, 17, "`: C gave NULL\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str8, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str9, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str10, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str11, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str12, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str13, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str14, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str15, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str16, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str17, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str18, 2, "!c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str19, 7, "c == -1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str20, 6, "      ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str21, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str22, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str23, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str24, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str25, 4, "left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str26, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str27, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str28, 10, "(errno) : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str29, 5, "right");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str31, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str32, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str33, 14, "      int c = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str34, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str35, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str36, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str37, 19, "      r = c == 0 \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str38, 5, "right");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str39, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str40, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str41, 21, "(NTAG(TAG_MkUnit)) : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str42, 4, "left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultLines_str43, 8, "(errno);");
Clo g_heff_2ecompile_2eemitc_2eresultLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eresultLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eresultLines(V v_md_240, V v_leaf_241, V v_ptrs_242, V v_b_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_b_243, 3));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Gives: {
    V v_it1_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_CVoid: {
      heff_drop(v_md_240);
      heff_drop(v_leaf_241);
      V v_t_246 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
      V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str0), v_t_246), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str1));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eresultLines_str2), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_248});
    }
    default: {
      V v_t_249 = (g_heff_2ecompile_2eemitc_2eresultDecl(v_it1_245));
      V v_t_2410 = (g_heff_2ecompile_2eemitc_2eglueCallOf(heff_dup(v_b_243)));
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str3), v_t_249), v_t_2410);
      V v_t_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str4));
      V v_t_2416;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_CInteger: {
        v_t_2416 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_2416 = NTAG(TAG_False);
        break;
      }
      case TAG_CBool: {
        v_t_2416 = NTAG(TAG_False);
        break;
      }
      case TAG_CString: {
        v_t_2416 = NTAG(TAG_True);
        break;
      }
      case TAG_CText: {
        v_t_2416 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedString: {
        v_t_2416 = NTAG(TAG_True);
        break;
      }
      case TAG_CBytes: {
        v_t_2416 = NTAG(TAG_True);
        break;
      }
      case TAG_COwnedBytes: {
        v_t_2416 = NTAG(TAG_True);
        break;
      }
      case TAG_CPointer: {
        v_t_2416 = NTAG(TAG_True);
        break;
      }
      case TAG_CVoid: {
        v_t_2416 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
      V v_t_2419;
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str5), v_md_240), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str6));
        V v_t_2418 = heff_strAppend(v_t_2417, heff_get_n(v_b_243, 0, 5));
        v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str7)), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_md_240);
        heff_drop_rec(v_b_243, 5);
        heff_drop(v_t_2416);
        v_t_2419 = NTAG(TAG_Nil);
      }
      V v_t_2420 = ({ V a_0 = v_leaf_241; V a_1 = v_ptrs_242; V a_2 = v_it1_245; V r_ = (g_heff_2ecompile_2eemitc_2econvOf(a_0, a_1, a_2)); heff_drop(v_it1_245); r_; });
      V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str8), v_t_2420), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str9));
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
      V v_ys_2423 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2422));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_ys_2423});
    }
    }
  }
  case TAG_GivesOrErrno: {
    V v_t_2424 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_md_240);
    V v_t_2425 = (g_heff_2ecompile_2eemitc_2eresultDecl(v_t_2424));
    V v_t_2426 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
    V v_t_2430;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_CInteger: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str10);
      break;
    }
    case TAG_CDouble: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str11);
      break;
    }
    case TAG_CBool: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str12);
      break;
    }
    case TAG_CString: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str13);
      break;
    }
    case TAG_CText: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str14);
      break;
    }
    case TAG_COwnedString: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str15);
      break;
    }
    case TAG_CBytes: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str16);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str17);
      break;
    }
    case TAG_CPointer: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str18);
      break;
    }
    case TAG_CVoid: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str19);
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    V v_t_2431 = ({ V a_0 = heff_dup(v_leaf_241); V a_1 = v_ptrs_242; V a_2 = v_t_2424; V r_ = (g_heff_2ecompile_2eemitc_2econvOf(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str20), v_t_2425), v_t_2426);
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str21), v_t_2430), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str22));
    V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str23), heff_dup(v_leaf_241)), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str24));
    V v_t_2435 = heff_strAppend(v_t_2433, heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str25)));
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str26), v_leaf_241), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str27));
    V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str28)), heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str29)));
    V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str30)), v_t_2431);
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str31)), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str32)), v_t_2439});
  }
  case TAG_DoneOrErrno: {
    heff_drop(v_md_240);
    V v_t_2440 = (g_heff_2ecompile_2eemitc_2eglueCallOf(v_b_243));
    V v_t_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str33), v_t_2440), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str34));
    V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str35), heff_dup(v_leaf_241)), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str36));
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str37), heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str38)));
    V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eresultLines_str39), v_leaf_241), ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str40));
    V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str41)), heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str42)));
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemitc_2eresultLines_str43)), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2446});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eemitc_2eresultLines_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eresultLines(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eonceInOrder_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eonceInOrder(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_240, v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        V t_0 = v_seen_240;
        V t_1 = v_xs_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_field_246);
        V v_t_248 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(v_seen_240), v_x_242, NTAG(TAG_MkUnit)));
        V v_cell_249 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
        V v_u_2410 = (g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(v_t_248, v_xs_243, v_cell_249));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eonceInOrder(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str0, 27, "V heff_bocGiven(V tn, V v);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str1, 19, "V heff_bocNew(V v);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str2, 22, "V heff_bocTaken(V tn);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str3, 34, "V heff_performAt(int i, V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str4, 49, "V heff_bocWhen(V cs, V body, V cond, V ws, V rs);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str5, 25, "V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str6, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str7, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str8, 18, "#define HEFF_SPLIT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str9, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str10, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str11, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str12, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str13, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str14, 17, "#define HEFF_PART");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str15, 17, "#include \"heff.h\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsWith_str16, 6, "heff.h");
V g_heff_2ecompile_2eemitc_2epartsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epartsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsWith_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2epartsWith(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244, V v_x6_245) {
top: ;
  V v_prefix_246 = heff_take_field(v_ending_242, 0);
  V v_end_247 = heff_get_n(v_ending_242, 1, 2);
  switch (heff_tag_of(v_x6_245)) {
  case TAG_MkPair: {
    V v_ems_248 = heff_field(v_x6_245, 0);
    V v_s_249 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24MkPair = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str0), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str2), v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str4), v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str5), v_t_2412})});
    V v_ys_2414 = (g_prelude_2e_2b_2b(v_prefix_246, v_t_2413));
    V v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str6); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str7); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str8), v_ys_2414}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str9); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2416; V r_ = (g_list_2efoldl_24s1882737314x358197882(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_241)));
    V v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str10); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2418; V r_ = (g_list_2efoldl_24s1882737314x358197882(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = ({ V a_0 = heff_dup(v_ce_244); V b_1 = heff_tag_at_n(v_ru_24x6_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, v_t_2419}); V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2421 = (g_heff_2ecompile_2eemitc_2edeclOf(heff_dup(v_ce_244), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get())));
    V v_t_2422 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2423 = heff_tr(heff_call(v_end_247, 1, (V[]){heff_dup(v_ce_244)}));
    V v_t_2424 = (g_list_2emap_24s380834591x871125279(v_t_2423));
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2422, v_t_2424));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2425));
    V v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str11); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str12); V a_2 = v_t_2420; V a_3 = v_t_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_t_2420); heff_drop(v_t_2426); r_; });
    V v_ce_2428 = v_ce_244;
    V v_s_2429 = heff_dup(v_s_249);
    V v_strs_2430 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_s_249, 5)));
    V v_protos_2431 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_s_249, 3)));
    V v_lams_2432 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_get_n(v_s_249, 2, 8)));
    V v_defs_2433 = v_defs_243;
    V v_ems_2434 = v_ems_248;
    V v_t_2435 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_s_2429, 6))));
    V v_t_2436 = (g_list_2efoldl_24s1325692678x1256705229(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_s_2429, 7))));
    V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_clo), 10, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str13), ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str14), ((V)&g_heff_2ecompile_2eemitc_2epartsWith_str15), v_ce_2428, heff_dup(v_s_2429), v_t_2435, v_t_2436, heff_dup(v_strs_2430), heff_dup(v_protos_2431), heff_dup(v_lams_2432)}));
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2emoduleParts_clo), 1, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2epartsWith_lam0, 1, 4, (V[]){v_s_2429, v_strs_2430, v_protos_2431, v_lams_2432})}));
    V v_t_2441 = (g_list_2efoldl_24f1882859809x1518778929(NTAG(TAG_Nil), v_defs_2433, v_ems_2434));
    V v_m_2442 = (g_list_2efoldl_24s1071292119x112543158(MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(-1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(g_std_2eordmap_2eempty_get()), v_t_2441));
    V v_t_2443 = ({ V a_0 = v_m_2442; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2442); r_; });
    V v_t_2444 = (g_list_2econcatMap(v_t_2440, v_t_2443));
    V v_t_2445 = (g_list_2emap(v_t_2437, v_t_2444));
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eentryPart_get()), v_t_2427}), v_t_2445});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2epartsWith_str16), v_t_2415}), v_t_2446});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2eemitc_2epartsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epartsWith(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2epartsWith_lam0(V self, V *args) {
  V v_p_2438 = args[0];
  V v_s_2429 = heff_env(self)[0];
  V v_strs_2430 = heff_env(self)[1];
  V v_protos_2431 = heff_env(self)[2];
  V v_lams_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ls_2439 = ({ V a_0 = v_s_2429; V a_1 = v_strs_2430; V a_2 = v_protos_2431; V a_3 = v_lams_2432; V a_4 = v_p_2438; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_s_2429, 8); heff_drop(v_strs_2430); heff_drop(v_protos_2431); heff_drop(v_lams_2432); heff_drop(v_p_2438); r_; });
  return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_2439; V r_ = (g_list_2efoldl_24s1894035205x969464323(a_0, a_1, a_2)); heff_drop(v_ls_2439); r_; });
}
Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_rest_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(a[0], a1); heff_drop(a1); return r;
}