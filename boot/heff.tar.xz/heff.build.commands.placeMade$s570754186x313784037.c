// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_bin 307073
#define LBL_said 10017968
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_str0, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_str1, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_str2, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0(V v_st_240, V v_t_241, V v_x_242, V v_n_243, V v_p_244, V v_p_245, V v_x_246) {
top: ;
  V v_a_247 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), v_x_242));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_243)));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_t_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 1, 6)));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_243));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_t_2415 = ({ V a_0 = v_st_240; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2414); r_; });
  V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_str0), v_t_2411), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_str1));
  V v_why_2417 = heff_strAppend(v_t_2416, v_t_2415);
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_str2), v_why_2417), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_str3));
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_lam0, 1, 2, (V[]){v_p_244, v_p_245})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_p_244, v_p_245));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1(V v_x_240, V v_st_241, V v_t_242, V v_n_243, V v_p_244, V v_x_245, V v_next_246, V v_p_247, V v_x_248, V v_x_249) {
top: ;
  V v_c_2436;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    heff_take_n(v_x_249, 0ULL, 1);
    v_c_2436 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam0_clo);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_249, 0ULL, 1);
    V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_240)));
    V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 1))));
    V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_243)));
    V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
    V v_s_2418 = ({ V a_0 = v_st_241; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2417); r_; });
    V v_to_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2418));
    V v_t_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2414); r_; });
    V v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2419; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2419); r_; });
    V v_a_2423 = heff_tag_n(TAG_Replace, 3, (V[]){v_t_2420, v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam1_clo)});
    v_c_2436 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam2, 2, 1, (V[]){v_a_2423});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam4, 1, 9, (V[]){v_st_241, v_t_242, v_n_243, v_p_244, v_x_245, v_next_246, v_p_247, v_x_240, v_x_248})});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam1(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_2425 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    heff_take_n(v_x_2431, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2425;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2433 = heff_field(v_x_2431, 0);
    heff_take_n(v_x_2431, 1ULL, 1);
    switch (heff_tag_of(v_y_2433)) {
    case TAG_Left: {
      heff_take_n(v_y_2433, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2425;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2433, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2425;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2433);
    }
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_a_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2423})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2430, v_hd_2424, heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam3, 1, 1, (V[]){v_k_2425})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam6(V self, V *args) {
  V v_x_2453 = args[0];
  V v_next_246 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_drop(v_x_2453);
  heff_clo_take(self, 3);
  V f_ = v_next_246;
  heff_room[0] = v_p_244;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_next_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_drop(v_x_2450);
  heff_clo_take(self, 4);
  V v_t_2451 = heff_tag_n(TAG_End, 2, (V[]){v_x_245, NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam6, 1, 3, (V[]){v_next_246, v_p_244, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam7(V self, V *args) {
  V v_r_2456 = args[0];
  return v_r_2456;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam8(V self, V *args) {
  V v_x_2463 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_n_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2463)) {
  case TAG_Left: {
    V v_x_2464 = heff_field(v_x_2463, 0);
    V v_ru_24x_2463_24Left = heff_take_reuse_n(v_x_2463, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_st_241; V a_1 = v_t_242; V a_2 = v_x_248; V a_3 = v_n_243; V a_4 = v_p_244; V a_5 = v_p_247; V b_6 = heff_tag_re_n(v_ru_24x_2463_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2464}); V r_ = (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2465 = heff_field(v_x_2463, 0);
    V v_ru_24x_2463_24Right = heff_take_reuse_n(v_x_2463, 1ULL, 1);
    switch (heff_tag_of(v_y_2465)) {
    case TAG_Left: {
      V v_err_2466 = heff_field(v_y_2465, 0);
      V v_ru_24y_2465_24Left = heff_take_reuse_n(v_y_2465, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2463_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_st_241; V a_1 = v_t_242; V a_2 = v_x_248; V a_3 = v_n_243; V a_4 = v_p_244; V a_5 = v_p_247; V b_6 = heff_tag_re_n(v_ru_24y_2465_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2466}); V r_ = (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2467 = heff_field(v_y_2465, 0);
      heff_take_n(v_y_2465, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_st_241; V a_1 = v_t_242; V a_2 = v_x_248; V a_3 = v_n_243; V a_4 = v_p_244; V a_5 = v_p_247; V b_6 = heff_tag_at_n(v_ru_24x_2463_24Right, TAG_Right, 1, (V[]){v_x_2467}); V r_ = (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2465);
    }
  }
  default: return heff_nomatch(v_x_2463);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_243 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_next_246 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_x_240 = heff_env(self)[7];
  V v_x_248 = heff_env(self)[8];
  if ((heff_dup(v_x_2437) == NTAG(TAG_True))) {
    heff_drop(v_x_2437);
    heff_clo_take(self, 9);
    heff_drop(v_x_240);
    heff_drop(v_x_248);
    V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_take_field(v_t_242, 1)));
    V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_243));
    V v_t_2440 = (g_std_2epath_2ejoin(v_t_2438, v_t_2439));
    V v_path_2441 = ({ V a_0 = v_st_241; V a_1 = v_t_2440; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2440); r_; });
    V v_t_2442 = heff_strAppend(heff_get_n(v_t_242, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_str0));
    V v_t_2443 = heff_strAppend(heff_strAppend(v_t_2442, v_path_2441), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_str1));
    V v_t_2444 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2443, NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam5, 1, 4, (V[]){v_x_245, v_p_244, v_next_246, v_p_247})));
  } else {
    heff_drop(v_x_2437);
    heff_clo_take(self, 9);
    heff_drop(v_x_245);
    heff_drop(v_next_246);
    V v_path_2454 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_240));
    V v_t_2455 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2454; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2454); r_; });
    V v_a_2457 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2455, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam7_clo)});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2462, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1_lam8, 1, 6, (V[]){v_st_241, v_t_242, v_x_248, v_n_243, v_p_244, v_p_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2(V v_st_240, V v_t_241, V v_x_242, V v_n_243, V v_x_244, V v_p_245, V v_x_246, V v_next_247, V v_p_248, V v_x_249) {
top: ;
  V v_a_2410 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_242)));
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_2410));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_243)));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_s_2414 = ({ V a_0 = v_st_240; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_path_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2414));
  V v_to_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_244)));
  V v_t_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2415; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2415); r_; });
  V v_t_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2416; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2416); r_; });
  V v_a_2420 = heff_tag_n(TAG_Copy, 3, (V[]){v_t_2417, v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_lam0_clo)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2425, heff_dup(v_p_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_lam1, 1, 9, (V[]){v_x_244, v_st_240, v_t_241, v_n_243, v_p_245, v_x_246, v_next_247, v_p_248, v_x_242})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_entry(V self, V *a) {
  (void)self;
  V a9 = a[9]; V r = g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a9); heff_drop(a9); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_lam0(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_n_243 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  V v_x_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_p_248 = heff_env(self)[7];
  V v_x_242 = heff_env(self)[8];
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_x_2427 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Left = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    heff_clo_take(self, 9);
    return (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1(v_x_244, v_st_240, v_t_241, v_n_243, v_p_245, v_x_246, v_next_247, v_p_248, v_x_242, heff_tag_re_n(v_ru_24x_2426_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2427})));
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Left: {
      V v_err_2429 = heff_field(v_y_2428, 0);
      V v_ru_24y_2428_24Left = heff_take_reuse_n(v_y_2428, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2426_24Right, 1);
      heff_clo_take(self, 9);
      return (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1(v_x_244, v_st_240, v_t_241, v_n_243, v_p_245, v_x_246, v_next_247, v_p_248, v_x_242, heff_tag_re_n(v_ru_24y_2428_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2429})));
    }
    case TAG_Right: {
      V v_x_2430 = heff_field(v_y_2428, 0);
      heff_take_n(v_y_2428, 1ULL, 1);
      heff_clo_take(self, 9);
      return (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l1(v_x_244, v_st_240, v_t_241, v_n_243, v_p_245, v_x_246, v_next_247, v_p_248, v_x_242, heff_tag_at_n(v_ru_24x_2426_24Right, TAG_Right, 1, (V[]){v_x_2430})));
    }
    default: return heff_nomatch(v_y_2428);
    }
  }
  default: return heff_nomatch(v_x_2426);
  }
}