// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_Holds 53574
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MkRegex 19093
#define TAG_Right 62770
#define TAG_Settled 45257
#define TAG_Write 36323
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_bind 9519364
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_files 298792593
#define LBL_fmap 9641981
#define LBL_goldens 436112074
#define LBL_hmap 9701563
#define LBL_labels 836724522
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_pattern 1588251091
#define LBL_property 1899481104
#define LBL_ret 322331
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_testsSkipped 1800484421
#define LBL_threads 1041404398
#define LBL_total 311908190
#define LBL_unchecked 1931098040
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed, LBL_testsSkipped};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_seen__threads[] = {LBL_seen, LBL_threads};
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void);
V g_co_2eop_24s2022167152x294629972_24rec0_get(void);
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2eexpectedRes_get(void);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_clo;
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569(V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_clo;
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V, V);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo;
V g_heff_2ebuild_2etesting_2elastLines(V, V);
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elastLines_clo;
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2esubtestsOfJson(V);
V g_heff_2ebuild_2etesting_2esubtestsOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestsOfJson_clo;
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_clo;
V g_heff_2ebuild_2etesting_2etestOneC_24s287295492x1205636284(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneC_24s287295492x1205636284_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneC_24s287295492x1205636284_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24f932140008x904662204(V, V, V);
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f932140008x904662204_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1113395621x248103432(V);
V g_list_2emap_24s1113395621x248103432_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_regex_2egather(V, V, V, V, V, V);
V g_regex_2egather_entry(V self, V *a);
extern Clo g_regex_2egather_clo;
V g_regex_2erunFrom(V, V, V, V, V, V);
V g_regex_2erunFrom_entry(V self, V *a);
extern Clo g_regex_2erunFrom_clo;
Clo g_heff_2ebuild_2etesting_2eaddRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eaddRes_entry, 2, 0};

V g_heff_2ebuild_2etesting_2eaddRes(V v_a_240, V v_b_241) {
top: ;
  V v_unchecked_242 = heff_take_field(v_b_241, 4);
  V v_files_243 = heff_take_field(v_b_241, 0);
  V v_expectErrors_244 = heff_take_field(v_b_241, 1);
  V v_total_245 = heff_take_field(v_b_241, 2);
  V v_failed_246 = heff_take_field(v_b_241, 3);
  V v_tests_247 = heff_take_field(v_b_241, 5);
  V v_testsFailed_248 = heff_take_field(v_b_241, 6);
  V v_testsSkipped_249 = heff_get_n(v_b_241, 7, 8);
  V v_unchecked_2410 = heff_take_field(v_a_240, 4);
  V v_files_2411 = heff_take_field(v_a_240, 0);
  V v_expectErrors_2412 = heff_take_field(v_a_240, 1);
  V v_total_2413 = heff_take_field(v_a_240, 2);
  V v_failed_2414 = heff_take_field(v_a_240, 3);
  V v_tests_2415 = heff_take_field(v_a_240, 5);
  V v_testsFailed_2416 = heff_take_field(v_a_240, 6);
  V v_testsSkipped_2417 = heff_take_field(v_a_240, 7);
  V v_t_2418 = (g_prelude_2e_2b_2b(v_unchecked_2410, v_unchecked_242));
  return ({ V rv_0 = heff_intAdd(v_files_2411, v_files_243); V rv_1 = heff_intAdd(v_expectErrors_2412, v_expectErrors_244); V rv_2 = heff_intAdd(v_total_2413, v_total_245); V rv_3 = heff_intAdd(v_failed_2414, v_failed_246); V rv_4 = v_t_2418; V rv_5 = heff_intAdd(v_tests_2415, v_tests_247); V rv_6 = heff_intAdd(v_testsFailed_2416, v_testsFailed_248); V rv_7 = heff_intAdd(v_testsSkipped_2417, v_testsSkipped_249); V rr_ = heff_rec_reuse_nf(v_a_240, 0ULL, 8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eaddRes(a[0], a[1]);
}
HEFF_REC_LIT(g_heff_2ebuild_2etesting_2eexpectedRes_lit0, 8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, MK_INT(1LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL));

static V g_heff_2ebuild_2etesting_2eexpectedRes_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eexpectedRes_st;
static V g_heff_2ebuild_2etesting_2eexpectedRes_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eexpectedRes_lit0);
}
V g_heff_2ebuild_2etesting_2eexpectedRes_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eexpectedRes_st)) return g_heff_2ebuild_2etesting_2eexpectedRes_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eexpectedRes_val, &g_heff_2ebuild_2etesting_2eexpectedRes_st, g_heff_2ebuild_2etesting_2eexpectedRes_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2elastLines_str3, 1, "\012");
Clo g_heff_2ebuild_2etesting_2elastLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2elastLines_entry, 2, 0};

V g_heff_2ebuild_2etesting_2elastLines(V v_n_240, V v_t_241) {
top: ;
  V v_xs_242 = (g_prelude_2esplit_2esplitFrom_240(v_t_241, ((V)&g_heff_2ebuild_2etesting_2elastLines_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2elastLines_str1), v_t_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x2_244 = (g_list_2efoldl_24f932140008x904662204(NTAG(TAG_Nil), v_n_240, v_t_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2etesting_2elastLines_str2);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2elastLines_str3); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2elastLines(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestsOfJson_str0, 8, "subtests");
Clo g_heff_2ebuild_2etesting_2esubtestsOfJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2esubtestsOfJson_entry, 1, 0};

V g_heff_2ebuild_2etesting_2esubtestsOfJson(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Left: {
    return NTAG(TAG_Nil);
  }
  case TAG_Right: {
    V v_j_242 = heff_field(v_x1_240, 0);
    V v_t_2422;
    switch (heff_tag_of(v_j_242)) {
    case TAG_JNull: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JBool: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JInt: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JFloat: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JString: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JArray: {
      v_t_2422 = NTAG(TAG_Nil);
      break;
    }
    case TAG_JObject: {
      V v_fs_248 = heff_field(v_j_242, 0);
      HeffT2 v_t_249 = (g_list_2efind_24s1807954837x1305454787_24cpr(((V)&g_heff_2ebuild_2etesting_2esubtestsOfJson_str0), v_fs_248));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_p_2412 = v_field_2411;
          V v_t_2415;
          switch (heff_tag_of(v_p_2412)) {
          case TAG_MkPair: {
            V v_y_2414 = heff_field(v_p_2412, 1);
            heff_take_n(v_p_2412, 2ULL, 2);
            v_t_2415 = v_y_2414;
            break;
          }
          default: heff_nomatch(v_p_2412);
          }
          switch (heff_tag_of(v_t_2415)) {
          case TAG_JNull: {
            v_t_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2415, 0ULL, 1);
            v_t_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2415, 0ULL, 1);
            v_t_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2415, 0ULL, 1);
            v_t_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_t_2415, 0ULL, 1);
            v_t_2422 = NTAG(TAG_Nil);
            break;
          }
          case TAG_JArray: {
            V v_xs_2420 = heff_field(v_t_2415, 0);
            heff_take_n(v_t_2415, 1ULL, 1);
            v_t_2422 = v_xs_2420;
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2415, 0ULL, 1);
            v_t_2422 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_t_2415);
          }
        } else {
          heff_drop(v_field_2411);
          v_t_2422 = NTAG(TAG_Nil);
        }
      }
      break;
    }
    default: heff_nomatch(v_j_242);
    }
    HEFF_LAST return g_list_2emap_24s1113395621x248103432(v_t_2422);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2etesting_2esubtestsOfJson_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2esubtestsOfJson(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2elevelsSelected_entry, 2, 0};

V g_heff_2ebuild_2etesting_2elevelsSelected(V v_x1_240, V v_names_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_names_241, 0);
      V v_ns_245 = heff_field(v_names_241, 1);
      V v_x1_246 = heff_dup(v_r_242);
      V v_s_247 = heff_dup(v_n_244);
      V v_from_248 = MK_INT(0LL);
      V v_t_2418;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_MkRegex: {
        V v_prog_249 = heff_field(v_x1_246, 0);
        V v_groups_2410 = heff_field(v_x1_246, 1);
        heff_take_n(v_x1_246, 3ULL, 2);
        V v_t_2411 = heff_intAdd(heff_intMul(MK_INT(2LL), v_groups_2410), MK_INT(2LL));
        V v_fresh_2412 = heff_arrayReplicate(v_t_2411, MK_INT(-1LL));
        V v_t_2413 = heff_arrayReplicate(heff_arrayLength_lent(v_prog_249, 0), NTAG(TAG_False));
        V v_t_2414 = heff_rec_n(2, shape_seen__threads, (V[]){v_t_2413, NTAG(TAG_Nil)});
        V v_t_2415 = (g_regex_2egather(v_prog_249, v_s_247, v_from_248, MK_INT(0LL), heff_dup(v_fresh_2412), v_t_2414));
        V v_xs_2416 = heff_get_n(v_t_2415, 1, 2);
        V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
        v_t_2418 = ({ V a_0 = v_prog_249; V a_1 = v_fresh_2412; V a_2 = v_s_247; V a_3 = v_from_248; V a_4 = v_t_2417; V a_5 = NTAG(TAG_Nothing); V r_ = (g_regex_2erunFrom(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_prog_249); heff_drop(v_fresh_2412); heff_drop(v_s_247); r_; });
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take_n(v_t_2418, 0ULL, 1);
        V t_0 = v_rs_243;
        V t_1 = v_ns_245;
        v_x1_240 = t_0;
        v_names_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2418);
      }
    }
    default: return heff_nomatch(v_names_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2etesting_2elevelsSelected(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_str0, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_str1, 1, "\012");
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_entry, 4, 0};

V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569(V v_update_240, V v_f_241, V v_o_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam0, 2, 1, (V[]){v_o_242});
  }
  case TAG_Cons: {
    V v_g_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_248 = (g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652(v_update_240, heff_dup(v_f_241), v_g_246));
    return heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam1, 2, 5, (V[]){v_c_248, v_update_240, v_f_241, v_o_242, v_rest_247});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_o_242 = heff_env(self)[0];
  heff_drop(v_hd_244);
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = v_o_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_g_2429 = heff_env(self)[0];
  V v_hd_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_call(v_g_2429, 1, (V[]){v_x_2431}));
  V f_ = heff_get_n(v_hd_2428, 0, 3);
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam3(V self, V *args) {
  V v_g_2429 = args[0];
  V v_m_2430 = args[1];
  V v_hd_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2428, 1));
  args[0] = v_m_2430;
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam4, 1, 2, (V[]){v_g_2429, v_hd_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam5(V self, V *args) {
  V v_c_2433 = args[0];
  V v_hd_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2433;
  heff_room[0] = heff_dup(v_hd_2428);
  heff_room[1] = heff_get_n(v_hd_2428, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam6(V self, V *args) {
  V v_a_2436 = args[0];
  V v_lit_2414 = heff_env(self)[0];
  V v_lit_2415 = heff_env(self)[1];
  V v_lit_2416 = heff_env(self)[2];
  V v_lit_2417 = heff_env(self)[3];
  V v_lit_2418 = heff_env(self)[4];
  V v_lit_2419 = heff_env(self)[5];
  heff_drop(v_a_2436);
  heff_clo_take(self, 6);
  V v_t_2437 = (g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569(v_lit_2414, v_lit_2415, v_lit_2416, v_lit_2417));
  V f_ = v_t_2437;
  heff_room[0] = v_lit_2418;
  heff_room[1] = v_lit_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_o_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Holds: {
    heff_clo_take(self, 6);
    V v_t_2412 = (g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569(v_update_240, v_f_241, v_o_242, v_rest_247));
    V f_ = v_t_2412;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Wrote: {
    V v_path_2413 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Wrote = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    heff_clo_take(self, 6);
    V v_lit_2414 = v_update_240;
    V v_lit_2415 = v_f_241;
    V v_lit_2416 = v_o_242;
    V v_lit_2417 = v_rest_247;
    V v_lit_2418 = heff_dup(v_hd_249);
    V v_lit_2419 = v_k_2410;
    V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_str0), v_path_2413), ((V)&g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_str1));
    V v_t_2421 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2420, NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Wrote, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_p_2427 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2426});
    V v_hd_2428 = v_hd_249;
    V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam3, 2, 1, (V[]){heff_dup(v_hd_2428)})}), heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam5, 1, 1, (V[]){heff_dup(v_hd_2428)}), v_p_2427}));
    V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_2428, 2), 1, (V[]){v_t_2434}));
    V f_ = heff_get_n(v_hd_2428, 1, 3);
    heff_room[0] = v_t_2435;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam6, 1, 6, (V[]){v_lit_2414, v_lit_2415, v_lit_2416, v_lit_2417, v_lit_2418, v_lit_2419});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Wrong: {
    V v_note_2438 = heff_field(v_x_2411, 0);
    V v_why_2439 = heff_field(v_x_2411, 1);
    V v_ru_24x_2411_24Wrong = heff_take_reuse_n(v_x_2411, 3ULL, 2);
    heff_clo_take(self, 6);
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    heff_drop(v_rest_247);
    heff_drop(v_hd_249);
    V v_t_2440 = heff_tag_at_n(v_ru_24x_2411_24Wrong, TAG_Cons, 2, (V[]){v_note_2438, NTAG(TAG_Nil)});
    V v_t_2441 = (g_prelude_2e_2b_2b(heff_take_field(v_o_242, 8), v_t_2440));
    V v_x_2442 = ({ V rv_1 = NTAG(TAG_False); V rv_2 = NTAG(TAG_Nothing); V rv_8 = v_t_2441; V rv_9 = heff_tag_n(TAG_Just, 1, (V[]){v_why_2439}); V rr_ = heff_rec_reuse_nf(v_o_242, 3321ULL, 12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, 15794115u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    V f_ = v_k_2410;
    args[0] = v_x_2442;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_o_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569_lam2, 1, 6, (V[]){v_update_240, v_f_241, v_o_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam2(V self, V *args);
Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_entry, 3, 0};

V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    return ((V)&g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_o_245, 1));
    V v_c_2410;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_c_2410 = (g_heff_2ebuild_2etesting_2egoldensGo_24s1662925198x92774569(heff_dup(v_update_240), heff_dup(v_f_241), heff_dup(v_o_245), heff_get_n(v_o_245, 11, 12)));
    } else {
      heff_drop(v_t_247);
      v_c_2410 = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam1, 2, 1, (V[]){v_o_245});
    }
    return heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam2, 2, 4, (V[]){v_c_2410, v_update_240, v_f_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_o_245 = heff_env(self)[0];
  heff_drop(v_hd_248);
  heff_clo_take(self, 1);
  V f_ = v_k_249;
  args[0] = v_o_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(v_update_240, v_f_241, v_rest_246));
  V f_ = v_t_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam4, 1, 2, (V[]){v_k_2412, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_lam3, 1, 5, (V[]){v_update_240, v_f_241, v_rest_246, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str1, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str2, 21, "  errors, as expected");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str4, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str5, 28, "  checks, but expects errors");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str7, 43, ": checks, but its first line expects errors");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str8, 4, "heff");
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam4(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_entry, 6, 0};

V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879(V v_opts_240, V v_f_241, V v_x3_242, V v_l_243, V v_z_244, V v_z_245) {
top: ;
  if ((heff_dup(v_x3_242) == NTAG(TAG_True))) {
    if (!heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str0))) {
      heff_drop_rec(v_opts_240, 5);
      heff_drop(v_f_241);
      heff_drop_rec(v_l_243, 5);
      heff_drop(v_z_244);
      return heff_tail(v_z_245, 1, (V[]){heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2etesting_2enoRes_get())})});
    } else {
      heff_drop_rec(v_opts_240, 5);
      V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_l_243)));
      return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam0, 1, 4, (V[]){v_f_241, v_l_243, v_z_244, v_z_245})});
    }
  } else {
    return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str8), heff_dup(heff_rfield(v_l_243, 1)), MK_INT(0LL), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam4, 1, 5, (V[]){v_l_243, v_z_244, v_opts_240, v_f_241, v_z_245})));
  }
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_245;
  args[0] = heff_tag_n(TAG_Settled, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_p_2415 = heff_env(self)[0];
  heff_drop(v_x_2423);
  heff_clo_take(self, 1);
  V f_ = v_p_2415;
  args[0] = heff_dup(g_heff_2ebuild_2etesting_2eexpectedRes_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_f_248 = heff_env(self)[0];
  V v_p_2415 = heff_env(self)[1];
  heff_drop(v_x_2431);
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_f_248, ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str7)), NTAG(TAG_Nil)});
  V f_ = v_p_2415;
  args[0] = heff_rec_n(8, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed__testsSkipped, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2432, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_l_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_f_248 = v_f_241;
  V v_t_249 = heff_get_n(v_l_243, 1, 5);
  V v_x2_2412;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    v_x2_2412 = ({ V b_0 = heff_get_n(v_x_247, 0, 2); V r_ = (g_list_2eany_24s1740858080x874135214(b_0)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_249, 0ULL, 2);
    heff_drop_rec(v_x_247, 2);
    v_x2_2412 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_p_2413 = v_z_244;
  V v_p_2415 = heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam1, 1, 1, (V[]){v_z_245});
  if ((heff_dup(v_x2_2412) == NTAG(TAG_True))) {
    heff_drop(v_x2_2412);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str1), v_f_248), ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str2));
    V v_t_2417 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str3)), NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_p_2413, heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam2, 1, 1, (V[]){v_p_2415})));
  } else {
    heff_drop(v_x2_2412);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str4), heff_dup(v_f_248)), ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str5));
    V v_t_2425 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_str6)), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_p_2413, heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam3, 1, 2, (V[]){v_f_248, v_p_2415})));
  }
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_l_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_opts_240; V a_1 = v_f_241; V a_2 = v_l_243; V b_3 = heff_get_n(v_x_2435, 0, 2); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2ebuild_2etesting_2etestOneC_24s287295492x1205636284(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
}
V g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_drop(v_x_2433);
  V v_t_2434 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_l_243)));
  heff_clo_take(self, 5);
  V f_ = v_t_2434;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestLoaded_24s1488776460x835653879_lam5, 1, 5, (V[]){v_opts_240, v_f_241, v_l_243, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str13, 0, "");
Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry, 2, 0};

V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V v_tok_240, V v_j_241) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_247 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str0); V a_1 = v_fs_247; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2411 = v_field_2410;
        V v_t_2414;
        switch (heff_tag_of(v_p_2411)) {
        case TAG_MkPair: {
          V v_y_2413 = heff_field(v_p_2411, 1);
          heff_take_n(v_p_2411, 2ULL, 2);
          v_t_2414 = v_y_2413;
          break;
        }
        default: heff_nomatch(v_p_2411);
        }
        switch (heff_tag_of(v_t_2414)) {
        case TAG_JNull: {
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2418 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          v_t_2421 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_s_2418});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop_cell(v_tok_240, 1);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_field_2410);
        v_t_2421 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_j_241)) {
    case TAG_JNull: {
      return NTAG(TAG_Nothing);
    }
    case TAG_JBool: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JInt: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JFloat: {
      heff_take_na(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JString: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JArray: {
      heff_take_n(v_j_241, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JObject: {
      V v_fs_2427 = heff_field(v_j_241, 0);
      V v_ru_24j_241_24JObject = heff_take_reuse_n(v_j_241, 1ULL, 1);
      HeffT2 v_t_2428 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str1); V a_1 = v_fs_2427; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2427); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_p_2431 = v_field_2430;
          V v_t_2434;
          switch (heff_tag_of(v_p_2431)) {
          case TAG_MkPair: {
            V v_y_2433 = heff_field(v_p_2431, 1);
            heff_take_n(v_p_2431, 2ULL, 2);
            v_t_2434 = v_y_2433;
            break;
          }
          default: heff_nomatch(v_p_2431);
          }
          switch (heff_tag_of(v_t_2434)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2439 = heff_field(v_t_2434, 0);
            heff_take_n(v_t_2434, 1ULL, 1);
            switch (heff_tag_of(v_xs_2439)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24j_241_24JObject, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2440 = heff_field(v_xs_2439, 0);
              V v_it12_2441 = heff_field(v_xs_2439, 1);
              V v_ru_24xs_2439_24Cons = heff_take_reuse_n(v_xs_2439, 3ULL, 2);
              switch (heff_tag_of(v_it12_2441)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24j_241_24JObject, 1);
                heff_drop(v_expected_2440);
                heff_drop_cell(v_ru_24xs_2439_24Cons, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2442 = heff_field(v_it12_2441, 0);
                heff_take_n(v_it12_2441, 1ULL, 2);
                V v_t_2450;
                switch (heff_tag_of(v_expected_2440)) {
                case TAG_JNull: {
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2447 = heff_field(v_expected_2440, 0);
                  heff_take_n(v_expected_2440, 1ULL, 1);
                  v_t_2450 = v_t_2447;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2440, 0ULL, 1);
                  v_t_2450 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2440);
                }
                V v_t_2457;
                switch (heff_tag_of(v_got_2442)) {
                case TAG_JNull: {
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2454 = heff_field(v_got_2442, 0);
                  heff_take_n(v_got_2442, 1ULL, 1);
                  v_t_2457 = v_t_2454;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2442, 0ULL, 1);
                  v_t_2457 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_str13);
                  break;
                }
                default: heff_nomatch(v_got_2442);
                }
                return heff_tag_at_n(v_ru_24j_241_24JObject, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24xs_2439_24Cons, TAG_FailDiffer, 2, (V[]){v_t_2450, v_t_2457})});
              }
              default: return heff_nomatch(v_it12_2441);
              }
            }
            default: return heff_nomatch(v_xs_2439);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_t_2434, 0ULL, 1);
            heff_drop_cell(v_ru_24j_241_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2434);
          }
        } else {
          heff_drop_cell(v_ru_24j_241_24JObject, 1);
          heff_drop(v_field_2430);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_j_241);
    }
  }
  case TAG_Just: {
    V v_why_2459 = heff_field(v_t_2421, 0);
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
    heff_drop(v_j_241);
    return heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2459})});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(a[0], a[1]);
}