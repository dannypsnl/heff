// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinding 25795
#define TAG_EBindingP 13114
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_Fail 27959
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_hungOn 741036848
#define LBL_ifLink 754803170
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__hungOn__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_hungOn, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblockLast(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eblockLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V);
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2egroup_24tok2(V, V);
V g_std_2edoc_2egroup_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_24tok2_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_t_2414;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_rfield(v_t_241, 7)));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_245 = v_field_244;
        switch (heff_tag_of(v_x_245)) {
        case TAG_Nil: {
          v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
          break;
        }
        case TAG_Cons: {
          V v_ru_24x_245_24Cons = heff_take_reuse_n(v_x_245, 0ULL, 2);
          V v_t_2412;
          if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
            v_t_2412 = NTAG(TAG_Nil);
          } else {
            HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_rfield(v_t_241, 7)));
            {
              V v_field_2410 = v_t_248.f[1];
              int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
              if ((v_tag_249 == ((int64_t)0ULL))) {
                V v_x_2411 = v_field_2410;
                v_t_2412 = v_x_2411;
              } else {
                heff_drop(v_field_2410);
                v_t_2412 = NTAG(TAG_Nil);
              }
            }
          }
          V v_t_2413 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2412); r_; });
          v_t_2414 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x_245_24Cons, v_t_2413, heff_dup(g_std_2edoc_2ehardline_get())));
          break;
        }
        default: heff_nomatch(v_x_245);
        }
      } else {
        heff_drop(v_field_244);
        v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
  }
  HeffT2 v_t_2415 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 2), heff_rfield(v_t_241, 7)));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_t_2419;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      v_t_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2417);
      v_t_2419 = NTAG(TAG_Nil);
    }
    V v_t_2420 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_s_2421 = heff_dup(heff_rfield(v_t_241, 2));
    V v_t_2422;
    if (heff_strEq_c_lent(v_s_2421, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
      heff_drop(v_s_2421);
      v_t_2422 = NTAG(TAG_None);
    } else {
      v_t_2422 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2421});
    }
    V v_t_2423;
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
      heff_drop_rec(v_env_240, 7);
      heff_drop_rec(v_t_241, 9);
      v_t_2423 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
    }
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2420, v_t_2424));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2425);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_blank_244 = heff_dup(heff_rfield(v_c_242, 1));
    V v_text_245 = heff_dup(heff_rfield(v_c_242, 0));
    V v_t_247;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_246 = v_blank_244;
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_246);
        v_t_247 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      heff_drop(v_blank_244);
      v_t_247 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_248 = ({ V a_0 = v_text_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(a_0)); heff_drop(v_text_245); r_; });
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_249));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_248, v_t_2410));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_247, v_t_2411);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2455));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2479 = heff_field(v_e_240, 3);
    V t_0 = v_body_2479;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  case TAG_EWithBound: {
    return NTAG(TAG_False);
  }
  case TAG_EBinding: {
    return NTAG(TAG_False);
  }
  case TAG_EBindingP: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Op: {
    V v_a_241 = heff_field(v_e_240, 0);
    V v_op_242 = heff_field(v_e_240, 1);
    V v_b_243 = heff_field(v_e_240, 2);
    HeffT2 v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(v_b_243));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_bf_247 = v_field_245;
      V v_rest_248 = v_field_246;
      V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_242), v_rest_248));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_242), v_bf_247}), v_rest_248});
        return ((HeffT2){{heff_dup(v_a_241), v_t_2410}});
      } else {
        heff_drop(v_bf_247);
        heff_drop(v_rest_248);
        heff_drop(v_t_249);
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_242), heff_dup(v_b_243)}), NTAG(TAG_Nil)});
        return ((HeffT2){{heff_dup(v_a_241), v_t_2411}});
      }
    }
  }
  default: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_OpRhs: {
      V v_op_243 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    default: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_commas_243);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2412 = v_commas_243;
    } else {
      v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_commas_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_commas_243); r_; });
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_x1_240, 1);
    V v_x1_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2455)));
    switch (heff_tag_of(v_x1_2456)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_x1_2456, 0);
      V v_rev_2458 = heff_field(v_x1_2456, 1);
      heff_take_n(v_x1_2456, 3ULL, 2);
      V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_2458));
      V v_init2_2460 = v_t_2459;
      heff_drop(v_init2_2460);
      V v_it12_2461 = v_x_2457;
      switch (heff_tag_of(v_it12_2461)) {
      case TAG_EParen: {
        V v_e_2463 = heff_field(v_it12_2461, 1);
        heff_take_n(v_it12_2461, 2ULL, 3);
        return ({ V a_0 = v_e_2463; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_e_2463); r_; });
      }
      default: {
        return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_it12_2461); r_; });
      }
      }
    }
    default: return heff_nomatch(v_x1_2456);
    }
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  case TAG_EWithBound: {
    return NTAG(TAG_False);
  }
  case TAG_EBinding: {
    return NTAG(TAG_False);
  }
  case TAG_EBindingP: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangsLast(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2455));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_True);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  case TAG_EWithBound: {
    return NTAG(TAG_False);
  }
  case TAG_EBinding: {
    return NTAG(TAG_False);
  }
  case TAG_EBindingP: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}

static V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_st;
static V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_init(void) {
  return heff_tag_n(TAG_FlatAlt, 2, (V[]){heff_dup(g_std_2edoc_2eemptyDoc_get()), NTAG(TAG_Fail)});
}
V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_st)) return g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_val, &g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_st, g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_init);
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_ix_246 = heff_take_field(v_t_245, 7);
      V v_blank_247 = heff_get_n(v_t_245, 8, 9);
      HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_env_240, 1); V a_1 = v_ix_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_ix_246); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_t_2414;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = v_blank_247;
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop(v_blank_247);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2414 = v_blank_247;
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_ix_246 = heff_take_field(v_t_245, 7);
      V v_blank_247 = heff_get_n(v_t_245, 8, 9);
      HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_env_240, 1); V a_1 = v_ix_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_ix_246); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_t_2414;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = v_blank_247;
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop(v_blank_247);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2414 = v_blank_247;
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, "=");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 4, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam48_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam49_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam55_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam56_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(17, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__hungOn__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam36_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam37_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam38_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam39_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam42_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam43_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam46_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam47_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam48_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam49_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam50_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam51_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam54_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam55_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam56_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam57_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c_lent(v_i_2411, MK_INT(0LL), 2)) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2443 = args[0];
  V v_e_2444 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_a_2445 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2443));
  heff_clo_take(self, 1);
  V v_one_2446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_240}));
  V v_t_2447 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_2444));
  V v_b_2451;
  if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
    heff_drop(v_t_2447);
    V v_d_2448 = heff_tr(heff_call(v_one_2446, 1, (V[]){v_e_2444}));
    v_b_2451 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2448});
  } else {
    heff_drop(v_t_2447);
    V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_2444));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_t_2449);
      V v_d_2450 = heff_tr(heff_call(v_one_2446, 1, (V[]){v_e_2444}));
      v_b_2451 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2450});
    } else {
      heff_drop(v_t_2449);
      v_b_2451 = heff_tr(heff_call(v_one_2446, 1, (V[]){v_e_2444}));
    }
  }
  V v_t_2452 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), v_b_2451));
  V v_t_2453 = (g_std_2edoc_2e_3c_3e(v_a_2445, v_t_2452));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2453));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2465 = args[0];
  V v_k_2464 = heff_env(self)[0];
  V v_d_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2466 = heff_intSub(v_k_2464, v_i_2465);
  if (heff_intEq_c_lent(v_i_2466, MK_INT(0LL), 2)) {
    heff_drop(v_i_2466);
    return v_d_2463;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2466, v_d_2463});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2464 = args[0];
  V v_d_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2464, v_d_2463})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2472 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2472));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2487 = args[0];
  V v_f_2488 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_a_2489 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2487));
  heff_clo_take(self, 1);
  V v_d_2490 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 2, (V[]){v_env_240, v_f_2488}));
  V v_t_2491 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2490})));
  V v_t_2492 = (g_std_2edoc_2e_3c_3e(v_a_2489, v_t_2491));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2492));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_24101 = args[0];
  V v_k_24100 = heff_env(self)[0];
  V v_d_2499 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24102 = heff_intSub(v_k_24100, v_i_24101);
  if (heff_intEq_c_lent(v_i_24102, MK_INT(0LL), 2)) {
    heff_drop(v_i_24102);
    return v_d_2499;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24102, v_d_2499});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_24100 = args[0];
  V v_d_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_24100, v_d_2499})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24128 = args[0];
  V v_f_24129 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_a_24130 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24128));
  heff_clo_take(self, 1);
  V v_d_24131 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 2, (V[]){v_env_240, v_f_24129}));
  V v_t_24132 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24131})));
  V v_t_24133 = (g_std_2edoc_2e_3c_3e(v_a_24130, v_t_24132));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24133));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24144 = args[0];
  V v_k_24143 = heff_env(self)[0];
  V v_d_24142 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24145 = heff_intSub(v_k_24143, v_i_24144);
  if (heff_intEq_c_lent(v_i_24145, MK_INT(0LL), 2)) {
    heff_drop(v_i_24145);
    return v_d_24142;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24145, v_d_24142});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24143 = args[0];
  V v_d_24142 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24143, v_d_24142})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24201 = args[0];
  V v_a_24202 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24184 = heff_env(self)[1];
  V v_c_24187 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24203 = ({ V a_0 = heff_rfield(v_env_240, 0); V a_1 = heff_get_n(v_o_24184, 4, 9); V b_2 = heff_get_n(v_c_24187, 3, 9); V r_ = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_24204;
  if ((heff_dup(v_x1_24203) == NTAG(TAG_True))) {
    heff_drop(v_x1_24203);
    v_t_24204 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24203);
    v_t_24204 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24205 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24201));
  V v_b_24206 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24202}));
  V v_t_24207 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24206));
  V v_t_24208 = (g_std_2edoc_2e_3c_3e(v_a_24205, v_t_24207));
  return (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24208));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24215 = args[0];
  V v_k_24214 = heff_env(self)[0];
  V v_d_24213 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24216 = heff_intSub(v_k_24214, v_i_24215);
  if (heff_intEq_c_lent(v_i_24216, MK_INT(0LL), 2)) {
    heff_drop(v_i_24216);
    return v_d_24213;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24216, v_d_24213});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24214 = args[0];
  V v_d_24213 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24214, v_d_24213})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24222 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24223 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24222}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24223));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24250 = args[0];
  V v_op_24240 = heff_env(self)[0];
  V v_bf_24245 = heff_env(self)[1];
  V v_rest_24246 = heff_env(self)[2];
  V v_env_240 = heff_env(self)[3];
  V v_x1_24251 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24250));
  V v_t_24252;
  if ((heff_dup(v_x1_24251) == NTAG(TAG_True))) {
    heff_drop(v_x1_24251);
    v_t_24252 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24251);
    v_t_24252 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 4);
  V v_t_24253 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24240, v_bf_24245}), v_rest_24246});
  V v_t_24254 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 3, (V[]){v_env_240, v_t_24253, v_r_24250}));
  return (g_std_2edoc_2e_3c_3e(v_t_24252, v_t_24254));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24382 = args[0];
  V v_k_24381 = heff_env(self)[0];
  V v_d_24380 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24383 = heff_intSub(v_k_24381, v_i_24382);
  if (heff_intEq_c_lent(v_i_24383, MK_INT(0LL), 2)) {
    heff_drop(v_i_24383);
    return v_d_24380;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24383, v_d_24380});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24381 = args[0];
  V v_d_24380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24381, v_d_24380})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24446 = args[0];
  V v_k_24445 = heff_env(self)[0];
  V v_d_24442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24447 = heff_intSub(v_k_24445, v_i_24446);
  if (heff_intEq_c_lent(v_i_24447, MK_INT(0LL), 2)) {
    heff_drop(v_i_24447);
    return v_d_24442;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24447, v_d_24442});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24445 = args[0];
  V v_d_24442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24445, v_d_24442})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24465 = args[0];
  V v_k_24464 = heff_env(self)[0];
  V v_d_24461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24466 = heff_intSub(v_k_24464, v_i_24465);
  if (heff_intEq_c_lent(v_i_24466, MK_INT(0LL), 2)) {
    heff_drop(v_i_24466);
    return v_d_24461;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24466, v_d_24461});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24464 = args[0];
  V v_d_24461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24464, v_d_24461})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_i_24517 = args[0];
  V v_k_24516 = heff_env(self)[0];
  V v_d_24515 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24518 = heff_intSub(v_k_24516, v_i_24517);
  if (heff_intEq_c_lent(v_i_24518, MK_INT(0LL), 2)) {
    heff_drop(v_i_24518);
    return v_d_24515;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24518, v_d_24515});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_k_24516 = args[0];
  V v_d_24515 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 2, (V[]){v_k_24516, v_d_24515})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_i_24548 = args[0];
  V v_k_24547 = heff_env(self)[0];
  V v_d_24538 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24549 = heff_intSub(v_k_24547, v_i_24548);
  if (heff_intEq_c_lent(v_i_24549, MK_INT(0LL), 2)) {
    heff_drop(v_i_24549);
    return v_d_24538;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24549, v_d_24538});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_k_24547 = args[0];
  V v_d_24538 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 2, (V[]){v_k_24547, v_d_24538})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_i_24556 = args[0];
  V v_k_24555 = heff_env(self)[0];
  V v_d_24554 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24557 = heff_intSub(v_k_24555, v_i_24556);
  if (heff_intEq_c_lent(v_i_24557, MK_INT(0LL), 2)) {
    heff_drop(v_i_24557);
    return v_d_24554;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24557, v_d_24554});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_k_24555 = args[0];
  V v_d_24554 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 1, 2, (V[]){v_k_24555, v_d_24554})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_i_24577 = args[0];
  V v_k_24576 = heff_env(self)[0];
  V v_d_24575 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24578 = heff_intSub(v_k_24576, v_i_24577);
  if (heff_intEq_c_lent(v_i_24578, MK_INT(0LL), 2)) {
    heff_drop(v_i_24578);
    return v_d_24575;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24578, v_d_24575});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_k_24576 = args[0];
  V v_d_24575 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 1, 2, (V[]){v_k_24576, v_d_24575})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_i_24585 = args[0];
  V v_k_24584 = heff_env(self)[0];
  V v_d_24583 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24586 = heff_intSub(v_k_24584, v_i_24585);
  if (heff_intEq_c_lent(v_i_24586, MK_INT(0LL), 2)) {
    heff_drop(v_i_24586);
    return v_d_24583;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24586, v_d_24583});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_k_24584 = args[0];
  V v_d_24583 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 2, (V[]){v_k_24584, v_d_24583})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_i_24595 = args[0];
  V v_k_24594 = heff_env(self)[0];
  V v_d_24593 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24596 = heff_intSub(v_k_24594, v_i_24595);
  if (heff_intEq_c_lent(v_i_24596, MK_INT(0LL), 2)) {
    heff_drop(v_i_24596);
    return v_d_24593;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24596, v_d_24593});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_k_24594 = args[0];
  V v_d_24593 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 2, (V[]){v_k_24594, v_d_24593})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24Atom, v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2412 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2412));
  }
  case TAG_Named: {
    V v_o_2413 = heff_field(v_e0_241, 0);
    V v_x_2414 = heff_field(v_e0_241, 1);
    V v_k_2415 = heff_field(v_e0_241, 2);
    V v_e_2416 = heff_field(v_e0_241, 3);
    V v_c_2417 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2418 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2413));
    V v_a_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2415));
    V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2416}));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2421));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_a_2419, v_t_2424));
    V v_t_2426 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2417));
    V v_t_2427 = (g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2426));
    return (g_std_2edoc_2e_3c_3e(v_t_2418, v_t_2427));
  }
  case TAG_Tup: {
    V v_o_2428 = heff_field(v_e0_241, 0);
    V v_es_2429 = heff_field(v_e0_241, 1);
    V v_commas_2430 = heff_field(v_e0_241, 2);
    V v_c_2431 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2429)) {
    case TAG_Nil: {
      heff_drop(v_commas_2430);
      V v_t_2432 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2428));
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2431));
      return (g_std_2edoc_2e_3c_3e(v_t_2432, v_t_2433));
    }
    case TAG_Cons: {
      V v_e1_2434 = heff_field(v_es_2429, 0);
      V v_more_2435 = heff_field(v_es_2429, 1);
      V v_ru_24es_2429_24Cons = heff_take_reuse_n(v_es_2429, 3ULL, 2);
      V v_t_2436 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2428)));
      V v_one_2437 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_240)}));
      V v_t_2438 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e1_2434));
      V v_t_2442;
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_t_2438);
        V v_d_2439 = heff_tr(heff_call(v_one_2437, 1, (V[]){v_e1_2434}));
        v_t_2442 = heff_tag_at_n(v_ru_24es_2429_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2439});
      } else {
        heff_drop(v_t_2438);
        V v_t_2440 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e1_2434));
        if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
          heff_drop(v_t_2440);
          V v_d_2441 = heff_tr(heff_call(v_one_2437, 1, (V[]){v_e1_2434}));
          v_t_2442 = heff_tag_at_n(v_ru_24es_2429_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2441});
        } else {
          heff_drop_cell(v_ru_24es_2429_24Cons, 2);
          heff_drop(v_t_2440);
          v_t_2442 = heff_tr(heff_call(v_one_2437, 1, (V[]){v_e1_2434}));
        }
      }
      V v_t_2454 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2430; V a_3 = v_more_2435; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_commas_2430); heff_drop(v_more_2435); r_; });
      V v_x1_2455 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2428, 4, 9), heff_rfield(v_c_2431, 3)));
      V v_t_2456;
      if ((heff_dup(v_x1_2455) == NTAG(TAG_True))) {
        heff_drop(v_x1_2455);
        v_t_2456 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2455);
        v_t_2456 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2431));
      V v_t_2458 = (g_std_2edoc_2e_3c_3e(v_t_2456, v_t_2457));
      V v_t_2459 = (g_std_2edoc_2e_3c_3e(v_t_2454, v_t_2458));
      V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2442, v_t_2459));
      V v_t_2461 = heff_tag_n(TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2461, v_t_2460));
      V v_d_2463 = (g_std_2edoc_2e_3c_3e(v_t_2436, v_t_2462));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2463})})));
    }
    default: return heff_nomatch(v_es_2429);
    }
  }
  case TAG_Seg: {
    V v_v_2467 = heff_field(v_e0_241, 0);
    V v_cc_2468 = heff_field(v_e0_241, 1);
    V v_spec_2469 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2467}));
    V v_t_2471 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2468));
    V v_t_2473 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2469; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_spec_2469); r_; });
    V v_t_2474 = (g_std_2edoc_2e_3c_3e(v_t_2471, v_t_2473));
    return (g_std_2edoc_2e_3c_3e(v_t_2470, v_t_2474));
  }
  case TAG_Braces: {
    V v_o_2475 = heff_field(v_e0_241, 0);
    V v_fs_2476 = heff_field(v_e0_241, 1);
    V v_commas_2477 = heff_field(v_e0_241, 2);
    V v_c_2478 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2476)) {
    case TAG_Nil: {
      heff_drop(v_commas_2477);
      V v_t_2479 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2475));
      V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2478));
      return (g_std_2edoc_2e_3c_3e(v_t_2479, v_t_2480));
    }
    case TAG_Cons: {
      V v_f1_2481 = heff_field(v_fs_2476, 0);
      V v_more_2482 = heff_field(v_fs_2476, 1);
      V v_ru_24fs_2476_24Cons = heff_take_reuse_n(v_fs_2476, 3ULL, 2);
      V v_a_2483 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2475)));
      V v_d_2484 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 2, (V[]){heff_dup(v_env_240), v_f1_2481}));
      V v_t_2485 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2476_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2484})));
      V v_t_2486 = (g_std_2edoc_2e_3c_3e(v_a_2483, v_t_2485));
      V v_t_2493 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2477; V a_3 = v_more_2482; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_commas_2477); heff_drop(v_more_2482); r_; });
      V v_x1_2494 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2475, 4, 9), heff_rfield(v_c_2478, 3)));
      V v_t_2495;
      if ((heff_dup(v_x1_2494) == NTAG(TAG_True))) {
        heff_drop(v_x1_2494);
        v_t_2495 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2494);
        v_t_2495 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2496 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2478));
      V v_t_2497 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2496));
      V v_t_2498 = (g_std_2edoc_2e_3c_3e(v_t_2493, v_t_2497));
      V v_d_2499 = (g_std_2edoc_2e_3c_3e(v_t_2486, v_t_2498));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_2499})})));
    }
    default: return heff_nomatch(v_fs_2476);
    }
  }
  case TAG_Update: {
    V v_o_24103 = heff_field(v_e0_241, 0);
    V v_r_24104 = heff_field(v_e0_241, 1);
    V v_bar_24105 = heff_field(v_e0_241, 2);
    V v_fs_24106 = heff_field(v_e0_241, 3);
    V v_commas_24107 = heff_field(v_e0_241, 4);
    V v_c_24108 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_24106)) {
    case TAG_Nil: {
      heff_drop(v_commas_24107);
      V v_a_24109 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24103));
      V v_a_24110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24104}));
      V v_a_24111 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24105));
      V v_b_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24108));
      V v_t_24113 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24112));
      V v_t_24114 = (g_std_2edoc_2e_3c_3e(v_a_24111, v_t_24113));
      V v_t_24115 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24114));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(v_a_24110, v_t_24115));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24116));
      return (g_std_2edoc_2e_3c_3e(v_a_24109, v_t_24117));
    }
    case TAG_Cons: {
      V v_f1_24118 = heff_field(v_fs_24106, 0);
      V v_more_24119 = heff_field(v_fs_24106, 1);
      V v_ru_24fs_24106_24Cons = heff_take_reuse_n(v_fs_24106, 3ULL, 2);
      V v_a_24120 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24103)));
      V v_d_24121 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24104}));
      V v_t_24122 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24106_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24121})));
      V v_t_24123 = (g_std_2edoc_2e_3c_3e(v_a_24120, v_t_24122));
      V v_a_24124 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24105));
      V v_d_24125 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 2, (V[]){heff_dup(v_env_240), v_f1_24118}));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24125})));
      V v_t_24127 = (g_std_2edoc_2e_3c_3e(v_a_24124, v_t_24126));
      V v_t_24134 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24107; V a_3 = v_more_24119; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_commas_24107); heff_drop(v_more_24119); r_; });
      V v_x1_24135 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24103, 4, 9), heff_rfield(v_c_24108, 3)));
      V v_t_24136;
      if ((heff_dup(v_x1_24135) == NTAG(TAG_True))) {
        heff_drop(v_x1_24135);
        v_t_24136 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24135);
        v_t_24136 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24137 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24108));
      V v_t_24138 = (g_std_2edoc_2e_3c_3e(v_t_24136, v_t_24137));
      V v_t_24139 = (g_std_2edoc_2e_3c_3e(v_t_24134, v_t_24138));
      V v_t_24140 = (g_std_2edoc_2e_3c_3e(v_t_24127, v_t_24139));
      V v_t_24141 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24140));
      V v_d_24142 = (g_std_2edoc_2e_3c_3e(v_t_24123, v_t_24141));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24142})})));
    }
    default: return heff_nomatch(v_fs_24106);
    }
  }
  case TAG_EUSet: {
    V v_x_24146 = heff_field(v_e0_241, 0);
    V v_eq_24147 = heff_field(v_e0_241, 1);
    V v_e_24148 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24149 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24146}));
    V v_b_24150 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24147));
    V v_t_24151 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24150));
    V v_t_24152 = (g_std_2edoc_2e_3c_3e(v_a_24149, v_t_24151));
    V v_t_24153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24148}));
    return (g_std_2edoc_2e_3c_3e(v_t_24152, v_t_24153));
  }
  case TAG_InstB: {
    V v_o_24154 = heff_field(v_e0_241, 0);
    V v_o2_24155 = heff_field(v_e0_241, 1);
    V v_d_24156 = heff_field(v_e0_241, 2);
    V v_c1_24157 = heff_field(v_e0_241, 3);
    V v_c_24158 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24159 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24154));
    V v_t_24160 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24155));
    V v_t_24161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24156}));
    V v_t_24162 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24157));
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24158));
    V v_t_24164 = (g_std_2edoc_2e_3c_3e(v_t_24162, v_t_24163));
    V v_t_24165 = (g_std_2edoc_2e_3c_3e(v_t_24161, v_t_24164));
    V v_t_24166 = (g_std_2edoc_2e_3c_3e(v_t_24160, v_t_24165));
    return (g_std_2edoc_2e_3c_3e(v_t_24159, v_t_24166));
  }
  case TAG_EFSet: {
    V v_x_24167 = heff_field(v_e0_241, 0);
    V v_eq_24168 = heff_field(v_e0_241, 1);
    V v_e_24169 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24170 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24167));
    V v_b_24171 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24168));
    V v_t_24172 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24171));
    V v_t_24173 = (g_std_2edoc_2e_3c_3e(v_a_24170, v_t_24172));
    V v_t_24174 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24169}));
    return (g_std_2edoc_2e_3c_3e(v_t_24173, v_t_24174));
  }
  case TAG_EFDefault: {
    V v_d_24175 = heff_field(v_e0_241, 0);
    V v_eq_24176 = heff_field(v_e0_241, 1);
    V v_e_24177 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24175}));
    V v_b_24179 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24176));
    V v_t_24180 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24179));
    V v_t_24181 = (g_std_2edoc_2e_3c_3e(v_a_24178, v_t_24180));
    V v_t_24182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24177}));
    return (g_std_2edoc_2e_3c_3e(v_t_24181, v_t_24182));
  }
  case TAG_Sum: {
    V v_kw_24183 = heff_field(v_e0_241, 0);
    V v_o_24184 = heff_field(v_e0_241, 1);
    V v_alts_24185 = heff_field(v_e0_241, 2);
    V v_bars_24186 = heff_field(v_e0_241, 3);
    V v_c_24187 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24185)) {
    case TAG_Nil: {
      heff_drop(v_bars_24186);
      V v_a_24188 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24183));
      V v_a_24189 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24184));
      V v_b_24190 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24187));
      V v_t_24191 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24190));
      V v_t_24192 = (g_std_2edoc_2e_3c_3e(v_a_24189, v_t_24191));
      V v_t_24193 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24192));
      return (g_std_2edoc_2e_3c_3e(v_a_24188, v_t_24193));
    }
    case TAG_Cons: {
      V v_a1_24194 = heff_field(v_alts_24185, 0);
      V v_more_24195 = heff_field(v_alts_24185, 1);
      V v_ru_24alts_24185_24Cons = heff_take_reuse_n(v_alts_24185, 3ULL, 2);
      V v_a_24196 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24183));
      V v_a_24197 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24184)));
      V v_b_24198 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24194}));
      V v_t_24199 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24alts_24185_24Cons, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24198));
      V v_t_24200 = (g_std_2edoc_2e_3c_3e(v_a_24197, v_t_24199));
      V v_a_24209 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24184, heff_dup(v_c_24187)}); V a_2 = v_bars_24186; V a_3 = v_more_24195; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_bars_24186); heff_drop(v_more_24195); r_; });
      V v_b_24210 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24187));
      V v_t_24211 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24210));
      V v_t_24212 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24211));
      V v_d_24213 = (g_std_2edoc_2e_3c_3e(v_t_24200, v_t_24212));
      V v_b_24217 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24213})})));
      V v_t_24218 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24217));
      return (g_std_2edoc_2e_3c_3e(v_a_24196, v_t_24218));
    }
    default: return heff_nomatch(v_alts_24185);
    }
  }
  case TAG_ECon: {
    V v_c_24219 = heff_field(v_e0_241, 0);
    V v_args_24220 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ECon = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24221 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24219));
    V v_t_24224 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24220; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_args_24220); r_; });
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24ECon, v_t_24221, v_t_24224));
  }
  case TAG_EField: {
    V v_e_24225 = heff_field(v_e0_241, 0);
    V v_f_24226 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24227 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24225}));
    V v_t_24228 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24226));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24EField, v_t_24227, v_t_24228));
  }
  case TAG_ENeg: {
    V v_m_24229 = heff_field(v_e0_241, 0);
    V v_e_24230 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24231 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24229));
    V v_t_24232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24230}));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24ENeg, v_t_24231, v_t_24232));
  }
  case TAG_ETilde: {
    V v_m_24233 = heff_field(v_e0_241, 0);
    V v_e_24234 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ETilde = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24235 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24233));
    V v_t_24236 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24234}));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24ETilde, v_t_24235, v_t_24236));
  }
  case TAG_App: {
    V v_h_24237 = heff_field(v_e0_241, 0);
    V v_args_24238 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = MK_INT(0LL);
    heff_room[2] = v_h_24237;
    heff_room[3] = v_args_24238;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  case TAG_Op: {
    V v_a_24239 = heff_field(v_e0_241, 0);
    V v_op_24240 = heff_field(v_e0_241, 1);
    V v_b_24241 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24242 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(v_b_24241));
    {
      V v_field_24243 = v_t_24242.f[0];
      V v_field_24244 = v_t_24242.f[1];
      V v_bf_24245 = v_field_24243;
      V v_rest_24246 = v_field_24244;
      V v_t_24247 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_24240), v_rest_24246));
      if ((heff_dup(v_t_24247) == NTAG(TAG_True))) {
        heff_drop(v_b_24241);
        heff_drop(v_t_24247);
        V v_t_24248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24240), heff_dup(v_bf_24245)}), heff_dup(v_rest_24246)});
        V v_t_24249 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 3, (V[]){heff_dup(v_env_240), v_t_24248, v_a_24239}));
        V v_f_24255 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 4, (V[]){heff_dup(v_op_24240), heff_dup(v_bf_24245), heff_dup(v_rest_24246), v_env_240});
        V v_t_24256 = heff_tr(heff_call(heff_dup(v_f_24255), 1, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24240, v_bf_24245})}));
        V v_t_24257 = (g_list_2emap(v_f_24255, v_rest_24246));
        V v_ds_24258 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24256, v_t_24257});
        V v_t_24259 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24258; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop_tag(v_ds_24258, 2); r_; });
        V v_t_24260 = (g_std_2edoc_2e_3c_3e(v_t_24249, v_t_24259));
        return (g_std_2edoc_2egroup(v_t_24260));
      } else {
        heff_drop(v_bf_24245);
        heff_drop(v_rest_24246);
        heff_drop(v_t_24247);
        V v_t_24261 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24240), heff_dup(v_b_24241)}), NTAG(TAG_Nil)});
        V v_t_24262 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 3, (V[]){heff_dup(v_env_240), v_t_24261, v_a_24239}));
        V v_x1_24263 = ({ V b_0 = heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24240), heff_dup(v_b_24241)}); V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(b_0)); heff_drop(b_0); r_; });
        V v_t_24264;
        if ((heff_dup(v_x1_24263) == NTAG(TAG_True))) {
          heff_drop(v_x1_24263);
          v_t_24264 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_24263);
          v_t_24264 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_t_24265 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24240), heff_dup(v_b_24241)}), NTAG(TAG_Nil)});
        V v_t_24266 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 3, (V[]){v_env_240, v_t_24265, heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24240, v_b_24241})}));
        V v_t_24267 = (g_std_2edoc_2e_3c_3e(v_t_24264, v_t_24266));
        V v_ds_24268 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24267, NTAG(TAG_Nil)});
        V v_t_24269 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24268; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop_tag(v_ds_24268, 2); r_; });
        V v_t_24270 = (g_std_2edoc_2e_3c_3e(v_t_24262, v_t_24269));
        return (g_std_2edoc_2egroup(v_t_24270));
      }
    }
  }
  case TAG_Ops: {
    V v_a_24271 = heff_field(v_e0_241, 0);
    V v_rest_24272 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24271;
    heff_room[2] = v_rest_24272;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24273 = heff_field(v_e0_241, 0);
    V v_e_24274 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24OpRhs = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24275 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24273));
    V v_b_24276 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24274}));
    V v_t_24277 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24OpRhs, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24276));
    return (g_std_2edoc_2e_3c_3e(v_a_24275, v_t_24277));
  }
  case TAG_Ann: {
    V v_e_24278 = heff_field(v_e0_241, 0);
    V v_cc_24279 = heff_field(v_e0_241, 1);
    V v_ty_24280 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24281 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24278}));
    V v_b_24282 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24279));
    V v_t_24283 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24282));
    V v_t_24284 = (g_std_2edoc_2e_3c_3e(v_a_24281, v_t_24283));
    V v_t_24285 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24280}));
    V v_d_24286 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24285));
    V v_t_24287 = (g_std_2edoc_2e_3c_3e(v_t_24284, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24286})));
    return (g_std_2edoc_2egroup(v_t_24287));
  }
  case TAG_BVar: {
    V v_t_24288 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24BVar = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24BVar, v_env_240, v_t_24288));
  }
  case TAG_BImp: {
    V v_o_24289 = heff_field(v_e0_241, 0);
    V v_x_24290 = heff_field(v_e0_241, 1);
    V v_c_24291 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24292 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24289));
    V v_t_24293 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24290));
    V v_t_24294 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24291));
    V v_t_24295 = (g_std_2edoc_2e_3c_3e(v_t_24293, v_t_24294));
    return (g_std_2edoc_2e_3c_3e(v_t_24292, v_t_24295));
  }
  case TAG_BAnn: {
    V v_o_24296 = heff_field(v_e0_241, 0);
    V v_x_24297 = heff_field(v_e0_241, 1);
    V v_cc_24298 = heff_field(v_e0_241, 2);
    V v_ty_24299 = heff_field(v_e0_241, 3);
    V v_c_24300 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24301 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24296));
    V v_a_24302 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24297));
    V v_a_24303 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24298));
    V v_b_24304 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24299}));
    V v_t_24305 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24304));
    V v_t_24306 = (g_std_2edoc_2e_3c_3e(v_a_24303, v_t_24305));
    V v_t_24307 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24306));
    V v_t_24308 = (g_std_2edoc_2e_3c_3e(v_a_24302, v_t_24307));
    V v_t_24309 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24300));
    V v_t_24310 = (g_std_2edoc_2e_3c_3e(v_t_24308, v_t_24309));
    return (g_std_2edoc_2e_3c_3e(v_t_24301, v_t_24310));
  }
  case TAG_BPat: {
    V v_p_24311 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return ({ V a_0 = v_env_240; V a_1 = v_p_24311; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_p_24311); r_; });
  }
  case TAG_Lam: {
    V v_bs_24312 = heff_field(v_e0_241, 0);
    V v_binders_24313 = heff_field(v_e0_241, 1);
    V v_arrow_24314 = heff_field(v_e0_241, 2);
    V v_body_24315 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24316 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24312));
    V v_t_24317 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24318 = (g_list_2emap(v_t_24317, v_binders_24313));
    V v_a_24319 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24318; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24318); r_; });
    V v_b_24320 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24314));
    V v_t_24321 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24320));
    V v_t_24322 = (g_std_2edoc_2e_3c_3e(v_a_24319, v_t_24321));
    V v_t_24323 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24315));
    V v_t_24327;
    if ((heff_dup(v_t_24323) == NTAG(TAG_True))) {
      heff_drop(v_t_24323);
      V v_t_24324 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24315}));
      v_t_24327 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24324));
    } else {
      heff_drop(v_t_24323);
      V v_t_24325 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 2, (V[]){v_env_240, v_body_24315}));
      V v_d_24326 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24325));
      v_t_24327 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24326})));
    }
    V v_t_24328 = (g_std_2edoc_2e_3c_3e(v_t_24322, v_t_24327));
    return (g_std_2edoc_2e_3c_3e(v_t_24316, v_t_24328));
  }
  case TAG_Case: {
    V v_kw_24329 = heff_field(v_e0_241, 0);
    V v_scrut_24330 = heff_field(v_e0_241, 1);
    V v_of2_24331 = heff_field(v_e0_241, 2);
    V v_alts_24332 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24333 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24329));
    V v_a_24334 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24330}));
    V v_b_24335 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24331));
    V v_t_24336 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24335));
    V v_t_24337 = (g_std_2edoc_2e_3c_3e(v_a_24334, v_t_24336));
    V v_t_24338 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24337));
    V v_t_24339 = (g_std_2edoc_2e_3c_3e(v_a_24333, v_t_24338));
    V v_t_24340 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24332; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1498724748x1708929622(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop(v_alts_24332); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24339, v_t_24340));
  }
  case TAG_EAlt: {
    V v_p_24341 = heff_field(v_e0_241, 0);
    V v_arrow_24342 = heff_field(v_e0_241, 1);
    V v_body_24343 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24344 = ({ V a_0 = v_env_240; V a_1 = v_p_24341; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24341); r_; });
    V v_b_24345 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24342));
    V v_t_24346 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24345));
    V v_t_24347 = (g_std_2edoc_2e_3c_3e(v_a_24344, v_t_24346));
    V v_t_24348 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24343}));
    return (g_std_2edoc_2e_3c_3e(v_t_24347, v_t_24348));
  }
  case TAG_If: {
    V v_kw_24349 = heff_field(v_e0_241, 0);
    V v_c_24350 = heff_field(v_e0_241, 1);
    V v_th_24351 = heff_field(v_e0_241, 2);
    V v_a_24352 = heff_field(v_e0_241, 3);
    V v_el_24353 = heff_field(v_e0_241, 4);
    V v_b_24354 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24355 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24349, v_c_24350, v_th_24351, v_a_24352}));
    V v_t_24356 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24353, v_b_24354}));
    V v_t_24357 = (g_std_2edoc_2e_3c_3e(v_t_24355, v_t_24356));
    return (g_std_2edoc_2egroup(v_t_24357));
  }
  case TAG_Do: {
    V v_kw_24358 = heff_field(v_e0_241, 0);
    V v_stmts_24359 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Do = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_t_24360 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24358));
    V v_t_24361 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24359; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop(v_stmts_24359); r_; });
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24Do, v_t_24360, v_t_24361));
  }
  case TAG_ESBind: {
    V v_x_24362 = heff_field(v_e0_241, 0);
    V v_arrow_24363 = heff_field(v_e0_241, 1);
    V v_e_24364 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24365 = ({ V a_0 = v_env_240; V a_1 = v_x_24362; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24362); r_; });
    V v_b_24366 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24363));
    V v_t_24367 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24366));
    V v_t_24368 = (g_std_2edoc_2e_3c_3e(v_a_24365, v_t_24367));
    V v_t_24369 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24364}));
    return (g_std_2edoc_2e_3c_3e(v_t_24368, v_t_24369));
  }
  case TAG_ELet: {
    V v_kw_24370 = heff_field(v_e0_241, 0);
    V v_p_24371 = heff_field(v_e0_241, 1);
    V v_ann_24372 = heff_field(v_e0_241, 2);
    V v_eq_24373 = heff_field(v_e0_241, 3);
    V v_e_24374 = heff_field(v_e0_241, 4);
    V v_body_24375 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24375)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24370, v_p_24371, v_ann_24372, v_eq_24373, v_e_24374});
    }
    case TAG_Just: {
      V v_it1_24376 = heff_field(v_body_24375, 0);
      V v_ru_24body_24375_24Just = heff_take_reuse_n(v_body_24375, 1ULL, 1);
      switch (heff_tag_of(v_it1_24376)) {
      case TAG_MkPair: {
        V v_i_24377 = heff_field(v_it1_24376, 0);
        V v_b_24378 = heff_field(v_it1_24376, 1);
        V v_ru_24it1_24376_24MkPair = heff_take_reuse_n(v_it1_24376, 3ULL, 2);
        V v_t_24379 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24370, v_p_24371, v_ann_24372, v_eq_24373, v_e_24374, v_i_24377, v_b_24378}));
        V v_d_24380 = (g_std_2edoc_2egroup_24tok2(v_ru_24it1_24376_24MkPair, v_t_24379));
        return heff_tag_at_n(v_ru_24body_24375_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24380})});
      }
      default: return heff_nomatch(v_it1_24376);
      }
    }
    default: return heff_nomatch(v_body_24375);
    }
  }
  case TAG_ELetElse: {
    V v_kw_24384 = heff_field(v_e0_241, 0);
    V v_p_24385 = heff_field(v_e0_241, 1);
    V v_ann_24386 = heff_field(v_e0_241, 2);
    V v_eq_24387 = heff_field(v_e0_241, 3);
    V v_e_24388 = heff_field(v_e0_241, 4);
    V v_el_24389 = heff_field(v_e0_241, 5);
    V v_ss_24390 = heff_field(v_e0_241, 6);
    heff_take_n(v_e0_241, 127ULL, 7);
    V v_a_24391 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_240), v_kw_24384, v_p_24385, v_ann_24386, v_eq_24387, v_e_24388}));
    V v_b_24392 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_el_24389));
    V v_t_24393 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24392));
    V v_t_24394 = (g_std_2edoc_2e_3c_3e(v_a_24391, v_t_24393));
    V v_t_24402;
    switch (heff_tag_of(v_ss_24390)) {
    case TAG_Nil: {
      v_t_24402 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24390; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); r_; });
      break;
    }
    case TAG_Cons: {
      V v_s1_24395 = heff_dup(heff_field(v_ss_24390, 0));
      V v_it2_24396 = heff_dup(heff_field(v_ss_24390, 1));
      switch (heff_tag_of(v_it2_24396)) {
      case TAG_Nil: {
        V v_t_24397 = (g_heff_2esyntax_2ecst_2efirstE(v_s1_24395));
        V v_t_24398 = heff_get_n(v_t_24397, 6, 9);
        if ((heff_dup(v_t_24398) == NTAG(TAG_True))) {
          heff_drop(v_s1_24395);
          heff_drop(v_t_24398);
          v_t_24402 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24390; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop_tag(v_ss_24390, 2); r_; });
        } else {
          heff_drop_tag(v_ss_24390, 2);
          heff_drop(v_t_24398);
          V v_t_24399 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_s1_24395}));
          v_t_24402 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24399));
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it2_24396, 0ULL, 2);
        heff_drop(v_s1_24395);
        v_t_24402 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24390; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop_tag(v_ss_24390, 2); r_; });
        break;
      }
      default: heff_nomatch(v_it2_24396);
      }
      break;
    }
    default: heff_nomatch(v_ss_24390);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_24394, v_t_24402));
  }
  case TAG_ELetMut: {
    V v_kw_24403 = heff_field(v_e0_241, 0);
    V v_m_24404 = heff_field(v_e0_241, 1);
    V v_x_24405 = heff_field(v_e0_241, 2);
    V v_ann_24406 = heff_field(v_e0_241, 3);
    V v_eq_24407 = heff_field(v_e0_241, 4);
    V v_e_24408 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24409 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24403));
    V v_a_24410 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24404));
    V v_b_24411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24405));
    V v_t_24412 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24411));
    V v_t_24413 = (g_std_2edoc_2e_3c_3e(v_a_24410, v_t_24412));
    V v_t_24414 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24413));
    V v_t_24415 = (g_std_2edoc_2e_3c_3e(v_a_24409, v_t_24414));
    V v_a_24423;
    switch (heff_tag_of(v_ann_24406)) {
    case TAG_Nothing: {
      v_a_24423 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24416 = heff_field(v_ann_24406, 0);
      V v_ru_24ann_24406_24Just = heff_take_reuse_n(v_ann_24406, 1ULL, 1);
      switch (heff_tag_of(v_it1_24416)) {
      case TAG_MkPair: {
        V v_cc_24417 = heff_field(v_it1_24416, 0);
        V v_ty_24418 = heff_field(v_it1_24416, 1);
        V v_ru_24it1_24416_24MkPair = heff_take_reuse_n(v_it1_24416, 3ULL, 2);
        V v_a_24419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24417));
        V v_b_24420 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24418}));
        V v_t_24421 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24it1_24416_24MkPair, heff_tag_at_n(v_ru_24ann_24406_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24420));
        V v_t_24422 = (g_std_2edoc_2e_3c_3e(v_a_24419, v_t_24421));
        v_a_24423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_t_24422));
        break;
      }
      default: heff_nomatch(v_it1_24416);
      }
      break;
    }
    default: heff_nomatch(v_ann_24406);
    }
    V v_b_24424 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24407));
    V v_t_24425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24424));
    V v_t_24426 = (g_std_2edoc_2e_3c_3e(v_a_24423, v_t_24425));
    V v_t_24427 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24408}));
    V v_t_24428 = (g_std_2edoc_2e_3c_3e(v_t_24426, v_t_24427));
    return (g_std_2edoc_2e_3c_3e(v_t_24415, v_t_24428));
  }
  case TAG_EAssign: {
    V v_x_24429 = heff_field(v_e0_241, 0);
    V v_k_24430 = heff_field(v_e0_241, 1);
    V v_e_24431 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24432 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24429));
    V v_b_24433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24430));
    V v_t_24434 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_b_24433));
    V v_t_24435 = (g_std_2edoc_2e_3c_3e(v_a_24432, v_t_24434));
    V v_t_24436 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24431}));
    return (g_std_2edoc_2e_3c_3e(v_t_24435, v_t_24436));
  }
  case TAG_EWhile: {
    V v_kw_24437 = heff_field(v_e0_241, 0);
    V v_c_24438 = heff_field(v_e0_241, 1);
    V v_d_24439 = heff_field(v_e0_241, 2);
    V v_body_24440 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24441 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24437));
    V v_d_24442 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24438}));
    V v_b_24443 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24439));
    V v_t_24444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24443));
    V v_t_24448 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24442})}), v_t_24444));
    V v_t_24449 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24448));
    V v_t_24450 = (g_std_2edoc_2e_3c_3e(v_a_24441, v_t_24449));
    V v_t_24451 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24440; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop(v_body_24440); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24450, v_t_24451));
  }
  case TAG_EFor: {
    V v_kw_24452 = heff_field(v_e0_241, 0);
    V v_p_24453 = heff_field(v_e0_241, 1);
    V v_i_24454 = heff_field(v_e0_241, 2);
    V v_c_24455 = heff_field(v_e0_241, 3);
    V v_d_24456 = heff_field(v_e0_241, 4);
    V v_body_24457 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24458 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24452));
    V v_a_24459 = ({ V a_0 = v_env_240; V a_1 = v_p_24453; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24453); r_; });
    V v_a_24460 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_i_24454));
    V v_d_24461 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24455}));
    V v_b_24462 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24456));
    V v_t_24463 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_b_24462));
    V v_t_24467 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24461})}), v_t_24463));
    V v_t_24468 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24467));
    V v_t_24469 = (g_std_2edoc_2e_3c_3e(v_a_24460, v_t_24468));
    V v_t_24470 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), v_t_24469));
    V v_t_24471 = (g_std_2edoc_2e_3c_3e(v_a_24459, v_t_24470));
    V v_t_24472 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_t_24471));
    V v_t_24473 = (g_std_2edoc_2e_3c_3e(v_a_24458, v_t_24472));
    V v_t_24474 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop(v_body_24457); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24473, v_t_24474));
  }
  case TAG_EJump: {
    V v_kw_24475 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_241_24EJump, v_env_240, v_kw_24475));
  }
  case TAG_EReturn: {
    V v_kw_24476 = heff_field(v_e0_241, 0);
    V v_e_24477 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24478 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24476));
    V v_d_24479 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24477}));
    V v_t_24480 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24479})));
    return (g_std_2edoc_2e_3c_3e(v_a_24478, v_t_24480));
  }
  case TAG_ENest: {
    V v_o_24481 = heff_field(v_e0_241, 0);
    V v_arrow_24482 = heff_field(v_e0_241, 1);
    V v_e_24483 = heff_field(v_e0_241, 2);
    V v_c_24484 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24481));
    V v_a_24486 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24482));
    V v_b_24487 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24483}));
    V v_t_24488 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_b_24487));
    V v_t_24489 = (g_std_2edoc_2e_3c_3e(v_a_24486, v_t_24488));
    V v_t_24490 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24484));
    V v_t_24491 = (g_std_2edoc_2e_3c_3e(v_t_24489, v_t_24490));
    return (g_std_2edoc_2e_3c_3e(v_t_24485, v_t_24491));
  }
  case TAG_EArrow: {
    V v_arrow_24492 = heff_field(v_e0_241, 0);
    V v_e_24493 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EArrow = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24494 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24492));
    V v_b_24495 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24493}));
    V v_t_24496 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_241_24EArrow, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_b_24495));
    return (g_std_2edoc_2e_3c_3e(v_a_24494, v_t_24496));
  }
  case TAG_IfThen: {
    V v_kw_24497 = heff_field(v_e0_241, 0);
    V v_c_24498 = heff_field(v_e0_241, 1);
    V v_th_24499 = heff_field(v_e0_241, 2);
    V v_a_24500 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24501 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){v_env_240, v_kw_24497, v_c_24498, v_th_24499, v_a_24500}));
    return (g_std_2edoc_2egroup(v_t_24501));
  }
  case TAG_ETry: {
    V v_kw_24502 = heff_field(v_e0_241, 0);
    V v_ty_24503 = heff_field(v_e0_241, 1);
    V v_body_24504 = heff_field(v_e0_241, 2);
    V v_c_24505 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24506 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24502));
    V v_t_24509;
    switch (heff_tag_of(v_ty_24503)) {
    case TAG_Nothing: {
      v_t_24509 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_t_24507 = heff_field(v_ty_24503, 0);
      V v_ru_24ty_24503_24Just = heff_take_reuse_n(v_ty_24503, 1ULL, 1);
      V v_t_24508 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_t_24507}));
      v_t_24509 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ty_24503_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_t_24508));
      break;
    }
    default: heff_nomatch(v_ty_24503);
    }
    V v_d_24510 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24504; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop(v_body_24504); r_; });
    V v_t_24511 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_c_24505}));
    V v_t_24512 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24511));
    V v_t_24513 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24510}), v_t_24512));
    V v_t_24514 = (g_std_2edoc_2e_3c_3e(v_t_24509, v_t_24513));
    V v_d_24515 = (g_std_2edoc_2e_3c_3e(v_t_24506, v_t_24514));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){v_d_24515})});
  }
  case TAG_ECatch: {
    V v_kw_24519 = heff_field(v_e0_241, 0);
    V v_b_24520 = heff_field(v_e0_241, 1);
    V v_arrow_24521 = heff_field(v_e0_241, 2);
    V v_body_24522 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24523 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24519));
    V v_a_24524 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 2, (V[]){heff_dup(v_env_240), v_b_24520}));
    V v_b_24525 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24521));
    V v_t_24526 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_b_24525));
    V v_t_24527 = (g_std_2edoc_2e_3c_3e(v_a_24524, v_t_24526));
    V v_t_24528 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_t_24527));
    V v_t_24529 = (g_std_2edoc_2e_3c_3e(v_a_24523, v_t_24528));
    V v_d_24530 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24522; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop(v_body_24522); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24529, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24530})));
  }
  case TAG_EWith: {
    V v_kw_24531 = heff_field(v_e0_241, 0);
    V v_e_24532 = heff_field(v_e0_241, 1);
    V v_a_24533 = heff_field(v_e0_241, 2);
    V v_x_24534 = heff_field(v_e0_241, 3);
    V v_d_24535 = heff_field(v_e0_241, 4);
    V v_body_24536 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24537 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24531));
    V v_d_24538 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24532}));
    V v_a_24539 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_a_24533));
    V v_a_24540 = ({ V a_0 = v_env_240; V a_1 = v_x_24534; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24534); r_; });
    V v_b_24541 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24535));
    V v_t_24542 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_b_24541));
    V v_t_24543 = (g_std_2edoc_2e_3c_3e(v_a_24540, v_t_24542));
    V v_t_24544 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_t_24543));
    V v_t_24545 = (g_std_2edoc_2e_3c_3e(v_a_24539, v_t_24544));
    V v_t_24546 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_t_24545));
    V v_t_24550 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_d_24538})}), v_t_24546));
    V v_t_24551 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_t_24550));
    V v_t_24552 = (g_std_2edoc_2e_3c_3e(v_a_24537, v_t_24551));
    V v_d_24553 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24536; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop(v_body_24536); r_; });
    V v_d_24554 = (g_std_2edoc_2e_3c_3e(v_t_24552, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24553})));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){v_d_24554})});
  }
  case TAG_EWithBound: {
    V v_kw_24558 = heff_field(v_e0_241, 0);
    V v_bs_24559 = heff_field(v_e0_241, 1);
    V v_w_24560 = heff_field(v_e0_241, 2);
    V v_d_24561 = heff_field(v_e0_241, 3);
    V v_body_24562 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_a_24563 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24558));
    V v_d_24583;
    switch (heff_tag_of(v_bs_24559)) {
    case TAG_Nil: {
      heff_drop(v_w_24560);
      v_d_24583 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Cons: {
      V v_b1_24564 = heff_field(v_bs_24559, 0);
      V v_rest_24565 = heff_field(v_bs_24559, 1);
      V v_ru_24bs_24559_24Cons = heff_take_reuse_n(v_bs_24559, 3ULL, 2);
      V v_t_24566 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_b1_24564}));
      V v_t_24567 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1176994294x1772976451(v_env_240, MK_INT(1LL), v_rest_24565));
      V v_t_24581;
      switch (heff_tag_of(v_w_24560)) {
      case TAG_Nothing: {
        heff_drop(v_rest_24565);
        heff_drop_cell(v_ru_24bs_24559_24Cons, 2);
        v_t_24581 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Just: {
        V v_it1_24568 = heff_field(v_w_24560, 0);
        V v_ru_24w_24560_24Just = heff_take_reuse_n(v_w_24560, 1ULL, 1);
        switch (heff_tag_of(v_it1_24568)) {
        case TAG_MkPair: {
          V v_wk_24569 = heff_field(v_it1_24568, 0);
          V v_c_24570 = heff_field(v_it1_24568, 1);
          V v_ru_24it1_24568_24MkPair = heff_take_reuse_n(v_it1_24568, 3ULL, 2);
          V v_t_24573;
          switch (heff_tag_of(v_rest_24565)) {
          case TAG_Nil: {
            v_t_24573 = heff_tag_at_n(v_ru_24w_24560_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_rest_24565, 0ULL, 2);
            heff_drop_cell(v_ru_24w_24560_24Just, 1);
            v_t_24573 = heff_dup(g_std_2edoc_2ehardline_get());
            break;
          }
          default: heff_nomatch(v_rest_24565);
          }
          V v_a_24574 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_wk_24569));
          V v_d_24575 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24570}));
          V v_t_24579 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24bs_24559_24Cons, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){v_d_24575})})));
          V v_t_24580 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24it1_24568_24MkPair, v_a_24574, v_t_24579));
          v_t_24581 = (g_std_2edoc_2e_3c_3e(v_t_24573, v_t_24580));
          break;
        }
        default: heff_nomatch(v_it1_24568);
        }
        break;
      }
      default: heff_nomatch(v_w_24560);
      }
      V v_t_24582 = (g_std_2edoc_2e_3c_3e(v_t_24567, v_t_24581));
      v_d_24583 = (g_std_2edoc_2e_3c_3e(v_t_24566, v_t_24582));
      break;
    }
    default: heff_nomatch(v_bs_24559);
    }
    V v_t_24587 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_d_24583})})));
    V v_t_24588 = (g_std_2edoc_2e_3c_3e(v_a_24563, v_t_24587));
    V v_t_24589 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24561));
    V v_d_24590 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24562; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a_0, a_1, a_2)); heff_drop_rec(v_env_240, 7); heff_drop(v_body_24562); r_; });
    V v_t_24591 = (g_std_2edoc_2e_3c_3e(v_t_24589, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24590})));
    V v_t_24592 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_t_24591));
    V v_d_24593 = (g_std_2edoc_2e_3c_3e(v_t_24588, v_t_24592));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){v_d_24593})});
  }
  case TAG_EBinding: {
    V v_x_24597 = heff_field(v_e0_241, 0);
    V v_k_24598 = heff_field(v_e0_241, 1);
    V v_e_24599 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24600 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24597));
    V v_b_24601 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24598));
    V v_t_24602 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24601));
    V v_t_24603 = (g_std_2edoc_2e_3c_3e(v_a_24600, v_t_24602));
    V v_t_24604 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24599}));
    V v_d_24605 = (g_std_2edoc_2e_3c_3e(v_t_24603, v_t_24604));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24605});
  }
  case TAG_EBindingP: {
    V v_p_24606 = heff_field(v_e0_241, 0);
    V v_k_24607 = heff_field(v_e0_241, 1);
    V v_e_24608 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24609 = ({ V a_0 = v_env_240; V a_1 = v_p_24606; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24606); r_; });
    V v_b_24610 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24607));
    V v_t_24611 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), v_b_24610));
    V v_t_24612 = (g_std_2edoc_2e_3c_3e(v_a_24609, v_t_24611));
    V v_t_24613 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24608}));
    V v_d_24614 = (g_std_2edoc_2e_3c_3e(v_t_24612, v_t_24613));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24614});
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_env_24615 = args[0];
  V v_e_24616 = args[1];
  V v_t_24617 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24616));
  if ((heff_dup(v_t_24617) == NTAG(TAG_True))) {
    heff_drop(v_t_24617);
    V v_t_24618 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24615, v_e_24616}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), v_t_24618));
  } else {
    heff_drop(v_t_24617);
    V v_t_24619 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 2, (V[]){v_env_24615, v_e_24616}));
    V v_t_24620 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24619));
    return (g_std_2edoc_2egroup(v_t_24620));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_env_24621 = args[0];
  V v_kw_24622 = args[1];
  V v_p_24623 = args[2];
  V v_ann_24624 = args[3];
  V v_eq_24625 = args[4];
  V v_e_24626 = args[5];
  V v_a_24627 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24621), v_kw_24622));
  V v_b_24628 = ({ V a_0 = v_env_24621; V a_1 = v_p_24623; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24623); r_; });
  V v_t_24629 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), v_b_24628));
  V v_t_24630 = (g_std_2edoc_2e_3c_3e(v_a_24627, v_t_24629));
  V v_a_24638;
  switch (heff_tag_of(v_ann_24624)) {
  case TAG_Nothing: {
    v_a_24638 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24631 = heff_field(v_ann_24624, 0);
    V v_ru_24ann_24624_24Just = heff_take_reuse_n(v_ann_24624, 1ULL, 1);
    switch (heff_tag_of(v_it1_24631)) {
    case TAG_MkPair: {
      V v_cc_24632 = heff_field(v_it1_24631, 0);
      V v_ty_24633 = heff_field(v_it1_24631, 1);
      V v_ru_24it1_24631_24MkPair = heff_take_reuse_n(v_it1_24631, 3ULL, 2);
      V v_a_24634 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24621), v_cc_24632));
      V v_b_24635 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24621), v_ty_24633}));
      V v_t_24636 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24it1_24631_24MkPair, heff_tag_at_n(v_ru_24ann_24624_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), v_b_24635));
      V v_t_24637 = (g_std_2edoc_2e_3c_3e(v_a_24634, v_t_24636));
      v_a_24638 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), v_t_24637));
      break;
    }
    default: heff_nomatch(v_it1_24631);
    }
    break;
  }
  default: heff_nomatch(v_ann_24624);
  }
  V v_b_24639 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24621), v_eq_24625));
  V v_t_24640 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), v_b_24639));
  V v_t_24641 = (g_std_2edoc_2e_3c_3e(v_a_24638, v_t_24640));
  V v_t_24642 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24621, v_e_24626}));
  V v_t_24643 = (g_std_2edoc_2e_3c_3e(v_t_24641, v_t_24642));
  return (g_std_2edoc_2e_3c_3e(v_t_24630, v_t_24643));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_env_24644 = args[0];
  V v_kw_24645 = args[1];
  V v_p_24646 = args[2];
  V v_ann_24647 = args[3];
  V v_eq_24648 = args[4];
  V v_e_24649 = args[5];
  V v_i_24650 = args[6];
  V v_b_24651 = args[7];
  V v_d_24652 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24644), v_kw_24645, v_p_24646, v_ann_24647, v_eq_24648, v_e_24649}));
  V v_t_24653 = heff_dup(heff_rfield(v_i_24650, 6));
  V v_t_24656;
  if ((heff_dup(v_t_24653) == NTAG(TAG_True))) {
    heff_drop(v_t_24653);
    v_t_24656 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24653);
    V v_t_24654 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24651));
    V v_x1_24655 = heff_get_n(v_t_24654, 6, 9);
    if ((heff_dup(v_x1_24655) == NTAG(TAG_True))) {
      heff_drop(v_x1_24655);
      v_t_24656 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24655);
      v_t_24656 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24657 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24644), v_i_24650));
  V v_b_24673;
  switch (heff_tag_of(v_b_24651)) {
  case TAG_ELet: {
    V v_it6_24663 = heff_dup(heff_field(v_b_24651, 5));
    switch (heff_tag_of(v_it6_24663)) {
    case TAG_Nothing: {
      v_b_24673 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24644, v_b_24651}));
      break;
    }
    case TAG_Just: {
      V v_it61_24664 = heff_field(v_it6_24663, 0);
      heff_take_n(v_it6_24663, 1ULL, 1);
      switch (heff_tag_of(v_b_24651)) {
      case TAG_ELet: {
        V v_kw2_24665 = heff_field(v_b_24651, 0);
        V v_p2_24666 = heff_field(v_b_24651, 1);
        V v_ann2_24667 = heff_field(v_b_24651, 2);
        V v_eq2_24668 = heff_field(v_b_24651, 3);
        V v_e2_24669 = heff_field(v_b_24651, 4);
        heff_take_n(v_b_24651, 31ULL, 6);
        switch (heff_tag_of(v_it61_24664)) {
        case TAG_MkPair: {
          V v_i2_24671 = heff_field(v_it61_24664, 0);
          V v_b2_24672 = heff_field(v_it61_24664, 1);
          heff_take_n(v_it61_24664, 3ULL, 2);
          v_b_24673 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24644, v_kw2_24665, v_p2_24666, v_ann2_24667, v_eq2_24668, v_e2_24669, v_i2_24671, v_b2_24672}));
          break;
        }
        default: heff_nomatch(v_it61_24664);
        }
        break;
      }
      default: heff_nomatch(v_b_24651);
      }
      break;
    }
    default: heff_nomatch(v_it6_24663);
    }
    break;
  }
  default: {
    v_b_24673 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24644, v_b_24651}));
    break;
  }
  }
  V v_t_24674 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), v_b_24673));
  V v_t_24675 = (g_std_2edoc_2e_3c_3e(v_a_24657, v_t_24674));
  V v_t_24676 = (g_std_2edoc_2e_3c_3e(v_t_24656, v_t_24675));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24652}), v_t_24676));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_i_24685 = args[0];
  V v_k_24684 = heff_env(self)[0];
  V v_d_24683 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24686 = heff_intSub(v_k_24684, v_i_24685);
  if (heff_intEq_c_lent(v_i_24686, MK_INT(0LL), 2)) {
    heff_drop(v_i_24686);
    return v_d_24683;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24686, v_d_24683});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_k_24684 = args[0];
  V v_d_24683 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 2, (V[]){v_k_24684, v_d_24683})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_env_24677 = args[0];
  V v_kw_24678 = args[1];
  V v_c_24679 = args[2];
  V v_th_24680 = args[3];
  V v_a_24681 = args[4];
  V v_a_24682 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24677), v_kw_24678));
  V v_d_24683 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24677), v_c_24679}));
  V v_t_24687 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_d_24683})})));
  V v_t_24688 = (g_std_2edoc_2e_3c_3e(v_a_24682, v_t_24687));
  V v_t_24689 = heff_dup(heff_rfield(v_th_24680, 6));
  V v_t_24692;
  if ((heff_dup(v_t_24689) == NTAG(TAG_True))) {
    heff_drop(v_t_24689);
    v_t_24692 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24689);
    V v_t_24690 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24681));
    V v_x1_24691 = heff_get_n(v_t_24690, 6, 9);
    if ((heff_dup(v_x1_24691) == NTAG(TAG_True))) {
      heff_drop(v_x1_24691);
      v_t_24692 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24691);
      v_t_24692 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24693 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24677), v_th_24680));
  V v_d_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24677, v_a_24681}));
  V v_t_24695 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24694})));
  V v_t_24696 = (g_std_2edoc_2e_3c_3e(v_a_24693, v_t_24695));
  V v_t_24697 = (g_std_2edoc_2e_3c_3e(v_t_24692, v_t_24696));
  V v_t_24698 = (g_std_2edoc_2e_3c_3e(v_t_24688, v_t_24697));
  return (g_std_2edoc_2egroup(v_t_24698));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_env_24699 = args[0];
  V v_el_24700 = args[1];
  V v_b_24701 = args[2];
  switch (heff_tag_of(v_b_24701)) {
  case TAG_If: {
    V v_kw_24702 = heff_dup(heff_field(v_b_24701, 0));
    V v_c_24703 = heff_dup(heff_field(v_b_24701, 1));
    V v_th_24704 = heff_dup(heff_field(v_b_24701, 2));
    V v_a_24705 = heff_dup(heff_field(v_b_24701, 3));
    V v_el2_24706 = heff_dup(heff_field(v_b_24701, 4));
    V v_b2_24707 = heff_dup(heff_field(v_b_24701, 5));
    V v_t_24708 = heff_dup(heff_rfield(v_el_24700, 6));
    V v_t_24711;
    if ((heff_dup(v_t_24708) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24701, 6);
      heff_drop(v_t_24708);
      v_t_24711 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24708);
      V v_t_24709 = ({ V a_0 = v_b_24701; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24701, 6); r_; });
      V v_x1_24710 = heff_get_n(v_t_24709, 6, 9);
      if ((heff_dup(v_x1_24710) == NTAG(TAG_True))) {
        heff_drop(v_x1_24710);
        v_t_24711 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24710);
        v_t_24711 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24712 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24699), v_el_24700));
    V v_b_24713 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24699), v_kw_24702, v_c_24703, v_th_24704, v_a_24705}));
    V v_t_24714 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), v_b_24713));
    V v_t_24715 = (g_std_2edoc_2e_3c_3e(v_a_24712, v_t_24714));
    V v_t_24716 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24699, v_el2_24706, v_b2_24707}));
    V v_t_24717 = (g_std_2edoc_2e_3c_3e(v_t_24715, v_t_24716));
    return (g_std_2edoc_2e_3c_3e(v_t_24711, v_t_24717));
  }
  default: {
    V v_t_24718 = heff_dup(heff_rfield(v_el_24700, 6));
    V v_t_24721;
    if ((heff_dup(v_t_24718) == NTAG(TAG_True))) {
      heff_drop(v_t_24718);
      v_t_24721 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24718);
      V v_t_24719 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24701));
      V v_x1_24720 = heff_get_n(v_t_24719, 6, 9);
      if ((heff_dup(v_x1_24720) == NTAG(TAG_True))) {
        heff_drop(v_x1_24720);
        v_t_24721 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24720);
        v_t_24721 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24722 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24699), v_el_24700));
    V v_d_24723 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24699, v_b_24701}));
    V v_t_24724 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24723})));
    V v_t_24725 = (g_std_2edoc_2e_3c_3e(v_a_24722, v_t_24724));
    return (g_std_2edoc_2e_3c_3e(v_t_24721, v_t_24725));
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_24747 = args[0];
  V v_one_24746 = heff_env(self)[0];
  V v_t_24748 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24747));
  V v_x1_24749 = heff_get_n(v_t_24748, 6, 9);
  V v_t_24750;
  if ((heff_dup(v_x1_24749) == NTAG(TAG_True))) {
    heff_drop(v_x1_24749);
    v_t_24750 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24749);
    v_t_24750 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_24751 = heff_tr(heff_call(v_one_24746, 1, (V[]){v_a_24747}));
  return (g_std_2edoc_2e_3c_3e(v_t_24750, v_t_24751));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_24760 = args[0];
  V v_one_24759 = heff_env(self)[0];
  V v_t_24761 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24760));
  V v_x1_24762 = heff_get_n(v_t_24761, 6, 9);
  V v_t_24763;
  if ((heff_dup(v_x1_24762) == NTAG(TAG_True))) {
    heff_drop(v_x1_24762);
    v_t_24763 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24762);
    v_t_24763 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_24764 = heff_tr(heff_call(v_one_24759, 1, (V[]){v_a_24760}));
  return (g_std_2edoc_2e_3c_3e(v_t_24763, v_t_24764));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_env_24726 = args[0];
  V v_hang_24727 = args[1];
  V v_h_24728 = args[2];
  V v_args_24729 = args[3];
  V v_x1_24730 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_24729)));
  switch (heff_tag_of(v_x1_24730)) {
  case TAG_Nil: {
    heff_drop(v_hang_24727);
    heff_drop(v_args_24729);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24726;
    args[1] = v_h_24728;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_x_24731 = heff_field(v_x1_24730, 0);
    V v_rev_24732 = heff_field(v_x1_24730, 1);
    V v_ru_24x1_24730_24Cons = heff_take_reuse_n(v_x1_24730, 3ULL, 2);
    V v_init2_24733 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24732));
    switch (heff_tag_of(v_x_24731)) {
    case TAG_EParen: {
      V v_o_24734 = heff_field(v_x_24731, 0);
      V v_e_24735 = heff_field(v_x_24731, 1);
      V v_c_24736 = heff_field(v_x_24731, 2);
      heff_take_n(v_x_24731, 7ULL, 3);
      V v_t_24737 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_24735));
      if ((heff_dup(v_t_24737) == NTAG(TAG_True))) {
        heff_drop(v_args_24729);
        heff_drop(v_t_24737);
        V v_t_24738 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24726), v_h_24728}));
        V v_t_24739 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24726)}));
        V v_t_24740 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24726), v_o_24734));
        V v_t_24741 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24726), v_e_24735}));
        V v_t_24742 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24726, v_c_24736));
        V v_t_24743 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x1_24730_24Cons, v_t_24741, v_t_24742));
        V v_t_24744 = (g_std_2edoc_2e_3c_3e(v_t_24740, v_t_24743));
        return (g_heff_2esyntax_2efmt_2elayout_2eblockLast(v_hang_24727, v_t_24738, v_t_24739, v_init2_24733, v_t_24744));
      } else {
        heff_drop(v_hang_24727);
        heff_drop(v_init2_24733);
        heff_drop(v_o_24734);
        heff_drop(v_e_24735);
        heff_drop(v_c_24736);
        heff_drop(v_t_24737);
        V v_t_24745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24726), v_h_24728}));
        V v_one_24746 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24726}));
        V v_d_24752 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_24746}); V a_2 = v_args_24729; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_args_24729); r_; });
        V v_t_24753 = (g_std_2edoc_2e_3c_3e(v_t_24745, heff_tag_at_n(v_ru_24x1_24730_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24752})));
        return (g_std_2edoc_2egroup(v_t_24753));
      }
    }
    default: {
      V v_t_24754 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_24731));
      if ((heff_dup(v_t_24754) == NTAG(TAG_True))) {
        heff_drop(v_args_24729);
        heff_drop_cell(v_ru_24x1_24730_24Cons, 2);
        heff_drop(v_t_24754);
        V v_t_24755 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24726), v_h_24728}));
        V v_t_24756 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24726)}));
        V v_t_24757 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24726, v_x_24731}));
        return (g_heff_2esyntax_2efmt_2elayout_2eblockLast(v_hang_24727, v_t_24755, v_t_24756, v_init2_24733, v_t_24757));
      } else {
        heff_drop(v_hang_24727);
        heff_drop(v_x_24731);
        heff_drop(v_init2_24733);
        heff_drop(v_t_24754);
        V v_t_24758 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24726), v_h_24728}));
        V v_one_24759 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24726}));
        V v_d_24765 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_24759}); V a_2 = v_args_24729; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_args_24729); r_; });
        V v_t_24766 = (g_std_2edoc_2e_3c_3e(v_t_24758, heff_tag_at_n(v_ru_24x1_24730_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24765})));
        return (g_std_2edoc_2egroup(v_t_24766));
      }
    }
    }
  }
  default: return heff_nomatch(v_x1_24730);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_env_24767 = args[0];
  V v_e_24768 = args[1];
  switch (heff_tag_of(v_e_24768)) {
  case TAG_App: {
    V v_h_24769 = heff_dup(heff_field(v_e_24768, 0));
    V v_args_24770 = heff_dup(heff_field(v_e_24768, 1));
    V v_t_24771 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_24768));
    if ((heff_dup(v_t_24771) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_24768, 2);
      heff_drop(v_t_24771);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
      heff_room[0] = v_env_24767;
      heff_room[1] = MK_INT(2LL);
      heff_room[2] = v_h_24769;
      heff_room[3] = v_args_24770;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    } else {
      heff_drop(v_h_24769);
      heff_drop(v_args_24770);
      heff_drop(v_t_24771);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_24767;
      args[1] = v_e_24768;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24767;
    args[1] = v_e_24768;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_env_24772 = args[0];
  V v_rest_24773 = args[1];
  V v_e_24774 = args[2];
  switch (heff_tag_of(v_e_24774)) {
  case TAG_Braces: {
    V v_o_24775 = heff_field(v_e_24774, 0);
    V v_fs_24776 = heff_field(v_e_24774, 1);
    V v_commas_24777 = heff_field(v_e_24774, 2);
    V v_c_24778 = heff_field(v_e_24774, 3);
    heff_take_n(v_e_24774, 15ULL, 4);
    switch (heff_tag_of(v_fs_24776)) {
    case TAG_Nil: {
      heff_drop(v_rest_24773);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_24772;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24775, v_fs_24776, v_commas_24777, v_c_24778});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_24779 = heff_dup(heff_field(v_fs_24776, 0));
      V v_rest2_24780 = heff_dup(heff_field(v_fs_24776, 1));
      switch (heff_tag_of(v_rest2_24780)) {
      case TAG_Nil: {
        V v_t_24781 = ({ V a_0 = v_rest_24773; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_24773); r_; });
        if ((heff_dup(v_t_24781) == NTAG(TAG_True))) {
          heff_drop(v_t_24781);
          V v_x1_24782 = heff_dup(v_d_24779);
          V v_x1_24950;
          switch (heff_tag_of(v_x1_24782)) {
          case TAG_Atom: {
            heff_take_n(v_x1_24782, 0ULL, 1);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EParen: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Named: {
            heff_take_n(v_x1_24782, 0ULL, 5);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Tup: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Seg: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Braces: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Update: {
            heff_take_n(v_x1_24782, 0ULL, 6);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EUSet: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_InstB: {
            heff_take_n(v_x1_24782, 0ULL, 5);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EFSet: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_True);
            break;
          }
          case TAG_EFDefault: {
            V v_eq_24821 = heff_field(v_x1_24782, 1);
            heff_take_n(v_x1_24782, 2ULL, 3);
            v_x1_24950 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_eq_24821, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)));
            heff_drop_rec(v_eq_24821, 9);
            break;
          }
          case TAG_Sum: {
            heff_take_n(v_x1_24782, 0ULL, 5);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ECon: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EField: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ENeg: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ETilde: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_App: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Op: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Ops: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_OpRhs: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Ann: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_BVar: {
            heff_take_n(v_x1_24782, 0ULL, 1);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_BImp: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_BAnn: {
            heff_take_n(v_x1_24782, 0ULL, 5);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_BPat: {
            heff_take_n(v_x1_24782, 0ULL, 1);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Lam: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Case: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EAlt: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_If: {
            heff_take_n(v_x1_24782, 0ULL, 6);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_Do: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ESBind: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_x1_24782, 0ULL, 6);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ELetElse: {
            heff_take_n(v_x1_24782, 0ULL, 7);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ELetMut: {
            heff_take_n(v_x1_24782, 0ULL, 6);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EAssign: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EWhile: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EFor: {
            heff_take_n(v_x1_24782, 0ULL, 6);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EJump: {
            heff_take_n(v_x1_24782, 0ULL, 1);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EReturn: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EArrow: {
            heff_take_n(v_x1_24782, 0ULL, 2);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_IfThen: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_ECatch: {
            heff_take_n(v_x1_24782, 0ULL, 4);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_x1_24782, 0ULL, 6);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EWithBound: {
            heff_take_n(v_x1_24782, 0ULL, 5);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EBinding: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          case TAG_EBindingP: {
            heff_take_n(v_x1_24782, 0ULL, 3);
            v_x1_24950 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x1_24782);
          }
          if (!(heff_dup(v_x1_24950) == NTAG(TAG_True))) {
            heff_drop(v_x1_24950);
            switch (heff_tag_of(v_commas_24777)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_24776, 2);
              V v_t_24951 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24772), v_o_24775));
              V v_t_24952 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24772), v_d_24779}));
              V v_t_24953 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24772, v_c_24778));
              V v_t_24954 = (g_std_2edoc_2e_3c_3e(v_t_24952, v_t_24953));
              return (g_std_2edoc_2e_3c_3e(v_t_24951, v_t_24954));
            }
            case TAG_Cons: {
              heff_drop(v_d_24779);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_24772;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24775, v_fs_24776, v_commas_24777, v_c_24778});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_24777);
            }
          } else {
            heff_drop(v_d_24779);
            heff_drop(v_x1_24950);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_24772;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24775, v_fs_24776, v_commas_24777, v_c_24778});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
        } else {
          heff_drop(v_d_24779);
          heff_drop(v_t_24781);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_24772;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24775, v_fs_24776, v_commas_24777, v_c_24778});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_24780, 0ULL, 2);
        heff_drop(v_rest_24773);
        heff_drop(v_d_24779);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_24772;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24775, v_fs_24776, v_commas_24777, v_c_24778});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_24780);
      }
    }
    default: return heff_nomatch(v_fs_24776);
    }
  }
  default: {
    heff_drop(v_rest_24773);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24772;
    args[1] = v_e_24774;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_env_24959 = args[0];
  V v_b_24960 = args[1];
  switch (heff_tag_of(v_b_24960)) {
  case TAG_BVar: {
    V v_t_24961 = heff_field(v_b_24960, 0);
    V v_ru_24b_24960_24BVar = heff_take_reuse_n(v_b_24960, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24b_24960_24BVar, v_env_24959, v_t_24961));
  }
  case TAG_BImp: {
    V v_o_24962 = heff_field(v_b_24960, 0);
    V v_x_24963 = heff_field(v_b_24960, 1);
    V v_c_24964 = heff_field(v_b_24960, 2);
    heff_take_n(v_b_24960, 7ULL, 3);
    V v_t_24965 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24959), v_o_24962));
    V v_t_24966 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24959), v_x_24963));
    V v_t_24967 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24959, v_c_24964));
    V v_t_24968 = (g_std_2edoc_2e_3c_3e(v_t_24966, v_t_24967));
    return (g_std_2edoc_2e_3c_3e(v_t_24965, v_t_24968));
  }
  case TAG_BAnn: {
    V v_o_24969 = heff_field(v_b_24960, 0);
    V v_x_24970 = heff_field(v_b_24960, 1);
    V v_cc_24971 = heff_field(v_b_24960, 2);
    V v_ty_24972 = heff_field(v_b_24960, 3);
    V v_c_24973 = heff_field(v_b_24960, 4);
    heff_take_n(v_b_24960, 31ULL, 5);
    V v_t_24974 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24959), v_o_24969));
    V v_a_24975 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24959), v_x_24970));
    V v_a_24976 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24959), v_cc_24971));
    V v_b_24977 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24959), v_ty_24972}));
    V v_t_24978 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), v_b_24977));
    V v_t_24979 = (g_std_2edoc_2e_3c_3e(v_a_24976, v_t_24978));
    V v_t_24980 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), v_t_24979));
    V v_t_24981 = (g_std_2edoc_2e_3c_3e(v_a_24975, v_t_24980));
    V v_t_24982 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24959, v_c_24973));
    V v_t_24983 = (g_std_2edoc_2e_3c_3e(v_t_24981, v_t_24982));
    return (g_std_2edoc_2e_3c_3e(v_t_24974, v_t_24983));
  }
  case TAG_BPat: {
    V v_p_24984 = heff_field(v_b_24960, 0);
    heff_take_n(v_b_24960, 1ULL, 1);
    return ({ V a_0 = v_env_24959; V a_1 = v_p_24984; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_env_24959); heff_drop(v_p_24984); r_; });
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24959;
    args[1] = v_b_24960;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_env_24985 = args[0];
  V v_rest_24986 = args[1];
  V v_r_24987 = args[2];
  switch (heff_tag_of(v_r_24987)) {
  case TAG_OpRhs: {
    V v_op_24988 = heff_field(v_r_24987, 0);
    V v_e_24989 = heff_field(v_r_24987, 1);
    V v_ru_24r_24987_24OpRhs = heff_take_reuse_n(v_r_24987, 3ULL, 2);
    V v_a_24990 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24985), v_op_24988));
    V v_b_24991 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 3, (V[]){v_env_24985, v_rest_24986, v_e_24989}));
    V v_t_24992 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24r_24987_24OpRhs, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), v_b_24991));
    return (g_std_2edoc_2e_3c_3e(v_a_24990, v_t_24992));
  }
  default: {
    heff_drop(v_rest_24986);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24985;
    args[1] = v_r_24987;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_env_24993 = args[0];
  V v_r_24994 = args[1];
  switch (heff_tag_of(v_r_24994)) {
  case TAG_OpRhs: {
    V v_op_24995 = heff_field(v_r_24994, 0);
    V v_e_24996 = heff_field(v_r_24994, 1);
    V v_ru_24r_24994_24OpRhs = heff_take_reuse_n(v_r_24994, 3ULL, 2);
    V v_a_24997 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24993), v_op_24995));
    V v_b_24998 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24993, v_e_24996}));
    V v_t_24999 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24r_24994_24OpRhs, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), v_b_24998));
    return (g_std_2edoc_2e_3c_3e(v_a_24997, v_t_24999));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24993;
    args[1] = v_r_24994;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_r_241012 = args[0];
  V v_env_241000 = heff_env(self)[0];
  V v_x1_241013 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_241012));
  V v_t_241014;
  if ((heff_dup(v_x1_241013) == NTAG(TAG_True))) {
    heff_drop(v_x1_241013);
    v_t_241014 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241013);
    v_t_241014 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_241015 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 2, (V[]){v_env_241000, v_r_241012}));
  return (g_std_2edoc_2e_3c_3e(v_t_241014, v_t_241015));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_r_241021 = args[0];
  V v_env_241000 = heff_env(self)[0];
  V v_x1_241022 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_241021));
  V v_t_241023;
  if ((heff_dup(v_x1_241022) == NTAG(TAG_True))) {
    heff_drop(v_x1_241022);
    v_t_241023 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241022);
    v_t_241023 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_241024 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 2, (V[]){v_env_241000, v_r_241021}));
  return (g_std_2edoc_2e_3c_3e(v_t_241023, v_t_241024));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_env_241000 = args[0];
  V v_first_241001 = args[1];
  V v_rest_241002 = args[2];
  V v_f_241003 = heff_dup(heff_rfield(v_env_241000, 6));
  HeffT2 v_t_241004 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(v_f_241003, heff_dup(v_rest_241002)));
  {
    V v_field_241006 = v_t_241004.f[1];
    int64_t v_tag_241005 = ((int64_t)v_t_241004.f[0]);
    V v_t_241010;
    if ((v_tag_241005 == ((int64_t)0ULL))) {
      V v_it1_241007 = v_field_241006;
      switch (heff_tag_of(v_it1_241007)) {
      case TAG_Nil: {
        heff_drop(v_f_241003);
        v_t_241010 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_241008 = heff_field(v_it1_241007, 0);
        V v_os_241009 = heff_field(v_it1_241007, 1);
        heff_take_n(v_it1_241007, 3ULL, 2);
        v_t_241010 = ({ V a_0 = v_f_241003; V a_1 = v_o_241008; V a_2 = v_os_241009; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_f_241003); heff_drop(v_o_241008); heff_drop(v_os_241009); r_; });
        break;
      }
      default: heff_nomatch(v_it1_241007);
      }
    } else {
      heff_drop(v_f_241003);
      heff_drop(v_field_241006);
      v_t_241010 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_241010)) {
    case TAG_Nothing: {
      V v_t_241011 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241000), v_first_241001}));
      V v_t_241016 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_env_241000}); V a_2 = v_rest_241002; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_rest_241002); r_; });
      V v_t_241017 = (g_std_2edoc_2e_3c_3e(v_t_241011, v_t_241016));
      return (g_std_2edoc_2egroup(v_t_241017));
    }
    case TAG_Just: {
      V v_m_241018 = heff_field(v_t_241010, 0);
      heff_take_n(v_t_241010, 1ULL, 1);
      V v_t_241019 = (g_list_2eall_24s78096928x1476871221(heff_rfield(v_env_241000, 6), v_m_241018, v_rest_241002));
      if ((heff_dup(v_t_241019) == NTAG(TAG_True))) {
        heff_drop(v_m_241018);
        heff_drop(v_t_241019);
        V v_t_241020 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241000), v_first_241001}));
        V v_t_241025 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_env_241000}); V a_2 = v_rest_241002; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_rest_241002); r_; });
        V v_t_241026 = (g_std_2edoc_2e_3c_3e(v_t_241020, v_t_241025));
        return (g_std_2edoc_2egroup(v_t_241026));
      } else {
        heff_drop(v_t_241019);
        V v_t_241027 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13)), 5, (V[]){v_env_241000, v_m_241018, v_first_241001, NTAG(TAG_Nil), v_rest_241002}));
        return (g_std_2edoc_2egroup(v_t_241027));
      }
    }
    default: return heff_nomatch(v_t_241010);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_env_241028 = args[0];
  V v_m_241029 = args[1];
  V v_f_241030 = args[2];
  V v_acc_241031 = args[3];
  V v_rs_241032 = args[4];
  switch (heff_tag_of(v_rs_241032)) {
  case TAG_Nil: {
    heff_drop(v_m_241029);
    V v_t_241033 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241031));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
    args[0] = v_env_241028;
    args[1] = v_f_241030;
    args[2] = v_t_241033;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_241034 = heff_field(v_rs_241032, 0);
    V v_rest2_241035 = heff_field(v_rs_241032, 1);
    V v_ru_24rs_241032_24Cons = heff_take_reuse_n(v_rs_241032, 3ULL, 2);
    switch (heff_tag_of(v_r_241034)) {
    case TAG_OpRhs: {
      V v_op_241036 = heff_dup(heff_field(v_r_241034, 0));
      V v_e_241037 = heff_dup(heff_field(v_r_241034, 1));
      V v_t_241038 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_241028, 6)), heff_dup(v_m_241029), heff_dup(heff_rfield(v_op_241036, 1))));
      switch (heff_tag_of(v_t_241038)) {
      case TAG_Tighter: {
        heff_drop_cell(v_ru_24rs_241032_24Cons, 2);
        heff_drop_rec(v_op_241036, 9);
        heff_drop(v_e_241037);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
        args[0] = v_env_241028;
        args[1] = v_m_241029;
        args[2] = v_f_241030;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241034, v_acc_241031});
        args[4] = v_rest2_241035;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Looser: {
        heff_drop_cell(v_ru_24rs_241032_24Cons, 2);
        heff_drop_rec(v_op_241036, 9);
        heff_drop(v_e_241037);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
        args[0] = v_env_241028;
        args[1] = v_m_241029;
        args[2] = v_f_241030;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241034, v_acc_241031});
        args[4] = v_rest2_241035;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Same: {
        V v_ru_24t_241038_24Same = heff_take_reuse_n(v_t_241038, 0ULL, 1);
        V v_t_241040 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241031));
        V v_t_241041 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 3, (V[]){heff_dup(v_env_241028), v_f_241030, v_t_241040}));
        V v_x1_241042 = ({ V a_0 = v_r_241034; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_241034, 2); r_; });
        V v_t_241043;
        if ((heff_dup(v_x1_241042) == NTAG(TAG_True))) {
          heff_drop(v_x1_241042);
          v_t_241043 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_241042);
          v_t_241043 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_241044 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241028), v_op_241036));
        V v_b_241045 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13)), 5, (V[]){v_env_241028, v_m_241029, v_e_241037, NTAG(TAG_Nil), v_rest2_241035}));
        V v_t_241046 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24rs_241032_24Cons, heff_tag_at_n(v_ru_24t_241038_24Same, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), v_b_241045));
        V v_t_241047 = (g_std_2edoc_2e_3c_3e(v_a_241044, v_t_241046));
        V v_t_241048 = (g_std_2edoc_2e_3c_3e(v_t_241043, v_t_241047));
        return (g_std_2edoc_2e_3c_3e(v_t_241041, v_t_241048));
      }
      case TAG_Unrelated: {
        heff_drop_cell(v_ru_24rs_241032_24Cons, 2);
        heff_drop_rec(v_op_241036, 9);
        heff_drop(v_e_241037);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
        args[0] = v_env_241028;
        args[1] = v_m_241029;
        args[2] = v_f_241030;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241034, v_acc_241031});
        args[4] = v_rest2_241035;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_241038, 0ULL, 1);
        heff_drop_cell(v_ru_24rs_241032_24Cons, 2);
        heff_drop_rec(v_op_241036, 9);
        heff_drop(v_e_241037);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
        args[0] = v_env_241028;
        args[1] = v_m_241029;
        args[2] = v_f_241030;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241034, v_acc_241031});
        args[4] = v_rest2_241035;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_241038);
      }
    }
    default: {
      heff_drop_cell(v_ru_24rs_241032_24Cons, 2);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
      args[0] = v_env_241028;
      args[1] = v_m_241029;
      args[2] = v_f_241030;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241034, v_acc_241031});
      args[4] = v_rest2_241035;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    }
  }
  default: return heff_nomatch(v_rs_241032);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_env_241050 = args[0];
  V v_a_241051 = args[1];
  switch (heff_tag_of(v_a_241051)) {
  case TAG_EAlt: {
    V v_p_241052 = heff_field(v_a_241051, 0);
    V v_arrow_241053 = heff_field(v_a_241051, 1);
    V v_body_241054 = heff_field(v_a_241051, 2);
    heff_take_n(v_a_241051, 7ULL, 3);
    V v_a_241055 = ({ V a_0 = v_env_241050; V a_1 = v_p_241052; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_241052); r_; });
    V v_b_241056 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241050), v_arrow_241053));
    V v_t_241057 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), v_b_241056));
    V v_t_241058 = (g_std_2edoc_2e_3c_3e(v_a_241055, v_t_241057));
    V v_t_241059 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241050, v_body_241054}));
    return (g_std_2edoc_2e_3c_3e(v_t_241058, v_t_241059));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241050;
    args[1] = v_a_241051;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_env_241060 = args[0];
  V v_s_241061 = args[1];
  switch (heff_tag_of(v_s_241061)) {
  case TAG_If: {
    V v_d_241068 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241060, v_s_241061}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_241068});
  }
  case TAG_ESBind: {
    V v_x_241069 = heff_field(v_s_241061, 0);
    V v_arrow_241070 = heff_field(v_s_241061, 1);
    V v_e_241071 = heff_field(v_s_241061, 2);
    heff_take_n(v_s_241061, 7ULL, 3);
    V v_a_241072 = ({ V a_0 = v_env_241060; V a_1 = v_x_241069; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_241069); r_; });
    V v_b_241073 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241060), v_arrow_241070));
    V v_t_241074 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), v_b_241073));
    V v_t_241075 = (g_std_2edoc_2e_3c_3e(v_a_241072, v_t_241074));
    V v_t_241076 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241060, v_e_241071}));
    return (g_std_2edoc_2e_3c_3e(v_t_241075, v_t_241076));
  }
  case TAG_IfThen: {
    V v_d_241081 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241060, v_s_241061}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_241081});
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241060;
    args[1] = v_s_241061;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_env_241082 = args[0];
  V v_f_241083 = args[1];
  switch (heff_tag_of(v_f_241083)) {
  case TAG_EUSet: {
    V v_x_241084 = heff_field(v_f_241083, 0);
    V v_eq_241085 = heff_field(v_f_241083, 1);
    V v_e_241086 = heff_field(v_f_241083, 2);
    heff_take_n(v_f_241083, 7ULL, 3);
    V v_a_241087 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241082), v_x_241084}));
    V v_b_241088 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241082), v_eq_241085));
    V v_t_241089 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), v_b_241088));
    V v_t_241090 = (g_std_2edoc_2e_3c_3e(v_a_241087, v_t_241089));
    V v_t_241091 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241082, v_e_241086}));
    return (g_std_2edoc_2e_3c_3e(v_t_241090, v_t_241091));
  }
  case TAG_EFSet: {
    V v_x_241092 = heff_field(v_f_241083, 0);
    V v_eq_241093 = heff_field(v_f_241083, 1);
    V v_e_241094 = heff_field(v_f_241083, 2);
    heff_take_n(v_f_241083, 7ULL, 3);
    V v_a_241095 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241082), v_x_241092));
    V v_b_241096 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241082), v_eq_241093));
    V v_t_241097 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), v_b_241096));
    V v_t_241098 = (g_std_2edoc_2e_3c_3e(v_a_241095, v_t_241097));
    V v_t_241099 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241082, v_e_241094}));
    return (g_std_2edoc_2e_3c_3e(v_t_241098, v_t_241099));
  }
  case TAG_EFDefault: {
    V v_d_241100 = heff_field(v_f_241083, 0);
    V v_eq_241101 = heff_field(v_f_241083, 1);
    V v_e_241102 = heff_field(v_f_241083, 2);
    heff_take_n(v_f_241083, 7ULL, 3);
    V v_a_241103 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241082), v_d_241100}));
    V v_b_241104 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241082), v_eq_241101));
    V v_t_241105 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), v_b_241104));
    V v_t_241106 = (g_std_2edoc_2e_3c_3e(v_a_241103, v_t_241105));
    V v_t_241107 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241082, v_e_241102}));
    return (g_std_2edoc_2e_3c_3e(v_t_241106, v_t_241107));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241082;
    args[1] = v_f_241083;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        V v_ru_24x212_244_24Cons = heff_take_reuse_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x212_244_24Cons, heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_ix_244 = heff_take_field(v_t_243, 7);
    V v_blank_245 = heff_get_n(v_t_243, 8, 9);
    HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_ix_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_ix_244); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2412;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = v_blank_245;
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop(v_blank_245);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_248);
        v_t_2412 = v_blank_245;
      }
      V v_t_2413;
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
    }
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str16, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_d1_244 = heff_field(v_d_240, 0);
    switch (heff_tag_of(v_d1_244)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_d1_244, 0);
      V v_d12_249 = heff_field(v_d1_244, 1);
      switch (heff_tag_of(v_d12_249)) {
      case TAG_Nil: {
        V v_x2_2410 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_248)));
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nil: {
          return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3);
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_2410, 0);
          V v_xs_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        }
        default: return heff_nomatch(v_x2_2410);
        }
      }
      case TAG_Cons: {
        return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5);
      }
      default: return heff_nomatch(v_d12_249);
      }
    }
    default: return heff_nomatch(v_d1_244);
    }
  }
  case TAG_DInstance: {
    V v_n_2416 = heff_field(v_d_240, 1);
    V v_x2_2419 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2416)));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  case TAG_DEqn: {
    V v_n_2422 = heff_field(v_d_240, 0);
    V v_x2_2427 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2422)));
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
    }
    default: return heff_nomatch(v_x2_2427);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DMutual: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str14);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str15);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str16);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str1, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_eof_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_rfield(v_eof_243, 7)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_249;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        v_t_249 = v_x_248;
      } else {
        heff_drop(v_field_247);
        v_t_249 = NTAG(TAG_Nil);
      }
      return ({ V a_0 = v_env_240; V a_1 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_t_249); r_; });
    }
  }
  case TAG_Cons: {
    V v_d_2410 = heff_field(v_x5_244, 0);
    V v_ds_2411 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_2410));
    V v_t_2454;
    switch (heff_tag_of(v_d_2410)) {
    case TAG_DImport: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DMutual: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2452 = heff_dup(heff_field(v_d_2410, 0));
      v_t_2454 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_w_2452, 0)), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0)));
      heff_drop_rec(v_w_2452, 9);
      break;
    }
    default: heff_nomatch(v_d_2410);
    }
    V v_t_24206;
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      heff_drop(v_t_2454);
      V v_t_2455 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
      V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2410)));
      V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2455, v_t_2456, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_2410)})));
      V v_t_2459 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_2410); r_; });
      V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2459, v_eof_243, v_ds_2411));
      v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2460));
    } else {
      heff_drop(v_t_2454);
      V v_t_2461 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_t_2461);
        V v_env_2462 = heff_dup(v_env_240);
        V v_lead_2463 = heff_take_field(v_env_2462, 1);
        V v_inline_2464 = heff_take_field(v_env_2462, 2);
        V v_src_2465 = heff_get_n(v_env_2462, 0, 7);
        V v_first_2466 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
        V v_ix_2467 = heff_take_field(v_first_2466, 7);
        V v_start_2468 = heff_get_n(v_first_2466, 3, 9);
        V v_t_2469 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_2410));
        V v_t_2470 = ({ V a_0 = v_t_2469; V a_1 = v_d_2410; V a_2 = v_ds_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2469); r_; });
        V v_last2_2471 = (g_heff_2esyntax_2ecst_2elastD(v_t_2470));
        HeffT2 v_t_2472 = ({ V a_0 = v_lead_2463; V a_1 = v_ix_2467; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_lead_2463); r_; });
        {
          V v_field_2474 = v_t_2472.f[1];
          int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
          V v_t_2476;
          if ((v_tag_2473 == ((int64_t)0ULL))) {
            V v_x_2475 = v_field_2474;
            v_t_2476 = v_x_2475;
          } else {
            heff_drop(v_field_2474);
            v_t_2476 = NTAG(TAG_Nil);
          }
          V v_t_2477 = ({ V a_0 = v_t_2476; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_2476); r_; });
          HeffT2 v_t_2478 = ({ V a_0 = v_inline_2464; V a_1 = v_ix_2467; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_inline_2464); heff_drop(v_ix_2467); r_; });
          {
            V v_field_2480 = v_t_2478.f[1];
            int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
            V v_t_2482;
            if ((v_tag_2479 == ((int64_t)0ULL))) {
              V v_x_2481 = v_field_2480;
              v_t_2482 = v_x_2481;
            } else {
              heff_drop(v_field_2480);
              v_t_2482 = NTAG(TAG_Nil);
            }
            V v_t_2483 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2482; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2482); r_; });
            V v_b_2484 = (g_heff_2esyntax_2efmt_2elayout_2etrailEnd(v_src_2465, heff_get_n(v_last2_2471, 4, 9)));
            V v_t_2485 = ({ V b_0 = heff_strSlice(v_src_2465, v_start_2468, v_b_2484); V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(b_0)); heff_drop(b_0); r_; });
            V v_t_2486 = (g_std_2edoc_2e_3c_3e(v_t_2483, v_t_2485));
            V v_t_2487 = (g_std_2edoc_2e_3c_3e(v_t_2477, v_t_2486));
            V v_t_2488 = ({ V a_0 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_2410); r_; });
            V v_t_2489 = ({ V a_0 = v_t_2488; V a_1 = v_ds_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2488); r_; });
            V v_t_2490 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_t_2489));
            v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_2487, v_t_2490));
          }
        }
      } else {
        heff_drop(v_t_2461);
        V v_env_2491 = heff_dup(v_env_240);
        V v_d_2492 = heff_dup(v_d_2410);
        V v_expect_24186;
        switch (heff_tag_of(v_d_2492)) {
        case TAG_DImport: {
          heff_take_n(v_d_2492, 0ULL, 1);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DFixity: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DSig: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DInstance: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DEqn: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DData: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DType: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DTheory: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DMutual: {
          V v_ds_24125 = heff_field(v_d_2492, 1);
          V v_ru_24d_2492_24DMutual = heff_take_reuse_n(v_d_2492, 2ULL, 2);
          V v_x1_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_24125));
          switch (heff_tag_of(v_x1_24126)) {
          case TAG_Nil: {
            heff_drop_rec(v_env_2491, 7);
            heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
            v_expect_24186 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_x_24127 = heff_field(v_x1_24126, 0);
            heff_take_n(v_x1_24126, 1ULL, 2);
            switch (heff_tag_of(v_x_24127)) {
            case TAG_DImport: {
              heff_take_n(v_x_24127, 0ULL, 1);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DFixity: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DSig: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DInstance: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DEqn: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DData: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DType: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DTheory: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DMutual: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DPrimitive: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DTest: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DWatch: {
              V v_w_24168 = heff_field(v_x_24127, 0);
              V v_e_24169 = heff_field(v_x_24127, 1);
              heff_take_n(v_x_24127, 3ULL, 2);
              V v_t_24170 = (g_heff_2esyntax_2ecst_2elastE(v_e_24169));
              V v_t_24171 = heff_intAdd(heff_get_n(v_t_24170, 7, 9), MK_INT(1LL));
              HeffT2 v_t_24172 = ({ V b_0 = heff_get_n(v_env_2491, 1, 7); V a_1 = v_t_24171; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24171); r_; });
              {
                V v_field_24174 = v_t_24172.f[1];
                int64_t v_tag_24173 = ((int64_t)v_t_24172.f[0]);
                V v_t_24176;
                if ((v_tag_24173 == ((int64_t)0ULL))) {
                  V v_x_24175 = v_field_24174;
                  v_t_24176 = v_x_24175;
                } else {
                  heff_drop(v_field_24174);
                  v_t_24176 = NTAG(TAG_Nil);
                }
                V v_t_24177 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_w_24168, 0)), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str1)));
                heff_drop_rec(v_w_24168, 9);
                v_expect_24186 = ({ V a_0 = v_ru_24d_2492_24DMutual; V a_1 = v_t_24177; V a_2 = v_t_24176; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2(a_0, a_1, a_2)); heff_drop(v_t_24177); r_; });
              }
              break;
            }
            default: heff_nomatch(v_x_24127);
            }
            break;
          }
          default: heff_nomatch(v_x1_24126);
          }
          break;
        }
        case TAG_DPrimitive: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DTest: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DWatch: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d_2492);
        }
        V v_t_24187 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
        V v_t_24188 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2410)));
        V v_t_24190 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_24187, v_t_24188, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){heff_dup(v_d_2410)})));
        V v_d_24191 = (g_list_2efoldl_24f1134152647x940271785(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_expect_24186));
        V v_env_24192 = v_env_240;
        V v_t_24193 = (g_heff_2esyntax_2ecst_2elastD(v_d_2410));
        V v_ix_24194 = heff_intAdd(heff_get_n(v_t_24193, 7, 9), MK_INT(1LL));
        V v_n_24195 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_expect_24186; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_expect_24186); r_; });
        V v_t_24203;
        if (heff_intEq_c_lent(v_n_24195, MK_INT(0LL), 2)) {
          heff_drop(v_ix_24194);
          heff_drop(v_n_24195);
          v_t_24203 = v_env_24192;
        } else {
          HeffT2 v_t_24196 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_24192, 1), v_ix_24194));
          {
            V v_field_24198 = v_t_24196.f[1];
            int64_t v_tag_24197 = ((int64_t)v_t_24196.f[0]);
            V v_t_24200;
            if ((v_tag_24197 == ((int64_t)0ULL))) {
              V v_x_24199 = v_field_24198;
              v_t_24200 = v_x_24199;
            } else {
              heff_drop(v_field_24198);
              v_t_24200 = NTAG(TAG_Nil);
            }
            V v_t_24201 = ({ V a_0 = v_n_24195; V a_1 = v_t_24200; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24200); r_; });
            V v_t_24202 = ({ V a_0 = heff_take_field(v_env_24192, 1); V a_1 = v_ix_24194; V a_2 = v_t_24201; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_ix_24194); heff_drop(v_t_24201); r_; });
            v_t_24203 = ({ V rv_1 = v_t_24202; V rr_ = heff_rec_reuse_nf(v_env_24192, 125ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          }
        }
        V v_t_24204 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_t_24203, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_ds_2411));
        V v_t_24205 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24191}), v_t_24204));
        v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_24190, v_t_24205));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_24206));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2457 = args[0];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2457; V a_1 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2410); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_24189 = args[0];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_24189; V a_1 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2410); r_; });
}