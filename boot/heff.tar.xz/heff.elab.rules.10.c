// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Delay 58579
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IntNum 31256
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkChk 56962
#define TAG_MkSyn 7342
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SLitFloat 3938
#define TAG_SLitInt 21439
#define TAG_SmallU 20221
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_digits 615232529
#define LBL_exponent 966452320
#define LBL_globals 352931696
#define LBL_instantiated 552850723
#define LBL_kind 9787483
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_names 305943394
#define LBL_negative 1666250321
#define LBL_note 9882809
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_state 311115947
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_val 326043
#define LBL_witness 1587180415
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_array_2eempty_get(void);
V g_heff_2eelab_2eenvironment_2epartOf(V, V);
V g_heff_2eelab_2eenvironment_2epartOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2epartOf_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2eliftU_24tok1(V, V, V, V);
V g_heff_2eelab_2emeta_2eliftU_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_24tok1_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24tok2_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eatFloat64_w(V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64(V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_clo;
V g_heff_2eelab_2erules_2ebindingSyn(V, V);
V g_heff_2eelab_2erules_2ebindingSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebindingSyn_clo;
V g_heff_2eelab_2erules_2ecommitted(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecommitted_clo;
V g_heff_2eelab_2erules_2edelayChkBy(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkBy_clo;
V g_heff_2eelab_2erules_2eescapeAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eescapeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eescapeAt_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracDefault_w(V, V, V, double, V, V);
V g_heff_2eelab_2erules_2efracDefault(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracDefault_clo;
V g_heff_2eelab_2erules_2efracDefault_24tok1_w(V, V, V, V, double, V, V);
V g_heff_2eelab_2erules_2efracDefault_24tok1(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracDefault_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracDefault_24tok1_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2egivenTwice(V, V);
V g_heff_2eelab_2erules_2egivenTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenTwice_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2eguessFunctionTy(V, V, V, V, V);
V g_heff_2eelab_2erules_2eguessFunctionTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eguessFunctionTy_clo;
V g_heff_2eelab_2erules_2eguessedFunction(V, V, V);
V g_heff_2eelab_2erules_2eguessedFunction_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eguessedFunction_clo;
V g_heff_2eelab_2erules_2emetaOfStx(V);
V g_heff_2eelab_2erules_2emetaOfStx_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOfStx_clo;
V g_heff_2eelab_2erules_2emisfit(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_clo;
V g_heff_2eelab_2erules_2emisfit_24tok1(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2emisfit_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emisfit_24tok1_clo;
V g_heff_2eelab_2erules_2enameAtGo(V, V);
V g_heff_2eelab_2erules_2enameAtGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enameAtGo_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
V g_heff_2eelab_2erules_2enumLitDefault(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitDefault_clo;
V g_heff_2eelab_2erules_2enumLitWait(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_clo;
V g_heff_2eelab_2erules_2epatternCanFail(V, V, V, V);
V g_heff_2eelab_2erules_2epatternCanFail_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epatternCanFail_clo;
V g_heff_2eelab_2erules_2eplainMismatch(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eplainMismatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplainMismatch_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2eresourceEscapes(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eresourceEscapes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eresourceEscapes_clo;
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V);
V g_heff_2eelab_2erules_2eupdateSetting(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateSetting_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_list_2ekeepIf_24s924780574x2000457388(V, V);
V g_list_2ekeepIf_24s924780574x2000457388_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s924780574x2000457388_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str0, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str1, 6, "found ");
HEFF_LIT(g_heff_2eelab_2erules_2ecommitted_str2, 3, " : ");
V g_heff_2eelab_2erules_2ecommitted_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2ecommitted_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecommitted_lam0, 1, 0};
V g_heff_2eelab_2erules_2ecommitted_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecommitted_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ecommitted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecommitted_entry, 8, 0};

V g_heff_2eelab_2erules_2ecommitted(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_fit_245, V v_hd_246, V v_k_247) {
top: ;
  V v_state_248 = heff_take_field(v_fit_245, 2);
  V v_instantiated_249 = heff_take_field(v_fit_245, 1);
  V v_witness_2410 = heff_get_n(v_fit_245, 0, 3);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2ecommitted_lam0_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam1, 1, 10, (V[]){v_state_248, v_hd_246, v_instantiated_249, v_e_240, v_hm_242, v_holeVal_243, v_sp_241, v_witness_2410, v_k_247, v_goal_244})});
}
V g_heff_2eelab_2erules_2ecommitted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecommitted(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2ecommitted_lam0(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 3, 9);
}
V g_heff_2eelab_2erules_2ecommitted_lam4(V self, V *args) {
  V v_u_2433 = args[0];
  V v_witness_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_goal_244 = heff_env(self)[3];
  heff_drop(v_u_2433);
  heff_clo_take(self, 4);
  V v_t_2434 = heff_tr(heff_call(heff_get_n(v_witness_2410, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2435 = ({ V a_0 = v_e_240; V a_1 = v_x_2415; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2415); r_; });
  V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2ecommitted_str1), v_t_2434), ((V)&g_heff_2eelab_2erules_2ecommitted_str2));
  return heff_strAppend(v_t_2436, v_t_2435);
}
V g_heff_2eelab_2erules_2ecommitted_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_instantiated_249 = heff_env(self)[1];
  heff_drop(v_x_2439);
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = v_instantiated_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecommitted_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_witness_2410 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_x_2415 = heff_env(self)[5];
  V v_goal_244 = heff_env(self)[6];
  V v_instantiated_249 = heff_env(self)[7];
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_err_2431 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Left = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    heff_clo_take(self, 8);
    heff_drop(v_x_2415);
    heff_drop(v_goal_244);
    heff_drop_rec(v_instantiated_249, 3);
    return ({ V a_0 = v_ru_24x_2430_24Left; V a_1 = v_e_240; V a_2 = v_sp_241; V a_3 = v_witness_2410; V a_4 = v_err_2431; V a_5 = v_hd_246; V a_6 = v_k_247; V r_ = (g_heff_2eelab_2erules_2emisfit_24tok1(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_err_2431); r_; });
  }
  case TAG_Right: {
    heff_take_n(v_x_2430, 0ULL, 1);
    heff_clo_take(self, 8);
    V v_t_2437 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2ecommitted_str0), heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam4, 1, 4, (V[]){v_witness_2410, v_e_240, v_x_2415, v_goal_244})}), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2438;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam5, 1, 2, (V[]){v_k_247, v_instantiated_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2eelab_2erules_2ecommitted_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_instantiated_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hm_242 = heff_env(self)[2];
  V v_holeVal_243 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_witness_2410 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_x_2415 = heff_env(self)[8];
  V v_goal_244 = heff_env(self)[9];
  heff_drop(v_x_2419);
  V v_t_2420 = heff_get_n(heff_dup(heff_rfield(v_instantiated_249, 0)), 1, 2);
  V v_x1_2421 = heff_tr(heff_call(v_t_2420, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2425;
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Nom: {
    V v_x_2422 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_t_2425 = v_x_2422;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2421, 0ULL, 1);
    v_t_2425 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2424 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_t_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x1_2421);
  }
  V v_c_2426 = heff_dup(heff_rfield(v_e_240, 0));
  V v_len_2427 = heff_take_field(v_c_2426, 0);
  V v_names_2428 = heff_get_n(v_c_2426, 1, 5);
  V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_instantiated_249, 0)), 0, 2);
  heff_clo_take(self, 10);
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), heff_rec_n(2, shape_len__names, (V[]){v_len_2427, v_names_2428}), v_hm_242, v_holeVal_243, v_t_2429, v_t_2425, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam3, 1, 8, (V[]){v_e_240, v_sp_241, v_witness_2410, v_hd_246, v_k_247, v_x_2415, v_goal_244, v_instantiated_249})));
}
V g_heff_2eelab_2erules_2ecommitted_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_state_248 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_instantiated_249 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hm_242 = heff_env(self)[4];
  V v_holeVal_243 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_witness_2410 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  V v_goal_244 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2416 = heff_tag_n(TAG_Put, 2, (V[]){v_state_248, NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecommitted_lam2, 1, 10, (V[]){v_instantiated_249, v_e_240, v_hm_242, v_holeVal_243, v_hd_246, v_sp_241, v_witness_2410, v_k_247, v_x_2415, v_goal_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eguessFunctionTy_str0, 8, "argument");
HEFF_LIT(g_heff_2eelab_2erules_2eguessFunctionTy_str1, 6, "result");
HEFF_LIT(g_heff_2eelab_2erules_2eguessFunctionTy_str2, 5, "guess");
HEFF_LIT(g_heff_2eelab_2erules_2eguessFunctionTy_str3, 39, "lambda's type guessed a function type \?");
HEFF_LIT(g_heff_2eelab_2erules_2eguessFunctionTy_str4, 5, " -> \?");
V g_heff_2eelab_2erules_2eguessFunctionTy_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eguessFunctionTy_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eguessFunctionTy_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eguessFunctionTy_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eguessFunctionTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eguessFunctionTy_entry, 5, 0};

V g_heff_2eelab_2erules_2eguessFunctionTy(V v_e_240, V v_sp_241, V v_a_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VDecode: {
    V v_u_248 = heff_dup(heff_field(v_a_242, 2));
    v_t_2424 = v_u_248;
    break;
  }
  case TAG_VFunction: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VRecord: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VSum: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimString: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VFixed: {
    v_t_2424 = NTAG(TAG_SmallU);
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
  V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 5);
  return ({ V a_0 = v_t_2425; V a_1 = v_t_2426; V a_2 = heff_tag_n(TAG_VU, 1, (V[]){v_t_2424}); V a_3 = ((V)&g_heff_2eelab_2erules_2eguessFunctionTy_str0); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_243); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2eguessFunctionTy_lam0, 1, 5, (V[]){v_a_242, v_e_240, v_sp_241, v_hd_243, v_k_244}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2426); r_; });
}
V g_heff_2eelab_2erules_2eguessFunctionTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eguessFunctionTy(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eguessFunctionTy_lam2(V self, V *args) {
  V v_u_2451 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_x_2450 = heff_env(self)[1];
  heff_drop(v_u_2451);
  heff_clo_take(self, 2);
  V v_t_2452 = ({ V b_0 = heff_get_n(v_x_2427, 0, 2); V r_ = (g_heff_2eelab_2erules_2emetaOfStx(b_0)); heff_drop(b_0); r_; });
  V v_t_2453 = ({ V b_0 = heff_get_n(v_x_2450, 0, 2); V r_ = (g_heff_2eelab_2erules_2emetaOfStx(b_0)); heff_drop(b_0); r_; });
  V v_t_2454 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eguessFunctionTy_str3), heff_intShow(v_t_2452));
  return heff_strAppend(heff_strAppend(v_t_2454, ((V)&g_heff_2eelab_2erules_2eguessFunctionTy_str4)), heff_intShow(v_t_2453));
}
V g_heff_2eelab_2erules_2eguessFunctionTy_lam3(V self, V *args) {
  V v_x_2457 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_x_2450 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_drop(v_x_2457);
  V v_g_2458 = heff_dup(heff_rfield(v_e_240, 1));
  V v_c_2459 = heff_dup(heff_rfield(v_e_240, 0));
  V v_len_2460 = heff_take_field(v_c_2459, 0);
  V v_names_2461 = heff_get_n(v_c_2459, 1, 5);
  heff_clo_take(self, 6);
  V v_b_2462 = (g_heff_2eelab_2erules_2eguessedFunction(v_e_240, v_x_2427, v_x_2450));
  V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){v_g_2458, heff_rec_n(2, shape_len__names, (V[]){v_len_2460, v_names_2461}), v_a_242, v_b_2462}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2463, v_hd_243, v_k_244));
}
V g_heff_2eelab_2erules_2eguessFunctionTy_lam1(V self, V *args) {
  V v_x_2450 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_a_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2455 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2eguessFunctionTy_str2), heff_clo_n(g_heff_2eelab_2erules_2eguessFunctionTy_lam2, 1, 2, (V[]){heff_dup(v_x_2427), heff_dup(v_x_2450)})}), NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2456;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eguessFunctionTy_lam3, 1, 6, (V[]){v_e_240, v_x_2427, v_x_2450, v_a_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eguessFunctionTy_lam0(V self, V *args) {
  V v_x_2427 = args[0];
  V v_a_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_t_2447;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VDecode: {
    V v_u_2431 = heff_dup(heff_field(v_a_242, 2));
    v_t_2447 = v_u_2431;
    break;
  }
  case TAG_VFunction: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VRecord: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VSum: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimString: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  case TAG_VFixed: {
    v_t_2447 = NTAG(TAG_SmallU);
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
  V v_t_2449 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 5);
  return ({ V a_0 = v_t_2448; V a_1 = v_t_2449; V a_2 = heff_tag_n(TAG_VU, 1, (V[]){v_t_2447}); V a_3 = ((V)&g_heff_2eelab_2erules_2eguessFunctionTy_str1); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_243); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2eguessFunctionTy_lam1, 1, 6, (V[]){v_sp_241, v_x_2427, v_hd_243, v_e_240, v_a_242, v_k_244}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2449); r_; });
}
Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroAnn_entry, 4, 0};

V g_heff_2eelab_2erules_2efunctionIntroAnn(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  HeffT1 v_t_244 = (g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(v_sp_240, v_x_241, v_dom_242, v_body_243));
  {
    V v_field_245 = v_t_244.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_245});
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2efunctionIntroAnn(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eescapeAt_str0, 16, "the type names `");
HEFF_LIT(g_heff_2eelab_2erules_2eescapeAt_str1, 27, "` outside where it is bound");
Clo g_heff_2eelab_2erules_2eescapeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eescapeAt_entry, 7, 0};

V g_heff_2eelab_2erules_2eescapeAt(V v_e_240, V v_sp_241, V v_a_242, V v_a_27_243, V v_err_244, V v_l_245, V v_x7_246) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_err_244)) {
    case TAG_UnequalTys: {
      heff_drop(v_l_245);
      V v_t_2410 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2410});
    }
    case TAG_UnequalEls: {
      heff_drop(v_l_245);
      V v_t_2414 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2414});
    }
    case TAG_UnequalNeus: {
      heff_drop(v_l_245);
      V v_t_2420 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2420});
    }
    case TAG_MentionsError: {
      heff_drop(v_l_245);
      V v_t_2421 = (g_heff_2eelab_2erules_2eprettyEqErr(heff_dup(heff_rfield(v_e_240, 1)), v_err_244));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2421});
    }
    case TAG_Escapes: {
      V v_sc_2423 = heff_dup(heff_rfield(v_e_240, 0));
      V v_names_2424 = heff_take_field(v_sc_2423, 1);
      V v_len_2425 = heff_get_n(v_sc_2423, 0, 5);
      V v_t_2426 = heff_intSub(heff_intSub(v_len_2425, MK_INT(1LL)), v_l_245);
      V v_t_2427 = ({ V a_0 = v_names_2424; V a_1 = v_t_2426; V r_ = (g_heff_2eelab_2erules_2enameAtGo(a_0, a_1)); heff_drop(v_names_2424); r_; });
      V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eescapeAt_str0), v_t_2427), ((V)&g_heff_2eelab_2erules_2eescapeAt_str1));
      return heff_tail(((V)&g_heff_2eelab_2erules_2eplainMismatch_clo), 5, (V[]){v_e_240, v_sp_241, v_a_242, v_a_27_243, v_t_2428});
    }
    default: return heff_nomatch(v_err_244);
    }
  }
  case TAG_Just: {
    V v_x71_2429 = heff_field(v_x7_246, 0);
    heff_drop(v_a_242);
    heff_drop(v_a_27_243);
    switch (heff_tag_of(v_x71_2429)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x71_2429, 0);
      V v_t_2431 = heff_field(v_x71_2429, 1);
      V v_sc_2432 = heff_dup(heff_rfield(v_e_240, 0));
      V v_names_2433 = heff_take_field(v_sc_2432, 1);
      V v_len_2434 = heff_get_n(v_sc_2432, 0, 5);
      V v_t_2435 = heff_intSub(heff_intSub(v_len_2434, MK_INT(1LL)), v_l_245);
      V v_t_2436 = ({ V a_0 = v_names_2433; V a_1 = v_t_2435; V r_ = (g_heff_2eelab_2erules_2enameAtGo(a_0, a_1)); heff_drop(v_names_2433); r_; });
      return heff_tail(((V)&g_heff_2eelab_2erules_2eresourceEscapes_clo), 5, (V[]){v_e_240, v_sp_241, v_t_2436, heff_dup(v_x_2430), heff_dup(v_t_2431)});
    }
    default: return heff_nomatch(v_x71_2429);
    }
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2erules_2eescapeAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2eelab_2erules_2eescapeAt(a[0], a[1], a[2], a[3], a4, a[5], a6); heff_drop(a4); heff_drop(a6); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat64_str0, 21, " is out of range for ");
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat64_str1, 49, "Float64, whose greatest is 1.7976931348623157e308");
V g_heff_2eelab_2erules_2eatFloat64_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eatFloat64_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat64_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2eatFloat64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat64_entry, 5, 0};

V g_heff_2eelab_2erules_2eatFloat64_w(V v_sp_240, V v_text_241, double v_x_242, V v_p_243, V v_p_244) {
top: ;
  V v_malg_245 = heff_take_field(v_p_243, 2);
  V v_bind_246 = heff_get_n(v_p_243, 1, 3);
  if (((v_x_242 - v_x_242) == (0.0))) {
    heff_drop(v_sp_240);
    heff_drop(v_text_241);
    heff_drop(v_malg_245);
    heff_drop(v_bind_246);
    V v_t_248 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_x_242)}), ((V)&g_heff_2eelab_2erules_2eatFloat64_lam0_clo)});
    return heff_tail(v_p_244, 1, (V[]){v_t_248});
  } else {
    V v_t_249 = heff_strAppend(heff_strAppend(v_text_241, ((V)&g_heff_2eelab_2erules_2eatFloat64_str0)), ((V)&g_heff_2eelab_2erules_2eatFloat64_str1));
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), v_t_249, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2412}));
    return heff_tail(v_bind_246, 2, (V[]){v_t_2413, v_p_244});
  }
}
V g_heff_2eelab_2erules_2eatFloat64(V v_sp_240, V v_text_241, V v_box_24x_242, V v_p_243, V v_p_244) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2eelab_2erules_2eatFloat64_w(v_sp_240, v_text_241, v_x_242, v_p_243, v_p_244));
}
V g_heff_2eelab_2erules_2eatFloat64_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eatFloat64(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eatFloat64_lam0(V self, V *args) {
  V v_u_247 = args[0];
  heff_drop(v_u_247);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitDefault_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_lam1, 1, 0};
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitDefault_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitDefault(V v_sp_240, V v_e_241, V v_a_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IntNum: {
    V v_i_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24IntNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    HeffT1 v_t_2413 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_at_n(v_ru_24x4_243_24IntNum, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitDefault_lam0, 3, 1, (V[]){v_i_246})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_f_2415 = v_field_2414;
      return heff_tail(v_f_2415, 4, (V[]){v_e_241, v_a_242, v_z_244, v_z_245});
    }
  }
  case TAG_FracNum: {
    V v_d_2416 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24FracNum = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_negative_2417 = heff_take_field(v_d_2416, 0);
    V v_digits_2418 = heff_take_field(v_d_2416, 1);
    V v_exponent_2419 = heff_get_n(v_d_2416, 2, 3);
    V v_t_2420 = v_negative_2417;
    double v_t_2422;
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      double v_x_2421 = ({ V a_0 = v_digits_2418; V a_1 = v_exponent_2419; double r_ = (g_std_2emath_2efromDecimal_w(a_0, a_1)); heff_drop(v_exponent_2419); r_; });
      v_t_2422 = ((-1.0) * v_x_2421);
    } else {
      heff_drop(v_t_2420);
      v_t_2422 = ({ V a_0 = v_digits_2418; V a_1 = v_exponent_2419; double r_ = (g_std_2emath_2efromDecimal_w(a_0, a_1)); heff_drop(v_exponent_2419); r_; });
    }
    return (g_heff_2eelab_2erules_2efracDefault_24tok1_w(v_ru_24x4_243_24FracNum, v_sp_240, v_e_241, v_a_242, v_t_2422, v_z_244, v_z_245));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2enumLitDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitDefault(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitDefault_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  heff_drop(v_u_2410);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2enumLitDefault_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_hd_248 = args[1];
  V v_k_249 = args[2];
  V v_i_246 = heff_env(self)[0];
  heff_drop(v_e_247);
  heff_drop(v_hd_248);
  heff_clo_take(self, 1);
  V v_t_2411 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_i_246}), ((V)&g_heff_2eelab_2erules_2enumLitDefault_lam1_clo)});
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, NTAG(TAG_VPrimInt)});
  V f_ = v_k_249;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitWait_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enumLitWait_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitWait_entry, 3, 0};

V g_heff_2eelab_2erules_2enumLitWait(V v_n_240, V v_sp_241, V v_lit_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam0, 4, 3, (V[]){v_sp_241, v_lit_242, v_n_240})});
}
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitWait(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2enumLitWait_lam1(V self, V *args) {
  V v_c_247 = args[0];
  V v_a0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_247, 3, 9); V a_1 = v_a0_244; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitWait_lam3(V self, V *args) {
  V v_chk_2437 = args[0];
  V v_hd_2438 = args[1];
  V v_k2_2439 = args[2];
  V v_x_2411 = heff_env(self)[0];
  V v_t_2440 = heff_tr(heff_call(v_chk_2437, 2, (V[]){heff_dup(v_hd_2438), heff_dup(heff_rfield(v_hd_2438, 0))}));
  heff_clo_take(self, 1);
  V v_t_2441 = heff_tag_n(TAG_Delay, 3, (V[]){v_x_2411, v_t_2440, NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tr(heff_call(heff_take_field(v_hd_2438, 2), 1, (V[]){v_t_2442}));
  V f_ = heff_get_n(v_hd_2438, 1, 3);
  args[0] = v_t_2443;
  args[1] = v_k2_2439;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enumLitWait_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_n_240 = heff_env(self)[5];
  V v_t_2434;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_VU: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2413 = heff_dup(heff_field(v_x_2411, 0));
    switch (heff_tag_of(v_t1_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2413, 0ULL, 1);
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t1_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VRecord: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VSum: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimString: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  case TAG_VFixed: {
    v_t_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
    heff_clo_take(self, 6);
    heff_drop(v_n_240);
    heff_drop(v_t_2434);
    return (g_heff_2eelab_2erules_2enumLitAt(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
  } else {
    heff_drop(v_t_2434);
    heff_clo_take(self, 6);
    if ((((int64_t)0ULL) < heff_peek_word(v_n_240))) {
      switch (heff_tag_of(v_lit_242)) {
      case TAG_IntNum: {
        V v_c_2436 = (g_heff_2eelab_2erules_2enumLitWait(heff_box_word((heff_unbox_word(v_n_240) - ((int64_t)1ULL))), heff_dup(v_sp_241), v_lit_242));
        return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam3, 3, 1, (V[]){heff_dup(v_x_2411)}); V a_1 = v_e_243; V a_2 = v_sp_241; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitWait_str0); V a_4 = v_c_2436; V a_5 = v_x_2411; V a_6 = v_hd_245; V a_7 = v_k_246; V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2436); r_; });
      }
      case TAG_FracNum: {
        heff_drop(v_n_240);
        return (g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
      }
      default: return heff_nomatch(v_lit_242);
      }
    } else {
      heff_drop(v_n_240);
      return (g_heff_2eelab_2erules_2enumLitDefault(v_sp_241, v_e_243, v_x_2411, v_lit_242, v_hd_245, v_k_246));
    }
  }
}
V g_heff_2eelab_2erules_2enumLitWait_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_a0_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V v_sp_241 = heff_env(self)[0];
  V v_lit_242 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam1, 1, 1, (V[]){v_a0_244})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_t_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitWait_lam2, 1, 6, (V[]){v_sp_241, v_e_243, v_lit_242, v_hd_245, v_k_246, v_n_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2ebindingSyn_str0, 45, "non-exhaustive pattern: no case provided for ");
HEFF_LIT(g_heff_2eelab_2erules_2ebindingSyn_str1, 91, "say what happens where it does not match: `case`, or, in a `do` block, `let p = e else ...`");
V g_heff_2eelab_2erules_2ebindingSyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ebindingSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ebindingSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ebindingSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ebindingSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ebindingSyn_entry, 2, 0};

V g_heff_2eelab_2erules_2ebindingSyn(V v_p_240, V v_s_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ebindingSyn_lam0, 1, 2, (V[]){heff_dup(v_s_241), v_p_240})});
}
V g_heff_2eelab_2erules_2ebindingSyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2ebindingSyn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2ebindingSyn_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_clo_take(self, 3);
    heff_drop_rec(v_hd_245, 3);
    V f_ = v_k_246;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_it1_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Just = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_x_247);
    switch (heff_tag_of(v_it1_2417)) {
    case TAG_MkPair: {
      V v_sp_2418 = heff_field(v_it1_2417, 0);
      V v_what_2419 = heff_field(v_it1_2417, 1);
      heff_take_n(v_it1_2417, 3ULL, 2);
      V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(317LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2ebindingSyn_str0), v_what_2419), v_sp_2418, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2ebindingSyn_str1)})});
      V v_t_2421 = heff_tag_at_n(v_ru_24x_2416_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2422}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2423;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2417);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eelab_2erules_2ebindingSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_p_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_t_2410;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_dup(heff_field(v_x_247, 0));
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_t_2411 = (g_heff_2eelab_2eenvironment_2epartOf(heff_rfield(v_e_242, 0), heff_get_n(v_t_2410, 0, 2)));
  V v_t_2414;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_dup(heff_field(v_x_247, 1));
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  heff_clo_take(self, 4);
  V v_t_2415 = ({ V b_0 = heff_get_n(v_e_242, 0, 8); V a_1 = v_t_2411; V a_2 = v_t_2414; V a_3 = v_p_240; V r_ = (g_heff_2eelab_2erules_2epatternCanFail(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2414); r_; });
  V f_ = v_t_2415;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ebindingSyn_lam3, 1, 3, (V[]){v_k_246, v_x_247, v_hd_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ebindingSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_p_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ebindingSyn_lam2, 1, 4, (V[]){v_e_242, v_p_240, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ebindingSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_p_240 = heff_env(self)[1];
  V v_c_244;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2ebindingSyn_lam1, 2, 3, (V[]){v_c_244, v_e_242, v_p_240});
}
V g_heff_2eelab_2erules_2eupdateSetting_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam5, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam6, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam7, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam8(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam8, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam9, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam10, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam11(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam11, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam12(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam12, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam13(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam13, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam14(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam14, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam15(V self, V *args); static Clo g_heff_2eelab_2erules_2eupdateSetting_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_lam15, 2, 0};
V g_heff_2eelab_2erules_2eupdateSetting_lam21(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam20(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam19(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam18(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam17(V self, V *args);
V g_heff_2eelab_2erules_2eupdateSetting_lam16(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdateSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateSetting_entry, 8, 0};

V g_heff_2eelab_2erules_2eupdateSetting(V v_upd_240, V v_e_241, V v_sp_242, V v_r_243, V v_g_244, V v_a_245, V v_fs_246, V v_x_247) {
top: ;
  V v_it_248 = (g_list_2ekeepIf_24s924780574x2000457388(v_x_247, heff_dup(v_fs_246)));
  switch (heff_tag_of(v_it_248)) {
  case TAG_Nil: {
    heff_drop(v_upd_240);
    heff_drop(v_e_241);
    heff_drop(v_fs_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam0, 2, 5, (V[]){v_x_247, v_sp_242, v_r_243, v_g_244, v_a_245});
  }
  case TAG_Cons: {
    V v_it1_2420 = heff_field(v_it_248, 0);
    V v_it2_2421 = heff_field(v_it_248, 1);
    heff_take_n(v_it_248, 3ULL, 2);
    heff_drop(v_sp_242);
    switch (heff_tag_of(v_it1_2420)) {
    case TAG_UpdateTo: {
      V v_xsp_2423 = heff_field(v_it1_2420, 1);
      V v_fsp_2424 = heff_field(v_it1_2420, 2);
      V v_c_2425 = heff_field(v_it1_2420, 3);
      heff_take_n(v_it1_2420, 14ULL, 4);
      heff_drop(v_upd_240);
      heff_drop(v_e_241);
      heff_drop(v_r_243);
      heff_drop(v_g_244);
      heff_drop(v_a_245);
      switch (heff_tag_of(v_it2_2421)) {
      case TAG_Nil: {
        heff_drop(v_fs_246);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam4, 2, 4, (V[]){v_x_247, v_c_2425, v_fsp_2424, v_xsp_2423});
      }
      case TAG_Cons: {
        heff_take_n(v_it2_2421, 0ULL, 2);
        heff_drop(v_xsp_2423);
        heff_drop(v_fsp_2424);
        heff_drop(v_c_2425);
        return (g_heff_2eelab_2erules_2egivenTwice(v_fs_246, v_x_247));
      }
      default: return heff_nomatch(v_it2_2421);
      }
    }
    case TAG_UpdateIn: {
      V v_xsp_2431 = heff_field(v_it1_2420, 1);
      V v_fsp_2432 = heff_field(v_it1_2420, 2);
      V v_inner_2433 = heff_field(v_it1_2420, 3);
      heff_take_n(v_it1_2420, 14ULL, 4);
      HeffT2 v_t_2434 = ({ V a_0 = v_it2_2421; HeffT2 r_ = (g_heff_2eelab_2erules_2eupdateInner_24cpr(a_0)); heff_drop(v_it2_2421); r_; });
      {
        V v_field_2436 = v_t_2434.f[1];
        int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
        if ((v_tag_2435 == ((int64_t)0ULL))) {
          heff_drop(v_fs_246);
          V v_rest_2437 = v_field_2436;
          V v_e_2438 = v_e_241;
          V v_a_2439 = heff_dup(v_a_245);
          V v_x_2440 = heff_dup(v_x_247);
          V v_xsp_2441 = v_xsp_2431;
          V v_t_2442 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_2439)));
          V v_c_2486;
          switch (heff_tag_of(v_t_2442)) {
          case TAG_LikeU: {
            heff_take_n(v_t_2442, 0ULL, 1);
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam5_clo);
            break;
          }
          case TAG_LikeFunction: {
            heff_take_n(v_t_2442, 0ULL, 4);
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam6_clo);
            break;
          }
          case TAG_LikeRecord: {
            V v_capture_2453 = heff_field(v_t_2442, 1);
            V v_fieldTypes_2454 = heff_field(v_t_2442, 2);
            heff_take_n(v_t_2442, 6ULL, 3);
            HeffT2 v_t_2455 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_fieldTypes_2454, 1), v_x_2440));
            {
              V v_field_2457 = v_t_2455.f[1];
              int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
              V v_t_2459;
              if ((v_tag_2456 == ((int64_t)0ULL))) {
                V v_i_2458 = v_field_2457;
                v_t_2459 = v_i_2458;
              } else {
                heff_drop(v_field_2457);
                v_t_2459 = heff_abandon();
              }
              V v_t_2460 = heff_get_n(heff_dup(heff_rfield(v_e_2438, 0)), 0, 5);
              HeffT2 v_t_2461 = ({ V a_0 = v_t_2460; V a_1 = v_capture_2453; V a_2 = v_fieldTypes_2454; V a_3 = v_t_2459; V a_4 = heff_dup(g_array_2eempty_get()); V a_5 = MK_INT(0LL); HeffT2 r_ = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2460); heff_drop(v_capture_2453); heff_drop_rec(v_fieldTypes_2454, 3); heff_drop(v_t_2459); r_; });
              {
                V v_field_2463 = v_t_2461.f[1];
                int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                if ((v_tag_2462 == ((int64_t)0ULL))) {
                  V v_t_2464 = v_field_2463;
                  v_c_2486 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2erecordName_clo), 5, (V[]){v_e_2438, v_a_2439, v_x_2440, v_xsp_2441, v_t_2464}));
                } else {
                  heff_drop_rec(v_e_2438, 8);
                  heff_drop(v_a_2439);
                  heff_drop(v_x_2440);
                  heff_drop(v_xsp_2441);
                  heff_drop(v_field_2463);
                  v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam7_clo);
                }
              }
            }
            break;
          }
          case TAG_LikeSum: {
            heff_take_n(v_t_2442, 0ULL, 1);
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam8_clo);
            break;
          }
          case TAG_LikeInt: {
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam9_clo);
            break;
          }
          case TAG_LikeFloat: {
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam10_clo);
            break;
          }
          case TAG_LikeString: {
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam11_clo);
            break;
          }
          case TAG_LikeRune: {
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam12_clo);
            break;
          }
          case TAG_LikeArray: {
            heff_take_n(v_t_2442, 0ULL, 1);
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam13_clo);
            break;
          }
          case TAG_LikeFixed: {
            heff_take_n(v_t_2442, 0ULL, 1);
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam14_clo);
            break;
          }
          case TAG_NoRules: {
            heff_drop_rec(v_e_2438, 8);
            heff_drop(v_a_2439);
            heff_drop(v_x_2440);
            heff_drop(v_xsp_2441);
            v_c_2486 = ((V)&g_heff_2eelab_2erules_2eupdateSetting_lam15_clo);
            break;
          }
          default: heff_nomatch(v_t_2442);
          }
          return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam16, 2, 9, (V[]){v_c_2486, v_upd_240, v_fsp_2432, v_r_243, v_g_244, v_a_245, v_x_247, v_inner_2433, v_rest_2437});
        } else {
          heff_drop(v_upd_240);
          heff_drop(v_e_241);
          heff_drop(v_r_243);
          heff_drop(v_g_244);
          heff_drop(v_a_245);
          heff_drop(v_xsp_2431);
          heff_drop(v_fsp_2432);
          heff_drop(v_inner_2433);
          heff_drop(v_field_2436);
          return (g_heff_2eelab_2erules_2egivenTwice(v_fs_246, v_x_247));
        }
      }
    }
    default: return heff_nomatch(v_it1_2420);
    }
  }
  default: return heff_nomatch(v_it_248);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eupdateSetting(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_e_2411 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_fty_2412 = heff_env(self)[3];
  V v_hd_2414 = heff_env(self)[4];
  V v_k_2415 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_MkPair: {
    V v_m_2417 = heff_field(v_x_2416, 0);
    V v_t_2418 = heff_field(v_x_2416, 1);
    heff_take_n(v_x_2416, 3ULL, 2);
    heff_clo_take(self, 6);
    return (g_heff_2eelab_2erules_2esameField(v_sp_242, v_e_2411, v_x_247, v_fty_2412, v_m_2417, v_t_2418, v_hd_2414, v_k_2415));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_e_2411 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_fty_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam3, 1, 6, (V[]){v_sp_242, v_e_2411, v_x_247, v_fty_2412, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam1(V self, V *args) {
  V v_e_2411 = args[0];
  V v_fty_2412 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  V v_g_244 = heff_env(self)[2];
  V v_a_245 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2413 = ({ V a_0 = heff_dup(v_sp_242); V a_1 = heff_dup(v_e_2411); V a_2 = v_r_243; V a_3 = v_g_244; V a_4 = v_a_245; V a_5 = heff_dup(v_x_247); V r_ = (g_heff_2eelab_2erules_2eupdatedField(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_r_243); r_; });
  return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam2, 2, 5, (V[]){v_c_2413, v_sp_242, v_e_2411, v_x_247, v_fty_2412});
}
V g_heff_2eelab_2erules_2eupdateSetting_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_r_243 = heff_env(self)[2];
  V v_g_244 = heff_env(self)[3];
  V v_a_245 = heff_env(self)[4];
  heff_drop(v_hd_249);
  heff_clo_take(self, 5);
  V v_t_2419 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){heff_dup(v_x_247), heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam1, 2, 5, (V[]){heff_dup(v_sp_242), v_r_243, v_g_244, v_a_245, v_x_247})}), v_sp_242, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get())});
  V f_ = v_k_2410;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_c_2425 = heff_env(self)[1];
  V v_fsp_2424 = heff_env(self)[2];
  V v_xsp_2423 = heff_env(self)[3];
  heff_drop(v_hd_2426);
  heff_clo_take(self, 4);
  V f_ = v_k_2427;
  args[0] = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_247, v_c_2425, v_fsp_2424, v_xsp_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam5(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam6(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam7(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  heff_drop(v_hd_2465);
  V f_ = v_k_2466;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam8(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  heff_drop(v_hd_2468);
  V f_ = v_k_2469;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam9(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  heff_drop(v_hd_2470);
  V f_ = v_k_2471;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam10(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  heff_drop(v_hd_2472);
  V f_ = v_k_2473;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam11(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  heff_drop(v_hd_2474);
  V f_ = v_k_2475;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam12(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  heff_drop(v_hd_2476);
  V f_ = v_k_2477;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam13(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  heff_drop(v_hd_2479);
  V f_ = v_k_2480;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam14(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  heff_drop(v_hd_2482);
  V f_ = v_k_2483;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam15(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  heff_drop(v_hd_2484);
  V f_ = v_k_2485;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam21(V self, V *args) {
  V v_x_24106 = args[0];
  V v_sp_2491 = heff_env(self)[0];
  V v_e_2497 = heff_env(self)[1];
  V v_x_2495 = heff_env(self)[2];
  V v_fty_2498 = heff_env(self)[3];
  V v_t_24104 = heff_env(self)[4];
  V v_hd_24100 = heff_env(self)[5];
  V v_k_24101 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2erules_2esameField(v_sp_2491, v_e_2497, v_x_2495, v_fty_2498, v_x_24106, v_t_24104, v_hd_24100, v_k_24101));
}
V g_heff_2eelab_2erules_2eupdateSetting_lam20(V self, V *args) {
  V v_x_24102 = args[0];
  V v_upd_2490 = heff_env(self)[0];
  V v_sp_2491 = heff_env(self)[1];
  V v_r_2492 = heff_env(self)[2];
  V v_e_2497 = heff_env(self)[3];
  V v_fs_2496 = heff_env(self)[4];
  V v_hd_24100 = heff_env(self)[5];
  V v_x_2495 = heff_env(self)[6];
  V v_fty_2498 = heff_env(self)[7];
  V v_k_24101 = heff_env(self)[8];
  switch (heff_tag_of(v_x_24102)) {
  case TAG_MkPair: {
    V v_m_24103 = heff_field(v_x_24102, 0);
    V v_t_24104 = heff_field(v_x_24102, 1);
    heff_take_n(v_x_24102, 3ULL, 2);
    heff_clo_take(self, 9);
    V v_c_24105 = heff_tr(heff_call(v_upd_2490, 6, (V[]){heff_dup(v_sp_2491), v_r_2492, heff_dup(v_e_2497), v_m_24103, heff_dup(v_t_24104), v_fs_2496}));
    V f_ = v_c_24105;
    heff_room[0] = heff_dup(v_hd_24100);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam21, 1, 7, (V[]){v_sp_2491, v_e_2497, v_x_2495, v_fty_2498, v_t_24104, v_hd_24100, v_k_24101});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24102);
  }
}
V g_heff_2eelab_2erules_2eupdateSetting_lam19(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_c_2499 = heff_env(self)[0];
  V v_upd_2490 = heff_env(self)[1];
  V v_sp_2491 = heff_env(self)[2];
  V v_r_2492 = heff_env(self)[3];
  V v_e_2497 = heff_env(self)[4];
  V v_fs_2496 = heff_env(self)[5];
  V v_x_2495 = heff_env(self)[6];
  V v_fty_2498 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2499;
  args[0] = heff_dup(v_hd_24100);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam20, 1, 9, (V[]){v_upd_2490, v_sp_2491, v_r_2492, v_e_2497, v_fs_2496, v_hd_24100, v_x_2495, v_fty_2498, v_k_24101});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam18(V self, V *args) {
  V v_e_2497 = args[0];
  V v_fty_2498 = args[1];
  V v_sp_2491 = heff_env(self)[0];
  V v_r_2492 = heff_env(self)[1];
  V v_g_2493 = heff_env(self)[2];
  V v_a_2494 = heff_env(self)[3];
  V v_x_2495 = heff_env(self)[4];
  V v_upd_2490 = heff_env(self)[5];
  V v_fs_2496 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2499 = (g_heff_2eelab_2erules_2eupdatedField(heff_dup(v_sp_2491), heff_dup(v_e_2497), v_r_2492, v_g_2493, v_a_2494, heff_dup(v_x_2495)));
  return heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam19, 2, 8, (V[]){v_c_2499, v_upd_2490, v_sp_2491, v_r_2492, v_e_2497, v_fs_2496, v_x_2495, v_fty_2498});
}
V g_heff_2eelab_2erules_2eupdateSetting_lam17(V self, V *args) {
  V v_x_2489 = args[0];
  V v_upd_240 = heff_env(self)[0];
  V v_fsp_2432 = heff_env(self)[1];
  V v_r_243 = heff_env(self)[2];
  V v_g_244 = heff_env(self)[3];
  V v_a_245 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  V v_inner_2433 = heff_env(self)[6];
  V v_rest_2437 = heff_env(self)[7];
  V v_k_2488 = heff_env(self)[8];
  heff_drop(v_x_2489);
  heff_clo_take(self, 9);
  V v_upd_2490 = v_upd_240;
  V v_sp_2491 = heff_dup(v_fsp_2432);
  V v_r_2492 = v_r_243;
  V v_g_2493 = v_g_244;
  V v_a_2494 = v_a_245;
  V v_x_2495 = heff_dup(v_x_247);
  V v_fs_2496 = (g_heff_2eelab_2erules_2eappendP(v_inner_2433, v_rest_2437));
  V v_x_24107 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_247, heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam18, 2, 7, (V[]){v_sp_2491, v_r_2492, v_g_2493, v_a_2494, v_x_2495, v_upd_2490, v_fs_2496})}), v_fsp_2432, heff_dup(g_heff_2eelab_2eparams_2enoSpan_get())});
  V f_ = v_k_2488;
  args[0] = v_x_24107;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdateSetting_lam16(V self, V *args) {
  V v_hd_2487 = args[0];
  V v_k_2488 = args[1];
  V v_c_2486 = heff_env(self)[0];
  V v_upd_240 = heff_env(self)[1];
  V v_fsp_2432 = heff_env(self)[2];
  V v_r_243 = heff_env(self)[3];
  V v_g_244 = heff_env(self)[4];
  V v_a_245 = heff_env(self)[5];
  V v_x_247 = heff_env(self)[6];
  V v_inner_2433 = heff_env(self)[7];
  V v_rest_2437 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2486;
  args[0] = v_hd_2487;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eupdateSetting_lam17, 1, 9, (V[]){v_upd_240, v_fsp_2432, v_r_243, v_g_244, v_a_245, v_x_247, v_inner_2433, v_rest_2437, v_k_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}