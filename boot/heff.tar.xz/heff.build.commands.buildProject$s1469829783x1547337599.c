// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_bad 306815
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str0, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str1, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str2, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str3, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str4, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0(V v_hd_240, V v_st_241, V v_t_242, V v_cmd_243, V v_k_244, V v_none_245, V v_done_246, V v_x_247) {
top: ;
  V v_x_2410;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Left: {
    heff_take_n(v_x_247, 0ULL, 1);
    v_x_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_249 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Right = heff_take_reuse_n(v_x_247, 1ULL, 1);
    v_x_2410 = heff_tag_at_n(v_ru_24x_247_24Right, TAG_Just, 1, (V[]){v_y_249});
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_t_2412;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_dup(heff_field(v_x_2410, 0));
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_total_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str0), v_total_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam0_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s535099379x685970669(v_t_2416, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam1, 1, 8, (V[]){v_x_2410, v_st_241, v_t_242, v_hd_240, v_cmd_243, v_k_244, v_none_245, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam0(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2438);
  V v_t_2439 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_240, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_bad_2422 = heff_env(self)[0];
  V v_cmd_243 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_apps_2423 = heff_env(self)[4];
  V v_none_245 = heff_env(self)[5];
  V v_st_241 = heff_env(self)[6];
  V v_t_242 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_drop(v_x_2426);
  if (heff_intLt_c_lent(MK_INT(0LL), v_bad_2422, 1)) {
    heff_clo_take(self, 9);
    heff_drop(v_apps_2423);
    heff_drop(v_none_245);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_done_246);
    V v_n_2427 = v_bad_2422;
    V v_t_2428;
    if (heff_intEq_c_lent(v_n_2427, MK_INT(1LL), 2)) {
      heff_drop(v_n_2427);
      v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str1);
    } else {
      v_t_2428 = heff_strAppend(heff_intShow(v_n_2427), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str2));
    }
    V v_what_2429 = heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str3));
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str4), v_cmd_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str5));
    V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, v_what_2429), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str6));
    V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_str7)), NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam4, 1, 2, (V[]){v_hd_240, v_k_244})));
  } else {
    heff_clo_take(self, 9);
    heff_drop(v_bad_2422);
    heff_drop(v_cmd_243);
    V v_t_2445 = heff_dup(v_apps_2423);
    switch (heff_tag_of(v_t_2445)) {
    case TAG_Nil: {
      heff_drop(v_apps_2423);
      heff_drop(v_st_241);
      heff_drop(v_t_242);
      heff_drop(v_done_246);
      V f_ = v_none_245;
      heff_room[0] = v_hd_240;
      heff_room[1] = v_k_244;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2445, 0ULL, 2);
      heff_drop(v_none_245);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584(v_st_241, v_t_242, v_done_246, v_apps_2423, v_hd_240, v_k_244));
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_cmd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_none_245 = heff_env(self)[4];
  V v_st_241 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_246 = heff_env(self)[7];
  V v_bad_2422 = heff_take_field(v_x_2421, 1);
  V v_apps_2423 = heff_get_n(v_x_2421, 0, 2);
  heff_clo_take(self, 8);
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam3, 1, 9, (V[]){v_bad_2422, v_cmd_243, v_hd_240, v_k_244, v_apps_2423, v_none_245, v_st_241, v_t_242, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  V v_cmd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_none_245 = heff_env(self)[6];
  V v_done_246 = heff_env(self)[7];
  V v_t_2419;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2418 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_t_2419 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2420 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  return (g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(v_x_2417), v_t_2420, v_t_2419, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_lam2, 1, 8, (V[]){v_x_2417, v_hd_240, v_cmd_243, v_k_244, v_none_245, v_st_241, v_t_242, v_done_246})));
}