// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_F32 16337
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkCode 2932
#define TAG_MkDef 57825
#define TAG_PerformAt 64592
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_ems 310085
#define LBL_entry 298026124
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_fun 311289
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_name 9869138
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_tuples 1084651734
#define LBL_ver 326173
#define LBL_wrapper 1827365593
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_tags__lbls__facts[] = {LBL_tags, LBL_lbls, LBL_facts};
V g_heff_2ecompile_2eemitc_2ecallArgs(V, V);
V g_heff_2ecompile_2eemitc_2ecallArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallArgs_clo;
V g_heff_2ecompile_2eemitc_2ecallLent(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallLent_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
HeffT6 g_heff_2ecompile_2eemitc_2eckOf_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eemitc_2edefC_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2eemitAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitAt_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2eglueCallOf(V);
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo;
V g_heff_2ecompile_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo;
V g_heff_2ecompile_2eemitc_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2enumbered(V, V, V);
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbered_clo;
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2estaticOf(V, V, V);
V g_heff_2ecompile_2eemitc_2estaticOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estaticOf_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
HeffT2 g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eunboxed(V);
V g_heff_2ecompile_2eemitc_2eunboxed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxed_clo;
V g_heff_2ecompile_2eemitc_2eunboxedC(V, V);
V g_heff_2ecompile_2eemitc_2eunboxedC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxedC_clo;
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
V g_heff_2ecompile_2efacts_2esureOnlyHere(V, V, V);
V g_heff_2ecompile_2efacts_2esureOnlyHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureOnlyHere_clo;
HeffT4 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
V g_heff_2ecompile_2elower_2ercOf(V, V);
V g_heff_2ecompile_2elower_2ercOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ercOf_clo;
V g_heff_2ecompile_2eowned_2elendingPrim(V);
V g_heff_2ecompile_2eowned_2elendingPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2elendingPrim_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eall_24s2069645224x1221092236(V);
V g_list_2eall_24s2069645224x1221092236_entry(V self, V *a);
extern Clo g_list_2eall_24s2069645224x1221092236_clo;
V g_list_2eany_24s63755471x810534073(V, V);
V g_list_2eany_24s63755471x810534073_entry(V self, V *a);
extern Clo g_list_2eany_24s63755471x810534073_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s478006518x1380334353(V);
V g_list_2ekeepIf_24s478006518x1380334353_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1613211967x1923010103(V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2ezipWith_24s952564628x174753269(V, V, V, V, V);
V g_list_2ezipWith_24s952564628x174753269_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s952564628x174753269_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_prelude_2etraverse_24s428640578x580976168(V, V);
V g_prelude_2etraverse_24s428640578x580976168_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s428640578x580976168_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2eemitc_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbered_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_m_242, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_n_240;
        V t_1 = v_xs_244;
        V t_2 = v_m_242;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_m_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, v_x_243, v_n_240));
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_xs_244;
        V t_2 = v_t_249;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_m_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enumbered(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str2, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str3, 12, ")((uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str5, 11, " (uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str6, 2, "))");
Clo g_heff_2ecompile_2eemitc_2ewrapped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapped_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewrapped(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
  V v_t_246;
  switch (heff_tag_of(v_vs_242)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_vs_242, 0);
    v_t_246 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_vs_242);
  }
  HeffT3 v_t_247 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
  {
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_t_2413;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_249;
      V v_x12_2412 = v_field_2410;
      heff_drop(v_x12_2412);
      v_t_2413 = v_x_2411;
    } else {
      heff_drop(v_field_249);
      heff_drop(v_field_2410);
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str1);
    }
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str2), v_t_243), ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str3));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, v_t_246), ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str4));
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, v_op_241), ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str5));
    return heff_strAppend(heff_strAppend(v_t_2416, v_t_2413), ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str6));
  }
}
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ewrapped(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str3, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str4, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str7, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str8, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str9, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str11, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str12, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str13, 7, "_get())");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str15, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str16, 6, "_get()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str17, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str18, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str19, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str20, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str21, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str22, 13, "heff_flt(NAN)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str23, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str24, 18, "heff_flt(INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str25, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str26, 19, "heff_flt(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str27, 9, "heff_flt(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str29, 8, "HEFF_LIT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str30, 10, "HEFF_BYTES");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str31, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str32, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str33, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str34, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str35, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str36, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str37, 16, "heff_f32((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str38, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str39, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str40, 5, "NTAG(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str41, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str42, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str43, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str44, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str45, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str46, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str47, 3, "){{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str48, 3, "}})");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str49, 11, "heff_tag_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str50, 12, "heff_tag_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str51, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str52, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str53, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str54, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str55, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str56, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str57, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str58, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str59, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str60, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str61, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str62, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str63, 15, "heff_tag_at_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str64, 14, "heff_tag_re_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str65, 14, "heff_tag_at_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str66, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str67, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str68, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str69, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str70, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str71, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str72, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str73, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str74, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str75, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str76, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str77, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str78, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str79, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str80, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str81, 11, "heff_rec_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str82, 12, "heff_rec_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str83, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str84, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str85, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str86, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str87, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str88, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str89, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str90, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str91, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str92, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str93, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str94, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str95, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str96, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str97, 5, "V rv_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str98, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str99, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str100, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str101, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str102, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str103, 17, "heff_rfield(rr_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str104, 7, ") = rv_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str105, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str106, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str107, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str108, 3, "({ ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str109, 24, "V rr_ = heff_rec_reuse_n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str110, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str111, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str112, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str113, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str114, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str115, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str116, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str117, 7, "rr_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str118, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str119, 12, "heff_rfield(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str120, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str121, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str122, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str123, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str124, 12, "heff_rget_v(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str125, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str126, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str127, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str128, 11, "heff_get_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str129, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str130, 11, "heff_rflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str131, 10, "heff_rget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str132, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str133, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str134, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str135, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str136, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str137, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str138, 15, "heff_get_nflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str139, 11, "heff_get_n_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str140, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str141, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str142, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str143, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str144, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str145, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str146, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str147, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str148, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str149, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str150, 10, "heff_word_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str151, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str152, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str153, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str154, 16, "heff_take_field(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str155, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str156, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str157, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str158, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str159, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str160, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str161, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str162, 9, "heff_get(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str163, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str164, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str165, 15, "heff_performAt(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str166, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str167, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str168, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str169, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str170, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str171, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str172, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str173, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str174, 8, "heff_tr(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str175, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str176, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str177, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str178, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str179, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str180, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str181, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str182, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str183, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str184, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str185, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str186, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str187, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str188, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str189, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str190, 18, "heff_tr(heff_call(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str191, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str192, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str193, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str194, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str195, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str196, 14, "heff_abandon()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str197, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str198, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str199, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str200, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str201, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str202, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str203, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str204, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str205, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str206, 11, "heff_unbox_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str207, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str208, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str209, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str210, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str211, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str212, 10, "heff_peek_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str213, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str214, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str215, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str216, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str217, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str218, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str219, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str220, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str221, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str222, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str223, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str224, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str225, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str226, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str227, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str228, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str229, 2, ")-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str230, 4, "ULL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str231, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str232, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str233, 4, "ULL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str234, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str235, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str236, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str237, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str238, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str239, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str240, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str241, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str242, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str243, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str244, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str245, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str246, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str247, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str248, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str249, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str250, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str251, 1, ")");
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2eexpF_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_lam28, 1, 0};
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam34(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam35(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam36(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eexpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eexpF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_243 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_242); r_; });
    V v_x_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str1), v_t_243);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_RDup: {
    V v_x_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_247 = ({ V a_0 = v_x_246; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str2); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_246); r_; });
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str3), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str4), v_t_247));
    V v_x_249 = heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str5));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam1, 1, 1, (V[]){v_x_249});
  }
  case TAG_RClo: {
    V v_g_2411 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2412 = ({ V a_0 = v_g_2411; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str6); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2411); r_; });
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str7), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str8), v_t_2412));
    V v_x_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str9));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam2, 1, 1, (V[]){v_x_2414});
  }
  case TAG_RGet: {
    V v_g_2416 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2417 = ({ V a_0 = v_g_2416; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str10); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2416); r_; });
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str11), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str12), v_t_2417));
    V v_x_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str13));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam3, 1, 1, (V[]){v_x_2419});
  }
  case TAG_RGetRaw: {
    V v_g_2421 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2422 = ({ V a_0 = v_g_2421; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str14); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2421); r_; });
    V v_x_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str15), v_t_2422), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str16));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam4, 1, 1, (V[]){v_x_2423});
  }
  case TAG_RInt: {
    V v_n_2425 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam5, 1, 1, (V[]){v_n_2425});
  }
  case TAG_RFloat: {
    V v_x_2430 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam6, 1, 1, (V[]){v_x_2430});
  }
  case TAG_RStr: {
    V v_s_2434 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str29), v_s_2434});
  }
  case TAG_RBytes: {
    V v_s_2435 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str30), v_s_2435});
  }
  case TAG_RFixed: {
    V v_w_2436 = heff_field(v_x2_241, 0);
    V v_n_2437 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_w_2438 = v_w_2436;
    V v_n_2439 = v_n_2437;
    int64_t v_t_2440;
    switch (heff_tag_of(v_w_2438)) {
    case TAG_I8: {
      v_t_2440 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2440 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2440 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2440 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2440 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2440 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2440 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2440 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2440 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_2438);
    }
    V v_x_2444;
    if ((v_t_2440 == ((int64_t)64ULL))) {
      if ((heff_intLt_c_lent(v_n_2439, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_2439, 1))) {
        V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str31), heff_intShow(v_n_2439));
        v_x_2444 = heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str32));
      } else {
        V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str33), heff_intShow(v_n_2439));
        v_x_2444 = heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str34));
      }
    } else {
      V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str35), heff_intShow(v_n_2439));
      v_x_2444 = heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str36));
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam7, 1, 1, (V[]){v_x_2444});
  }
  case TAG_RF32: {
    V v_x_2446 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam8, 1, 1, (V[]){v_x_2446});
  }
  case TAG_RNTag: {
    V v_t_2449 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2450 = ({ V a_0 = v_t_2449; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str39); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2449); r_; });
    V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str40), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str41), v_t_2450));
    V v_x_2452 = heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str42));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam9, 1, 1, (V[]){v_x_2452});
  }
  case TAG_RStatic: {
    V v_x_2454 = heff_field(v_x2_241, 0);
    V v_e_2455 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return ({ V a_0 = v_k_240; V a_1 = v_x_2454; V a_2 = v_e_2455; V r_ = (g_heff_2ecompile_2eemitc_2estaticOf(a_0, a_1, a_2)); heff_drop(v_x_2454); r_; });
  }
  case TAG_RTag: {
    V v_t_2456 = heff_field(v_x2_241, 0);
    V v_flat_2457 = heff_field(v_x2_241, 1);
    V v_es_2458 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2459 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_dup(v_es_2458)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam10, 1, 4, (V[]){v_m_2459, v_t_2456, v_es_2458, v_flat_2457});
  }
  case TAG_RTagIn: {
    V v_ru_2485 = heff_field(v_x2_241, 0);
    V v_t_2486 = heff_field(v_x2_241, 1);
    V v_flat_2487 = heff_field(v_x2_241, 2);
    V v_sm_2488 = heff_field(v_x2_241, 3);
    V v_es_2489 = heff_field(v_x2_241, 4);
    heff_take_n(v_x2_241, 31ULL, 5);
    V v_f_2490 = heff_get_n(v_k_240, 0, 6);
    V v_m_2491 = heff_tr(heff_call(heff_dup(v_f_2490), 1, (V[]){v_ru_2485}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam11, 1, 6, (V[]){v_m_2491, v_f_2490, v_es_2489, v_flat_2487, v_sm_2488, v_t_2486});
  }
  case TAG_RRec: {
    V v_ls_24121 = heff_field(v_x2_241, 0);
    V v_flat_24122 = heff_field(v_x2_241, 1);
    V v_es_24123 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24124 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24123));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam12, 1, 3, (V[]){v_m_24124, v_ls_24121, v_flat_24122});
  }
  case TAG_RRecIn: {
    V v_x_24148 = heff_field(v_x2_241, 0);
    V v_keep_24149 = heff_field(v_x2_241, 1);
    V v_kept_24150 = heff_field(v_x2_241, 2);
    V v_flat_24151 = heff_field(v_x2_241, 3);
    V v_n_24152 = heff_field(v_x2_241, 4);
    V v_ls_24153 = heff_field(v_x2_241, 5);
    V v_changed_24154 = heff_field(v_x2_241, 6);
    V v_su_24155 = heff_field(v_x2_241, 7);
    heff_take_n(v_x2_241, 255ULL, 8);
    V v_t_24156 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_changed_24154)));
    V v_m_24157 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_t_24156));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam13, 1, 9, (V[]){v_m_24157, v_ls_24153, v_su_24155, v_x_24148, v_keep_24149, v_kept_24150, v_flat_24151, v_n_24152, v_changed_24154});
  }
  case TAG_RField: {
    V v_e_24195 = heff_field(v_x2_241, 0);
    V v_i_24196 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24197 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24195}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam14, 1, 2, (V[]){v_m_24197, v_i_24196});
  }
  case TAG_RDupE: {
    V v_e_24204 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24205 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24204}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam15, 1, 1, (V[]){v_m_24205});
  }
  case TAG_RFieldV: {
    V v_e_24211 = heff_field(v_x2_241, 0);
    V v_i_24212 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24213 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24211}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam16, 1, 2, (V[]){v_m_24213, v_i_24212});
  }
  case TAG_RGetN: {
    V v_e_24220 = heff_field(v_x2_241, 0);
    V v_i_24221 = heff_field(v_x2_241, 1);
    V v_n_24222 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24223 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24220}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam17, 1, 3, (V[]){v_m_24223, v_i_24221, v_n_24222});
  }
  case TAG_RFieldU: {
    V v_r_24231 = heff_field(v_x2_241, 0);
    V v_su_24232 = heff_field(v_x2_241, 1);
    V v_e_24233 = heff_field(v_x2_241, 2);
    V v_i_24234 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_24235;
    if ((heff_dup(v_su_24232) == NTAG(TAG_True))) {
      heff_drop(v_su_24232);
      v_t_24235 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str130);
    } else {
      heff_drop(v_su_24232);
      v_t_24235 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str131);
    }
    V v_t_24237;
    switch (heff_tag_of(v_r_24231)) {
    case TAG_RepV: {
      v_t_24237 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str132);
      break;
    }
    case TAG_RepFix: {
      V v_w_24236 = heff_field(v_r_24231, 0);
      heff_take_n(v_r_24231, 1ULL, 1);
      v_t_24237 = ({ V a_0 = v_w_24236; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24236); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24237 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str133);
      break;
    }
    case TAG_RepInt: {
      v_t_24237 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str134);
      break;
    }
    default: heff_nomatch(v_r_24231);
    }
    V v_pre_24238 = heff_strAppend(heff_strAppend(v_t_24235, v_t_24237), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str135));
    V v_m_24239 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24233}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam18, 1, 3, (V[]){v_m_24239, v_i_24234, v_pre_24238});
  }
  case TAG_RGetNU: {
    V v_r_24246 = heff_field(v_x2_241, 0);
    V v_su_24247 = heff_field(v_x2_241, 1);
    V v_e_24248 = heff_field(v_x2_241, 2);
    V v_i_24249 = heff_field(v_x2_241, 3);
    V v_n_24250 = heff_field(v_x2_241, 4);
    heff_take_n(v_x2_241, 31ULL, 5);
    V v_t_24251;
    if ((heff_dup(v_su_24247) == NTAG(TAG_True))) {
      heff_drop(v_su_24247);
      v_t_24251 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str138);
    } else {
      heff_drop(v_su_24247);
      v_t_24251 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str139);
    }
    V v_t_24253;
    switch (heff_tag_of(v_r_24246)) {
    case TAG_RepV: {
      v_t_24253 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str140);
      break;
    }
    case TAG_RepFix: {
      V v_w_24252 = heff_field(v_r_24246, 0);
      heff_take_n(v_r_24246, 1ULL, 1);
      v_t_24253 = ({ V a_0 = v_w_24252; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24252); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24253 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str141);
      break;
    }
    case TAG_RepInt: {
      v_t_24253 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str142);
      break;
    }
    default: heff_nomatch(v_r_24246);
    }
    V v_pre_24254 = heff_strAppend(heff_strAppend(v_t_24251, v_t_24253), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str143));
    V v_m_24255 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24248}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam19, 1, 4, (V[]){v_m_24255, v_i_24249, v_n_24250, v_pre_24254});
  }
  case TAG_RWord: {
    V v_r_24263 = heff_field(v_x2_241, 0);
    V v_e_24264 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24266;
    switch (heff_tag_of(v_r_24263)) {
    case TAG_RepV: {
      v_t_24266 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str147);
      break;
    }
    case TAG_RepFix: {
      V v_w_24265 = heff_field(v_r_24263, 0);
      heff_take_n(v_r_24263, 1ULL, 1);
      v_t_24266 = ({ V a_0 = v_w_24265; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24265); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24266 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str148);
      break;
    }
    case TAG_RepInt: {
      v_t_24266 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str149);
      break;
    }
    default: heff_nomatch(v_r_24263);
    }
    V v_pre_24267 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str150), v_t_24266), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str151));
    V v_m_24268 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24264}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam20, 1, 2, (V[]){v_m_24268, v_pre_24267});
  }
  case TAG_RTakeField: {
    V v_x_24274 = heff_field(v_x2_241, 0);
    V v_i_24275 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_t_24276 = ({ V a_0 = v_x_24274; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str153); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_24274); r_; });
    V v_t_24277 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str154), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str155), v_t_24276));
    V v_t_24278 = heff_strAppend(heff_strAppend(v_t_24277, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str156)), heff_intShow(v_i_24275));
    V v_x_24279 = heff_strAppend(v_t_24278, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str157));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam21, 1, 1, (V[]){v_x_24279});
  }
  case TAG_RGetLabel: {
    V v_e_24281 = heff_field(v_x2_241, 0);
    V v_l_24282 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24283 = ({ V a_0 = v_l_24282; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str158); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_l_24282); r_; });
    V v_t_24284 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str159), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str160), v_t_24283));
    V v_post_24285 = heff_strAppend(v_t_24284, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str161));
    V v_m_24286 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24281}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam22, 1, 2, (V[]){v_m_24286, v_post_24285});
  }
  case TAG_RPrimFn: {
    V v_p_24292 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2eprimLit_clo), 1, (V[]){v_p_24292});
  }
  case TAG_RPrim: {
    V v_x21_24293 = heff_field(v_x2_241, 0);
    V v_es_24294 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_24293)) {
    case TAG_PerformAt: {
      V v_i_24295 = heff_field(v_x21_24293, 0);
      heff_take_n(v_x21_24293, 1ULL, 1);
      V v_m_24296 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24294));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam23, 1, 2, (V[]){v_m_24296, v_i_24295});
    }
    default: {
      V v_t_24307 = (g_heff_2ecompile_2eowned_2elendingPrim(v_x21_24293));
      V v_t_24309;
      if ((heff_dup(v_t_24307) == NTAG(TAG_True))) {
        heff_drop(v_t_24307);
        V v_t_24308 = (g_list_2eall_24s2069645224x1221092236(v_es_24294));
        if ((heff_dup(v_t_24308) == NTAG(TAG_True))) {
          heff_drop(v_t_24308);
          v_t_24309 = (g_list_2eany_24s63755471x810534073(v_es_24294, v_es_24294));
        } else {
          heff_drop(v_t_24308);
          v_t_24309 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_t_24307);
        v_t_24309 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24309) == NTAG(TAG_True))) {
        heff_drop(v_t_24309);
        return ({ V a_0 = v_k_240; V a_1 = v_x21_24293; V a_2 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str168); V a_3 = v_es_24294; V r_ = (g_heff_2ecompile_2eemitc_2elentPrimC(a_0, a_1, a_2, a_3)); heff_drop(v_x21_24293); r_; });
      } else {
        heff_drop(v_t_24309);
        V v_m_24310 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24294));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam24, 1, 2, (V[]){v_m_24310, v_x21_24293});
      }
    }
    }
  }
  case TAG_RLam: {
    V v_xs_24321 = heff_field(v_x2_241, 0);
    V v_fv_24322 = heff_field(v_x2_241, 1);
    V v_held_24323 = heff_field(v_x2_241, 2);
    V v_x24_24324 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x24_24324)) {
    case TAG_MkCode: {
      V v_body_24325 = heff_field(v_x24_24324, 0);
      heff_take_n(v_x24_24324, 1ULL, 1);
      return heff_tail(((V)&g_heff_2ecompile_2eemitc_2elamC_clo), 5, (V[]){v_k_240, v_xs_24321, v_fv_24322, v_held_24323, v_body_24325});
    }
    default: return heff_nomatch(v_x24_24324);
    }
  }
  case TAG_RCall: {
    V v_g_24326 = heff_field(v_x2_241, 0);
    V v_tr_24327 = heff_field(v_x2_241, 1);
    V v_w_24328 = heff_field(v_x2_241, 2);
    V v_args_24329 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_k_24330 = v_k_240;
    V v_g_24331 = v_g_24326;
    V v_tr_24332 = v_tr_24327;
    V v_w_24333 = v_w_24328;
    V v_args_24334 = v_args_24329;
    V v_t_24335 = (g_list_2eall_24s1793250635x935291087(v_args_24334));
    if ((heff_dup(v_t_24335) == NTAG(TAG_True))) {
      heff_drop(v_t_24335);
      V v_t_24336 = (g_list_2emap_24s976303750x321235480(v_args_24334));
      V v_m_24337 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_24330, 0, 6), v_t_24336));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam25, 1, 4, (V[]){v_m_24337, v_tr_24332, v_w_24333, v_g_24331});
    } else {
      heff_drop(v_t_24335);
      return ({ V a_0 = v_k_24330; V a_1 = v_g_24331; V a_2 = v_tr_24332; V a_3 = v_w_24333; V a_4 = v_args_24334; V r_ = (g_heff_2ecompile_2eemitc_2ecallLent(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_24331); heff_drop(v_tr_24332); heff_drop(v_w_24333); r_; });
    }
  }
  case TAG_RApply: {
    V v_f_24352 = heff_field(v_x2_241, 0);
    V v_es_24353 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_f_24354 = heff_get_n(v_k_240, 0, 6);
    V v_m_24355 = heff_tr(heff_call(heff_dup(v_f_24354), 1, (V[]){v_f_24352}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam26, 1, 3, (V[]){v_m_24355, v_f_24354, v_es_24353});
  }
  case TAG_RBool: {
    V v_c_24379 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24380 = ({ V a_0 = v_k_240; V a_1 = v_c_24379; V r_ = (g_heff_2ecompile_2eemitc_2etestC(a_0, a_1)); heff_drop_rec(v_k_240, 6); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam27, 1, 1, (V[]){v_m_24380});
  }
  case TAG_RAbandon: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2eexpF_lam28_clo);
  }
  case TAG_RBox: {
    V v_r_24387 = heff_field(v_x2_241, 0);
    V v_e_24388 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24390;
    switch (heff_tag_of(v_r_24387)) {
    case TAG_RepV: {
      v_t_24390 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str197);
      break;
    }
    case TAG_RepFix: {
      V v_w_24389 = heff_field(v_r_24387, 0);
      heff_take_n(v_r_24387, 1ULL, 1);
      v_t_24390 = ({ V a_0 = v_w_24389; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24389); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24390 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str198);
      break;
    }
    case TAG_RepInt: {
      v_t_24390 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str199);
      break;
    }
    default: heff_nomatch(v_r_24387);
    }
    V v_pre_24391 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str200), v_t_24390), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str201));
    V v_m_24392 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24388}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam29, 1, 2, (V[]){v_m_24392, v_pre_24391});
  }
  case TAG_RUnbox: {
    V v_r_24398 = heff_field(v_x2_241, 0);
    V v_e_24399 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24401;
    switch (heff_tag_of(v_r_24398)) {
    case TAG_RepV: {
      v_t_24401 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str203);
      break;
    }
    case TAG_RepFix: {
      V v_w_24400 = heff_field(v_r_24398, 0);
      heff_take_n(v_r_24398, 1ULL, 1);
      v_t_24401 = ({ V a_0 = v_w_24400; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24400); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24401 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str204);
      break;
    }
    case TAG_RepInt: {
      v_t_24401 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str205);
      break;
    }
    default: heff_nomatch(v_r_24398);
    }
    V v_pre_24402 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str206), v_t_24401), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str207));
    V v_m_24403 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24399}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam30, 1, 2, (V[]){v_m_24403, v_pre_24402});
  }
  case TAG_RPeek: {
    V v_r_24409 = heff_field(v_x2_241, 0);
    V v_e_24410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24412;
    switch (heff_tag_of(v_r_24409)) {
    case TAG_RepV: {
      v_t_24412 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str209);
      break;
    }
    case TAG_RepFix: {
      V v_w_24411 = heff_field(v_r_24409, 0);
      heff_take_n(v_r_24409, 1ULL, 1);
      v_t_24412 = ({ V a_0 = v_w_24411; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24411); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24412 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str210);
      break;
    }
    case TAG_RepInt: {
      v_t_24412 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str211);
      break;
    }
    default: heff_nomatch(v_r_24409);
    }
    V v_pre_24413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str212), v_t_24412), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str213));
    V v_m_24414 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24410}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam31, 1, 2, (V[]){v_m_24414, v_pre_24413});
  }
  case TAG_RPrimU: {
    V v_p_24420 = heff_field(v_x2_241, 0);
    V v_es_24421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24422 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24421));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam32, 1, 2, (V[]){v_m_24422, v_p_24420});
  }
  case TAG_RPrimAt: {
    V v_p_24429 = heff_field(v_x2_241, 0);
    V v_r_24430 = heff_field(v_x2_241, 1);
    V v_es_24431 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_24432 = (g_heff_2ecompile_2eowned_2elendingPrim(v_p_24429));
    V v_t_24434;
    if ((heff_dup(v_t_24432) == NTAG(TAG_True))) {
      heff_drop(v_t_24432);
      V v_t_24433 = (g_list_2eall_24s2069645224x1221092236(v_es_24431));
      if ((heff_dup(v_t_24433) == NTAG(TAG_True))) {
        heff_drop(v_t_24433);
        v_t_24434 = (g_list_2eany_24s63755471x810534073(v_es_24431, v_es_24431));
      } else {
        heff_drop(v_t_24433);
        v_t_24434 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_24432);
      v_t_24434 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24434) == NTAG(TAG_True))) {
      heff_drop(v_t_24434);
      V v_t_24436;
      switch (heff_tag_of(v_r_24430)) {
      case TAG_RepV: {
        v_t_24436 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str215);
        break;
      }
      case TAG_RepFix: {
        V v_w_24435 = heff_field(v_r_24430, 0);
        heff_take_n(v_r_24430, 1ULL, 1);
        v_t_24436 = ({ V a_0 = v_w_24435; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24435); r_; });
        break;
      }
      case TAG_RepF64: {
        v_t_24436 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str216);
        break;
      }
      case TAG_RepInt: {
        v_t_24436 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str217);
        break;
      }
      default: heff_nomatch(v_r_24430);
      }
      return ({ V a_0 = v_k_240; V a_1 = v_p_24429; V a_2 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str218), v_t_24436); V a_3 = v_es_24431; V r_ = (g_heff_2ecompile_2eemitc_2elentPrimC(a_0, a_1, a_2, a_3)); heff_drop(v_p_24429); r_; });
    } else {
      heff_drop(v_t_24434);
      V v_m_24437 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24431));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam33, 1, 3, (V[]){v_m_24437, v_p_24429, v_r_24430});
    }
  }
  case TAG_RFixU: {
    V v_w_24451 = heff_field(v_x2_241, 0);
    V v_n_24452 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_w_24453 = v_w_24451;
    V v_n_24454 = v_n_24452;
    V v_x_24461;
    if (heff_intLt_c_lent(v_n_24454, MK_INT(0LL), 2)) {
      V v_t_24455 = ({ V a_0 = v_w_24453; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_24453); r_; });
      V v_t_24456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str228), v_t_24455), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str229));
      V v_t_24457 = heff_intShow(heff_intSub(MK_INT(0LL), v_n_24454));
      v_x_24461 = heff_strAppend(heff_strAppend(v_t_24456, v_t_24457), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str230));
    } else {
      V v_t_24458 = ({ V a_0 = v_w_24453; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_24453); r_; });
      V v_t_24459 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str231), v_t_24458), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str232));
      V v_t_24460 = heff_strAppend(v_t_24459, heff_intShow(v_n_24454));
      v_x_24461 = heff_strAppend(v_t_24460, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str233));
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam34, 1, 1, (V[]){v_x_24461});
  }
  case TAG_RF32U: {
    V v_x_24463 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam35, 1, 1, (V[]){v_x_24463});
  }
  case TAG_RF64U: {
    V v_x_24468 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam36, 1, 1, (V[]){v_x_24468});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eexpF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2420});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args) {
  V v_s_2426 = args[0];
  V v_n_2425 = heff_env(self)[0];
  V v_t_2429;
  heff_clo_take(self, 1);
  if ((heff_intLt_c_lent(v_n_2425, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_2425, 1))) {
    V v_t_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str17), heff_intShow(v_n_2425));
    v_t_2429 = heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str18));
  } else {
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str19), heff_intShow(v_n_2425));
    v_t_2429 = heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str20));
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_s_2426});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args) {
  V v_s_2431 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_t_2433;
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str21))) {
    heff_drop(v_x_2430);
    v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str22);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str23))) {
      heff_drop(v_x_2430);
      v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str24);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str25))) {
        heff_drop(v_x_2430);
        v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str26);
      } else {
        V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str27), heff_floatShow(v_x_2430));
        v_t_2433 = heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str28));
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_s_2431});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_s_2445});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args) {
  V v_s_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str37), heff_floatShow(v_x_2446));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str38)), v_s_2447});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args) {
  V v_s_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2452, v_s_2453});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args) {
  V v_s_2460 = args[0];
  V v_m_2459 = heff_env(self)[0];
  V v_t_2456 = heff_env(self)[1];
  V v_es_2458 = heff_env(self)[2];
  V v_flat_2457 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2461 = heff_tr(heff_call(v_m_2459, 1, (V[]){v_s_2460}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_s_2463 = heff_field(v_x2_2461, 1);
    V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
    V v_x_2484;
    if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2456, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_2456, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
      heff_drop(v_t_2456);
      heff_drop(v_flat_2457);
      V v_n_2464 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2458; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2458); r_; });
      V v_t_2467;
      switch (heff_tag_of(v_x_2462)) {
      case TAG_Nil: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str43);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x_2462, 0);
        V v_xs_2466 = heff_field(v_x_2462, 1);
        heff_take_n(v_x_2462, 3ULL, 2);
        v_t_2467 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str44); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
        break;
      }
      default: heff_nomatch(v_x_2462);
      }
      V v_t_2468 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str45), heff_intShow(v_n_2464));
      V v_t_2469 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str46), v_t_2468), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str47));
      v_x_2484 = heff_strAppend(heff_strAppend(v_t_2469, v_t_2467), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str48));
    } else {
      V v_t_2470;
      if (heff_intEq_c_lent(v_flat_2457, MK_INT(0LL), 2)) {
        v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str49);
      } else {
        v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str50);
      }
      V v_t_2471 = ({ V a_0 = v_t_2456; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str51); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2456); r_; });
      V v_t_2472 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2458; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2458); r_; });
      V v_t_2474;
      if (heff_intEq_c_lent(v_flat_2457, MK_INT(0LL), 2)) {
        heff_drop(v_flat_2457);
        v_t_2474 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str52);
      } else {
        V v_t_2473 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str53), heff_intShow(v_flat_2457));
        v_t_2474 = heff_strAppend(v_t_2473, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str54));
      }
      V v_t_2480;
      switch (heff_tag_of(v_x_2462)) {
      case TAG_Nil: {
        v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str55);
        break;
      }
      case TAG_Cons: {
        V v_t_2479;
        switch (heff_tag_of(v_x_2462)) {
        case TAG_Nil: {
          v_t_2479 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str56);
          break;
        }
        case TAG_Cons: {
          V v_x_2477 = heff_field(v_x_2462, 0);
          V v_xs_2478 = heff_field(v_x_2462, 1);
          heff_take_n(v_x_2462, 3ULL, 2);
          v_t_2479 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str57); V a_1 = v_x_2477; V a_2 = v_xs_2478; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2478); r_; });
          break;
        }
        default: heff_nomatch(v_x_2462);
        }
        v_t_2480 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str58), v_t_2479), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str59));
        break;
      }
      default: heff_nomatch(v_x_2462);
      }
      V v_t_2481 = heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str60), v_t_2471));
      V v_t_2482 = heff_strAppend(heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str61)), heff_intShow(v_t_2472));
      V v_t_2483 = heff_strAppend(heff_strAppend(v_t_2482, v_t_2474), v_t_2480);
      v_x_2484 = heff_strAppend(v_t_2483, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str62));
    }
    return heff_tag_re_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2484, v_s_2463});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args) {
  V v_s_2492 = args[0];
  V v_m_2491 = heff_env(self)[0];
  V v_f_2490 = heff_env(self)[1];
  V v_es_2489 = heff_env(self)[2];
  V v_flat_2487 = heff_env(self)[3];
  V v_sm_2488 = heff_env(self)[4];
  V v_t_2486 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2493 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_s_2492}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_s_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    V v_t_2496 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_2490, heff_dup(v_es_2489)));
    V v_x2_2497 = heff_tr(heff_call(v_t_2496, 1, (V[]){v_s_2495}));
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_MkPair: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_s_2499 = heff_field(v_x2_2497, 1);
      V v_ru_24x2_2497_24MkPair = heff_take_reuse_n(v_x2_2497, 3ULL, 2);
      V v_t_24100;
      if (!heff_intEq_c_lent(v_flat_2487, MK_INT(0LL), 2)) {
        v_t_24100 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str63);
      } else {
        if (!heff_intEq_c_lent(v_sm_2488, MK_INT(0LL), 2)) {
          v_t_24100 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str64);
        } else {
          v_t_24100 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str65);
        }
      }
      V v_t_24101 = ({ V a_0 = v_t_2486; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str66); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2486); r_; });
      V v_t_24102 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2489; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2489); r_; });
      V v_t_24105;
      if (!heff_intEq_c_lent(v_flat_2487, MK_INT(0LL), 2)) {
        heff_drop(v_sm_2488);
        V v_t_24103 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str67), heff_intShow(v_flat_2487));
        v_t_24105 = heff_strAppend(v_t_24103, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str68));
      } else {
        heff_drop(v_flat_2487);
        if (!heff_intEq_c_lent(v_sm_2488, MK_INT(0LL), 2)) {
          V v_t_24104 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str69), heff_intShow(v_sm_2488));
          v_t_24105 = heff_strAppend(v_t_24104, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str70));
        } else {
          heff_drop(v_sm_2488);
          v_t_24105 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str71);
        }
      }
      HeffT3 v_t_24106 = ({ V a_0 = MK_INT(1LL); V b_1 = heff_tag_at_n(v_ru_24x2_2497_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_2494), v_x_2498}); HeffT3 r_ = (g_list_2edrop_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_24108 = v_t_24106.f[1];
        V v_field_24109 = v_t_24106.f[2];
        int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
        V v_t_24115;
        if ((v_tag_24107 == ((int64_t)0ULL))) {
          V v_x11_24110 = heff_dup(v_field_24108);
          heff_drop(v_x11_24110);
          V v_x12_24111 = heff_dup(v_field_24109);
          heff_drop(v_x12_24111);
          V v_t_24114;
          if ((v_tag_24107 == ((int64_t)0ULL))) {
            V v_x_24112 = v_field_24108;
            V v_xs_24113 = v_field_24109;
            v_t_24114 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str72); V a_1 = v_x_24112; V a_2 = v_xs_24113; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24113); r_; });
          } else {
            heff_drop(v_field_24108);
            heff_drop(v_field_24109);
            v_t_24114 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str73);
          }
          v_t_24115 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str74), v_t_24114), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str75));
        } else {
          heff_drop(v_field_24108);
          heff_drop(v_field_24109);
          v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str76);
        }
        V v_t_24116 = heff_strAppend(heff_strAppend(v_t_24100, v_x_2494), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str77));
        V v_t_24117 = heff_strAppend(v_t_24116, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str78), v_t_24101));
        V v_t_24118 = heff_strAppend(heff_strAppend(v_t_24117, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str79)), heff_intShow(v_t_24102));
        V v_t_24119 = heff_strAppend(heff_strAppend(v_t_24118, v_t_24105), v_t_24115);
        V v_x_24120 = heff_strAppend(v_t_24119, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str80));
        return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){v_x_24120, v_s_2499});
      }
    }
    default: return heff_nomatch(v_x2_2497);
    }
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args) {
  V v_s_24125 = args[0];
  V v_m_24124 = heff_env(self)[0];
  V v_ls_24121 = heff_env(self)[1];
  V v_flat_24122 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24126 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_s_24125}));
  switch (heff_tag_of(v_x2_24126)) {
  case TAG_MkPair: {
    V v_x_24127 = heff_field(v_x2_24126, 0);
    V v_s_24128 = heff_field(v_x2_24126, 1);
    V v_ru_24x2_24126_24MkPair = heff_take_reuse_n(v_x2_24126, 3ULL, 2);
    HeffT2 v_t_24129 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(heff_dup(v_ls_24121), v_s_24128));
    {
      V v_field_24130 = v_t_24129.f[0];
      V v_field_24131 = v_t_24129.f[1];
      V v_x_24132 = v_field_24130;
      V v_s_24133 = v_field_24131;
      V v_t_24134;
      if (heff_intEq_c_lent(v_flat_24122, MK_INT(0LL), 2)) {
        v_t_24134 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str81);
      } else {
        v_t_24134 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str82);
      }
      V v_t_24135 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_24121; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ls_24121); r_; });
      V v_t_24137;
      if (heff_intEq_c_lent(v_flat_24122, MK_INT(0LL), 2)) {
        heff_drop(v_flat_24122);
        v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str83);
      } else {
        V v_t_24136 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str84), heff_intShow(v_flat_24122));
        v_t_24137 = heff_strAppend(v_t_24136, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str85));
      }
      V v_t_24143;
      switch (heff_tag_of(v_x_24127)) {
      case TAG_Nil: {
        v_t_24143 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str86);
        break;
      }
      case TAG_Cons: {
        V v_t_24142;
        switch (heff_tag_of(v_x_24127)) {
        case TAG_Nil: {
          v_t_24142 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str87);
          break;
        }
        case TAG_Cons: {
          V v_x_24140 = heff_field(v_x_24127, 0);
          V v_xs_24141 = heff_field(v_x_24127, 1);
          heff_take_n(v_x_24127, 3ULL, 2);
          v_t_24142 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str88); V a_1 = v_x_24140; V a_2 = v_xs_24141; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24141); r_; });
          break;
        }
        default: heff_nomatch(v_x_24127);
        }
        v_t_24143 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str89), v_t_24142), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str90));
        break;
      }
      default: heff_nomatch(v_x_24127);
      }
      V v_t_24144 = heff_strAppend(v_t_24134, heff_intShow(v_t_24135));
      V v_t_24145 = heff_strAppend(heff_strAppend(v_t_24144, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str91)), v_x_24132);
      V v_t_24146 = heff_strAppend(heff_strAppend(v_t_24145, v_t_24137), v_t_24143);
      V v_x_24147 = heff_strAppend(v_t_24146, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str92));
      return heff_tag_at_n(v_ru_24x2_24126_24MkPair, TAG_MkPair, 2, (V[]){v_x_24147, v_s_24133});
    }
  }
  default: return heff_nomatch(v_x2_24126);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args) {
  V v_s_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  V v_ls_24153 = heff_env(self)[1];
  V v_su_24155 = heff_env(self)[2];
  V v_x_24148 = heff_env(self)[3];
  V v_keep_24149 = heff_env(self)[4];
  V v_kept_24150 = heff_env(self)[5];
  V v_flat_24151 = heff_env(self)[6];
  V v_n_24152 = heff_env(self)[7];
  V v_changed_24154 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_s_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_s_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    HeffT2 v_t_24162 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(v_ls_24153, v_s_24161));
    {
      V v_field_24163 = v_t_24162.f[0];
      V v_field_24164 = v_t_24162.f[1];
      V v_x_24165 = v_field_24163;
      V v_s_24166 = v_field_24164;
      V v_suffix_24167;
      if ((heff_dup(v_su_24155) == NTAG(TAG_True))) {
        heff_drop(v_su_24155);
        v_suffix_24167 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str93);
      } else {
        heff_drop(v_su_24155);
        v_suffix_24167 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str94);
      }
      V v_x_24168 = v_x_24148;
      V v_shape_24169 = v_x_24165;
      V v_keep_24170 = v_keep_24149;
      V v_t_24171 = heff_strAppend(heff_intShow(v_kept_24150), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str95));
      V v_t_24172 = heff_strAppend(v_t_24171, heff_intShow(v_flat_24151));
      V v_flats_24173 = heff_strAppend(v_t_24172, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str96));
      V v_n_24174 = v_n_24152;
      V v_vs_24175 = v_x_24160;
      V v_changed_24176 = (g_list_2emap_24s1937570095x2110149801(v_changed_24154));
      V v_x2_24177 = (g_list_2ezipWith_24s952564628x174753269(((V)&g_heff_2ecompile_2eemitc_2eexpF_str97), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str98), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str99), v_vs_24175, heff_dup(v_changed_24176)));
      V v_t_24180;
      switch (heff_tag_of(v_x2_24177)) {
      case TAG_Nil: {
        v_t_24180 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str100);
        break;
      }
      case TAG_Cons: {
        V v_x_24178 = heff_field(v_x2_24177, 0);
        V v_xs_24179 = heff_field(v_x2_24177, 1);
        heff_take_n(v_x2_24177, 3ULL, 2);
        v_t_24180 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str101); V a_1 = v_x_24178; V a_2 = v_xs_24179; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24179); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24177);
      }
      V v_t_24181 = ({ V a_0 = v_x_24168; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str102); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_24168); r_; });
      V v_x2_24182 = (g_list_2emap_24s1613211967x1923010103(((V)&g_heff_2ecompile_2eemitc_2eexpF_str103), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str104), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str105), v_changed_24176));
      V v_t_24185;
      switch (heff_tag_of(v_x2_24182)) {
      case TAG_Nil: {
        v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str106);
        break;
      }
      case TAG_Cons: {
        V v_x_24183 = heff_field(v_x2_24182, 0);
        V v_xs_24184 = heff_field(v_x2_24182, 1);
        heff_take_n(v_x2_24182, 3ULL, 2);
        v_t_24185 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str107); V a_1 = v_x_24183; V a_2 = v_xs_24184; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24184); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24182);
      }
      V v_t_24186 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str108), v_t_24180), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str109));
      V v_t_24187 = heff_strAppend(heff_strAppend(v_t_24186, v_suffix_24167), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str110));
      V v_t_24188 = heff_strAppend(v_t_24187, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str111), v_t_24181));
      V v_t_24189 = heff_strAppend(heff_strAppend(v_t_24188, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str112)), heff_intShow(v_keep_24170));
      V v_t_24190 = heff_strAppend(heff_strAppend(v_t_24189, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str113)), heff_intShow(v_n_24174));
      V v_t_24191 = heff_strAppend(heff_strAppend(v_t_24190, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str114)), v_shape_24169);
      V v_t_24192 = heff_strAppend(heff_strAppend(v_t_24191, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str115)), v_flats_24173);
      V v_t_24193 = heff_strAppend(heff_strAppend(v_t_24192, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str116)), v_t_24185);
      V v_x_24194 = heff_strAppend(v_t_24193, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str117));
      return heff_tag_at_n(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){v_x_24194, v_s_24166});
    }
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args) {
  V v_s_24198 = args[0];
  V v_m_24197 = heff_env(self)[0];
  V v_i_24196 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24199 = heff_tr(heff_call(v_m_24197, 1, (V[]){v_s_24198}));
  switch (heff_tag_of(v_x2_24199)) {
  case TAG_MkPair: {
    V v_x_24200 = heff_field(v_x2_24199, 0);
    V v_s_24201 = heff_field(v_x2_24199, 1);
    V v_ru_24x2_24199_24MkPair = heff_take_reuse_n(v_x2_24199, 3ULL, 2);
    V v_t_24202 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str118), heff_intShow(v_i_24196));
    V v_t_24203 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str119), v_x_24200), heff_strAppend(v_t_24202, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str120)));
    return heff_tag_re_n(v_ru_24x2_24199_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24203, v_s_24201});
  }
  default: return heff_nomatch(v_x2_24199);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args) {
  V v_s_24206 = args[0];
  V v_m_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24207 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_s_24206}));
  switch (heff_tag_of(v_x2_24207)) {
  case TAG_MkPair: {
    V v_x_24208 = heff_field(v_x2_24207, 0);
    V v_s_24209 = heff_field(v_x2_24207, 1);
    V v_ru_24x2_24207_24MkPair = heff_take_reuse_n(v_x2_24207, 3ULL, 2);
    V v_t_24210 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str121), v_x_24208), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str122));
    return heff_tag_re_n(v_ru_24x2_24207_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24210, v_s_24209});
  }
  default: return heff_nomatch(v_x2_24207);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args) {
  V v_s_24214 = args[0];
  V v_m_24213 = heff_env(self)[0];
  V v_i_24212 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24215 = heff_tr(heff_call(v_m_24213, 1, (V[]){v_s_24214}));
  switch (heff_tag_of(v_x2_24215)) {
  case TAG_MkPair: {
    V v_x_24216 = heff_field(v_x2_24215, 0);
    V v_s_24217 = heff_field(v_x2_24215, 1);
    V v_ru_24x2_24215_24MkPair = heff_take_reuse_n(v_x2_24215, 3ULL, 2);
    V v_t_24218 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str123), heff_intShow(v_i_24212));
    V v_t_24219 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str124), v_x_24216), heff_strAppend(v_t_24218, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str125)));
    return heff_tag_re_n(v_ru_24x2_24215_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24219, v_s_24217});
  }
  default: return heff_nomatch(v_x2_24215);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args) {
  V v_s_24224 = args[0];
  V v_m_24223 = heff_env(self)[0];
  V v_i_24221 = heff_env(self)[1];
  V v_n_24222 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24225 = heff_tr(heff_call(v_m_24223, 1, (V[]){v_s_24224}));
  switch (heff_tag_of(v_x2_24225)) {
  case TAG_MkPair: {
    V v_x_24226 = heff_field(v_x2_24225, 0);
    V v_s_24227 = heff_field(v_x2_24225, 1);
    V v_ru_24x2_24225_24MkPair = heff_take_reuse_n(v_x2_24225, 3ULL, 2);
    V v_t_24228 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str126), heff_intShow(v_i_24221));
    V v_t_24229 = heff_strAppend(heff_strAppend(v_t_24228, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str127)), heff_intShow(v_n_24222));
    V v_t_24230 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str128), v_x_24226), heff_strAppend(v_t_24229, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str129)));
    return heff_tag_re_n(v_ru_24x2_24225_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24230, v_s_24227});
  }
  default: return heff_nomatch(v_x2_24225);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args) {
  V v_s_24240 = args[0];
  V v_m_24239 = heff_env(self)[0];
  V v_i_24234 = heff_env(self)[1];
  V v_pre_24238 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24241 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_s_24240}));
  switch (heff_tag_of(v_x2_24241)) {
  case TAG_MkPair: {
    V v_x_24242 = heff_field(v_x2_24241, 0);
    V v_s_24243 = heff_field(v_x2_24241, 1);
    V v_ru_24x2_24241_24MkPair = heff_take_reuse_n(v_x2_24241, 3ULL, 2);
    V v_t_24244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str136), heff_intShow(v_i_24234));
    V v_t_24245 = heff_strAppend(heff_strAppend(v_pre_24238, v_x_24242), heff_strAppend(v_t_24244, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str137)));
    return heff_tag_re_n(v_ru_24x2_24241_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24245, v_s_24243});
  }
  default: return heff_nomatch(v_x2_24241);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args) {
  V v_s_24256 = args[0];
  V v_m_24255 = heff_env(self)[0];
  V v_i_24249 = heff_env(self)[1];
  V v_n_24250 = heff_env(self)[2];
  V v_pre_24254 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24257 = heff_tr(heff_call(v_m_24255, 1, (V[]){v_s_24256}));
  switch (heff_tag_of(v_x2_24257)) {
  case TAG_MkPair: {
    V v_x_24258 = heff_field(v_x2_24257, 0);
    V v_s_24259 = heff_field(v_x2_24257, 1);
    V v_ru_24x2_24257_24MkPair = heff_take_reuse_n(v_x2_24257, 3ULL, 2);
    V v_t_24260 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str144), heff_intShow(v_i_24249));
    V v_t_24261 = heff_strAppend(heff_strAppend(v_t_24260, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str145)), heff_intShow(v_n_24250));
    V v_t_24262 = heff_strAppend(heff_strAppend(v_pre_24254, v_x_24258), heff_strAppend(v_t_24261, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str146)));
    return heff_tag_re_n(v_ru_24x2_24257_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24262, v_s_24259});
  }
  default: return heff_nomatch(v_x2_24257);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args) {
  V v_s_24269 = args[0];
  V v_m_24268 = heff_env(self)[0];
  V v_pre_24267 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24270 = heff_tr(heff_call(v_m_24268, 1, (V[]){v_s_24269}));
  switch (heff_tag_of(v_x2_24270)) {
  case TAG_MkPair: {
    V v_x_24271 = heff_field(v_x2_24270, 0);
    V v_s_24272 = heff_field(v_x2_24270, 1);
    V v_ru_24x2_24270_24MkPair = heff_take_reuse_n(v_x2_24270, 3ULL, 2);
    V v_t_24273 = heff_strAppend(heff_strAppend(v_pre_24267, v_x_24271), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str152));
    return heff_tag_re_n(v_ru_24x2_24270_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24273, v_s_24272});
  }
  default: return heff_nomatch(v_x2_24270);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args) {
  V v_s_24280 = args[0];
  V v_x_24279 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24279, v_s_24280});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args) {
  V v_s_24287 = args[0];
  V v_m_24286 = heff_env(self)[0];
  V v_post_24285 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24288 = heff_tr(heff_call(v_m_24286, 1, (V[]){v_s_24287}));
  switch (heff_tag_of(v_x2_24288)) {
  case TAG_MkPair: {
    V v_x_24289 = heff_field(v_x2_24288, 0);
    V v_s_24290 = heff_field(v_x2_24288, 1);
    V v_ru_24x2_24288_24MkPair = heff_take_reuse_n(v_x2_24288, 3ULL, 2);
    V v_t_24291 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str162), v_x_24289), v_post_24285);
    return heff_tag_re_n(v_ru_24x2_24288_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24291, v_s_24290});
  }
  default: return heff_nomatch(v_x2_24288);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args) {
  V v_s_24297 = args[0];
  V v_m_24296 = heff_env(self)[0];
  V v_i_24295 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24298 = heff_tr(heff_call(v_m_24296, 1, (V[]){v_s_24297}));
  switch (heff_tag_of(v_x2_24298)) {
  case TAG_MkPair: {
    V v_x_24299 = heff_field(v_x2_24298, 0);
    V v_s_24300 = heff_field(v_x2_24298, 1);
    V v_ru_24x2_24298_24MkPair = heff_take_reuse_n(v_x2_24298, 3ULL, 2);
    V v_t_24303;
    switch (heff_tag_of(v_x_24299)) {
    case TAG_Nil: {
      v_t_24303 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str163);
      break;
    }
    case TAG_Cons: {
      V v_x_24301 = heff_field(v_x_24299, 0);
      V v_xs_24302 = heff_field(v_x_24299, 1);
      heff_take_n(v_x_24299, 3ULL, 2);
      v_t_24303 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str164); V a_1 = v_x_24301; V a_2 = v_xs_24302; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24302); r_; });
      break;
    }
    default: heff_nomatch(v_x_24299);
    }
    V v_t_24304 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str165), heff_intShow(v_i_24295));
    V v_t_24305 = heff_strAppend(heff_strAppend(v_t_24304, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str166)), v_t_24303);
    V v_x_24306 = heff_strAppend(v_t_24305, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str167));
    return heff_tag_re_n(v_ru_24x2_24298_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24306, v_s_24300});
  }
  default: return heff_nomatch(v_x2_24298);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args) {
  V v_s_24311 = args[0];
  V v_m_24310 = heff_env(self)[0];
  V v_x21_24293 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24312 = heff_tr(heff_call(v_m_24310, 1, (V[]){v_s_24311}));
  switch (heff_tag_of(v_x2_24312)) {
  case TAG_MkPair: {
    V v_x_24313 = heff_field(v_x2_24312, 0);
    V v_s_24314 = heff_field(v_x2_24312, 1);
    V v_ru_24x2_24312_24MkPair = heff_take_reuse_n(v_x2_24312, 3ULL, 2);
    V v_t_24315 = ({ V a_0 = v_x21_24293; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_x21_24293); r_; });
    V v_t_24318;
    switch (heff_tag_of(v_x_24313)) {
    case TAG_Nil: {
      v_t_24318 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str169);
      break;
    }
    case TAG_Cons: {
      V v_x_24316 = heff_field(v_x_24313, 0);
      V v_xs_24317 = heff_field(v_x_24313, 1);
      heff_take_n(v_x_24313, 3ULL, 2);
      v_t_24318 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str170); V a_1 = v_x_24316; V a_2 = v_xs_24317; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24317); r_; });
      break;
    }
    default: heff_nomatch(v_x_24313);
    }
    V v_t_24319 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str171), v_t_24315), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str172));
    V v_x_24320 = heff_strAppend(heff_strAppend(v_t_24319, v_t_24318), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str173));
    return heff_tag_re_n(v_ru_24x2_24312_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24320, v_s_24314});
  }
  default: return heff_nomatch(v_x2_24312);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args) {
  V v_s_24338 = args[0];
  V v_m_24337 = heff_env(self)[0];
  V v_tr_24332 = heff_env(self)[1];
  V v_w_24333 = heff_env(self)[2];
  V v_g_24331 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24339 = heff_tr(heff_call(v_m_24337, 1, (V[]){v_s_24338}));
  switch (heff_tag_of(v_x2_24339)) {
  case TAG_MkPair: {
    V v_x_24340 = heff_field(v_x2_24339, 0);
    V v_s_24341 = heff_field(v_x2_24339, 1);
    V v_ru_24x2_24339_24MkPair = heff_take_reuse_n(v_x2_24339, 3ULL, 2);
    V v_t_24342;
    if ((heff_dup(v_tr_24332) == NTAG(TAG_True))) {
      heff_drop(v_tr_24332);
      v_t_24342 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str174);
    } else {
      heff_drop(v_tr_24332);
      v_t_24342 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str175);
    }
    V v_t_24346;
    switch (heff_tag_of(v_w_24333)) {
    case TAG_Nothing: {
      V v_t_24343 = ({ V a_0 = v_g_24331; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str176); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24331); r_; });
      v_t_24346 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str177), v_t_24343);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_w_24333, 0ULL, 1);
      V v_t_24345 = ({ V a_0 = v_g_24331; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str178); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24331); r_; });
      v_t_24346 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str179), v_t_24345), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str180));
      break;
    }
    default: heff_nomatch(v_w_24333);
    }
    V v_t_24349;
    switch (heff_tag_of(v_x_24340)) {
    case TAG_Nil: {
      v_t_24349 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str181);
      break;
    }
    case TAG_Cons: {
      V v_x_24347 = heff_field(v_x_24340, 0);
      V v_xs_24348 = heff_field(v_x_24340, 1);
      heff_take_n(v_x_24340, 3ULL, 2);
      v_t_24349 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str182); V a_1 = v_x_24347; V a_2 = v_xs_24348; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24348); r_; });
      break;
    }
    default: heff_nomatch(v_x_24340);
    }
    V v_t_24350 = heff_strAppend(heff_strAppend(v_t_24342, v_t_24346), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str183));
    V v_x_24351 = heff_strAppend(heff_strAppend(v_t_24350, v_t_24349), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str184));
    return heff_tag_re_n(v_ru_24x2_24339_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24351, v_s_24341});
  }
  default: return heff_nomatch(v_x2_24339);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args) {
  V v_s_24356 = args[0];
  V v_m_24355 = heff_env(self)[0];
  V v_f_24354 = heff_env(self)[1];
  V v_es_24353 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24357 = heff_tr(heff_call(v_m_24355, 1, (V[]){v_s_24356}));
  switch (heff_tag_of(v_x2_24357)) {
  case TAG_MkPair: {
    V v_x_24358 = heff_field(v_x2_24357, 0);
    V v_s_24359 = heff_field(v_x2_24357, 1);
    V v_ru_24x2_24357_24MkPair = heff_take_reuse_n(v_x2_24357, 3ULL, 2);
    V v_t_24360 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_24354, heff_dup(v_es_24353)));
    V v_x2_24361 = heff_tr(heff_call(v_t_24360, 1, (V[]){v_s_24359}));
    switch (heff_tag_of(v_x2_24361)) {
    case TAG_MkPair: {
      V v_x_24362 = heff_field(v_x2_24361, 0);
      V v_s_24363 = heff_field(v_x2_24361, 1);
      V v_ru_24x2_24361_24MkPair = heff_take_reuse_n(v_x2_24361, 3ULL, 2);
      V v_t_24364 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24353; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_24353); r_; });
      HeffT3 v_t_24365 = ({ V a_0 = MK_INT(1LL); V b_1 = heff_tag_at_n(v_ru_24x2_24361_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_24358), v_x_24362}); HeffT3 r_ = (g_list_2edrop_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_24367 = v_t_24365.f[1];
        V v_field_24368 = v_t_24365.f[2];
        int64_t v_tag_24366 = ((int64_t)v_t_24365.f[0]);
        V v_t_24374;
        if ((v_tag_24366 == ((int64_t)0ULL))) {
          V v_x11_24369 = heff_dup(v_field_24367);
          heff_drop(v_x11_24369);
          V v_x12_24370 = heff_dup(v_field_24368);
          heff_drop(v_x12_24370);
          V v_t_24373;
          if ((v_tag_24366 == ((int64_t)0ULL))) {
            V v_x_24371 = v_field_24367;
            V v_xs_24372 = v_field_24368;
            v_t_24373 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str185); V a_1 = v_x_24371; V a_2 = v_xs_24372; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24372); r_; });
          } else {
            heff_drop(v_field_24367);
            heff_drop(v_field_24368);
            v_t_24373 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str186);
          }
          v_t_24374 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str187), v_t_24373), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str188));
        } else {
          heff_drop(v_field_24367);
          heff_drop(v_field_24368);
          v_t_24374 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str189);
        }
        V v_t_24375 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str190), v_x_24358), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str191));
        V v_t_24376 = heff_strAppend(v_t_24375, heff_intShow(v_t_24364));
        V v_t_24377 = heff_strAppend(heff_strAppend(v_t_24376, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str192)), v_t_24374);
        V v_x_24378 = heff_strAppend(v_t_24377, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str193));
        return heff_tag_at_n(v_ru_24x2_24357_24MkPair, TAG_MkPair, 2, (V[]){v_x_24378, v_s_24363});
      }
    }
    default: return heff_nomatch(v_x2_24361);
    }
  }
  default: return heff_nomatch(v_x2_24357);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args) {
  V v_s_24381 = args[0];
  V v_m_24380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24382 = heff_tr(heff_call(v_m_24380, 1, (V[]){v_s_24381}));
  switch (heff_tag_of(v_x2_24382)) {
  case TAG_MkPair: {
    V v_x_24383 = heff_field(v_x2_24382, 0);
    V v_s_24384 = heff_field(v_x2_24382, 1);
    V v_ru_24x2_24382_24MkPair = heff_take_reuse_n(v_x2_24382, 3ULL, 2);
    V v_t_24385 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str194), v_x_24383), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str195));
    return heff_tag_re_n(v_ru_24x2_24382_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24385, v_s_24384});
  }
  default: return heff_nomatch(v_x2_24382);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args) {
  V v_s_24386 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str196), v_s_24386});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args) {
  V v_s_24393 = args[0];
  V v_m_24392 = heff_env(self)[0];
  V v_pre_24391 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24394 = heff_tr(heff_call(v_m_24392, 1, (V[]){v_s_24393}));
  switch (heff_tag_of(v_x2_24394)) {
  case TAG_MkPair: {
    V v_x_24395 = heff_field(v_x2_24394, 0);
    V v_s_24396 = heff_field(v_x2_24394, 1);
    V v_ru_24x2_24394_24MkPair = heff_take_reuse_n(v_x2_24394, 3ULL, 2);
    V v_t_24397 = heff_strAppend(heff_strAppend(v_pre_24391, v_x_24395), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str202));
    return heff_tag_re_n(v_ru_24x2_24394_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24397, v_s_24396});
  }
  default: return heff_nomatch(v_x2_24394);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args) {
  V v_s_24404 = args[0];
  V v_m_24403 = heff_env(self)[0];
  V v_pre_24402 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24405 = heff_tr(heff_call(v_m_24403, 1, (V[]){v_s_24404}));
  switch (heff_tag_of(v_x2_24405)) {
  case TAG_MkPair: {
    V v_x_24406 = heff_field(v_x2_24405, 0);
    V v_s_24407 = heff_field(v_x2_24405, 1);
    V v_ru_24x2_24405_24MkPair = heff_take_reuse_n(v_x2_24405, 3ULL, 2);
    V v_t_24408 = heff_strAppend(heff_strAppend(v_pre_24402, v_x_24406), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str208));
    return heff_tag_re_n(v_ru_24x2_24405_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24408, v_s_24407});
  }
  default: return heff_nomatch(v_x2_24405);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args) {
  V v_s_24415 = args[0];
  V v_m_24414 = heff_env(self)[0];
  V v_pre_24413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24416 = heff_tr(heff_call(v_m_24414, 1, (V[]){v_s_24415}));
  switch (heff_tag_of(v_x2_24416)) {
  case TAG_MkPair: {
    V v_x_24417 = heff_field(v_x2_24416, 0);
    V v_s_24418 = heff_field(v_x2_24416, 1);
    V v_ru_24x2_24416_24MkPair = heff_take_reuse_n(v_x2_24416, 3ULL, 2);
    V v_t_24419 = heff_strAppend(heff_strAppend(v_pre_24413, v_x_24417), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str214));
    return heff_tag_re_n(v_ru_24x2_24416_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24419, v_s_24418});
  }
  default: return heff_nomatch(v_x2_24416);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args) {
  V v_s_24423 = args[0];
  V v_m_24422 = heff_env(self)[0];
  V v_p_24420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24424 = heff_tr(heff_call(v_m_24422, 1, (V[]){v_s_24423}));
  switch (heff_tag_of(v_x2_24424)) {
  case TAG_MkPair: {
    V v_x_24425 = heff_field(v_x2_24424, 0);
    V v_s_24426 = heff_field(v_x2_24424, 1);
    V v_ru_24x2_24424_24MkPair = heff_take_reuse_n(v_x2_24424, 3ULL, 2);
    V v_t_24427 = (g_heff_2ecompile_2eemitc_2eunboxed(v_p_24420));
    V v_x_24428 = ({ V a_0 = v_t_24427; V a_1 = v_x_24425; V r_ = (g_heff_2ecompile_2eemitc_2eunboxedC(a_0, a_1)); heff_drop(v_t_24427); heff_drop(v_x_24425); r_; });
    return heff_tag_re_n(v_ru_24x2_24424_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24428, v_s_24426});
  }
  default: return heff_nomatch(v_x2_24424);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args) {
  V v_s_24438 = args[0];
  V v_m_24437 = heff_env(self)[0];
  V v_p_24429 = heff_env(self)[1];
  V v_r_24430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24439 = heff_tr(heff_call(v_m_24437, 1, (V[]){v_s_24438}));
  switch (heff_tag_of(v_x2_24439)) {
  case TAG_MkPair: {
    V v_x_24440 = heff_field(v_x2_24439, 0);
    V v_s_24441 = heff_field(v_x2_24439, 1);
    V v_ru_24x2_24439_24MkPair = heff_take_reuse_n(v_x2_24439, 3ULL, 2);
    V v_t_24442 = ({ V a_0 = v_p_24429; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_24429); r_; });
    V v_t_24444;
    switch (heff_tag_of(v_r_24430)) {
    case TAG_RepV: {
      v_t_24444 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str219);
      break;
    }
    case TAG_RepFix: {
      V v_w_24443 = heff_field(v_r_24430, 0);
      heff_take_n(v_r_24430, 1ULL, 1);
      v_t_24444 = ({ V a_0 = v_w_24443; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24443); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24444 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str220);
      break;
    }
    case TAG_RepInt: {
      v_t_24444 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str221);
      break;
    }
    default: heff_nomatch(v_r_24430);
    }
    V v_t_24447;
    switch (heff_tag_of(v_x_24440)) {
    case TAG_Nil: {
      v_t_24447 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str222);
      break;
    }
    case TAG_Cons: {
      V v_x_24445 = heff_field(v_x_24440, 0);
      V v_xs_24446 = heff_field(v_x_24440, 1);
      heff_take_n(v_x_24440, 3ULL, 2);
      v_t_24447 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str223); V a_1 = v_x_24445; V a_2 = v_xs_24446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24446); r_; });
      break;
    }
    default: heff_nomatch(v_x_24440);
    }
    V v_t_24448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str224), v_t_24442), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str225));
    V v_t_24449 = heff_strAppend(heff_strAppend(v_t_24448, v_t_24444), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str226));
    V v_x_24450 = heff_strAppend(heff_strAppend(v_t_24449, v_t_24447), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str227));
    return heff_tag_re_n(v_ru_24x2_24439_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24450, v_s_24441});
  }
  default: return heff_nomatch(v_x2_24439);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam34(V self, V *args) {
  V v_s_24462 = args[0];
  V v_x_24461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24461, v_s_24462});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam35(V self, V *args) {
  V v_s_24464 = args[0];
  V v_x_24463 = heff_env(self)[0];
  V v_t_24466;
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24463)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str234))) {
    heff_drop(v_x_24463);
    v_t_24466 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str235);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24463)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str236))) {
      heff_drop(v_x_24463);
      v_t_24466 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str237);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24463)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str238))) {
        heff_drop(v_x_24463);
        v_t_24466 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str239);
      } else {
        V v_t_24465 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str240), heff_floatShow(v_x_24463));
        v_t_24466 = heff_strAppend(v_t_24465, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str241));
      }
    }
  }
  V v_t_24467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str242), v_t_24466), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str243));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24467, v_s_24464});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam36(V self, V *args) {
  V v_s_24469 = args[0];
  V v_x_24468 = heff_env(self)[0];
  V v_t_24471;
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24468)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str244))) {
    heff_drop(v_x_24468);
    v_t_24471 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str245);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24468)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str246))) {
      heff_drop(v_x_24468);
      v_t_24471 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str247);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24468)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str248))) {
        heff_drop(v_x_24468);
        v_t_24471 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str249);
      } else {
        V v_t_24470 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str250), heff_floatShow(v_x_24468));
        v_t_24471 = heff_strAppend(v_t_24470, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str251));
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24471, v_s_24469});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_24cpr_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_24cpr_str1, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_24cpr_str2, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_24cpr_str3, 1, "V");
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam4(V self, V *args);

HeffT6 g_heff_2ecompile_2eemitc_2eckOf_24cpr(V v_rs_240, V v_tu_241, V v_ret_242) {
top: ;
  return ((HeffT6){{heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam0, 1, 3, (V[]){heff_dup(v_rs_240), heff_dup(v_tu_241), heff_dup(v_ret_242)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam1, 1, 3, (V[]){heff_dup(v_rs_240), heff_dup(v_tu_241), heff_dup(v_ret_242)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam3, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_dup(v_tu_241), v_ret_242, heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam4, 1, 2, (V[]){heff_dup(v_rs_240), v_tu_241})}});
}
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  V v_ret_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = v_ret_242; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
  return (g_heff_2ecompile_2eemitc_2eexpF(v_t_244, v_e_243));
}
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2410));
    V v_x_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2412); r_; });
    return heff_tag_re_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2413, v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam1(V self, V *args) {
  V v_ss_245 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  V v_ret_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_k_246 = ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = v_ret_242; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
  V v_m_247 = (g_prelude_2etraverse_24s428640578x580976168(v_k_246, v_ss_245));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam2, 1, 1, (V[]){v_m_247});
}
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V a_0 = v_rs_240; V a_1 = v_x_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_rs_240); heff_drop(v_x_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      switch (heff_tag_of(v_x_2418)) {
      case TAG_RepV: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_24cpr_str0);
      }
      case TAG_RepFix: {
        V v_w_2419 = heff_field(v_x_2418, 0);
        heff_take_n(v_x_2418, 1ULL, 1);
        return ({ V a_0 = v_w_2419; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2419); r_; });
      }
      case TAG_RepF64: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_24cpr_str1);
      }
      case TAG_RepInt: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_24cpr_str2);
      }
      default: return heff_nomatch(v_x_2418);
      }
    } else {
      heff_drop(v_field_2417);
      return ((V)&g_heff_2ecompile_2eemitc_2eckOf_24cpr_str3);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_24cpr_lam4(V self, V *args) {
  V v_u_2420 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  heff_drop(v_u_2420);
  heff_clo_take(self, 2);
  return ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str0, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str1, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str2, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str3, 6, "top: ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str5, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str6, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str7, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str8, 0, "");

HeffT2 g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr(V v_tu_240, V v_n_241, V v_f_242, V v_z_243) {
top: ;
  V v_reprs_244 = heff_take_field(v_f_242, 5);
  V v_entry_245 = heff_take_field(v_f_242, 3);
  V v_body_246 = heff_take_field(v_f_242, 4);
  V v_wrapper_247 = heff_take_field(v_f_242, 7);
  V v_key_248 = heff_take_field(v_f_242, 0);
  V v_params_249 = heff_get_n(v_f_242, 1, 8);
  HeffT6 v_t_2410 = (g_heff_2ecompile_2eemitc_2eckOf_24cpr(v_reprs_244, heff_dup(v_tu_240), heff_dup(v_n_241)));
  {
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[0]);
    heff_drop(v_t_2410.f[2]);
    heff_drop(v_t_2410.f[3]);
    heff_drop(v_t_2410.f[4]);
    heff_drop(v_t_2410.f[5]);
    V v_m_2417 = heff_tr(heff_call(v_field_2412, 1, (V[]){v_entry_245}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_243}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      HeffT6 v_t_2421 = (g_heff_2ecompile_2eemitc_2eckOf_24cpr(v_reprs_244, v_tu_240, heff_dup(v_n_241)));
      {
        V v_field_2423 = v_t_2421.f[1];
        heff_drop(v_t_2421.f[0]);
        heff_drop(v_t_2421.f[2]);
        heff_drop(v_t_2421.f[3]);
        heff_drop(v_t_2421.f[4]);
        heff_drop(v_t_2421.f[5]);
        V v_m_2428 = heff_tr(heff_call(v_field_2423, 1, (V[]){v_body_246}));
        V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2420}));
        switch (heff_tag_of(v_x2_2429)) {
        case TAG_MkPair: {
          V v_x_2430 = heff_field(v_x2_2429, 0);
          V v_s_2431 = heff_field(v_x2_2429, 1);
          V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
          V v_t_2432 = heff_dup(v_wrapper_247);
          V v_t_2434;
          switch (heff_tag_of(v_t_2432)) {
          case TAG_Nothing: {
            v_t_2434 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            heff_take_n(v_t_2432, 0ULL, 1);
            v_t_2434 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_t_2432);
          }
          V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str0), heff_intShow(heff_dup(v_n_241)));
          V v_t_2436 = ({ V a_0 = v_key_248; V a_1 = heff_dup(v_params_249); V a_2 = v_reprs_244; V a_3 = v_t_2435; V a_4 = v_t_2434; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2434); r_; });
          V v_t_2437 = v_wrapper_247;
          V v_t_2439;
          switch (heff_tag_of(v_t_2437)) {
          case TAG_Nothing: {
            v_t_2439 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            heff_take_n(v_t_2437, 0ULL, 1);
            v_t_2439 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_t_2437);
          }
          V v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str1), heff_intShow(v_n_241));
          V v_t_2441 = ({ V a_0 = v_key_248; V a_1 = v_params_249; V a_2 = v_reprs_244; V a_3 = v_t_2440; V a_4 = v_t_2439; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_key_248); heff_drop(v_reprs_244); heff_drop(v_t_2439); r_; });
          V v_t_2442 = heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str2));
          V v_t_2443 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str3), NTAG(TAG_Nil)});
          V v_t_2444 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str4), v_x_2419));
          V v_t_2445 = heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str5), NTAG(TAG_Nil)});
          V v_ys_2446 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2445, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str6), v_x_2430));
          V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2444, v_ys_2446));
          V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str7)), NTAG(TAG_Nil)});
          V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2447})});
          V v_x_2450 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2448, v_t_2449});
          return ((HeffT2){{v_x_2450, v_s_2431}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2429)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2418)}});
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str0, 2, "&n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str1, 2, "&n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str2, 2, "&n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str3, 2, "&n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str7, 1, ")");
Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglueCallOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eglueCallOf(V v_b_240) {
top: ;
  V v_args_241 = heff_take_field(v_b_240, 2);
  V v_result_242 = heff_take_field(v_b_240, 3);
  V v_fun_243 = heff_get_n(v_b_240, 1, 5);
  V v_t_244 = (g_heff_2ecompile_2eemitc_2ecallArgs(MK_INT(0LL), v_args_241));
  V v_t_245 = v_result_242;
  V v_t_2414;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Gives: {
    V v_t_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    switch (heff_tag_of(v_t_246)) {
    case TAG_CInteger: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CDouble: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CBool: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CString: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CText: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_COwnedString: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CBytes: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str0), NTAG(TAG_Nil)});
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str1), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CPointer: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CVoid: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  case TAG_GivesOrErrno: {
    V v_t_2410 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    switch (heff_tag_of(v_t_2410)) {
    case TAG_CInteger: {
      heff_take_n(v_t_2410, 0ULL, 1);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CDouble: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CBool: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CString: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CText: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_COwnedString: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CBytes: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str2), NTAG(TAG_Nil)});
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str3), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CPointer: {
      heff_take_n(v_t_2410, 0ULL, 2);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CVoid: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  case TAG_DoneOrErrno: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_x2_2415 = (g_prelude_2e_2b_2b(v_t_244, v_t_2414));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str5); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_strAppend(heff_strAppend(v_fun_243, ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str6)), v_t_2418);
  return heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str7));
}
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglueCallOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemptyCS_str0, 0, "");
HEFF_REC_LIT(g_heff_2ecompile_2eemitc_2eemptyCS_lit1, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, ((V)&g_heff_2ecompile_2eemitc_2eemptyCS_str0), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil));

static V g_heff_2ecompile_2eemitc_2eemptyCS_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eemptyCS_st;
static V g_heff_2ecompile_2eemitc_2eemptyCS_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eemptyCS_lit1);
}
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eemptyCS_st)) return g_heff_2ecompile_2eemitc_2eemptyCS_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eemptyCS_val, &g_heff_2ecompile_2eemitc_2eemptyCS_st, g_heff_2ecompile_2eemitc_2eemptyCS_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str0, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str1, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str2, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str3, 4, "LBL_");
Clo g_heff_2ecompile_2eemitc_2eceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eceOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eceOf(V v_provs_240, V v_facts_241, V v_names_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_names_242, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str0); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_246; V r_ = (g_list_2efoldl_24s1882737314x358197882(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_245, v_t_247));
  V v_xs_249 = (g_list_2ekeepIf_24s478006518x1380334353(v_t_248));
  V v_m_2410 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2410); r_; });
  V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_t_2411));
  V v_t_2413 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V a_2 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2enumbered(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = ({ V a_0 = MK_INT(10LL); V a_1 = MK_INT(65526LL); V a_2 = v_t_2412; V a_3 = v_t_2413; V a_4 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2412); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_names_242, 1);
    v_t_2417 = heff_dup(v_y_2416);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str1); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2418; V r_ = (g_list_2efoldl_24s1882737314x358197882(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
  V v_xs_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
  V v_m_2421 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2420; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  V v_t_2422 = ({ V a_0 = v_m_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2421); r_; });
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  V v_t_2424 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(2147483647LL); V a_2 = v_t_2423; V a_3 = heff_dup(g_std_2eordmap_2eempty_get()); V a_4 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2423); r_; });
  V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str2); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2425; V r_ = (g_list_2efoldl_24s1882737314x358197882(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
  V v_t_2427 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()), v_t_2426));
  V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_provs_240));
  V v_t_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str3); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2428; V r_ = (g_list_2efoldl_24s1882737314x358197882(a_0, a_1, a_2, a_3)); heff_drop(v_t_2428); r_; });
  V v_t_2430 = ({ V a_0 = v_t_2427; V a_1 = v_t_2429; V a_2 = v_facts_241; V r_ = (g_heff_2ecompile_2efacts_2esureOnlyHere(a_0, a_1, a_2)); heff_drop(v_t_2427); heff_drop(v_t_2429); r_; });
  return heff_rec_n(3, shape_tags__lbls__facts, (V[]){v_t_2414, v_t_2424, v_t_2430});
}
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eceOf(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str5, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eemitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eemitAt_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2eemitAt(V v_ce_240, V v_kept_241, V v_acc_242, V v_d_243, V v_own_244, V v_v_245) {
top: ;
  HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_kept_241, heff_rfield(v_d_243, 0)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_t_2410;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_k_249 = v_field_248;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_249, 0)), heff_dup(v_v_245))) {
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_k_249});
      } else {
        heff_drop_rec(v_k_249, 8);
        v_t_2410 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_field_248);
      v_t_2410 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      V v_acc_2411 = v_acc_242;
      V v_s_2412 = heff_take_field(v_acc_2411, 1);
      V v_ems_2413 = heff_take_field(v_acc_2411, 0);
      V v_fresh_2414 = heff_take_field(v_acc_2411, 2);
      V v_key_2415 = heff_dup(heff_rfield(v_d_243, 0));
      V v_v_2416 = v_v_245;
      V v_t_2429;
      switch (heff_tag_of(v_own_244)) {
      case TAG_MkPair: {
        V v_b0_2417 = heff_field(v_own_244, 0);
        V v_n_2418 = heff_field(v_own_244, 1);
        V v_t_2419 = (g_heff_2ecompile_2eimperative_2egenOf(NTAG(TAG_True)));
        V v_t_2420 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_243, 0)), heff_dup(heff_rfield(v_d_243, 1)), heff_dup(v_b0_2417)});
        HeffT4 v_t_2421 = (g_heff_2ecompile_2eimperative_2edefOf_24cpr(v_t_2419, v_t_2420, heff_dup(v_n_2418)));
        {
          V v_field_2422 = v_t_2421.f[0];
          V v_field_2423 = v_t_2421.f[1];
          V v_field_2424 = v_t_2421.f[2];
          V v_field_2425 = v_t_2421.f[3];
          V v_x_2426 = heff_tag_n(TAG_MkDef, 3, (V[]){v_field_2422, v_field_2423, v_field_2424});
          V v_y_2427 = v_field_2425;
          heff_drop(v_y_2427);
          V v_t_2428 = v_x_2426;
          v_t_2429 = (g_heff_2ecompile_2elower_2ercOf(heff_dup(heff_rfield(v_ce_240, 2)), v_t_2428));
        }
        break;
      }
      default: heff_nomatch(v_own_244);
      }
      V v_t_2430 = ({ V b_0 = heff_get_n(v_d_243, 0, 3); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V v_o_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str1), v_t_2430);
      V v_t_2432 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 8, 11);
      V v_t_2433 = heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){v_o_2431, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      HeffT2 v_t_2434 = ({ V a_0 = v_t_2432; V a_1 = v_t_2429; V a_2 = v_t_2433; HeffT2 r_ = (g_heff_2ecompile_2eemitc_2edefC_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
      {
        V v_field_2435 = v_t_2434.f[0];
        V v_field_2436 = v_t_2434.f[1];
        V v_e_2437 = v_field_2435;
        V v_s1_2438 = v_field_2436;
        V v_t_2439 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_2415, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str2)));
        V v_t_2440 = (g_heff_2ecompile_2eemitc_2ekeptOf(heff_dup(v_v_2416), heff_dup(v_e_2437), heff_dup(v_s1_2438)));
        V v_t_2441 = ({ V b_0 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str3), v_t_2439); V a_1 = v_t_2440; V a_2 = v_s_2412; V r_ = (g_heff_2ecompile_2eemitc_2emergeKept(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2442 = (g_heff_2ecompile_2eemitc_2ekeptOf(v_v_2416, heff_dup(v_e_2437), v_s1_2438));
        V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_key_2415, v_t_2442}), v_fresh_2414});
        return ({ V rv_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2437, v_ems_2413}); V rv_1 = v_t_2441; V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_acc_2411, 0ULL, 3, shape_ems__s__fresh, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      }
    }
    case TAG_Just: {
      V v_k_2444 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      heff_drop_rec(v_ce_240, 3);
      heff_drop(v_v_245);
      V v_t_2445 = ({ V b_0 = heff_get_n(v_d_243, 0, 3); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str4); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V v_t_2446 = ({ V b_0 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str5), v_t_2445); V a_1 = heff_dup(v_k_2444); V a_2 = heff_take_field(v_acc_242, 1); V r_ = (g_heff_2ecompile_2eemitc_2emergeKept(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_2447 = heff_rec_n(2, shape_protos__code, (V[]){heff_take_field(v_k_2444, 1), heff_get_n(v_k_2444, 2, 8)});
      V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, heff_take_field(v_acc_242, 0)});
      return ({ V rv_0 = v_t_2448; V rv_1 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_acc_242, 4ULL, 3, shape_ems__s__fresh, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eemitAt(a[0], a1, a[2], a[3], a4, a[5]); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ethreadsLine_str0, 22, "#define HEFF_THREADS 1");

static V g_heff_2ecompile_2eemitc_2ethreadsLine_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2ethreadsLine_st;
static V g_heff_2ecompile_2eemitc_2ethreadsLine_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2ethreadsLine_str0);
}
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2ethreadsLine_st)) return g_heff_2ecompile_2eemitc_2ethreadsLine_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2ethreadsLine_val, &g_heff_2ecompile_2eemitc_2ethreadsLine_st, g_heff_2ecompile_2eemitc_2ethreadsLine_init);
}