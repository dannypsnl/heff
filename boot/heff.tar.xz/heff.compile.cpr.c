// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CRel 55099
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_Flat 38290
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_Nest 8345
#define TAG_OfFixed 17267
#define TAG_OpEq 47278
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Tip 31527
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_body 9524841
#define LBL_cons 9554936
#define LBL_fld 311000
#define LBL_flds 9641116
#define LBL_group 299987609
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_labels 836724522
#define LBL_leaves 840404935
#define LBL_lets 9813631
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_places 961367927
#define LBL_record 1012233084
#define LBL_tag 324116
#define LBL_tuple 312083426
#define LBL_tys 324872
#define LBL_vals 10107449
#define LBL_var 326049
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_lets__vals[] = {LBL_lets, LBL_vals};
static uint32_t shape_tag__index__tys__flds__places[] = {LBL_tag, LBL_index, LBL_tys, LBL_flds, LBL_places};
static uint32_t shape_tuple__numbered__kinds__record__labels__cons__group[] = {LBL_tuple, LBL_numbered, LBL_kinds, LBL_record, LBL_labels, LBL_cons, LBL_group};
V g_heff_2ecompile_2ecpr_2eapart(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapart_clo;
V g_heff_2ecompile_2ecpr_2eapartW(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eapartW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eapartW_clo;
V g_heff_2ecompile_2ecpr_2earmBodyAs(V, V, V, V);
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo;
V g_heff_2ecompile_2ecpr_2ebindFlds(V, V);
V g_heff_2ecompile_2ecpr_2ebindFlds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebindFlds_clo;
V g_heff_2ecompile_2ecpr_2eboundAll(V, V);
V g_heff_2ecompile_2ecpr_2eboundAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eboundAll_clo;
V g_heff_2ecompile_2ecpr_2ebuiltFld(V, V);
V g_heff_2ecompile_2ecpr_2ebuiltFld_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltFld_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOf(V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOf_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(V, V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_clo;
V g_heff_2ecompile_2ecpr_2ebuiltOut(V, V, V);
V g_heff_2ecompile_2ecpr_2ebuiltOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltOut_clo;
V g_heff_2ecompile_2ecpr_2ecalledApart(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2ecalledApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ecalledApart_clo;
V g_heff_2ecompile_2ecpr_2echosen(V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_clo;
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(V, V, V, V);
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_clo;
V g_heff_2ecompile_2ecpr_2edefWith(V, V, V);
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edefWith_clo;
V g_heff_2ecompile_2ecpr_2edropCalling(V);
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2edropCalling_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V, V, V);
V g_heff_2ecompile_2ecpr_2efitting(V);
V g_heff_2ecompile_2ecpr_2efitting_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2efitting_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efitting_24cpr(V);
V g_heff_2ecompile_2ecpr_2efldAt(V, V);
V g_heff_2ecompile_2ecpr_2efldAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2efldAt_clo;
HeffT2 g_heff_2ecompile_2ecpr_2efreeAt_24cpr(V, V, V, V);
V g_heff_2ecompile_2ecpr_2ekeptGo(V, V);
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo;
V g_heff_2ecompile_2ecpr_2elabelAt(V, V, V);
V g_heff_2ecompile_2ecpr_2elabelAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2elabelAt_clo;
V g_heff_2ecompile_2ecpr_2eleafExprs(V, V);
V g_heff_2ecompile_2ecpr_2eleafExprs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eleafExprs_clo;
V g_heff_2ecompile_2ecpr_2emergeFld(V, V);
V g_heff_2ecompile_2ecpr_2emergeFld_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2emergeFld_clo;
V g_heff_2ecompile_2ecpr_2emergeTy(V, V);
V g_heff_2ecompile_2ecpr_2emergeTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2emergeTy_clo;
V g_heff_2ecompile_2ecpr_2eopenIn(V, V, V, V, V);
V g_heff_2ecompile_2ecpr_2eopenIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eopenIn_clo;
V g_heff_2ecompile_2ecpr_2eopensW(V, V, V, V);
V g_heff_2ecompile_2ecpr_2eopensW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eopensW_clo;
V g_heff_2ecompile_2ecpr_2eoutRw(V, V);
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutRw_clo;
V g_heff_2ecompile_2ecpr_2erw(V, V);
V g_heff_2ecompile_2ecpr_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2erw_clo;
V g_heff_2ecompile_2ecpr_2erwNode(V, V, V);
V g_heff_2ecompile_2ecpr_2erwNode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2erwNode_clo;
V g_heff_2ecompile_2ecpr_2esameLabels(V, V);
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esameLabels_clo;
V g_heff_2ecompile_2ecpr_2esitesW(V, V, V);
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esitesW_clo;
V g_heff_2ecompile_2ecpr_2esplitBy(V, V);
V g_heff_2ecompile_2ecpr_2esplitBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esplitBy_clo;
V g_heff_2ecompile_2ecpr_2esplitBy_24dps(V, V, V);
V g_heff_2ecompile_2ecpr_2esplitBy_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2esplitBy_24dps_clo;
V g_heff_2ecompile_2ecpr_2etagLayout(V, V, V);
V g_heff_2ecompile_2ecpr_2etagLayout_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2etagLayout_clo;
HeffT2 g_heff_2ecompile_2ecpr_2etagLayout_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr(V, V, V, V);
V g_heff_2ecompile_2eir_2earmFor(V, V);
V g_heff_2ecompile_2eir_2earmFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2earmFor_clo;
HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V, V);
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s151864352x1148566527_24cpr(V, V);
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24s1016340684x604821087(V, V);
V g_list_2efoldl_24s1016340684x604821087_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1016340684x604821087_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1497160917x619600869(V, V);
V g_list_2efoldl_24s1497160917x619600869_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1497160917x619600869_clo;
V g_list_2efoldl_24s1943292369x853546653(V, V);
V g_list_2efoldl_24s1943292369x853546653_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1943292369x853546653_clo;
V g_list_2efoldl_24s1980014771x775787011(V, V);
V g_list_2efoldl_24s1980014771x775787011_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1980014771x775787011_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1902028738x441242582(V);
V g_list_2emap_24s1902028738x441242582_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1261798533x517442282(V, V);
V g_list_2ezipWith_24s1261798533x517442282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1261798533x517442282_clo;
V g_list_2ezipWith_24s1680834068x1673006787(V, V);
V g_list_2ezipWith_24s1680834068x1673006787_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1680834068x1673006787_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s667382472x1709340739(V, V);
V g_list_2ezipWith_24s667382472x1709340739_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s667382472x1709340739_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2etraverse_24s1023157662x1060337521_24cpr(V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s75890152x1871550235(V, V, V, V);
V g_prelude_2etraverse_24s75890152x1871550235_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s75890152x1871550235_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2ecpr_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_args_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_args_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecpr_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2efldAt_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2efldAt_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2efldAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2efldAt_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2efldAt(V v_e_240, V v_ty_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_ru_24e_240_24EVar = heff_take_reuse_n(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EVar, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EGlobal: {
    V v_ru_24e_240_24EGlobal = heff_take_reuse_n(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EGlobal, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_e_240, 0);
    V v_args_2418 = heff_field(v_e_240, 1);
    V v_ts_2419 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    switch (heff_tag_of(v_args_2418)) {
    case TAG_Nil: {
      heff_drop(v_t_2417);
      heff_drop(v_ts_2419);
      return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
    }
    case TAG_Cons: {
      V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2418));
      V v_t_2423 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2422, MK_INT(1LL))));
      V v_t_2425 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2efldAt_lam0, 1, 1, (V[]){heff_dup(v_ts_2419)}), v_t_2423));
      V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2418));
      V v_t_2427 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2426, MK_INT(1LL))));
      V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2efldAt_lam1, 1, 1, (V[]){v_ts_2419}), v_t_2427));
      V v_t_2430 = (g_list_2ezipWith(((V)&g_heff_2ecompile_2ecpr_2efldAt_clo), v_args_2418, v_t_2429));
      return heff_tag_n(TAG_Nest, 4, (V[]){v_ty_241, v_t_2417, v_t_2425, v_t_2430});
    }
    default: return heff_nomatch(v_args_2418);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_e_240, 0ULL, 2);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EPrim: {
    V v_ru_24e_240_24EPrim = heff_take_reuse_n(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EPrim, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EInt: {
    V v_ru_24e_240_24EInt = heff_take_reuse_n(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EInt, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EFloat: {
    V v_ru_24e_240_24EFloat = heff_take_reuse_nf(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EFloat, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EStr: {
    V v_ru_24e_240_24EStr = heff_take_reuse_n(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EStr, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EBytes: {
    V v_ru_24e_240_24EBytes = heff_take_reuse_n(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EBytes, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EFloat32: {
    V v_ru_24e_240_24EFloat32 = heff_take_reuse_na(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EFloat32, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EBool: {
    V v_ru_24e_240_24EBool = heff_take_reuse_n(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EBool, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EValues: {
    V v_ru_24e_240_24EValues = heff_take_reuse_n(v_e_240, 0ULL, 1);
    return heff_tag_at_n(v_ru_24e_240_24EValues, TAG_Flat, 1, (V[]){v_ty_241});
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return heff_tag_n(TAG_Flat, 1, (V[]){v_ty_241});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2ecpr_2efldAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2efldAt(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2efldAt_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_ts_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2424; V a_1 = v_ts_2419; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2419); r_; });
}
V g_heff_2ecompile_2ecpr_2efldAt_lam1(V self, V *args) {
  V v_i_2428 = args[0];
  V v_ts_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2428; V a_1 = v_ts_2419; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2419); r_; });
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2edropCalling_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2edropCalling_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2edropCalling_entry, 1, 0};

V g_heff_2ecompile_2ecpr_2edropCalling(V v_m_240) {
top: ;
  V v_t_241 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_m_240, NTAG(TAG_Nil)));
  V v_ps_2413 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edropCalling_lam0, 1, 1, (V[]){heff_dup(v_m_240)}); V a_1 = v_t_241; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2413; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2413); r_; });
}
V g_heff_2ecompile_2ecpr_2edropCalling_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2edropCalling(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam1(V self, V *args) {
  V v_g_248 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V a_0 = v_m_240; V a_1 = v_g_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_m_240); heff_drop(v_g_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x_2412); c_; })));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edropCalling_lam0(V self, V *args) {
  V v_p_242 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_t_245;
  switch (heff_tag_of(v_p_242)) {
  case TAG_MkPair: {
    V v_y_244 = heff_field(v_p_242, 1);
    heff_take_n(v_p_242, 2ULL, 2);
    v_t_245 = v_y_244;
    break;
  }
  default: heff_nomatch(v_p_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
  V v_t_247 = (g_list_2efoldl_24s1980014771x775787011(NTAG(TAG_Nil), v_t_246));
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edropCalling_lam1, 1, 1, (V[]){v_m_240}); V a_1 = v_t_247; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_247); r_; });
}
Clo g_heff_2ecompile_2ecpr_2ekeptGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ekeptGo_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2ekeptGo(V v_m_240, V v_m2_241) {
top: ;
  V v_t_242 = (g_std_2eordmap_2esize(v_m2_241));
  V v_t_243 = (g_std_2eordmap_2esize(v_m_240));
  if (heff_intEq_c(v_t_242, v_t_243)) {
    heff_drop(v_m2_241);
    return v_m_240;
  } else {
    heff_drop(v_m_240);
    V v_t_244 = (g_heff_2ecompile_2ecpr_2edropCalling(v_m2_241));
    V t_0 = v_m2_241;
    V t_1 = v_t_244;
    v_m_240 = t_0;
    v_m2_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2ecpr_2ekeptGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ekeptGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str12, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str13, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str14, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str15, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str16, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str17, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str18, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str19, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str20, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str21, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str22, 1, "_");
HEFF_LIT(g_heff_2ecompile_2ecpr_2emergeTy_str23, 1, "\?");
Clo g_heff_2ecompile_2ecpr_2emergeTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2emergeTy_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2emergeTy(V v_a_240, V v_b_241) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_a_240)) {
  case TAG_FtFloat: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str0);
    break;
  }
  case TAG_FtFixed: {
    V v_w_242 = heff_dup(heff_field(v_a_240, 0));
    switch (heff_tag_of(v_w_242)) {
    case TAG_I8: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str1);
      break;
    }
    case TAG_I16: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str2);
      break;
    }
    case TAG_I32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str3);
      break;
    }
    case TAG_I64: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str4);
      break;
    }
    case TAG_U8: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str5);
      break;
    }
    case TAG_U16: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str6);
      break;
    }
    case TAG_U32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str7);
      break;
    }
    case TAG_U64: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str8);
      break;
    }
    case TAG_F32: {
      v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str9);
      break;
    }
    default: heff_nomatch(v_w_242);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str10);
    break;
  }
  case TAG_FtAny: {
    v_t_243 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str11);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_b_241)) {
  case TAG_FtFloat: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str12);
    break;
  }
  case TAG_FtFixed: {
    V v_w_244 = heff_field(v_b_241, 0);
    switch (heff_tag_of(v_w_244)) {
    case TAG_I8: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str13);
      break;
    }
    case TAG_I16: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str14);
      break;
    }
    case TAG_I32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str15);
      break;
    }
    case TAG_I64: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str16);
      break;
    }
    case TAG_U8: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str17);
      break;
    }
    case TAG_U16: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str18);
      break;
    }
    case TAG_U32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str19);
      break;
    }
    case TAG_U64: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str20);
      break;
    }
    case TAG_F32: {
      v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str21);
      break;
    }
    default: heff_nomatch(v_w_244);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str22);
    break;
  }
  case TAG_FtAny: {
    v_t_245 = ((V)&g_heff_2ecompile_2ecpr_2emergeTy_str23);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  if (heff_strEq_c(v_t_243, v_t_245)) {
    return v_a_240;
  } else {
    heff_drop(v_a_240);
    return NTAG(TAG_FtOther);
  }
}
V g_heff_2ecompile_2ecpr_2emergeTy_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2emergeTy(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecpr_2emergeFld_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2emergeFld_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2emergeFld(V v_f_240, V v_g_241) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_Flat: {
    V v_t_248;
    switch (heff_tag_of(v_f_240)) {
    case TAG_Flat: {
      V v_a_243 = heff_field(v_f_240, 0);
      heff_take_n(v_f_240, 1ULL, 1);
      v_t_248 = v_a_243;
      break;
    }
    case TAG_Nest: {
      V v_a_244 = heff_field(v_f_240, 0);
      heff_take_n(v_f_240, 1ULL, 4);
      v_t_248 = v_a_244;
      break;
    }
    default: heff_nomatch(v_f_240);
    }
    V v_t_2414;
    switch (heff_tag_of(v_g_241)) {
    case TAG_Flat: {
      V v_a_249 = heff_field(v_g_241, 0);
      heff_take_n(v_g_241, 1ULL, 1);
      v_t_2414 = v_a_249;
      break;
    }
    case TAG_Nest: {
      V v_a_2410 = heff_field(v_g_241, 0);
      heff_take_n(v_g_241, 1ULL, 4);
      v_t_2414 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_g_241);
    }
    V v_t_2415 = ({ V a_0 = v_t_248; V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2ecpr_2emergeTy(a_0, a_1)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_Flat, 1, (V[]){v_t_2415});
  }
  case TAG_Nest: {
    V v_a_2416 = heff_dup(heff_field(v_f_240, 0));
    V v_t_2417 = heff_dup(heff_field(v_f_240, 1));
    V v_ts_2418 = heff_dup(heff_field(v_f_240, 2));
    V v_fs_2419 = heff_dup(heff_field(v_f_240, 3));
    switch (heff_tag_of(v_g_241)) {
    case TAG_Flat: {
      heff_drop(v_a_2416);
      heff_drop(v_t_2417);
      heff_drop(v_ts_2418);
      heff_drop(v_fs_2419);
      V v_t_2426;
      switch (heff_tag_of(v_f_240)) {
      case TAG_Flat: {
        V v_a_2421 = heff_field(v_f_240, 0);
        heff_take_n(v_f_240, 1ULL, 1);
        v_t_2426 = v_a_2421;
        break;
      }
      case TAG_Nest: {
        V v_a_2422 = heff_field(v_f_240, 0);
        heff_take_n(v_f_240, 1ULL, 4);
        v_t_2426 = v_a_2422;
        break;
      }
      default: heff_nomatch(v_f_240);
      }
      V v_t_2432;
      switch (heff_tag_of(v_g_241)) {
      case TAG_Flat: {
        V v_a_2427 = heff_field(v_g_241, 0);
        heff_take_n(v_g_241, 1ULL, 1);
        v_t_2432 = v_a_2427;
        break;
      }
      case TAG_Nest: {
        V v_a_2428 = heff_field(v_g_241, 0);
        heff_take_n(v_g_241, 1ULL, 4);
        v_t_2432 = v_a_2428;
        break;
      }
      default: heff_nomatch(v_g_241);
      }
      V v_t_2433 = ({ V a_0 = v_t_2426; V a_1 = v_t_2432; V r_ = (g_heff_2ecompile_2ecpr_2emergeTy(a_0, a_1)); heff_drop(v_t_2432); r_; });
      return heff_tag_n(TAG_Flat, 1, (V[]){v_t_2433});
    }
    case TAG_Nest: {
      V v_b_2434 = heff_field(v_g_241, 0);
      V v_u_2435 = heff_field(v_g_241, 1);
      V v_us_2436 = heff_field(v_g_241, 2);
      V v_gs_2437 = heff_field(v_g_241, 3);
      V v_ru_24g_241_24Nest = heff_take_reuse_n(v_g_241, 15ULL, 4);
      heff_drop_tag(v_f_240, 4);
      if ((heff_strEq_c_lent(v_t_2417, v_u_2435, 0) && ({ V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2419)); int c_ = ({ V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_gs_2437)); int c_ = heff_intEq_c_lent(v_t_2442, v_t_2443, 0); heff_drop(v_t_2443); c_; }); heff_drop(v_t_2442); c_; }))) {
        heff_drop(v_u_2435);
        V v_t_2438 = ({ V a_0 = v_a_2416; V a_1 = v_b_2434; V r_ = (g_heff_2ecompile_2ecpr_2emergeTy(a_0, a_1)); heff_drop(v_b_2434); r_; });
        V v_t_2439 = (g_list_2ezipWith_24s1680834068x1673006787(v_ts_2418, v_us_2436));
        V v_t_2440 = (g_list_2ezipWith(((V)&g_heff_2ecompile_2ecpr_2emergeFld_clo), v_fs_2419, v_gs_2437));
        return heff_tag_at_n(v_ru_24g_241_24Nest, TAG_Nest, 4, (V[]){v_t_2438, v_t_2417, v_t_2439, v_t_2440});
      } else {
        heff_drop(v_t_2417);
        heff_drop(v_ts_2418);
        heff_drop(v_fs_2419);
        heff_drop(v_u_2435);
        heff_drop(v_us_2436);
        heff_drop(v_gs_2437);
        heff_drop_cell(v_ru_24g_241_24Nest, 4);
        V v_t_2441 = ({ V a_0 = v_a_2416; V a_1 = v_b_2434; V r_ = (g_heff_2ecompile_2ecpr_2emergeTy(a_0, a_1)); heff_drop(v_b_2434); r_; });
        return heff_tag_n(TAG_Flat, 1, (V[]){v_t_2441});
      }
    }
    default: return heff_nomatch(v_g_241);
    }
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2ecompile_2ecpr_2emergeFld_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2emergeFld(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2ecpr_2efreeAt_24cpr(V v_k_240, V v_used_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k2_244 = heff_field(v_x4_243, 0);
    V v_ks_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2ecompile_2erepr_2ereprEq(v_k_240, v_k2_244));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_x1_247 = (g_list_2eany_24s688114072x773797180(v_i_242, v_used_241));
      if (!(heff_dup(v_x1_247) == NTAG(TAG_True))) {
        heff_drop(v_x1_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_242}});
      } else {
        heff_drop(v_x1_247);
        V t_0 = v_k_240;
        V t_1 = v_used_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        V t_3 = v_ks_245;
        v_k_240 = t_0;
        v_used_241 = t_1;
        v_i_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_t_246);
      V t_0 = v_k_240;
      V t_1 = v_used_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_ks_245;
      v_k_240 = t_0;
      v_used_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}

HeffT2 g_heff_2ecompile_2ecpr_2efitting_24cpr(V v_lay_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_lay_240, 5)));
  if (heff_intLe_c(v_t_241, MK_INT(4LL))) {
    V v_t_242 = heff_dup(heff_rfield(v_lay_240, 1));
    V v_t_244;
    if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
      heff_drop(v_t_242);
      V v_t_243 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_dup(heff_rfield(v_lay_240, 2))});
    } else {
      heff_drop(v_t_242);
      v_t_244 = heff_dup(heff_rfield(v_lay_240, 2));
    }
    V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_244; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    if (heff_intLe_c(v_t_245, MK_INT(12LL))) {
      V v_t_246 = heff_dup(heff_rfield(v_lay_240, 2));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        heff_drop_rec(v_lay_240, 7);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_lay_240}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_246)}});
      }
    } else {
      heff_drop_rec(v_lay_240, 7);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    heff_drop_rec(v_lay_240, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
Clo g_heff_2ecompile_2ecpr_2efitting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2efitting_entry, 1, 0};

V g_heff_2ecompile_2ecpr_2efitting(V v_lay_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2ecpr_2efitting_24cpr(v_lay_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ecpr_2efitting_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2efitting(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str2, 1, "#");

HeffT2 g_heff_2ecompile_2ecpr_2etagLayout_24cpr(V v_root_240, V v_numbered_241, V v_l_242) {
top: ;
  V v_kinds_243 = heff_take_field(v_l_242, 0);
  V v_cons_244 = heff_get_n(v_l_242, 1, 2);
  V v_t_246;
  if ((heff_dup(v_numbered_241) == NTAG(TAG_True))) {
    V v_t_245 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_dup(v_kinds_243)});
  } else {
    v_t_246 = heff_dup(v_kinds_243);
  }
  V v_x2_247 = (g_list_2emap_24s2090270526x1588636862(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_rec_n(7, shape_tuple__numbered__kinds__record__labels__cons__group, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2etagLayout_24cpr_str2), v_t_2410), v_numbered_241, v_kinds_243, NTAG(TAG_False), NTAG(TAG_Nil), v_cons_244, v_root_240});
  return (g_heff_2ecompile_2ecpr_2efitting_24cpr(v_t_2411));
}
Clo g_heff_2ecompile_2ecpr_2etagLayout_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2etagLayout_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2etagLayout(V v_root_240, V v_numbered_241, V v_l_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2ecpr_2etagLayout_24cpr(v_root_240, v_numbered_241, v_l_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2ecpr_2etagLayout_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2etagLayout(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2eapartW_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eapartW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eapartW_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2eapartW(V v_lay_240, V v_x_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EProj: {
      V v_e_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 4);
      V v_t_2450;
      switch (heff_tag_of(v_e_246)) {
      case TAG_EVar: {
        V v_y_2410 = heff_dup(heff_field(v_e_246, 0));
        if (heff_strEq_c_lent(v_x_241, v_y_2410, 2)) {
          V v_t_2411 = heff_dup(heff_rfield(v_lay_240, 3));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            v_t_2450 = heff_intAdd(v_n_242, MK_INT(1LL));
          } else {
            heff_drop(v_t_2411);
            v_t_2450 = v_n_242;
          }
        } else {
          v_t_2450 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EBool: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_ESet: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EValues: {
        v_t_2450 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_2450 = v_n_242;
        break;
      }
      default: heff_nomatch(v_e_246);
      }
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_t_2450;
      V t_3 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_e_246, v_rest_245});
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2451 = heff_field(v_x41_244, 0);
      V v_arms_2452 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2498;
      switch (heff_tag_of(v_s_2451)) {
      case TAG_EVar: {
        V v_y_2453 = heff_dup(heff_field(v_s_2451, 0));
        if (heff_strEq_c_lent(v_x_241, v_y_2453, 2)) {
          if (!(heff_dup(heff_rfield(v_lay_240, 3)) == NTAG(TAG_True))) {
            V v_t_2459 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2eapartW_lam0, 1, 1, (V[]){heff_dup(v_arms_2452)}); V a_1 = heff_rfield(v_lay_240, 5); V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
            if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
              heff_drop(v_t_2459);
              v_t_2498 = heff_intAdd(v_n_242, MK_INT(1LL));
            } else {
              heff_drop(v_t_2459);
              v_t_2498 = v_n_242;
            }
          } else {
            v_t_2498 = v_n_242;
          }
        } else {
          v_t_2498 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EBool: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_ESet: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EValues: {
        v_t_2498 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_2498 = v_n_242;
        break;
      }
      default: heff_nomatch(v_s_2451);
      }
      V v_t_2499 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2452, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_t_2498;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_s_2451, v_t_2499});
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_24100 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_lay_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_24100;
      v_lay_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2eapartW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2eapartW(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eapartW_lam0(V self, V *args) {
  V v_c_2454 = args[0];
  V v_arms_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2455 = ({ V b_0 = heff_get_n(v_c_2454, 0, 5); V a_1 = v_arms_2452; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_arms_2452); r_; });
  {
    V v_field_2457 = v_t_2455.f[1];
    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2456 == ((int64_t)0ULL)) && ({ V v_x11_2458 = heff_dup(v_field_2457); int c_ = 1; heff_drop(v_x11_2458); c_; })));
    heff_drop(v_field_2457);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2esitesW_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2esitesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esitesW_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2esitesW(V v_k_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_ELet: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_a_246 = heff_field(v_x31_243, 1);
      V v_b_247 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_k_248 = heff_dup(v_k_240);
      V v_acc_249 = v_acc_241;
      V v_x_2410 = v_x_245;
      V v_a_2411 = heff_dup(v_a_246);
      V v_b_2412 = heff_dup(v_b_247);
      V v_t_2464;
      switch (heff_tag_of(v_a_2411)) {
      case TAG_EVar: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_a_2411, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_a_2411, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_a_2411, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ECall: {
        V v_g_2436 = heff_field(v_a_2411, 0);
        V v_ru_24a_2411_24ECall = heff_take_reuse_n(v_a_2411, 1ULL, 2);
        V v_acc_2438 = v_acc_249;
        V v_x_2439 = v_x_2410;
        V v_b_2440 = v_b_2412;
        HeffT2 v_t_2441 = ({ V a_0 = v_k_248; V a_1 = v_g_2436; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_248); heff_drop(v_g_2436); r_; });
        {
          V v_field_2443 = v_t_2441.f[1];
          int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
          if ((v_tag_2442 == ((int64_t)0ULL))) {
            V v_lay_2444 = v_field_2443;
            V v_t_2445 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_2440), NTAG(TAG_Nil)});
            V v_x_2446 = (g_heff_2ecompile_2ecpr_2eapartW(v_lay_2444, v_x_2439, MK_INT(0LL), v_t_2445));
            V v_t_2447 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2446, 1));
            heff_drop(v_x_2446);
            if (((heff_dup(v_t_2447) == NTAG(TAG_True)) && ({ V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2440), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24129 = (g_heff_2ecompile_2ecpr_2eapartW(v_lay_2444, v_x_2439, MK_INT(0LL), heff_dup(v_t_2448))); int c_ = ({ V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2440), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24130 = (g_heff_2ecompile_2eir_2ecountW(v_x_2439, MK_INT(0LL), heff_dup(v_t_2449))); int c_ = heff_intEq_c_lent(v_t_24129, v_t_24130, 0); heff_drop(v_t_24130); c_; }); heff_drop(v_t_2449); c_; }); heff_drop(v_t_24129); c_; }); heff_drop(v_t_2448); c_; }))) {
              heff_drop(v_x_2439);
              heff_drop(v_b_2440);
              heff_drop(v_t_2447);
              v_t_2464 = heff_tag_at_n(v_ru_24a_2411_24ECall, TAG_Cons, 2, (V[]){heff_get_n(v_lay_2444, 6, 7), v_acc_2438});
            } else {
              heff_drop_cell(v_ru_24a_2411_24ECall, 2);
              heff_drop(v_x_2439);
              heff_drop(v_b_2440);
              heff_drop_rec(v_lay_2444, 7);
              heff_drop(v_t_2447);
              v_t_2464 = v_acc_2438;
            }
          } else {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop_cell(v_ru_24a_2411_24ECall, 2);
            heff_drop(v_x_2439);
            heff_drop(v_b_2440);
            heff_drop(v_field_2443);
            v_t_2464 = v_acc_2438;
          }
        }
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_a_2411, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_a_2411, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_a_2411, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_248);
        heff_drop(v_x_2410);
        heff_drop(v_b_2412);
        v_t_2464 = v_acc_249;
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_246, heff_tag_n(TAG_Cons, 2, (V[]){v_b_247, v_rest_244})});
      V t_0 = v_k_240;
      V t_1 = v_t_2464;
      V t_2 = v_t_2465;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2466 = heff_field(v_x31_243, 0);
      V v_arms_2467 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EMatch = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_k_2468 = heff_dup(v_k_240);
      V v_acc_2469 = v_acc_241;
      V v_s_2470 = heff_dup(v_s_2466);
      V v_arms_2471 = heff_dup(v_arms_2467);
      V v_t_24126;
      switch (heff_tag_of(v_s_2470)) {
      case TAG_EVar: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_s_2470, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_s_2470, 0ULL, 4);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_s_2470, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ECall: {
        V v_g_2495 = heff_field(v_s_2470, 0);
        heff_take_n(v_s_2470, 1ULL, 2);
        V v_acc_2497 = v_acc_2469;
        V v_arms_2498 = v_arms_2471;
        HeffT2 v_t_2499 = ({ V a_0 = v_k_2468; V a_1 = v_g_2495; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_2468); heff_drop(v_g_2495); r_; });
        {
          V v_field_24101 = v_t_2499.f[1];
          int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
          if ((v_tag_24100 == ((int64_t)0ULL))) {
            V v_lay_24102 = v_field_24101;
            V v_record_24103 = heff_take_field(v_lay_24102, 3);
            V v_cons_24104 = heff_take_field(v_lay_24102, 5);
            V v_group_24105 = heff_get_n(v_lay_24102, 6, 7);
            if (!(heff_dup(v_record_24103) == NTAG(TAG_True))) {
              heff_drop(v_record_24103);
              V v_t_24111 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2esitesW_lam0, 1, 1, (V[]){v_arms_2498}); V a_1 = v_cons_24104; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_cons_24104); r_; });
              if ((heff_dup(v_t_24111) == NTAG(TAG_True))) {
                heff_drop(v_t_24111);
                v_t_24126 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_group_24105, v_acc_2497});
              } else {
                heff_drop_cell(v_ru_24x3_242_24Cons, 2);
                heff_drop(v_group_24105);
                heff_drop(v_t_24111);
                v_t_24126 = v_acc_2497;
              }
            } else {
              heff_drop_cell(v_ru_24x3_242_24Cons, 2);
              heff_drop(v_arms_2498);
              heff_drop(v_record_24103);
              heff_drop(v_cons_24104);
              heff_drop(v_group_24105);
              v_t_24126 = v_acc_2497;
            }
          } else {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            heff_drop(v_arms_2498);
            heff_drop(v_field_24101);
            v_t_24126 = v_acc_2497;
          }
        }
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_s_2470, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_s_2470, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_s_2470, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_2468);
        heff_drop(v_arms_2471);
        v_t_24126 = v_acc_2469;
        break;
      }
      default: heff_nomatch(v_s_2470);
      }
      V v_t_24127 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2467, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_t_24126;
      V t_2 = heff_tag_at_n(v_ru_24x31_243_24EMatch, TAG_Cons, 2, (V[]){v_s_2466, v_t_24127});
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_24128 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_k_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_24128;
      v_k_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2esitesW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2esitesW(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2esitesW_lam0(V self, V *args) {
  V v_c_24106 = args[0];
  V v_arms_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24107 = ({ V b_0 = heff_get_n(v_c_24106, 0, 5); V a_1 = v_arms_2498; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_arms_2498); r_; });
  {
    V v_field_24109 = v_t_24107.f[1];
    int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24108 == ((int64_t)0ULL)) && ({ V v_x11_24110 = heff_dup(v_field_24109); int c_ = 1; heff_drop(v_x11_24110); c_; })));
    heff_drop(v_field_24109);
    return v_ret_24bool;
  }
}
Clo g_heff_2ecompile_2ecpr_2elabelAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2elabelAt_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2elabelAt(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_l_240, v_k_243, 0)) {
      return v_i_241;
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2elabelAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2elabelAt(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecpr_2esplitBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esplitBy_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2esplitBy(V v_x1_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_xs_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_xs_2410;
    switch (heff_tag_of(v_f_242)) {
    case TAG_Flat: {
      V v_a_244 = heff_dup(heff_field(v_f_242, 0));
      v_xs_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Nest: {
      V v_fs_248 = heff_dup(heff_field(v_f_242, 3));
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_248));
      v_xs_2410 = (g_list_2efoldl_24s1497160917x619600869(NTAG(TAG_Nil), v_t_249));
      break;
    }
    default: heff_nomatch(v_f_242);
    }
    V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2410; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    V v_t_2412 = (g_list_2etake(v_t_2411, heff_dup(v_xs_241)));
    V v_xs_2419;
    switch (heff_tag_of(v_f_242)) {
    case TAG_Flat: {
      V v_a_2413 = heff_field(v_f_242, 0);
      heff_take_n(v_f_242, 1ULL, 1);
      v_xs_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2413, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Nest: {
      V v_fs_2417 = heff_field(v_f_242, 3);
      heff_take_n(v_f_242, 8ULL, 4);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2417));
      v_xs_2419 = (g_list_2efoldl_24s1497160917x619600869(NTAG(TAG_Nil), v_t_2418));
      break;
    }
    default: heff_nomatch(v_f_242);
    }
    V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2419; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    V v_t_2421 = ({ V a_0 = v_t_2420; V a_1 = v_xs_241; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_xs_241); r_; });
    V v_cell_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2423 = (g_heff_2ecompile_2ecpr_2esplitBy_24dps(v_fs_243, v_t_2421, v_cell_2422));
    heff_drop(v_u_2423);
    return v_cell_2422;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecpr_2esplitBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2esplitBy(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecpr_2esplitBy_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2esplitBy_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2esplitBy_24dps(V v_x1_240, V v_xs_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_xs_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_xs_2411;
    switch (heff_tag_of(v_f_243)) {
    case TAG_Flat: {
      V v_a_245 = heff_dup(heff_field(v_f_243, 0));
      v_xs_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Nest: {
      V v_fs_249 = heff_dup(heff_field(v_f_243, 3));
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_249));
      v_xs_2411 = (g_list_2efoldl_24s1497160917x619600869(NTAG(TAG_Nil), v_t_2410));
      break;
    }
    default: heff_nomatch(v_f_243);
    }
    V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    V v_t_2413 = (g_list_2etake(v_t_2412, heff_dup(v_xs_241)));
    V v_xs_2420;
    switch (heff_tag_of(v_f_243)) {
    case TAG_Flat: {
      V v_a_2414 = heff_field(v_f_243, 0);
      heff_take_n(v_f_243, 1ULL, 1);
      v_xs_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2414, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Nest: {
      V v_fs_2418 = heff_field(v_f_243, 3);
      heff_take_n(v_f_243, 8ULL, 4);
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2418));
      v_xs_2420 = (g_list_2efoldl_24s1497160917x619600869(NTAG(TAG_Nil), v_t_2419));
      break;
    }
    default: heff_nomatch(v_f_243);
    }
    V v_t_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2420; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    V v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = v_xs_241; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_xs_241); r_; });
    V v_cell_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2424 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2423);
    V t_0 = v_fs_244;
    V t_1 = v_t_2422;
    V t_2 = v_u_2424;
    v_x1_240 = t_0;
    v_xs_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecpr_2esplitBy_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2esplitBy_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecpr_2ebuiltFld_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltFld_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2ebuiltFld(V v_f_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_Flat: {
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      return NTAG(TAG_EAbandon);
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_ys_241, 0);
      heff_take_n(v_ys_241, 1ULL, 2);
      return v_x_243;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  case TAG_Nest: {
    V v_t_246 = heff_field(v_f_240, 1);
    V v_ts_247 = heff_field(v_f_240, 2);
    V v_gs_248 = heff_field(v_f_240, 3);
    V v_t_249 = (g_heff_2ecompile_2ecpr_2esplitBy(heff_dup(v_gs_248), v_ys_241));
    V v_t_2410 = (g_list_2ezipWith(((V)&g_heff_2ecompile_2ecpr_2ebuiltFld_clo), heff_dup(v_gs_248), v_t_249));
    return heff_tag_n(TAG_ETag, 3, (V[]){heff_dup(v_t_246), v_t_2410, heff_dup(v_ts_247)});
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltFld_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2ebuiltFld(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2ecpr_2eopensW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eopensW_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2eopensW(V v_t_240, V v_x_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EMatch: {
      V v_s_246 = heff_field(v_x41_244, 0);
      V v_arms_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2451;
      switch (heff_tag_of(v_s_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_dup(heff_field(v_s_246, 0));
        if (heff_strEq_c_lent(v_x_241, v_y_248, 2)) {
          HeffT2 v_t_249 = (g_heff_2ecompile_2eir_2earmFor_24cpr(v_t_240, v_arms_247));
          {
            V v_field_2411 = v_t_249.f[1];
            int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
            if ((v_tag_2410 == ((int64_t)0ULL))) {
              V v_x11_2412 = v_field_2411;
              heff_drop(v_x11_2412);
              v_t_2451 = heff_intAdd(v_n_242, MK_INT(1LL));
            } else {
              heff_drop(v_field_2411);
              v_t_2451 = v_n_242;
            }
          }
        } else {
          v_t_2451 = v_n_242;
        }
        break;
      }
      case TAG_EGlobal: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_ELam: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EApp: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_ELet: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_ERecord: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EProj: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_ETag: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EMatch: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EPrim: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EPrimCall: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_ECall: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EInt: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EFloat: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EStr: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EBytes: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EFixed: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EFloat32: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EAbandon: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EBool: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_ESet: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EValues: {
        v_t_2451 = v_n_242;
        break;
      }
      case TAG_EFix: {
        v_t_2451 = v_n_242;
        break;
      }
      default: heff_nomatch(v_s_246);
      }
      V v_t_2452 = (g_heff_2ecompile_2eir_2epushArms(v_arms_247, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_x_241;
      V t_2 = v_t_2451;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_s_246, v_t_2452});
      v_t_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2453 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_t_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2453;
      v_t_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2eopensW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2eopensW(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2eopenIn_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eopenIn_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eopenIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eopenIn_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2eopenIn(V v_k_240, V v_fb_241, V v_t_242, V v_gs_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EMatch: {
    V v_s_245 = heff_field(v_e_244, 0);
    V v_arms_246 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EMatch = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_s_245)) {
    case TAG_EVar: {
      V v_y_247 = heff_dup(heff_field(v_s_245, 0));
      v_t_2446 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_fb_241, 0)), heff_dup(v_y_247)));
      heff_drop(v_y_247);
      break;
    }
    case TAG_EGlobal: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_245);
    }
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_s_245);
      heff_drop_cell(v_ru_24e_244_24EMatch, 2);
      heff_drop(v_t_2446);
      V v_go_2447 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecpr_2eopenIn_clo), 4, (V[]){heff_dup(v_k_240), heff_dup(v_fb_241), heff_dup(v_t_242), heff_dup(v_gs_243)}));
      HeffT2 v_t_2448 = ({ V a_0 = v_t_242; V a_1 = v_arms_246; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(a_0, a_1)); heff_drop(v_t_242); heff_drop(v_arms_246); r_; });
      {
        V v_field_2450 = v_t_2448.f[1];
        int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
        if ((v_tag_2449 == ((int64_t)0ULL))) {
          V v_x51_2451 = v_field_2450;
          switch (heff_tag_of(v_x51_2451)) {
          case TAG_MkArm: {
            V v_ws_2453 = heff_field(v_x51_2451, 1);
            V v_b_2454 = heff_field(v_x51_2451, 2);
            heff_take_n(v_x51_2451, 6ULL, 3);
            V v_t_2455 = (g_heff_2ecompile_2ecpr_2esplitBy(heff_dup(v_gs_243), heff_get_n(v_fb_241, 2, 3)));
            V v_t_2456 = (g_list_2ezipWith_24s1876717925x1404326288(v_gs_243, v_t_2455));
            V v_t_2457 = (g_list_2ezipWith_24s1261798533x517442282(v_ws_2453, v_t_2456));
            V v_t_2458 = heff_tr(heff_call(v_go_2447, 1, (V[]){v_b_2454}));
            return heff_tail(v_k_240, 2, (V[]){v_t_2457, v_t_2458});
          }
          default: return heff_nomatch(v_x51_2451);
          }
        } else {
          heff_drop(v_k_240);
          heff_drop_rec(v_fb_241, 3);
          heff_drop(v_gs_243);
          heff_drop(v_go_2447);
          heff_drop(v_field_2450);
          return NTAG(TAG_EAbandon);
        }
      }
    } else {
      heff_drop(v_t_2446);
      return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2ecpr_2eopenIn_lam0, 2, 4, (V[]){v_k_240, v_fb_241, v_t_242, v_gs_243}), heff_tag_re_n(v_ru_24e_244_24EMatch, TAG_EMatch, 2, 3ULL, (V[]){v_s_245, v_arms_246})));
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2ecpr_2eopenIn_lam1, 2, 4, (V[]){v_k_240, v_fb_241, v_t_242, v_gs_243}), v_e_244));
  }
  }
}
V g_heff_2ecompile_2ecpr_2eopenIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eopenIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2ecpr_2eopenIn_lam0(V self, V *args) {
  V v_x_2459 = args[0];
  V v_p_2460 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_fb_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_gs_243 = heff_env(self)[3];
  heff_drop(v_x_2459);
  heff_clo_take(self, 4);
  return (g_heff_2ecompile_2ecpr_2eopenIn(v_k_240, v_fb_241, v_t_242, v_gs_243, v_p_2460));
}
V g_heff_2ecompile_2ecpr_2eopenIn_lam1(V self, V *args) {
  V v_x_2461 = args[0];
  V v_p_2462 = args[1];
  V v_k_240 = heff_env(self)[0];
  V v_fb_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_gs_243 = heff_env(self)[3];
  heff_drop(v_x_2461);
  heff_clo_take(self, 4);
  return (g_heff_2ecompile_2ecpr_2eopenIn(v_k_240, v_fb_241, v_t_242, v_gs_243, v_p_2462));
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebindFlds_str0, 0, "");
Clo g_heff_2ecompile_2ecpr_2ebindFlds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebindFlds_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2ebindFlds(V v_x1_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(v_b_241);
  }
  case TAG_Cons: {
    V v_fb_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_k_244 = ((V)&g_heff_2ecompile_2ecpr_2ebindFlds_clo);
    V v_fb_245 = heff_dup(v_fb_242);
    V v_f_246 = heff_get_n(v_fb_242, 1, 3);
    V v_b_247 = heff_tr(g_heff_2ecompile_2ecpr_2ebindFlds(v_rest_243, v_b_241));
    switch (heff_tag_of(v_f_246)) {
    case TAG_Flat: {
      V v_ru_24f_246_24Flat = heff_take_reuse_n(v_f_246, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_k_244);
      V v_t_249 = heff_take_field(v_fb_245, 2);
      V v_t_2412;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nil: {
        v_t_2412 = ((V)&g_heff_2ecompile_2ecpr_2ebindFlds_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 2);
        v_t_2412 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      return heff_tag_n(TAG_ELet, 3, (V[]){heff_get_n(v_fb_245, 0, 3), heff_tag_at_n(v_ru_24f_246_24Flat, TAG_EVar, 1, (V[]){v_t_2412}), v_b_247});
    }
    case TAG_Nest: {
      V v_t_2414 = heff_field(v_f_246, 1);
      V v_ts_2415 = heff_field(v_f_246, 2);
      V v_gs_2416 = heff_field(v_f_246, 3);
      heff_take_n(v_f_246, 14ULL, 4);
      V v_t_2417 = heff_dup(v_t_2414);
      V v_x_2418 = heff_dup(heff_rfield(v_fb_245, 0));
      V v_b_2419 = heff_dup(v_b_247);
      V v_t_2420 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_2419), NTAG(TAG_Nil)});
      V v_x_2421 = (g_heff_2ecompile_2ecpr_2eopensW(v_t_2417, v_x_2418, MK_INT(0LL), v_t_2420));
      V v_t_2422 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2421, 1));
      heff_drop(v_x_2421);
      if (((heff_dup(v_t_2422) == NTAG(TAG_True)) && ({ V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2419), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2428 = (g_heff_2ecompile_2ecpr_2eopensW(v_t_2417, v_x_2418, MK_INT(0LL), heff_dup(v_t_2423))); int c_ = ({ V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2419), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2429 = (g_heff_2ecompile_2eir_2ecountW(v_x_2418, MK_INT(0LL), heff_dup(v_t_2424))); int c_ = heff_intEq_c_lent(v_t_2428, v_t_2429, 0); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2424); c_; }); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2423); c_; }))) {
        heff_drop(v_ts_2415);
        heff_drop(v_t_2417);
        heff_drop(v_x_2418);
        heff_drop(v_b_2419);
        heff_drop(v_t_2422);
        return (g_heff_2ecompile_2ecpr_2eopenIn(v_k_244, v_fb_245, v_t_2414, v_gs_2416, v_b_247));
      } else {
        heff_drop(v_k_244);
        heff_drop(v_t_2417);
        heff_drop(v_x_2418);
        heff_drop(v_b_2419);
        heff_drop(v_t_2422);
        V v_xs_2425 = (g_list_2emap_24s1809017761x1063871171(heff_take_field(v_fb_245, 2)));
        V v_t_2426 = (g_heff_2ecompile_2ecpr_2esplitBy(heff_dup(v_gs_2416), v_xs_2425));
        V v_t_2427 = (g_list_2ezipWith_24s667382472x1709340739(v_gs_2416, v_t_2426));
        return heff_tag_n(TAG_ELet, 3, (V[]){heff_get_n(v_fb_245, 0, 3), heff_tag_n(TAG_ETag, 3, (V[]){v_t_2414, v_t_2427, v_ts_2415}), v_b_247});
      }
    }
    default: return heff_nomatch(v_f_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecpr_2ebindFlds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2ebindFlds(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2earmBodyAs_str0, 0, "");
V g_heff_2ecompile_2ecpr_2earmBodyAs_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2earmBodyAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2earmBodyAs_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2earmBodyAs(V v_lay_240, V v_vs_241, V v_c_242, V v_x4_243) {
top: ;
  V v_flds_244 = heff_take_field(v_c_242, 3);
  V v_places_245 = heff_get_n(v_c_242, 4, 5);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_lay_240, 7);
    heff_drop(v_flds_244);
    heff_drop(v_places_245);
    return NTAG(TAG_EAbandon);
  }
  case TAG_Just: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkArm: {
      V v_ws_248 = heff_field(v_x41_246, 1);
      V v_b_249 = heff_field(v_x41_246, 2);
      V v_fs_2410 = v_flds_244;
      V v_xs_2420 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2earmBodyAs_lam0, 1, 2, (V[]){v_lay_240, heff_dup(v_vs_241)}), v_places_245));
      V v_t_2421 = (g_heff_2ecompile_2ecpr_2esplitBy(heff_dup(v_fs_2410), v_xs_2420));
      V v_t_2422 = (g_list_2ezipWith_24s1876717925x1404326288(v_fs_2410, v_t_2421));
      V v_t_2423 = (g_list_2ezipWith_24s1261798533x517442282(heff_dup(v_ws_248), v_t_2422));
      return (g_heff_2ecompile_2ecpr_2ebindFlds(v_t_2423, v_b_249));
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecpr_2earmBodyAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2ecpr_2earmBodyAs(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2ecpr_2earmBodyAs_lam0(V self, V *args) {
  V v_i_2411 = args[0];
  V v_lay_240 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_get_n(v_lay_240, 1, 7);
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    v_t_2413 = heff_intAdd(v_i_2411, MK_INT(1LL));
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = v_i_2411;
  }
  HeffT3 v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  {
    V v_field_2416 = v_t_2414.f[1];
    V v_field_2417 = v_t_2414.f[2];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      V v_x12_2419 = v_field_2417;
      heff_drop(v_x12_2419);
      return v_x_2418;
    } else {
      heff_drop(v_field_2416);
      heff_drop(v_field_2417);
      return ((V)&g_heff_2ecompile_2ecpr_2earmBodyAs_str0);
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str1, 4, "True");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_str2, 5, "False");
Clo g_heff_2ecompile_2ecpr_2echosen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2echosen_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2echosen(V v_vs_240, V v_way_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_EAbandon);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_tail(heff_dup(v_way_241), 1, (V[]){v_c_243});
    }
    case TAG_Cons: {
      V v_yes_247 = heff_tr(heff_call(heff_dup(v_way_241), 1, (V[]){heff_dup(v_c_243)}));
      V v_no_248 = heff_tr(g_heff_2ecompile_2ecpr_2echosen(v_vs_240, v_way_241, v_x32_244));
      V v_t_2411;
      switch (heff_tag_of(v_vs_240)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2ecompile_2ecpr_2echosen_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_vs_240, 0);
        v_t_2411 = heff_dup(v_x_249);
        break;
      }
      default: heff_nomatch(v_vs_240);
      }
      V v_t_2412 = heff_tag_n(TAG_OfFixed, 2, (V[]){NTAG(TAG_I64), NTAG(TAG_OpEq)});
      V v_t_2413 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), heff_get_n(v_c_243, 1, 5)});
      V v_t_2414 = heff_tag_n(TAG_CRel, 3, (V[]){v_t_2412, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2411}), v_t_2413});
      V v_t_2415 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str1), NTAG(TAG_Nil), v_yes_247});
      V v_t_2416 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_str2), NTAG(TAG_Nil), v_no_248});
      V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_t_2414}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2417})});
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecpr_2echosen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2echosen(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eapart_str0, 0, "");
V g_heff_2ecompile_2ecpr_2eapart_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2eapart_lam3(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eapart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eapart_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2eapart(V v_lay_240, V v_x_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EProj: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_l_245 = heff_field(v_x4_243, 1);
    V v_sh_246 = heff_field(v_x4_243, 2);
    V v_t_247 = heff_field(v_x4_243, 3);
    V v_ru_24x4_243_24EProj = heff_take_reuse_n(v_x4_243, 15ULL, 4);
    V v_t_2447;
    switch (heff_tag_of(v_e_244)) {
    case TAG_EVar: {
      V v_y_248 = heff_dup(heff_field(v_e_244, 0));
      v_t_2447 = heff_bool(heff_strEq_c_lent(v_x_241, v_y_248, 0));
      heff_drop(v_y_248);
      break;
    }
    case TAG_EGlobal: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2447 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_e_244);
      heff_drop(v_sh_246);
      heff_drop(v_t_247);
      heff_drop_cell(v_ru_24x4_243_24EProj, 4);
      heff_drop(v_t_2447);
      V v_i_2448 = ({ V a_0 = v_l_245; V a_1 = MK_INT(0LL); V a_2 = heff_rfield(v_lay_240, 4); V r_ = (g_heff_2ecompile_2ecpr_2elabelAt(a_0, a_1, a_2)); heff_drop(v_l_245); r_; });
      V v_t_2449 = heff_dup(heff_rfield(v_lay_240, 1));
      V v_t_2450;
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_t_2449);
        v_t_2450 = heff_intAdd(v_i_2448, MK_INT(1LL));
      } else {
        heff_drop(v_t_2449);
        v_t_2450 = v_i_2448;
      }
      HeffT3 v_t_2451 = (g_list_2edrop_24cpr(v_t_2450, v_vs_242));
      {
        V v_field_2453 = v_t_2451.f[1];
        V v_field_2454 = v_t_2451.f[2];
        int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
        V v_t_2457;
        if ((v_tag_2452 == ((int64_t)0ULL))) {
          V v_x_2455 = v_field_2453;
          V v_x12_2456 = v_field_2454;
          heff_drop(v_x12_2456);
          v_t_2457 = v_x_2455;
        } else {
          heff_drop(v_field_2453);
          heff_drop(v_field_2454);
          v_t_2457 = ((V)&g_heff_2ecompile_2ecpr_2eapart_str0);
        }
        return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2457});
      }
    } else {
      heff_drop(v_t_2447);
      V v_t_2458 = heff_tr(g_heff_2ecompile_2ecpr_2eapart(v_lay_240, v_x_241, v_vs_242, v_e_244));
      return heff_tag_re_n(v_ru_24x4_243_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_t_2458, v_l_245, v_sh_246, v_t_247});
    }
  }
  case TAG_EMatch: {
    V v_s_2459 = heff_field(v_x4_243, 0);
    V v_arms_2460 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EMatch = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_24100;
    switch (heff_tag_of(v_s_2459)) {
    case TAG_EVar: {
      V v_y_2461 = heff_dup(heff_field(v_s_2459, 0));
      v_t_24100 = heff_bool(heff_strEq_c_lent(v_x_241, v_y_2461, 0));
      heff_drop(v_y_2461);
      break;
    }
    case TAG_EGlobal: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24100 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2459);
    }
    if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
      heff_drop(v_s_2459);
      heff_drop(v_t_24100);
      V v_arms_24106 = (g_list_2emap_24tok2(v_ru_24x4_243_24EMatch, heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam0, 1, 3, (V[]){heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242)}), v_arms_2460));
      return ({ V a_0 = v_vs_242; V b_1 = heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam1, 1, 3, (V[]){v_arms_24106, heff_dup(v_lay_240), heff_dup(v_vs_242)}); V a_2 = heff_dup(heff_rfield(v_lay_240, 5)); V r_ = (g_heff_2ecompile_2ecpr_2echosen(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    } else {
      heff_drop(v_t_24100);
      return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam2, 2, 3, (V[]){heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242)}), heff_tag_re_n(v_ru_24x4_243_24EMatch, TAG_EMatch, 2, 3ULL, (V[]){v_s_2459, v_arms_2460})));
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2ecpr_2eapart_lam3, 2, 3, (V[]){heff_dup(v_lay_240), heff_dup(v_x_241), heff_dup(v_vs_242)}), v_x4_243));
  }
  }
}
V g_heff_2ecompile_2ecpr_2eapart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2eapart(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2eapart_lam0(V self, V *args) {
  V v_x2_24101 = args[0];
  V v_lay_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_MkArm: {
    V v_t_24102 = heff_field(v_x2_24101, 0);
    V v_vs_24103 = heff_field(v_x2_24101, 1);
    V v_b_24104 = heff_field(v_x2_24101, 2);
    V v_ru_24x2_24101_24MkArm = heff_take_reuse_n(v_x2_24101, 7ULL, 3);
    heff_clo_take(self, 3);
    V v_t_24105 = ({ V a_0 = v_lay_240; V a_1 = v_x_241; V a_2 = v_vs_242; V a_3 = v_b_24104; V r_ = heff_tr(g_heff_2ecompile_2ecpr_2eapart(a_0, a_1, a_2, a_3)); heff_drop_rec(v_lay_240, 7); heff_drop(v_x_241); heff_drop(v_vs_242); r_; });
    return heff_tag_re_n(v_ru_24x2_24101_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_24102, v_vs_24103, v_t_24105});
  }
  default: return heff_nomatch(v_x2_24101);
  }
}
V g_heff_2ecompile_2ecpr_2eapart_lam1(V self, V *args) {
  V v_c_24107 = args[0];
  V v_arms_24106 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24108 = ({ V a_0 = heff_rfield(v_c_24107, 0); V a_1 = v_arms_24106; V r_ = (g_heff_2ecompile_2eir_2earmFor(a_0, a_1)); heff_drop(v_arms_24106); r_; });
  return ({ V a_0 = v_lay_240; V a_1 = v_vs_242; V a_2 = v_c_24107; V a_3 = v_t_24108; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_vs_242); heff_drop(v_t_24108); r_; });
}
V g_heff_2ecompile_2ecpr_2eapart_lam2(V self, V *args) {
  V v_x_24109 = args[0];
  V v_p_24110 = args[1];
  V v_lay_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_drop(v_x_24109);
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lay_240; V a_1 = v_x_241; V a_2 = v_vs_242; V a_3 = v_p_24110; V r_ = (g_heff_2ecompile_2ecpr_2eapart(a_0, a_1, a_2, a_3)); heff_drop_rec(v_lay_240, 7); heff_drop(v_x_241); heff_drop(v_vs_242); r_; });
}
V g_heff_2ecompile_2ecpr_2eapart_lam3(V self, V *args) {
  V v_x_24111 = args[0];
  V v_p_24112 = args[1];
  V v_lay_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_drop(v_x_24111);
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lay_240; V a_1 = v_x_241; V a_2 = v_vs_242; V a_3 = v_p_24112; V r_ = (g_heff_2ecompile_2ecpr_2eapart(a_0, a_1, a_2, a_3)); heff_drop_rec(v_lay_240, 7); heff_drop(v_x_241); heff_drop(v_vs_242); r_; });
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_str0, 3, "tag");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_str1, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ecalledApart_str3, 4, "$cpr");
Clo g_heff_2ecompile_2ecpr_2ecalledApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ecalledApart_entry, 5, 0};

V g_heff_2ecompile_2ecpr_2ecalledApart(V v_lay_240, V v_g_241, V v_args_242, V v_k_243, V v_z_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_lay_240, 1));
  V v_t_247;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
    v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_dup(heff_rfield(v_lay_240, 2))});
  } else {
    heff_drop(v_t_245);
    v_t_247 = heff_dup(heff_rfield(v_lay_240, 2));
  }
  V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
  HeffT2 v_t_2410 = (g_prelude_2etraverse_24s1023157662x1060337521_24cpr(heff_dup(v_lay_240), MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_str0), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_str1), ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_str2), MK_INT(1LL), v_t_249, v_z_244));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    V v_x_2413 = v_field_2411;
    V v_n_2414 = v_field_2412;
    V v_t_2415 = heff_tr(heff_call(v_k_243, 1, (V[]){heff_dup(v_x_2413)}));
    V v_t_2416 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_241, ((V)&g_heff_2ecompile_2ecpr_2ecalledApart_str3)), v_args_242});
    V v_t_2417 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_get_n(v_lay_240, 0, 7), v_x_2413, v_t_2415});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_x_2419 = heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2416, v_t_2418});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_n_2414});
  }
}
V g_heff_2ecompile_2ecpr_2ecalledApart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ecalledApart(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2ecpr_2erwNode_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2erwNode_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2erwNode_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2erwNode_lam2(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2erwNode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2erwNode_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2erwNode(V v_k_240, V v_e_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ELet: {
    V v_x_243 = heff_field(v_e_241, 0);
    V v_a_244 = heff_field(v_e_241, 1);
    V v_b_245 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    switch (heff_tag_of(v_a_244)) {
    case TAG_ECall: {
      V v_g_246 = heff_field(v_a_244, 0);
      V v_args_247 = heff_field(v_a_244, 1);
      V v_ru_24a_244_24ECall = heff_take_reuse_n(v_a_244, 3ULL, 2);
      V v_x_248 = v_x_243;
      V v_g_249 = heff_dup(v_g_246);
      V v_args_2410 = v_args_247;
      V v_b_2411 = v_b_245;
      HeffT2 v_t_2412 = ({ V a_0 = v_k_240; V a_1 = v_g_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_246); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_lay_2415 = v_field_2414;
          V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2411), NTAG(TAG_Nil)});
          V v_x_2417 = (g_heff_2ecompile_2ecpr_2eapartW(v_lay_2415, v_x_248, MK_INT(0LL), v_t_2416));
          V v_t_2418 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2417, 1));
          heff_drop(v_x_2417);
          if (((heff_dup(v_t_2418) == NTAG(TAG_True)) && ({ V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2411), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2447 = (g_heff_2ecompile_2ecpr_2eapartW(v_lay_2415, v_x_248, MK_INT(0LL), heff_dup(v_t_2419))); int c_ = ({ V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2411), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2448 = (g_heff_2ecompile_2eir_2ecountW(v_x_248, MK_INT(0LL), heff_dup(v_t_2420))); int c_ = heff_intEq_c_lent(v_t_2447, v_t_2448, 0); heff_drop(v_t_2448); c_; }); heff_drop(v_t_2420); c_; }); heff_drop(v_t_2447); c_; }); heff_drop(v_t_2419); c_; }))) {
            heff_drop_cell(v_ru_24e_241_24ELet, 3);
            heff_drop_cell(v_ru_24a_244_24ECall, 2);
            heff_drop(v_t_2418);
            return (g_heff_2ecompile_2ecpr_2ecalledApart(heff_dup(v_lay_2415), v_g_249, v_args_2410, heff_clo_n(g_heff_2ecompile_2ecpr_2erwNode_lam0, 1, 3, (V[]){v_lay_2415, v_x_248, v_b_2411}), v_z_242));
          } else {
            heff_drop(v_lay_2415);
            heff_drop(v_t_2418);
            V v_t_2422 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_248, heff_tag_at_n(v_ru_24a_244_24ECall, TAG_ECall, 2, (V[]){v_g_249, v_args_2410}), v_b_2411});
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_z_242});
          }
        } else {
          heff_drop(v_field_2414);
          V v_t_2423 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_248, heff_tag_at_n(v_ru_24a_244_24ECall, TAG_ECall, 2, (V[]){v_g_249, v_args_2410}), v_b_2411});
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_z_242});
        }
      }
    }
    default: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24e_241_24ELet, TAG_ELet, 3, 7ULL, (V[]){v_x_243, v_a_244, v_b_245}), v_z_242});
    }
    }
  }
  case TAG_EMatch: {
    V v_s_2424 = heff_field(v_e_241, 0);
    V v_arms_2425 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_s_2424)) {
    case TAG_ECall: {
      V v_g_2426 = heff_field(v_s_2424, 0);
      V v_args_2427 = heff_field(v_s_2424, 1);
      V v_ru_24s_2424_24ECall = heff_take_reuse_n(v_s_2424, 3ULL, 2);
      V v_g_2428 = heff_dup(v_g_2426);
      V v_args_2429 = v_args_2427;
      V v_arms_2430 = v_arms_2425;
      HeffT2 v_t_2431 = ({ V a_0 = v_k_240; V a_1 = v_g_2426; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2426); r_; });
      {
        V v_field_2433 = v_t_2431.f[1];
        int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
        if ((v_tag_2432 == ((int64_t)0ULL))) {
          V v_lay_2434 = v_field_2433;
          if (!(heff_dup(heff_rfield(v_lay_2434, 3)) == NTAG(TAG_True))) {
            V v_t_2440 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2erwNode_lam1, 1, 1, (V[]){heff_dup(v_arms_2430)}); V a_1 = heff_rfield(v_lay_2434, 5); V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
            if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24e_241_24EMatch, 2);
              heff_drop_cell(v_ru_24s_2424_24ECall, 2);
              heff_drop(v_t_2440);
              return (g_heff_2ecompile_2ecpr_2ecalledApart(heff_dup(v_lay_2434), v_g_2428, v_args_2429, heff_clo_n(g_heff_2ecompile_2ecpr_2erwNode_lam2, 1, 2, (V[]){v_arms_2430, v_lay_2434}), v_z_242));
            } else {
              heff_drop_rec(v_lay_2434, 7);
              heff_drop(v_t_2440);
              V v_t_2444 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_at_n(v_ru_24s_2424_24ECall, TAG_ECall, 2, (V[]){v_g_2428, v_args_2429}), v_arms_2430});
              return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, v_z_242});
            }
          } else {
            heff_drop_rec(v_lay_2434, 7);
            V v_t_2445 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_at_n(v_ru_24s_2424_24ECall, TAG_ECall, 2, (V[]){v_g_2428, v_args_2429}), v_arms_2430});
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_z_242});
          }
        } else {
          heff_drop(v_field_2433);
          V v_t_2446 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){heff_tag_at_n(v_ru_24s_2424_24ECall, TAG_ECall, 2, (V[]){v_g_2428, v_args_2429}), v_arms_2430});
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_z_242});
        }
      }
    }
    default: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, 3ULL, (V[]){v_s_2424, v_arms_2425}), v_z_242});
    }
    }
  }
  default: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_z_242});
  }
  }
}
V g_heff_2ecompile_2ecpr_2erwNode_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2erwNode(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2erwNode_lam0(V self, V *args) {
  V v_vs_2421 = args[0];
  V v_lay_2415 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_b_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lay_2415; V a_1 = v_x_248; V a_2 = v_vs_2421; V a_3 = v_b_2411; V r_ = (g_heff_2ecompile_2ecpr_2eapart(a_0, a_1, a_2, a_3)); heff_drop(v_lay_2415); heff_drop(v_x_248); heff_drop(v_vs_2421); r_; });
}
V g_heff_2ecompile_2ecpr_2erwNode_lam1(V self, V *args) {
  V v_c_2435 = args[0];
  V v_arms_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2436 = ({ V b_0 = heff_get_n(v_c_2435, 0, 5); V a_1 = v_arms_2430; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmFor_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_arms_2430); r_; });
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2437 == ((int64_t)0ULL)) && ({ V v_x11_2439 = heff_dup(v_field_2438); int c_ = 1; heff_drop(v_x11_2439); c_; })));
    heff_drop(v_field_2438);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2erwNode_lam3(V self, V *args) {
  V v_c_2442 = args[0];
  V v_arms_2430 = heff_env(self)[0];
  V v_lay_2434 = heff_env(self)[1];
  V v_vs_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2443 = ({ V a_0 = heff_rfield(v_c_2442, 0); V a_1 = v_arms_2430; V r_ = (g_heff_2ecompile_2eir_2earmFor(a_0, a_1)); heff_drop(v_arms_2430); r_; });
  return ({ V a_0 = v_lay_2434; V a_1 = v_vs_2441; V a_2 = v_c_2442; V a_3 = v_t_2443; V r_ = (g_heff_2ecompile_2ecpr_2earmBodyAs(a_0, a_1, a_2, a_3)); heff_drop(v_vs_2441); heff_drop(v_t_2443); r_; });
}
V g_heff_2ecompile_2ecpr_2erwNode_lam2(V self, V *args) {
  V v_vs_2441 = args[0];
  V v_arms_2430 = heff_env(self)[0];
  V v_lay_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_vs_2441; V b_1 = heff_clo_n(g_heff_2ecompile_2ecpr_2erwNode_lam3, 1, 3, (V[]){v_arms_2430, heff_dup(v_lay_2434), heff_dup(v_vs_2441)}); V a_2 = heff_get_n(v_lay_2434, 5, 7); V r_ = (g_heff_2ecompile_2ecpr_2echosen(a_0, b_1, a_2)); heff_drop(v_vs_2441); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2ecpr_2erw_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2erw_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2erw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2erw_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2erw(V v_k_240, V v_e_241) {
top: ;
  V v_m_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), v_e_241));
  return heff_clo_n(g_heff_2ecompile_2ecpr_2erw_lam1, 1, 2, (V[]){v_m_244, heff_dup(v_k_240)});
}
V g_heff_2ecompile_2ecpr_2erw_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2erw(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2erw_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_p_243 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_drop(v_x_242);
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_240; V a_1 = v_p_243; V r_ = (g_heff_2ecompile_2ecpr_2erw(a_0, a_1)); heff_drop(v_k_240); r_; });
}
V g_heff_2ecompile_2ecpr_2erw_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    return ({ V a_0 = v_k_240; V a_1 = v_x_247; V a_2 = v_n_248; V r_ = (g_heff_2ecompile_2ecpr_2erwNode(a_0, a_1, a_2)); heff_drop(v_k_240); r_; });
  }
  default: return heff_nomatch(v_x2_246);
  }
}

HeffT2 g_heff_2ecompile_2ecpr_2efieldAt_24cpr(V v_i_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_ps_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_e_245 = heff_field(v_x3_242, 0);
      V v_es_246 = heff_field(v_x3_242, 1);
      if (heff_intEq_c_lent(v_p_243, v_i_240, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_e_245)}});
      } else {
        V t_0 = v_i_240;
        V t_1 = v_ps_244;
        V t_2 = v_es_246;
        v_i_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eboundAll_str0, 2, "f$");
V g_heff_2ecompile_2ecpr_2eboundAll_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundAll_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundAll_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2eboundAll_lam3(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eboundAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eboundAll_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eboundAll(V v_b_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam0, 1, 1, (V[]){v_b_240});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_es_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_b_245 = v_b_240;
    V v_e_246 = v_e_243;
    V v_t_247 = (g_heff_2ecompile_2eir_2eisValue(v_e_246));
    V v_m_2419;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_246, NTAG(TAG_Nil)});
      V v_t_249 = (g_prelude_2e_2b_2b(heff_take_field(v_b_245, 1), v_t_248));
      V v_x_2410 = ({ V rv_1 = v_t_249; V rr_ = heff_rec_reuse_nf(v_b_245, 1ULL, 2, shape_lets__vals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      v_m_2419 = heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam1, 1, 1, (V[]){v_x_2410});
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_247);
      v_m_2419 = heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam2, 1, 2, (V[]){v_e_246, v_b_245});
    }
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eboundAll_lam3, 1, 2, (V[]){v_m_2419, v_es_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecpr_2eboundAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eboundAll(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_b_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_240, v_n_242});
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_n_2411});
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_e_246 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_2413 = heff_strAppend(((V)&g_heff_2ecompile_2ecpr_2eboundAll_str0), heff_intShow(heff_dup(v_n_2412)));
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2413), v_e_246}), NTAG(TAG_Nil)});
  V v_t_2415 = (g_prelude_2e_2b_2b(heff_take_field(v_b_245, 0), v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2413}), NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(heff_take_field(v_b_245, 1), v_t_2416));
  V v_x_2418 = ({ V rv_0 = v_t_2415; V rv_1 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_b_245, 0ULL, 2, shape_lets__vals, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, heff_intAdd(v_n_2412, MK_INT(1LL))});
}
V g_heff_2ecompile_2ecpr_2eboundAll_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_es_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    V v_t_2424 = (g_heff_2ecompile_2ecpr_2eboundAll(v_x_2422, v_es_244));
    V f_ = v_t_2424;
    args[0] = v_n_2423;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
Clo g_heff_2ecompile_2ecpr_2eleafExprs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eleafExprs_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eleafExprs(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_Flat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Nest: {
    V v_gs_246 = heff_field(v_f_240, 3);
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_ELam: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EApp: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_ETag: {
      V v_args_2423 = heff_field(v_e_241, 1);
      heff_take_n(v_e_241, 2ULL, 3);
      V v_t_2425 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), heff_dup(v_gs_246), v_args_2423));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1943292369x853546653(a_0, a_1)); heff_drop(v_t_2425); r_; });
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EPrim: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EBytes: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EBool: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_ESet: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EValues: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2ecompile_2ecpr_2eleafExprs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecpr_2eleafExprs(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOut_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOut(V v_lay_240, V v_c_241, V v_es_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_241, 3)), v_es_242));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1943292369x853546653(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = heff_rec_n(2, shape_lets__vals, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_m_246 = (g_heff_2ecompile_2ecpr_2eboundAll(v_t_245, v_t_244));
  return heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOut_lam0, 1, 3, (V[]){v_m_246, v_lay_240, v_c_241});
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2ebuiltOut(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam1(V self, V *args) {
  V v_i_2427 = args[0];
  V v_k_2428 = args[1];
  V v_places_2420 = heff_env(self)[0];
  V v_es_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2429 = ({ V a_0 = v_i_2427; V a_1 = v_places_2420; V a_2 = v_es_2421; HeffT2 r_ = (g_heff_2ecompile_2ecpr_2efieldAt_24cpr(a_0, a_1, a_2)); heff_drop(v_i_2427); heff_drop(v_places_2420); heff_drop(v_es_2421); r_; });
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      heff_drop(v_k_2428);
      V v_x_2432 = v_field_2431;
      return v_x_2432;
    } else {
      heff_drop(v_field_2431);
      switch (heff_tag_of(v_k_2428)) {
      case TAG_RepV: {
        return heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_RepFix: {
        V v_w_2433 = heff_field(v_k_2428, 0);
        heff_take_n(v_k_2428, 1ULL, 1);
        return heff_tag_n(TAG_EFixed, 2, (V[]){v_w_2433, MK_INT(0LL)});
      }
      case TAG_RepF64: {
        return heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64((0.0))});
      }
      case TAG_RepInt: {
        return heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
      }
      default: return heff_nomatch(v_k_2428);
      }
    }
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOut_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_lay_240 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_lets_2411 = heff_take_field(v_x_249, 0);
    V v_vals_2412 = heff_get_n(v_x_249, 1, 2);
    V v_ls_2413 = v_lets_2411;
    V v_lay_2414 = v_lay_240;
    V v_numbered_2415 = heff_take_field(v_lay_2414, 1);
    V v_kinds_2416 = heff_take_field(v_lay_2414, 2);
    V v_tuple_2417 = heff_get_n(v_lay_2414, 0, 7);
    V v_c_2418 = v_c_241;
    V v_index_2419 = heff_take_field(v_c_2418, 1);
    V v_places_2420 = heff_get_n(v_c_2418, 4, 5);
    V v_es_2421 = v_vals_2412;
    V v_t_2422 = heff_dup(v_numbered_2415);
    V v_t_2424;
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_t_2422);
      V v_t_2423 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), v_index_2419});
      v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_index_2419);
      heff_drop(v_t_2422);
      v_t_2424 = NTAG(TAG_Nil);
    }
    V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_kinds_2416));
    V v_t_2426 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2425, MK_INT(1LL))));
    V v_t_2434 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOut_lam1, 2, 2, (V[]){v_places_2420, v_es_2421}), v_t_2426, heff_dup(v_kinds_2416)));
    V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2434));
    V v_t_2436 = v_numbered_2415;
    V v_t_2438;
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_t_2436);
      V v_t_2437 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_kinds_2416});
    } else {
      heff_drop(v_t_2436);
      v_t_2438 = v_kinds_2416;
    }
    V v_t_2439 = (g_list_2emap_24s1902028738x441242582(v_t_2438));
    V v_e_2440 = heff_tag_n(TAG_ETag, 3, (V[]){v_tuple_2417, v_t_2435, v_t_2439});
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ls_2413));
    V v_x_2442 = ({ V a_0 = v_e_2440; V a_1 = v_t_2441; V r_ = (g_list_2efoldl_24s1016340684x604821087(a_0, a_1)); heff_drop(v_t_2441); r_; });
    return heff_tag_re_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2442, v_n_2410});
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2eoutRw_str2, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2eoutRw_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2eoutRw_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2eoutRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2eoutRw_entry, 2, 0};

V g_heff_2ecompile_2ecpr_2eoutRw(V v_lay_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ERecord: {
    V v_fs_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 1ULL, 2);
    HeffT2 v_t_244 = (g_list_2efind_24s151864352x1148566527_24cpr(((V)&g_heff_2ecompile_2ecpr_2eoutRw_str0), heff_rfield(v_lay_240, 5)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_248;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        v_t_248 = v_x_247;
      } else {
        heff_drop(v_field_246);
        v_t_248 = heff_rec_n(5, shape_tag__index__tys__flds__places, (V[]){((V)&g_heff_2ecompile_2ecpr_2eoutRw_str1), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      V v_t_249 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24e_241_24ERecord, v_fs_242));
      return (g_heff_2ecompile_2ecpr_2ebuiltOut(v_lay_240, v_t_248, v_t_249));
    }
  }
  case TAG_ETag: {
    V v_t_2410 = heff_field(v_e_241, 0);
    V v_args_2411 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 3);
    HeffT2 v_t_2413 = (g_list_2efind_24s151864352x1148566527_24cpr(v_t_2410, heff_rfield(v_lay_240, 5)));
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      V v_t_2417;
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        heff_drop(v_t_2410);
        V v_x_2416 = v_field_2415;
        v_t_2417 = v_x_2416;
      } else {
        heff_drop(v_field_2415);
        v_t_2417 = heff_rec_n(5, shape_tag__index__tys__flds__places, (V[]){v_t_2410, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      }
      return (g_heff_2ecompile_2ecpr_2ebuiltOut(v_lay_240, v_t_2417, v_args_2411));
    }
  }
  case TAG_ECall: {
    V v_g_2418 = heff_field(v_e_241, 0);
    V v_args_2419 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam0, 1, 2, (V[]){v_g_2418, v_args_2419});
  }
  default: {
    heff_drop_rec(v_lay_240, 7);
    return heff_clo_n(g_heff_2ecompile_2ecpr_2eoutRw_lam1, 1, 1, (V[]){v_e_241});
  }
  }
}
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecpr_2eoutRw(a[0], a[1]);
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam0(V self, V *args) {
  V v_n_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_args_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_2418, ((V)&g_heff_2ecompile_2ecpr_2eoutRw_str2)), v_args_2419});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_n_2420});
}
V g_heff_2ecompile_2ecpr_2eoutRw_lam1(V self, V *args) {
  V v_n_2422 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2422});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_str1, 0, "");
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOf_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOf(V v_lay_240, V v_vs_241, V v_c_242) {
top: ;
  V v_places_243 = heff_take_field(v_c_242, 4);
  V v_tys_244 = heff_take_field(v_c_242, 2);
  V v_flds_245 = heff_take_field(v_c_242, 3);
  V v_tag_246 = heff_get_n(v_c_242, 0, 5);
  V v_record_247 = heff_take_field(v_lay_240, 3);
  V v_numbered_248 = heff_take_field(v_lay_240, 1);
  V v_labels_249 = heff_get_n(v_lay_240, 4, 7);
  V v_t_2410 = v_record_247;
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_flds_245);
    heff_drop(v_tag_246);
    heff_drop(v_t_2410);
    V v_t_2422 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_lam0, 2, 2, (V[]){v_numbered_248, heff_dup(v_vs_241)}), v_labels_249, v_places_243));
    return heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2422, v_tys_244});
  } else {
    heff_drop(v_labels_249);
    heff_drop(v_t_2410);
    V v_fs_2423 = v_flds_245;
    V v_xs_2434 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_lam1, 1, 2, (V[]){v_numbered_248, heff_dup(v_vs_241)}), v_places_243));
    V v_t_2435 = (g_heff_2ecompile_2ecpr_2esplitBy(heff_dup(v_fs_2423), v_xs_2434));
    V v_t_2436 = (g_list_2ezipWith_24s667382472x1709340739(v_fs_2423, v_t_2435));
    return heff_tag_n(TAG_ETag, 3, (V[]){v_tag_246, v_t_2436, v_tys_244});
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecpr_2ebuiltOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam0(V self, V *args) {
  V v_l_2411 = args[0];
  V v_i_2412 = args[1];
  V v_numbered_248 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = v_numbered_248;
  V v_t_2414;
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    v_t_2414 = heff_intAdd(v_i_2412, MK_INT(1LL));
  } else {
    heff_drop(v_t_2413);
    v_t_2414 = v_i_2412;
  }
  HeffT3 v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_t_2421;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      V v_x12_2420 = v_field_2418;
      heff_drop(v_x12_2420);
      v_t_2421 = v_x_2419;
    } else {
      heff_drop(v_field_2417);
      heff_drop(v_field_2418);
      v_t_2421 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_str0);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2411, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2421})});
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_lam1(V self, V *args) {
  V v_i_2424 = args[0];
  V v_numbered_248 = heff_env(self)[0];
  V v_vs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = v_numbered_248;
  V v_t_2426;
  if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
    heff_drop(v_t_2425);
    v_t_2426 = heff_intAdd(v_i_2424, MK_INT(1LL));
  } else {
    heff_drop(v_t_2425);
    v_t_2426 = v_i_2424;
  }
  HeffT3 v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = v_vs_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_241); r_; });
  {
    V v_field_2429 = v_t_2427.f[1];
    V v_field_2430 = v_t_2427.f[2];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    V v_t_2433;
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      V v_x_2431 = v_field_2429;
      V v_x12_2432 = v_field_2430;
      heff_drop(v_x12_2432);
      v_t_2433 = v_x_2431;
    } else {
      heff_drop(v_field_2429);
      heff_drop(v_field_2430);
      v_t_2433 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_str1);
    }
    return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2433});
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str1, 4, "True");
HEFF_LIT(g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str2, 5, "False");
Clo g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(V v_lit_240, V v_lit_241, V v_vs_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return NTAG(TAG_EAbandon);
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_243, 0);
    V v_x32_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      HEFF_LAST return g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(v_ru_24x3_243_24Cons, heff_dup(v_lit_240), v_lit_241, v_c_244);
    }
    case TAG_Cons: {
      V v_yes_248 = (g_heff_2ecompile_2ecpr_2ebuiltOf(heff_dup(v_lit_240), v_lit_241, heff_dup(v_c_244)));
      V v_no_249 = (g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(v_lit_240, v_lit_241, v_vs_242, v_x32_245));
      V v_t_2412;
      switch (heff_tag_of(v_vs_242)) {
      case TAG_Nil: {
        v_t_2412 = ((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_vs_242, 0);
        v_t_2412 = heff_dup(v_x_2410);
        break;
      }
      default: heff_nomatch(v_vs_242);
      }
      V v_t_2413 = heff_tag_n(TAG_OfFixed, 2, (V[]){NTAG(TAG_I64), NTAG(TAG_OpEq)});
      V v_t_2414 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I64), heff_get_n(v_c_244, 1, 5)});
      V v_t_2415 = heff_tag_n(TAG_CRel, 3, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2412}), v_t_2414});
      V v_t_2416 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str1), NTAG(TAG_Nil), v_yes_248});
      V v_t_2417 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_str2), NTAG(TAG_Nil), v_no_249});
      V v_t_2418 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_t_2415}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2418})});
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str1, 3, "tag");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str2, 5, "field");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str3, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str4, 4, "$cpr");

HeffT2 g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr(V v_lay_240, V v_d_241, V v_xs_242, V v_z_243) {
top: ;
  V v_m_244 = (g_prelude_2etraverse_24s75890152x1871550235(MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str0), MK_INT(1LL), v_xs_242));
  V v_x2_245 = heff_tr(heff_call(v_m_244, 1, (V[]){v_z_243}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_dup(heff_rfield(v_lay_240, 1));
    V v_t_2410;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2410 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_Cons, 2, (V[]){v_t_249, heff_dup(heff_rfield(v_lay_240, 2))});
    } else {
      heff_drop_cell(v_ru_24x2_245_24MkPair, 2);
      heff_drop(v_t_248);
      v_t_2410 = heff_dup(heff_rfield(v_lay_240, 2));
    }
    V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2410; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2411, MK_INT(1LL))));
    HeffT2 v_t_2413 = (g_prelude_2etraverse_24s1023157662x1060337521_24cpr(heff_dup(v_lay_240), MK_INT(0LL), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str1), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str2), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str3), MK_INT(1LL), v_t_2412, v_n_247));
    {
      V v_field_2414 = v_t_2413.f[0];
      V v_field_2415 = v_t_2413.f[1];
      V v_x_2416 = v_field_2414;
      V v_n_2417 = v_field_2415;
      V v_t_2418 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_246)));
      V v_t_2419 = (g_heff_2ecompile_2ecpr_2echosen_24s1452175660x1050906010(v_lay_240, v_x_2416, v_x_2416, heff_dup(heff_rfield(v_lay_240, 5))));
      V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr_str4));
      V v_t_2421 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_get_n(v_lay_240, 0, 7), v_x_2416, v_t_2419});
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
      V v_t_2423 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_t_2420, v_t_2418}), v_t_2422});
      V v_body_2424 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_246, v_t_2423});
      V v_f_2425 = ({ V rv_2 = v_body_2424; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return ((HeffT2){{v_f_2425, v_n_2417}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_245)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2edefWith_str0, 4, "$cpr");
V g_heff_2ecompile_2ecpr_2edefWith_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam1(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam2(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam3(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam4(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam5(V self, V *args);
V g_heff_2ecompile_2ecpr_2edefWith_lam6(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2edefWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2edefWith_entry, 3, 0};

V g_heff_2ecompile_2ecpr_2edefWith(V v_k_240, V v_d_241, V v_m_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_t_243, 0);
    V v_b_245 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_m_242)) {
    case TAG_Nothing: {
      heff_drop(v_xs_244);
      heff_drop(v_b_245);
      V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
      V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
      V v_t_2413 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam0, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_247; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_247); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_m_2414 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
        return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam1, 1, 2, (V[]){v_m_2414, v_d_241});
      } else {
        heff_drop(v_t_2413);
        return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam2, 1, 1, (V[]){v_d_241});
      }
    }
    case TAG_Just: {
      V v_lay_2423 = heff_field(v_m_242, 0);
      V v_m_2424 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, v_b_245));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam3, 1, 4, (V[]){v_m_2424, heff_dup(v_lay_2423), v_d_241, v_xs_244});
    }
    default: return heff_nomatch(v_m_242);
    }
  }
  default: {
    heff_drop(v_t_243);
    V v_t_2441 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_d_241, 2))));
    V v_t_2442 = (g_heff_2ecompile_2eir_2enubI(v_t_2441));
    V v_t_2448 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam4, 1, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2442; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2442); r_; });
    if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
      heff_drop(v_t_2448);
      V v_m_2449 = (g_heff_2ecompile_2ecpr_2erw(v_k_240, heff_dup(heff_rfield(v_d_241, 2))));
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam5, 1, 2, (V[]){v_m_2449, v_d_241});
    } else {
      heff_drop(v_t_2448);
      return heff_clo_n(g_heff_2ecompile_2ecpr_2edefWith_lam6, 1, 1, (V[]){v_d_241});
    }
  }
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2edefWith(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2edefWith_lam0(V self, V *args) {
  V v_g_248 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_249 = ({ V a_0 = v_k_240; V a_1 = v_g_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x_2412); c_; })));
    heff_drop(v_field_2411);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2419 = ({ V rv_2 = v_x_2417; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2420, v_n_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_n_2421});
}
V g_heff_2ecompile_2ecpr_2edefWith_lam3(V self, V *args) {
  V v_n_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_lay_2423 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_xs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_n_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_MkPair: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    V v_n_2428 = heff_field(v_x2_2426, 1);
    V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
    V v_t_2429 = (g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(v_lay_2423, v_x_2427));
    V v_x2_2430 = heff_tr(heff_call(v_t_2429, 1, (V[]){v_n_2428}));
    switch (heff_tag_of(v_x2_2430)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_field(v_x2_2430, 0);
      V v_n_2432 = heff_field(v_x2_2430, 1);
      V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
      HeffT2 v_t_2433 = (g_heff_2ecompile_2ecpr_2ewrapperOf_24cpr(v_lay_2423, heff_dup(v_d_241), heff_dup(v_xs_244), v_n_2432));
      {
        V v_field_2434 = v_t_2433.f[0];
        V v_field_2435 = v_t_2433.f[1];
        V v_x_2436 = v_field_2434;
        V v_n_2437 = v_field_2435;
        V v_t_2438 = heff_strAppend(heff_take_field(v_d_241, 0), ((V)&g_heff_2ecompile_2ecpr_2edefWith_str0));
        V v_t_2439 = ({ V rv_0 = v_t_2438; V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, v_x_2431}); V rr_ = heff_rec_reuse_nf(v_d_241, 2ULL, 3, shape_key__name__body, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2440 = heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_Cons, 2, (V[]){v_x_2436, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_t_2440}), v_n_2437});
      }
    }
    default: return heff_nomatch(v_x2_2430);
    }
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam4(V self, V *args) {
  V v_g_2443 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2444 = ({ V a_0 = v_k_240; V a_1 = v_g_2443; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_k_240); heff_drop(v_g_2443); r_; });
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2445 == ((int64_t)0ULL)) && ({ V v_x_2447 = heff_dup(v_field_2446); int c_ = 1; heff_drop(v_x_2447); c_; })));
    heff_drop(v_field_2446);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam5(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    V v_t_2454 = ({ V rv_2 = v_x_2452; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2455, v_n_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2ecpr_2edefWith_lam6(V self, V *args) {
  V v_n_2456 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2457, v_n_2456});
}
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str1, 0, "");
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry, 4, 0};

V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(V v_tok_240, V v_lay_241, V v_vs_242, V v_c_243) {
top: ;
  V v_places_244 = heff_take_field(v_c_243, 4);
  V v_tys_245 = heff_take_field(v_c_243, 2);
  V v_flds_246 = heff_take_field(v_c_243, 3);
  V v_tag_247 = heff_get_n(v_c_243, 0, 5);
  V v_record_248 = heff_take_field(v_lay_241, 3);
  V v_numbered_249 = heff_take_field(v_lay_241, 1);
  V v_labels_2410 = heff_get_n(v_lay_241, 4, 7);
  V v_t_2411 = v_record_248;
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_flds_246);
    heff_drop(v_tag_247);
    heff_drop(v_t_2411);
    V v_t_2423 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0, 2, 2, (V[]){v_numbered_249, heff_dup(v_vs_242)}), v_labels_2410, v_places_244));
    return heff_tag_at_n(v_tok_240, TAG_ERecord, 2, (V[]){v_t_2423, v_tys_245});
  } else {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_labels_2410);
    heff_drop(v_t_2411);
    V v_fs_2424 = v_flds_246;
    V v_xs_2435 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1, 1, 2, (V[]){v_numbered_249, heff_dup(v_vs_242)}), v_places_244));
    V v_t_2436 = (g_heff_2ecompile_2ecpr_2esplitBy(heff_dup(v_fs_2424), v_xs_2435));
    V v_t_2437 = (g_list_2ezipWith_24s667382472x1709340739(v_fs_2424, v_t_2436));
    return heff_tag_n(TAG_ETag, 3, (V[]){v_tag_247, v_t_2437, v_tys_245});
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam0(V self, V *args) {
  V v_l_2412 = args[0];
  V v_i_2413 = args[1];
  V v_numbered_249 = heff_env(self)[0];
  V v_vs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = v_numbered_249;
  V v_t_2415;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    v_t_2415 = heff_intAdd(v_i_2413, MK_INT(1LL));
  } else {
    heff_drop(v_t_2414);
    v_t_2415 = v_i_2413;
  }
  HeffT3 v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_vs_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_242); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    V v_field_2419 = v_t_2416.f[2];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_t_2422;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2418;
      V v_x12_2421 = v_field_2419;
      heff_drop(v_x12_2421);
      v_t_2422 = v_x_2420;
    } else {
      heff_drop(v_field_2418);
      heff_drop(v_field_2419);
      v_t_2422 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str0);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2412, heff_tag_n(TAG_EVar, 1, (V[]){v_t_2422})});
  }
}
V g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_lam1(V self, V *args) {
  V v_i_2425 = args[0];
  V v_numbered_249 = heff_env(self)[0];
  V v_vs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = v_numbered_249;
  V v_t_2427;
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_drop(v_t_2426);
    v_t_2427 = heff_intAdd(v_i_2425, MK_INT(1LL));
  } else {
    heff_drop(v_t_2426);
    v_t_2427 = v_i_2425;
  }
  HeffT3 v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_vs_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_242); r_; });
  {
    V v_field_2430 = v_t_2428.f[1];
    V v_field_2431 = v_t_2428.f[2];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    V v_t_2434;
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_x_2432 = v_field_2430;
      V v_x12_2433 = v_field_2431;
      heff_drop(v_x12_2433);
      v_t_2434 = v_x_2432;
    } else {
      heff_drop(v_field_2430);
      heff_drop(v_field_2431);
      v_t_2434 = ((V)&g_heff_2ecompile_2ecpr_2ebuiltOf_24tok2_str1);
    }
    return heff_tag_n(TAG_EVar, 1, (V[]){v_t_2434});
  }
}