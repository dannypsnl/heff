// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_DeclareField 57313
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IntWord 51777
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RuneWord 42901
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_StringWord 15530
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_cmt 308164
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_digits 615232529
#define LBL_e 319
#define LBL_err 310239
#define LBL_exponent 966452320
#define LBL_first 298798794
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_negative 1666250321
#define LBL_text 10052084
#define LBL_tok 324554
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey(V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo;
V g_heff_2esyntax_2eformat_2ekeyDeclF(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo;
V g_heff_2esyntax_2eformat_2ekeyTermF(V, V);
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo;
V g_heff_2esyntax_2eformat_2ekeys_get(void);
V g_heff_2esyntax_2eformat_2elamKey(V, V);
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2elamKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
HeffT2 g_heff_2esyntax_2eformat_2esameMeaning_24cpr(V, V, V, V);
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2eformat_2estrsEq(V, V);
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estrsEq_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2016443462x370533815(V);
V g_list_2emap_24s2016443462x370533815_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s23414532x1067218554(V, V, V, V, V, V);
V g_list_2emap_24s23414532x1067218554_entry(V self, V *a);
extern Clo g_list_2emap_24s23414532x1067218554_clo;
V g_list_2emap_24s903588428x1469638784(V, V);
V g_list_2emap_24s903588428x1469638784_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str0, 4, "(var");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str2, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str4, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str5, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str6, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str10, 4, "(tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str19, 3, "(op");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str22, 4, "(int");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str23, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str27, 6, "(float");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str28, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str29, 7, "(string");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str31, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str32, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str33, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str34, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str35, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str37, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str38, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str39, 7, "(binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str40, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str42, 5, "(rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str43, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str44, 6, "(field");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str46, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str47, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str48, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str49, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str50, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str51, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str52, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str54, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str55, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str56, 7, "(record");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str57, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str58, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str59, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str60, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str61, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str62, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str63, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str64, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str65, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str66, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str67, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str68, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str69, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str70, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str71, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str72, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str73, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str75, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str76, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str77, 5, "(word");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str78, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str80, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str81, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str82, 3, "(as");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str83, 1, ")");
Clo g_heff_2esyntax_2eformat_2epatKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epatKey_entry, 1, 0};

V g_heff_2esyntax_2eformat_2epatKey(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_244 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str0), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str1), v_x_243));
      return heff_strAppend(v_t_244, ((V)&g_heff_2esyntax_2eformat_2epatKey_str2));
    }
    case TAG_PatTag: {
      V v_t_245 = heff_field(v_x11_241, 0);
      V v_ps_247 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_x2_248 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_247));
      V v_t_2411;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str4); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str5), v_t_2411), ((V)&g_heff_2esyntax_2eformat_2epatKey_str6));
      V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_parts_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2413});
      V v_x2_2415 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str7), v_parts_2414));
      V v_t_2418;
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_Nil: {
        v_t_2418 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_xs_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        v_t_2418 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str9); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2415);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str10), v_t_2418), ((V)&g_heff_2esyntax_2eformat_2epatKey_str11));
    }
    case TAG_PatOp: {
      V v_x_2419 = heff_field(v_x11_241, 0);
      V v_ps_2421 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_x2_2422 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2421));
      V v_t_2425;
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_xs_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        v_t_2425 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str13); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2422);
      }
      V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str14), v_t_2425), ((V)&g_heff_2esyntax_2eformat_2epatKey_str15));
      V v_t_2427 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
      V v_parts_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2419, v_t_2427});
      V v_x2_2429 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str16), v_parts_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str17);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str18); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str19), v_t_2432), ((V)&g_heff_2esyntax_2eformat_2epatKey_str20));
    }
    case TAG_PatInt: {
      V v_i_2433 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str21), heff_intShow(v_i_2433));
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str22), v_t_2434), ((V)&g_heff_2esyntax_2eformat_2epatKey_str23));
    }
    case TAG_PatFloat: {
      V v_x_2435 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_negative_2436 = heff_take_field(v_x_2435, 0);
      V v_digits_2437 = heff_take_field(v_x_2435, 1);
      V v_exponent_2438 = heff_get_n(v_x_2435, 2, 3);
      V v_t_2439 = v_negative_2436;
      double v_t_2441;
      if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
        heff_drop(v_t_2439);
        double v_x_2440 = ({ V a_0 = v_digits_2437; V a_1 = v_exponent_2438; double r_ = (g_std_2emath_2efromDecimal_w(a_0, a_1)); heff_drop(v_exponent_2438); r_; });
        v_t_2441 = ((-1.0) * v_x_2440);
      } else {
        heff_drop(v_t_2439);
        v_t_2441 = ({ V a_0 = v_digits_2437; V a_1 = v_exponent_2438; double r_ = (g_std_2emath_2efromDecimal_w(a_0, a_1)); heff_drop(v_exponent_2438); r_; });
      }
      V v_parts_2442 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_floatShow(heff_box_f64(v_t_2441)), NTAG(TAG_Nil)});
      V v_x2_2443 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str24), v_parts_2442));
      V v_t_2446;
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_Nil: {
        v_t_2446 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str25);
        break;
      }
      case TAG_Cons: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        V v_xs_2445 = heff_field(v_x2_2443, 1);
        heff_take_n(v_x2_2443, 3ULL, 2);
        v_t_2446 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str26); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2443);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str27), v_t_2446), ((V)&g_heff_2esyntax_2eformat_2epatKey_str28));
    }
    case TAG_PatString: {
      V v_x_2447 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2448 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str29), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str30), v_x_2447));
      return heff_strAppend(v_t_2448, ((V)&g_heff_2esyntax_2eformat_2epatKey_str31));
    }
    case TAG_PatBinary: {
      V v_segs_2449 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_x2_2450 = (g_list_2emap_24s2016443462x370533815(v_segs_2449));
      V v_t_2453;
      switch (heff_tag_of(v_x2_2450)) {
      case TAG_Nil: {
        v_t_2453 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str32);
        break;
      }
      case TAG_Cons: {
        V v_x_2451 = heff_field(v_x2_2450, 0);
        V v_xs_2452 = heff_field(v_x2_2450, 1);
        heff_take_n(v_x2_2450, 3ULL, 2);
        v_t_2453 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str33); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2450);
      }
      V v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str34), v_t_2453), ((V)&g_heff_2esyntax_2eformat_2epatKey_str35));
      V v_parts_2455 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
      V v_x2_2456 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str36), v_parts_2455));
      V v_t_2459;
      switch (heff_tag_of(v_x2_2456)) {
      case TAG_Nil: {
        v_t_2459 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str37);
        break;
      }
      case TAG_Cons: {
        V v_x_2457 = heff_field(v_x2_2456, 0);
        V v_xs_2458 = heff_field(v_x2_2456, 1);
        heff_take_n(v_x2_2456, 3ULL, 2);
        v_t_2459 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str38); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2456);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str39), v_t_2459), ((V)&g_heff_2esyntax_2eformat_2epatKey_str40));
    }
    case TAG_PatRune: {
      V v_c_2460 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2461 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str41), heff_intShow(v_c_2460));
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str42), v_t_2461), ((V)&g_heff_2esyntax_2eformat_2epatKey_str43));
    }
    case TAG_PatRecord: {
      V v_fs_2462 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_x2_2463 = (g_list_2emap_24s23414532x1067218554(((V)&g_heff_2esyntax_2eformat_2epatKey_str44), ((V)&g_heff_2esyntax_2eformat_2epatKey_str45), ((V)&g_heff_2esyntax_2eformat_2epatKey_str46), ((V)&g_heff_2esyntax_2eformat_2epatKey_str47), ((V)&g_heff_2esyntax_2eformat_2epatKey_str48), v_fs_2462));
      V v_t_2466;
      switch (heff_tag_of(v_x2_2463)) {
      case TAG_Nil: {
        v_t_2466 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str49);
        break;
      }
      case TAG_Cons: {
        V v_x_2464 = heff_field(v_x2_2463, 0);
        V v_xs_2465 = heff_field(v_x2_2463, 1);
        heff_take_n(v_x2_2463, 3ULL, 2);
        v_t_2466 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str50); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2463);
      }
      V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str51), v_t_2466), ((V)&g_heff_2esyntax_2eformat_2epatKey_str52));
      V v_parts_2468 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
      V v_x2_2469 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str53), v_parts_2468));
      V v_t_2472;
      switch (heff_tag_of(v_x2_2469)) {
      case TAG_Nil: {
        v_t_2472 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str54);
        break;
      }
      case TAG_Cons: {
        V v_x_2470 = heff_field(v_x2_2469, 0);
        V v_xs_2471 = heff_field(v_x2_2469, 1);
        heff_take_n(v_x2_2469, 3ULL, 2);
        v_t_2472 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str55); V a_1 = v_x_2470; V a_2 = v_xs_2471; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2471); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2469);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str56), v_t_2472), ((V)&g_heff_2esyntax_2eformat_2epatKey_str57));
    }
    case TAG_PatWord: {
      V v_w_2473 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2475;
      switch (heff_tag_of(v_w_2473)) {
      case TAG_TypeWord: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str58);
        break;
      }
      case TAG_IntWord: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str59);
        break;
      }
      case TAG_FloatWord: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str60);
        break;
      }
      case TAG_StringWord: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str61);
        break;
      }
      case TAG_RuneWord: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str62);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str63);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str64);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2474 = heff_field(v_w_2473, 0);
        heff_take_n(v_w_2473, 1ULL, 1);
        switch (heff_tag_of(v_w_2474)) {
        case TAG_I8: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str65);
          break;
        }
        case TAG_I16: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str66);
          break;
        }
        case TAG_I32: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str67);
          break;
        }
        case TAG_I64: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str68);
          break;
        }
        case TAG_U8: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str69);
          break;
        }
        case TAG_U16: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str70);
          break;
        }
        case TAG_U32: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str71);
          break;
        }
        case TAG_U64: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str72);
          break;
        }
        case TAG_F32: {
          v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str73);
          break;
        }
        default: heff_nomatch(v_w_2474);
        }
        break;
      }
      default: heff_nomatch(v_w_2473);
      }
      V v_t_2476 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2475, NTAG(TAG_Nil)});
      V v_x2_2477 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str74), v_t_2476));
      V v_t_2480;
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_Nil: {
        v_t_2480 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str75);
        break;
      }
      case TAG_Cons: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_xs_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        v_t_2480 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str76); V a_1 = v_x_2478; V a_2 = v_xs_2479; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2479); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2477);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str77), v_t_2480), ((V)&g_heff_2esyntax_2eformat_2epatKey_str78));
    }
    case TAG_PatAs: {
      V v_x_2481 = heff_field(v_x11_241, 0);
      V v_q_2483 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_t_2484 = (g_heff_2esyntax_2eformat_2epatKey(v_q_2483));
      V v_t_2485 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
      V v_parts_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2481, v_t_2485});
      V v_x2_2487 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str79), v_parts_2486));
      V v_t_2490;
      switch (heff_tag_of(v_x2_2487)) {
      case TAG_Nil: {
        v_t_2490 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str80);
        break;
      }
      case TAG_Cons: {
        V v_x_2488 = heff_field(v_x2_2487, 0);
        V v_xs_2489 = heff_field(v_x2_2487, 1);
        heff_take_n(v_x2_2487, 3ULL, 2);
        v_t_2490 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str81); V a_1 = v_x_2488; V a_2 = v_xs_2489; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2489); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2487);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str82), v_t_2490), ((V)&g_heff_2esyntax_2eformat_2epatKey_str83));
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2epatKey(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str0, 5, "(name");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str2, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str3, 9, "(implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str9, 4, "(ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str10, 1, ")");
Clo g_heff_2esyntax_2eformat_2elamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2elamKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2elamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LamName: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_244 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str0), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str1), heff_dup(v_x_242)));
    return heff_strAppend(v_t_244, ((V)&g_heff_2esyntax_2eformat_2elamKey_str2));
  }
  case TAG_LamImplicit: {
    V v_x_245 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_r_240, 2);
    V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str4), heff_dup(v_x_245)));
    return heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2eformat_2elamKey_str5));
  }
  case TAG_LamAnn: {
    V v_x_248 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2410)}));
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_parts_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_248), v_t_2412});
    V v_x2_2414 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2elamKey_str6), v_parts_2413));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str8); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str9), v_t_2417), ((V)&g_heff_2esyntax_2eformat_2elamKey_str10));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2elamKey(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str3, 6, "(field");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str8, 6, "(field");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str13, 4, "(bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str14, 1, ")");
Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2efieldDeclKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2efieldDeclKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_x214_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      switch (heff_tag_of(v_x214_247)) {
      case TAG_Nothing: {
        V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
        V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        V v_parts_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_249});
        V v_x2_2411 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str0), v_parts_2410));
        V v_t_2414;
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Nil: {
          v_t_2414 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_xs_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 3ULL, 2);
          v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2411);
        }
        return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str3), v_t_2414), ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str4));
      }
      case TAG_Just: {
        V v_d_2415 = heff_field(v_x214_247, 0);
        heff_take_n(v_x214_247, 1ULL, 1);
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
        V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2415}));
        V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
        V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2418})});
        V v_x2_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str5), v_parts_2419));
        V v_t_2423;
        switch (heff_tag_of(v_x2_2420)) {
        case TAG_Nil: {
          v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_x2_2420, 0);
          V v_xs_2422 = heff_field(v_x2_2420, 1);
          heff_take_n(v_x2_2420, 3ULL, 2);
          v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str7); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2420);
        }
        return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str8), v_t_2423), ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str9));
      }
      default: return heff_nomatch(v_x214_247);
      }
    }
    case TAG_BadFieldDecl: {
      V v_e_2424 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2424}));
      V v_parts_2426 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
      V v_x2_2427 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str10), v_parts_2426));
      V v_t_2430;
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nil: {
        v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_xs_2429 = heff_field(v_x2_2427, 1);
        heff_take_n(v_x2_2427, 3ULL, 2);
        v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str12); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2427);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str13), v_t_2430), ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str14));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2efieldDeclKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str3, 5, "(bind");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str8, 4, "(let");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str13, 5, "(expr");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str18, 4, "(mut");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str21, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str22, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str23, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str27, 8, "(letelse");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str28, 1, ")");
Clo g_heff_2esyntax_2eformat_2estmtKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estmtKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estmtKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_e_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str3), v_t_2413), ((V)&g_heff_2esyntax_2eformat_2estmtKey_str4));
    }
    case TAG_StmtLet: {
      V v_p_2414 = heff_field(v_x21_242, 0);
      V v_e_2415 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24StmtLet = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2416 = (g_heff_2esyntax_2eformat_2epatKey(v_p_2414));
      V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2415}));
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_at_n(v_ru_24x21_242_24StmtLet, TAG_Cons, 2, (V[]){v_t_2416, v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str5), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str7); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str8), v_t_2423), ((V)&g_heff_2esyntax_2eformat_2estmtKey_str9));
    }
    case TAG_StmtExpr: {
      V v_e_2424 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2424}));
      V v_parts_2426 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
      V v_x2_2427 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str10), v_parts_2426));
      V v_t_2430;
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nil: {
        v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_xs_2429 = heff_field(v_x2_2427, 1);
        heff_take_n(v_x2_2427, 3ULL, 2);
        v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str12); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2427);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str13), v_t_2430), ((V)&g_heff_2esyntax_2eformat_2estmtKey_str14));
    }
    case TAG_StmtLetMut: {
      V v_x_2431 = heff_field(v_x21_242, 0);
      V v_e_2433 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2433}));
      V v_t_2435 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
      V v_parts_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2431, v_t_2435});
      V v_x2_2437 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str15), v_parts_2436));
      V v_t_2440;
      switch (heff_tag_of(v_x2_2437)) {
      case TAG_Nil: {
        v_t_2440 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2438 = heff_field(v_x2_2437, 0);
        V v_xs_2439 = heff_field(v_x2_2437, 1);
        heff_take_n(v_x2_2437, 3ULL, 2);
        v_t_2440 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str17); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2437);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str18), v_t_2440), ((V)&g_heff_2esyntax_2eformat_2estmtKey_str19));
    }
    case TAG_StmtLetElse: {
      V v_p_2441 = heff_field(v_x21_242, 0);
      V v_e_2442 = heff_field(v_x21_242, 1);
      V v_ss_2443 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_2444 = (g_heff_2esyntax_2eformat_2epatKey(v_p_2441));
      V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2442}));
      V v_f_2446 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_2447 = (g_list_2emap(v_f_2446, v_ss_2443));
      V v_t_2450;
      switch (heff_tag_of(v_x2_2447)) {
      case TAG_Nil: {
        v_t_2450 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_2448 = heff_field(v_x2_2447, 0);
        V v_xs_2449 = heff_field(v_x2_2447, 1);
        heff_take_n(v_x2_2447, 3ULL, 2);
        v_t_2450 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str21); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2447);
      }
      V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str22), v_t_2450), ((V)&g_heff_2esyntax_2eformat_2estmtKey_str23));
      V v_t_2452 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
      V v_parts_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2452})});
      V v_x2_2454 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str24), v_parts_2453));
      V v_t_2457;
      switch (heff_tag_of(v_x2_2454)) {
      case TAG_Nil: {
        v_t_2457 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str25);
        break;
      }
      case TAG_Cons: {
        V v_x_2455 = heff_field(v_x2_2454, 0);
        V v_xs_2456 = heff_field(v_x2_2454, 1);
        heff_take_n(v_x2_2454, 3ULL, 2);
        v_t_2457 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str26); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2454);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str27), v_t_2457), ((V)&g_heff_2esyntax_2eformat_2estmtKey_str28));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2estmtKey(a[0], a[1]);
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam0, 1, 0};
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam1, 1, 0};

static V g_heff_2esyntax_2eformat_2ekeys_val;
static HEFF_ONCE g_heff_2esyntax_2eformat_2ekeys_st;
static V g_heff_2esyntax_2eformat_2ekeys_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2eformat_2ekeys_lam0_clo), ((V)&g_heff_2esyntax_2eformat_2ekeys_lam1_clo)});
}
V g_heff_2esyntax_2eformat_2ekeys_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eformat_2ekeys_st)) return g_heff_2esyntax_2eformat_2ekeys_val;
  return heff_global(&g_heff_2esyntax_2eformat_2ekeys_val, &g_heff_2esyntax_2eformat_2ekeys_st, g_heff_2esyntax_2eformat_2ekeys_init);
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args) {
  V v_n_240 = args[0];
  return (g_heff_2esyntax_2eformat_2ekeyTermF(heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()), v_n_240));
}
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2eformat_2ekeyDeclF(heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()), v_d_241));
}
Clo g_heff_2esyntax_2eformat_2estrsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estrsEq_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estrsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_argv_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_argv_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2estrsEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str0, 55, "formatting would change the module claim or the imports");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str1, 68, "formatting would change what the file means (a bug of the formatter)");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str2, 76, "formatting would lose or move a comment across code (a bug of the formatter)");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str3, 68, "formatting would change what the file means (a bug of the formatter)");

HeffT2 g_heff_2esyntax_2eformat_2esameMeaning_24cpr(V v_src_240, V v_out_241, V v_a_242, V v_b_243) {
top: ;
  V v_imports_244 = heff_take_field(v_b_243, 0);
  V v_decls_245 = heff_take_field(v_b_243, 1);
  V v_diags_246 = heff_get_n(v_b_243, 2, 3);
  V v_imports_247 = heff_take_field(v_a_242, 0);
  V v_decls_248 = heff_take_field(v_a_242, 1);
  V v_diags_249 = heff_get_n(v_a_242, 2, 3);
  V v_x1_2410 = ({ V a_0 = v_imports_247; V a_1 = v_imports_244; V r_ = (g_heff_2esyntax_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_imports_247); heff_drop(v_imports_244); r_; });
  if (!(heff_dup(v_x1_2410) == NTAG(TAG_True))) {
    heff_drop(v_out_241);
    heff_drop(v_decls_245);
    heff_drop(v_diags_246);
    heff_drop(v_decls_248);
    heff_drop(v_diags_249);
    heff_drop(v_x1_2410);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str0)}});
  } else {
    heff_drop(v_x1_2410);
    V v_t_2411 = ({ V a_0 = v_decls_248; V a_1 = v_decls_245; V r_ = (g_heff_2esyntax_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_decls_248); heff_drop(v_decls_245); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_x1_2412 = ({ V a_0 = v_diags_249; V a_1 = v_diags_246; V r_ = (g_heff_2esyntax_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_diags_249); heff_drop(v_diags_246); r_; });
      if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
        heff_drop(v_out_241);
        heff_drop(v_x1_2412);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str1)}});
      } else {
        heff_drop(v_x1_2412);
        V v_t_2413 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
        V v_src_2414 = heff_get_n(v_t_2413, 3, 4);
        V v_t_2415 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        HeffT3 v_t_2416 = ({ V a_0 = v_src_2414; V a_1 = v_t_2415; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); HeffT3 r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2414); r_; });
        {
          V v_field_2419 = v_t_2416.f[2];
          heff_drop(v_t_2416.f[0]);
          heff_drop(v_t_2416.f[1]);
          V v_t_2420 = (g_list_2emap_24s903588428x1469638784(MK_INT(0LL), v_field_2419));
          V v_t_2421 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_out_241, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
          V v_src_2422 = heff_get_n(v_t_2421, 3, 4);
          V v_t_2423 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
          HeffT3 v_t_2424 = ({ V a_0 = v_src_2422; V a_1 = v_t_2423; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); HeffT3 r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2422); r_; });
          {
            V v_field_2427 = v_t_2424.f[2];
            heff_drop(v_t_2424.f[0]);
            heff_drop(v_t_2424.f[1]);
            V v_t_2428 = (g_list_2emap_24s903588428x1469638784(MK_INT(0LL), v_field_2427));
            V v_x1_2429 = ({ V a_0 = v_t_2420; V a_1 = v_t_2428; V r_ = (g_heff_2esyntax_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_t_2420); heff_drop(v_t_2428); r_; });
            if (!(heff_dup(v_x1_2429) == NTAG(TAG_True))) {
              heff_drop(v_out_241);
              heff_drop(v_x1_2429);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str2)}});
            } else {
              heff_drop(v_x1_2429);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_out_241}});
            }
          }
        }
      }
    } else {
      heff_drop(v_out_241);
      heff_drop(v_diags_246);
      heff_drop(v_diags_249);
      heff_drop(v_t_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str3)}});
    }
  }
}