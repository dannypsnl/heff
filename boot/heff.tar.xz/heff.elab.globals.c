// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_broken 566525696
#define LBL_entries 787768015
#define LBL_hidden 729654485
#define LBL_instances 1653559473
#define LBL_order 307364712
#define LBL_places 961367927
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void);
V g_heff_2eelab_2eglobals_2eisBroken(V, V);
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eisBroken_clo;
V g_heff_2eelab_2eglobals_2eplacesSaid(V);
V g_heff_2eelab_2eglobals_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eplacesSaid_clo;
V g_heff_2eelab_2eglobals_2eplacesSaid_24acc(V, V);
V g_heff_2eelab_2eglobals_2eplacesSaid_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eplacesSaid_24acc_clo;
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2eglobals_2eunderBrokenFrom(V, V, V);
V g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eunderBrokenFrom_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);

static V g_heff_2eelab_2eglobals_2eemptyGlobals_val;
static HEFF_ONCE g_heff_2eelab_2eglobals_2eemptyGlobals_st;
static V g_heff_2eelab_2eglobals_2eemptyGlobals_init(void) {
  return heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eglobals_2eemptyGlobals_st)) return g_heff_2eelab_2eglobals_2eemptyGlobals_val;
  return heff_global(&g_heff_2eelab_2eglobals_2eemptyGlobals_val, &g_heff_2eelab_2eglobals_2eemptyGlobals_st, g_heff_2eelab_2eglobals_2eemptyGlobals_init);
}
HEFF_LIT(g_heff_2eelab_2eglobals_2eunderBrokenFrom_str0, 1, ".");
Clo g_heff_2eelab_2eglobals_2eunderBrokenFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eunderBrokenFrom(V v_g_240, V v_x_241, V v_i_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2eelab_2eglobals_2eunderBrokenFrom_str0), v_x_241, v_i_242, 5);
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    return NTAG(TAG_False);
  } else {
    V v_t_244 = heff_strSlice_lent(v_x_241, MK_INT(0LL), heff_intAdd_lent(v_j_243, MK_INT(1LL), 2), 6);
    HeffT2 v_t_245 = ({ V a_0 = heff_rfield(v_g_240, 3); V a_1 = v_t_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_j_243);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_247);
        V t_0 = v_g_240;
        V t_1 = v_x_241;
        V t_2 = heff_intAdd(v_j_243, MK_INT(1LL));
        v_g_240 = t_0;
        v_x_241 = t_1;
        v_i_242 = t_2;
        goto top;
      }
    }
  }
}
V g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eglobals_2eunderBrokenFrom(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eglobals_2eisBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eisBroken_entry, 2, 0};

V g_heff_2eelab_2eglobals_2eisBroken(V v_g_240, V v_x_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_240, 2), v_x_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_k_245 = v_field_244;
      HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_g_240, 3, 8); V a_1 = v_k_245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_245); r_; });
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x_249 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x_249); c_; })));
        heff_drop(v_field_248);
        return v_ret_24bool;
      }
    } else {
      heff_drop(v_field_244);
      HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_g_240, 3), v_x_241));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop_rec(v_g_240, 8);
          V v_x_2413 = v_field_2412;
          heff_drop(v_x_2413);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_field_2412);
          return ({ V a_0 = v_g_240; V a_1 = v_x_241; V a_2 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eglobals_2eunderBrokenFrom(a_0, a_1, a_2)); heff_drop_rec(v_g_240, 8); r_; });
        }
      }
    }
  }
}
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eglobals_2eisBroken(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eglobals_2eaddEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eaddEntry_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eaddEntry(V v_x_240, V v_e_241, V v_g_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_g_242, 1), v_x_240));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_248;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      heff_drop(v_x_246);
      V v_t_247 = (g_list_2ekeepIf_24s930188071x496633547(v_x_240, heff_dup(heff_rfield(v_g_242, 0))));
      v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_240), v_t_247});
    } else {
      heff_drop(v_field_245);
      v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_240), heff_dup(heff_rfield(v_g_242, 0))});
    }
    V v_t_249 = ({ V a_0 = heff_take_field(v_g_242, 1); V a_1 = v_x_240; V a_2 = v_e_241; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
    return ({ V rv_0 = v_t_248; V rv_1 = v_t_249; V rr_ = heff_rec_reuse_nf(v_g_242, 252ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65520u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
}
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eglobals_2eaddEntry(a[0], a1, a[2]); heff_drop(a1); return r;
}

HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V v_g_240, V v_x_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_240, 4), v_x_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_x_241);
      V v_ks_245 = v_field_244;
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_ks_245, MK_INT(0LL)}});
    } else {
      heff_drop(v_field_244);
      HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_240, 2), v_x_241));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_k_249 = v_field_248;
          HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_240, 1), v_k_249));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              heff_drop_rec(v_g_240, 8);
              heff_drop(v_x_241);
              V v_e_2413 = v_field_2412;
              return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_k_249, v_e_2413}});
            } else {
              heff_drop(v_k_249);
              heff_drop(v_field_2412);
              V v_t_2414 = ({ V a_0 = v_g_240; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2eglobals_2eisBroken(a_0, a_1)); heff_drop(v_x_241); r_; });
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_t_2414);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              } else {
                heff_drop(v_t_2414);
                return ((HeffT3){{heff_word_i64(((int64_t)3ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          }
        } else {
          heff_drop(v_field_248);
          HeffT2 v_t_2415 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_g_240, 6), v_x_241));
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2417;
              heff_drop(v_x_2418);
              V v_t_2419 = ({ V a_0 = v_g_240; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2eglobals_2eisBroken(a_0, a_1)); heff_drop(v_x_241); r_; });
              if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
                heff_drop(v_t_2419);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              } else {
                heff_drop(v_t_2419);
                return ((HeffT3){{heff_word_i64(((int64_t)3ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_field_2417);
              HeffT2 v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_g_240, 1), v_x_241));
              {
                V v_field_2422 = v_t_2420.f[1];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  heff_drop_rec(v_g_240, 8);
                  V v_e_2423 = v_field_2422;
                  return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_x_241, v_e_2423}});
                } else {
                  heff_drop(v_field_2422);
                  V v_t_2424 = ({ V a_0 = v_g_240; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2eglobals_2eisBroken(a_0, a_1)); heff_drop(v_x_241); r_; });
                  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
                    heff_drop(v_t_2424);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  } else {
                    heff_drop(v_t_2424);
                    return ((HeffT3){{heff_word_i64(((int64_t)3ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eglobals_2eplacesSaid_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eglobals_2eplacesSaid_str1, 6, ", and ");
HEFF_LIT(g_heff_2eelab_2eglobals_2eplacesSaid_str2, 2, ", ");
Clo g_heff_2eelab_2eglobals_2eplacesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eplacesSaid_entry, 1, 0};

V g_heff_2eelab_2eglobals_2eplacesSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2eglobals_2eplacesSaid_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Cons: {
          V v_y_245 = heff_field(v_x12_242, 0);
          return heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2eelab_2eglobals_2eplacesSaid_str1)), heff_dup(v_y_245));
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2eelab_2eglobals_2eplacesSaid_str2));
        return (g_heff_2eelab_2eglobals_2eplacesSaid_24acc(v_x12_242, v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eglobals_2eplacesSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eglobals_2eplacesSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eglobals_2eplacesSaid_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eglobals_2eplacesSaid_24acc_str1, 6, ", and ");
HEFF_LIT(g_heff_2eelab_2eglobals_2eplacesSaid_24acc_str2, 2, ", ");
Clo g_heff_2eelab_2eglobals_2eplacesSaid_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eplacesSaid_24acc_entry, 2, 0};

V g_heff_2eelab_2eglobals_2eplacesSaid_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2eelab_2eglobals_2eplacesSaid_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_243)) {
        case TAG_Cons: {
          V v_y_246 = heff_field(v_x12_243, 0);
          V v_t_248 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_heff_2eelab_2eglobals_2eplacesSaid_24acc_str1));
          return heff_strAppend(v_t_248, heff_dup(v_y_246));
        }
        default: return heff_nomatch(v_x12_243);
        }
      }
      case TAG_Cons: {
        V v_s_2411 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_heff_2eelab_2eglobals_2eplacesSaid_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2411;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eglobals_2eplacesSaid_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eglobals_2eplacesSaid_24acc(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eglobals_2eaddOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eglobals_2eaddOwn_entry, 3, 0};

V g_heff_2eelab_2eglobals_2eaddOwn(V v_x_240, V v_k_241, V v_g_242) {
top: ;
  V v_t_243 = heff_take_field(v_g_242, 0);
  V v_t_244 = heff_take_field(v_g_242, 1);
  V v_t_245 = heff_take_field(v_g_242, 2);
  V v_t_246 = heff_take_field(v_g_242, 3);
  V v_t_247 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_g_242, 4), v_x_240));
  V v_t_248 = heff_take_field(v_g_242, 5);
  V v_t_249 = heff_take_field(v_g_242, 6);
  V v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_245, v_x_240, v_k_241));
  return ({ V rv_0 = v_t_243; V rv_1 = v_t_244; V rv_2 = v_t_2410; V rv_3 = v_t_246; V rv_4 = v_t_247; V rv_5 = v_t_248; V rv_6 = v_t_249; V rr_ = heff_rec_reuse_nf(v_g_242, 128ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 49152u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eglobals_2eaddOwn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}