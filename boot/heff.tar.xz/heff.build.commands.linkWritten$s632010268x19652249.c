// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2elinkOf(V);
V g_heff_2ebuild_2ecommands_2elinkOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkOf_clo;
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str4, 1, "\012");
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0(V v_outPath_240, V v_flags_241, V v_hd_242, V v_k_243, V v_x_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2ecommands_2elinkOf(heff_dup(v_outPath_240)));
  V v_t_248;
  switch (heff_tag_of(v_flags_241)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_flags_241, 0);
    V v_xs_247 = heff_field(v_flags_241, 1);
    v_t_248 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str1), heff_dup(v_x_246), v_xs_247));
    break;
  }
  default: heff_nomatch(v_flags_241);
  }
  V v_t_2411;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    heff_take_n(v_x_244, 0ULL, 1);
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2410 = heff_field(v_x_244, 0);
    V v_ru_24x_244_24Right = heff_take_reuse_n(v_x_244, 1ULL, 1);
    v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Right, TAG_Just, 1, (V[]){v_y_2410});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  HEFF_LAST return g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950(v_t_245, heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str2)), v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_lam0, 1, 3, (V[]){v_k_243, v_outPath_240, v_hd_242}));
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  if ((heff_dup(v_x_2412) == NTAG(TAG_True))) {
    heff_drop(v_x_2412);
    heff_clo_take(self, 3);
    heff_drop(v_outPath_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2412);
    heff_clo_take(self, 3);
    V v_t_2413 = (g_heff_2ebuild_2ecommands_2elinkOf(v_outPath_240));
    V v_str_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str3), v_t_2413);
    V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2414, ((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_str4)), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s632010268x19652249_2ek_24l0_lam1, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
}