// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_EndGive 48080
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define LBL_depth 296830685
#define LBL_head 9693863
#define LBL_muts 9858798
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1239681792x678203211_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s143795099x1025702421_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s814616358x897102902_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24dps_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2epatNames_str0, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2epatNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatNames_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_243, ((V)&g_heff_2esyntax_2epresyntax_2epatNames_str0), 2)) {
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_246));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_247); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2410 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2411); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2417 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2420 = heff_field(v_x11_241, 0);
      V v_q_2422 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_cell_2423 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2420, heff_hole()});
      V v_u_2424 = (g_heff_2esyntax_2epresyntax_2epatNames_24dps(v_q_2422, v_cell_2423));
      heff_drop(v_u_2424);
      return v_cell_2423;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatNames(a[0]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkSegment: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_a_2411 = heff_field(v_a_247, 2);
        V v_a_2412 = heff_field(v_a_247, 3);
        V v_a_2413 = heff_field(v_a_247, 4);
        V v_ru_24a_247_24MkSegment = heff_take_reuse_n(v_a_247, 31ULL, 5);
        V v_a_2443;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2443 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_249)) {
          case TAG_At: {
            V v_a_2414 = heff_dup(heff_field(v_a_249, 0));
            switch (heff_tag_of(v_a_2414)) {
            case TAG_ELam: {
              heff_take_n(v_a_2414, 0ULL, 2);
              switch (heff_tag_of(v_a_249)) {
              case TAG_At: {
                v_a_2443 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_249);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_2414, 0ULL, 1);
              switch (heff_tag_of(v_a_249)) {
              case TAG_At: {
                v_a_2443 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_249);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_2414, 0ULL, 1);
              switch (heff_tag_of(v_a_249)) {
              case TAG_At: {
                v_a_2443 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_249);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_2414, 0ULL, 1);
              switch (heff_tag_of(v_a_249)) {
              case TAG_At: {
                v_a_2443 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_249);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_2414, 0ULL, 1);
              switch (heff_tag_of(v_a_249)) {
              case TAG_At: {
                v_a_2443 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_249);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_2414, 0ULL, 4);
              switch (heff_tag_of(v_a_249)) {
              case TAG_At: {
                v_a_2443 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_249);
              }
              break;
            }
            default: {
              heff_drop(v_a_2414);
              HeffT2 v_t_2438 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_249)));
              {
                V v_field_2439 = v_t_2438.f[0];
                V v_field_2440 = v_t_2438.f[1];
                V v_a_2441 = v_field_2439;
                V v_a_2442 = v_field_2440;
                heff_drop(v_a_2442);
                v_a_2443 = v_a_2441;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_249);
          }
        }
        V v_t_2444 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkSegment, TAG_MkSegment, 5, 31ULL, (V[]){v_a_249, v_a_2410, v_a_2411, v_a_2412, v_a_2413}), v_a_248});
        V v_cell_2445 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2444, heff_hole()});
        V v_u_2446 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2445);
        V t_0 = v_a_2443;
        V t_1 = v_xs_246;
        V t_2 = v_u_2446;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2437;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2437 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_248, 0ULL, 4);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2432 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2433 = v_t_2432.f[0];
                V v_field_2434 = v_t_2432.f[1];
                V v_a_2435 = v_field_2433;
                V v_a_2436 = v_field_2434;
                heff_drop(v_a_2436);
                v_a_2437 = v_a_2435;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        V v_t_2438 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_a_246, v_a_247}), v_a_245});
        V v_cell_2439 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2438, heff_hole()});
        HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24dps_24cpr(v_a_2437, v_xs_243, v_cell_2439));
        {
          V v_field_2441 = v_t_2440.f[0];
          V v_field_2442 = v_t_2440.f[1];
          V v_x_2443 = v_field_2441;
          V v__5f_2444 = v_field_2442;
          heff_drop(v__5f_2444);
          return ((HeffT2){{v_x_2443, v_cell_2439}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkAlt: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24MkAlt = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2440;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2440 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_2410)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_a_2410, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_2411, 0ULL, 4);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2440 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2435 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_2410)));
              {
                V v_field_2436 = v_t_2435.f[0];
                V v_field_2437 = v_t_2435.f[1];
                V v_a_2438 = v_field_2436;
                V v_a_2439 = v_field_2437;
                heff_drop(v_a_2439);
                v_a_2440 = v_a_2438;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_2410);
          }
        }
        V v_t_2441 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2442 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2441, heff_hole()});
        V v_u_2443 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2442);
        V t_0 = v_a_2440;
        V t_1 = v_xs_246;
        V t_2 = v_u_2443;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_dup(heff_field(v_x3_241, 0));
    switch (heff_tag_of(v_x31_242)) {
    case TAG_EVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x31_242, 0ULL, 3);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EString: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EBinary: {
      V v_segs_2413 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EBinary = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2415 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_2416 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1685160129x1203636606_24cpr(heff_dup(v_st_240), v_segs_2413));
        {
          V v_field_2417 = v_t_2416.f[0];
          V v_field_2418 = v_t_2416.f[1];
          V v_x_2419 = v_field_2417;
          V v_y_2420 = v_field_2418;
          V v_t_2421 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EBinary, TAG_EBinary, 1, (V[]){v_y_2420}), v_sp_2415});
          return ((HeffT2){{v_x_2419, v_t_2421}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ERune: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EWord: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EApp: {
      V v_h_2424 = heff_field(v_x31_242, 0);
      V v_args_2425 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EApp = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2427 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2457;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_2457 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_h_2424)) {
          case TAG_At: {
            V v_e1_2428 = heff_dup(heff_field(v_h_2424, 0));
            switch (heff_tag_of(v_e1_2428)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2428, 0ULL, 2);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_2428, 0ULL, 1);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_2428, 0ULL, 4);
              switch (heff_tag_of(v_h_2424)) {
              case TAG_At: {
                v_x_2457 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_h_2424);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2428);
              HeffT2 v_t_2452 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_h_2424)));
              {
                V v_field_2453 = v_t_2452.f[0];
                V v_field_2454 = v_t_2452.f[1];
                V v_x_2455 = v_field_2453;
                V v_y_2456 = v_field_2454;
                heff_drop(v_y_2456);
                v_x_2457 = v_x_2455;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_h_2424);
          }
        }
        HeffT2 v_t_2458 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(v_x_2457, v_args_2425));
        {
          V v_field_2459 = v_t_2458.f[0];
          V v_field_2460 = v_t_2458.f[1];
          V v_x_2461 = v_field_2459;
          V v_y_2462 = v_field_2460;
          V v_t_2463 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EApp, TAG_EApp, 2, 1ULL, (V[]){v_h_2424, v_y_2462}), v_sp_2427});
          return ((HeffT2){{v_x_2461, v_t_2463}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EProject: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_ENamed: {
      V v_x_2465 = heff_field(v_x31_242, 0);
      V v_e_2466 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ENamed = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_2468 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_2498;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_2498 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_e_2466)) {
          case TAG_At: {
            V v_e1_2469 = heff_dup(heff_field(v_e_2466, 0));
            switch (heff_tag_of(v_e1_2469)) {
            case TAG_ELam: {
              heff_take_n(v_e1_2469, 0ULL, 2);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_2469, 0ULL, 1);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_2469, 0ULL, 1);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_2469, 0ULL, 1);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_2469, 0ULL, 1);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_2469, 0ULL, 4);
              switch (heff_tag_of(v_e_2466)) {
              case TAG_At: {
                v_x_2498 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2466);
              }
              break;
            }
            default: {
              heff_drop(v_e1_2469);
              HeffT2 v_t_2493 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_2466)));
              {
                V v_field_2494 = v_t_2493.f[0];
                V v_field_2495 = v_t_2493.f[1];
                V v_x_2496 = v_field_2494;
                V v_y_2497 = v_field_2495;
                heff_drop(v_y_2497);
                v_x_2498 = v_x_2496;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2466);
          }
        }
        V v_t_2499 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ENamed, TAG_ENamed, 2, 3ULL, (V[]){v_x_2465, v_e_2466}), v_sp_2468});
        return ((HeffT2){{v_x_2498, v_t_2499}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EPi: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_ELam: {
      V v_b_24102 = heff_field(v_x31_242, 0);
      V v_body_24103 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELam = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24105 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24135;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24135 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_body_24103)) {
          case TAG_At: {
            V v_e1_24106 = heff_dup(heff_field(v_body_24103, 0));
            switch (heff_tag_of(v_e1_24106)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24106, 0ULL, 2);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24106, 0ULL, 1);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24106, 0ULL, 1);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24106, 0ULL, 1);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24106, 0ULL, 1);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24106, 0ULL, 4);
              switch (heff_tag_of(v_body_24103)) {
              case TAG_At: {
                v_x_24135 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_body_24103);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24106);
              HeffT2 v_t_24130 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_body_24103)));
              {
                V v_field_24131 = v_t_24130.f[0];
                V v_field_24132 = v_t_24130.f[1];
                V v_x_24133 = v_field_24131;
                V v_y_24134 = v_field_24132;
                heff_drop(v_y_24134);
                v_x_24135 = v_x_24133;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_body_24103);
          }
        }
        V v_t_24136 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELam, TAG_ELam, 2, 3ULL, (V[]){v_b_24102, v_body_24103}), v_sp_24105});
        return ((HeffT2){{v_x_24135, v_t_24136}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EAnn: {
      V v_e_24137 = heff_field(v_x31_242, 0);
      V v_t_24138 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EAnn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24140 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24170;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24170 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_e_24137)) {
          case TAG_At: {
            V v_e1_24141 = heff_dup(heff_field(v_e_24137, 0));
            switch (heff_tag_of(v_e1_24141)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24141, 0ULL, 2);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24141, 0ULL, 1);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24141, 0ULL, 1);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24141, 0ULL, 1);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24141, 0ULL, 1);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24141, 0ULL, 4);
              switch (heff_tag_of(v_e_24137)) {
              case TAG_At: {
                v_x_24170 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24137);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24141);
              HeffT2 v_t_24165 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24137)));
              {
                V v_field_24166 = v_t_24165.f[0];
                V v_field_24167 = v_t_24165.f[1];
                V v_x_24168 = v_field_24166;
                V v_y_24169 = v_field_24167;
                heff_drop(v_y_24169);
                v_x_24170 = v_x_24168;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24137);
          }
        }
        V v_t_24171 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EAnn, TAG_EAnn, 2, 3ULL, (V[]){v_e_24137, v_t_24138}), v_sp_24140});
        return ((HeffT2){{v_x_24170, v_t_24171}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESpec: {
      V v_a_24172 = heff_field(v_x31_242, 0);
      V v_x_24173 = heff_field(v_x31_242, 1);
      V v_xsp_24174 = heff_field(v_x31_242, 2);
      V v_v_24175 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24ESpec = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24177 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          V v_t_24178 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
          return ((HeffT2){{NTAG(TAG_True), v_t_24178}});
        } else {
          switch (heff_tag_of(v_a_24172)) {
          case TAG_At: {
            V v_e1_24179 = heff_dup(heff_field(v_a_24172, 0));
            switch (heff_tag_of(v_e1_24179)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24179, 0ULL, 2);
              V v_x_24212;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24183 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24183)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24183, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24183, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24183, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24183, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24183, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24183, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24212 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24183);
                  HeffT2 v_t_24207 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24208 = v_t_24207.f[0];
                    V v_field_24209 = v_t_24207.f[1];
                    V v_x_24210 = v_field_24208;
                    V v_y_24211 = v_field_24209;
                    heff_drop(v_y_24211);
                    v_x_24212 = v_x_24210;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24213 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24212, v_t_24213}});
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24179, 0ULL, 1);
              V v_x_24244;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24215 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24215)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24215, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24215, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24215, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24215, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24215, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24215, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24244 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24215);
                  HeffT2 v_t_24239 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24240 = v_t_24239.f[0];
                    V v_field_24241 = v_t_24239.f[1];
                    V v_x_24242 = v_field_24240;
                    V v_y_24243 = v_field_24241;
                    heff_drop(v_y_24243);
                    v_x_24244 = v_x_24242;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24245 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24244, v_t_24245}});
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24179, 0ULL, 1);
              V v_t_24247 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{NTAG(TAG_True), v_t_24247}});
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24179, 0ULL, 1);
              V v_x_24278;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24249 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24249)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24249, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24249, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24249, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24249, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24249, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24249, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24278 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24249);
                  HeffT2 v_t_24273 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24274 = v_t_24273.f[0];
                    V v_field_24275 = v_t_24273.f[1];
                    V v_x_24276 = v_field_24274;
                    V v_y_24277 = v_field_24275;
                    heff_drop(v_y_24277);
                    v_x_24278 = v_x_24276;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24279 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24278, v_t_24279}});
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24179, 0ULL, 1);
              V v_x_24310;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24281 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24281)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24281, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24281, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24281, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24281, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24281, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24281, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24310 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24281);
                  HeffT2 v_t_24305 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24306 = v_t_24305.f[0];
                    V v_field_24307 = v_t_24305.f[1];
                    V v_x_24308 = v_field_24306;
                    V v_y_24309 = v_field_24307;
                    heff_drop(v_y_24309);
                    v_x_24310 = v_x_24308;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24311 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24310, v_t_24311}});
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24179, 0ULL, 4);
              V v_x_24345;
              switch (heff_tag_of(v_v_24175)) {
              case TAG_At: {
                V v_e1_24316 = heff_dup(heff_field(v_v_24175, 0));
                switch (heff_tag_of(v_e1_24316)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24316, 0ULL, 2);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24316, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24316, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24316, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24316, 0ULL, 1);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24316, 0ULL, 4);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    v_x_24345 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24316);
                  HeffT2 v_t_24340 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                  {
                    V v_field_24341 = v_t_24340.f[0];
                    V v_field_24342 = v_t_24340.f[1];
                    V v_x_24343 = v_field_24341;
                    V v_y_24344 = v_field_24342;
                    heff_drop(v_y_24344);
                    v_x_24345 = v_x_24343;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_v_24175);
              }
              V v_t_24346 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
              return ((HeffT2){{v_x_24345, v_t_24346}});
            }
            default: {
              heff_drop(v_e1_24179);
              HeffT2 v_t_24347 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24172)));
              {
                V v_field_24348 = v_t_24347.f[0];
                V v_field_24349 = v_t_24347.f[1];
                V v_x_24350 = v_field_24348;
                V v_y_24351 = v_field_24349;
                heff_drop(v_y_24351);
                V v_x_24381;
                if ((heff_dup(v_x_24350) == NTAG(TAG_True))) {
                  heff_drop(v_x_24350);
                  v_x_24381 = NTAG(TAG_True);
                } else {
                  heff_drop(v_x_24350);
                  switch (heff_tag_of(v_v_24175)) {
                  case TAG_At: {
                    V v_e1_24352 = heff_dup(heff_field(v_v_24175, 0));
                    switch (heff_tag_of(v_e1_24352)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24352, 0ULL, 2);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_EDo: {
                      heff_take_n(v_e1_24352, 0ULL, 1);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_ENest: {
                      heff_take_n(v_e1_24352, 0ULL, 1);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_ELazy: {
                      heff_take_n(v_e1_24352, 0ULL, 1);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_ETry: {
                      heff_take_n(v_e1_24352, 0ULL, 1);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    case TAG_EWith: {
                      heff_take_n(v_e1_24352, 0ULL, 4);
                      switch (heff_tag_of(v_v_24175)) {
                      case TAG_At: {
                        v_x_24381 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_v_24175);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24352);
                      HeffT2 v_t_24376 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_v_24175)));
                      {
                        V v_field_24377 = v_t_24376.f[0];
                        V v_field_24378 = v_t_24376.f[1];
                        V v_x_24379 = v_field_24377;
                        V v_y_24380 = v_field_24378;
                        heff_drop(v_y_24380);
                        v_x_24381 = v_x_24379;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_v_24175);
                  }
                }
                V v_t_24382 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ESpec, TAG_ESpec, 4, 15ULL, (V[]){v_a_24172, v_x_24173, v_xsp_24174, v_v_24175}), v_sp_24177});
                return ((HeffT2){{v_x_24381, v_t_24382}});
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24172)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ESig: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_ESum: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EStruct: {
      V v_fs_24385 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EStruct = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24387 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24388 = (g_heff_2esyntax_2epresyntax_2eaccList_24s814616358x897102902_24cpr(heff_dup(v_st_240), v_fs_24385));
        {
          V v_field_24389 = v_t_24388.f[0];
          V v_field_24390 = v_t_24388.f[1];
          V v_x_24391 = v_field_24389;
          V v_y_24392 = v_field_24390;
          V v_t_24393 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EStruct, TAG_EStruct, 1, (V[]){v_y_24392}), v_sp_24387});
          return ((HeffT2){{v_x_24391, v_t_24393}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EUpdate: {
      V v_a_24394 = heff_field(v_x31_242, 0);
      V v_fs_24395 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EUpdate = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24397 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24427;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24427 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_a_24394)) {
          case TAG_At: {
            V v_e1_24398 = heff_dup(heff_field(v_a_24394, 0));
            switch (heff_tag_of(v_e1_24398)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24398, 0ULL, 2);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24398, 0ULL, 1);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24398, 0ULL, 1);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24398, 0ULL, 1);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24398, 0ULL, 1);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24398, 0ULL, 4);
              switch (heff_tag_of(v_a_24394)) {
              case TAG_At: {
                v_x_24427 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_24394);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24398);
              HeffT2 v_t_24422 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24394)));
              {
                V v_field_24423 = v_t_24422.f[0];
                V v_field_24424 = v_t_24422.f[1];
                V v_x_24425 = v_field_24423;
                V v_y_24426 = v_field_24424;
                heff_drop(v_y_24426);
                v_x_24427 = v_x_24425;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_24394);
          }
        }
        HeffT2 v_t_24428 = (g_heff_2esyntax_2epresyntax_2eaccList_24s496186332x30239536_24cpr(v_x_24427, v_fs_24395));
        {
          V v_field_24429 = v_t_24428.f[0];
          V v_field_24430 = v_t_24428.f[1];
          V v_x_24431 = v_field_24429;
          V v_y_24432 = v_field_24430;
          V v_t_24433 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EUpdate, TAG_EUpdate, 2, 1ULL, (V[]){v_a_24394, v_y_24432}), v_sp_24397});
          return ((HeffT2){{v_x_24431, v_t_24433}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EMatch: {
      V v_s_24434 = heff_field(v_x31_242, 0);
      V v_alts_24435 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EMatch = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24437 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24467;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24467 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_s_24434)) {
          case TAG_At: {
            V v_e1_24438 = heff_dup(heff_field(v_s_24434, 0));
            switch (heff_tag_of(v_e1_24438)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24438, 0ULL, 2);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24438, 0ULL, 1);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24438, 0ULL, 1);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24438, 0ULL, 1);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24438, 0ULL, 1);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24438, 0ULL, 4);
              switch (heff_tag_of(v_s_24434)) {
              case TAG_At: {
                v_x_24467 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_s_24434);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24438);
              HeffT2 v_t_24462 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_s_24434)));
              {
                V v_field_24463 = v_t_24462.f[0];
                V v_field_24464 = v_t_24462.f[1];
                V v_x_24465 = v_field_24463;
                V v_y_24466 = v_field_24464;
                heff_drop(v_y_24466);
                v_x_24467 = v_x_24465;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_s_24434);
          }
        }
        HeffT2 v_t_24468 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1677166586x1409031985_24cpr(v_x_24467, v_alts_24435));
        {
          V v_field_24469 = v_t_24468.f[0];
          V v_field_24470 = v_t_24468.f[1];
          V v_x_24471 = v_field_24469;
          V v_y_24472 = v_field_24470;
          V v_t_24473 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_24434, v_y_24472}), v_sp_24437});
          return ((HeffT2){{v_x_24471, v_t_24473}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELetIn: {
      V v_rhs_24474 = heff_field(v_x31_242, 0);
      V v_a_24475 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24ELetIn = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24477 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          switch (heff_tag_of(v_a_24475)) {
          case TAG_At: {
            V v_x31_24478 = heff_field(v_a_24475, 0);
            V v_sp_24479 = heff_field(v_a_24475, 1);
            V v_ru_24a_24475_24At = heff_take_reuse_n(v_a_24475, 3ULL, 2);
            switch (heff_tag_of(v_x31_24478)) {
            case TAG_MkAlt: {
              V v_p_24480 = heff_field(v_x31_24478, 0);
              V v_e_24481 = heff_field(v_x31_24478, 1);
              V v_ru_24x31_24478_24MkAlt = heff_take_reuse_n(v_x31_24478, 3ULL, 2);
              V v_t_24482 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_24478_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_24480, v_e_24481}), v_sp_24479});
              V v_t_24483 = heff_tag_at_n(v_ru_24a_24475_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_24474, v_t_24482}), v_sp_24477});
              return ((HeffT2){{NTAG(TAG_True), v_t_24483}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24478)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24475)}});
          }
        } else {
          V v_x_24513;
          switch (heff_tag_of(v_rhs_24474)) {
          case TAG_At: {
            V v_e1_24484 = heff_dup(heff_field(v_rhs_24474, 0));
            switch (heff_tag_of(v_e1_24484)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24484, 0ULL, 2);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24484, 0ULL, 1);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24484, 0ULL, 1);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24484, 0ULL, 1);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24484, 0ULL, 1);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24484, 0ULL, 4);
              switch (heff_tag_of(v_rhs_24474)) {
              case TAG_At: {
                v_x_24513 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_rhs_24474);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24484);
              HeffT2 v_t_24508 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_rhs_24474)));
              {
                V v_field_24509 = v_t_24508.f[0];
                V v_field_24510 = v_t_24508.f[1];
                V v_x_24511 = v_field_24509;
                V v_y_24512 = v_field_24510;
                heff_drop(v_y_24512);
                v_x_24513 = v_x_24511;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_rhs_24474);
          }
          switch (heff_tag_of(v_a_24475)) {
          case TAG_At: {
            V v_x31_24514 = heff_field(v_a_24475, 0);
            V v_sp_24515 = heff_field(v_a_24475, 1);
            V v_ru_24a_24475_24At = heff_take_reuse_n(v_a_24475, 3ULL, 2);
            switch (heff_tag_of(v_x31_24514)) {
            case TAG_MkAlt: {
              V v_p_24516 = heff_field(v_x31_24514, 0);
              V v_e_24517 = heff_field(v_x31_24514, 1);
              V v_ru_24x31_24514_24MkAlt = heff_take_reuse_n(v_x31_24514, 3ULL, 2);
              V v_x_24547;
              if ((heff_dup(v_x_24513) == NTAG(TAG_True))) {
                heff_drop(v_x_24513);
                v_x_24547 = NTAG(TAG_True);
              } else {
                heff_drop(v_x_24513);
                switch (heff_tag_of(v_e_24517)) {
                case TAG_At: {
                  V v_e1_24518 = heff_dup(heff_field(v_e_24517, 0));
                  switch (heff_tag_of(v_e1_24518)) {
                  case TAG_ELam: {
                    heff_take_n(v_e1_24518, 0ULL, 2);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_EDo: {
                    heff_take_n(v_e1_24518, 0ULL, 1);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_ENest: {
                    heff_take_n(v_e1_24518, 0ULL, 1);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_True);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_ELazy: {
                    heff_take_n(v_e1_24518, 0ULL, 1);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_ETry: {
                    heff_take_n(v_e1_24518, 0ULL, 1);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  case TAG_EWith: {
                    heff_take_n(v_e1_24518, 0ULL, 4);
                    switch (heff_tag_of(v_e_24517)) {
                    case TAG_At: {
                      v_x_24547 = NTAG(TAG_False);
                      break;
                    }
                    default: heff_nomatch(v_e_24517);
                    }
                    break;
                  }
                  default: {
                    heff_drop(v_e1_24518);
                    HeffT2 v_t_24542 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24517)));
                    {
                      V v_field_24543 = v_t_24542.f[0];
                      V v_field_24544 = v_t_24542.f[1];
                      V v_x_24545 = v_field_24543;
                      V v_y_24546 = v_field_24544;
                      heff_drop(v_y_24546);
                      v_x_24547 = v_x_24545;
                    }
                    break;
                  }
                  }
                  break;
                }
                default: heff_nomatch(v_e_24517);
                }
              }
              V v_t_24548 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_24514_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_p_24516, v_e_24517}), v_sp_24515});
              V v_t_24549 = heff_tag_at_n(v_ru_24a_24475_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELetIn, TAG_ELetIn, 2, 1ULL, (V[]){v_rhs_24474, v_t_24548}), v_sp_24477});
              return ((HeffT2){{v_x_24547, v_t_24549}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_24514)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_24475)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EDo: {
      V v_ss_24550 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EDo = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24552 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24553 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(heff_dup(v_st_240), v_ss_24550));
        {
          V v_field_24554 = v_t_24553.f[0];
          V v_field_24555 = v_t_24553.f[1];
          V v_x_24556 = v_field_24554;
          V v_y_24557 = v_field_24555;
          V v_t_24558 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24EDo, TAG_EDo, 1, (V[]){v_y_24557}), v_sp_24552});
          return ((HeffT2){{v_x_24556, v_t_24558}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELocal: {
      heff_take_n(v_x31_242, 0ULL, 2);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_x31_242, 0ULL, 1);
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EAssign: {
      V v_x_24562 = heff_field(v_x31_242, 0);
      V v_xsp_24563 = heff_field(v_x31_242, 1);
      V v_e_24564 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EAssign = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24566 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24596;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24596 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_e_24564)) {
          case TAG_At: {
            V v_e1_24567 = heff_dup(heff_field(v_e_24564, 0));
            switch (heff_tag_of(v_e1_24567)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24567, 0ULL, 2);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24567, 0ULL, 1);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24567, 0ULL, 1);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24567, 0ULL, 1);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24567, 0ULL, 1);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24567, 0ULL, 4);
              switch (heff_tag_of(v_e_24564)) {
              case TAG_At: {
                v_x_24596 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24564);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24567);
              HeffT2 v_t_24591 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24564)));
              {
                V v_field_24592 = v_t_24591.f[0];
                V v_field_24593 = v_t_24591.f[1];
                V v_x_24594 = v_field_24592;
                V v_y_24595 = v_field_24593;
                heff_drop(v_y_24595);
                v_x_24596 = v_x_24594;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24564);
          }
        }
        V v_t_24597 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EAssign, TAG_EAssign, 3, 7ULL, (V[]){v_x_24562, v_xsp_24563, v_e_24564}), v_sp_24566});
        return ((HeffT2){{v_x_24596, v_t_24597}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWhile: {
      V v_c_24598 = heff_field(v_x31_242, 0);
      V v_body_24599 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EWhile = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24601 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24631;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24631 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_c_24598)) {
          case TAG_At: {
            V v_e1_24602 = heff_dup(heff_field(v_c_24598, 0));
            switch (heff_tag_of(v_e1_24602)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24602, 0ULL, 2);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24602, 0ULL, 1);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24602, 0ULL, 1);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24602, 0ULL, 1);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24602, 0ULL, 1);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24602, 0ULL, 4);
              switch (heff_tag_of(v_c_24598)) {
              case TAG_At: {
                v_x_24631 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24598);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24602);
              HeffT2 v_t_24626 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_c_24598)));
              {
                V v_field_24627 = v_t_24626.f[0];
                V v_field_24628 = v_t_24626.f[1];
                V v_x_24629 = v_field_24627;
                V v_y_24630 = v_field_24628;
                heff_drop(v_y_24630);
                v_x_24631 = v_x_24629;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_c_24598);
          }
        }
        HeffT2 v_t_24632 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_24631, v_body_24599));
        {
          V v_field_24633 = v_t_24632.f[0];
          V v_field_24634 = v_t_24632.f[1];
          V v_x_24635 = v_field_24633;
          V v_y_24636 = v_field_24634;
          V v_t_24637 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EWhile, TAG_EWhile, 2, 1ULL, (V[]){v_c_24598, v_y_24636}), v_sp_24601});
          return ((HeffT2){{v_x_24635, v_t_24637}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EFor: {
      V v_p_24638 = heff_field(v_x31_242, 0);
      V v_c_24639 = heff_field(v_x31_242, 1);
      V v_body_24640 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EFor = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24642 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24672;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24672 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_c_24639)) {
          case TAG_At: {
            V v_e1_24643 = heff_dup(heff_field(v_c_24639, 0));
            switch (heff_tag_of(v_e1_24643)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24643, 0ULL, 2);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24643, 0ULL, 1);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24643, 0ULL, 1);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24643, 0ULL, 1);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24643, 0ULL, 1);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24643, 0ULL, 4);
              switch (heff_tag_of(v_c_24639)) {
              case TAG_At: {
                v_x_24672 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_c_24639);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24643);
              HeffT2 v_t_24667 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_c_24639)));
              {
                V v_field_24668 = v_t_24667.f[0];
                V v_field_24669 = v_t_24667.f[1];
                V v_x_24670 = v_field_24668;
                V v_y_24671 = v_field_24669;
                heff_drop(v_y_24671);
                v_x_24672 = v_x_24670;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_c_24639);
          }
        }
        HeffT2 v_t_24673 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_24672, v_body_24640));
        {
          V v_field_24674 = v_t_24673.f[0];
          V v_field_24675 = v_t_24673.f[1];
          V v_x_24676 = v_field_24674;
          V v_y_24677 = v_field_24675;
          V v_t_24678 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EFor, TAG_EFor, 3, 3ULL, (V[]){v_p_24638, v_c_24639, v_y_24677}), v_sp_24642});
          return ((HeffT2){{v_x_24676, v_t_24678}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EIfThen: {
      V v_c_24679 = heff_field(v_x31_242, 0);
      V v_a_24680 = heff_field(v_x31_242, 1);
      V v_ru_24x31_242_24EIfThen = heff_take_reuse_n(v_x31_242, 3ULL, 2);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24682 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          V v_t_24683 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
          return ((HeffT2){{NTAG(TAG_True), v_t_24683}});
        } else {
          switch (heff_tag_of(v_c_24679)) {
          case TAG_At: {
            V v_e1_24684 = heff_dup(heff_field(v_c_24679, 0));
            switch (heff_tag_of(v_e1_24684)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24684, 0ULL, 2);
              V v_x_24717;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24688 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24688)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24688, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24688, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24688, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24688, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24688, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24688, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24717 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24688);
                  HeffT2 v_t_24712 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24713 = v_t_24712.f[0];
                    V v_field_24714 = v_t_24712.f[1];
                    V v_x_24715 = v_field_24713;
                    V v_y_24716 = v_field_24714;
                    heff_drop(v_y_24716);
                    v_x_24717 = v_x_24715;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24718 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24717, v_t_24718}});
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24684, 0ULL, 1);
              V v_x_24749;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24720 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24720)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24720, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24720, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24720, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24720, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24720, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24720, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24749 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24720);
                  HeffT2 v_t_24744 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24745 = v_t_24744.f[0];
                    V v_field_24746 = v_t_24744.f[1];
                    V v_x_24747 = v_field_24745;
                    V v_y_24748 = v_field_24746;
                    heff_drop(v_y_24748);
                    v_x_24749 = v_x_24747;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24750 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24749, v_t_24750}});
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24684, 0ULL, 1);
              V v_t_24752 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{NTAG(TAG_True), v_t_24752}});
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24684, 0ULL, 1);
              V v_x_24783;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24754 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24754)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24754, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24754, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24754, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24754, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24754, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24754, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24783 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24754);
                  HeffT2 v_t_24778 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24779 = v_t_24778.f[0];
                    V v_field_24780 = v_t_24778.f[1];
                    V v_x_24781 = v_field_24779;
                    V v_y_24782 = v_field_24780;
                    heff_drop(v_y_24782);
                    v_x_24783 = v_x_24781;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24784 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24783, v_t_24784}});
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24684, 0ULL, 1);
              V v_x_24815;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24786 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24786)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24786, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24786, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24786, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24786, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24786, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24786, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24815 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24786);
                  HeffT2 v_t_24810 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24811 = v_t_24810.f[0];
                    V v_field_24812 = v_t_24810.f[1];
                    V v_x_24813 = v_field_24811;
                    V v_y_24814 = v_field_24812;
                    heff_drop(v_y_24814);
                    v_x_24815 = v_x_24813;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24816 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24815, v_t_24816}});
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24684, 0ULL, 4);
              V v_x_24850;
              switch (heff_tag_of(v_a_24680)) {
              case TAG_At: {
                V v_e1_24821 = heff_dup(heff_field(v_a_24680, 0));
                switch (heff_tag_of(v_e1_24821)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_24821, 0ULL, 2);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_24821, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_24821, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_24821, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_24821, 0ULL, 1);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_24821, 0ULL, 4);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    v_x_24850 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_24821);
                  HeffT2 v_t_24845 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                  {
                    V v_field_24846 = v_t_24845.f[0];
                    V v_field_24847 = v_t_24845.f[1];
                    V v_x_24848 = v_field_24846;
                    V v_y_24849 = v_field_24847;
                    heff_drop(v_y_24849);
                    v_x_24850 = v_x_24848;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_a_24680);
              }
              V v_t_24851 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
              return ((HeffT2){{v_x_24850, v_t_24851}});
            }
            default: {
              heff_drop(v_e1_24684);
              HeffT2 v_t_24852 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_c_24679)));
              {
                V v_field_24853 = v_t_24852.f[0];
                V v_field_24854 = v_t_24852.f[1];
                V v_x_24855 = v_field_24853;
                V v_y_24856 = v_field_24854;
                heff_drop(v_y_24856);
                V v_x_24886;
                if ((heff_dup(v_x_24855) == NTAG(TAG_True))) {
                  heff_drop(v_x_24855);
                  v_x_24886 = NTAG(TAG_True);
                } else {
                  heff_drop(v_x_24855);
                  switch (heff_tag_of(v_a_24680)) {
                  case TAG_At: {
                    V v_e1_24857 = heff_dup(heff_field(v_a_24680, 0));
                    switch (heff_tag_of(v_e1_24857)) {
                    case TAG_ELam: {
                      heff_take_n(v_e1_24857, 0ULL, 2);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_EDo: {
                      heff_take_n(v_e1_24857, 0ULL, 1);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_ENest: {
                      heff_take_n(v_e1_24857, 0ULL, 1);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_True);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_ELazy: {
                      heff_take_n(v_e1_24857, 0ULL, 1);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_ETry: {
                      heff_take_n(v_e1_24857, 0ULL, 1);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    case TAG_EWith: {
                      heff_take_n(v_e1_24857, 0ULL, 4);
                      switch (heff_tag_of(v_a_24680)) {
                      case TAG_At: {
                        v_x_24886 = NTAG(TAG_False);
                        break;
                      }
                      default: heff_nomatch(v_a_24680);
                      }
                      break;
                    }
                    default: {
                      heff_drop(v_e1_24857);
                      HeffT2 v_t_24881 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_24680)));
                      {
                        V v_field_24882 = v_t_24881.f[0];
                        V v_field_24883 = v_t_24881.f[1];
                        V v_x_24884 = v_field_24882;
                        V v_y_24885 = v_field_24883;
                        heff_drop(v_y_24885);
                        v_x_24886 = v_x_24884;
                      }
                      break;
                    }
                    }
                    break;
                  }
                  default: heff_nomatch(v_a_24680);
                  }
                }
                V v_t_24887 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EIfThen, TAG_EIfThen, 2, 3ULL, (V[]){v_c_24679, v_a_24680}), v_sp_24682});
                return ((HeffT2){{v_x_24886, v_t_24887}});
              }
            }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_c_24679)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EBreak: {
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EContinue: {
      return ((HeffT2){{heff_dup(v_st_240), v_x3_241}});
    }
    case TAG_EReturn: {
      V v_e_24888 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24EReturn = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24890 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24920;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24920 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_e_24888)) {
          case TAG_At: {
            V v_e1_24891 = heff_dup(heff_field(v_e_24888, 0));
            switch (heff_tag_of(v_e1_24891)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24891, 0ULL, 2);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24891, 0ULL, 1);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24891, 0ULL, 1);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24891, 0ULL, 1);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24891, 0ULL, 1);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24891, 0ULL, 4);
              switch (heff_tag_of(v_e_24888)) {
              case TAG_At: {
                v_x_24920 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24888);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24891);
              HeffT2 v_t_24915 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24888)));
              {
                V v_field_24916 = v_t_24915.f[0];
                V v_field_24917 = v_t_24915.f[1];
                V v_x_24918 = v_field_24916;
                V v_y_24919 = v_field_24917;
                heff_drop(v_y_24919);
                v_x_24920 = v_x_24918;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24888);
          }
        }
        V v_t_24921 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EReturn, TAG_EReturn, 1, 1ULL, (V[]){v_e_24888}), v_sp_24890});
        return ((HeffT2){{v_x_24920, v_t_24921}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ENest: {
      V v_e_24922 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ENest = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24924 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24954;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24954 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_e_24922)) {
          case TAG_At: {
            V v_e1_24925 = heff_dup(heff_field(v_e_24922, 0));
            switch (heff_tag_of(v_e1_24925)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24925, 0ULL, 2);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24925, 0ULL, 1);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24925, 0ULL, 1);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24925, 0ULL, 1);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24925, 0ULL, 1);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24925, 0ULL, 4);
              switch (heff_tag_of(v_e_24922)) {
              case TAG_At: {
                v_x_24954 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24922);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24925);
              HeffT2 v_t_24949 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24922)));
              {
                V v_field_24950 = v_t_24949.f[0];
                V v_field_24951 = v_t_24949.f[1];
                V v_x_24952 = v_field_24950;
                V v_y_24953 = v_field_24951;
                heff_drop(v_y_24953);
                v_x_24954 = v_x_24952;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24922);
          }
        }
        V v_t_24955 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ENest, TAG_ENest, 1, 1ULL, (V[]){v_e_24922}), v_sp_24924});
        return ((HeffT2){{v_x_24954, v_t_24955}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ELazy: {
      V v_e_24956 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ELazy = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24958 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_24988;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_24988 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_e_24956)) {
          case TAG_At: {
            V v_e1_24959 = heff_dup(heff_field(v_e_24956, 0));
            switch (heff_tag_of(v_e1_24959)) {
            case TAG_ELam: {
              heff_take_n(v_e1_24959, 0ULL, 2);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_24959, 0ULL, 1);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_24959, 0ULL, 1);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_24959, 0ULL, 1);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_24959, 0ULL, 1);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_24959, 0ULL, 4);
              switch (heff_tag_of(v_e_24956)) {
              case TAG_At: {
                v_x_24988 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_24956);
              }
              break;
            }
            default: {
              heff_drop(v_e1_24959);
              HeffT2 v_t_24983 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24956)));
              {
                V v_field_24984 = v_t_24983.f[0];
                V v_field_24985 = v_t_24983.f[1];
                V v_x_24986 = v_field_24984;
                V v_y_24987 = v_field_24985;
                heff_drop(v_y_24987);
                v_x_24988 = v_x_24986;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_24956);
          }
        }
        V v_t_24989 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24ELazy, TAG_ELazy, 1, 1ULL, (V[]){v_e_24956}), v_sp_24958});
        return ((HeffT2){{v_x_24988, v_t_24989}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETuple: {
      V v_es_24990 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETuple = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_24992 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_24993 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(heff_dup(v_st_240), v_es_24990));
        {
          V v_field_24994 = v_t_24993.f[0];
          V v_field_24995 = v_t_24993.f[1];
          V v_x_24996 = v_field_24994;
          V v_y_24997 = v_field_24995;
          V v_t_24998 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETuple, TAG_ETuple, 1, (V[]){v_y_24997}), v_sp_24992});
          return ((HeffT2){{v_x_24996, v_t_24998}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_ETry: {
      V v_tr_24999 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24ETry = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_241001 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        switch (heff_tag_of(v_tr_24999)) {
        case TAG_MkTry: {
          V v_err_241002 = heff_field(v_tr_24999, 0);
          V v_body_241003 = heff_field(v_tr_24999, 1);
          V v_c_241004 = heff_field(v_tr_24999, 2);
          V v_ru_24tr_24999_24MkTry = heff_take_reuse_n(v_tr_24999, 7ULL, 3);
          HeffT2 v_t_241005 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(heff_dup(v_st_240), v_body_241003));
          {
            V v_field_241006 = v_t_241005.f[0];
            V v_field_241007 = v_t_241005.f[1];
            V v_x_241008 = v_field_241006;
            V v_y_241009 = v_field_241007;
            switch (heff_tag_of(v_c_241004)) {
            case TAG_MkCatchArm: {
              V v_b_241010 = heff_field(v_c_241004, 0);
              V v_ss_241011 = heff_field(v_c_241004, 1);
              V v_ru_24c_241004_24MkCatchArm = heff_take_reuse_n(v_c_241004, 3ULL, 2);
              HeffT2 v_t_241012 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_241008, v_ss_241011));
              {
                V v_field_241013 = v_t_241012.f[0];
                V v_field_241014 = v_t_241012.f[1];
                V v_x_241015 = v_field_241013;
                V v_y_241016 = v_field_241014;
                V v_t_241017 = heff_tag_re_n(v_ru_24tr_24999_24MkTry, TAG_MkTry, 3, 1ULL, (V[]){v_err_241002, v_y_241009, heff_tag_re_n(v_ru_24c_241004_24MkCatchArm, TAG_MkCatchArm, 2, 1ULL, (V[]){v_b_241010, v_y_241016})});
                V v_t_241018 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_242_24ETry, TAG_ETry, 1, (V[]){v_t_241017}), v_sp_241001});
                return ((HeffT2){{v_x_241015, v_t_241018}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_c_241004)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_tr_24999)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWith: {
      V v_w_241019 = heff_field(v_x31_242, 0);
      V v_x_241020 = heff_field(v_x31_242, 1);
      V v_xsp_241021 = heff_field(v_x31_242, 2);
      V v_body_241022 = heff_field(v_x31_242, 3);
      V v_ru_24x31_242_24EWith = heff_take_reuse_n(v_x31_242, 15ULL, 4);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_241024 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        V v_x_241054;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          v_x_241054 = NTAG(TAG_True);
        } else {
          switch (heff_tag_of(v_w_241019)) {
          case TAG_At: {
            V v_e1_241025 = heff_dup(heff_field(v_w_241019, 0));
            switch (heff_tag_of(v_e1_241025)) {
            case TAG_ELam: {
              heff_take_n(v_e1_241025, 0ULL, 2);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_e1_241025, 0ULL, 1);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_e1_241025, 0ULL, 1);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_e1_241025, 0ULL, 1);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_e1_241025, 0ULL, 1);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_e1_241025, 0ULL, 4);
              switch (heff_tag_of(v_w_241019)) {
              case TAG_At: {
                v_x_241054 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_w_241019);
              }
              break;
            }
            default: {
              heff_drop(v_e1_241025);
              HeffT2 v_t_241049 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_w_241019)));
              {
                V v_field_241050 = v_t_241049.f[0];
                V v_field_241051 = v_t_241049.f[1];
                V v_x_241052 = v_field_241050;
                V v_y_241053 = v_field_241051;
                heff_drop(v_y_241053);
                v_x_241054 = v_x_241052;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_w_241019);
          }
        }
        HeffT2 v_t_241055 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_241054, v_body_241022));
        {
          V v_field_241056 = v_t_241055.f[0];
          V v_field_241057 = v_t_241055.f[1];
          V v_x_241058 = v_field_241056;
          V v_y_241059 = v_field_241057;
          V v_t_241060 = heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_242_24EWith, TAG_EWith, 4, 7ULL, (V[]){v_w_241019, v_x_241020, v_xsp_241021, v_y_241059}), v_sp_241024});
          return ((HeffT2){{v_x_241058, v_t_241060}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    case TAG_EWithBound: {
      V v_bs_241061 = heff_field(v_x31_242, 0);
      V v_w_241062 = heff_field(v_x31_242, 1);
      V v_body_241063 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24EWithBound = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      switch (heff_tag_of(v_x3_241)) {
      case TAG_At: {
        V v_sp_241065 = heff_field(v_x3_241, 1);
        V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 2ULL, 2);
        HeffT2 v_t_241066 = (g_heff_2esyntax_2epresyntax_2eaccList_24s143795099x1025702421_24cpr(heff_dup(v_st_240), v_bs_241061));
        {
          V v_field_241067 = v_t_241066.f[0];
          V v_field_241068 = v_t_241066.f[1];
          V v_x_241069 = v_field_241067;
          V v_y_241070 = v_field_241068;
          switch (heff_tag_of(v_w_241062)) {
          case TAG_Nothing: {
            V v_t_241071 = heff_tag_re_n(v_ru_24x31_242_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_241070, NTAG(TAG_Nothing), v_body_241063});
            return ((HeffT2){{v_x_241069, heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_241071, v_sp_241065})}});
          }
          case TAG_Just: {
            V v_e_241072 = heff_field(v_w_241062, 0);
            V v_ru_24w_241062_24Just = heff_take_reuse_n(v_w_241062, 1ULL, 1);
            V v_x_241102;
            if ((heff_dup(v_x_241069) == NTAG(TAG_True))) {
              heff_drop(v_x_241069);
              v_x_241102 = NTAG(TAG_True);
            } else {
              heff_drop(v_x_241069);
              switch (heff_tag_of(v_e_241072)) {
              case TAG_At: {
                V v_e1_241073 = heff_dup(heff_field(v_e_241072, 0));
                switch (heff_tag_of(v_e1_241073)) {
                case TAG_ELam: {
                  heff_take_n(v_e1_241073, 0ULL, 2);
                  switch (heff_tag_of(v_e_241072)) {
                  case TAG_At: {
                    v_x_241102 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_e_241072);
                  }
                  break;
                }
                case TAG_EDo: {
                  heff_take_n(v_e1_241073, 0ULL, 1);
                  switch (heff_tag_of(v_e_241072)) {
                  case TAG_At: {
                    v_x_241102 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_e_241072);
                  }
                  break;
                }
                case TAG_ENest: {
                  heff_take_n(v_e1_241073, 0ULL, 1);
                  switch (heff_tag_of(v_e_241072)) {
                  case TAG_At: {
                    v_x_241102 = NTAG(TAG_True);
                    break;
                  }
                  default: heff_nomatch(v_e_241072);
                  }
                  break;
                }
                case TAG_ELazy: {
                  heff_take_n(v_e1_241073, 0ULL, 1);
                  switch (heff_tag_of(v_e_241072)) {
                  case TAG_At: {
                    v_x_241102 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_e_241072);
                  }
                  break;
                }
                case TAG_ETry: {
                  heff_take_n(v_e1_241073, 0ULL, 1);
                  switch (heff_tag_of(v_e_241072)) {
                  case TAG_At: {
                    v_x_241102 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_e_241072);
                  }
                  break;
                }
                case TAG_EWith: {
                  heff_take_n(v_e1_241073, 0ULL, 4);
                  switch (heff_tag_of(v_e_241072)) {
                  case TAG_At: {
                    v_x_241102 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_e_241072);
                  }
                  break;
                }
                default: {
                  heff_drop(v_e1_241073);
                  HeffT2 v_t_241097 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_241072)));
                  {
                    V v_field_241098 = v_t_241097.f[0];
                    V v_field_241099 = v_t_241097.f[1];
                    V v_x_241100 = v_field_241098;
                    V v_y_241101 = v_field_241099;
                    heff_drop(v_y_241101);
                    v_x_241102 = v_x_241100;
                  }
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_e_241072);
              }
            }
            V v_t_241103 = heff_tag_re_n(v_ru_24x31_242_24EWithBound, TAG_EWithBound, 3, 4ULL, (V[]){v_y_241070, heff_tag_re_n(v_ru_24w_241062_24Just, TAG_Just, 1, 1ULL, (V[]){v_e_241072}), v_body_241063});
            return ((HeffT2){{v_x_241102, heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_241103, v_sp_241065})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_w_241062)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_2418;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_2418 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      switch (heff_tag_of(v_x_242)) {
      case TAG_At: {
        V v_a_244 = heff_dup(heff_field(v_x_242, 0));
        switch (heff_tag_of(v_a_244)) {
        case TAG_ELam: {
          heff_take_n(v_a_244, 0ULL, 2);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2418 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_EReturn: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2418 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        default: {
          heff_drop(v_a_244);
          HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_x_242)));
          {
            V v_field_2414 = v_t_2413.f[0];
            V v_field_2415 = v_t_2413.f[1];
            V v_a_2416 = v_field_2414;
            V v_a_2417 = v_field_2415;
            heff_drop(v_a_2417);
            v_st_2418 = v_a_2416;
          }
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_x_242);
      }
    }
    V v_cell_2419 = heff_tag_re_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    HeffT2 v_t_2420 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1076071392x1642337306_24dps_24cpr(v_st_2418, v_xs_243, v_cell_2419));
    {
      V v_field_2421 = v_t_2420.f[0];
      V v_field_2422 = v_t_2420.f[1];
      V v_x_2423 = v_field_2421;
      V v__5f_2424 = v_field_2422;
      heff_drop(v__5f_2424);
      return ((HeffT2){{v_x_2423, v_cell_2419}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2422;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2422 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2422 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2417 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2418 = v_t_2417.f[0];
                V v_field_2419 = v_t_2417.f[1];
                V v_a_2420 = v_field_2418;
                V v_a_2421 = v_field_2419;
                heff_drop(v_a_2421);
                v_a_2422 = v_a_2420;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        V v_t_2423 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_a_246, v_a_247}), v_a_245});
        V v_cell_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
        HeffT2 v_t_2425 = (g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24dps_24cpr(v_a_2422, v_xs_243, v_cell_2424));
        {
          V v_field_2426 = v_t_2425.f[0];
          V v_field_2427 = v_t_2425.f[1];
          V v_x_2428 = v_field_2426;
          V v__5f_2429 = v_field_2427;
          heff_drop(v__5f_2429);
          return ((HeffT2){{v_x_2428, v_cell_2424}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1239681792x678203211_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_247 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_x_245), v_st_240));
    V v_cell_248 = heff_tag_re_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_245, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
    V t_0 = v_st_247;
    V t_1 = v_xs_246;
    V t_2 = v_u_249;
    v_st_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  HeffT3 v_t_245 = (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_240, v_xsp_241, v_t_242, v_x4_243, v_sp_244));
  {
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_247, v_field_248})});
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_247, v_field_248})});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_247, v_field_248})});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_str0, 5, "join#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_str1, 5, "join#");
Clo g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(V v_tok_240, V v_lit_241, V v_lit_242, V v_cx_243, V v_sp_244, V v_scope_245, V v_end_246) {
top: ;
  V v_t_247 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
  V v_t_248 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_str0), v_t_247)});
  V v_t_249 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, heff_dup(v_sp_244)}), heff_dup(heff_rfield(v_cx_243, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_243, 4))});
  V v_t_2410 = heff_tr(heff_call(v_scope_245, 1, (V[]){heff_tag_n(TAG_EndJump, 1, (V[]){v_t_249})}));
  V v_t_2411 = (g_heff_2esyntax_2epresyntax_2evarParams(heff_dup(v_sp_244), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_243, 1))));
  V v_t_2417;
  switch (heff_tag_of(v_lit_242)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_end_246)) {
    case TAG_EndValue: {
      v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(v_cx_243, v_lit_241));
      break;
    }
    case TAG_EndJump: {
      v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_243, v_lit_241, v_lit_242, v_end_246));
      break;
    }
    case TAG_EndGive: {
      v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_243, v_lit_241, v_lit_242, v_end_246));
      break;
    }
    default: heff_nomatch(v_end_246);
    }
    break;
  }
  case TAG_Cons: {
    v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_243, v_lit_241, v_lit_242, v_end_246));
    break;
  }
  default: heff_nomatch(v_lit_242);
  }
  V v_t_2418 = heff_intShow(heff_dup(heff_rfield(v_sp_244, 0)));
  V v_t_2419 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_str1), v_t_2418), heff_dup(v_sp_244), v_t_2411, v_t_2417));
  V v_t_2420 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2410, v_t_2420}), v_sp_244});
}
V g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2escopeJoin_24s1349346620x375722567_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}