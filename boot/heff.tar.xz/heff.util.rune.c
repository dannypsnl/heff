// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eutil_2erune_2ebytesEsc(V, V, V);
V g_heff_2eutil_2erune_2ebytesEsc_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ebytesEsc_clo;
V g_heff_2eutil_2erune_2ebytesEsc_24acc(V, V, V, V);
V g_heff_2eutil_2erune_2ebytesEsc_24acc_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ebytesEsc_24acc_clo;
V g_heff_2eutil_2erune_2ehexWith(V, V);
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ehexWith_clo;
V g_heff_2eutil_2erune_2epadTo4(V);
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2epadTo4_clo;
V g_heff_2eutil_2erune_2epow2(V);
V g_heff_2eutil_2erune_2epow2_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2epow2_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_heff_2eutil_2erune_2eruneStartGo(V, V, V);
V g_heff_2eutil_2erune_2eruneStartGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2eruneStartGo_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
Clo g_heff_2eutil_2erune_2ehexWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ehexWith_entry, 2, 0};

V g_heff_2eutil_2erune_2ehexWith(V v_digits_240, V v_n_241) {
top: ;
  if (heff_intLt_c_lent(v_n_241, MK_INT(16LL), 2)) {
    return heff_strSlice(heff_dup(v_digits_240), heff_dup(v_n_241), heff_intAdd(v_n_241, MK_INT(1LL)));
  } else {
    V v_t_242 = (g_heff_2eutil_2erune_2ehexWith(v_digits_240, heff_intDiv_lent(v_n_241, MK_INT(16LL), 2)));
    int64_t v_t_243 = (heff_unbox_word(heff_intMod_lent(v_n_241, MK_INT(16LL), 2)) + ((int64_t)1ULL));
    V v_t_244 = heff_strSlice(heff_dup(v_digits_240), heff_intMod(v_n_241, MK_INT(16LL)), heff_box_word(v_t_243));
    return heff_strAppend(v_t_242, v_t_244);
  }
}
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2erune_2ehexWith(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eutil_2erune_2epadTo4_str0, 1, "0");
Clo g_heff_2eutil_2erune_2epadTo4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2epadTo4_entry, 1, 0};

V g_heff_2eutil_2erune_2epadTo4(V v_s_240) {
top: ;
  if ((((int64_t)4ULL) <= heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    return v_s_240;
  } else {
    V t_0 = heff_strAppend(((V)&g_heff_2eutil_2erune_2epadTo4_str0), v_s_240);
    v_s_240 = t_0;
    goto top;
  }
}
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2epadTo4(a[0]);
}
Clo g_heff_2eutil_2erune_2erunesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2erunesGo_entry, 4, 0};

V g_heff_2eutil_2erune_2erunesGo(V v_s_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  if ((heff_intLe_c_lent(v_j_242, v_i_241, 0) || heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1))) {
    heff_drop(v_i_241);
    return v_n_243;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      V v_w_244 = heff_strRuneWidth_lent(v_s_240, v_i_241, 0);
      if (heff_intLt_c_lent(v_j_242, heff_intAdd_lent(v_i_241, v_w_244, 0), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_w_244);
        return v_n_243;
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, v_w_244);
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eutil_2erune_2erunesGo(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2eutil_2erune_2eruneStartGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2eruneStartGo_entry, 3, 0};

V g_heff_2eutil_2erune_2eruneStartGo(V v_s_240, V v_i_241, V v_k_242) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1)) {
    return v_i_241;
  } else {
    V v_w_243 = heff_strRuneWidth_lent(v_s_240, v_i_241, 0);
    if (heff_intLt_c_lent(v_k_242, heff_intAdd_lent(v_i_241, v_w_243, 0), 2)) {
      heff_drop(v_w_243);
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, v_w_243);
      V t_2 = v_k_242;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2eutil_2erune_2eruneStartGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eutil_2erune_2eruneStartGo(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str0, 2, "\\'");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str1, 2, "\\\\");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str2, 2, "\\n");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str3, 2, "\\t");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str4, 2, "\\r");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str5, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str6, 3, "\\u{");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str7, 1, "}");
Clo g_heff_2eutil_2erune_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2equoted_entry, 1, 0};

V g_heff_2eutil_2erune_2equoted(V v_c_240) {
top: ;
  if (heff_intEq_c_lent(v_c_240, MK_INT(39LL), 2)) {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eutil_2erune_2equoted_str0);
  } else {
    if (heff_intEq_c_lent(v_c_240, MK_INT(92LL), 2)) {
      heff_drop(v_c_240);
      return ((V)&g_heff_2eutil_2erune_2equoted_str1);
    } else {
      if (heff_intEq_c_lent(v_c_240, MK_INT(10LL), 2)) {
        heff_drop(v_c_240);
        return ((V)&g_heff_2eutil_2erune_2equoted_str2);
      } else {
        if (heff_intEq_c_lent(v_c_240, MK_INT(9LL), 2)) {
          heff_drop(v_c_240);
          return ((V)&g_heff_2eutil_2erune_2equoted_str3);
        } else {
          if (heff_intEq_c_lent(v_c_240, MK_INT(13LL), 2)) {
            heff_drop(v_c_240);
            return ((V)&g_heff_2eutil_2erune_2equoted_str4);
          } else {
            if ((heff_intLe_c_lent(MK_INT(0LL), v_c_240, 1) ? (heff_intLe_c_lent(v_c_240, MK_INT(1114111LL), 2) ? ((((int64_t)55296ULL) <= heff_peek_word(v_c_240)) && (heff_peek_word(v_c_240) <= ((int64_t)57343ULL))) : 1) : 1)) {
              heff_drop(v_c_240);
              V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(MK_INT(65533LL)), NTAG(TAG_Nil)});
              return heff_strOfRunes(v_t_241);
            } else {
              if (((heff_peek_word(v_c_240) < ((int64_t)32ULL)) || ((((int64_t)127ULL) <= heff_peek_word(v_c_240)) && (heff_peek_word(v_c_240) < ((int64_t)160ULL))))) {
                V v_t_242 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2equoted_str5), v_c_240));
                return heff_strAppend(heff_strAppend(((V)&g_heff_2eutil_2erune_2equoted_str6), v_t_242), ((V)&g_heff_2eutil_2erune_2equoted_str7));
              } else {
                V v_t_243;
                if (((((int64_t)0ULL) <= heff_peek_word(v_c_240)) && ((heff_peek_word(v_c_240) <= ((int64_t)1114111ULL)) && ((((int64_t)55296ULL) <= heff_peek_word(v_c_240)) ? !(heff_peek_word(v_c_240) <= ((int64_t)57343ULL)) : 1)))) {
                  v_t_243 = v_c_240;
                } else {
                  heff_drop(v_c_240);
                  v_t_243 = MK_INT(65533LL);
                }
                V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_243), NTAG(TAG_Nil)});
                return heff_strOfRunes(v_t_244);
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2equoted(a[0]);
}
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_str0, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_str1, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_str2, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_str3, 2, "\\x");
Clo g_heff_2eutil_2erune_2ebytesEsc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ebytesEsc_entry, 3, 0};

V g_heff_2eutil_2erune_2ebytesEsc(V v_s_240, V v_i_241, V v_w_242) {
top: ;
  if (heff_intLe_c_lent(v_w_242, MK_INT(0LL), 2)) {
    heff_drop(v_i_241);
    heff_drop(v_w_242);
    return ((V)&g_heff_2eutil_2erune_2ebytesEsc_str0);
  } else {
    V v_b_243 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    V v_t_244 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2ebytesEsc_str1), heff_box_word(heff_word_div(heff_peek_word(v_b_243), ((int64_t)16ULL)))));
    V v_t_245 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2ebytesEsc_str2), heff_box_word(heff_word_mod(heff_unbox_word(v_b_243), ((int64_t)16ULL)))));
    V v_s_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2eutil_2erune_2ebytesEsc_str3), v_t_244), v_t_245);
    return (g_heff_2eutil_2erune_2ebytesEsc_24acc(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), heff_intSub(v_w_242, MK_INT(1LL)), v_s_246));
  }
}
V g_heff_2eutil_2erune_2ebytesEsc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2erune_2ebytesEsc(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_24acc_str1, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_24acc_str2, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_24acc_str3, 2, "\\x");
Clo g_heff_2eutil_2erune_2ebytesEsc_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ebytesEsc_24acc_entry, 4, 0};

V g_heff_2eutil_2erune_2ebytesEsc_24acc(V v_s_240, V v_i_241, V v_w_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(v_w_242, MK_INT(0LL), 2)) {
    heff_drop(v_i_241);
    heff_drop(v_w_242);
    return heff_strAppend(v_acc_243, ((V)&g_heff_2eutil_2erune_2ebytesEsc_24acc_str0));
  } else {
    V v_b_244 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    V v_t_245 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2ebytesEsc_24acc_str1), heff_box_word(heff_word_div(heff_peek_word(v_b_244), ((int64_t)16ULL)))));
    V v_t_246 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2ebytesEsc_24acc_str2), heff_box_word(heff_word_mod(heff_unbox_word(v_b_244), ((int64_t)16ULL)))));
    V v_t_247 = heff_strAppend(heff_strAppend(v_acc_243, ((V)&g_heff_2eutil_2erune_2ebytesEsc_24acc_str3)), v_t_245);
    V v_s_248 = heff_strAppend(v_t_247, v_t_246);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_intSub(v_w_242, MK_INT(1LL));
    V t_3 = v_s_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_w_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2eutil_2erune_2ebytesEsc_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2erune_2ebytesEsc_24acc(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str0, 2, "\\\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str1, 2, "\\\\");
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str2, 2, "\\n");
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str3, 2, "\\r");
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str4, 2, "\\t");
Clo g_heff_2eutil_2erune_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2equoteGo_entry, 3, 0};

V g_heff_2eutil_2erune_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1)) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str0));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str1));
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)10ULL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str2));
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)13ULL))) {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
            V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str3));
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_acc_242 = t_2;
            goto top;
          } else {
            if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)9ULL))) {
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
              V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str4));
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            } else {
              if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)128ULL))) {
                V v_t_243 = heff_strSlice_lent(v_s_240, v_i_241, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 4);
                V t_0 = v_s_240;
                V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
                V t_2 = heff_strAppend(v_acc_242, v_t_243);
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_acc_242 = t_2;
                goto top;
              } else {
                V v_s_244 = heff_dup(v_s_240);
                V v_i_245 = heff_dup(v_i_241);
                HeffT2 v_t_246 = heff_strRuneDecode_lent(v_s_240, v_i_241, 0);
                {
                  V v_rune_247 = v_t_246.f[0];
                  V v_width_248 = v_t_246.f[1];
                  V v_t_249 = heff_runeToInt(v_rune_247);
                  V v_t_2411;
                  if ((heff_intEq_c_lent(v_t_249, MK_INT(65533LL), 2) ? ({ V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(MK_INT(65533LL)), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2413 = heff_strOfRunes(heff_dup(v_t_2410)); int c_ = heff_strEq_c_lent(heff_strSlice_lent(v_s_244, v_i_245, heff_intAdd_lent(v_i_245, v_width_248, 0), 4), v_t_2413, 1); heff_drop(v_t_2413); c_; }); heff_drop(v_t_2410); c_; }) : 1)) {
                    heff_drop(v_t_249);
                    v_t_2411 = heff_strSlice(v_s_244, heff_dup(v_i_245), heff_intAdd_lent(v_i_245, v_width_248, 1));
                  } else {
                    heff_drop(v_t_249);
                    v_t_2411 = ({ V a_0 = v_s_244; V a_1 = v_i_245; V a_2 = heff_dup(v_width_248); V r_ = (g_heff_2eutil_2erune_2ebytesEsc(a_0, a_1, a_2)); heff_drop(v_s_244); r_; });
                  }
                  V v_t_2412 = heff_intAdd(v_i_241, v_width_248);
                  V t_0 = v_s_240;
                  V t_1 = v_t_2412;
                  V t_2 = heff_strAppend(v_acc_242, v_t_2411);
                  v_s_240 = t_0;
                  v_i_241 = t_1;
                  v_acc_242 = t_2;
                  goto top;
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2erune_2equoteGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str0, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str1, 1, "\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str2, 1, "\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str3, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str4, 2, ", ");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str5, 2, "\\\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str6, 2, "\\\\");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str7, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str8, 1, "\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str9, 1, "\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str10, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str11, 2, ", ");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str12, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str13, 2, ", ");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str14, 0, "");
Clo g_heff_2eutil_2erune_2equoteBytesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2equoteBytesGo_entry, 4, 0};

V g_heff_2eutil_2erune_2equoteBytesGo(V v_s_240, V v_box_24i_241, V v_run_242, V v_acc_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    if (heff_strEq_c_lent(v_run_242, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str0), 2)) {
      heff_drop(v_run_242);
      return v_acc_243;
    } else {
      V v_p_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2eutil_2erune_2equoteBytesGo_str1), v_run_242), ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str2));
      if (heff_strEq_c_lent(v_acc_243, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str3), 2)) {
        heff_drop(v_acc_243);
        return v_p_244;
      } else {
        return heff_strAppend(heff_strAppend(v_acc_243, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str4)), v_p_244);
      }
    }
  } else {
    if (((((int64_t)32ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) < ((int64_t)127ULL)))) {
      V v_b_245 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
      V v_t_246;
      if ((heff_peek_word(v_b_245) == ((int64_t)34ULL))) {
        heff_drop(v_b_245);
        v_t_246 = ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str5);
      } else {
        if ((heff_peek_word(v_b_245) == ((int64_t)92ULL))) {
          heff_drop(v_b_245);
          v_t_246 = ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str6);
        } else {
          v_t_246 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_b_245)));
        }
      }
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_strAppend(v_run_242, v_t_246);
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_run_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      V v_acc_248;
      if (heff_strEq_c_lent(v_run_242, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str7), 2)) {
        heff_drop(v_run_242);
        v_acc_248 = v_acc_243;
      } else {
        V v_p_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2eutil_2erune_2equoteBytesGo_str8), v_run_242), ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str9));
        if (heff_strEq_c_lent(v_acc_243, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str10), 2)) {
          heff_drop(v_acc_243);
          v_acc_248 = v_p_247;
        } else {
          v_acc_248 = heff_strAppend(heff_strAppend(v_acc_243, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str11)), v_p_247);
        }
      }
      V v_p_249 = heff_intShow(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2));
      V v_t_2410;
      if (heff_strEq_c_lent(v_acc_248, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str12), 2)) {
        heff_drop(v_acc_248);
        v_t_2410 = v_p_249;
      } else {
        v_t_2410 = heff_strAppend(heff_strAppend(v_acc_248, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str13)), v_p_249);
      }
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str14);
      V t_3 = v_t_2410;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_run_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2erune_2equoteBytesGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2eutil_2erune_2epow2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2epow2_entry, 1, 0};

V g_heff_2eutil_2erune_2epow2(V v_box_24k_240) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 <= ((int64_t)0ULL))) {
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2eutil_2erune_2epow2(heff_box_word((v_k_240 - ((int64_t)1ULL)))));
    return heff_intMul(MK_INT(2LL), v_t_241);
  }
}
V g_heff_2eutil_2erune_2epow2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2epow2(a[0]);
}