// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Among 19600
#define TAG_ArrowDown 21357
#define TAG_ArrowLeft 52976
#define TAG_ArrowRight 29566
#define TAG_ArrowUp 57900
#define TAG_BackTab 60780
#define TAG_Backspace 1027
#define TAG_Bold 53386
#define TAG_Char 10597
#define TAG_Continue 52606
#define TAG_Control 37853
#define TAG_Delete 50238
#define TAG_Dim 16148
#define TAG_Dirs 41877
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Enter 13030
#define TAG_Escape 55216
#define TAG_Files 59123
#define TAG_Flagged 28540
#define TAG_Home 35586
#define TAG_Inverse 25398
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PageDown 11812
#define TAG_PageUp 3752
#define TAG_Picked 5619
#define TAG_Plain 3036
#define TAG_Positional 16703
#define TAG_ReadDirectory 46629
#define TAG_Rest 61983
#define TAG_Right 62770
#define TAG_Sequence 46672
#define TAG_Some 35658
#define TAG_Tab 31265
#define TAG_Typed 36072
#define LBL_alone 294267509
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_columns 1181578779
#define LBL_complete 145693389
#define LBL_cursor 598022785
#define LBL_dir 308999
#define LBL_doc 309170
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_filter 672649891
#define LBL_flags 298871457
#define LBL_form 9644427
#define LBL_input 301716452
#define LBL_listing 413833414
#define LBL_long 9823043
#define LBL_menu 9843238
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_options 1129866465
#define LBL_part 9928890
#define LBL_pos 320718
#define LBL_prog 9945121
#define LBL_required 351999471
#define LBL_rows 10002080
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_slots 310891087
#define LBL_style 311138763
#define LBL_text 10052084
#define LBL_typing 1088343202
#define LBL_values 1123329101
static uint32_t shape_dir__names[] = {LBL_dir, LBL_names};
static uint32_t shape_entry__slots__at[] = {LBL_entry, LBL_slots, LBL_at};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_prog__entries__filter__typing__menu__form__alone__listing[] = {LBL_prog, LBL_entries, LBL_filter, LBL_typing, LBL_menu, LBL_form, LBL_alone, LBL_listing};
static uint32_t shape_rows__cursor[] = {LBL_rows, LBL_cursor};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_list_2eany_24s317268364x1703376737(V);
V g_list_2eany_24s317268364x1703376737_entry(V self, V *a);
extern Clo g_list_2eany_24s317268364x1703376737_clo;
V g_list_2eany_24s624430845x1248965393(V);
V g_list_2eany_24s624430845x1248965393_entry(V self, V *a);
extern Clo g_list_2eany_24s624430845x1248965393_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f1084934118x784646860(V, V, V, V, V);
V g_list_2efoldl_24f1084934118x784646860_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1084934118x784646860_clo;
V g_list_2efoldl_24f1563799791x267609364(V, V);
V g_list_2efoldl_24f1563799791x267609364_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1563799791x267609364_clo;
V g_list_2efoldl_24f2002190724x1241209655(V, V, V, V, V, V);
V g_list_2efoldl_24f2002190724x1241209655_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2002190724x1241209655_clo;
V g_list_2efoldl_24f545139853x5269120(V, V);
V g_list_2efoldl_24f545139853x5269120_entry(V self, V *a);
extern Clo g_list_2efoldl_24f545139853x5269120_clo;
V g_list_2efoldl_24f547094838x440994078(V, V, V);
V g_list_2efoldl_24f547094838x440994078_entry(V self, V *a);
extern Clo g_list_2efoldl_24f547094838x440994078_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1396019640x159929943(V, V, V);
V g_list_2efoldl_24s1396019640x159929943_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1396019640x159929943_clo;
V g_list_2efoldl_24s1722219619x1576677028(V, V);
V g_list_2efoldl_24s1722219619x1576677028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722219619x1576677028_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s6718001x1068992521(V, V, V);
V g_list_2efoldl_24s6718001x1068992521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s6718001x1068992521_clo;
V g_list_2efoldl_24s830704854x853664858(V, V, V, V);
V g_list_2efoldl_24s830704854x853664858_entry(V self, V *a);
extern Clo g_list_2efoldl_24s830704854x853664858_clo;
HeffT2 g_list_2eindexWhere_2eindexFrom_240_24s1862090511x134883249_24cpr(V, V, V);
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s3089255x286808945(V, V, V, V);
V g_list_2ekeepIf_24s3089255x286808945_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s3089255x286808945_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1511070573x340395911(V, V, V);
V g_list_2emap_24f1511070573x340395911_entry(V self, V *a);
extern Clo g_list_2emap_24f1511070573x340395911_clo;
V g_list_2emap_24f552182249x837938394(V, V);
V g_list_2emap_24f552182249x837938394_entry(V self, V *a);
extern Clo g_list_2emap_24f552182249x837938394_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s130357166x1398406834(V);
V g_list_2emap_24s130357166x1398406834_entry(V self, V *a);
extern Clo g_list_2emap_24s130357166x1398406834_clo;
V g_list_2emap_24s1539380703x380520933(V);
V g_list_2emap_24s1539380703x380520933_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s456747242x756515627(V);
V g_list_2emap_24s456747242x756515627_entry(V self, V *a);
extern Clo g_list_2emap_24s456747242x756515627_clo;
V g_list_2emap_24s865484684x739952503(V);
V g_list_2emap_24s865484684x739952503_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2ewords_2ewordsFrom_240(V, V, V, V);
V g_prelude_2ewords_2ewordsFrom_240_entry(V self, V *a);
extern Clo g_prelude_2ewords_2ewordsFrom_240_clo;
HeffT2 g_std_2ecli_2einteractive_2ecompletedText_24cpr(V, V);
V g_std_2ecli_2einteractive_2eedited(V, V);
V g_std_2ecli_2einteractive_2eedited_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eedited_clo;
V g_std_2ecli_2einteractive_2eflagSlot(V);
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagSlot_clo;
HeffT2 g_std_2ecli_2einteractive_2eflagSlot_24cpr(V);
V g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_get(void);
V g_std_2ecli_2einteractive_2eflagWord(V, V);
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eflagWord_clo;
V g_std_2ecli_2einteractive_2eformFilled(V, V);
V g_std_2ecli_2einteractive_2eformFilled_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformFilled_clo;
V g_std_2ecli_2einteractive_2eformFilled_2eslots_240(V, V);
V g_std_2ecli_2einteractive_2eformFilled_2eslots_240_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformFilled_2eslots_240_clo;
V g_std_2ecli_2einteractive_2eformStep(V, V, V);
V g_std_2ecli_2einteractive_2eformStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformStep_clo;
V g_std_2ecli_2einteractive_2eformView(V, V, V);
V g_std_2ecli_2einteractive_2eformView_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformView_clo;
V g_std_2ecli_2einteractive_2eformWords(V);
V g_std_2ecli_2einteractive_2eformWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eformWords_clo;
V g_std_2ecli_2einteractive_2elistStep(V, V);
V g_std_2ecli_2einteractive_2elistStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elistStep_clo;
V g_std_2ecli_2einteractive_2elistView(V, V);
V g_std_2ecli_2einteractive_2elistView_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elistView_clo;
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287(V);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_clo;
V g_std_2ecli_2einteractive_2emoved(V, V);
V g_std_2ecli_2einteractive_2emoved_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2emoved_clo;
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(V, V, V);
V g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956_clo;
V g_std_2ecli_2einteractive_2eoffered(V, V);
V g_std_2ecli_2einteractive_2eoffered_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eoffered_clo;
V g_std_2ecli_2einteractive_2eopened(V, V);
V g_std_2ecli_2einteractive_2eopened_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eopened_clo;
V g_std_2ecli_2einteractive_2epartLabel(V);
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartLabel_clo;
V g_std_2ecli_2einteractive_2epartSaid(V);
V g_std_2ecli_2einteractive_2epartSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartSaid_clo;
V g_std_2ecli_2einteractive_2epathsFor(V, V, V);
V g_std_2ecli_2einteractive_2epathsFor_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epathsFor_clo;
V g_std_2ecli_2einteractive_2epathsFor_2etaken_241(V, V, V);
V g_std_2ecli_2einteractive_2epathsFor_2etaken_241_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epathsFor_2etaken_241_clo;
V g_std_2ecli_2einteractive_2eposGiven(V, V);
V g_std_2ecli_2einteractive_2eposGiven_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eposGiven_clo;
V g_std_2ecli_2einteractive_2eposGiven_24dps(V, V, V);
V g_std_2ecli_2einteractive_2eposGiven_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eposGiven_24dps_clo;
V g_std_2ecli_2einteractive_2eposWords(V, V);
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eposWords_clo;
V g_std_2ecli_2einteractive_2eruneStart(V, V);
V g_std_2ecli_2einteractive_2eruneStart_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eruneStart_clo;
V g_std_2ecli_2einteractive_2esameUpTo(V, V, V);
V g_std_2ecli_2einteractive_2esameUpTo_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2esameUpTo_clo;
V g_std_2ecli_2einteractive_2eslashFrom(V, V);
V g_std_2ecli_2einteractive_2eslashFrom_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslashFrom_clo;
V g_std_2ecli_2einteractive_2eslotRows(V, V, V, V);
V g_std_2ecli_2einteractive_2eslotRows_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRows_clo;
V g_std_2ecli_2einteractive_2eslotRows_24dps(V, V, V, V, V);
V g_std_2ecli_2einteractive_2eslotRows_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotRows_24dps_clo;
V g_std_2ecli_2einteractive_2eslotStep(V, V, V);
V g_std_2ecli_2einteractive_2eslotStep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslotStep_clo;
V g_std_2ecli_2einteractive_2estep(V, V);
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2estep_clo;
V g_std_2ecli_2einteractive_2eswitchOptions_get(void);
V g_std_2ecli_2einteractive_2etypedOnList(V, V);
V g_std_2ecli_2einteractive_2etypedOnList_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2etypedOnList_clo;
V g_std_2ecli_2einteractive_2etypedOnList_24tok1(V, V, V);
V g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2etypedOnList_24tok1_clo;
V g_std_2ecli_2einteractive_2eupdateAt(V, V, V);
V g_std_2ecli_2einteractive_2eupdateAt_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eupdateAt_clo;
V g_std_2ecli_2einteractive_2eupdateAt_24dps(V, V, V, V);
V g_std_2ecli_2einteractive_2eupdateAt_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eupdateAt_24dps_clo;
V g_std_2ecli_2einteractive_2eview(V, V);
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eview_clo;
HeffT2 g_std_2ecli_2einteractive_2ewantedDir_24cpr(V);
HeffT2 g_std_2ecli_2eproblemOf_24cpr(V, V);
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eterminal_2ewidget_2ebold(V);
V g_std_2eterminal_2ewidget_2ebold_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ebold_clo;
V g_std_2eterminal_2ewidget_2echoiceKey(V, V);
V g_std_2eterminal_2ewidget_2echoiceKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceKey_clo;
V g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(V, V, V, V);
V g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614_clo;
V g_std_2eterminal_2ewidget_2econtrolMove(V, V, V);
V g_std_2eterminal_2ewidget_2econtrolMove_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2econtrolMove_clo;
V g_std_2eterminal_2ewidget_2efieldKey(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_clo;
V g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_clo;
V g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_get(void);
V g_std_2eterminal_2ewidget_2einverse(V);
V g_std_2eterminal_2ewidget_2einverse_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2einverse_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
V g_std_2eterminal_2ewidget_2emenuKey(V, V, V);
V g_std_2eterminal_2ewidget_2emenuKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuKey_clo;
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240(V, V, V);
V g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240_clo;
V g_std_2eterminal_2ewidget_2epad(V, V);
V g_std_2eterminal_2ewidget_2epad_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epad_clo;
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240(V, V, V);
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_clo;
HEFF_LIT(g_std_2ecli_2einteractive_2eswitchOptions_str0, 3, "off");
HEFF_LIT(g_std_2ecli_2einteractive_2eswitchOptions_str1, 2, "on");
HEFF_TAG_LIT(g_std_2ecli_2einteractive_2eswitchOptions_lit2, TAG_Cons, 2, ((V)&g_std_2ecli_2einteractive_2eswitchOptions_str1), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_std_2ecli_2einteractive_2eswitchOptions_lit3, TAG_Cons, 2, ((V)&g_std_2ecli_2einteractive_2eswitchOptions_str0), ((V)&g_std_2ecli_2einteractive_2eswitchOptions_lit2));

static V g_std_2ecli_2einteractive_2eswitchOptions_val;
static HEFF_ONCE g_std_2ecli_2einteractive_2eswitchOptions_st;
static V g_std_2ecli_2einteractive_2eswitchOptions_init(void) {
  return ((V)&g_std_2ecli_2einteractive_2eswitchOptions_lit3);
}
V g_std_2ecli_2einteractive_2eswitchOptions_get(void) {
  if (HEFF_DONE(g_std_2ecli_2einteractive_2eswitchOptions_st)) return g_std_2ecli_2einteractive_2eswitchOptions_val;
  return heff_global(&g_std_2ecli_2einteractive_2eswitchOptions_val, &g_std_2ecli_2einteractive_2eswitchOptions_st, g_std_2ecli_2einteractive_2eswitchOptions_init);
}

static V g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_val;
static HEFF_ONCE g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_st;
static V g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_init(void) {
  return heff_rec_n(2, shape_options__at, (V[]){heff_dup(g_std_2ecli_2einteractive_2eswitchOptions_get()), MK_INT(0LL)});
}
V g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_get(void) {
  if (HEFF_DONE(g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_st)) return g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_val;
  return heff_global(&g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_val, &g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_st, g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_init);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_24cpr_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_24cpr_str1, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_24cpr_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagSlot_24cpr_str3, 0, "");

HeffT2 g_std_2ecli_2einteractive_2eflagSlot_24cpr(V v_f_240) {
top: ;
  V v_t_249;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 2)), ((V)&g_std_2ecli_2einteractive_2eflagSlot_24cpr_str0))) {
    v_t_249 = heff_tag_n(TAG_Picked, 1, (V[]){heff_dup(g_std_2ecli_2einteractive_2eflagSlot_24cpr_24rec0_get())});
  } else {
    V v_t_241 = heff_dup(heff_rfield(v_f_240, 4));
    switch (heff_tag_of(v_t_241)) {
    case TAG_Nil: {
      V v_t_242 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_std_2ecli_2einteractive_2eflagSlot_24cpr_str1)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_243 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_std_2ecli_2einteractive_2eflagSlot_24cpr_str2)), v_t_242});
      v_t_249 = heff_tag_n(TAG_Typed, 1, (V[]){v_t_243});
      break;
    }
    case TAG_Cons: {
      V v_ru_24t_241_24Cons = heff_take_reuse_n(v_t_241, 0ULL, 2);
      V v_t_246 = heff_dup(heff_rfield(v_f_240, 6));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24t_241_24Cons, 2);
        heff_drop(v_t_246);
        V v_t_247 = heff_rec_n(2, shape_options__at, (V[]){heff_dup(heff_rfield(v_f_240, 4)), MK_INT(0LL)});
        v_t_249 = heff_tag_n(TAG_Picked, 1, (V[]){v_t_247});
      } else {
        heff_drop(v_t_246);
        V v_t_248 = heff_tag_at_n(v_ru_24t_241_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eflagSlot_24cpr_str3), heff_dup(heff_rfield(v_f_240, 4))});
        v_t_249 = heff_tag_n(TAG_Picked, 1, (V[]){heff_rec_n(2, shape_options__at, (V[]){v_t_248, MK_INT(0LL)})});
      }
      break;
    }
    default: heff_nomatch(v_t_241);
    }
  }
  return ((HeffT2){{heff_tag_n(TAG_Flagged, 1, (V[]){v_f_240}), v_t_249}});
}
Clo g_std_2ecli_2einteractive_2eflagSlot_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eflagSlot_entry, 1, 0};

V g_std_2ecli_2einteractive_2eflagSlot(V v_f_240) {
top: ;
  HeffT2 v_t_241 = (g_std_2ecli_2einteractive_2eflagSlot_24cpr(v_f_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_part__input, (V[]){v_field_242, v_field_243});
  }
}
V g_std_2ecli_2einteractive_2eflagSlot_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eflagSlot(a[0]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eposWords_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eposWords_str1, 0, "");
Clo g_std_2ecli_2einteractive_2eposWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eposWords_entry, 2, 0};

V g_std_2ecli_2einteractive_2eposWords(V v_a_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_a_240)) {
  case TAG_One: {
    V v_t_242 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_243), MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_t_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_std_2ecli_2einteractive_2eposWords_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_246 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_247), MK_INT(-1LL)));
      V v_t_249 = heff_strSlice(heff_dup(v_t_241), v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    }
  }
  case TAG_Optional: {
    V v_t_2410 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
    V v_t_2412 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_2411), MK_INT(-1LL)));
    V v_t_2413 = heff_strSlice(heff_dup(v_t_241), v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
    if (heff_strEq_c(v_t_2413, ((V)&g_std_2ecli_2einteractive_2eposWords_str1))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_2414 = (g_prelude_2eskipSpaces(v_t_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_t_241, 0)) - ((int64_t)1ULL));
      V v_t_2416 = (g_prelude_2eskipSpaces(v_t_241, heff_box_word(v_t_2415), MK_INT(-1LL)));
      V v_t_2417 = heff_strSlice(heff_dup(v_t_241), v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    }
  }
  case TAG_Many: {
    return (g_prelude_2ewords_2ewordsFrom_240(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  case TAG_Some: {
    return (g_prelude_2ewords_2ewordsFrom_240(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  case TAG_Rest: {
    return (g_prelude_2ewords_2ewordsFrom_240(v_t_241, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_a_240);
  }
}
V g_std_2ecli_2einteractive_2eposWords_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2einteractive_2eposWords(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str1, 2, "on");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str4, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2eflagWord_str5, 1, "=");
Clo g_std_2ecli_2einteractive_2eflagWord_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eflagWord_entry, 2, 0};

V g_std_2ecli_2einteractive_2eflagWord(V v_f_240, V v_v_241) {
top: ;
  V v_meta_242 = heff_take_field(v_f_240, 2);
  V v_long_243 = heff_get_n(v_f_240, 0, 8);
  if (heff_strEq_c(v_meta_242, ((V)&g_std_2ecli_2einteractive_2eflagWord_str0))) {
    if (heff_strEq_c(v_v_241, ((V)&g_std_2ecli_2einteractive_2eflagWord_str1))) {
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str2), v_long_243), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_long_243);
      return NTAG(TAG_Nil);
    }
  } else {
    if (heff_strEq_c_lent(v_v_241, ((V)&g_std_2ecli_2einteractive_2eflagWord_str3), 2)) {
      heff_drop(v_v_241);
      heff_drop(v_long_243);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2eflagWord_str4), v_long_243), ((V)&g_std_2ecli_2einteractive_2eflagWord_str5));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_244, v_v_241), NTAG(TAG_Nil)});
    }
  }
}
V g_std_2ecli_2einteractive_2eflagWord_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eflagWord(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eformWords_str0, 2, "--");
Clo g_std_2ecli_2einteractive_2eformWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformWords_entry, 1, 0};

V g_std_2ecli_2einteractive_2eformWords(V v_fm_240) {
top: ;
  V v_entry_241 = heff_take_field(v_fm_240, 0);
  V v_slots_242 = heff_get_n(v_fm_240, 1, 3);
  V v_t_243 = heff_get_n(heff_get_n(v_entry_241, 2, 3), 1, 2);
  V v_rest_244 = ({ V a_0 = v_t_243; V r_ = (g_list_2eany_24s624430845x1248965393(a_0)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2efoldl_24f1563799791x267609364(NTAG(TAG_Nil), heff_dup(v_slots_242)));
  V v_ps_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1722219619x1576677028(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2efoldl_24f545139853x5269120(NTAG(TAG_Nil), v_slots_242));
  V v_fs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1722219619x1576677028(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_list_2eany_24s317268364x1703376737(v_ps_246));
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_rest_244);
    heff_drop(v_t_249);
    return (g_prelude_2e_2b_2b(v_fs_248, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2einteractive_2eformWords_str0), v_ps_246})));
  } else {
    heff_drop(v_t_249);
    if ((heff_dup(v_rest_244) == NTAG(TAG_True))) {
      heff_drop(v_rest_244);
      return (g_prelude_2e_2b_2b(v_fs_248, v_ps_246));
    } else {
      heff_drop(v_rest_244);
      return (g_prelude_2e_2b_2b(v_ps_246, v_fs_248));
    }
  }
}
V g_std_2ecli_2einteractive_2eformWords_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformWords(a[0]);
}
Clo g_std_2ecli_2einteractive_2eposGiven_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eposGiven_entry, 2, 0};

V g_std_2ecli_2einteractive_2eposGiven(V v_x1_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_ws_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x11_242, 1, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      V v_t_245 = (g_list_2etake(MK_INT(1LL), heff_dup(v_ws_241)));
      V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = v_ws_241; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_ws_241); r_; });
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_248 = (g_std_2ecli_2einteractive_2eposGiven_24dps(v_ps_243, v_t_246, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    case TAG_Optional: {
      V v_t_249 = (g_list_2etake(MK_INT(1LL), heff_dup(v_ws_241)));
      V v_t_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = v_ws_241; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_ws_241); r_; });
      V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2412 = (g_std_2ecli_2einteractive_2eposGiven_24dps(v_ps_243, v_t_2410, v_cell_2411));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    case TAG_Many: {
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, heff_hole()});
      V v_u_2414 = (g_std_2ecli_2einteractive_2eposGiven_24dps(v_ps_243, NTAG(TAG_Nil), v_cell_2413));
      heff_drop(v_u_2414);
      return v_cell_2413;
    }
    case TAG_Some: {
      V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, heff_hole()});
      V v_u_2416 = (g_std_2ecli_2einteractive_2eposGiven_24dps(v_ps_243, NTAG(TAG_Nil), v_cell_2415));
      heff_drop(v_u_2416);
      return v_cell_2415;
    }
    case TAG_Rest: {
      V v_cell_2417 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, heff_hole()});
      V v_u_2418 = (g_std_2ecli_2einteractive_2eposGiven_24dps(v_ps_243, NTAG(TAG_Nil), v_cell_2417));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2eposGiven_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eposGiven(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2eposGiven_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eposGiven_24dps_entry, 3, 0};

V g_std_2ecli_2einteractive_2eposGiven_24dps(V v_x1_240, V v_ws_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_ws_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_ps_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_get_n(v_x11_243, 1, 3);
    switch (heff_tag_of(v_t_245)) {
    case TAG_One: {
      V v_t_246 = (g_list_2etake(MK_INT(1LL), heff_dup(v_ws_241)));
      V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = v_ws_241; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_ws_241); r_; });
      V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_ps_244;
      V t_1 = v_t_247;
      V t_2 = v_u_249;
      v_x1_240 = t_0;
      v_ws_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Optional: {
      V v_t_2410 = (g_list_2etake(MK_INT(1LL), heff_dup(v_ws_241)));
      V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = v_ws_241; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_ws_241); r_; });
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2412);
      V t_0 = v_ps_244;
      V t_1 = v_t_2411;
      V t_2 = v_u_2413;
      v_x1_240 = t_0;
      v_ws_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Many: {
      V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, heff_hole()});
      V v_u_2415 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2414);
      V t_0 = v_ps_244;
      V t_1 = NTAG(TAG_Nil);
      V t_2 = v_u_2415;
      v_x1_240 = t_0;
      v_ws_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Some: {
      V v_cell_2416 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, heff_hole()});
      V v_u_2417 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2416);
      V t_0 = v_ps_244;
      V t_1 = NTAG(TAG_Nil);
      V t_2 = v_u_2417;
      v_x1_240 = t_0;
      v_ws_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Rest: {
      V v_cell_2418 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, heff_hole()});
      V v_u_2419 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2418);
      V t_0 = v_ps_244;
      V t_1 = NTAG(TAG_Nil);
      V t_2 = v_u_2419;
      v_x1_240 = t_0;
      v_ws_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2eposGiven_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ecli_2einteractive_2eposGiven_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_std_2ecli_2einteractive_2eformFilled_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformFilled_entry, 2, 0};

V g_std_2ecli_2einteractive_2eformFilled(V v_e_240, V v_sp_241) {
top: ;
  V v_t_242 = (g_std_2ecli_2einteractive_2eformFilled_2eslots_240(heff_dup(v_e_240), heff_dup(v_sp_241)));
  V v_xs_243 = (g_std_2ecli_2einteractive_2eformFilled_2eslots_240(heff_dup(v_e_240), heff_dup(v_sp_241)));
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_sp_241, 1, 2); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; HeffT2 r_ = (g_list_2eindexWhere_2eindexFrom_240_24s1862090511x134883249_24cpr(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_xs_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_t_248;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = MK_INT(0LL);
    }
    return heff_rec_n(3, shape_entry__slots__at, (V[]){v_e_240, v_t_242, v_t_248});
  }
}
V g_std_2ecli_2einteractive_2eformFilled_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformFilled(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2eslashFrom_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslashFrom_entry, 2, 0};

V g_std_2ecli_2einteractive_2eslashFrom(V v_w_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < ((int64_t)0ULL))) {
    return heff_box_word(v_i_241);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_w_240, heff_box_word(v_i_241), 2)) == ((int64_t)47ULL))) {
      return heff_box_word(v_i_241);
    } else {
      V t_0 = v_w_240;
      int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
      v_w_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_std_2ecli_2einteractive_2eslashFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2eslashFrom(a0, a[1]); heff_drop(a0); return r;
}
V g_std_2ecli_2einteractive_2epathsFor_lam0(V self, V *args);
Clo g_std_2ecli_2einteractive_2epathsFor_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epathsFor_entry, 3, 0};

V g_std_2ecli_2einteractive_2epathsFor(V v_c_240, V v_l_241, V v_w_242) {
top: ;
  V v_dir_243 = heff_take_field(v_l_241, 0);
  V v_names_244 = heff_get_n(v_l_241, 1, 2);
  int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_w_242, 0)) - ((int64_t)1ULL));
  V v_t_246 = (g_std_2ecli_2einteractive_2eslashFrom(v_w_242, heff_box_word(v_t_245)));
  V v_t_247 = heff_strSlice(heff_dup(v_w_242), MK_INT(0LL), heff_intAdd(v_t_246, MK_INT(1LL)));
  if (heff_strEq_c(v_dir_243, v_t_247)) {
    V v_t_248 = heff_tr(heff_call(((V)&g_std_2ecli_2einteractive_2epathsFor_2etaken_241_clo), 2, (V[]){v_c_240, heff_dup(v_w_242)}));
    V v_t_249 = ({ V a_0 = v_t_248; V a_1 = v_names_244; V r_ = (g_list_2ekeepIf(a_0, a_1)); heff_drop(v_t_248); r_; });
    return (g_list_2emap(heff_clo_n(g_std_2ecli_2einteractive_2epathsFor_lam0, 1, 1, (V[]){v_w_242}), v_t_249));
  } else {
    heff_drop(v_c_240);
    heff_drop(v_w_242);
    heff_drop(v_names_244);
    return NTAG(TAG_Nil);
  }
}
V g_std_2ecli_2einteractive_2epathsFor_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2epathsFor(a[0], a[1], a[2]);
}
V g_std_2ecli_2einteractive_2epathsFor_lam0(V self, V *args) {
  V v_n_2410 = args[0];
  V v_w_242 = heff_env(self)[0];
  int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_w_242, 0)) - ((int64_t)1ULL));
  V v_t_2412 = (g_std_2ecli_2einteractive_2eslashFrom(v_w_242, heff_box_word(v_t_2411)));
  heff_clo_take(self, 1);
  V v_t_2413 = heff_strSlice(v_w_242, MK_INT(0LL), heff_intAdd(v_t_2412, MK_INT(1LL)));
  return heff_strAppend(v_t_2413, v_n_2410);
}
Clo g_std_2ecli_2einteractive_2eruneStart_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eruneStart_entry, 2, 0};

V g_std_2ecli_2einteractive_2eruneStart(V v_a_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if (((((int64_t)0ULL) < v_i_241) && ((v_i_241 < heff_unbox_word(heff_strLength_lent(v_a_240, 0))) && ((((int64_t)128ULL) <= heff_unbox_word(heff_strByteAt_lent(v_a_240, heff_box_word(v_i_241), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_a_240, heff_box_word(v_i_241), 2)) < ((int64_t)192ULL)))))) {
    V t_0 = v_a_240;
    int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
    v_a_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return heff_box_word(v_i_241);
  }
}
V g_std_2ecli_2einteractive_2eruneStart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2eruneStart(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2esameUpTo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2esameUpTo_entry, 3, 0};

V g_std_2ecli_2einteractive_2esameUpTo(V v_a_240, V v_b_241, V v_box_24i_242) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if (((v_i_242 < heff_unbox_word(heff_strLength_lent(v_a_240, 0))) && ((v_i_242 < heff_unbox_word(heff_strLength_lent(v_b_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_240, heff_box_word(v_i_242), 2)) == heff_unbox_word(heff_strByteAt_lent(v_b_241, heff_box_word(v_i_242), 2)))))) {
    V t_0 = v_a_240;
    V t_1 = v_b_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    v_a_240 = t_0;
    v_b_241 = t_1;
    v_i_242 = t_2;
    goto top;
  } else {
    return (g_std_2ecli_2einteractive_2eruneStart(v_a_240, heff_box_word(v_i_242)));
  }
}
V g_std_2ecli_2einteractive_2esameUpTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2einteractive_2esameUpTo(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_std_2ecli_2einteractive_2eedited_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eedited_entry, 2, 0};

V g_std_2ecli_2einteractive_2eedited(V v_k_240, V v_m_241) {
top: ;
  V v_f_242 = (g_std_2eterminal_2ewidget_2efieldKey(v_k_240, heff_take_field(v_m_241, 2)));
  V v_t_243 = heff_take_field(v_m_241, 3);
  V v_t_247;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    v_t_247 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_243);
    V v_t_244 = heff_dup(heff_rfield(v_f_242, 0));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nil: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_t_247 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
  }
  V v_t_248 = ({ V rv_2 = v_f_242; V rv_3 = v_t_247; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 227ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 64527u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  return heff_tag_n(TAG_Continue, 1, (V[]){v_t_248});
}
V g_std_2ecli_2einteractive_2eedited_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2eedited(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2emoved_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2emoved_entry, 2, 0};

V g_std_2ecli_2einteractive_2emoved(V v_k_240, V v_m_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24f2002190724x1241209655(MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), v_m_241, MK_INT(0LL), heff_rfield(v_m_241, 1)));
  V v_t_243 = (g_std_2eterminal_2ewidget_2emenuKey(v_t_242, v_k_240, heff_take_field(v_m_241, 4)));
  V v_t_244 = ({ V rv_4 = v_t_243; V rr_ = heff_rec_reuse_nf(v_m_241, 239ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  return heff_tag_n(TAG_Continue, 1, (V[]){v_t_244});
}
V g_std_2ecli_2einteractive_2emoved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2emoved(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2einteractive_2eopened_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eopened_entry, 2, 0};

V g_std_2ecli_2einteractive_2eopened(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Continue, 1, (V[]){v_m_240});
  }
  case TAG_Just: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 2)), 1, 2);
    V v_t_244 = (g_list_2emap_24s1539380703x380520933(v_t_243));
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_242, 2)), 0, 2);
    V v_t_246 = (g_list_2emap_24s456747242x756515627(v_t_245));
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_244, v_t_246));
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){heff_rec_n(3, shape_entry__slots__at, (V[]){v_e_242, v_t_247, MK_INT(0LL)})});
    V v_t_249 = ({ V rv_5 = v_t_248; V rr_ = heff_rec_reuse_nf(v_m_240, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_249});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2einteractive_2eopened_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eopened(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2etypedOnList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2etypedOnList_entry, 2, 0};

V g_std_2ecli_2einteractive_2etypedOnList(V v_c_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 3));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_f_243 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_240, heff_take_field(v_m_241, 2)));
    V v_t_244 = heff_take_field(v_m_241, 3);
    V v_t_248;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      v_t_248 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = heff_dup(heff_rfield(v_f_243, 0));
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nil: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_245, 0ULL, 2);
        v_t_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
    }
    V v_t_249 = ({ V rv_2 = v_f_243; V rv_3 = v_t_248; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 227ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 64527u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_249});
  } else {
    heff_drop(v_t_242);
    if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(113LL))) {
      heff_drop(v_c_240);
      heff_drop_rec(v_m_241, 8);
      return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(106LL))) {
        heff_drop(v_c_240);
        HEFF_LAST return g_std_2ecli_2einteractive_2emoved(NTAG(TAG_ArrowDown), v_m_241);
      } else {
        if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(107LL))) {
          heff_drop(v_c_240);
          HEFF_LAST return g_std_2ecli_2einteractive_2emoved(NTAG(TAG_ArrowUp), v_m_241);
        } else {
          if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(47LL))) {
            heff_drop(v_c_240);
            V v_t_2410 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_m_241, 247ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2410});
          } else {
            V v_f_2411 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_240, heff_take_field(v_m_241, 2)));
            V v_t_2412 = heff_take_field(v_m_241, 3);
            V v_t_2416;
            if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
              heff_drop(v_t_2412);
              v_t_2416 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2412);
              V v_t_2413 = heff_dup(heff_rfield(v_f_2411, 0));
              switch (heff_tag_of(v_t_2413)) {
              case TAG_Nil: {
                v_t_2416 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2413, 0ULL, 2);
                v_t_2416 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_t_2413);
              }
            }
            V v_t_2417 = ({ V rv_2 = v_f_2411; V rv_3 = v_t_2416; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_241, 227ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 64527u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
            return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2417});
          }
        }
      }
    }
  }
}
V g_std_2ecli_2einteractive_2etypedOnList_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2etypedOnList(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2elistStep_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elistStep_str1, 0, "");
Clo g_std_2ecli_2einteractive_2elistStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elistStep_entry, 2, 0};

V g_std_2ecli_2einteractive_2elistStep(V v_k_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_242 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Char = heff_take_reuse_n(v_k_240, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2etypedOnList_24tok1(v_ru_24k_240_24Char, v_c_242, v_m_241));
  }
  case TAG_Enter: {
    V v_t_243 = (g_list_2ekeepIf_24s3089255x286808945(MK_INT(0LL), v_m_241, MK_INT(0LL), heff_dup(heff_rfield(v_m_241, 1))));
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
    HeffT3 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_t_243; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2411;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        V v_x12_2410 = v_field_248;
        heff_drop(v_x12_2410);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_x_249});
      } else {
        heff_drop(v_field_247);
        heff_drop(v_field_248);
        v_t_2411 = NTAG(TAG_Nothing);
      }
      HEFF_LAST return g_std_2ecli_2einteractive_2eopened(v_m_241, v_t_2411);
    }
  }
  case TAG_Escape: {
    V v_m_2412 = v_m_241;
    V v_t_2413 = heff_take_field(v_m_2412, 3);
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      V v_t_2414 = heff_take_field(v_m_2412, 0);
      V v_t_2415 = heff_take_field(v_m_2412, 1);
      V v_t_2416 = heff_take_field(v_m_2412, 5);
      V v_t_2417 = heff_take_field(v_m_2412, 6);
      V v_t_2418 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_std_2ecli_2einteractive_2elistStep_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_f_2419 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_std_2ecli_2einteractive_2elistStep_str1)), v_t_2418});
      V v_t_2420 = heff_dup(heff_rfield(v_f_2419, 0));
      V v_t_2423;
      switch (heff_tag_of(v_t_2420)) {
      case TAG_Nil: {
        v_t_2423 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2420, 0ULL, 2);
        v_t_2423 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2420);
      }
      V v_t_2424 = ({ V rv_0 = v_t_2414; V rv_1 = v_t_2415; V rv_2 = v_f_2419; V rv_3 = v_t_2423; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rv_5 = v_t_2416; V rv_6 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_m_2412, 128ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 49152u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
      return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2424});
    } else {
      heff_drop_rec(v_m_2412, 8);
      heff_drop(v_t_2413);
      return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    }
  }
  case TAG_Tab: {
    V v_t_2425 = (g_list_2ekeepIf_24s3089255x286808945(MK_INT(0LL), v_m_241, MK_INT(0LL), heff_dup(heff_rfield(v_m_241, 1))));
    V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
    HeffT3 v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = v_t_2425; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2425); r_; });
    {
      V v_field_2429 = v_t_2427.f[1];
      V v_field_2430 = v_t_2427.f[2];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      V v_t_2433;
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        V v_x_2431 = v_field_2429;
        V v_x12_2432 = v_field_2430;
        heff_drop(v_x12_2432);
        v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2431});
      } else {
        heff_drop(v_field_2429);
        heff_drop(v_field_2430);
        v_t_2433 = NTAG(TAG_Nothing);
      }
      HEFF_LAST return g_std_2ecli_2einteractive_2eopened(v_m_241, v_t_2433);
    }
  }
  case TAG_BackTab: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_Backspace: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eedited(NTAG(TAG_Backspace), v_m_241);
  }
  case TAG_Delete: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eedited(NTAG(TAG_Delete), v_m_241);
  }
  case TAG_ArrowUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_ArrowDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_ArrowLeft: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eedited(NTAG(TAG_ArrowLeft), v_m_241);
  }
  case TAG_ArrowRight: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eedited(NTAG(TAG_ArrowRight), v_m_241);
  }
  case TAG_Home: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_End: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_PageUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_PageDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2emoved(v_k_240, v_m_241);
  }
  case TAG_Control: {
    V v_c_2434 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Control = heff_take_reuse_n(v_k_240, 1ULL, 1);
    V v_c_2435 = v_c_2434;
    V v_m_2436 = v_m_241;
    if ((heff_runeEq_c(heff_dup(v_c_2435), MK_INT(110LL)) || heff_runeEq_c(heff_dup(v_c_2435), MK_INT(112LL)))) {
      V v_lit_2437 = v_c_2435;
      V v_m_2438 = v_m_2436;
      V v_lit_2439 = v_lit_2437;
      V v_n_2440 = (g_list_2efoldl_24f2002190724x1241209655(MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), v_m_2438, MK_INT(0LL), heff_rfield(v_m_2438, 1)));
      V v_m_2441 = heff_take_field(v_m_2438, 4);
      V v_t_2442 = (g_std_2eterminal_2ewidget_2econtrolMove(v_n_2440, v_lit_2439, v_m_2441));
      V v_t_2443 = ({ V rv_4 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_m_2438, 239ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_2443});
    } else {
      V v_f_2444 = heff_tr(heff_call(heff_dup(g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_get()), 2, (V[]){v_c_2435, heff_take_field(v_m_2436, 2)}));
      V v_t_2445 = heff_take_field(v_m_2436, 3);
      V v_t_2449;
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_t_2445);
        v_t_2449 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_2445);
        V v_t_2446 = heff_dup(heff_rfield(v_f_2444, 0));
        switch (heff_tag_of(v_t_2446)) {
        case TAG_Nil: {
          v_t_2449 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2446, 0ULL, 2);
          v_t_2449 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2446);
        }
      }
      V v_t_2450 = ({ V rv_2 = v_f_2444; V rv_3 = v_t_2449; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_2436, 227ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 64527u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
      return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_2450});
    }
  }
  case TAG_Sequence: {
    return ({ V a_0 = v_k_240; V a_1 = v_m_241; V r_ = (g_std_2ecli_2einteractive_2emoved(a_0, a_1)); heff_drop_tag(v_k_240, 1); r_; });
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2elistStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2elistStep(a[0], a[1]);
}
Clo g_std_2ecli_2einteractive_2eupdateAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eupdateAt_entry, 3, 0};

V g_std_2ecli_2einteractive_2eupdateAt(V v_i_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_g_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_t_245 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_243}));
      return heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_t_245, v_xs_244});
    } else {
      V v_cell_246 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_247 = ({ V a_0 = heff_intSub(v_i_240, MK_INT(1LL)); V a_1 = v_g_241; V a_2 = v_xs_244; V a_3 = v_cell_246; V r_ = (g_std_2ecli_2einteractive_2eupdateAt_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); r_; });
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2eupdateAt_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eupdateAt(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2eupdateAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eupdateAt_24dps_entry, 4, 0};

V g_std_2ecli_2einteractive_2eupdateAt_24dps(V v_i_240, V v_g_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_xs_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_246 = heff_tr(heff_call(heff_dup(v_g_241), 1, (V[]){v_x_244}));
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_xs_245}));
    } else {
      V v_cell_247 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_g_241;
      V t_2 = v_xs_245;
      V t_3 = v_u_248;
      v_i_240 = t_0;
      v_g_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2einteractive_2eupdateAt_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_std_2ecli_2einteractive_2eupdateAt_24dps(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_std_2ecli_2einteractive_2eslotStep_lam0(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam1(V self, V *args);
V g_std_2ecli_2einteractive_2eslotStep_lam2(V self, V *args);
Clo g_std_2ecli_2einteractive_2eslotStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotStep_entry, 3, 0};

V g_std_2ecli_2einteractive_2eslotStep(V v_k_240, V v_m_241, V v_fm_242) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_243 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Char = heff_take_reuse_n(v_k_240, 1ULL, 1);
    HeffT3 v_t_244 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_2413;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        V v_x12_249 = v_field_247;
        heff_drop(v_x12_249);
        V v_t_2410 = heff_get_n(v_x_248, 1, 2);
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Typed: {
          heff_take_n(v_t_2410, 0ULL, 1);
          v_t_2413 = NTAG(TAG_False);
          break;
        }
        case TAG_Picked: {
          heff_take_n(v_t_2410, 0ULL, 1);
          v_t_2413 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
      } else {
        heff_drop(v_field_246);
        heff_drop(v_field_247);
        v_t_2413 = NTAG(TAG_False);
      }
      if (((heff_dup(v_t_2413) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_243), MK_INT(113LL)))) {
        heff_drop_rec(v_fm_242, 3);
        heff_drop(v_c_243);
        heff_drop(v_t_2413);
        V v_t_2414 = heff_dup(heff_rfield(v_m_241, 6));
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop_rec(v_m_241, 8);
          heff_drop(v_t_2414);
          return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
        } else {
          heff_drop(v_t_2414);
          V v_t_2415 = ({ V rv_5 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
          return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2415});
        }
      } else {
        heff_drop(v_t_2413);
        HeffT3 v_t_2416 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
        {
          V v_field_2418 = v_t_2416.f[1];
          V v_field_2419 = v_t_2416.f[2];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          V v_t_2425;
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x_2420 = v_field_2418;
            V v_x12_2421 = v_field_2419;
            heff_drop(v_x12_2421);
            V v_t_2422 = heff_get_n(v_x_2420, 1, 2);
            switch (heff_tag_of(v_t_2422)) {
            case TAG_Typed: {
              heff_take_n(v_t_2422, 0ULL, 1);
              v_t_2425 = NTAG(TAG_False);
              break;
            }
            case TAG_Picked: {
              heff_take_n(v_t_2422, 0ULL, 1);
              v_t_2425 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_t_2422);
            }
          } else {
            heff_drop(v_field_2418);
            heff_drop(v_field_2419);
            v_t_2425 = NTAG(TAG_False);
          }
          if (((heff_dup(v_t_2425) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_243), MK_INT(106LL)))) {
            heff_drop(v_c_243);
            heff_drop(v_t_2425);
            V v_t_2426 = heff_dup(heff_rfield(v_fm_242, 1));
            V v_t_2432;
            switch (heff_tag_of(v_t_2426)) {
            case TAG_Nil: {
              v_t_2432 = MK_INT(0LL);
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_t_2426, 0ULL, 2);
              V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
              V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
              V v_t_2431 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
              v_t_2432 = heff_intMod(heff_intAdd(v_t_2431, v_t_2429), v_t_2430);
              break;
            }
            default: heff_nomatch(v_t_2426);
            }
            V v_fm_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            V v_t_2434 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2433}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
            return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2434});
          } else {
            heff_drop(v_t_2425);
            HeffT3 v_t_2435 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
            {
              V v_field_2437 = v_t_2435.f[1];
              V v_field_2438 = v_t_2435.f[2];
              int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
              V v_t_2444;
              if ((v_tag_2436 == ((int64_t)0ULL))) {
                V v_x_2439 = v_field_2437;
                V v_x12_2440 = v_field_2438;
                heff_drop(v_x12_2440);
                V v_t_2441 = heff_get_n(v_x_2439, 1, 2);
                switch (heff_tag_of(v_t_2441)) {
                case TAG_Typed: {
                  heff_take_n(v_t_2441, 0ULL, 1);
                  v_t_2444 = NTAG(TAG_False);
                  break;
                }
                case TAG_Picked: {
                  heff_take_n(v_t_2441, 0ULL, 1);
                  v_t_2444 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_t_2441);
                }
              } else {
                heff_drop(v_field_2437);
                heff_drop(v_field_2438);
                v_t_2444 = NTAG(TAG_False);
              }
              if (((heff_dup(v_t_2444) == NTAG(TAG_True)) && heff_runeEq_c(heff_dup(v_c_243), MK_INT(107LL)))) {
                heff_drop(v_c_243);
                heff_drop(v_t_2444);
                V v_t_2445 = heff_dup(heff_rfield(v_fm_242, 1));
                V v_t_2451;
                switch (heff_tag_of(v_t_2445)) {
                case TAG_Nil: {
                  v_t_2451 = MK_INT(0LL);
                  break;
                }
                case TAG_Cons: {
                  heff_take_n(v_t_2445, 0ULL, 2);
                  V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
                  V v_t_2449 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
                  V v_t_2450 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
                  v_t_2451 = heff_intMod(heff_intAdd(v_t_2450, v_t_2448), v_t_2449);
                  break;
                }
                default: heff_nomatch(v_t_2445);
                }
                V v_fm_2452 = ({ V rv_2 = v_t_2451; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                V v_t_2453 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2452}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
                return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2453});
              } else {
                heff_drop(v_t_2444);
                V v_t_2477 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam0, 1, 1, (V[]){v_c_243}), heff_take_field(v_fm_242, 1)));
                V v_fm_2478 = ({ V rv_1 = v_t_2477; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_2479 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2478}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
                return heff_tag_at_n(v_ru_24k_240_24Char, TAG_Continue, 1, (V[]){v_t_2479});
              }
            }
          }
        }
      }
    }
  }
  case TAG_Control: {
    V v_c_2480 = heff_field(v_k_240, 0);
    V v_ru_24k_240_24Control = heff_take_reuse_n(v_k_240, 1ULL, 1);
    if (heff_runeEq_c(heff_dup(v_c_2480), MK_INT(110LL))) {
      heff_drop(v_c_2480);
      V v_t_2481 = heff_dup(heff_rfield(v_fm_242, 1));
      V v_t_2487;
      switch (heff_tag_of(v_t_2481)) {
      case TAG_Nil: {
        v_t_2487 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2481, 0ULL, 2);
        V v_t_2484 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
        V v_t_2485 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
        V v_t_2486 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
        v_t_2487 = heff_intMod(heff_intAdd(v_t_2486, v_t_2484), v_t_2485);
        break;
      }
      default: heff_nomatch(v_t_2481);
      }
      V v_fm_2488 = ({ V rv_2 = v_t_2487; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2489 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2488}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_2489});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_2480), MK_INT(112LL))) {
        heff_drop(v_c_2480);
        V v_t_2490 = heff_dup(heff_rfield(v_fm_242, 1));
        V v_t_2496;
        switch (heff_tag_of(v_t_2490)) {
        case TAG_Nil: {
          v_t_2496 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2490, 0ULL, 2);
          V v_t_2493 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          V v_t_2494 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          V v_t_2495 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
          v_t_2496 = heff_intMod(heff_intAdd(v_t_2495, v_t_2493), v_t_2494);
          break;
        }
        default: heff_nomatch(v_t_2490);
        }
        V v_fm_2497 = ({ V rv_2 = v_t_2496; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2498 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2497}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_2498});
      } else {
        V v_t_24106 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam1, 1, 1, (V[]){v_c_2480}), heff_take_field(v_fm_242, 1)));
        V v_fm_24107 = ({ V rv_1 = v_t_24106; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_24108 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24107}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24k_240_24Control, TAG_Continue, 1, (V[]){v_t_24108});
      }
    }
  }
  default: {
    V v_t_24116 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_242, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eslotStep_lam2, 1, 1, (V[]){v_k_240}), heff_take_field(v_fm_242, 1)));
    V v_fm_24117 = ({ V rv_1 = v_t_24116; V rr_ = heff_rec_reuse_nf(v_fm_242, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_24118 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_24117}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_24118});
  }
  }
}
V g_std_2ecli_2einteractive_2eslotStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotStep(a[0], a[1], a[2]);
}
V g_std_2ecli_2einteractive_2eslotStep_lam0(V self, V *args) {
  V v_s_2454 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_t_2455 = heff_take_field(v_s_2454, 1);
  V v_t_2476;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_t_2455)) {
  case TAG_Typed: {
    V v_f_2456 = heff_field(v_t_2455, 0);
    V v_ru_24t_2455_24Typed = heff_take_reuse_n(v_t_2455, 1ULL, 1);
    V v_t_2457 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_243, v_f_2456));
    v_t_2476 = heff_tag_at_n(v_ru_24t_2455_24Typed, TAG_Typed, 1, (V[]){v_t_2457});
    break;
  }
  case TAG_Picked: {
    V v_c_2458 = heff_field(v_t_2455, 0);
    V v_ru_24t_2455_24Picked = heff_take_reuse_n(v_t_2455, 1ULL, 1);
    V v_lit_2459 = v_c_243;
    V v_c_2460 = v_c_2458;
    V v_t_2475;
    if ((heff_runeEq_c(heff_dup(v_lit_2459), MK_INT(32LL)) || heff_runeEq_c(heff_dup(v_lit_2459), MK_INT(108LL)))) {
      heff_drop(v_lit_2459);
      V v_t_2461 = heff_dup(heff_rfield(v_c_2460, 0));
      V v_t_2467;
      switch (heff_tag_of(v_t_2461)) {
      case TAG_Nil: {
        v_t_2467 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2461, 0ULL, 2);
        V v_t_2464 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2460, 0)));
        V v_t_2465 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2460, 0)));
        V v_t_2466 = heff_intAdd(heff_dup(heff_rfield(v_c_2460, 1)), MK_INT(1LL));
        v_t_2467 = heff_intMod(heff_intAdd(v_t_2466, v_t_2464), v_t_2465);
        break;
      }
      default: heff_nomatch(v_t_2461);
      }
      v_t_2475 = ({ V rv_1 = v_t_2467; V rr_ = heff_rec_reuse_nf(v_c_2460, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    } else {
      if (heff_runeEq_c(v_lit_2459, MK_INT(104LL))) {
        V v_t_2468 = heff_dup(heff_rfield(v_c_2460, 0));
        V v_t_2474;
        switch (heff_tag_of(v_t_2468)) {
        case TAG_Nil: {
          v_t_2474 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2468, 0ULL, 2);
          V v_t_2471 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2460, 0)));
          V v_t_2472 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_2460, 0)));
          V v_t_2473 = heff_intAdd(heff_dup(heff_rfield(v_c_2460, 1)), MK_INT(-1LL));
          v_t_2474 = heff_intMod(heff_intAdd(v_t_2473, v_t_2471), v_t_2472);
          break;
        }
        default: heff_nomatch(v_t_2468);
        }
        v_t_2475 = ({ V rv_1 = v_t_2474; V rr_ = heff_rec_reuse_nf(v_c_2460, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        v_t_2475 = v_c_2460;
      }
    }
    v_t_2476 = heff_tag_at_n(v_ru_24t_2455_24Picked, TAG_Picked, 1, (V[]){v_t_2475});
    break;
  }
  default: heff_nomatch(v_t_2455);
  }
  return ({ V rv_1 = v_t_2476; V rr_ = heff_rec_reuse_nf(v_s_2454, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam1(V self, V *args) {
  V v_s_2499 = args[0];
  V v_c_2480 = heff_env(self)[0];
  V v_t_24100 = heff_take_field(v_s_2499, 1);
  V v_t_24105;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_t_24100)) {
  case TAG_Typed: {
    V v_f_24101 = heff_field(v_t_24100, 0);
    V v_ru_24t_24100_24Typed = heff_take_reuse_n(v_t_24100, 1ULL, 1);
    V v_t_24102 = heff_tr(heff_call(heff_dup(g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_get()), 2, (V[]){v_c_2480, v_f_24101}));
    v_t_24105 = heff_tag_at_n(v_ru_24t_24100_24Typed, TAG_Typed, 1, (V[]){v_t_24102});
    break;
  }
  case TAG_Picked: {
    V v_c_24103 = heff_field(v_t_24100, 0);
    V v_ru_24t_24100_24Picked = heff_take_reuse_n(v_t_24100, 1ULL, 1);
    heff_drop(v_c_2480);
    V v_c_24104 = v_c_24103;
    v_t_24105 = heff_tag_at_n(v_ru_24t_24100_24Picked, TAG_Picked, 1, (V[]){v_c_24104});
    break;
  }
  default: heff_nomatch(v_t_24100);
  }
  return ({ V rv_1 = v_t_24105; V rr_ = heff_rec_reuse_nf(v_s_2499, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2einteractive_2eslotStep_lam2(V self, V *args) {
  V v_s_24109 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_t_24110 = heff_take_field(v_s_24109, 1);
  V v_t_24115;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_t_24110)) {
  case TAG_Typed: {
    V v_f_24111 = heff_field(v_t_24110, 0);
    V v_ru_24t_24110_24Typed = heff_take_reuse_n(v_t_24110, 1ULL, 1);
    V v_t_24112 = ({ V a_0 = v_k_240; V a_1 = v_f_24111; V r_ = (g_std_2eterminal_2ewidget_2efieldKey(a_0, a_1)); heff_drop(v_k_240); r_; });
    v_t_24115 = heff_tag_at_n(v_ru_24t_24110_24Typed, TAG_Typed, 1, (V[]){v_t_24112});
    break;
  }
  case TAG_Picked: {
    V v_c_24113 = heff_field(v_t_24110, 0);
    V v_ru_24t_24110_24Picked = heff_take_reuse_n(v_t_24110, 1ULL, 1);
    V v_t_24114 = ({ V a_0 = v_k_240; V a_1 = v_c_24113; V r_ = (g_std_2eterminal_2ewidget_2echoiceKey(a_0, a_1)); heff_drop(v_k_240); r_; });
    v_t_24115 = heff_tag_at_n(v_ru_24t_24110_24Picked, TAG_Picked, 1, (V[]){v_t_24114});
    break;
  }
  default: heff_nomatch(v_t_24110);
  }
  return ({ V rv_1 = v_t_24115; V rr_ = heff_rec_reuse_nf(v_s_24109, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
HEFF_LIT(g_std_2ecli_2einteractive_2eoffered_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eoffered_str1, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eoffered_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eoffered_str3, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eoffered_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eoffered_str5, 0, "");
Clo g_std_2ecli_2einteractive_2eoffered_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eoffered_entry, 2, 0};

V g_std_2ecli_2einteractive_2eoffered(V v_x1_240, V v_fm_241) {
top: ;
  V v_at_242 = heff_take_field(v_fm_241, 2);
  V v_slots_243 = heff_get_n(v_fm_241, 1, 3);
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_at_242);
    heff_drop(v_slots_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_l_244 = heff_field(v_x1_240, 0);
    HeffT3 v_t_245 = ({ V a_0 = v_at_242; V a_1 = v_slots_243; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_slots_243); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        V v_part_2410 = heff_take_field(v_x_249, 0);
        V v_input_2411 = heff_get_n(v_x_249, 1, 2);
        V v_x12_2412 = v_field_248;
        heff_drop(v_x12_2412);
        V v_p_2413 = v_part_2410;
        V v_t_2414 = v_input_2411;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_Typed: {
          V v_t_2415 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_p_2413)) {
          case TAG_Positional: {
            V v_p_2416 = heff_dup(heff_field(v_p_2413, 0));
            v_t_2418 = heff_get_n(v_p_2416, 2, 3);
            break;
          }
          case TAG_Flagged: {
            V v_f_2417 = heff_dup(heff_field(v_p_2413, 0));
            v_t_2418 = heff_get_n(v_f_2417, 7, 8);
            break;
          }
          default: heff_nomatch(v_p_2413);
          }
          switch (heff_tag_of(v_t_2418)) {
          case TAG_None: {
            heff_drop(v_p_2413);
            heff_drop_rec(v_t_2415, 2);
            return NTAG(TAG_Nil);
          }
          case TAG_Files: {
            heff_take_n(v_t_2418, 0ULL, 1);
            V v_t_2422;
            switch (heff_tag_of(v_p_2413)) {
            case TAG_Positional: {
              V v_p_2420 = heff_field(v_p_2413, 0);
              heff_take_n(v_p_2413, 1ULL, 1);
              v_t_2422 = heff_get_n(v_p_2420, 2, 3);
              break;
            }
            case TAG_Flagged: {
              V v_f_2421 = heff_field(v_p_2413, 0);
              heff_take_n(v_p_2413, 1ULL, 1);
              v_t_2422 = heff_get_n(v_f_2421, 7, 8);
              break;
            }
            default: heff_nomatch(v_p_2413);
            }
            V v_t_2423 = heff_strOfRunes(heff_get_n(v_t_2415, 0, 2));
            V v_xs_2424 = ({ V a_0 = v_t_2423; V a_1 = ((V)&g_std_2ecli_2einteractive_2eoffered_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2eoffered_str1), v_t_2423, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2423); r_; });
            V v_x1_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
            V v_t_2428;
            switch (heff_tag_of(v_x1_2425)) {
            case TAG_Nil: {
              v_t_2428 = ((V)&g_std_2ecli_2einteractive_2eoffered_str2);
              break;
            }
            case TAG_Cons: {
              V v_x_2426 = heff_field(v_x1_2425, 0);
              heff_take_n(v_x1_2425, 1ULL, 2);
              v_t_2428 = v_x_2426;
              break;
            }
            default: heff_nomatch(v_x1_2425);
            }
            return (g_std_2ecli_2einteractive_2epathsFor(v_t_2422, heff_dup(v_l_244), v_t_2428));
          }
          case TAG_Dirs: {
            V v_t_2431;
            switch (heff_tag_of(v_p_2413)) {
            case TAG_Positional: {
              V v_p_2429 = heff_field(v_p_2413, 0);
              heff_take_n(v_p_2413, 1ULL, 1);
              v_t_2431 = heff_get_n(v_p_2429, 2, 3);
              break;
            }
            case TAG_Flagged: {
              V v_f_2430 = heff_field(v_p_2413, 0);
              heff_take_n(v_p_2413, 1ULL, 1);
              v_t_2431 = heff_get_n(v_f_2430, 7, 8);
              break;
            }
            default: heff_nomatch(v_p_2413);
            }
            V v_t_2432 = heff_strOfRunes(heff_get_n(v_t_2415, 0, 2));
            V v_xs_2433 = ({ V a_0 = v_t_2432; V a_1 = ((V)&g_std_2ecli_2einteractive_2eoffered_str3); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2eoffered_str4), v_t_2432, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2432); r_; });
            V v_x1_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2433));
            V v_t_2437;
            switch (heff_tag_of(v_x1_2434)) {
            case TAG_Nil: {
              v_t_2437 = ((V)&g_std_2ecli_2einteractive_2eoffered_str5);
              break;
            }
            case TAG_Cons: {
              V v_x_2435 = heff_field(v_x1_2434, 0);
              heff_take_n(v_x1_2434, 1ULL, 2);
              v_t_2437 = v_x_2435;
              break;
            }
            default: heff_nomatch(v_x1_2434);
            }
            return (g_std_2ecli_2einteractive_2epathsFor(v_t_2431, heff_dup(v_l_244), v_t_2437));
          }
          case TAG_Among: {
            heff_take_n(v_t_2418, 0ULL, 1);
            heff_drop(v_p_2413);
            heff_drop_rec(v_t_2415, 2);
            return NTAG(TAG_Nil);
          }
          default: return heff_nomatch(v_t_2418);
          }
        }
        case TAG_Picked: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop(v_p_2413);
          return NTAG(TAG_Nil);
        }
        default: return heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop(v_field_247);
        heff_drop(v_field_248);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2eoffered_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2eoffered(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2ecompletedText_24cpr_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecompletedText_24cpr_str1, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecompletedText_24cpr_str2, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecompletedText_24cpr_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecompletedText_24cpr_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecompletedText_24cpr_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ecompletedText_24cpr_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ecompletedText_24cpr_str7, 0, "");

HeffT2 g_std_2ecli_2einteractive_2ecompletedText_24cpr(V v_t_240, V v_ps_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_ps_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_std_2ecli_2einteractive_2ecompletedText_24cpr_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_ps_241, 0);
    V v_xs_243 = heff_field(v_ps_241, 1);
    v_t_244 = (g_list_2efoldl_24s830704854x853664858(MK_INT(0LL), MK_INT(0LL), heff_dup(v_x_242), v_xs_243));
    break;
  }
  default: heff_nomatch(v_ps_241);
  }
  V v_x_245 = heff_strLength(v_t_244);
  V v_xs_246 = (g_prelude_2esplit_2esplitFrom_240(v_t_240, ((V)&g_std_2ecli_2einteractive_2ecompletedText_24cpr_str1), MK_INT(0LL), heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2ecompletedText_24cpr_str2), v_t_240, MK_INT(0LL), 5), NTAG(TAG_Nil)));
  V v_x1_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_std_2ecli_2einteractive_2ecompletedText_24cpr_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_y_2411 = heff_strLength(v_t_2410);
  if ((heff_unbox_word(v_y_2411) < heff_unbox_word(v_x_245))) {
    V v_xs_2412 = (g_prelude_2esplit_2esplitFrom_240(v_t_240, ((V)&g_std_2ecli_2einteractive_2ecompletedText_24cpr_str4), MK_INT(0LL), heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2ecompletedText_24cpr_str5), v_t_240, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_x1_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_std_2ecli_2einteractive_2ecompletedText_24cpr_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 2);
      v_t_2416 = v_x_2414;
      break;
    }
    default: heff_nomatch(v_x1_2413);
    }
    V v_t_2419;
    switch (heff_tag_of(v_ps_241)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_std_2ecli_2einteractive_2ecompletedText_24cpr_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_ps_241, 0);
      V v_xs_2418 = heff_field(v_ps_241, 1);
      v_t_2419 = (g_list_2efoldl_24s830704854x853664858(MK_INT(0LL), MK_INT(0LL), heff_dup(v_x_2417), v_xs_2418));
      break;
    }
    default: heff_nomatch(v_ps_241);
    }
    int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_t_240, 0)) - heff_unbox_word(heff_strLength(v_t_2416)));
    V v_f_2421 = heff_strAppend(heff_strSlice_lent(v_t_240, MK_INT(0LL), heff_box_word(v_t_2420), 6), v_t_2419);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
  } else {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
V g_std_2ecli_2einteractive_2eformStep_lam0(V self, V *args);
Clo g_std_2ecli_2einteractive_2eformStep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformStep_entry, 3, 0};

V g_std_2ecli_2einteractive_2eformStep(V v_k_240, V v_m_241, V v_fm_242) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Enter: {
    V v_t_244 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 2, 3);
    HeffT2 v_t_246 = (g_std_2ecli_2eproblemOf_24cpr(v_t_245, v_t_244));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop_rec(v_fm_242, 3);
        V v_p_249 = v_field_248;
        heff_drop(v_p_249);
        return heff_tag_n(TAG_Continue, 1, (V[]){v_m_241});
      } else {
        heff_drop_rec(v_m_241, 8);
        heff_drop(v_field_248);
        V v_t_2410 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
        V v_t_2411 = heff_get_n(heff_get_n(v_fm_242, 0, 3), 0, 3);
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2410})});
        return heff_tag_n(TAG_Done, 1, (V[]){v_t_2412});
      }
    }
  }
  case TAG_Escape: {
    heff_drop_rec(v_fm_242, 3);
    V v_t_2413 = heff_dup(heff_rfield(v_m_241, 6));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop_rec(v_m_241, 8);
      heff_drop(v_t_2413);
      return heff_tag_n(TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    } else {
      heff_drop(v_t_2413);
      V v_t_2414 = ({ V rv_5 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2414});
    }
  }
  case TAG_Tab: {
    V v_l_2415 = heff_dup(heff_rfield(v_m_241, 7));
    V v_fm_2416 = heff_dup(v_fm_242);
    HeffT3 v_t_2417 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_2416, 2)), heff_rfield(v_fm_2416, 1)));
    {
      V v_field_2419 = v_t_2417.f[1];
      V v_field_2420 = v_t_2417.f[2];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      V v_t_2437;
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_x_2421 = v_field_2419;
        V v_x12_2422 = v_field_2420;
        heff_drop(v_x12_2422);
        V v_t_2423 = heff_get_n(v_x_2421, 1, 2);
        switch (heff_tag_of(v_t_2423)) {
        case TAG_Typed: {
          V v_t_2424 = heff_field(v_t_2423, 0);
          V v_ru_24t_2423_24Typed = heff_take_reuse_n(v_t_2423, 1ULL, 1);
          V v_t_2425 = ({ V a_0 = v_l_2415; V a_1 = heff_dup(v_fm_2416); V r_ = (g_std_2ecli_2einteractive_2eoffered(a_0, a_1)); heff_drop(v_l_2415); r_; });
          V v_t_2426 = heff_strOfRunes(heff_get_n(v_t_2424, 0, 2));
          HeffT2 v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = v_t_2425; HeffT2 r_ = (g_std_2ecli_2einteractive_2ecompletedText_24cpr(a_0, a_1)); heff_drop(v_t_2426); heff_drop(v_t_2425); r_; });
          {
            V v_field_2429 = v_t_2427.f[1];
            int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
            if ((v_tag_2428 == ((int64_t)0ULL))) {
              V v_text_2430 = v_field_2429;
              V v_t_2434 = (g_std_2ecli_2einteractive_2eupdateAt(heff_dup(heff_rfield(v_fm_2416, 2)), heff_clo_n(g_std_2ecli_2einteractive_2eformStep_lam0, 1, 1, (V[]){v_text_2430}), heff_take_field(v_fm_2416, 1)));
              V v_t_2435 = ({ V rv_1 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_fm_2416, 5ULL, 3, shape_entry__slots__at, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              v_t_2437 = heff_tag_at_n(v_ru_24t_2423_24Typed, TAG_Just, 1, (V[]){v_t_2435});
            } else {
              heff_drop_rec(v_fm_2416, 3);
              heff_drop_cell(v_ru_24t_2423_24Typed, 1);
              heff_drop(v_field_2429);
              v_t_2437 = NTAG(TAG_Nothing);
            }
          }
          break;
        }
        case TAG_Picked: {
          heff_take_n(v_t_2423, 0ULL, 1);
          heff_drop(v_l_2415);
          heff_drop_rec(v_fm_2416, 3);
          v_t_2437 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2423);
        }
      } else {
        heff_drop(v_l_2415);
        heff_drop_rec(v_fm_2416, 3);
        heff_drop(v_field_2419);
        heff_drop(v_field_2420);
        v_t_2437 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_t_2437)) {
      case TAG_Nothing: {
        V v_t_2438 = heff_dup(heff_rfield(v_fm_242, 1));
        V v_t_2444;
        switch (heff_tag_of(v_t_2438)) {
        case TAG_Nil: {
          v_t_2444 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2438, 0ULL, 2);
          V v_t_2441 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
          V v_t_2443 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
          v_t_2444 = heff_intMod(heff_intAdd(v_t_2443, v_t_2441), v_t_2442);
          break;
        }
        default: heff_nomatch(v_t_2438);
        }
        V v_fm_2445 = ({ V rv_2 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2446 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2445}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2446});
      }
      case TAG_Just: {
        V v_done_2447 = heff_field(v_t_2437, 0);
        V v_ru_24t_2437_24Just = heff_take_reuse_n(v_t_2437, 1ULL, 1);
        heff_drop_rec(v_fm_242, 3);
        V v_t_2448 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_done_2447}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_at_n(v_ru_24t_2437_24Just, TAG_Continue, 1, (V[]){v_t_2448});
      }
      default: return heff_nomatch(v_t_2437);
      }
    }
  }
  case TAG_BackTab: {
    V v_t_2449 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2455;
    switch (heff_tag_of(v_t_2449)) {
    case TAG_Nil: {
      v_t_2455 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2449, 0ULL, 2);
      V v_t_2452 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2453 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2454 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
      v_t_2455 = heff_intMod(heff_intAdd(v_t_2454, v_t_2452), v_t_2453);
      break;
    }
    default: heff_nomatch(v_t_2449);
    }
    V v_fm_2456 = ({ V rv_2 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2457 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2456}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2457});
  }
  case TAG_Backspace: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Delete: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_ArrowUp: {
    V v_t_2458 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2464;
    switch (heff_tag_of(v_t_2458)) {
    case TAG_Nil: {
      v_t_2464 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2458, 0ULL, 2);
      V v_t_2461 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2462 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2463 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(-1LL));
      v_t_2464 = heff_intMod(heff_intAdd(v_t_2463, v_t_2461), v_t_2462);
      break;
    }
    default: heff_nomatch(v_t_2458);
    }
    V v_fm_2465 = ({ V rv_2 = v_t_2464; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2466 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2465}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2466});
  }
  case TAG_ArrowDown: {
    V v_t_2467 = heff_dup(heff_rfield(v_fm_242, 1));
    V v_t_2473;
    switch (heff_tag_of(v_t_2467)) {
    case TAG_Nil: {
      v_t_2473 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2467, 0ULL, 2);
      V v_t_2470 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2471 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_t_2472 = heff_intAdd(heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(1LL));
      v_t_2473 = heff_intMod(heff_intAdd(v_t_2472, v_t_2470), v_t_2471);
      break;
    }
    default: heff_nomatch(v_t_2467);
    }
    V v_fm_2474 = ({ V rv_2 = v_t_2473; V rr_ = heff_rec_reuse_nf(v_fm_242, 3ULL, 3, shape_entry__slots__at, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2475 = ({ V rv_5 = heff_tag_n(TAG_Just, 1, (V[]){v_fm_2474}); V rr_ = heff_rec_reuse_nf(v_m_241, 223ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    return heff_tag_n(TAG_Continue, 1, (V[]){v_t_2475});
  }
  case TAG_ArrowLeft: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_ArrowRight: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Home: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_End: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_PageUp: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_PageDown: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Control: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  case TAG_Sequence: {
    HEFF_LAST return g_std_2ecli_2einteractive_2eslotStep(v_k_240, v_m_241, v_fm_242);
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2ecli_2einteractive_2eformStep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformStep(a[0], a[1], a[2]);
}
V g_std_2ecli_2einteractive_2eformStep_lam0(V self, V *args) {
  V v_s_2431 = args[0];
  V v_text_2430 = heff_env(self)[0];
  V v_t_2432 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(heff_dup(v_text_2430)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  heff_clo_take(self, 1);
  V v_t_2433 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(v_text_2430), v_t_2432});
  return ({ V rv_1 = heff_tag_n(TAG_Typed, 1, (V[]){v_t_2433}); V rr_ = heff_rec_reuse_nf(v_s_2431, 1ULL, 2, shape_part__input, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
Clo g_std_2ecli_2einteractive_2estep_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2estep_entry, 2, 0};

V g_std_2ecli_2einteractive_2estep(V v_k_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    HEFF_LAST return g_std_2ecli_2einteractive_2elistStep(v_k_240, v_m_241);
  }
  case TAG_Just: {
    V v_fm_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2eformStep(v_k_240, v_m_241, v_fm_243));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2einteractive_2estep_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2estep(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str0, 8, "filter: ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str1, 71, "type to filter, \342\206\221 \342\206\223 or j k to move, Enter to fill one in, q to quit");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str2, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str3, 14, ": its commands");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str4, 23, "no command's name has `");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str5, 7, "` in it");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str7, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str8, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str9, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str10, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str11, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str12, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2elistView_str13, 1, " ");
V g_std_2ecli_2einteractive_2elistView_lam0(V self, V *args);
Clo g_std_2ecli_2einteractive_2elistView_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elistView_entry, 2, 0};

V g_std_2ecli_2einteractive_2elistView(V v_size_240, V v_m_241) {
top: ;
  V v_rows_242 = heff_take_field(v_size_240, 1);
  V v_columns_243 = heff_get_n(v_size_240, 0, 2);
  V v_h_244 = heff_intSub_lent(v_rows_242, MK_INT(1LL), 2);
  V v_t_245 = heff_dup(heff_rfield(v_m_241, 3));
  V v_t_2411;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str0), NTAG(TAG_Plain)});
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_m_241, 2)), 0, 2);
    V v_t_248 = heff_rec_n(2, shape_text__style, (V[]){heff_strOfRunes(v_t_247), NTAG(TAG_Plain)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_249});
  } else {
    heff_drop(v_t_245);
    V v_t_2410 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str1), NTAG(TAG_Dim)});
    v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  V v_h_2412 = heff_intSub(v_rows_242, MK_INT(4LL));
  V v_m_2413 = heff_dup(heff_rfield(v_m_241, 4));
  V v_t_2414 = (g_list_2ekeepIf_24s3089255x286808945(MK_INT(0LL), v_m_241, MK_INT(0LL), heff_dup(heff_rfield(v_m_241, 1))));
  V v_w_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2414; V r_ = (g_list_2efoldl_24s6718001x1068992521(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_list_2ekeepIf_24s3089255x286808945(MK_INT(0LL), v_m_241, MK_INT(0LL), heff_dup(heff_rfield(v_m_241, 1))));
  V v_items_2425 = (g_list_2emap(heff_clo_n(g_std_2ecli_2einteractive_2elistView_lam0, 1, 1, (V[]){v_w_2415}), v_t_2416));
  V v_t_2427;
  if (heff_intLt_c(heff_dup(heff_rfield(v_m_2413, 0)), heff_dup(v_h_2412))) {
    v_t_2427 = MK_INT(0LL);
  } else {
    V v_t_2426 = heff_intSub(heff_dup(heff_rfield(v_m_2413, 0)), heff_dup(v_h_2412));
    v_t_2427 = heff_intAdd(v_t_2426, MK_INT(1LL));
  }
  V v_t_2428 = (g_std_2eterminal_2ewidget_2emenuRows_2emenuFrom_240(heff_get_n(v_m_2413, 0, 1), MK_INT(0LL), v_items_2425));
  V v_t_2429 = ({ V a_0 = v_t_2427; V a_1 = v_t_2428; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2428); r_; });
  V v_t_2430 = (g_list_2etake(v_h_2412, v_t_2429));
  V v_t_2431 = heff_rec_n(2, shape_text__style, (V[]){heff_dup(heff_rfield(v_m_241, 0)), NTAG(TAG_Bold)});
  V v_t_2432 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str3), NTAG(TAG_Plain)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2430});
  V v_rs_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_t_2433}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2434})});
  V v_t_2436 = (g_list_2ereplicate(heff_dup(v_h_244), NTAG(TAG_Nil)));
  V v_t_2437 = (g_prelude_2e_2b_2b(v_rs_2435, v_t_2436));
  V v_t_2438 = (g_list_2etake(v_h_244, v_t_2437));
  V v_m_2439 = heff_dup(v_m_241);
  V v_filter_2440 = heff_take_field(v_m_2439, 2);
  V v_prog_2441 = heff_get_n(v_m_2439, 0, 8);
  V v_t_2442 = (g_list_2ekeepIf_24s3089255x286808945(MK_INT(0LL), v_m_241, MK_INT(0LL), heff_dup(heff_rfield(v_m_241, 1))));
  V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_m_241, 4)), 0, 1);
  HeffT3 v_t_2444 = ({ V a_0 = v_t_2443; V a_1 = v_t_2442; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2442); r_; });
  {
    V v_field_2446 = v_t_2444.f[1];
    V v_field_2447 = v_t_2444.f[2];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    V v_x2_2450;
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_x_2448 = v_field_2446;
      V v_x12_2449 = v_field_2447;
      heff_drop(v_x12_2449);
      v_x2_2450 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2448});
    } else {
      heff_drop(v_field_2446);
      heff_drop(v_field_2447);
      v_x2_2450 = NTAG(TAG_Nothing);
    }
    V v_s_2481;
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_Nothing: {
      heff_drop(v_prog_2441);
      V v_t_2451 = heff_strOfRunes(heff_get_n(v_filter_2440, 0, 2));
      v_s_2481 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2elistView_str4), v_t_2451), ((V)&g_std_2ecli_2einteractive_2elistView_str5));
      break;
    }
    case TAG_Just: {
      V v_e_2452 = heff_field(v_x2_2450, 0);
      heff_take_n(v_x2_2450, 1ULL, 1);
      heff_drop_rec(v_filter_2440, 2);
      V v_shape_2453 = heff_take_field(v_e_2452, 2);
      V v_name_2454 = heff_get_n(v_e_2452, 0, 3);
      V v_t_2455 = heff_dup(heff_rfield(v_shape_2453, 1));
      V v_t_2479;
      switch (heff_tag_of(v_t_2455)) {
      case TAG_Nil: {
        V v_t_2456 = heff_dup(heff_rfield(v_shape_2453, 0));
        switch (heff_tag_of(v_t_2456)) {
        case TAG_Nil: {
          heff_drop_rec(v_shape_2453, 2);
          v_t_2479 = ((V)&g_std_2ecli_2einteractive_2elistView_str6);
          break;
        }
        case TAG_Cons: {
          V v_ru_24t_2456_24Cons = heff_take_reuse_n(v_t_2456, 0ULL, 2);
          V v_sh_2459 = v_shape_2453;
          V v_pos_2460 = heff_take_field(v_sh_2459, 1);
          V v_flags_2461 = heff_get_n(v_sh_2459, 0, 2);
          V v_t_2462 = (g_list_2emap_24s2029999044x514618413(v_pos_2460));
          V v_t_2463 = (g_list_2emap_24s1281445768x1036802655(v_flags_2461));
          V v_xs_2464 = (g_prelude_2e_2b_2b_24tok2(v_ru_24t_2456_24Cons, v_t_2462, v_t_2463));
          V v_t_2467;
          switch (heff_tag_of(v_xs_2464)) {
          case TAG_Nil: {
            v_t_2467 = ((V)&g_std_2ecli_2einteractive_2elistView_str7);
            break;
          }
          case TAG_Cons: {
            V v_x_2465 = heff_field(v_xs_2464, 0);
            V v_xs_2466 = heff_field(v_xs_2464, 1);
            heff_take_n(v_xs_2464, 3ULL, 2);
            v_t_2467 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2elistView_str8); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
            break;
          }
          default: heff_nomatch(v_xs_2464);
          }
          v_t_2479 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2elistView_str9), v_t_2467);
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        break;
      }
      case TAG_Cons: {
        V v_ru_24t_2455_24Cons = heff_take_reuse_n(v_t_2455, 0ULL, 2);
        V v_sh_2470 = v_shape_2453;
        V v_pos_2471 = heff_take_field(v_sh_2470, 1);
        V v_flags_2472 = heff_get_n(v_sh_2470, 0, 2);
        V v_t_2473 = (g_list_2emap_24s2029999044x514618413(v_pos_2471));
        V v_t_2474 = (g_list_2emap_24s1281445768x1036802655(v_flags_2472));
        V v_xs_2475 = (g_prelude_2e_2b_2b_24tok2(v_ru_24t_2455_24Cons, v_t_2473, v_t_2474));
        V v_t_2478;
        switch (heff_tag_of(v_xs_2475)) {
        case TAG_Nil: {
          v_t_2478 = ((V)&g_std_2ecli_2einteractive_2elistView_str10);
          break;
        }
        case TAG_Cons: {
          V v_x_2476 = heff_field(v_xs_2475, 0);
          V v_xs_2477 = heff_field(v_xs_2475, 1);
          heff_take_n(v_xs_2475, 3ULL, 2);
          v_t_2478 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2elistView_str11); V a_1 = v_x_2476; V a_2 = v_xs_2477; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2477); r_; });
          break;
        }
        default: heff_nomatch(v_xs_2475);
        }
        v_t_2479 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2elistView_str12), v_t_2478);
        break;
      }
      default: heff_nomatch(v_t_2455);
      }
      V v_t_2480 = heff_strAppend(heff_strAppend(v_prog_2441, ((V)&g_std_2ecli_2einteractive_2elistView_str13)), v_name_2454);
      v_s_2481 = heff_strAppend(v_t_2480, v_t_2479);
      break;
    }
    default: heff_nomatch(v_x2_2450);
    }
    V v_s_2482 = (g_std_2eterminal_2ewidget_2epad(v_columns_243, v_s_2481));
    V v_t_2483 = heff_rec_n(2, shape_text__style, (V[]){v_s_2482, NTAG(TAG_Inverse)});
    V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
    V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
    V v_t_2486 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2485));
    V v_t_2487 = heff_take_field(v_m_241, 3);
    V v_t_2493;
    if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
      heff_drop(v_t_2487);
      V v_f_2488 = heff_get_n(v_m_241, 2, 8);
      V v_at_2489 = heff_take_field(v_f_2488, 1);
      V v_text_2490 = heff_get_n(v_f_2488, 0, 2);
      V v_t_2491 = ({ V a_0 = MK_INT(0LL); V a_1 = v_at_2489; V a_2 = v_text_2490; V r_ = (g_list_2efoldl_24f547094838x440994078(a_0, a_1, a_2)); heff_drop(v_text_2490); r_; });
      V v_t_2492 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_intAdd(MK_INT(8LL), v_t_2491), MK_INT(1LL)});
      v_t_2493 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2492});
    } else {
      heff_drop_rec(v_m_241, 8);
      heff_drop(v_t_2487);
      v_t_2493 = NTAG(TAG_Nothing);
    }
    return heff_rec_n(2, shape_rows__cursor, (V[]){v_t_2486, v_t_2493});
  }
}
V g_std_2ecli_2einteractive_2elistView_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2elistView(a[0], a[1]);
}
V g_std_2ecli_2einteractive_2elistView_lam0(V self, V *args) {
  V v_e_2417 = args[0];
  V v_w_2415 = heff_env(self)[0];
  V v_name_2418 = heff_take_field(v_e_2417, 0);
  V v_doc_2419 = heff_get_n(v_e_2417, 1, 3);
  heff_clo_take(self, 1);
  V v_s_2420 = (g_std_2eterminal_2ewidget_2epad(v_w_2415, v_name_2418));
  V v_t_2421 = heff_rec_n(2, shape_text__style, (V[]){v_s_2420, NTAG(TAG_Bold)});
  V v_t_2422 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2elistView_str2), NTAG(TAG_Plain)});
  V v_t_2423 = heff_rec_n(2, shape_text__style, (V[]){v_doc_2419, NTAG(TAG_Dim)});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2424})});
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str0, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str1, 1, "]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str2, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str3, 4, "...]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str4, 3, "...");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str5, 1, "[");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str6, 4, "...]");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str7, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str8, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str9, 1, "-");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str10, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str11, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str12, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str13, 1, "=");
HEFF_LIT(g_std_2ecli_2einteractive_2epartLabel_str14, 2, "--");
Clo g_std_2ecli_2einteractive_2epartLabel_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartLabel_entry, 1, 0};

V g_std_2ecli_2einteractive_2epartLabel(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_meta_242 = heff_dup(heff_rfield(v_p_241, 0));
    V v_arity_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_m_244 = v_meta_242;
    V v_t_245 = v_arity_243;
    switch (heff_tag_of(v_t_245)) {
    case TAG_One: {
      return v_m_244;
    }
    case TAG_Optional: {
      return heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str0), v_m_244), ((V)&g_std_2ecli_2einteractive_2epartLabel_str1));
    }
    case TAG_Many: {
      return heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str2), v_m_244), ((V)&g_std_2ecli_2einteractive_2epartLabel_str3));
    }
    case TAG_Some: {
      return heff_strAppend(v_m_244, ((V)&g_std_2ecli_2einteractive_2epartLabel_str4));
    }
    case TAG_Rest: {
      return heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str5), v_m_244), ((V)&g_std_2ecli_2einteractive_2epartLabel_str6));
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Flagged: {
    V v_f_246 = heff_field(v_x1_240, 0);
    V v_short_247 = heff_dup(heff_rfield(v_f_246, 1));
    V v_meta_248 = heff_dup(heff_rfield(v_f_246, 2));
    V v_long_249 = heff_dup(heff_rfield(v_f_246, 0));
    V v_t_2410;
    if (heff_strEq_c_lent(v_short_247, ((V)&g_std_2ecli_2einteractive_2epartLabel_str7), 2)) {
      heff_drop(v_short_247);
      v_t_2410 = ((V)&g_std_2ecli_2einteractive_2epartLabel_str8);
    } else {
      v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str9), v_short_247), ((V)&g_std_2ecli_2einteractive_2epartLabel_str10));
    }
    V v_t_2411;
    if (heff_strEq_c_lent(v_meta_248, ((V)&g_std_2ecli_2einteractive_2epartLabel_str11), 2)) {
      heff_drop(v_meta_248);
      v_t_2411 = ((V)&g_std_2ecli_2einteractive_2epartLabel_str12);
    } else {
      v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartLabel_str13), v_meta_248);
    }
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_std_2ecli_2einteractive_2epartLabel_str14)), v_long_249);
    return heff_strAppend(v_t_2412, v_t_2411);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2epartLabel(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_str0, 2, "> ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_str1, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_str2, 2, "  ");
Clo g_std_2ecli_2einteractive_2eslotRows_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRows_entry, 4, 0};

V g_std_2ecli_2einteractive_2eslotRows(V v_w_240, V v_at_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_at_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x4_243, 0);
    V v_ss_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_w_246 = heff_dup(v_w_240);
    V v_on_247 = heff_bool(heff_intEq_c_lent(v_i_242, v_at_241, 0));
    V v_s_248 = v_s_244;
    V v_part_249 = heff_take_field(v_s_248, 0);
    V v_input_2410 = heff_get_n(v_s_248, 1, 2);
    V v_t_2411;
    if ((heff_dup(v_on_247) == NTAG(TAG_True))) {
      v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_str0), NTAG(TAG_Bold)});
    } else {
      v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_str1), NTAG(TAG_Plain)});
    }
    V v_t_2412 = (g_std_2ecli_2einteractive_2epartLabel(v_part_249));
    V v_s_2413 = (g_std_2eterminal_2ewidget_2epad(v_w_246, v_t_2412));
    V v_on_2414 = v_on_247;
    V v_part_2415 = v_part_249;
    V v_x3_2416 = v_input_2410;
    V v_t_2433;
    switch (heff_tag_of(v_x3_2416)) {
    case TAG_Typed: {
      V v_t_2417 = heff_field(v_x3_2416, 0);
      heff_take_n(v_x3_2416, 1ULL, 1);
      if (!(heff_dup(v_on_2414) == NTAG(TAG_True))) {
        heff_drop(v_on_2414);
        V v_t_2418 = heff_dup(heff_rfield(v_t_2417, 0));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          heff_drop_rec(v_t_2417, 2);
          V v_t_2421;
          switch (heff_tag_of(v_part_2415)) {
          case TAG_Positional: {
            V v_p_2419 = heff_field(v_part_2415, 0);
            heff_take_n(v_part_2415, 1ULL, 1);
            v_t_2421 = heff_get_n(v_p_2419, 0, 3);
            break;
          }
          case TAG_Flagged: {
            V v_f_2420 = heff_field(v_part_2415, 0);
            heff_take_n(v_part_2415, 1ULL, 1);
            v_t_2421 = heff_get_n(v_f_2420, 2, 8);
            break;
          }
          default: heff_nomatch(v_part_2415);
          }
          V v_t_2422 = heff_rec_n(2, shape_text__style, (V[]){v_t_2421, NTAG(TAG_Dim)});
          v_t_2433 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2418, 0ULL, 2);
          heff_drop(v_part_2415);
          V v_t_2425 = heff_strOfRunes(heff_get_n(v_t_2417, 0, 2));
          V v_t_2426 = heff_rec_n(2, shape_text__style, (V[]){v_t_2425, NTAG(TAG_Plain)});
          v_t_2433 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
      } else {
        heff_drop(v_on_2414);
        heff_drop(v_part_2415);
        V v_t_2427 = heff_strOfRunes(heff_get_n(v_t_2417, 0, 2));
        V v_t_2428 = heff_rec_n(2, shape_text__style, (V[]){v_t_2427, NTAG(TAG_Plain)});
        v_t_2433 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      }
      break;
    }
    case TAG_Picked: {
      V v_c_2429 = heff_field(v_x3_2416, 0);
      heff_take_n(v_x3_2416, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_part_2415);
      V v_at_2430 = heff_take_field(v_c_2429, 1);
      V v_options_2431 = heff_get_n(v_c_2429, 0, 2);
      V v_t_2432;
      if ((heff_dup(v_on_2414) == NTAG(TAG_True))) {
        heff_drop(v_on_2414);
        v_t_2432 = ((V)&g_std_2eterminal_2ewidget_2einverse_clo);
      } else {
        heff_drop(v_on_2414);
        v_t_2432 = ((V)&g_std_2eterminal_2ewidget_2ebold_clo);
      }
      v_t_2433 = ({ V a_0 = v_t_2432; V a_1 = v_at_2430; V a_2 = MK_INT(0LL); V a_3 = v_options_2431; V r_ = (g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(a_0, a_1, a_2, a_3)); heff_drop(v_t_2432); heff_drop(v_at_2430); r_; });
      break;
    }
    default: heff_nomatch(v_x3_2416);
    }
    V v_t_2434 = heff_rec_n(2, shape_text__style, (V[]){v_s_2413, NTAG(TAG_Plain)});
    V v_t_2435 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_str2), NTAG(TAG_Plain)});
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2433})});
    V v_cell_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2436}), heff_hole()});
    V v_u_2438 = ({ V a_0 = v_w_240; V a_1 = v_at_241; V a_2 = heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))); V a_3 = v_ss_245; V a_4 = v_cell_2437; V r_ = (g_std_2ecli_2einteractive_2eslotRows_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_at_241); r_; });
    heff_drop(v_u_2438);
    return v_cell_2437;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2einteractive_2eslotRows_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eslotRows(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_24dps_str0, 2, "> ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_24dps_str1, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2eslotRows_24dps_str2, 2, "  ");
Clo g_std_2ecli_2einteractive_2eslotRows_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eslotRows_24dps_entry, 5, 0};

V g_std_2ecli_2einteractive_2eslotRows_24dps(V v_w_240, V v_at_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x4_243, 0);
    V v_ss_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_w_247 = heff_dup(v_w_240);
    V v_on_248 = heff_bool(heff_intEq_c_lent(v_i_242, v_at_241, 0));
    V v_s_249 = v_s_245;
    V v_part_2410 = heff_take_field(v_s_249, 0);
    V v_input_2411 = heff_get_n(v_s_249, 1, 2);
    V v_t_2412;
    if ((heff_dup(v_on_248) == NTAG(TAG_True))) {
      v_t_2412 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_24dps_str0), NTAG(TAG_Bold)});
    } else {
      v_t_2412 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_24dps_str1), NTAG(TAG_Plain)});
    }
    V v_t_2413 = (g_std_2ecli_2einteractive_2epartLabel(v_part_2410));
    V v_s_2414 = (g_std_2eterminal_2ewidget_2epad(v_w_247, v_t_2413));
    V v_on_2415 = v_on_248;
    V v_part_2416 = v_part_2410;
    V v_x3_2417 = v_input_2411;
    V v_t_2434;
    switch (heff_tag_of(v_x3_2417)) {
    case TAG_Typed: {
      V v_t_2418 = heff_field(v_x3_2417, 0);
      heff_take_n(v_x3_2417, 1ULL, 1);
      if (!(heff_dup(v_on_2415) == NTAG(TAG_True))) {
        heff_drop(v_on_2415);
        V v_t_2419 = heff_dup(heff_rfield(v_t_2418, 0));
        switch (heff_tag_of(v_t_2419)) {
        case TAG_Nil: {
          heff_drop_rec(v_t_2418, 2);
          V v_t_2422;
          switch (heff_tag_of(v_part_2416)) {
          case TAG_Positional: {
            V v_p_2420 = heff_field(v_part_2416, 0);
            heff_take_n(v_part_2416, 1ULL, 1);
            v_t_2422 = heff_get_n(v_p_2420, 0, 3);
            break;
          }
          case TAG_Flagged: {
            V v_f_2421 = heff_field(v_part_2416, 0);
            heff_take_n(v_part_2416, 1ULL, 1);
            v_t_2422 = heff_get_n(v_f_2421, 2, 8);
            break;
          }
          default: heff_nomatch(v_part_2416);
          }
          V v_t_2423 = heff_rec_n(2, shape_text__style, (V[]){v_t_2422, NTAG(TAG_Dim)});
          v_t_2434 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2419, 0ULL, 2);
          heff_drop(v_part_2416);
          V v_t_2426 = heff_strOfRunes(heff_get_n(v_t_2418, 0, 2));
          V v_t_2427 = heff_rec_n(2, shape_text__style, (V[]){v_t_2426, NTAG(TAG_Plain)});
          v_t_2434 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2419);
        }
      } else {
        heff_drop(v_on_2415);
        heff_drop(v_part_2416);
        V v_t_2428 = heff_strOfRunes(heff_get_n(v_t_2418, 0, 2));
        V v_t_2429 = heff_rec_n(2, shape_text__style, (V[]){v_t_2428, NTAG(TAG_Plain)});
        v_t_2434 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
      }
      break;
    }
    case TAG_Picked: {
      V v_c_2430 = heff_field(v_x3_2417, 0);
      heff_take_n(v_x3_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      heff_drop(v_part_2416);
      V v_at_2431 = heff_take_field(v_c_2430, 1);
      V v_options_2432 = heff_get_n(v_c_2430, 0, 2);
      V v_t_2433;
      if ((heff_dup(v_on_2415) == NTAG(TAG_True))) {
        heff_drop(v_on_2415);
        v_t_2433 = ((V)&g_std_2eterminal_2ewidget_2einverse_clo);
      } else {
        heff_drop(v_on_2415);
        v_t_2433 = ((V)&g_std_2eterminal_2ewidget_2ebold_clo);
      }
      v_t_2434 = ({ V a_0 = v_t_2433; V a_1 = v_at_2431; V a_2 = MK_INT(0LL); V a_3 = v_options_2432; V r_ = (g_std_2eterminal_2ewidget_2echoiceRow_2echoiceFrom_240_24s703018658x55492614(a_0, a_1, a_2, a_3)); heff_drop(v_t_2433); heff_drop(v_at_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x3_2417);
    }
    V v_t_2435 = heff_rec_n(2, shape_text__style, (V[]){v_s_2414, NTAG(TAG_Plain)});
    V v_t_2436 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eslotRows_24dps_str2), NTAG(TAG_Plain)});
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2434})});
    V v_cell_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2437}), heff_hole()});
    V v_u_2439 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2438);
    V t_0 = v_w_240;
    V t_1 = v_at_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_ss_246;
    V t_4 = v_u_2439;
    v_w_240 = t_0;
    v_at_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2einteractive_2eslotRows_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_std_2ecli_2einteractive_2eslotRows_24dps(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str0, 16, "one word, wanted");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str1, 40, "one word, or none: the command's default");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str2, 36, "any number of words, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str3, 33, "one word or more, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str4, 51, "the rest of the words, as they are, split at spaces");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str5, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str6, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str7, 8, "; a file");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str8, 4, "; a ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str9, 5, " file");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str10, 13, "; a directory");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str11, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str12, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str13, 9, "; one of ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str14, 2, ": ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str15, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str16, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str17, 2, "; ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str18, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str19, 38, "a switch, off or on (\342\206\220 \342\206\222 or space)");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str20, 37, "a value, typed; left empty, not given");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str21, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str22, 2, ", ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str23, 7, "one of ");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str24, 19, " (\342\206\220 \342\206\222 or space)");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str25, 8, "; wanted");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str26, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str27, 2, "--");
HEFF_LIT(g_std_2ecli_2einteractive_2epartSaid_str28, 2, ": ");
Clo g_std_2ecli_2einteractive_2epartSaid_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epartSaid_entry, 1, 0};

V g_std_2ecli_2einteractive_2epartSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Positional: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_arity_242 = heff_dup(heff_rfield(v_p_241, 1));
    V v_complete_243 = heff_dup(heff_rfield(v_p_241, 2));
    V v_meta_244 = heff_dup(heff_rfield(v_p_241, 0));
    V v_t_245 = v_arity_242;
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_One: {
      v_t_246 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str0);
      break;
    }
    case TAG_Optional: {
      v_t_246 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str1);
      break;
    }
    case TAG_Many: {
      v_t_246 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str2);
      break;
    }
    case TAG_Some: {
      v_t_246 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str3);
      break;
    }
    case TAG_Rest: {
      v_t_246 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str4);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_247 = v_complete_243;
    V v_t_2413;
    switch (heff_tag_of(v_t_247)) {
    case TAG_None: {
      v_t_2413 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str5);
      break;
    }
    case TAG_Files: {
      V v_sfx_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      if (heff_strEq_c_lent(v_sfx_248, ((V)&g_std_2ecli_2einteractive_2epartSaid_str6), 2)) {
        heff_drop(v_sfx_248);
        v_t_2413 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str7);
      } else {
        v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str8), v_sfx_248), ((V)&g_std_2ecli_2einteractive_2epartSaid_str9));
      }
      break;
    }
    case TAG_Dirs: {
      v_t_2413 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str10);
      break;
    }
    case TAG_Among: {
      V v_ws_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_ws_249)) {
      case TAG_Nil: {
        v_t_2412 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_ws_249, 0);
        V v_xs_2411 = heff_field(v_ws_249, 1);
        heff_take_n(v_ws_249, 3ULL, 2);
        v_t_2412 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str12); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
        break;
      }
      default: heff_nomatch(v_ws_249);
      }
      v_t_2413 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str13), v_t_2412);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2414 = heff_strAppend(heff_strAppend(v_meta_244, ((V)&g_std_2ecli_2einteractive_2epartSaid_str14)), v_t_246);
    return heff_strAppend(v_t_2414, v_t_2413);
  }
  case TAG_Flagged: {
    V v_f_2415 = heff_field(v_x1_240, 0);
    V v_doc_2416 = heff_dup(heff_rfield(v_f_2415, 3));
    V v_meta_2417 = heff_dup(heff_rfield(v_f_2415, 2));
    V v_values_2418 = heff_dup(heff_rfield(v_f_2415, 4));
    V v_required_2419 = heff_dup(heff_rfield(v_f_2415, 6));
    V v_long_2420 = heff_dup(heff_rfield(v_f_2415, 0));
    V v_t_2421;
    if (heff_strEq_c_lent(v_doc_2416, ((V)&g_std_2ecli_2einteractive_2epartSaid_str15), 2)) {
      heff_drop(v_doc_2416);
      v_t_2421 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str16);
    } else {
      v_t_2421 = heff_strAppend(v_doc_2416, ((V)&g_std_2ecli_2einteractive_2epartSaid_str17));
    }
    V v_t_2429;
    if (heff_strEq_c(v_meta_2417, ((V)&g_std_2ecli_2einteractive_2epartSaid_str18))) {
      heff_drop(v_values_2418);
      v_t_2429 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str19);
    } else {
      V v_t_2422 = heff_dup(v_values_2418);
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nil: {
        heff_drop(v_values_2418);
        v_t_2429 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str20);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2422, 0ULL, 2);
        V v_t_2425 = v_values_2418;
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_Nil: {
          v_t_2428 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str21);
          break;
        }
        case TAG_Cons: {
          V v_x_2426 = heff_field(v_t_2425, 0);
          V v_xs_2427 = heff_field(v_t_2425, 1);
          heff_take_n(v_t_2425, 3ULL, 2);
          v_t_2428 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str22); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str23), v_t_2428), ((V)&g_std_2ecli_2einteractive_2epartSaid_str24));
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
    }
    V v_t_2430 = v_required_2419;
    V v_t_2431;
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      v_t_2431 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str25);
    } else {
      heff_drop(v_t_2430);
      v_t_2431 = ((V)&g_std_2ecli_2einteractive_2epartSaid_str26);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2epartSaid_str27), v_long_2420), ((V)&g_std_2ecli_2einteractive_2epartSaid_str28));
    V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, v_t_2421), v_t_2429);
    return heff_strAppend(v_t_2433, v_t_2431);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einteractive_2epartSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2einteractive_2epartSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str1, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str3, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str4, 2, "  ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str5, 6, " path)");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str6, 7, " paths)");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str7, 8, "  (Tab: ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str8, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str9, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str10, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str11, 2, "$ ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str12, 5, "leave");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str13, 4, "back");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str14, 9, "not yet: ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str15, 8, "  (Esc: ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str16, 1, ")");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str17, 5, "leave");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str18, 4, "back");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str19, 56, "Enter: run it  \302\267  Tab \342\206\221 \342\206\223: another field  \302\267  Esc: ");
HEFF_LIT(g_std_2ecli_2einteractive_2eformView_str20, 0, "");
Clo g_std_2ecli_2einteractive_2eformView_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eformView_entry, 3, 0};

V g_std_2ecli_2einteractive_2eformView(V v_size_240, V v_m_241, V v_fm_242) {
top: ;
  V v_prog_243 = heff_take_field(v_m_241, 0);
  V v_listing_244 = heff_take_field(v_m_241, 7);
  V v_alone_245 = heff_get_n(v_m_241, 6, 8);
  V v_rows_246 = heff_take_field(v_size_240, 1);
  V v_columns_247 = heff_get_n(v_size_240, 0, 2);
  V v_h_248 = heff_intSub(v_rows_246, MK_INT(1LL));
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
  V v_t_2410 = heff_strAppend(heff_strAppend(heff_dup(v_prog_243), ((V)&g_std_2ecli_2einteractive_2eformView_str0)), v_t_249);
  V v_t_2411 = heff_rec_n(2, shape_text__style, (V[]){v_t_2410, NTAG(TAG_Bold)});
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 1, 3);
  V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_list_2emap_24f1511070573x340395911(v_columns_247, ((V)&g_std_2ecli_2einteractive_2eformView_str1), v_t_2413));
  V v_t_2415 = (g_list_2efoldl_24s1396019640x159929943(MK_INT(0LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
  V v_t_2416 = (g_std_2ecli_2einteractive_2eslotRows(v_t_2415, heff_dup(heff_rfield(v_fm_242, 2)), MK_INT(0LL), heff_dup(heff_rfield(v_fm_242, 1))));
  HeffT3 v_t_2417 = (g_list_2edrop_24cpr(heff_dup(heff_rfield(v_fm_242, 2)), heff_rfield(v_fm_242, 1)));
  {
    V v_field_2419 = v_t_2417.f[1];
    V v_field_2420 = v_t_2417.f[2];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    V v_t_2426;
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2419;
      V v_x12_2422 = v_field_2420;
      heff_drop(v_x12_2422);
      V v_s_2423 = ({ V b_0 = heff_get_n(v_x_2421, 0, 2); V r_ = (g_std_2ecli_2einteractive_2epartSaid(b_0)); heff_drop(b_0); r_; });
      V v_t_2424 = ({ V a_0 = v_s_2423; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_s_2423); r_; });
      V v_t_2425 = (g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240(v_columns_247, ((V)&g_std_2ecli_2einteractive_2eformView_str2), v_t_2424));
      v_t_2426 = (g_list_2emap_24s865484684x739952503(v_t_2425));
    } else {
      heff_drop(v_field_2419);
      heff_drop(v_field_2420);
      v_t_2426 = NTAG(TAG_Nil);
    }
    V v_w_2427 = heff_dup(v_columns_247);
    V v_ps_2428 = ({ V a_0 = v_listing_244; V a_1 = heff_dup(v_fm_242); V r_ = (g_std_2ecli_2einteractive_2eoffered(a_0, a_1)); heff_drop(v_listing_244); r_; });
    V v_t_2442;
    switch (heff_tag_of(v_ps_2428)) {
    case TAG_Nil: {
      heff_drop(v_w_2427);
      v_t_2442 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_x2_2431 = (g_list_2emap_24s130357166x1398406834(heff_dup(v_ps_2428)));
      V v_t_2434;
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_Nil: {
        v_t_2434 = ((V)&g_std_2ecli_2einteractive_2eformView_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2432 = heff_field(v_x2_2431, 0);
        V v_xs_2433 = heff_field(v_x2_2431, 1);
        heff_take_n(v_x2_2431, 3ULL, 2);
        v_t_2434 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2eformView_str4); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2431);
      }
      V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2428));
      V v_t_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ps_2428; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_ps_2428, 2); r_; });
      V v_t_2437;
      if (heff_intEq_c(v_t_2436, MK_INT(1LL))) {
        v_t_2437 = ((V)&g_std_2ecli_2einteractive_2eformView_str5);
      } else {
        v_t_2437 = ((V)&g_std_2ecli_2einteractive_2eformView_str6);
      }
      V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_std_2ecli_2einteractive_2eformView_str7)), heff_intShow(v_t_2435));
      V v_s_2439 = heff_strAppend(v_t_2438, v_t_2437);
      V v_t_2440 = ({ V a_0 = v_s_2439; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_s_2439); r_; });
      V v_t_2441 = ({ V a_0 = v_w_2427; V a_1 = ((V)&g_std_2ecli_2einteractive_2eformView_str8); V a_2 = v_t_2440; V r_ = (g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240(a_0, a_1, a_2)); heff_drop(v_w_2427); r_; });
      v_t_2442 = (g_list_2emap_24f552182249x837938394(MK_INT(3LL), v_t_2441));
      break;
    }
    default: heff_nomatch(v_ps_2428);
    }
    V v_ws_2443 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
    V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 0, 3);
    V v_t_2445 = heff_strAppend(heff_strAppend(v_prog_243, ((V)&g_std_2ecli_2einteractive_2eformView_str9)), v_t_2444);
    V v_s_2446 = ({ V a_0 = ((V)&g_std_2ecli_2einteractive_2eformView_str10); V a_1 = v_t_2445; V a_2 = v_ws_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(a_0, a_1, a_2)); heff_drop(v_ws_2443); r_; });
    V v_t_2447 = heff_rec_n(2, shape_text__style, (V[]){((V)&g_std_2ecli_2einteractive_2eformView_str11), NTAG(TAG_Plain)});
    V v_t_2448 = heff_rec_n(2, shape_text__style, (V[]){v_s_2446, NTAG(TAG_Bold)});
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2449}), NTAG(TAG_Nil)});
    V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2450});
    V v_t_2452 = (g_prelude_2e_2b_2b(v_t_2442, v_t_2451));
    V v_t_2453 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2452));
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2453});
    V v_t_2455 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2454));
    V v_ys_2456 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_t_2455});
    V v_t_2457 = (g_prelude_2e_2b_2b(v_t_2414, v_ys_2456));
    V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    V v_rs_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2457});
    V v_t_2460 = (g_list_2ereplicate(heff_dup(v_h_248), NTAG(TAG_Nil)));
    V v_t_2461 = (g_prelude_2e_2b_2b(v_rs_2459, v_t_2460));
    V v_t_2462 = (g_list_2etake(v_h_248, v_t_2461));
    V v_alone_2463 = v_alone_245;
    V v_t_2464 = (g_std_2ecli_2einteractive_2eformWords(heff_dup(v_fm_242)));
    V v_t_2465 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 2, 3);
    HeffT2 v_t_2466 = (g_std_2ecli_2eproblemOf_24cpr(v_t_2465, v_t_2464));
    {
      V v_field_2468 = v_t_2466.f[1];
      int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
      V v_s_2474;
      if ((v_tag_2467 == ((int64_t)0ULL))) {
        V v_p_2469 = v_field_2468;
        V v_t_2470 = ({ V a_0 = v_p_2469; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop(v_p_2469); r_; });
        V v_t_2471;
        if ((heff_dup(v_alone_2463) == NTAG(TAG_True))) {
          heff_drop(v_alone_2463);
          v_t_2471 = ((V)&g_std_2ecli_2einteractive_2eformView_str12);
        } else {
          heff_drop(v_alone_2463);
          v_t_2471 = ((V)&g_std_2ecli_2einteractive_2eformView_str13);
        }
        V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2einteractive_2eformView_str14), v_t_2470), ((V)&g_std_2ecli_2einteractive_2eformView_str15));
        v_s_2474 = heff_strAppend(heff_strAppend(v_t_2472, v_t_2471), ((V)&g_std_2ecli_2einteractive_2eformView_str16));
      } else {
        heff_drop(v_field_2468);
        V v_t_2473;
        if ((heff_dup(v_alone_2463) == NTAG(TAG_True))) {
          heff_drop(v_alone_2463);
          v_t_2473 = ((V)&g_std_2ecli_2einteractive_2eformView_str17);
        } else {
          heff_drop(v_alone_2463);
          v_t_2473 = ((V)&g_std_2ecli_2einteractive_2eformView_str18);
        }
        v_s_2474 = heff_strAppend(((V)&g_std_2ecli_2einteractive_2eformView_str19), v_t_2473);
      }
      V v_s_2475 = (g_std_2eterminal_2ewidget_2epad(heff_dup(v_columns_247), v_s_2474));
      V v_t_2476 = heff_rec_n(2, shape_text__style, (V[]){v_s_2475, NTAG(TAG_Inverse)});
      V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, NTAG(TAG_Nil)});
      V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
      V v_t_2479 = (g_prelude_2e_2b_2b(v_t_2462, v_t_2478));
      V v_t_2480 = heff_get_n(heff_dup(heff_rfield(v_fm_242, 0)), 1, 3);
      V v_t_2481 = ({ V a_0 = v_t_2480; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_t_2480); r_; });
      V v_t_2482 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_columns_247; V a_3 = ((V)&g_std_2ecli_2einteractive_2eformView_str20); V a_4 = v_t_2481; V r_ = (g_list_2efoldl_24f1084934118x784646860(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_columns_247); heff_drop(v_t_2481); r_; });
      V v_top_2483 = heff_intAdd(v_t_2482, MK_INT(2LL));
      V v_w_2484 = (g_list_2efoldl_24s1396019640x159929943(MK_INT(0LL), MK_INT(0LL), heff_rfield(v_fm_242, 1)));
      V v_fm_2485 = heff_dup(v_fm_242);
      HeffT3 v_t_2486 = ({ V a_0 = heff_take_field(v_fm_242, 2); V b_1 = heff_get_n(v_fm_242, 1, 3); HeffT3 r_ = (g_list_2edrop_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2488 = v_t_2486.f[1];
        V v_field_2489 = v_t_2486.f[2];
        int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
        V v_s_2492;
        if ((v_tag_2487 == ((int64_t)0ULL))) {
          V v_x_2490 = v_field_2488;
          V v_x12_2491 = v_field_2489;
          heff_drop(v_x12_2491);
          v_s_2492 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2490});
        } else {
          heff_drop(v_field_2488);
          heff_drop(v_field_2489);
          v_s_2492 = NTAG(TAG_Nothing);
        }
        V v_t_24103;
        switch (heff_tag_of(v_s_2492)) {
        case TAG_Nothing: {
          heff_drop(v_top_2483);
          heff_drop(v_w_2484);
          heff_drop_rec(v_fm_2485, 3);
          v_t_24103 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_s1_2493 = heff_field(v_s_2492, 0);
          V v_ru_24s_2492_24Just = heff_take_reuse_n(v_s_2492, 1ULL, 1);
          V v_t_2494 = heff_get_n(v_s1_2493, 1, 2);
          switch (heff_tag_of(v_t_2494)) {
          case TAG_Typed: {
            V v_t_2495 = heff_field(v_t_2494, 0);
            heff_take_n(v_t_2494, 1ULL, 1);
            V v_at_2496 = heff_take_field(v_t_2495, 1);
            V v_text_2497 = heff_get_n(v_t_2495, 0, 2);
            V v_t_2498 = ({ V a_0 = MK_INT(0LL); V a_1 = v_at_2496; V a_2 = v_text_2497; V r_ = (g_list_2efoldl_24f547094838x440994078(a_0, a_1, a_2)); heff_drop(v_text_2497); r_; });
            V v_t_2499 = heff_intAdd(heff_intAdd(MK_INT(2LL), v_w_2484), MK_INT(2LL));
            V v_t_24100 = heff_intAdd(v_top_2483, heff_get_n(v_fm_2485, 2, 3));
            V v_t_24101 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_intAdd(v_t_2499, v_t_2498), v_t_24100});
            v_t_24103 = heff_tag_at_n(v_ru_24s_2492_24Just, TAG_Just, 1, (V[]){v_t_24101});
            break;
          }
          case TAG_Picked: {
            heff_take_n(v_t_2494, 0ULL, 1);
            heff_drop(v_top_2483);
            heff_drop(v_w_2484);
            heff_drop_rec(v_fm_2485, 3);
            heff_drop_cell(v_ru_24s_2492_24Just, 1);
            v_t_24103 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_t_2494);
          }
          break;
        }
        default: heff_nomatch(v_s_2492);
        }
        return heff_rec_n(2, shape_rows__cursor, (V[]){v_t_2479, v_t_24103});
      }
    }
  }
}
V g_std_2ecli_2einteractive_2eformView_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eformView(a[0], a[1], a[2]);
}
Clo g_std_2ecli_2einteractive_2eview_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2eview_entry, 2, 0};

V g_std_2ecli_2einteractive_2eview(V v_size_240, V v_m_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_m_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    HEFF_LAST return g_std_2ecli_2einteractive_2elistView(v_size_240, v_m_241);
  }
  case TAG_Just: {
    V v_fm_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    return (g_std_2ecli_2einteractive_2eformView(v_size_240, v_m_241, v_fm_243));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2einteractive_2eview_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2eview(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2einteractive_2ewantedDir_24cpr_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ewantedDir_24cpr_str1, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ewantedDir_24cpr_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2ewantedDir_24cpr_str3, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ewantedDir_24cpr_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2einteractive_2ewantedDir_24cpr_str5, 0, "");

HeffT2 g_std_2ecli_2einteractive_2ewantedDir_24cpr(V v_m_240) {
top: ;
  V v_t_241 = heff_get_n(v_m_240, 5, 8);
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_fm_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_at_243 = heff_take_field(v_fm_242, 2);
    V v_slots_244 = heff_get_n(v_fm_242, 1, 3);
    HeffT3 v_t_245 = ({ V a_0 = v_at_243; V a_1 = v_slots_244; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_slots_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      V v_field_248 = v_t_245.f[2];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        V v_part_2410 = heff_take_field(v_x_249, 0);
        V v_input_2411 = heff_get_n(v_x_249, 1, 2);
        V v_x12_2412 = v_field_248;
        heff_drop(v_x12_2412);
        V v_p_2413 = v_part_2410;
        V v_t_2414 = v_input_2411;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_Typed: {
          V v_t_2415 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_p_2413)) {
          case TAG_Positional: {
            V v_p_2416 = heff_field(v_p_2413, 0);
            heff_take_n(v_p_2413, 1ULL, 1);
            v_t_2418 = heff_get_n(v_p_2416, 2, 3);
            break;
          }
          case TAG_Flagged: {
            V v_f_2417 = heff_field(v_p_2413, 0);
            heff_take_n(v_p_2413, 1ULL, 1);
            v_t_2418 = heff_get_n(v_f_2417, 7, 8);
            break;
          }
          default: heff_nomatch(v_p_2413);
          }
          switch (heff_tag_of(v_t_2418)) {
          case TAG_None: {
            heff_drop_rec(v_t_2415, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Files: {
            heff_take_n(v_t_2418, 0ULL, 1);
            V v_t_2420 = heff_strOfRunes(heff_get_n(v_t_2415, 0, 2));
            V v_xs_2421 = ({ V a_0 = v_t_2420; V a_1 = ((V)&g_std_2ecli_2einteractive_2ewantedDir_24cpr_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2ewantedDir_24cpr_str1), v_t_2420, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2420); r_; });
            V v_x1_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
            V v_w_2425;
            switch (heff_tag_of(v_x1_2422)) {
            case TAG_Nil: {
              v_w_2425 = ((V)&g_std_2ecli_2einteractive_2ewantedDir_24cpr_str2);
              break;
            }
            case TAG_Cons: {
              V v_x_2423 = heff_field(v_x1_2422, 0);
              heff_take_n(v_x1_2422, 1ULL, 2);
              v_w_2425 = v_x_2423;
              break;
            }
            default: heff_nomatch(v_x1_2422);
            }
            int64_t v_t_2426 = (heff_unbox_word(heff_strLength_lent(v_w_2425, 0)) - ((int64_t)1ULL));
            V v_t_2427 = (g_std_2ecli_2einteractive_2eslashFrom(v_w_2425, heff_box_word(v_t_2426)));
            V v_f_2428 = heff_strSlice(v_w_2425, MK_INT(0LL), heff_intAdd(v_t_2427, MK_INT(1LL)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
          }
          case TAG_Dirs: {
            V v_t_2429 = heff_strOfRunes(heff_get_n(v_t_2415, 0, 2));
            V v_xs_2430 = ({ V a_0 = v_t_2429; V a_1 = ((V)&g_std_2ecli_2einteractive_2ewantedDir_24cpr_str3); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_std_2ecli_2einteractive_2ewantedDir_24cpr_str4), v_t_2429, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2429); r_; });
            V v_x1_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
            V v_w_2434;
            switch (heff_tag_of(v_x1_2431)) {
            case TAG_Nil: {
              v_w_2434 = ((V)&g_std_2ecli_2einteractive_2ewantedDir_24cpr_str5);
              break;
            }
            case TAG_Cons: {
              V v_x_2432 = heff_field(v_x1_2431, 0);
              heff_take_n(v_x1_2431, 1ULL, 2);
              v_w_2434 = v_x_2432;
              break;
            }
            default: heff_nomatch(v_x1_2431);
            }
            int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_w_2434, 0)) - ((int64_t)1ULL));
            V v_t_2436 = (g_std_2ecli_2einteractive_2eslashFrom(v_w_2434, heff_box_word(v_t_2435)));
            V v_f_2437 = heff_strSlice(v_w_2434, MK_INT(0LL), heff_intAdd(v_t_2436, MK_INT(1LL)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
          }
          case TAG_Among: {
            heff_take_n(v_t_2418, 0ULL, 1);
            heff_drop_rec(v_t_2415, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2418)}});
          }
        }
        case TAG_Picked: {
          heff_take_n(v_t_2414, 0ULL, 1);
          heff_drop(v_p_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t_2414)}});
        }
      } else {
        heff_drop(v_field_247);
        heff_drop(v_field_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_241)}});
  }
}
HEFF_LIT(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_str0, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_str1, 1, ".");
HEFF_LIT(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_str2, 0, "");
HEFF_LIT(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_str3, 1, ".");
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam0(V self, V *args); static Clo g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam0, 1, 0};
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam2(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam4(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam3(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam1(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam5(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam6(V self, V *args); static Clo g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam6, 1, 0};
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam8(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam10(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam9(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam7(V self, V *args);
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam11(V self, V *args);
Clo g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_entry, 1, 0};

V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287(V v_m_240) {
top: ;
  HeffT2 v_t_241 = (g_std_2ecli_2einteractive_2ewantedDir_24cpr(heff_dup(v_m_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_d_244 = v_field_243;
      V v_t_245 = heff_dup(heff_rfield(v_m_240, 7));
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        V v_t_246;
        if (heff_strEq_c_lent(v_d_244, ((V)&g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_str0), 2)) {
          v_t_246 = ((V)&g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_str1);
        } else {
          v_t_246 = heff_dup(v_d_244);
        }
        V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_t_246));
        V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
        V v_a_2410 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_248, ((V)&g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam0_clo)});
        return heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam1, 2, 4, (V[]){v_d_244, v_m_240, v_a_2410, v_path_247});
      }
      case TAG_Just: {
        V v_l_2430 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 1);
        if (heff_strEq_c(heff_get_n(v_l_2430, 0, 2), heff_dup(v_d_244))) {
          heff_drop(v_d_244);
          return heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam5, 2, 1, (V[]){v_m_240});
        } else {
          V v_t_2433;
          if (heff_strEq_c_lent(v_d_244, ((V)&g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_str2), 2)) {
            v_t_2433 = ((V)&g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_str3);
          } else {
            v_t_2433 = heff_dup(v_d_244);
          }
          V v_path_2434 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_t_2433));
          V v_t_2435 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2434; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
          V v_a_2437 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2435, ((V)&g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam6_clo)});
          return heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam7, 2, 4, (V[]){v_d_244, v_m_240, v_a_2437, v_path_2434});
        }
      }
      default: return heff_nomatch(v_t_245);
      }
    } else {
      heff_drop(v_field_243);
      return heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam11, 2, 1, (V[]){v_m_240});
    }
  }
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287(a[0]);
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_dir__names, (V[]){v_d_244, v_x_2413})});
  V v_t_2415 = ({ V rv_7 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_m_240, 127ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  V f_ = v_k_2412;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam4(V self, V *args) {
  V v_n_2427 = args[0];
  V v_path_247 = heff_env(self)[0];
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2427));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_247, v_t_2428));
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_path_247 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    heff_take_n(v_x_2422, 0ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_path_247);
    heff_drop(v_hd_2411);
    V f_ = v_k_2416;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2424 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    switch (heff_tag_of(v_y_2424)) {
    case TAG_Left: {
      heff_take_n(v_y_2424, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_path_247);
      heff_drop(v_hd_2411);
      V f_ = v_k_2416;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2426 = heff_field(v_y_2424, 0);
      heff_take_n(v_y_2424, 1ULL, 1);
      heff_clo_take(self, 3);
      V v_x_2429 = (g_list_2emap(heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam4, 1, 1, (V[]){v_path_247}), v_x_2426));
      return (g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(v_x_2429, v_hd_2411, v_k_2416));
    }
    default: return heff_nomatch(v_y_2424);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_d_244 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  V v_path_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_k_2416 = heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam2, 1, 3, (V[]){v_d_244, v_m_240, v_k_2412});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2421, heff_dup(v_hd_2411), heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam3, 1, 3, (V[]){v_k_2416, v_path_247, v_hd_2411})));
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_m_240 = heff_env(self)[0];
  heff_drop(v_hd_2431);
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = v_m_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam6(V self, V *args) {
  V v_r_2436 = args[0];
  return v_r_2436;
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_d_244 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_k_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_dir__names, (V[]){v_d_244, v_x_2440})});
  V v_t_2442 = ({ V rv_7 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_m_240, 127ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  V f_ = v_k_2439;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam10(V self, V *args) {
  V v_n_2454 = args[0];
  V v_path_2434 = heff_env(self)[0];
  V v_t_2455 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2454));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_2434, v_t_2455));
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2443 = heff_env(self)[0];
  V v_path_2434 = heff_env(self)[1];
  V v_hd_2438 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Left: {
    heff_take_n(v_x_2449, 0ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_path_2434);
    heff_drop(v_hd_2438);
    V f_ = v_k_2443;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2451 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    switch (heff_tag_of(v_y_2451)) {
    case TAG_Left: {
      heff_take_n(v_y_2451, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_path_2434);
      heff_drop(v_hd_2438);
      V f_ = v_k_2443;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2453 = heff_field(v_y_2451, 0);
      heff_take_n(v_y_2451, 1ULL, 1);
      heff_clo_take(self, 3);
      V v_x_2456 = (g_list_2emap(heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam10, 1, 1, (V[]){v_path_2434}), v_x_2453));
      return (g_std_2ecli_2einteractive_2enamesIn_2enamed_240_24s2000754744x371120956(v_x_2456, v_hd_2438, v_k_2443));
    }
    default: return heff_nomatch(v_y_2451);
    }
  }
  default: return heff_nomatch(v_x_2449);
  }
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam7(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_d_244 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_a_2437 = heff_env(self)[2];
  V v_path_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_k_2443 = heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam8, 1, 3, (V[]){v_d_244, v_m_240, v_k_2439});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2437})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2448, heff_dup(v_hd_2438), heff_clo_n(g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam9, 1, 3, (V[]){v_k_2443, v_path_2434, v_hd_2438})));
}
V g_std_2ecli_2einteractive_2elisted_24s2126540308x2126753287_lam11(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_m_240 = heff_env(self)[0];
  heff_drop(v_hd_2457);
  heff_clo_take(self, 1);
  V f_ = v_k_2458;
  args[0] = v_m_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_std_2ecli_2einteractive_2etypedOnList_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry, 3, 0};

V g_std_2ecli_2einteractive_2etypedOnList_24tok1(V v_tok_240, V v_c_241, V v_m_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_m_242, 3));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_f_244 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_241, heff_take_field(v_m_242, 2)));
    V v_t_245 = heff_take_field(v_m_242, 3);
    V v_t_249;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_249 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V v_t_246 = heff_dup(heff_rfield(v_f_244, 0));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        v_t_249 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
    }
    V v_t_2410 = ({ V rv_2 = v_f_244; V rv_3 = v_t_249; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_242, 227ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 64527u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_at_n(v_tok_240, TAG_Continue, 1, (V[]){v_t_2410});
  } else {
    heff_drop(v_t_243);
    if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(113LL))) {
      heff_drop(v_c_241);
      heff_drop_rec(v_m_242, 8);
      return heff_tag_at_n(v_tok_240, TAG_Done, 1, (V[]){NTAG(TAG_Nothing)});
    } else {
      if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(106LL))) {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_c_241);
        return (g_std_2ecli_2einteractive_2emoved(NTAG(TAG_ArrowDown), v_m_242));
      } else {
        if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(107LL))) {
          heff_drop_cell(v_tok_240, 1);
          heff_drop(v_c_241);
          return (g_std_2ecli_2einteractive_2emoved(NTAG(TAG_ArrowUp), v_m_242));
        } else {
          if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(47LL))) {
            heff_drop(v_c_241);
            V v_t_2411 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_m_242, 247ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
            return heff_tag_at_n(v_tok_240, TAG_Continue, 1, (V[]){v_t_2411});
          } else {
            V v_f_2412 = (g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(v_c_241, heff_take_field(v_m_242, 2)));
            V v_t_2413 = heff_take_field(v_m_242, 3);
            V v_t_2417;
            if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
              heff_drop(v_t_2413);
              v_t_2417 = NTAG(TAG_True);
            } else {
              heff_drop(v_t_2413);
              V v_t_2414 = heff_dup(heff_rfield(v_f_2412, 0));
              switch (heff_tag_of(v_t_2414)) {
              case TAG_Nil: {
                v_t_2417 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2414, 0ULL, 2);
                v_t_2417 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_t_2414);
              }
            }
            V v_t_2418 = ({ V rv_2 = v_f_2412; V rv_3 = v_t_2417; V rv_4 = heff_dup(g_std_2eterminal_2ewidget_2emenu_get()); V rr_ = heff_rec_reuse_nf(v_m_242, 227ULL, 8, shape_prog__entries__filter__typing__menu__form__alone__listing, 64527u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
            return heff_tag_at_n(v_tok_240, TAG_Continue, 1, (V[]){v_t_2418});
          }
        }
      }
    }
  }
}
V g_std_2ecli_2einteractive_2etypedOnList_24tok1_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einteractive_2etypedOnList_24tok1(a[0], a[1], a[2]);
}