#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Args 26338
#define TAG_Arrived 9729
#define TAG_Attempt 14217
#define TAG_Await 41810
#define TAG_Begin 41697
#define TAG_Close 2276
#define TAG_CloseFile 52884
#define TAG_CloseGiving 1232
#define TAG_CloseInput 41785
#define TAG_Closed 4831
#define TAG_Copy 17796
#define TAG_Directory 35277
#define TAG_Draw 50003
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exactly 30616
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FileStatus 2909
#define TAG_Finish 61316
#define TAG_Flush 26516
#define TAG_GetEnv 43934
#define TAG_Given 9359
#define TAG_Gone 5826
#define TAG_Got 19224
#define TAG_Inherited 58190
#define TAG_Interactive 42932
#define TAG_IsTerminal 53507
#define TAG_Kill 53643
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Log 24016
#define TAG_MakeDirectory 16793
#define TAG_MakeGiving 40807
#define TAG_Measure 52418
#define TAG_MkKid 64674
#define TAG_Monotonic 64960
#define TAG_Move 53768
#define TAG_NotRun 12703
#define TAG_Now 25954
#define TAG_Open 48267
#define TAG_OpenPath 44468
#define TAG_Other 45236
#define TAG_PathStatus 29154
#define TAG_PathUri 23459
#define TAG_Pending 60181
#define TAG_Piped 58996
#define TAG_Platform 55558
#define TAG_Processors 11008
#define TAG_ProgramPath 46819
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_ReadChunk 39695
#define TAG_ReadDirectory 46629
#define TAG_ReadErrors 12846
#define TAG_ReadFile 6783
#define TAG_ReadInput 54226
#define TAG_ReadLine 54539
#define TAG_ReadLink 54545
#define TAG_ReadOnly 17623
#define TAG_ReadOutput 34844
#define TAG_ReadStdin 20528
#define TAG_RealPath 18882
#define TAG_Regular 40886
#define TAG_Release 43671
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Seek 25805
#define TAG_Send 26077
#define TAG_SetMode 203
#define TAG_SetWorkingDir 4024
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Signalled 34337
#define TAG_Sleep 25229
#define TAG_Standard 18554
#define TAG_StandardPort 63523
#define TAG_Start 63542
#define TAG_TemporaryDirectory 61563
#define TAG_TemporaryFile 11955
#define TAG_Terminate 62553
#define TAG_Through 26159
#define TAG_TimedOut 6056
#define TAG_Timeout 14063
#define TAG_TryWait 64330
#define TAG_UriPath 39251
#define TAG_UseColor 15915
#define TAG_Wait 10206
#define TAG_Waited 38255
#define TAG_Wake 10253
#define TAG_Within 10658
#define TAG_WorkingDir 28879
#define TAG_Writable 11315
#define TAG_Write 36323
#define TAG_WriteBytes 40855
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_WriteInput 15010
#define TAG_WriteString 34128
#define LBL_code 9554612
#define LBL_columns 1181578779
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_kind 9787483
#define LBL_message 1186782793
#define LBL_mode 9852522
#define LBL_modified 129625309
#define LBL_name 9869138
#define LBL_other 307428138
#define LBL_out 319944
#define LBL_path 9928940
#define LBL_rows 10002080
#define LBL_size 10026184
V g_run_24entry_get(void);
// The standard streams' side of std.io, for the C backend: an
// effect provider.  A provider of the C backend defines, for each
// effect definition X of its module, `static V heff_provider_X(V p, V
// k)`: the operation `p` (a tag, `heff_tag_of`, its fields
// `heff_field`), done, and its answer given to the continuation `k`,
// last (`heff_tail`), as the JavaScript providers do (`k(a[1])`).  A
// function of the operation's (`ReadStdin`'s) is asked for its value
// through `heff_tr`.  It owns `p` and `k` (reference counts, as
// the runtime says): it takes what it keeps of `p` (`heff_dup`),
// drops `p`, and gives `k` away.  A number is as the runtime keeps it: an
// Int a word (`INT_OF`, `MK_INT`) or big, an Int64 and a UInt64 as an Int
// is, an integer of a fixed-width type of up to 32 bits a word of its
// value, a Float32 a word of its bits (`heff_f32_of`, `heff_f32`), a Float64
// boxed (`FLT_OF`, `heff_flt`); a Rune is a word of its code point.  It
// is bundled after the runtime, whose functions it uses -- among them
// those of foreign values, the host's things a provider hands out and
// another takes (`heff_foreign`, `heff_foreign_ptr`).
// A string it is given, or gives, crosses to the system and back only
// through the runtime's helpers, by what it is there -- content, a path,
// a name or text: `heff_str_bytes`, `heff_put`, `heff_cstr`,
// `heff_str_text`, `heff_cstr_text` and the like ("What providers share"
// in the runtime says which is which) -- never by its units, so that
// how the runtime keeps a string is the runtime's alone.

// (the lines std.progress draws on the terminal, once there are any:
// what is written clears them first, and they come back below it)
static void (*heff_lines)(int);

static V heff_provider_stdio(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Write: {
    if (heff_lines) heff_lines(1);
    heff_put(stdout, heff_field(p, 0));
    if (heff_lines) heff_lines(0);
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_WriteErr: {
    if (heff_lines) heff_lines(1);
    fflush(stdout);
    heff_put(stderr, heff_field(p, 0));
    if (heff_lines) heff_lines(0);
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_Flush: {
    fflush(stdout);
    V x = heff_dup(heff_field(p, 0));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_ReadStdin: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    size_t cap = 4096, n = 0;
    unsigned char *buf = heff_alloc(cap);
    size_t got;
    while ((got = fread(buf + n, 1, cap - n, stdin)) > 0) {
      n += got;
      if (n == cap) {
        unsigned char *b2 = heff_alloc(cap * 2);
        memcpy(b2, buf, n);
        free(buf);
        buf = b2;
        cap *= 2;
      }
    }
    V s = heff_str_bytes(buf, (int64_t)n);
    free(buf);
    V x = heff_tr(heff_app1(f, s));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of stdio");
    return 0;
  }
}

// The process's side of std.process, for the C backend: an effect
// provider.
// `Exit` ends the program there; `Exec` runs the command in its place.
// A command `Start`ed runs beside it, the host's own thing -- a foreign
// value, a `Started`, held by a `with` -- until it is waited for or
// its `with` ends (`Release`: ended, if it has not, and waited for);
// those not ended at the program's end are terminated then (atexit),
// and asked to end where a signal ends it.  A wait on one started in a
// group of std.reactor's is pending while the other threads go on: this
// provider is a source of the reactor's.

#ifdef _WIN32
#include <direct.h>
#else
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <time.h>
#include <unistd.h>
#endif
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__DragonFly__)
#include <sys/event.h>
#define HEFF_KQUEUE 1
#elif defined(__linux__)
#include <sys/syscall.h>
#endif

// (where the program is: its executable, as the system says)
static V heff_program_path(void) {
  char buf[4096];
#if defined(_WIN32)
  DWORD n = GetModuleFileNameA(NULL, buf, sizeof buf);
  if (n == 0 || n >= sizeof buf) return heff_str_text(heff_argv[0]);
  return heff_str_text(buf);
#elif defined(__APPLE__)
  uint32_t n = sizeof buf;
  if (_NSGetExecutablePath(buf, &n) != 0) return heff_str_text(heff_argv[0]);
#else
  ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 1);
  if (n < 0) return heff_str_text(heff_argv[0]);
  buf[n] = 0;
#endif
#ifndef _WIN32
  char real[4096];
  return heff_str_text(realpath(buf, real) ? real : buf);
#endif
}

// (a list of strings as a NULL-ended array of C strings, `first` first:
// NULL if one of them cannot be a C string)
static char **heff_argv_of(const char *first, V l) {
  int64_t n = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) n++;
  char **as = heff_alloc((n + 2) * sizeof(char *));
  as[0] = (char *)first;
  int64_t i = 1;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) {
    as[i] = heff_cstr_text(heff_field(c, 0));
    if (!as[i]) {
      for (int64_t j = 1; j < i; j++) free(as[j]);
      free(as);
      return NULL;
    }
    i++;
  }
  as[i] = NULL;
  return as;
}


// (the lines std.progress draws on the terminal, once there are any,
// cleared for good where a command runs in the program's place: an
// `Exit` clears them as the program ends)
static void (*heff_lines)(int);

#ifndef _WIN32
extern char **environ;
#endif

// A command run to its end (`Run`, an `Invocation`): its standard input
// the input given, written through a pipe and then closed, or none, the
// null device (not this program's, nor a closed descriptor, which the
// command's next open would take); its output and error stream read
// together, each kept up to `keep` bytes; killed (SIGKILL) at its time
// limit.  How it ended is an `Ended`.

// (what a command's input is: none, the null device; a string given,
// written to it; a pipe the program writes to; the program's)
enum { HEFF_IN_NONE, HEFF_IN_GIVEN, HEFF_IN_PIPED, HEFF_IN_INHERITED };

// (what its output or its error stream is: collected, read and kept; a
// pipe the program reads; the program's)
enum { HEFF_OUT_COLLECTED, HEFF_OUT_PIPED, HEFF_OUT_INHERITED };

// (an invocation, as the system is to be given it)
typedef struct {
  char **as;     // its name, then its arguments: NULL if one has a NUL
  char *dir;     // where it runs: the thread's, unless it says
  char **env;    // its environment: NULL, the program's
  int in_mode;   // HEFF_IN_*: its input
  char *in;      // the input `Given`: NULL, none
  size_t nin;
  int out_mode, err_mode;  // HEFF_OUT_*: its output, its error stream
  int64_t timeout, keep;  // milliseconds, bytes: 0, no limit
  int group;     // started in a process group of its own, ended with it
  V command;     // its name, and its directory, as the program gave them
  V given_dir;   //  (a failure's: 0, none)
} HeffInvocation;

// (the environment, `NAME=VALUE`s: the program's but those `sets` names,
// then those; malloc'd, NULL-ended -- NULL where one has a NUL)
static char **heff_env_with(char **sets, int64_t n) {
#ifdef _WIN32
  char *block = GetEnvironmentStringsA();
  int64_t ne = 0;
  for (char *e = block; *e; e += strlen(e) + 1) ne++;
#else
  int64_t ne = 0;
  while (environ[ne]) ne++;
#endif
  char **env = heff_alloc((size_t)(ne + n + 1) * sizeof(char *));
  int64_t k = 0;
#ifdef _WIN32
  for (char *e = block; *e; e += strlen(e) + 1) {
#else
  for (char **at = environ; *at; at++) {
    char *e = *at;
#endif
    const char *eq = strchr(e + (*e == '=' ? 1 : 0), '=');
    size_t len = eq ? (size_t)(eq - e) : strlen(e);
    int set = 0;
    for (int64_t i = 0; i < n && !set; i++)
#ifdef _WIN32
      set = _strnicmp(sets[i], e, len) == 0 && sets[i][len] == '=';
#else
      set = strncmp(sets[i], e, len) == 0 && sets[i][len] == '=';
#endif
    if (!set) {
      size_t l = strlen(e) + 1;
      env[k] = heff_alloc(l);
      memcpy(env[k++], e, l);
    }
  }
#ifdef _WIN32
  FreeEnvironmentStringsA(block);
#endif
  for (int64_t i = 0; i < n; i++) env[k++] = sets[i];
  env[k] = NULL;
  return env;
}

// (an `Output` as a mode)
static int heff_output_mode(V o) {
  switch (heff_tag_of(o)) {
  case TAG_Piped: return HEFF_OUT_PIPED;
  case TAG_Inherited: return HEFF_OUT_INHERITED;
  default: return HEFF_OUT_COLLECTED;
  }
}

// (the invocation `v`, an `Invocation` (its fields in its type's order:
// command, args, dir, env, input, output, errors, timeout, keep, group), as the
// system is to be given it: 0 where a string of it has a NUL in it)
static int heff_invocation(V v, HeffInvocation *r) {
  memset(r, 0, sizeof *r);
  V cmd = heff_rget_v(v, 0), args = heff_rget_v(v, 1), dir = heff_rget_v(v, 2);
  V env = heff_rget_v(v, 3), in = heff_rget_v(v, 4);
  V out = heff_rget_v(v, 5), err = heff_rget_v(v, 6);
  V timeout = heff_rget_v(v, 7), keep = heff_rget_v(v, 8);
  V group = heff_rget_v(v, 9);
  int ok = 1;
  char *c = heff_cstr_text(cmd);
  r->as = c ? heff_argv_of(c, args) : NULL;
  if (!r->as) { free(c); ok = 0; }
  // (where it runs: from this thread's directory, or that itself)
  if (((Str *)dir)->len > 0) {
    r->dir = heff_path_in_dir(heff_cstr(dir));
    if (!r->dir) ok = 0;
  } else r->dir = heff_dir_copy();
  int64_t n = 0;
  for (V l = env; heff_tag_of(l) == TAG_Cons; l = heff_field(l, 1)) n++;
  if (n > 0) {
    char **sets = heff_alloc((size_t)n * sizeof(char *));
    int64_t i = 0;
    for (V l = env; heff_tag_of(l) == TAG_Cons; l = heff_field(l, 1)) {
      V pair = heff_field(l, 0);
      char *name = heff_cstr_text(heff_field(pair, 0)), *value = heff_cstr_text(heff_field(pair, 1));
      if (name && value && *name && !strchr(name, '=')) {
        size_t a = strlen(name), b = strlen(value);
        sets[i] = heff_alloc(a + b + 2);
        memcpy(sets[i], name, a);
        sets[i][a] = '=';
        memcpy(sets[i] + a + 1, value, b + 1);
        i++;
      } else ok = 0;
      free(name);
      free(value);
    }
    r->env = heff_env_with(sets, i);
    free(sets);
  }
  switch (heff_tag_of(in)) {
  case TAG_Given:
    r->in_mode = HEFF_IN_GIVEN;
    r->in = heff_bytes(heff_field(in, 0), &r->nin);
    break;
  case TAG_Piped: r->in_mode = HEFF_IN_PIPED; break;
  case TAG_Inherited: r->in_mode = HEFF_IN_INHERITED; break;
  default: r->in_mode = HEFF_IN_NONE;
  }
  r->out_mode = heff_output_mode(out);
  r->err_mode = heff_output_mode(err);
  r->timeout = IS_INT(timeout) && INT_OF(timeout) > 0 ? INT_OF(timeout) : 0;
  r->keep = IS_INT(keep) && INT_OF(keep) > 0 ? INT_OF(keep) : 0;
  r->group = group == NTAG(TAG_True);
  r->command = cmd;
  r->given_dir = dir;
  heff_drop(args);
  heff_drop(env);
  heff_drop(in);
  heff_drop(out);
  heff_drop(err);
  heff_drop(timeout);
  heff_drop(keep);
  heff_drop(group);
  return ok;
}

static void heff_invocation_free(HeffInvocation *r) {
  if (r->as) {
    free(r->as[0]);
    for (int64_t j = 1; r->as[j]; j++) free(r->as[j]);
    free(r->as);
  }
  if (r->env) {
    for (int64_t j = 0; r->env[j]; j++) free(r->env[j]);
    free(r->env);
  }
  free(r->dir);
  free(r->in);
  if (r->command) heff_drop(r->command);
  if (r->given_dir) heff_drop(r->given_dir);
}

// (`n` bytes of what a command wrote, kept while fewer than `keep` are)
static void heff_keep_put(Buf *b, const char *c, size_t n, int64_t keep) {
  if (keep > 0) {
    if (b->n >= (size_t)keep) return;
    if (n > (size_t)keep - b->n) n = (size_t)keep - b->n;
  }
  buf_put(b, c, n);
}

static uint32_t heff_error_shape[4] = { LBL_code, LBL_name, LBL_message, LBL_path };

// (a `ProcessError` of errno `err`, of the program or the directory
// `path`, taken)
static V heff_process_error(int err, V path) {
  const char *name = heff_errno_name(err);
  char number[24];
  if (name[1] == '?') {
    snprintf(number, sizeof number, "errno %d", err);
    name = number;
  }
  V f[4] = { heff_int(err), heff_str_text(name), heff_str_text(strerror(err)), path };
  return heff_rec(4, heff_error_shape, f);
}

// (why the invocation `v` could not be run: errno `err`, of its
// directory, `at_dir`, or its command -- as the program gave them)
static V heff_why_not(HeffInvocation *v, int err, int at_dir) {
  V path;
  if (at_dir && v->given_dir && ((Str *)v->given_dir)->len > 0) path = heff_dup(v->given_dir);
  else if (at_dir && v->dir) path = heff_str_bytes(v->dir, (int64_t)strlen(v->dir));
  else path = v->command ? heff_dup(v->command) : heff_str_bytes("", 0);
  return heff_process_error(err, path);
}

// (how a command ended, as an `Ended`: `how` 0 by itself, its status
// `code`; 1 by the signal `code`; 2 at its time limit; 3 started, its
// end lost -- the command named `name`'s, ECHILD)
static V heff_ended(int how, int64_t code, const char *name) {
  V x = MK_INT(code);
  switch (how) {
  case 0: return heff_tag_n(TAG_Exited, 1, &x);
  case 1: return heff_tag_n(TAG_Signalled, 1, &x);
  case 2: return NTAG(TAG_TimedOut);
  default:
    x = heff_process_error(ECHILD, heff_str_bytes(name, (int64_t)strlen(name)));
    return heff_tag_n(TAG_NotRun, 1, &x);
  }
}

// Commands started (`Start`; `Run` is one started and waited for at
// once): each a `HeffSub`, the pointer of a foreign value (a `Started`)
// until the program lets go of it.  What it writes to a pipe is read
// into its buffers, what it is given written to its input, and its time
// limit kept, whenever the program waits on it -- `heff_round`, over
// those waited on.  (On Windows, a thread reads each of its pipes, and
// one writes its input.)  It has ended once it has exited and its pipes
// are closed, read to their end -- or once its time limit has passed:
// then killed, and its pipes closed, not even what its own children
// still write waited for.

// (a `HeffSub`'s mark: what a foreign value given an operation must be)
#define HEFF_SUB_MAGIC 0x53554250u

typedef struct HeffSub HeffSub;

// (an output stream of a command's: what it is, its pipe while open,
// what has come of it)
typedef struct {
  int mode;  // HEFF_OUT_*
#ifdef _WIN32
  HANDLE h, thread;  // its pipe, and the thread reading it: 0, none
  volatile LONG closed;
  HeffSub *owner;
#else
  int fd;  // -1: closed, or none
#endif
  Buf b;
  size_t at;  // what is read of `b` (a `Piped` stream's): taken before it
} HeffStream;

struct HeffSub {
  uint32_t magic;  // HEFF_SUB_MAGIC
#ifdef _WIN32
  HANDLE h;        // the process
  HANDLE feedh;    // the pipe its `Given` input is written to, by `feeder`
  HANDLE feeder;
  HANDLE fin;      // its input's pipe, `Piped`, while open: 0, none
  HANDLE came;     // set as something comes on a stream, or it ends
  CRITICAL_SECTION lock;  // its streams' buffers, the threads writing them
  int exited;
  DWORD code;
#else
  pid_t pid;
  int group;       // the leader of a process group of its own, `pid`
  int reaped;      // 0: not yet; 1: reaped, `st` its status; 2: lost
  int st;
  int fin;         // its input's pipe, while open: -1, none
  size_t at;       // how much of `given` is written
  int exitfd;      // what says it exited, readable then: -1, nothing does
  int exit_tried;  // (whether `exitfd` was asked for)
#endif
  int in_mode;     // HEFF_IN_*
  char *given;     // its input, `Given`: NULL, none
  size_t ngiven;
  HeffStream out, err;
  int64_t keep, deadline;  // bytes, the time it is killed at: 0, none
  int timed;
  char *name;      // its command's name, as it was given
  HeffSub *next;   // among those started, to be ended at the program's end
};

// (`n` bytes come on the stream: kept, as its mode says -- those
// `Collected` up to `keep`, those `Piped` until they are read)
static void heff_stream_put(HeffStream *st, const char *c, size_t n, int64_t keep) {
  if (st->mode == HEFF_OUT_PIPED) buf_put(&st->b, c, n);
  else heff_keep_put(&st->b, c, n, keep);
}

#ifdef _WIN32
static SRWLOCK heff_subs_lock = SRWLOCK_INIT;
#define HEFF_SUBS_LOCK() AcquireSRWLockExclusive(&heff_subs_lock)
#define HEFF_SUBS_UNLOCK() ReleaseSRWLockExclusive(&heff_subs_lock)

// (all a pipe gives, until it is closed, or the read cancelled)
static DWORD WINAPI heff_stream_drain(LPVOID u) {
  HeffStream *st = u;
  HeffSub *s = st->owner;
  char chunk[65536];
  DWORD got;
  while (ReadFile(st->h, chunk, sizeof chunk, &got, NULL) && got > 0) {
    EnterCriticalSection(&s->lock);
    heff_stream_put(st, chunk, got, s->keep);
    LeaveCriticalSection(&s->lock);
    SetEvent(s->came);
  }
  InterlockedExchange(&st->closed, 1);
  SetEvent(s->came);
  return 0;
}

// (its input written to the pipe, then the pipe closed)
static DWORD WINAPI heff_sub_feeder(LPVOID u) {
  HeffSub *s = u;
  size_t at = 0;
  DWORD put;
  while (at < s->ngiven) {
    DWORD want = s->ngiven - at > 65536 ? 65536 : (DWORD)(s->ngiven - at);
    if (!WriteFile(s->feedh, s->given + at, want, &put, NULL)) break;
    at += put;
  }
  CloseHandle(s->feedh);
  return 0;
}

// (a thread running `fn`, or, where none can be made, `fn` run here)
static HANDLE heff_thread_or_here(LPTHREAD_START_ROUTINE fn, void *u) {
  HANDLE t = CreateThread(NULL, 0, fn, u, 0, NULL);
  if (!t) fn(u);
  return t;
}

// (the thread ended: waited for, its read or write cancelled first
// where `cancel` says, again until it has ended)
static void heff_thread_join(HANDLE *t, int cancel) {
  if (!*t) return;
  if (cancel)
    do CancelSynchronousIo(*t);
    while (WaitForSingleObject(*t, 50) == WAIT_TIMEOUT);
  WaitForSingleObject(*t, INFINITE);
  CloseHandle(*t);
  *t = 0;
}

static int heff_stream_closed(HeffStream *st) {
  return !st->thread || st->closed;
}

// (whether it has ended: exited, its pipes read to their end)
static int heff_sub_done(HeffSub *s) {
  if (!s->exited) {
    if (WaitForSingleObject(s->h, 0) != WAIT_OBJECT_0) return 0;
    GetExitCodeProcess(s->h, &s->code);
    s->exited = 1;
  }
  return heff_stream_closed(&s->out) && heff_stream_closed(&s->err);
}

// (ended now: killed, if it has not exited, and its pipes no more read)
static void heff_sub_cut(HeffSub *s) {
  if (!s->exited) {
    TerminateProcess(s->h, 1);
    WaitForSingleObject(s->h, INFINITE);
    GetExitCodeProcess(s->h, &s->code);
    s->exited = 1;
  }
  heff_thread_join(&s->out.thread, 1);
  heff_thread_join(&s->err.thread, 1);
  heff_thread_join(&s->feeder, 1);
}

// (past its time limit, and not ended: cut short)
static void heff_sub_expire(HeffSub *s, int64_t now) {
  if (!s->deadline || now < s->deadline || heff_sub_done(s)) return;
  heff_sub_cut(s);
  s->timed = 1;
}

// (one round over the commands `ss`: waited for up to `ms` (-1: as long
// as it takes) for one to exit, those past their time limit cut short)
static void heff_round(HeffSub **ss, int n, int64_t ms) {
  HANDLE hs[MAXIMUM_WAIT_OBJECTS];
  DWORD k = 0;
  int64_t now = heff_now_ms();
  for (int i = 0; i < n; i++) {
    HeffSub *s = ss[i];
    if (heff_sub_done(s)) { ms = 0; continue; }
    if (!s->exited && k < MAXIMUM_WAIT_OBJECTS) hs[k++] = s->h;
    else if (ms < 0 || ms > 5) ms = 5;
    if (s->deadline) {
      int64_t left = s->deadline > now ? s->deadline - now : 0;
      if (ms < 0 || left < ms) ms = left;
    }
  }
  if (k) WaitForMultipleObjects(k, hs, FALSE, ms < 0 ? INFINITE : (DWORD)ms);
  else if (ms != 0) Sleep(ms < 0 ? 5 : (DWORD)ms);
  now = heff_now_ms();
  for (int i = 0; i < n; i++) heff_sub_expire(ss[i], now);
}

// (the environment as CreateProcess takes it: each `NAME=VALUE` ended by
// a NUL, and a NUL after them; malloc'd)
static char *heff_env_block(char **env) {
  Buf b = {0};
  for (char **e = env; *e; e++) buf_put(&b, *e, strlen(*e) + 1);
  buf_put(&b, "", 1);
  return b.s;
}

// (an output stream's pipe made, where it has one: its read end the
// stream's, its write end the command's; else the program's own `std`)
static int heff_stream_pipe(HeffStream *st, SECURITY_ATTRIBUTES *sa, HANDLE *w, DWORD std) {
  if (st->mode == HEFF_OUT_INHERITED) {
    *w = GetStdHandle(std);
    return 1;
  }
  if (!CreatePipe(&st->h, w, sa, 0)) return 0;
  SetHandleInformation(st->h, HANDLE_FLAG_INHERIT, 0);
  return 1;
}

static void heff_sub_free(HeffSub *s) {
  heff_thread_join(&s->out.thread, 0);
  heff_thread_join(&s->err.thread, 0);
  heff_thread_join(&s->feeder, 0);
  if (s->out.h) CloseHandle(s->out.h);
  if (s->err.h) CloseHandle(s->err.h);
  if (s->h) CloseHandle(s->h);
  if (s->fin) CloseHandle(s->fin);
  if (s->came) CloseHandle(s->came);
  DeleteCriticalSection(&s->lock);
  free(s->out.b.s);
  free(s->err.b.s);
  free(s->given);
  free(s->name);
  free(s);
}

// (the command started, as `v` says: NULL where it could not be, why in
// `*err` -- its directory's, `*at_dir`)
static HeffSub *heff_sub_spawn(HeffInvocation *v, int *err, int *at_dir) {
  SECURITY_ATTRIBUTES sa = { sizeof sa, NULL, TRUE };
  HeffSub *s = heff_alloc(sizeof *s);
  memset(s, 0, sizeof *s);
  s->magic = HEFF_SUB_MAGIC;
  s->name = heff_strdup(v->as[0]);
  InitializeCriticalSection(&s->lock);
  s->came = CreateEventA(NULL, FALSE, FALSE, NULL);
  s->in_mode = v->in_mode;
  s->out.owner = s->err.owner = s;
  s->out.mode = v->out_mode;
  s->err.mode = v->err_mode;
  HANDLE ow = 0, ew = 0, ir = 0, iw = 0;
  int ok = heff_stream_pipe(&s->out, &sa, &ow, STD_OUTPUT_HANDLE)
           && heff_stream_pipe(&s->err, &sa, &ew, STD_ERROR_HANDLE);
  if (ok && (v->in_mode == HEFF_IN_GIVEN || v->in_mode == HEFF_IN_PIPED)) {
    ok = CreatePipe(&ir, &iw, &sa, 0);
    if (ok) SetHandleInformation(iw, HANDLE_FLAG_INHERIT, 0);
  } else if (ok && v->in_mode == HEFF_IN_NONE) {
    ir = CreateFileA("NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa, OPEN_EXISTING, 0, NULL);
    ok = ir != INVALID_HANDLE_VALUE;
    if (!ok) ir = 0;
  }
  PROCESS_INFORMATION pi;
  if (ok) {
    char *line = heff_command_line(v->as);
    char *block = v->env ? heff_env_block(v->env) : NULL;
    STARTUPINFOA si;
    memset(&si, 0, sizeof si);
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = v->in_mode == HEFF_IN_INHERITED ? GetStdHandle(STD_INPUT_HANDLE) : ir;
    si.hStdOutput = ow;
    si.hStdError = ew;
    fflush(stdout);
    fflush(stderr);
    ok = CreateProcessA(NULL, line, NULL, NULL, TRUE, 0, block, v->dir, &si, &pi);
    free(line);
    free(block);
  }
  // (the command's ends of its pipes, its now)
  if (s->out.h && ow) CloseHandle(ow);
  if (s->err.h && ew) CloseHandle(ew);
  if (ir) CloseHandle(ir);
  if (!ok) {
    DWORD last = GetLastError();
    *at_dir = last == ERROR_DIRECTORY;
    *err = last == ERROR_FILE_NOT_FOUND || last == ERROR_DIRECTORY ? ENOENT : EACCES;
    if (iw) CloseHandle(iw);
    heff_sub_free(s);
    return NULL;
  }
  CloseHandle(pi.hThread);
  s->h = pi.hProcess;
  s->keep = v->keep;
  s->deadline = v->timeout > 0 ? heff_now_ms() + v->timeout : 0;
  if (s->out.h) s->out.thread = heff_thread_or_here(heff_stream_drain, &s->out);
  if (s->err.h) s->err.thread = heff_thread_or_here(heff_stream_drain, &s->err);
  if (iw && v->in_mode == HEFF_IN_PIPED) s->fin = iw;
  else if (iw) {
    s->given = v->in;
    s->ngiven = v->nin;
    v->in = NULL;
    s->feedh = iw;
    s->feeder = heff_thread_or_here(heff_sub_feeder, s);
  }
  return s;
}

// (how it ended: `how` as heff_ended takes it, its status `code`)
static int heff_sub_how(HeffSub *s, int64_t *code) {
  *code = (int64_t)s->code;
  return s->timed ? 2 : 0;
}

static void heff_sub_kill(HeffSub *s) {
  if (!heff_sub_done(s) && !s->exited) TerminateProcess(s->h, 1);
}

// (it ended, if it has not: made to at once, as Windows has no asking)
static void heff_sub_end(HeffSub *s) {
  if (!heff_sub_done(s)) heff_sub_cut(s);
}
#else
static pthread_mutex_t heff_subs_mu = PTHREAD_MUTEX_INITIALIZER;
#define HEFF_SUBS_LOCK() pthread_mutex_lock(&heff_subs_mu)
#define HEFF_SUBS_UNLOCK() pthread_mutex_unlock(&heff_subs_mu)

// (a descriptor not given to the commands run: those of another
// command's pipes, run at once by another thread, would keep them open)
static int heff_cloexec(int fd) {
  if (fd >= 0) fcntl(fd, F_SETFD, FD_CLOEXEC);
  return fd;
}

static int heff_pipe(int p[2]) {
  if (pipe(p) != 0) return 0;
  heff_cloexec(p[0]);
  heff_cloexec(p[1]);
  return 1;
}

static void heff_close(int *fd) {
  if (*fd >= 0) close(*fd);
  *fd = -1;
}

static int heff_nonblock(int fd) {
  if (fd >= 0) fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
  return fd;
}

// (how a command ended, by waitpid's status)
static int heff_ended_how(int st, int64_t *code) {
  if (WIFEXITED(st)) { *code = WEXITSTATUS(st); return 0; }
  if (WIFSIGNALED(st)) { *code = WTERMSIG(st); return 1; }
  return 3;
}

// (a write to an input not read fails, not the program by SIGPIPE: held
// off in this thread while it is written to, and taken back if it came)
static void heff_nopipe(sigset_t *before) {
  sigset_t sp;
  sigemptyset(&sp);
  sigaddset(&sp, SIGPIPE);
  pthread_sigmask(SIG_BLOCK, &sp, before);
}

static void heff_nopipe_end(const sigset_t *before) {
  sigset_t pending, sp;
  sigemptyset(&sp);
  sigaddset(&sp, SIGPIPE);
  sigpending(&pending);
  if (sigismember(&pending, SIGPIPE) && !sigismember(before, SIGPIPE)) {
    int s;
    sigwait(&sp, &s);
  }
  pthread_sigmask(SIG_SETMASK, before, NULL);
}

// (as much of what is to be written to its input as its pipe takes now,
// written: the pipe closed where it is read no more, or, `Given`, once
// all of it is)
static void heff_sub_feed(HeffSub *s) {
  while (s->fin >= 0 && s->at < s->ngiven) {
    ssize_t put = write(s->fin, s->given + s->at, s->ngiven - s->at);
    if (put > 0) s->at += (size_t)put;
    else if (put < 0 && errno == EINTR) continue;
    else if (put < 0 && errno == EAGAIN) return;
    else {
      heff_close(&s->fin);
      return;
    }
  }
  if (s->in_mode == HEFF_IN_GIVEN) heff_close(&s->fin);
}

// (what has come on the stream, read: closed at its end)
static void heff_stream_read(HeffSub *s, HeffStream *st) {
  char chunk[65536];
  ssize_t got = read(st->fd, chunk, sizeof chunk);
  if (got < 0 && (errno == EINTR || errno == EAGAIN)) return;
  if (got <= 0) heff_close(&st->fd);
  else heff_stream_put(st, chunk, (size_t)got, s->keep);
}

// (whether it has exited, reaped where it has: waiting, where `block`)
static void heff_sub_reap(HeffSub *s, int block) {
  if (s->reaped) return;
  int st;
  pid_t w;
  while ((w = waitpid(s->pid, &st, block ? 0 : WNOHANG)) < 0 && errno == EINTR) {}
  if (w == s->pid) {
    s->reaped = 1;
    s->st = st;
  } else if (w < 0) s->reaped = 2;
}

// (whether it has ended: exited, its pipes read to their end)
static int heff_sub_done(HeffSub *s) {
  return s->reaped && s->out.fd < 0 && s->err.fd < 0;
}

// (the signal sent to it -- to its process group, the group's own --
// if it has not been reaped)
static void heff_sub_signal(HeffSub *s, int sig) {
  if (!s->reaped) kill(s->group ? -s->pid : s->pid, sig);
}

// (ended now: killed, if it has not exited, and its pipes closed; of a
// group's own, what is left of the group killed too)
static void heff_sub_cut(HeffSub *s) {
  if (s->group) kill(-s->pid, SIGKILL);
  if (!s->reaped) {
    kill(s->pid, SIGKILL);
    heff_sub_reap(s, 1);
  }
  heff_close(&s->out.fd);
  heff_close(&s->err.fd);
  heff_close(&s->fin);
}

// (past its time limit, and not ended: cut short)
static void heff_sub_expire(HeffSub *s, int64_t now) {
  if (!s->deadline || now < s->deadline || heff_sub_done(s)) return;
  heff_sub_cut(s);
  s->timed = 1;
}

// (a descriptor that says when the command exits, readable then: a
// kqueue's, its NOTE_EXIT (macOS, the BSDs), or a pidfd (Linux); -1
// where the system has neither, or it has exited already -- then it is
// looked at every 5 ms until it is reaped.  Asked for once.)
static int heff_sub_exit_fd(HeffSub *s) {
  if (s->exit_tried) return s->exitfd;
  s->exit_tried = 1;
#if defined(HEFF_KQUEUE)
  int kq = kqueue();
  if (kq >= 0) {
    struct kevent ev;
    EV_SET(&ev, (uintptr_t)s->pid, EVFILT_PROC, EV_ADD | EV_ONESHOT, NOTE_EXIT, 0, NULL);
    if (kevent(kq, &ev, 1, NULL, 0, NULL) == 0) s->exitfd = heff_cloexec(kq);
    else close(kq);
  }
#elif defined(__linux__) && defined(SYS_pidfd_open)
  int fd = (int)syscall(SYS_pidfd_open, s->pid, 0);
  if (fd >= 0) s->exitfd = heff_cloexec(fd);
#endif
  return s->exitfd;
}

// (a descriptor to poll, put at `fds[*k]` where there is room, counted
// either way)
static void heff_polled_put(struct pollfd *fds, int room, int *k, int fd, short events) {
  if (fd < 0) return;
  if (*k < room) fds[*k] = (struct pollfd){ fd, events, 0 };
  (*k)++;
}

// (what is to be polled for the command -- its pipes, to read or to
// write; what says it exited -- put at `fds`, `*k` on, where there is
// room; and how long at most to wait for them, `*ms` (-1: as long as it
// takes): its time limit, 5 ms where nothing says when it exits, none
// where it has ended)
static void heff_sub_polled(HeffSub *s, struct pollfd *fds, int room, int *k, int64_t now, int64_t *ms) {
  if (heff_sub_done(s)) { *ms = 0; return; }
  heff_polled_put(fds, room, k, s->out.fd, POLLIN);
  heff_polled_put(fds, room, k, s->err.fd, POLLIN);
  if (s->fin >= 0 && s->at < s->ngiven) heff_polled_put(fds, room, k, s->fin, POLLOUT);
  if (!s->reaped) {
    int x = heff_sub_exit_fd(s);
    if (x >= 0) heff_polled_put(fds, room, k, x, POLLIN);
    else if (*ms < 0 || *ms > 5) *ms = 5;
  }
  if (s->deadline) {
    int64_t left = s->deadline > now ? s->deadline - now : 0;
    if (*ms < 0 || left < *ms) *ms = left;
  }
}

// (what has come for the command, taken, nothing waited for: what it
// wrote read, what it is given written, reaped where it has exited, cut
// short where it is past its time limit)
static void heff_sub_came(HeffSub *s) {
  sigset_t before;
  heff_nopipe(&before);
  if (s->out.fd >= 0) heff_stream_read(s, &s->out);
  if (s->err.fd >= 0) heff_stream_read(s, &s->err);
  if (s->fin >= 0 && s->at < s->ngiven) heff_sub_feed(s);
  heff_nopipe_end(&before);
  heff_sub_reap(s, 0);
#if defined(HEFF_KQUEUE)
  // (the kqueue said it exited, and waitpid has not yet: the kqueue let
  // go of, so that it is not said again and again; looked at every 5 ms)
  if (!s->reaped && s->exitfd >= 0) {
    struct kevent ev;
    struct timespec none = { 0, 0 };
    if (kevent(s->exitfd, NULL, 0, &ev, 1, &none) > 0) heff_close(&s->exitfd);
  }
#endif
  heff_sub_expire(s, heff_now_ms());
}

// (one round over the commands `ss`: waited up to `ms` (-1: as long as
// it takes) for anything to come for any of them, then what came taken)
static void heff_round(HeffSub **ss, int n, int64_t ms) {
  int room = 4 * n + 1;
  struct pollfd *fds = heff_alloc((size_t)room * sizeof *fds);
  int k = 0;
  int64_t now = heff_now_ms();
  for (int i = 0; i < n; i++) heff_sub_polled(ss[i], fds, room, &k, now, &ms);
  if (ms > 1000000) ms = 1000000;
  poll(fds, (nfds_t)k, (int)ms);
  free(fds);
  for (int i = 0; i < n; i++) heff_sub_came(ss[i]);
}

static void heff_sub_free(HeffSub *s) {
  heff_close(&s->out.fd);
  heff_close(&s->err.fd);
  heff_close(&s->fin);
  heff_close(&s->exitfd);
  free(s->out.b.s);
  free(s->err.b.s);
  free(s->given);
  free(s->name);
  free(s);
}

// (the signals that end a program, held back by `heff_start` from
// before a command is started until it is among those ended with the
// program -- else one coming between would leave it running -- and the
// signals as they were held before)
static const int heff_ending[3] = { SIGINT, SIGTERM, SIGHUP };
static HEFF_TLS int heff_spawn_held = 0;
static HEFF_TLS sigset_t heff_spawn_mask;

// (the command started, forked and exec'd as `v` says -- in its
// directory, with its environment, its input -- or NULL where it could
// not be: not found, not a program, its directory not there, as the
// child says through a pipe of its own; why in `*err`, its directory's
// where `*at_dir`)
static HeffSub *heff_sub_spawn(HeffInvocation *v, int *err, int *at_dir) {
  HeffSub *s = heff_alloc(sizeof *s);
  memset(s, 0, sizeof *s);
  s->magic = HEFF_SUB_MAGIC;
  s->name = heff_strdup(v->as[0]);
  s->out.fd = s->err.fd = s->fin = s->exitfd = -1;
  s->in_mode = v->in_mode;
  s->out.mode = v->out_mode;
  s->err.mode = v->err_mode;
  int po[2] = { -1, -1 }, pe[2] = { -1, -1 }, pi[2] = { -1, -1 }, px[2] = { -1, -1 };
  int ok = heff_pipe(px);
  if (ok && v->out_mode != HEFF_OUT_INHERITED) ok = heff_pipe(po);
  if (ok && v->err_mode != HEFF_OUT_INHERITED) ok = heff_pipe(pe);
  if (ok && (v->in_mode == HEFF_IN_GIVEN || v->in_mode == HEFF_IN_PIPED)) ok = heff_pipe(pi);
  else if (ok && v->in_mode == HEFF_IN_NONE) ok = (pi[0] = heff_cloexec(open("/dev/null", O_RDONLY))) >= 0;
  pid_t pid = -1;
  if (ok) {
    fflush(stdout);
    fflush(stderr);
    pid = fork();
    if (pid == 0) {
      // (the child: nothing but what is safe after a fork; why it failed
      // said, its errno and whether its directory's)
      int e[2] = { 0, 0 };
      if (heff_spawn_held) {
        // (the program's handlers of the ending signals not the
        // command's, and the signals held as the program held them)
        for (int i = 0; i < 3; i++) {
          struct sigaction was;
          if (sigaction(heff_ending[i], NULL, &was) == 0 && was.sa_handler != SIG_IGN)
            signal(heff_ending[i], SIG_DFL);
        }
        sigprocmask(SIG_SETMASK, &heff_spawn_mask, NULL);
      }
      if (v->group) setpgid(0, 0);
      if (chdir(v->dir) != 0) {
        e[1] = 1;
        goto failed;
      }
      if ((pi[0] >= 0 && dup2(pi[0], 0) < 0) || (po[1] >= 0 && dup2(po[1], 1) < 0)
          || (pe[1] >= 0 && dup2(pe[1], 2) < 0))
        goto failed;
      if (v->env) environ = v->env;
      execvp(v->as[0], v->as);
    failed:
      e[0] = errno;
      (void)!write(px[1], e, sizeof e);
      _exit(127);
    }
  }
  // (its group made here too, so that it is there before it is killed)
  if (pid > 0 && v->group) setpgid(pid, pid);
  heff_close(&pi[0]);
  heff_close(&po[1]);
  heff_close(&pe[1]);
  heff_close(&px[1]);
  if (pid > 0) {
    // (the command's name found and run, or why not, said by the child)
    int e[2];
    ssize_t said;
    do said = read(px[0], e, sizeof e); while (said < 0 && errno == EINTR);
    if (said == (ssize_t)sizeof e) {
      int st;
      while (waitpid(pid, &st, 0) < 0 && errno == EINTR) {}
      pid = -1;
      errno = e[0];
      *at_dir = e[1];
    }
  }
  *err = errno ? errno : EINVAL;
  heff_close(&px[0]);
  if (pid <= 0) {
    heff_close(&po[0]);
    heff_close(&pe[0]);
    heff_close(&pi[1]);
    heff_sub_free(s);
    return NULL;
  }
  s->pid = pid;
  s->group = v->group;
  // (its pipes read as what has come, never waiting on one: a read of
  // nothing is nothing)
  s->out.fd = heff_nonblock(po[0]);
  s->err.fd = heff_nonblock(pe[0]);
  s->fin = pi[1];
  s->keep = v->keep;
  s->deadline = v->timeout > 0 ? heff_now_ms() + v->timeout : 0;
  if (s->fin >= 0) {
    fcntl(s->fin, F_SETFL, fcntl(s->fin, F_GETFL) | O_NONBLOCK);
#ifdef F_SETNOSIGPIPE
    // (macOS: SIGPIPE is the process's, not the thread's, there -- not
    // held off by a thread's mask: none sent for this pipe at all)
    fcntl(s->fin, F_SETNOSIGPIPE, 1);
#endif
    if (v->in_mode == HEFF_IN_GIVEN) {
      s->given = v->in;
      s->ngiven = v->nin;
      v->in = NULL;
      // (what its pipe takes now, written at once: a short input is all
      // given before it is waited on)
      sigset_t before;
      heff_nopipe(&before);
      heff_sub_feed(s);
      heff_nopipe_end(&before);
    }
  }
  return s;
}

// (how it ended: `how` as heff_ended takes it, its status or signal
// `code`)
static int heff_sub_how(HeffSub *s, int64_t *code) {
  if (s->timed) return 2;
  return s->reaped == 1 ? heff_ended_how(s->st, code) : 3;
}

static void heff_sub_kill(HeffSub *s) {
  heff_sub_signal(s, SIGKILL);
}
#endif

// (the first of the commands `ss` to end, waited for up to `ms`
// milliseconds (-1: as long as it takes; 0: not at all): its index, or
// -1 where none has ended)
static int heff_await(HeffSub **ss, int n, int64_t ms) {
  int64_t until = ms > 0 ? heff_now_ms() + ms : 0;
  for (int first = 1;; first = 0) {
    for (int i = 0; i < n; i++)
      if (heff_sub_done(ss[i])) return i;
    if (n == 0 || (ms == 0 && !first)) return -1;
    int64_t wait = ms == 0 ? 0 : -1;
    if (until) {
      wait = until - heff_now_ms();
      if (wait <= 0) return -1;
    }
    heff_round(ss, n, wait);
  }
}

#ifndef _WIN32
// (it ended, if it has not: its input closed, asked to end (SIGTERM),
// then made to, two seconds after)
static void heff_sub_end(HeffSub *s) {
  if (heff_sub_done(s)) return;
  heff_close(&s->fin);
  heff_sub_signal(s, SIGTERM);
  if (heff_await(&s, 1, 2000) < 0) heff_sub_cut(s);
}
#endif

static uint32_t heff_run_shape[3] = { LBL_ended, LBL_out, LBL_err };

// (an ended command's `Ran`: how it ended, what it wrote)
static V heff_sub_ran(HeffSub *s) {
  int64_t code = 0;
  int how = heff_sub_how(s, &code);
  V f[3] = {
    heff_ended(how, code, s->name),
    heff_str_bytes(s->out.b.s ? s->out.b.s + s->out.at : "", (int64_t)(s->out.b.n - s->out.at)),
    heff_str_bytes(s->err.b.s ? s->err.b.s + s->err.at : "", (int64_t)(s->err.b.n - s->err.at)),
  };
  return heff_rec(3, heff_run_shape, f);
}

// (a command not run, as `why`, a `ProcessError`, says: its `Ran`)
static V heff_not_ran(V why) {
  V f[3] = { heff_tag_n(TAG_NotRun, 1, &why), heff_str_bytes("", 0), heff_str_bytes("", 0) };
  return heff_rec(3, heff_run_shape, f);
}

// (the command of the invocation `inv` started, as `v`; NULL where it
// could not be, why at `*why`)
static HeffSub *heff_launched(V inv, HeffInvocation *v, V *why) {
  int err = EINVAL, at_dir = 0;
  HeffSub *s = heff_invocation(inv, v) ? heff_sub_spawn(v, &err, &at_dir) : NULL;
  if (!s) *why = heff_why_not(v, err, at_dir);
  heff_invocation_free(v);
  return s;
}

// (a command run, as an `Invocation` says, to its end: a `Ran`)
static V heff_run(V inv) {
  HeffInvocation v;
  V why;
  HeffSub *s = heff_launched(inv, &v, &why);
  if (!s) return heff_not_ran(why);
  heff_await(&s, 1, -1);
  V r = heff_sub_ran(s);
  heff_sub_free(s);
  return r;
}

// Those started and not yet waited for: ended at the program's end, and
// asked to end where a signal ends it.

static HeffSub *heff_subs = NULL;

static void heff_subs_atexit(void) {
  for (HeffSub *s = heff_subs; s; s = s->next) heff_sub_end(s);
}

#ifndef _WIN32
// (commands being started now, by any thread, and whether a signal is
// ending the program: it waits for those being started to be among
// those it ends -- two seconds at most, should a thread starting one
// wait on the one it came to -- and none is started after it)
static int heff_spawning = 0;
static int heff_ending_now = 0;

// (the program ended by a signal -- SIGINT, SIGTERM, SIGHUP, where
// nothing else was to be done at it: one std.signal's provider catches,
// waited for, is not -- what it started and has not
// ended asked to end too, then the signal as it was: ended as it would
// have been)
static void heff_subs_signal(int sig) {
  __atomic_store_n(&heff_ending_now, 1, __ATOMIC_SEQ_CST);
  for (int i = 0; i < 2000 && __atomic_load_n(&heff_spawning, __ATOMIC_SEQ_CST) > 0; i++) {
    struct timespec a = { 0, 1000000 };
    nanosleep(&a, NULL);
  }
  for (HeffSub *s = heff_subs; s; s = s->next)
    heff_sub_signal(s, SIGTERM);
  signal(sig, SIG_DFL);
  raise(sig);
}

static void heff_subs_watch(void) {
  for (int i = 0; i < 3; i++) {
    struct sigaction before;
    if (sigaction(heff_ending[i], NULL, &before) != 0 || before.sa_handler != SIG_DFL) continue;
    struct sigaction a;
    memset(&a, 0, sizeof a);
    a.sa_handler = heff_subs_signal;
    sigemptyset(&a.sa_mask);
    a.sa_flags = SA_RESTART;
    sigaction(heff_ending[i], &a, NULL);
  }
}

// (a command about to be started: the ending signals held back from
// this thread -- heard by another, the handler waits for it -- until
// it is among those started; where the program is being ended,
// nothing more is started: this thread waits for its end)
static void heff_spawn_hold(void) {
  sigset_t ending;
  sigemptyset(&ending);
  for (int i = 0; i < 3; i++) sigaddset(&ending, heff_ending[i]);
  pthread_sigmask(SIG_BLOCK, &ending, &heff_spawn_mask);
  heff_spawn_held = 1;
  __atomic_fetch_add(&heff_spawning, 1, __ATOMIC_SEQ_CST);
  if (__atomic_load_n(&heff_ending_now, __ATOMIC_SEQ_CST)) {
    __atomic_fetch_sub(&heff_spawning, 1, __ATOMIC_SEQ_CST);
    for (;;) pause();
  }
}

// (it is among those started, or was not started: the signals heard
// again, one that came meanwhile now)
static void heff_spawn_release(void) {
  __atomic_fetch_sub(&heff_spawning, 1, __ATOMIC_SEQ_CST);
  heff_spawn_held = 0;
  pthread_sigmask(SIG_SETMASK, &heff_spawn_mask, NULL);
}
#endif

// (ended by its custodian, while a thread may hold it still: killed,
// with its group, unless it has exited -- the thread that waits for it
// reaps it, and the program's letting go of it frees it)
static const char *heff_sub_ended(void *x) {
  HeffSub *s = x;
#ifdef _WIN32
  heff_sub_end(s);
#else
  if (s->group) kill(-s->pid, SIGKILL);
  heff_sub_signal(s, SIGKILL);
#endif
  return NULL;
}

// (let go of -- the program dropped its last reference to its value:
// ended first, taken out of those started)
static void heff_sub_let_go(void *x) {
  HeffSub *s = x;
  heff_sub_end(s);
  HEFF_SUBS_LOCK();
  for (HeffSub **at = &heff_subs; *at; at = &(*at)->next)
    if (*at == s) { *at = s->next; break; }
  HEFF_SUBS_UNLOCK();
  heff_sub_free(s);
}

// (the command started, as an `Invocation` says: `Right` it, the host's
// own -- a foreign value, ended and let go of where the program drops
// its last reference to it -- or `Left` why it was not)
static V heff_start(V inv) {
  HeffInvocation v;
  V why = 0;
  // (those not ended at the end ended then, from before the first is
  // started)
  HEFF_SUBS_LOCK();
  static int registered = 0;
  if (!registered) {
    registered = 1;
    atexit(heff_subs_atexit);
#ifndef _WIN32
    heff_subs_watch();
#endif
  }
  HEFF_SUBS_UNLOCK();
#ifndef _WIN32
  heff_spawn_hold();
#endif
  HeffSub *s = heff_launched(inv, &v, &why);
  if (s) {
    HEFF_SUBS_LOCK();
    s->next = heff_subs;
    heff_subs = s;
    HEFF_SUBS_UNLOCK();
  }
#ifndef _WIN32
  heff_spawn_release();
#endif
  if (!s) return heff_tag_n(TAG_Left, 1, &why);
  V x = heff_foreign_ending(s, heff_sub_let_go, heff_sub_ended);
  return heff_tag_n(TAG_Right, 1, &x);
}

// (the command a `Started` is, or the program failed: it is none)
static HeffSub *heff_sub_of(V v) {
  HeffSub *s = heff_foreign_ptr(v);
  if (s->magic != HEFF_SUB_MAGIC) heff_fail("std.process: no command started");
  return s;
}

// A command spoken to: its input `Piped`, written to and closed; its
// output or its error stream `Piped`, read as it goes.  What it writes
// is read into the stream's buffer whenever the program waits on it --
// a write as much as a read, so that it never waits on a program that
// waits on it -- and a read takes from there.

// (what a read asks for, a `Portion`: `kind` 0, whatever there is; 1,
// `n` bytes; 2, up to and with the `nd` bytes `d`)
typedef struct {
  int kind;
  int64_t n;
  const uint8_t *d;
  int64_t nd;
} HeffPortion;

static void heff_portion(V v, HeffPortion *w) {
  memset(w, 0, sizeof *w);
  switch (heff_tag_of(v)) {
  case TAG_Exactly:
    w->kind = 1;
    w->n = INT_OF(heff_field(v, 0));
    if (w->n < 0) w->n = 0;
    break;
  case TAG_Through:
    w->kind = 2;
    w->d = heff_bytes_data(heff_field(v, 0), &w->nd);
    break;
  default: w->kind = 0;
  }
}

// (what is taken of what has come on the stream and is not yet read, as
// `w` asks -- all that is left, at its end (`closed`): 1, the bytes in
// `*got`; 0, not yet; -1, none, at its end)
static int heff_stream_take(HeffStream *st, HeffPortion *w, int closed, V *got) {
  size_t avail = st->b.n - st->at, k = 0;
  const char *base = st->b.s ? st->b.s + st->at : "";
  int ok = 0;
  if (w->kind == 0) {
    ok = avail > 0;
    k = avail;
  } else if (w->kind == 1) {
    ok = avail >= (size_t)w->n;
    k = (size_t)w->n;
  } else {
    size_t nd = (size_t)w->nd;
    for (size_t i = 0; !ok && i + nd <= avail; i++)
      if (memcmp(base + i, w->d, nd) == 0) {
        ok = 1;
        k = i + nd;
      }
  }
  if (!ok && closed) {
    if (!avail) return -1;
    ok = 1;
    k = avail;
  }
  if (!ok) return 0;
  *got = heff_bytes_in(base, (int64_t)k);
  st->at += k;
  if (st->at == st->b.n) st->at = st->b.n = 0;
  else if (st->at > 65536 && st->at * 2 > st->b.n) {
    memmove(st->b.s, st->b.s + st->at, st->b.n - st->at);
    st->b.n -= st->at;
    st->at = 0;
  }
  return 1;
}

static V heff_got(V b) { return heff_tag_n(TAG_Got, 1, &b); }

#ifdef _WIN32
// (of what has come on the stream, what `w` asks, waited for up to `ms`
// (0: as long as it takes): a `Received`)
static V heff_sub_read(HeffSub *s, HeffStream *st, HeffPortion *w, int64_t ms) {
  if (st->mode != HEFF_OUT_PIPED) return NTAG(TAG_Closed);
  int64_t until = ms > 0 ? heff_now_ms() + ms : 0;
  for (;;) {
    V got;
    EnterCriticalSection(&s->lock);
    int closed = heff_stream_closed(st);
    int r = heff_stream_take(st, w, closed, &got);
    LeaveCriticalSection(&s->lock);
    if (r > 0) return heff_got(got);
    if (r < 0) return NTAG(TAG_Closed);
    int64_t wait = 50;
    if (until) {
      wait = until - heff_now_ms();
      if (wait <= 0) return NTAG(TAG_Timeout);
      if (wait > 50) wait = 50;
    }
    WaitForSingleObject(s->came, (DWORD)wait);
    heff_sub_expire(s, heff_now_ms());
  }
}

// (the bytes written to its input, all of them: whether they were)
static int heff_sub_write(HeffSub *s, const uint8_t *d, size_t n) {
  if (s->in_mode != HEFF_IN_PIPED || !s->fin) return 0;
  size_t at = 0;
  DWORD put;
  while (at < n) {
    DWORD want = n - at > 65536 ? 65536 : (DWORD)(n - at);
    if (!WriteFile(s->fin, d + at, want, &put, NULL)) {
      CloseHandle(s->fin);
      s->fin = 0;
      return 0;
    }
    at += put;
  }
  return 1;
}

static void heff_sub_close_input(HeffSub *s) {
  if (s->in_mode == HEFF_IN_PIPED && s->fin) {
    CloseHandle(s->fin);
    s->fin = 0;
  }
}
#else
// (of what has come on the stream, what `w` asks, waited for up to `ms`
// (0: as long as it takes): a `Received`)
static V heff_sub_read(HeffSub *s, HeffStream *st, HeffPortion *w, int64_t ms) {
  if (st->mode != HEFF_OUT_PIPED) return NTAG(TAG_Closed);
  int64_t until = ms > 0 ? heff_now_ms() + ms : 0;
  for (;;) {
    V got;
    int r = heff_stream_take(st, w, st->fd < 0, &got);
    if (r > 0) return heff_got(got);
    if (r < 0) return NTAG(TAG_Closed);
    int64_t wait = -1;
    if (until) {
      wait = until - heff_now_ms();
      if (wait <= 0) return NTAG(TAG_Timeout);
    }
    heff_round(&s, 1, wait);
  }
}

// (the bytes written to its input, all of them, what it writes read
// meanwhile: whether they were)
static int heff_sub_write(HeffSub *s, const uint8_t *d, size_t n) {
  if (s->in_mode != HEFF_IN_PIPED || s->fin < 0) return 0;
  s->given = (char *)d;
  s->ngiven = n;
  s->at = 0;
  sigset_t before;
  heff_nopipe(&before);
  heff_sub_feed(s);
  heff_nopipe_end(&before);
  while (s->fin >= 0 && s->at < s->ngiven) {
    if (heff_sub_done(s)) heff_close(&s->fin);
    else heff_round(&s, 1, -1);
  }
  int ok = s->fin >= 0;
  s->given = NULL;
  s->ngiven = s->at = 0;
  return ok;
}

static void heff_sub_close_input(HeffSub *s) {
  if (s->in_mode == HEFF_IN_PIPED) heff_close(&s->fin);
}
#endif

#ifndef _WIN32
// Waits on a started command, pending in a group of std.reactor's: a
// thread's, which goes on once it is done while the other threads go
// on meanwhile -- for its end (`Wait`, `Terminate`), for a portion of
// what it writes (`ReadOutput`, `ReadErrors`), for its input to take
// what is written (`WriteInput`).  Each is a wait of the reactor's with
// no descriptor of its own: this provider is a source of theirs --
// polled with the rest, the commands' pipes and what says each exited,
// for as long at most as a time limit or a read's leaves -- and says
// which are done.  Outside a group of the reactor's a wait is as it was,
// the program waiting with it.

enum { PW_WAIT, PW_READ, PW_WRITE };

typedef struct ProcWait ProcWait;
struct ProcWait {
  HeffWait w;        // (first: a wait is its `HeffWait`, its `fd` -1)
  HeffSub *s;
  V held, held2;     // (the command's value, and a read's portion or a
                     //  write's bytes: kept while the wait is pending)
  int what;          // PW_*
  HeffStream *st;    // (a read's stream)
  HeffPortion portion;
  int64_t until;     // (a read's time limit, or when a terminate makes
                     //  the command end: 0, none)
  int cut;           // (a terminate: cut short at `until`)
  V result;          // (a read's answer, once there is one)
  ProcWait *prev, *next;
};

static HEFF_TLS ProcWait *pw_first;
static HEFF_TLS HeffSource pw_source;

static int pw_step(HeffWait *w) {
  (void)w;
  return HEFF_STEP_WAIT;
}

// (whether the wait is done now; a read's answer made where it is)
static int pw_ready(ProcWait *p, int64_t now) {
  HeffSub *s = p->s;
  switch (p->what) {
  case PW_WAIT:
    if (heff_sub_done(s)) return 1;
    if (p->cut && now >= p->until) {
      heff_sub_cut(s);
      return 1;
    }
    return 0;
  case PW_READ: {
    V got;
    int r = heff_stream_take(p->st, &p->portion, p->st->fd < 0, &got);
    if (r > 0) p->result = heff_got(got);
    else if (r < 0) p->result = NTAG(TAG_Closed);
    else if (p->until && now >= p->until) p->result = NTAG(TAG_Timeout);
    else return 0;
    return 1;
  }
  default:
    if (heff_sub_done(s)) heff_close(&s->fin);
    return s->fin < 0 || s->at >= s->ngiven;
  }
}

// (the source's descriptors: those of every pending wait's command, and
// how long at most to wait for them)
static int pw_fds(struct pollfd *fds, int room, int *ms) {
  int k = 0;
  int64_t now = heff_now_ms(), m = -1;
  for (ProcWait *p = pw_first; p; p = p->next) {
    if (p->w.done) continue;
    heff_sub_polled(p->s, fds, room, &k, now, &m);
    if (p->until) {
      int64_t left = p->until > now ? p->until - now : 0;
      if (m < 0 || left < m) m = left;
    }
  }
  if (m > INT_MAX) m = INT_MAX;
  *ms = (int)m;
  return k;
}

// (after the poll: what came for each pending wait's command taken, and
// those done said so)
static void pw_came(struct pollfd *fds, int n) {
  (void)fds;
  (void)n;
  int64_t now = heff_now_ms();
  for (ProcWait *p = pw_first; p; p = p->next) {
    if (p->w.done) continue;
    heff_sub_came(p->s);
    if (pw_ready(p, now)) heff_wait_done(&p->w);
  }
}

// (the wait let go of: out of the pending, what it held dropped)
static void pw_free(ProcWait *p) {
  if (p->prev) p->prev->next = p->next;
  else pw_first = p->next;
  if (p->next) p->next->prev = p->prev;
  if (p->what == PW_WRITE) {
    p->s->given = NULL;
    p->s->ngiven = p->s->at = 0;
  }
  heff_drop(p->held);
  if (p->held2) heff_drop(p->held2);
  free(p);
}

static V pw_answer(HeffWait *w) {
  ProcWait *p = (ProcWait *)w;
  V r;
  switch (p->what) {
  case PW_WAIT: r = heff_sub_ran(p->s); break;
  case PW_READ: r = p->result; break;
  default: r = heff_bool(p->s->fin >= 0); break;
  }
  pw_free(p);
  return r;
}

static void pw_cancel(HeffWait *w) {
  ProcWait *p = (ProcWait *)w;
  if (p->what == PW_READ && p->result) heff_drop(p->result);
  pw_free(p);
}

// (a wait on the command `s`, whose value `held` it keeps)
static ProcWait *pw_new(int what, HeffSub *s, V held) {
  ProcWait *p = heff_alloc(sizeof *p);
  memset(p, 0, sizeof *p);
  p->what = what;
  p->s = s;
  p->held = held;
  return p;
}

// (the wait begun, pending: `f` of its answer given to `k` once it is
// done)
static V pw_begin(ProcWait *p, V f, V k) {
  p->w.fd = -1;
  p->w.step = pw_step;
  p->w.answer = pw_answer;
  p->w.cancel = pw_cancel;
  p->prev = NULL;
  p->next = pw_first;
  if (pw_first) pw_first->prev = p;
  pw_first = p;
  if (!pw_source.on) {
    pw_source.fds = pw_fds;
    pw_source.ready = pw_came;
    heff_reactor_source(&pw_source);
  }
  return heff_outside(&p->w, f, k);
}
#endif

static V heff_provider_process(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Args: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_strs_text(heff_argv + 1, heff_argc - 1));
    return heff_tail(k, 1, &x);
  }
  case TAG_GetEnv: {
    char *name = heff_cstr_text(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    const char *v = name ? getenv(name) : NULL;
    free(name);
    V x = heff_answer(f, v ? heff_just(heff_str_text(v)) : heff_nothing);
    return heff_tail(k, 1, &x);
  }
  case TAG_ProgramPath: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_program_path());
    return heff_tail(k, 1, &x);
  }
  // (the working directory is this thread's own, never the process's)
  case TAG_WorkingDir: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_str_text(heff_working_dir()));
    return heff_tail(k, 1, &x);
  }
  case TAG_SetWorkingDir: {
    char *dir = heff_cstr(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    V x = heff_answer(f, heff_bool(dir && heff_working_dir_set(dir)));
    return heff_tail(k, 1, &x);
  }
  case TAG_Platform: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
#if defined(__APPLE__)
    const char *pl = "darwin";
#elif defined(_WIN32)
    const char *pl = "win32";
#else
    const char *pl = "linux";
#endif
    V x = heff_answer(f, heff_str_text(pl));
    return heff_tail(k, 1, &x);
  }
  case TAG_Processors: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
#if defined(_WIN32)
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    int64_t n = si.dwNumberOfProcessors > 0 ? (int64_t)si.dwNumberOfProcessors : 1;
#elif defined(_SC_NPROCESSORS_ONLN)
    long c = sysconf(_SC_NPROCESSORS_ONLN);
    int64_t n = c > 0 ? (int64_t)c : 1;
#else
    int64_t n = 1;
#endif
    V x = heff_answer(f, MK_INT(n));
    return heff_tail(k, 1, &x);
  }
  case TAG_Exit: {
    int code = (int)INT_OF(heff_field(p, 0));
    fflush(stdout);
    fflush(stderr);
    heff_exit(code);
  }
  case TAG_Run: {
    V inv = heff_dup(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    V r = heff_run(inv);
    heff_drop(inv);
    V x = heff_answer(f, r);
    return heff_tail(k, 1, &x);
  }
  case TAG_Start: {
    V inv = heff_dup(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    V r = heff_start(inv);
    heff_drop(inv);
    V x = heff_answer(f, r);
    return heff_tail(k, 1, &x);
  }
  // (a command's value is kept through its operation: the operation may
  // hold the last reference, and dropping it lets the command go)
  // (a `with` letting go of its command: ended here where the `with`
  // held it alone, else left to whoever holds it still, ended as the
  // last of them lets go of it)
  case TAG_Release: {
    V v = heff_dup(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    if (heff_unique(v)) heff_sub_end(heff_sub_of(v));
    heff_drop(v);
    V u = NTAG(TAG_MkUnit);
    V x = heff_answer(f, heff_tag_n(TAG_Right, 1, &u));
    return heff_tail(k, 1, &x);
  }
  case TAG_Wait: {
    V v = heff_dup(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    HeffSub *s = heff_sub_of(v);
    heff_sub_close_input(s);
#ifndef _WIN32
    if (heff_group && heff_await(&s, 1, 0) < 0) return pw_begin(pw_new(PW_WAIT, s, v), f, k);
#endif
    heff_await(&s, 1, -1);
    V x = heff_answer(f, heff_sub_ran(s));
    heff_drop(v);
    return heff_tail(k, 1, &x);
  }
  case TAG_TryWait: {
    V v = heff_dup(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    HeffSub *s = heff_sub_of(v);
    V r = heff_await(&s, 1, 0) == 0 ? heff_just(heff_sub_ran(s)) : heff_nothing;
    heff_drop(v);
    V x = heff_answer(f, r);
    return heff_tail(k, 1, &x);
  }
  case TAG_Kill: {
    heff_sub_kill(heff_sub_of(heff_field(p, 0)));
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_Terminate: {
    V v = heff_dup(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    HeffSub *s = heff_sub_of(v);
#ifndef _WIN32
    if (heff_group && !heff_sub_done(s)) {
      // (asked to end; pending until it has, made to two seconds after)
      heff_close(&s->fin);
      heff_sub_signal(s, SIGTERM);
      if (heff_await(&s, 1, 0) < 0) {
        ProcWait *w = pw_new(PW_WAIT, s, v);
        w->cut = 1;
        w->until = heff_now_ms() + 2000;
        return pw_begin(w, f, k);
      }
    }
#endif
    heff_sub_end(s);
    V x = heff_answer(f, heff_sub_ran(s));
    heff_drop(v);
    return heff_tail(k, 1, &x);
  }
  case TAG_WriteInput: {
    V v = heff_dup(heff_field(p, 0));
    V b = heff_dup(heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    HeffSub *s = heff_sub_of(v);
    int64_t n;
    const uint8_t *d = heff_bytes_data(b, &n);
#ifndef _WIN32
    if (heff_group && s->in_mode == HEFF_IN_PIPED && s->fin >= 0) {
      // (what its pipe takes now written; pending for the rest)
      s->given = (char *)d;
      s->ngiven = (size_t)n;
      s->at = 0;
      sigset_t before;
      heff_nopipe(&before);
      heff_sub_feed(s);
      heff_nopipe_end(&before);
      if (s->fin >= 0 && s->at < s->ngiven) {
        ProcWait *w = pw_new(PW_WRITE, s, v);
        w->held2 = b;
        return pw_begin(w, f, k);
      }
      int ok = s->fin >= 0;
      s->given = NULL;
      s->ngiven = s->at = 0;
      heff_drop(v);
      heff_drop(b);
      V x = heff_answer(f, heff_bool(ok));
      return heff_tail(k, 1, &x);
    }
#endif
    int ok = heff_sub_write(s, d, (size_t)n);
    heff_drop(v);
    heff_drop(b);
    V x = heff_answer(f, heff_bool(ok));
    return heff_tail(k, 1, &x);
  }
  case TAG_CloseInput: {
    heff_sub_close_input(heff_sub_of(heff_field(p, 0)));
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_ReadOutput:
  case TAG_ReadErrors: {
    V v = heff_dup(heff_field(p, 0));
    V portion = heff_dup(heff_field(p, 1));
    V ms = heff_field(p, 2);
    int64_t limit = IS_INT(ms) && INT_OF(ms) > 0 ? INT_OF(ms) : 0;
    V f = heff_dup(heff_field(p, 3));
    int errors = heff_tag_of(p) == TAG_ReadErrors;
    heff_drop(p);
    HeffSub *s = heff_sub_of(v);
    HeffPortion w;
    heff_portion(portion, &w);
    HeffStream *st = errors ? &s->err : &s->out;
#ifndef _WIN32
    if (heff_group && st->mode == HEFF_OUT_PIPED) {
      // (what has come taken, where it is what is asked; pending else)
      heff_round(&s, 1, 0);
      V got;
      int r = heff_stream_take(st, &w, st->fd < 0, &got);
      if (r == 0) {
        ProcWait *pw = pw_new(PW_READ, s, v);
        pw->held2 = portion;
        pw->st = st;
        pw->portion = w;
        pw->until = limit ? heff_now_ms() + limit : 0;
        return pw_begin(pw, f, k);
      }
      heff_drop(v);
      heff_drop(portion);
      V x = heff_answer(f, r > 0 ? heff_got(got) : NTAG(TAG_Closed));
      return heff_tail(k, 1, &x);
    }
#endif
    V r = heff_sub_read(s, st, &w, limit);
    heff_drop(v);
    heff_drop(portion);
    V x = heff_answer(f, r);
    return heff_tail(k, 1, &x);
  }
  case TAG_Exec: {
    char *c = heff_cstr_text(heff_field(p, 0));
    char **as = c ? heff_argv_of(c, heff_field(p, 1)) : NULL;
    // (std.progress's lines, if any are drawn, cleared for good: the
    // command has the terminal now)
    if (heff_lines) heff_lines(2);
    fflush(stdout);
    fflush(stderr);
    errno = EINVAL;
    if (as) {
#ifdef _WIN32
      // (no exec on Windows: the command is run, and its exit code this
      // program's)
      HANDLE h = heff_spawn(as, GetStdHandle(STD_OUTPUT_HANDLE), GetStdHandle(STD_ERROR_HANDLE));
      if (h) heff_exit((int)heff_wait(h));
#else
      // (the program's process becomes the command's: in this
      // thread's directory, as it would be between a fork and an exec)
      if (chdir(heff_working_dir()) == 0) execvp(c, as);
#endif
    }
    // (why, as a `ProcessError` says it)
    int e = errno ? errno : ENOENT;
    fprintf(stderr, "%s: %s: %s\n", c ? c : "the command", heff_errno_name(e), strerror(e));
    heff_exit(1);
  }
  default:
    heff_fail("not an operation of process");
    return 0;
  }
}

// The disk's side of std.filesystem, for the C backend: an effect
// provider.
//
// Whole files, directories and paths are done there and then.  An open
// file is a `FsFile`, the host's own, which the program holds as a
// foreign value (held by a `with`): closed by `CloseFile` when the
// `with` ends, and let go of -- closed, unless the `with` closed it --
// where the program drops its last reference to it.  It reads ahead
// into a buffer of its own, from which lines and chunks are taken.
//
// A read or a write of an open file is a `FsOp`, done in steps as
// std.net's are: where a scheduler of
// std.reactor's runs, a pipe, a terminal or a socket -- what poll can
// say is ready -- is polled first, and the op waits in the runtime's
// reactor until it
// is, the other green threads going on.  The descriptor is left as it
// is, never made non-blocking (a standard stream's flags are its
// parent's too): a read is done once poll says there is something to
// read, and a write of no more than PIPE_BUF bytes once it says there
// is room.  A regular file is always ready, as poll sees it, and is read
// and written there and then, the whole program waiting for the disk.

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#ifdef _WIN32
// (no links on Windows as stat sees them, and mkdir takes no mode)
#define lstat stat
#define S_ISLNK(m) 0
#define heff_mkdir(p) mkdir(p)
#define heff_is_sep(c) ((c) == '/' || (c) == '\\')
#else
#include <limits.h>
#define heff_mkdir(p) mkdir(p, 0777)
#define heff_is_sep(c) ((c) == '/')
#endif

// Why an operation failed
// ---------------------------------------------------------------------
//
// A `FileError` names the path the failing call was given -- in a tree,
// the one inside it -- as the program wrote it: the system is given a
// path from this thread's directory (`heff_path_in_dir`), and a path it
// was given under one the program wrote is said from that one again.

static uint32_t fs_error_shape[5] = { LBL_code, LBL_name, LBL_message, LBL_path, LBL_other };

// (a `FileError` of errno `err`, of the path `path` and the other,
// `other` -- 0, none -- both taken)
static V fs_error(int err, V path, V other) {
  const char *name = heff_errno_name(err);
  char number[24];
  if (name[1] == '?') {
    snprintf(number, sizeof number, "errno %d", err);
    name = number;
  }
  V f[5] = { heff_int(err), heff_str_text(name), heff_str_text(strerror(err)), path,
             other ? heff_just(other) : heff_nothing };
  return heff_rec(5, fs_error_shape, f);
}

static V fs_right(V x) { return heff_tag_n(TAG_Right, 1, &x); }

// (`Right MkUnit`)
static V fs_done(void) { return fs_right(NTAG(TAG_MkUnit)); }

// (`Left` a `FileError` of errno `err`, of the path the C string `path`)
static V fs_left_at(int err, const char *path) {
  V x = fs_error(err, heff_str_bytes(path, (int64_t)strlen(path)), 0);
  return heff_tag_n(TAG_Left, 1, &x);
}

// (`Left` EINVAL, of a path that is none, a string with a NUL in it:
// `s`, not taken)
static V fs_invalid(V s) {
  V x = fs_error(EINVAL, heff_dup(s), 0);
  return heff_tag_n(TAG_Left, 1, &x);
}

// (a path as the program wrote it, `given`, and as the system is given
// it, `full`: both malloc'd, NULL where it has a NUL in it)
typedef struct {
  char *given;
  char *full;
} FsPath;

// (the path `s` as the system is to be given it: whether it is one)
static int fs_path(FsPath *p, V s) {
  p->given = heff_cstr(s);
  p->full = p->given ? heff_path_in_dir(heff_strdup(p->given)) : NULL;
  return p->full != NULL;
}

static void fs_path_free(FsPath *p) {
  free(p->given);
  free(p->full);
}

// (`n` bytes at `a` and the C string `b`, as a string)
static V fs_joined(const char *a, size_t n, const char *b) {
  size_t m = strlen(b);
  char *s = heff_alloc(n + m + 1);
  memcpy(s, a, n);
  memcpy(s + n, b, m + 1);
  V v = heff_str_bytes(s, (int64_t)(n + m));
  free(s);
  return v;
}

// (the path `at`, one the system was given, as the program wrote it:
// one of the paths `ps` or under it, from that one as written; one above
// it, where what is between is written the same; else as it is)
static V fs_named(const char *at, const FsPath *ps, int n) {
  size_t k = strlen(at);
  for (int i = 0; i < n; i++) {
    const char *full = ps[i].full, *given = ps[i].given;
    if (!full) continue;
    size_t f = strlen(full), g = strlen(given);
    if (k >= f && strncmp(at, full, f) == 0 && (at[f] == 0 || heff_is_sep(at[f]))) {
      // (under it: `given`, then what follows)
      const char *rest = at + f;
      if (*rest && g > 0 && heff_is_sep(given[g - 1])) rest++;
      return fs_joined(given, g, rest);
    }
    if (k < f && strncmp(at, full, k) == 0 && heff_is_sep(full[k])) {
      // (above it: `given`, less what follows `at` in `full`)
      size_t tail = f - k;
      if (g > tail && strcmp(given + g - tail, full + k) == 0) return fs_joined(given, g - tail, "");
    }
  }
  return heff_str_bytes(at, (int64_t)k);
}

// (why an operation failed, as it is found: the errno, the path the
// failing call was given and, where it took two, the other -- the
// system's, malloc'd)
typedef struct {
  int err;
  char *at, *other;
} FsWhy;

// (a failure of the call given `at`, and `other` (NULL, none), with the
// errno `err` -- 0: errno's, or EIO where it left none -- kept, unless
// one was before, the innermost of a tree's: 0)
static int fs_fail2(FsWhy *w, const char *at, const char *other, int err) {
  if (w->at) return 0;
  w->err = err ? err : errno ? errno : EIO;
  w->at = heff_strdup(at);
  w->other = other ? heff_strdup(other) : NULL;
  return 0;
}

// (a failure of the call given `at`, errno's: 0)
static int fs_fail(FsWhy *w, const char *at) { return fs_fail2(w, at, NULL, 0); }

// (`Left` why, its paths as the program wrote them, of the paths `ps`:
// `w` let go of)
static V fs_failed(FsWhy *w, const FsPath *ps, int n) {
  V at = fs_named(w->at ? w->at : "", ps, n);
  V other = w->other ? fs_named(w->other, ps, n) : 0;
  V x = fs_error(w->err ? w->err : EIO, at, other);
  free(w->at);
  free(w->other);
  w->at = w->other = NULL;
  return heff_tag_n(TAG_Left, 1, &x);
}

// Whole files, directories and trees
// ---------------------------------------------------------------------
//
// Each answers whether it was done; where it was not, why is in its
// `FsWhy`.

// (a file's text, at `*out`)
static int heff_read_file(const char *path, V *out, FsWhy *w) {
  errno = 0;
  FILE *f = fopen(path, "rb");
  if (!f) return fs_fail(w, path);
  // (a regular file read straight into the string, as long as it says)
  struct stat st;
  int64_t size =
    fstat(fileno(f), &st) == 0 && S_ISREG(st.st_mode) ? (int64_t)st.st_size : 0;
  *out = heff_str_read(f, size);
  if (!*out) fs_fail(w, path);
  fclose(f);
  return *out != 0;
}

static int heff_write_file(const char *path, V s, FsWhy *w) {
  errno = 0;
  FILE *f = fopen(path, "wb");
  if (!f) return fs_fail(w, path);
  heff_put(f, s);
  return fclose(f) == 0 || fs_fail(w, path);
}

// (a directory is at `path`, links followed)
static int heff_is_dir(const char *path) {
  struct stat st;
  return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

// (a directory and those it is in: whether a directory is there -- a
// file there is none, EEXIST)
static int heff_mkdir_p(char *path, FsWhy *w) {
  for (char *c = path + 1; *c; c++)
    if (heff_is_sep(*c)) {
      char sep = *c;
      *c = 0;
      // (a drive, `C:`, is there already)
      int drive = c[-1] == ':';
      int ok = drive || heff_mkdir(path) == 0 || errno == EEXIST;
      if (!ok) fs_fail(w, path);
      *c = sep;
      if (!ok) return 0;
    }
  errno = 0;
  if (heff_mkdir(path) == 0) return 1;
  int e = errno;
  if (e == EEXIST && heff_is_dir(path)) return 1;
  return fs_fail2(w, path, NULL, e);
}

// (the names in a directory, sorted, at `*out`)
static int heff_read_dir(const char *path, V *out, FsWhy *w) {
  errno = 0;
  DIR *d = opendir(path);
  if (!d) return fs_fail(w, path);
  int64_t n = 0, cap = 64;
  char **ns = heff_alloc(cap * sizeof(char *));
  struct dirent *e;
  while ((e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    if (n == cap) {
      char **n2 = heff_alloc(cap * 2 * sizeof(char *));
      memcpy(n2, ns, n * sizeof(char *));
      free(ns);
      ns = n2;
      cap *= 2;
    }
    ns[n++] = strdup(e->d_name);
  }
  closedir(d);
  qsort(ns, n, sizeof(char *), heff_cmp_cstr);
  *out = heff_strs_bytes(ns, n);
  for (int64_t i = 0; i < n; i++) free(ns[i]);
  free(ns);
  return 1;
}

// (every file and directory under `p`, its mode's write bits off, or on:
// a directory is made writable before what it holds, read-only after.
// -1 where nothing is at `p`)
static int heff_chmod_all(const char *p, int writable, FsWhy *w) {
  struct stat st;
  if (lstat(p, &st) != 0) return errno == ENOENT ? -1 : fs_fail(w, p);
  if (S_ISLNK(st.st_mode)) return 1;
  mode_t mode = writable ? (st.st_mode | 0200) : (st.st_mode & ~0222);
  mode &= 07777;
  if (S_ISDIR(st.st_mode)) {
    if (writable && chmod(p, mode) != 0) return fs_fail(w, p);
    DIR *d = opendir(p);
    if (!d) return fs_fail(w, p);
    struct dirent *e;
    int ok = 1;
    while (ok && (e = readdir(d))) {
      if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
      char *q = heff_join(p, e->d_name);
      ok = heff_chmod_all(q, writable, w) != 0;
      free(q);
    }
    closedir(d);
    if (!ok) return 0;
    if (!writable && chmod(p, mode) != 0) return fs_fail(w, p);
    return 1;
  }
  return chmod(p, mode) == 0 || fs_fail(w, p);
}

// (a file, or a directory and all it holds; nothing there is no failure)
static int heff_remove_all(const char *p, FsWhy *w) {
  struct stat st;
  if (lstat(p, &st) != 0) return errno == ENOENT || fs_fail(w, p);
  if (!S_ISDIR(st.st_mode)) return unlink(p) == 0 || fs_fail(w, p);
  DIR *d = opendir(p);
  if (!d) return fs_fail(w, p);
  struct dirent *e;
  int ok = 1;
  while (ok && (e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    char *q = heff_join(p, e->d_name);
    ok = heff_remove_all(q, w);
    free(q);
  }
  closedir(d);
  return ok && (rmdir(p) == 0 || fs_fail(w, p));
}

// (a file's bytes copied to `q`, which is given `mode`)
static int heff_copy_file(const char *p, const char *q, mode_t mode, FsWhy *w) {
  FILE *f = fopen(p, "rb");
  if (!f) return fs_fail(w, p);
  FILE *g = fopen(q, "wb");
  if (!g) {
    int e = errno;
    fclose(f);
    return fs_fail2(w, q, NULL, e);
  }
  char *chunk = heff_alloc(65536);
  size_t got;
  const char *bad = NULL;
  int e = 0;
  while (!bad && (got = fread(chunk, 1, 65536, f)) > 0)
    if (fwrite(chunk, 1, got, g) != got) {
      e = errno;
      bad = q;
    }
  if (!bad && ferror(f)) {
    e = errno;
    bad = p;
  }
  free(chunk);
  fclose(f);
  if (fclose(g) != 0 && !bad) {
    e = errno;
    bad = q;
  }
  if (!bad && chmod(q, mode) != 0) {
    e = errno;
    bad = q;
  }
  return bad ? fs_fail2(w, bad, NULL, e) : 1;
}

// (a file, or a directory and all it holds, copied to `q`: links
// followed, modes kept -- a directory's once what it holds is in it)
static int heff_copy_all(const char *p, const char *q, FsWhy *w) {
  struct stat st;
  if (stat(p, &st) != 0) return fs_fail(w, p);
  mode_t mode = st.st_mode & 07777;
  if (!S_ISDIR(st.st_mode)) return heff_copy_file(p, q, mode, w);
  if (heff_mkdir(q) != 0) return fs_fail(w, q);
  DIR *d = opendir(p);
  if (!d) return fs_fail(w, p);
  struct dirent *e;
  int ok = 1;
  while (ok && (e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    char *a = heff_join(p, e->d_name);
    char *b = heff_join(q, e->d_name);
    ok = heff_copy_all(a, b, w);
    free(a);
    free(b);
  }
  closedir(d);
  return ok && (chmod(q, mode) == 0 || fs_fail(w, q));
}

// (whether something is at `p`, a file, a directory or a link: 1; 0,
// nothing; -1, the system cannot say, why in `w`)
static int heff_something_at(const char *p, FsWhy *w) {
  struct stat st;
  if (lstat(p, &st) == 0) return 1;
  if (errno == ENOENT) return 0;
  fs_fail(w, p);
  return -1;
}

// (a move or a rename's: `to` free, why not in `w`)
static int heff_free_at(const char *to, FsWhy *w) {
  int there = heff_something_at(to, w);
  if (there > 0) fs_fail2(w, to, NULL, EEXIST);
  return there == 0;
}

// (an operation of whole files and paths: answered by an `Either
// FileError a`)
static V heff_fs_whole(V p, V k) {
  int tag = heff_tag_of(p);
  int two = tag == TAG_Copy || tag == TAG_Move || tag == TAG_Replace;
  V f = heff_dup(heff_field(p, tag == TAG_WriteFile || two ? 2 : 1));
  FsPath ps[2] = { { NULL, NULL }, { NULL, NULL } };
  FsWhy why = { 0, NULL, NULL };
  V r = 0;
  if (!fs_path(&ps[0], heff_field(p, 0))) r = fs_invalid(heff_field(p, 0));
  else if (two && !fs_path(&ps[1], heff_field(p, 1))) r = fs_invalid(heff_field(p, 1));
  else {
    char *path = ps[0].full, *to = ps[1].full;
    V got;
    switch (tag) {
    case TAG_ReadFile:
      if (heff_read_file(path, &got, &why)) r = fs_right(got);
      break;
    case TAG_WriteFile:
      if (heff_write_file(path, heff_field(p, 1), &why)) r = fs_done();
      break;
    case TAG_MakeDirectory:
      if (heff_mkdir_p(path, &why)) r = fs_done();
      break;
    case TAG_ReadDirectory:
      if (heff_read_dir(path, &got, &why)) r = fs_right(got);
      break;
    case TAG_Remove:
      errno = 0;
      if (heff_chmod_all(path, 1, &why) != 0 && heff_remove_all(path, &why)) r = fs_done();
      break;
    case TAG_ReadOnly:
    case TAG_Writable: {
      errno = 0;
      int c = heff_chmod_all(path, tag == TAG_Writable, &why);
      if (c == 1) r = fs_done();
      else if (c == -1) fs_fail2(&why, path, NULL, ENOENT);
      break;
    }
    case TAG_Copy:
      errno = 0;
      if (heff_free_at(to, &why) && heff_copy_all(path, to, &why)) r = fs_done();
      break;
    case TAG_Move:
      if (heff_free_at(to, &why)) {
        errno = 0;
        if (rename(path, to) == 0) r = fs_done();
        else fs_fail2(&why, path, to, 0);
      }
      break;
    case TAG_Replace:
      // (rename(2) puts a file in place of another at once; Windows' does
      // not over one there, MoveFileEx does)
      errno = 0;
#ifdef _WIN32
      if (MoveFileExA(path, to, MOVEFILE_REPLACE_EXISTING) != 0) r = fs_done();
#else
      if (rename(path, to) == 0) r = fs_done();
#endif
      else fs_fail2(&why, path, to, 0);
      break;
    default:
      heff_fail("not an operation of filesystem");
      return 0;
    }
    if (!r) r = fs_failed(&why, ps, two ? 2 : 1);
  }
  heff_drop(p);
  fs_path_free(&ps[0]);
  fs_path_free(&ps[1]);
  V x = heff_answer(f, r);
  return heff_tail(k, 1, &x);
}

// What a file is
// ---------------------------------------------------------------------

#ifndef EWOULDBLOCK
#define EWOULDBLOCK EAGAIN
#endif
#ifdef _WIN32
// (nothing is polled on Windows: an op is done there and then)
#ifndef POLLIN
#define POLLIN 1
#define POLLOUT 4
#endif
#ifndef O_CLOEXEC
#define O_CLOEXEC 0
#endif
#else
#ifndef O_BINARY
#define O_BINARY 0
#endif
#endif

static uint32_t fs_status_shape[4] = { LBL_kind, LBL_size, LBL_modified, LBL_mode };

// (`Right` what the system says of a file, stat's `st`)
static V fs_status(const struct stat *st) {
  int kind = S_ISREG(st->st_mode) ? TAG_Regular
           : S_ISDIR(st->st_mode) ? TAG_Directory
           : S_ISLNK(st->st_mode) ? TAG_Link
           : TAG_Other;
#if defined(__APPLE__)
  int64_t s = (int64_t)st->st_mtimespec.tv_sec, ns = (int64_t)st->st_mtimespec.tv_nsec;
#elif defined(_WIN32)
  int64_t s = (int64_t)st->st_mtime, ns = 0;
#else
  int64_t s = (int64_t)st->st_mtim.tv_sec, ns = (int64_t)st->st_mtim.tv_nsec;
#endif
  V f[4] = { NTAG(kind), heff_int((int64_t)st->st_size), heff_int(s * 1000000000 + ns),
             heff_int((int64_t)(st->st_mode & 07777)) };
  return fs_right(heff_rec(4, fs_status_shape, f));
}

// (a number given as an `Int`, at `*n`: whether it is one of a word)
static int fs_int(V v, int64_t *n) {
  if (!IS_INT(v)) return 0;
  *n = INT_OF(v);
  return 1;
}

// Open files
// ---------------------------------------------------------------------

// (this provider's open files, told from what other providers hand out)
#define FS_MAGIC 0x66696c65u
// (how much is read ahead at a time; a chunk's most)
#define FS_BUF ((size_t)65536)
#define FS_READ_MAX ((int64_t)16 << 20)

typedef struct {
  uint32_t magic;
  int fd;            // (-1 once closed)
  int refs;          // (each foreign value's that is it, each op's that
                     //  has it; and a standard stream's own)
  int standard;      // (a standard stream's number, 0 to 2: never closed;
                     //  else -1)
  int pollable;      // (a pipe, a terminal, a socket: polled, where a
                     //  scheduler runs)
  int seekable;      // (a regular file: what was read ahead is given back
                     //  before a write)
  uint8_t *buf;      // (read ahead: what is not yet taken, from `at` to
  size_t cap, at, end;  //  `end`)
  uint64_t taken;    // (how many times something was taken from it)
  int port;          // (a port of its own on standard stream `port - 1`:
                     //  what that one read ahead given to it, and back
                     //  as it is closed; 0 for none)
  char *path;        // (the path it was opened by, as the program wrote
                     //  it, a failure's; a standard stream's, `<stdin>`)
} FsFile;

// (the standard streams' files, once asked for: one each, kept, so
// that what one `with` read ahead is the next one's too)
static FsFile *fs_standard[3];

static void fs_unref(FsFile *h) {
  if (--h->refs > 0) return;
  free(h->buf);
  free(h->path);
  h->magic = 0;
  free(h);
}

// (the program's last reference to it dropped: closed, unless the
// `with` closed it or it is a standard stream, which stays open)
static void fs_let_go(void *x) {
  FsFile *h = x;
  if (h->standard < 0 && h->fd >= 0) {
    close(h->fd);
    h->fd = -1;
  }
  fs_unref(h);
}

// (the file of `fd`, opened by `path`, taken)
static FsFile *fs_new(int fd, int standard, char *path) {
  FsFile *h = heff_alloc(sizeof *h);
  memset(h, 0, sizeof *h);
  h->magic = FS_MAGIC;
  h->fd = fd;
  h->path = path;
  h->refs = standard >= 0;  // (a standard stream's own: kept)
  h->standard = standard;
  struct stat st;
  if (fstat(fd, &st) == 0) {
    h->seekable = S_ISREG(st.st_mode);
#ifndef _WIN32
    h->pollable = S_ISFIFO(st.st_mode) || S_ISCHR(st.st_mode) || S_ISSOCK(st.st_mode);
#endif
  }
  return h;
}

// (the file as the program holds it: a foreign value, counted by `h`)
static V fs_value(FsFile *h) {
  h->refs++;
  return heff_foreign(h, fs_let_go);
}

// (the file a foreign value is, or the program failed: it is none)
static FsFile *fs_file(V v) {
  FsFile *h = heff_foreign_ptr(v);
  if (h->magic != FS_MAGIC) heff_fail("std.filesystem: no open file");
  return h;
}

static size_t fs_buffered(FsFile *h) { return h->end - h->at; }

// (`Left` why an operation of the file failed, errno `err`)
static V fs_left_file(FsFile *h, int err) { return fs_left_at(err, h->path); }

// (room for `n` more bytes after what is read ahead: what is taken let
// go of, the buffer grown)
static void fs_room(FsFile *h, size_t n) {
  if (h->at == h->end) h->at = h->end = 0;
  if (h->cap - h->end >= n) return;
  if (h->at > 0) {
    memmove(h->buf, h->buf + h->at, h->end - h->at);
    h->end -= h->at;
    h->at = 0;
  }
  if (h->cap - h->end >= n) return;
  size_t cap = h->cap ? h->cap : FS_BUF;
  while (cap - h->end < n) cap *= 2;
  uint8_t *b = heff_alloc(cap);
  if (h->end) memcpy(b, h->buf, h->end);
  free(h->buf);
  h->buf = b;
  h->cap = cap;
}

// (what was read ahead given back, where the file is a regular one, so
// that a write is where the program has read up to: 0, or -1 with
// errno)
static int fs_unread(FsFile *h) {
  size_t n = fs_buffered(h);
  if (!n || !h->seekable) return 0;
#ifdef _WIN32
  if (_lseeki64(h->fd, -(int64_t)n, SEEK_CUR) < 0) return -1;
#else
  if (lseek(h->fd, -(off_t)n, SEEK_CUR) < 0) return -1;
#endif
  h->at = h->end = 0;
  h->taken++;
  return 0;
}

// (whether `fd` is ready for `events` now, not waiting: 1, 0, or -1
// with errno)
static int fs_ready(int fd, short events) {
#ifdef _WIN32
  (void)fd;
  (void)events;
  return 1;
#else
  struct pollfd p = { fd, events, 0 };
  int r;
  do r = poll(&p, 1, 0); while (r < 0 && errno == EINTR);
  return r < 0 ? -1 : r > 0;
#endif
}

// (`fd` waited for here, the whole program waiting: one another made
// non-blocking, not ready)
static void fs_wait_here(int fd, short events) {
#ifdef _WIN32
  (void)fd;
  (void)events;
#else
  struct pollfd p = { fd, events, 0 };
  while (poll(&p, 1, -1) < 0 && errno == EINTR) {}
#endif
}

// An operation, in steps
// ---------------------------------------------------------------------

enum { FS_CHUNK, FS_LINE, FS_WRITE };

typedef struct {
  HeffWait w;        // (first: an op is its wait; its `fd` the file's)
  int what;
  FsFile *h;         // (counted: the op's while it is)
  int err;           // (errno, where it failed)
  int async;         // (polled before each read and write, waiting in the
                     //  reactor until it is ready: a scheduler runs, and
                     //  the file is pollable)
  int eof;           // (a read came to the end)
  int64_t n;         // (a chunk's most)
  size_t scanned;    // (a line's: how far after `h->at` no newline is,
  uint64_t taken;    //  while `h->taken` is this)
  const uint8_t *data;  // (a write's bytes, `len` of them, `done` written)
  int64_t len, done;
  V held;            // (the operation, which holds the file, and a
                     //  write's bytes)
  char *owned;       // (or a copy of them, a string's)
  V result;          // (its answer, once it is done and did not fail)
} FsOp;

static FsOp *fs_op(int what, FsFile *h) {
  FsOp *o = heff_alloc(sizeof *o);
  memset(o, 0, sizeof *o);
  o->what = what;
  o->h = h;
  h->refs++;
  o->w.fd = h->fd;
  o->w.events = POLLIN;
#ifndef _WIN32
  o->async = heff_group != 0 && h->pollable;
#endif
  o->taken = h->taken;
  return o;
}

static void fs_op_free(FsOp *o) {
  if (o->result) heff_drop(o->result);
  if (o->held) heff_drop(o->held);
  free(o->owned);
  fs_unref(o->h);
  free(o);
}

// (up to `n` bytes read into `dst`: how many, 0 at the end, or -1 with
// errno -- EAGAIN, for an async op, where it is not ready)
static ssize_t fs_read_into(FsOp *o, uint8_t *dst, size_t n) {
  int fd = o->h->fd;
  for (;;) {
    if (o->async) {
      int r = fs_ready(fd, POLLIN);
      if (r < 0) return -1;
      if (r == 0) {
        errno = EAGAIN;
        return -1;
      }
    }
#ifdef _WIN32
    ssize_t r = read(fd, dst, (unsigned)n);
#else
    ssize_t r = read(fd, dst, n);
#endif
    if (r >= 0) return r;
    if (errno == EINTR) continue;
    if ((errno == EAGAIN || errno == EWOULDBLOCK) && !o->async) {
      fs_wait_here(fd, POLLIN);
      continue;
    }
    if (errno == EWOULDBLOCK) errno = EAGAIN;
    return -1;
  }
}

// (more read ahead, as much as there is room for, a buffer's at least:
// as `fs_read_into`)
static ssize_t fs_fill(FsOp *o) {
  FsFile *h = o->h;
  fs_room(h, FS_BUF);
  ssize_t r = fs_read_into(o, h->buf + h->end, h->cap - h->end);
  if (r > 0) h->end += (size_t)r;
  return r;
}

// (`n` bytes taken from what was read ahead)
static V fs_take(FsFile *h, size_t n) {
  V b = heff_bytes_in(h->buf + h->at, (int64_t)n);
  h->at += n;
  h->taken++;
  return b;
}

// (a step's end where a read failed: waiting, where it is not ready)
static int fs_failed_step(FsOp *o) {
  if (o->async && errno == EAGAIN) {
    o->w.events = POLLIN;
    return HEFF_STEP_WAIT;
  }
  o->err = errno;
  return HEFF_STEP_DONE;
}

// A chunk: what was read ahead, or read now -- straight into bytes of
// its own where as many as a buffer's are asked for.
static int fs_chunk_step(HeffWait *w) {
  FsOp *o = (FsOp *)w;
  FsFile *h = o->h;
  if (fs_buffered(h) == 0 && (size_t)o->n >= FS_BUF) {
    uint8_t *mine = heff_alloc((size_t)o->n);
    ssize_t r = fs_read_into(o, mine, (size_t)o->n);
    if (r < 0) {
      int e = errno;
      free(mine);
      errno = e;
      return fs_failed_step(o);
    }
    o->result = fs_right(heff_bytes_in(mine, (int64_t)r));
    free(mine);
    return HEFF_STEP_DONE;
  }
  if (fs_buffered(h) == 0 && fs_fill(o) < 0) return fs_failed_step(o);
  size_t n = fs_buffered(h);
  if (n > (size_t)o->n) n = (size_t)o->n;
  o->result = fs_right(n ? fs_take(h, n) : heff_bytes_in("", 0));
  return HEFF_STEP_DONE;
}

// (`Right (Just` the line of `n` bytes from what was read ahead`)`, its
// newline -- `nl` bytes, and a `\r` before it -- taken, left out)
static V fs_take_line(FsFile *h, size_t n, size_t nl) {
  const uint8_t *s = h->buf + h->at;
  size_t len = n;
  if (nl && len > 0 && s[len - 1] == '\r') len--;
  V line = heff_str_bytes(s, (int64_t)len);
  h->at += n + nl;
  h->taken++;
  return fs_right(heff_just(line));
}

// A line: what was read ahead looked through for a newline, more read
// until there is one or the file has ended.
static int fs_line_step(HeffWait *w) {
  FsOp *o = (FsOp *)w;
  FsFile *h = o->h;
  for (;;) {
    if (o->taken != h->taken) {
      // (another op took from it meanwhile: looked through anew)
      o->scanned = 0;
      o->taken = h->taken;
    }
    size_t have = fs_buffered(h);
    if (have > o->scanned) {
      const uint8_t *s = h->buf + h->at;
      const uint8_t *nl = memchr(s + o->scanned, '\n', have - o->scanned);
      if (nl) {
        o->result = fs_take_line(h, (size_t)(nl - s), 1);
        return HEFF_STEP_DONE;
      }
    }
    o->scanned = have;
    if (o->eof) {
      o->result = have ? fs_take_line(h, have, 0) : fs_right(heff_nothing);
      return HEFF_STEP_DONE;
    }
    ssize_t r = fs_fill(o);
    if (r < 0) return fs_failed_step(o);
    if (r == 0) o->eof = 1;
  }
}

// A write: all of it -- where it is polled, no more than PIPE_BUF bytes
// at a time, each once poll says there is room.
static int fs_write_step(HeffWait *w) {
  FsOp *o = (FsOp *)w;
  int fd = o->h->fd;
  while (o->done < o->len) {
    size_t n = (size_t)(o->len - o->done);
#ifndef _WIN32
    if (o->async) {
      int r = fs_ready(fd, POLLOUT);
      if (r < 0) {
        o->err = errno;
        return HEFF_STEP_DONE;
      }
      if (r == 0) {
        w->events = POLLOUT;
        return HEFF_STEP_WAIT;
      }
      if (n > PIPE_BUF) n = PIPE_BUF;
    }
    ssize_t r = write(fd, o->data + o->done, n);
#else
    ssize_t r = write(fd, o->data + o->done, (unsigned)n);
#endif
    if (r >= 0) {
      o->done += r;
      continue;
    }
    if (errno == EINTR) continue;
    if (errno == EAGAIN || errno == EWOULDBLOCK) {
      if (o->async) {
        w->events = POLLOUT;
        return HEFF_STEP_WAIT;
      }
      fs_wait_here(fd, POLLOUT);
      continue;
    }
    o->err = errno;
    return HEFF_STEP_DONE;
  }
  o->result = fs_done();
  return HEFF_STEP_DONE;
}

static V fs_answer(HeffWait *w) {
  FsOp *o = (FsOp *)w;
  // (why waiting failed, where it did -- its file closed meanwhile,
  // EBADF -- or why the op did)
  int err = w->err ? w->err : o->err;
  V r;
  if (err) r = fs_left_file(o->h, err);
  else {
    r = o->result;
    o->result = 0;
  }
  fs_op_free(o);
  return r;
}

static void fs_cancel(HeffWait *w) { fs_op_free((FsOp *)w); }

// (the op, its first step taken: done, its answer given to `k`; or
// waited for by the reactor -- `heff_outside`)
static V fs_go(FsOp *o, int (*step)(HeffWait *), V f, V k) {
  o->w.step = step;
  o->w.answer = fs_answer;
  o->w.cancel = fs_cancel;
  if (step(&o->w) == HEFF_STEP_WAIT) return heff_outside(&o->w, f, k);
  V x = heff_answer(f, fs_answer(&o->w));
  return heff_tail(k, 1, &x);
}

// (`len` bytes at `data` written to `h`: held by `held`, or `owned`)
static V fs_write(FsFile *h, const uint8_t *data, int64_t len, V held, char *owned, V f, V k) {
  // (what std.io wrote before it, first; and what was read ahead given
  // back)
  if (h->standard == 1 || h->standard == 2 || h->port == 2 || h->port == 3) fflush(stdout);
  if (h->standard == 2 || h->port == 3) fflush(stderr);
  if (fs_unread(h) < 0) {
    int e = errno;
    if (held) heff_drop(held);
    free(owned);
    V x = heff_answer(f, fs_left_file(h, e));
    return heff_tail(k, 1, &x);
  }
  FsOp *o = fs_op(FS_WRITE, h);
  o->w.events = POLLOUT;
  o->data = data;
  o->len = len;
  o->held = held;
  o->owned = owned;
  return fs_go(o, fs_write_step, f, k);
}

// Paths
// ---------------------------------------------------------------------

// (where the system keeps temporary files, no separator after it)
static void fs_temp_root(char *buf, size_t n) {
#ifdef _WIN32
  DWORD m = GetTempPathA((DWORD)n, buf);
  if (m == 0 || m >= n) snprintf(buf, n, ".");
#else
  const char *t = getenv("TMPDIR");
  snprintf(buf, n, "%s", t && *t ? t : "/tmp");
#endif
  size_t len = strlen(buf);
  while (len > 1 && heff_is_sep(buf[len - 1])) buf[--len] = 0;
}

static uint64_t fs_seed;

// (six letters, a temporary name's, hardly ever the same twice)
static void fs_letters(char *out) {
  uint64_t x = fs_seed ^ ((uint64_t)time(NULL) * 0x9e3779b97f4a7c15ULL) ^ (uint64_t)clock()
             ^ ((uint64_t)getpid() << 32) ^ (uint64_t)(uintptr_t)out;
#ifndef _WIN32
  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);
  x ^= (uint64_t)ts.tv_nsec * 0xbf58476d1ce4e5b9ULL;
#endif
  fs_seed = x * 6364136223846793005ULL + 1442695040888963407ULL;
  uint64_t y = fs_seed;
  y = (y ^ (y >> 30)) * 0xbf58476d1ce4e5b9ULL;
  y = (y ^ (y >> 27)) * 0x94d049bb133111ebULL;
  y ^= y >> 31;
  static const char abc[] = "abcdefghijklmnopqrstuvwxyz0123456789";
  for (int i = 0; i < 6; i++) {
    out[i] = abc[y % 36];
    y /= 36;
  }
  out[6] = 0;
}

// (a new temporary directory, or file -- made, empty, closed -- its name
// `prefix` and six letters: its path)
static V fs_temp(V prefix, int file) {
  char *pre = heff_cstr(prefix);
  if (!pre) return fs_invalid(prefix);
  char root[4096];
  fs_temp_root(root, sizeof root);
  size_t n = strlen(root) + strlen(pre) + 9;
  char *path = heff_alloc(n);
  V r = 0;
  for (int tries = 0; tries < 100 && !r; tries++) {
    char six[7];
    fs_letters(six);
#ifdef _WIN32
    snprintf(path, n, "%s\\%s%s", root, pre, six);
#else
    snprintf(path, n, "%s/%s%s", root, pre, six);
#endif
    if (!file) {
#ifdef _WIN32
      int made = mkdir(path) == 0;
#else
      int made = mkdir(path, 0700) == 0;
#endif
      if (made) r = fs_right(heff_str_bytes(path, (int64_t)strlen(path)));
      else if (errno != EEXIST) r = fs_left_at(errno, path);
    } else {
      int fd = open(path, O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_BINARY, 0600);
      if (fd >= 0) {
        close(fd);
        r = fs_right(heff_str_bytes(path, (int64_t)strlen(path)));
      } else if (errno != EEXIST) r = fs_left_at(errno, path);
    }
  }
  if (!r) r = fs_left_at(EEXIST, path);
  free(pre);
  free(path);
  return r;
}

// (`p` with its links resolved: `Right` it, or `Left` why not)
static V fs_real_path(const FsPath *p) {
  const char *path = p->full;
#ifdef _WIN32
  struct stat st;
  if (stat(path, &st) != 0) return fs_left_at(errno, p->given);
  char *r = _fullpath(NULL, path, 0);
#else
  char *r = realpath(path, NULL);
#endif
  if (!r) return fs_left_at(errno, p->given);
  V s = heff_str_bytes(r, (int64_t)strlen(r));
  free(r);
  return fs_right(s);
}

// (what the link at `path` says, as it was written: `Right` it, or
// `Left` why not -- not a link, EINVAL; on Windows, where links are not
// seen, EINVAL)
static V fs_read_link(const FsPath *p) {
#ifdef _WIN32
  return fs_left_at(EINVAL, p->given);
#else
  size_t cap = 256;
  for (;;) {
    char *b = heff_alloc(cap);
    ssize_t n = readlink(p->full, b, cap);
    if (n < 0) {
      int err = errno;
      free(b);
      return fs_left_at(err, p->given);
    }
    if ((size_t)n < cap) {
      V s = heff_str_bytes(b, (int64_t)n);
      free(b);
      return fs_right(s);
    }
    free(b);
    cap *= 2;
  }
#endif
}

// (`p`'s mode set: `Right MkUnit`, or `Left` why not)
static V fs_set_mode(const FsPath *p, int64_t mode) {
  const char *path = p->full;
#ifdef _WIN32
  int r = chmod(path, (mode & 0200) ? (_S_IREAD | _S_IWRITE) : _S_IREAD);
#else
  int r = chmod(path, (mode_t)(mode & 07777));
#endif
  return r == 0 ? fs_done() : fs_left_at(errno, p->given);
}

// (`p` opened as `OpenPath` says: `Right` the file, the host's own;
// or `Left` why not -- a directory's, EISDIR)
static V fs_open(const FsPath *p, int64_t access, int create, int truncate, int exclusive, int64_t mode) {
  const char *path = p->full;
  // (0 read, 1 write, 2 append, 3 read and write, 4 read and append)
  int flags = access == 0 ? O_RDONLY
            : access == 1 ? O_WRONLY
            : access == 2 ? (O_WRONLY | O_APPEND)
            : access == 3 ? O_RDWR
                          : (O_RDWR | O_APPEND);
  if (create) flags |= O_CREAT;
  if (truncate) flags |= O_TRUNC;
  if (exclusive) flags |= O_CREAT | O_EXCL;
  flags |= O_CLOEXEC | O_BINARY;
  int fd;
  do fd = open(path, flags, (int)(mode & 07777)); while (fd < 0 && errno == EINTR);
  if (fd < 0) return fs_left_at(errno, p->given);
  struct stat st;
  if (fstat(fd, &st) == 0 && S_ISDIR(st.st_mode)) {
    close(fd);
    return fs_left_at(EISDIR, p->given);
  }
  return fs_right(fs_value(fs_new(fd, -1, heff_strdup(p->given))));
}

// (a file closed, but a standard stream: what waits on it told so, not
// polled closed; errno, where it failed.  Done once: closed, the file's
// operations are `EBADF`, and letting it go frees only what holds it)
static int fs_close(FsFile *h) {
  int err = 0;
  if (h->port && h->fd >= 0) {
    FsFile *s = fs_standard[h->port - 1];
    if (s && !s->buf) {
      s->buf = h->buf; s->cap = h->cap; s->at = h->at; s->end = h->end;
      h->buf = NULL; h->cap = h->at = h->end = 0;
    }
  }
  if (h->standard < 0 && h->fd >= 0) {
    heff_reactor_closing(h->fd);
    if (close(h->fd) != 0 && errno != EINTR) err = errno;
    h->fd = -1;
  }
  return err;
}

// The operations
// ---------------------------------------------------------------------

// (`x` given to the function at field `at` of `p`, its answer to `k`;
// `p` let go of)
static V fs_answered(V p, int at, V x, V k) {
  V f = heff_dup(heff_field(p, at));
  heff_drop(p);
  V y = heff_answer(f, x);
  return heff_tail(k, 1, &y);
}

// (a path given to the system is from this thread's directory, which
// is the thread's own, not the process's)
static V heff_provider_filesystem(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_PathStatus: {
    FsPath path;
    int follow = heff_field(p, 1) == NTAG(TAG_True);
    V r;
    if (!fs_path(&path, heff_field(p, 0))) r = fs_invalid(heff_field(p, 0));
    else {
      struct stat st;
      int s = follow ? stat(path.full, &st) : lstat(path.full, &st);
      r = s == 0 ? fs_status(&st) : fs_left_at(errno, path.given);
    }
    fs_path_free(&path);
    return fs_answered(p, 2, r, k);
  }
  case TAG_SetMode: {
    FsPath path;
    int64_t mode;
    V r = !fs_path(&path, heff_field(p, 0)) ? fs_invalid(heff_field(p, 0))
        : !fs_int(heff_field(p, 1), &mode) ? fs_left_at(EINVAL, path.given)
        : fs_set_mode(&path, mode);
    fs_path_free(&path);
    return fs_answered(p, 2, r, k);
  }
  case TAG_RealPath: {
    FsPath path;
    V r = fs_path(&path, heff_field(p, 0)) ? fs_real_path(&path) : fs_invalid(heff_field(p, 0));
    fs_path_free(&path);
    return fs_answered(p, 1, r, k);
  }
  case TAG_ReadLink: {
    FsPath path;
    V r = fs_path(&path, heff_field(p, 0)) ? fs_read_link(&path) : fs_invalid(heff_field(p, 0));
    fs_path_free(&path);
    return fs_answered(p, 1, r, k);
  }
  case TAG_TemporaryDirectory:
    return fs_answered(p, 1, fs_temp(heff_field(p, 0), 0), k);
  case TAG_TemporaryFile:
    return fs_answered(p, 1, fs_temp(heff_field(p, 0), 1), k);
  case TAG_OpenPath: {
    FsPath path;
    int64_t access, mode;
    V r;
    if (!fs_path(&path, heff_field(p, 0))) r = fs_invalid(heff_field(p, 0));
    else if (!fs_int(heff_field(p, 1), &access) || !fs_int(heff_field(p, 5), &mode))
      r = fs_left_at(EINVAL, path.given);
    else
      r = fs_open(&path, access, heff_field(p, 2) == NTAG(TAG_True), heff_field(p, 3) == NTAG(TAG_True),
                  heff_field(p, 4) == NTAG(TAG_True), mode);
    fs_path_free(&path);
    return fs_answered(p, 6, r, k);
  }
  case TAG_Standard: {
    static const char *const names[3] = { "<stdin>", "<stdout>", "<stderr>" };
    int64_t i = INT_OF(heff_field(p, 0));
    if (i < 0 || i > 2) heff_fail("std.filesystem: no such standard stream");
    if (!fs_standard[i]) fs_standard[i] = fs_new((int)i, (int)i, heff_strdup(names[i]));
    return fs_answered(p, 1, fs_value(fs_standard[i]), k);
  }
  // (a port of its own on a standard stream: its descriptor a copy of
  // the stream's, closed as the port is, the stream left open; what the
  // stream read ahead its, until then)
  case TAG_StandardPort: {
    static const char *const names[3] = { "<stdin>", "<stdout>", "<stderr>" };
    int64_t i = INT_OF(heff_field(p, 0));
    if (i < 0 || i > 2) heff_fail("std.filesystem: no such standard stream");
    if (!fs_standard[i]) fs_standard[i] = fs_new((int)i, (int)i, heff_strdup(names[i]));
    int fd = dup((int)i);
    if (fd < 0) heff_fail("std.filesystem: a standard stream not duplicated");
    FsFile *s = fs_standard[i];
    // (what the stream is, as its own file found once: no `fstat` again)
    FsFile *h = heff_alloc(sizeof *h);
    memset(h, 0, sizeof *h);
    h->magic = FS_MAGIC;
    h->fd = fd;
    h->path = heff_strdup(names[i]);
    h->standard = -1;
    h->seekable = s->seekable;
    h->pollable = s->pollable;
    h->port = (int)i + 1;
    h->buf = s->buf; h->cap = s->cap; h->at = s->at; h->end = s->end;
    s->buf = NULL; s->cap = s->at = s->end = 0;
    return fs_answered(p, 1, fs_value(h), k);
  }
  // (an operation of an open file: one that waits keeps `p`, and so the
  // file, while it does, so that it is not let go of under it; after the
  // `with` closed the file, each is `EBADF`)
  case TAG_ReadChunk: {
    FsFile *h = fs_file(heff_field(p, 0));
    if (h->fd < 0) return fs_answered(p, 2, fs_left_file(h, EBADF), k);
    int64_t n;
    if (!fs_int(heff_field(p, 1), &n)) n = FS_READ_MAX;
    V f = heff_dup(heff_field(p, 2));
    if (n <= 0) {
      heff_drop(p);
      V x = heff_answer(f, fs_right(heff_bytes_in("", 0)));
      return heff_tail(k, 1, &x);
    }
    FsOp *o = fs_op(FS_CHUNK, h);
    o->n = n > FS_READ_MAX ? FS_READ_MAX : n;
    o->held = p;
    return fs_go(o, fs_chunk_step, f, k);
  }
  case TAG_ReadLine: {
    FsFile *h = fs_file(heff_field(p, 0));
    if (h->fd < 0) return fs_answered(p, 1, fs_left_file(h, EBADF), k);
    V f = heff_dup(heff_field(p, 1));
    FsOp *o = fs_op(FS_LINE, h);
    o->held = p;
    return fs_go(o, fs_line_step, f, k);
  }
  case TAG_WriteBytes: {
    FsFile *h = fs_file(heff_field(p, 0));
    if (h->fd < 0) return fs_answered(p, 2, fs_left_file(h, EBADF), k);
    V f = heff_dup(heff_field(p, 2));
    int64_t n;
    // (the bytes are `p`'s, held until they are written)
    const uint8_t *data = heff_bytes_data(heff_field(p, 1), &n);
    return fs_write(h, data, n, p, NULL, f, k);
  }
  case TAG_WriteString: {
    FsFile *h = fs_file(heff_field(p, 0));
    if (h->fd < 0) return fs_answered(p, 2, fs_left_file(h, EBADF), k);
    V f = heff_dup(heff_field(p, 2));
    size_t n;
    char *data = heff_bytes(heff_field(p, 1), &n);
    return fs_write(h, (const uint8_t *)data, (int64_t)n, p, data, f, k);
  }
  case TAG_Seek: {
    FsFile *h = fs_file(heff_field(p, 0));
    int64_t from, n;
    V r;
    if (h->fd < 0) r = fs_left_file(h, EBADF);
    else if (!fs_int(heff_field(p, 1), &from) || !fs_int(heff_field(p, 2), &n)) r = fs_left_file(h, EINVAL);
    else {
      // (from where the program has read up to, not where the file was
      // read ahead to)
      if (from == 1) n -= (int64_t)fs_buffered(h);
      int whence = from == 0 ? SEEK_SET : from == 1 ? SEEK_CUR : SEEK_END;
#ifdef _WIN32
      int64_t at = _lseeki64(h->fd, n, whence);
#else
      int64_t at = (int64_t)lseek(h->fd, (off_t)n, whence);
#endif
      if (at < 0) r = fs_left_file(h, errno);
      else {
        h->at = h->end = 0;
        h->taken++;
        r = fs_right(heff_int(at));
      }
    }
    return fs_answered(p, 3, r, k);
  }
  case TAG_FileStatus: {
    FsFile *h = fs_file(heff_field(p, 0));
    if (h->fd < 0) return fs_answered(p, 1, fs_left_file(h, EBADF), k);
    struct stat st;
    V r = fstat(h->fd, &st) == 0 ? fs_status(&st) : fs_left_file(h, errno);
    return fs_answered(p, 1, r, k);
  }
  case TAG_CloseFile: {
    FsFile *h = fs_file(heff_field(p, 0));
    int err = fs_close(h);
    return fs_answered(p, 1, err ? fs_left_file(h, err) : fs_done(), k);
  }
  default:
    return heff_fs_whole(p, k);
  }
}

// The terminal's side of heff.lsp.report, for the C backend: an
// effect provider.

#include <unistd.h>

// (colour on the stream `fd`: it is a terminal, or `HEFF_TTY=1` says it
// is, and `NO_COLOR` is not set)
static int heff_report_color(int fd) {
  const char *tty = getenv("HEFF_TTY"), *no = getenv("NO_COLOR");
  return (isatty(fd) || (tty && tty[0] == '1' && !tty[1])) && !(no && no[0]);
}

static V heff_provider_report(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_UseColor:
  case TAG_ErrColor: {
    int fd = heff_tag_of(p) == TAG_UseColor ? 1 : 2;
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_bool(heff_report_color(fd)));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of report");
    return 0;
  }
}

// The client's side of heff.lsp.rpc, for the C backend: JSON-RPC over
// stdio, as the Language Server Protocol frames it -- each message a
// `Content-Length: n` header, a blank line, then n bytes of JSON; stdout
// carries only the messages, logs go to stderr -- and what of the host a
// language server asks for.  A message is given as its body, its JSON
// read in heff.  Its strings are text, a host of text's --
// a message's body, and the paths and URIs a client names, or that are
// made of them (`heff_str_text`, `heff_cstr_text`) -- but for what it
// sends and logs, which is written out as it is (`heff_bytes`,
// `heff_put`).

#include <dirent.h>
#ifndef _WIN32
#include <poll.h>
#endif
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#ifdef _WIN32
#define lstat stat
#endif

// The messages, read from stdin
// ---------------------------------------------------------------------

static Buf rpc_in;
static int rpc_closed;

// (the next message's body, if a whole one is read: malloc'd)
static char *rpc_take(size_t *len) {
  for (;;) {
    char *sep = NULL;
    for (size_t i = 0; i + 4 <= rpc_in.n; i++)
      if (memcmp(rpc_in.s + i, "\r\n\r\n", 4) == 0) { sep = rpc_in.s + i; break; }
    if (!sep) return NULL;
    size_t head = (size_t)(sep - rpc_in.s), start = head + 4;
    long n = -1;
    for (size_t i = 0; i + 15 <= head; i++)
      if (strncasecmp(rpc_in.s + i, "Content-Length:", 15) == 0) {
        size_t k = i + 15;
        while (k < head && (rpc_in.s[k] == ' ' || rpc_in.s[k] == '\t')) k++;
        if (k < head && rpc_in.s[k] >= '0' && rpc_in.s[k] <= '9') {
          n = 0;
          while (k < head && rpc_in.s[k] >= '0' && rpc_in.s[k] <= '9') n = n * 10 + (rpc_in.s[k++] - '0');
        }
        break;
      }
    if (n < 0) {
      memmove(rpc_in.s, rpc_in.s + start, rpc_in.n - start);
      rpc_in.n -= start;
      continue;
    }
    if (rpc_in.n < start + (size_t)n) return NULL;
    char *body = heff_alloc((size_t)n + 1);
    memcpy(body, rpc_in.s + start, (size_t)n);
    body[n] = 0;
    memmove(rpc_in.s, rpc_in.s + start + n, rpc_in.n - start - n);
    rpc_in.n -= start + n;
    *len = (size_t)n;
    return body;
  }
}

static int64_t rpc_now(void) {
  struct timespec t;
  clock_gettime(CLOCK_REALTIME, &t);
  return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}

// (whether stdin has something to read within `wait` ms (none, below
// 0): 1 if so, 0 if not, below 0 if waiting failed)
static int rpc_ready(int wait) {
#ifdef _WIN32
  // (a pipe, as an editor gives it, is looked into until it has bytes;
  // what is not a pipe is read, waiting there)
  HANDLE h = GetStdHandle(STD_INPUT_HANDLE);
  int64_t until = rpc_now() + wait;
  for (;;) {
    DWORD avail = 0;
    if (!PeekNamedPipe(h, NULL, 0, NULL, &avail, NULL) || avail > 0) return 1;
    if (wait >= 0 && rpc_now() >= until) return 0;
    Sleep(5);
  }
#else
  struct pollfd fd = { 0, POLLIN, 0 };
  return poll(&fd, 1, wait);
#endif
}

// (the next event: a message's body (its JSON is read by rpc.hf), the
// time waited for, `ms`, passing first (none, below 0), or the client
// gone)
static V rpc_await(int64_t ms) {
  int64_t until = rpc_now() + ms;
  for (;;) {
    size_t n;
    char *body = rpc_take(&n);
    if (body) {
      V v = heff_str_text_n(body, (int64_t)n);
      free(body);
      return heff_tag(TAG_Arrived, 1, &v);
    }
    if (rpc_closed) return NTAG(TAG_Gone);
    int wait = -1;
    if (ms >= 0) {
      int64_t left = until - rpc_now();
      if (left <= 0) return NTAG(TAG_Waited);
      wait = left > 0x7fffffff ? 0x7fffffff : (int)left;
    }
    int r = rpc_ready(wait);
    if (r == 0) return NTAG(TAG_Waited);
    if (r < 0) continue;
    char chunk[65536];
    ssize_t got = read(0, chunk, sizeof chunk);
    if (got <= 0) rpc_closed = 1;
    else buf_put(&rpc_in, chunk, (size_t)got);
  }
}

// Paths and URIs
// ---------------------------------------------------------------------

// (a path made absolute against the working directory, its `.`, `..`
// and repeated separators resolved, as Node.js's path.resolve: malloc'd;
// on Windows a path starts with its drive, `C:`, and its separator is
// `\\`, though `/` is read as one too)
#ifdef _WIN32
#define RPC_SEP '\\'
#define rpc_is_sep(c) ((c) == '/' || (c) == '\\')
#else
#define RPC_SEP '/'
#define rpc_is_sep(c) ((c) == '/')
#endif

static char *rpc_resolve(const char *p) {
  Buf b = {0};
  const char *cwd = heff_working_dir();
#ifdef _WIN32
  int drive = p[0] && p[1] == ':';
  if (drive && rpc_is_sep(p[2])) buf_str(&b, p);
  else if (rpc_is_sep(p[0])) {
    if (cwd[0] && cwd[1] == ':') buf_put(&b, cwd, 2);
    buf_str(&b, p);
  } else {
    buf_str(&b, cwd);
    buf_put(&b, "\\", 1);
    buf_str(&b, drive ? p + 2 : p);
  }
#else
  if (p[0] != '/') {
    buf_str(&b, cwd);
    buf_put(&b, "/", 1);
  }
  buf_str(&b, p);
#endif
  buf_put(&b, "", 1);
  char *out = heff_alloc(b.n + 2);
  size_t o = 0, top = 0;
  const char *s = b.s;
#ifdef _WIN32
  if (s[0] && s[1] == ':') {
    out[o++] = s[0];
    out[o++] = ':';
    s += 2;
    top = 2;
  }
#endif
  while (*s) {
    while (rpc_is_sep(*s)) s++;
    const char *e = s;
    while (*e && !rpc_is_sep(*e)) e++;
    size_t n = (size_t)(e - s);
    if (n == 0 || (n == 1 && s[0] == '.')) {}
    else if (n == 2 && s[0] == '.' && s[1] == '.') {
      while (o > top && out[o - 1] != RPC_SEP) o--;
      if (o > top) o--;
    } else {
      out[o++] = RPC_SEP;
      memcpy(out + o, s, n);
      o += n;
    }
    s = e;
  }
  if (o == top) out[o++] = RPC_SEP;
  out[o] = 0;
  free(b.s);
  return out;
}

static int rpc_hex(char c) {
  return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
}

// (a file: URI's path, as Node.js's fileURLToPath: none if it has a host)
static V rpc_uri_path(const char *u) {
  if (strncmp(u, "file:", 5) != 0) return heff_nothing;
  u += 5;
  if (strncmp(u, "//", 2) == 0) {
    u += 2;
    const char *h = u;
    while (*u && *u != '/') u++;
    size_t hn = (size_t)(u - h);
    if (hn != 0 && !(hn == 9 && strncasecmp(h, "localhost", 9) == 0)) return heff_nothing;
  }
  Buf b = {0};
  for (; *u && *u != '?' && *u != '#'; u++) {
    int a, c;
    if (*u == '%' && (a = rpc_hex(u[1])) >= 0 && (c = rpc_hex(u[2])) >= 0) {
      char x = (char)(a * 16 + c);
      if (x == '/' || (RPC_SEP == '\\' && x == '\\')) { free(b.s); return heff_nothing; }
      buf_put(&b, &x, 1);
      u += 2;
    } else buf_put(&b, u, 1);
  }
  if (b.n == 0) buf_put(&b, "/", 1);
#ifdef _WIN32
  // (`/C:/a/b` is `C:\\a\\b`; a path without its drive is no path here)
  buf_put(&b, "", 1);
  if (!(b.n >= 4 && b.s[0] == '/' && b.s[2] == ':' && (b.s[3] == '/' || b.s[3] == 0))) { free(b.s); return heff_nothing; }
  b.n -= 2;
  memmove(b.s, b.s + 1, b.n);
  for (size_t i = 0; i < b.n; i++)
    if (b.s[i] == '/') b.s[i] = '\\';
  if (b.n == 2) buf_put(&b, "\\", 1);
#endif
  V s = heff_str_text_n(b.s, (int64_t)b.n);
  free(b.s);
  return heff_just(s);
}

// (a path as a file: URI, as Node.js's pathToFileURL(...).href)
static V rpc_path_uri(const char *p) {
  char *abs = rpc_resolve(p);
  Buf b = {0};
#ifdef _WIN32
  // (`C:\\a\\b` is `file:///C:/a/b`)
  for (char *c = abs; *c; c++)
    if (*c == '\\') *c = '/';
  buf_str(&b, "file:///");
#else
  buf_str(&b, "file://");
#endif
  for (const unsigned char *c = (const unsigned char *)abs; *c; c++) {
    if (*c <= 0x20 || *c >= 0x7F || strchr("\"#<>?`{}%\\", *c)) {
      char e[4];
      snprintf(e, sizeof e, "%%%02X", *c);
      buf_put(&b, e, 3);
    } else buf_put(&b, (const char *)c, 1);
  }
  free(abs);
  V s = heff_str_text_n(b.s, (int64_t)b.n);
  free(b.s);
  return s;
}

// The project's files
// ---------------------------------------------------------------------

static int rpc_is_root(const char *d) {
  char *p = heff_join(d, "package.hf");
  struct stat st;
  int ok = stat(p, &st) == 0 && S_ISREG(st.st_mode) && access(p, R_OK) == 0;
  free(p);
  return ok;
}

typedef struct { char **xs; int64_t n, cap; } Names;

static void names_add(Names *ns, char *x) {
  if (ns->n == ns->cap) {
    int64_t cap = ns->cap ? ns->cap * 2 : 16;
    char **x2 = heff_alloc(cap * sizeof(char *));
    if (ns->n) memcpy(x2, ns->xs, ns->n * sizeof(char *));
    free(ns->xs);
    ns->xs = x2;
    ns->cap = cap;
  }
  ns->xs[ns->n++] = x;
}

static int names_has(Names *ns, const char *x) {
  for (int64_t i = 0; i < ns->n; i++)
    if (strcmp(ns->xs[i], x) == 0) return 1;
  return 0;
}

static void names_free(Names *ns) {
  for (int64_t i = 0; i < ns->n; i++) free(ns->xs[i]);
  free(ns->xs);
}

static void rpc_walk(const char *d, Names *ignored, Names *files) {
  DIR *dir = opendir(d);
  if (!dir) return;
  Names here = {0};
  struct dirent *e;
  while ((e = readdir(dir))) names_add(&here, strdup(e->d_name));
  closedir(dir);
  qsort(here.xs, here.n, sizeof(char *), heff_cmp_cstr);
  for (int64_t i = 0; i < here.n; i++) {
    const char *name = here.xs[i];
    if (name[0] == '.' || names_has(ignored, name)) continue;
    char *p = heff_join(d, name);
    struct stat st;
    if (lstat(p, &st) == 0) {
      if (S_ISDIR(st.st_mode)) {
        if (!rpc_is_root(p)) rpc_walk(p, ignored, files);
      } else if (S_ISREG(st.st_mode)) {
        size_t n = strlen(name);
        if (n >= 3 && strcmp(name + n - 3, ".hf") == 0) { names_add(files, p); continue; }
      }
    }
    free(p);
  }
  names_free(&here);
}

// (the `.hf` files of the project at `root` (a directory with a
// package.hf): every directory but another project's, a hidden one, or
// one the root's .gitignore names)
static V rpc_project_files(const char *root) {
  Names files = {0}, ignored = {0};
  if (rpc_is_root(root)) {
    names_add(&ignored, strdup("node_modules"));
    char *gi = heff_join(root, ".gitignore");
    FILE *f = fopen(gi, "r");
    free(gi);
    if (f) {
      char line[4096];
      while (fgets(line, sizeof line, f)) {
        char *s = line, *e = line + strlen(line);
        while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
        while (e > s && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '\r' || e[-1] == '\n')) e--;
        if (s < e && *s == '/') s++;
        if (e > s && e[-1] == '/') e--;
        *e = 0;
        if (!*s || *s == '#' || strpbrk(s, "*?[/!")) continue;
        names_add(&ignored, strdup(s));
      }
      fclose(f);
    }
    rpc_walk(root, &ignored, &files);
  }
  V l = heff_strs_text(files.xs, files.n);
  names_free(&files);
  names_free(&ignored);
  return l;
}

// A computation tried
// ---------------------------------------------------------------------

// (what a tried holds -- its computation, and what is done with how it
// came out -- where `rpc_open` puts it, as std.reactor's provider takes
// a begun)
static V rpc_held[2];

static V rpc_open_fn(V self, V *a) {
  rpc_held[0] = a[0];
  rpc_held[1] = a[1];
  heff_drop(self);
  return NTAG(TAG_MkUnit);
}

// (`c`, a computation of the world, run to its end, a failure caught --
// an abandon, a case not provided for, the runtime's: `Right` its value,
// or `Left` why, said on stderr too.  What it made before failing is
// leaked, as `heff_try` leaves it; the depth of calls last is put back)
static V rpc_attempt(V c) {
  long dep = heff_dep;
  V r;
  const char *why = heff_try(c, heff_clo(heff_kept, 1, 0, NULL), &r);
  heff_dep = dep;
  if (!why) return heff_tag_n(TAG_Right, 1, &r);
  fprintf(stderr, "heff lsp: failed: %s\n", why);
  V w = heff_str_text(why);
  return heff_tag_n(TAG_Left, 1, &w);
}

// The provider
// ---------------------------------------------------------------------

static V heff_provider_rpc(V p, V k) {
  V x;
  switch (heff_tag_of(p)) {
  case TAG_Await: {
    int64_t ms = INT_OF(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, rpc_await(ms));
    break;
  }
  case TAG_Send: {
    size_t n;
    char *body = heff_bytes(heff_field(p, 0), &n);
    x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    fprintf(stdout, "Content-Length: %zu\r\n\r\n", n);
    fwrite(body, 1, n, stdout);
    fflush(stdout);
    free(body);
    break;
  }
  case TAG_Log: {
    fputs("heff lsp: ", stderr);
    heff_put(stderr, heff_field(p, 0));
    fputc('\n', stderr);
    x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    break;
  }
  case TAG_Now: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    x = heff_answer(f, MK_INT(rpc_now()));
    break;
  }
  case TAG_ProjectFiles: case TAG_UriPath: case TAG_PathUri: case TAG_AbsPath: {
    int tag = heff_tag_of(p);
    char *s = heff_cstr_text(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    // (a path or a URI with a NUL in it, which cannot be a C string, is
    // none: no files, no path, and as it was where one is made of it)
    V was = s ? 0 : heff_dup(heff_field(p, 0));
    heff_drop(p);
    V r;
    if (!s) r = tag == TAG_ProjectFiles ? NTAG(TAG_Nil) : tag == TAG_UriPath ? heff_nothing : was;
    else if (tag == TAG_ProjectFiles) r = rpc_project_files(s);
    else if (tag == TAG_UriPath) r = rpc_uri_path(s);
    else if (tag == TAG_PathUri) r = rpc_path_uri(s);
    else {
      char *a = rpc_resolve(s);
      r = heff_str_text(a);
      free(a);
    }
    free(s);
    x = heff_answer(f, r);
    break;
  }
  case TAG_Attempt: {
    V b = heff_dup(heff_field(p, 0));
    heff_drop(p);
    heff_drop(heff_answer(b, heff_clo(rpc_open_fn, 2, 0, NULL)));
    V c = rpc_held[0], f = rpc_held[1];
    x = heff_answer(f, rpc_attempt(c));
    break;
  }
  case TAG_Quit: {
    int code = (int)INT_OF(heff_field(p, 0));
    fflush(stdout);
    fflush(stderr);
    exit(code);
  }
  default:
    heff_fail("not an operation of rpc");
    return 0;
  }
  return heff_tail(k, 1, &x);
}

// The terminal's side of std.progress, for the C backend: an
// effect provider.
//
// The lines are drawn on the standard error by a thread of their own,
// as zig draws its progress (std.Progress): every 80 ms, the newest
// lines given, if they are not those drawn -- none in the first 200 ms
// after lines are first given, so that what is quickly done shows
// nothing -- each cut to the terminal's width, as many as leave two of
// its rows.  The cursor is left where the first line starts: what the
// program writes there clears them first (`heff_lines`, which
// std.io's provider calls around each write), and they come back
// below it.  At the program's end, or where it runs a command in its
// place, they are cleared for good.
//
// A command run under a task (`ShowRun`) is given a pipe for its own
// progress, its number in `ZIG_PROGRESS`, as zig gives its children
// one: zig writes the tree of its tasks there every 80 ms, a packet
// each -- `n`, a byte; `n` tasks of 128 bytes (how many of its items
// are done, of how many: 32 bits each, little-endian; its name, 120
// bytes, ended by a 0 if shorter); and the index of each one's parent,
// a byte each (255: none) -- and the newest tree is given to the
// program's function, whose lines are drawn.  (On Windows, where zig's
// is a handle, the command is run without it, by runtime.c's
// heff_capture, its input the program's.)  Elsewhere it has no input,
// as std.process's `run` gives none.

#ifndef _WIN32
#include <sys/ioctl.h>
#endif
#include <errno.h>
#include <fcntl.h>
#include <time.h>

// (`heff_lines(1)`: what is drawn cleared, and nothing drawn, until
// `heff_lines(0)`; `heff_lines(2)`: cleared, and nothing drawn again.
// Set once lines are first given; the providers of the streams declare
// it too -- one variable, however many of them a program has)
static void (*heff_lines)(int);

#ifdef _WIN32
static SRWLOCK heff_st_mu = SRWLOCK_INIT;
static CONDITION_VARIABLE heff_st_cv = CONDITION_VARIABLE_INIT;
static HANDLE heff_st_thread;
static void heff_st_lock(void) { AcquireSRWLockExclusive(&heff_st_mu); }
static void heff_st_unlock(void) { ReleaseSRWLockExclusive(&heff_st_mu); }
static void heff_st_wait(int ms) { SleepConditionVariableSRW(&heff_st_cv, &heff_st_mu, (DWORD)ms, 0); }
static void heff_st_wake(void) { WakeAllConditionVariable(&heff_st_cv); }
static int64_t heff_st_now(void) { return (int64_t)GetTickCount64(); }
#else
static pthread_mutex_t heff_st_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t heff_st_cv = PTHREAD_COND_INITIALIZER;
static pthread_t heff_st_thread;
static void heff_st_lock(void) { pthread_mutex_lock(&heff_st_mu); }
static void heff_st_unlock(void) { pthread_mutex_unlock(&heff_st_mu); }
static void heff_st_wait(int ms) {
  struct timespec t;
  clock_gettime(CLOCK_REALTIME, &t);
  t.tv_nsec += (long)ms * 1000000L;
  t.tv_sec += t.tv_nsec / 1000000000L;
  t.tv_nsec %= 1000000000L;
  pthread_cond_timedwait(&heff_st_cv, &heff_st_mu, &t);
}
static void heff_st_wake(void) { pthread_cond_broadcast(&heff_st_cv); }
static int64_t heff_st_now(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}
#endif

// (the newest lines given, `heff_st_n` of them; how many are on the
// terminal now; whether they are not those; since when lines have been
// given, nothing drawn before; whether the thread draws; whether the
// program is ending)
static char **heff_st_lines = NULL;
static int heff_st_n = 0, heff_st_drawn = 0, heff_st_dirty = 0;
static int64_t heff_st_since = 0;
static int heff_st_going = 0, heff_st_over = 0;

// (lines are drawn where the standard error is a terminal and `TERM` is
// not `dumb`; on Windows, a console that takes escape sequences: 1, 0,
// or -1 not asked yet)
static int heff_st_tty = -1;

static int heff_st_terminal(void) {
  if (heff_st_tty >= 0) return heff_st_tty;
  const char *term = getenv("TERM");
  int ok = !(term && strcmp(term, "dumb") == 0);
#ifdef _WIN32
  DWORD mode;
  HANDLE h = GetStdHandle(STD_ERROR_HANDLE);
  ok = ok && _isatty(2) && GetConsoleMode(h, &mode)
    && ((mode & ENABLE_VIRTUAL_TERMINAL_PROCESSING) || SetConsoleMode(h, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING));
#else
  ok = ok && isatty(2);
#endif
  heff_st_tty = ok;
  return ok;
}

// (the terminal's columns and rows: 80 by 25 if it does not say)
static void heff_st_size(int *cols, int *rows) {
  *cols = 80;
  *rows = 25;
#ifdef _WIN32
  CONSOLE_SCREEN_BUFFER_INFO info;
  if (GetConsoleScreenBufferInfo(GetStdHandle(STD_ERROR_HANDLE), &info)) {
    *cols = info.srWindow.Right - info.srWindow.Left + 1;
    *rows = info.srWindow.Bottom - info.srWindow.Top + 1;
  }
#else
  struct winsize w;
  if (ioctl(2, TIOCGWINSZ, &w) == 0 && w.ws_col > 0 && w.ws_row > 0) {
    *cols = w.ws_col;
    *rows = w.ws_row;
  }
#endif
}

// (how many columns a character takes: two, East Asian wide ones, else
// one)
static int heff_st_width(uint32_t u) {
  return (u >= 0x1100 && u <= 0x115F) || (u >= 0x2E80 && u <= 0xA4CF) || (u >= 0xAC00 && u <= 0xD7A3)
    || (u >= 0xF900 && u <= 0xFAFF) || (u >= 0xFE30 && u <= 0xFE4F) || (u >= 0xFF00 && u <= 0xFF60)
    || (u >= 0xFFE0 && u <= 0xFFE6) || (u >= 0x1F300 && u <= 0x1F64F) || (u >= 0x1F900 && u <= 0x1F9FF)
    || (u >= 0x20000 && u <= 0x3FFFD) ? 2 : 1;
}

// (a line, UTF-8, as much of it as fits in `width` columns)
static void heff_st_cut(Buf *b, const char *s, int width) {
  int w = 0;
  const unsigned char *p = (const unsigned char *)s;
  while (*p) {
    int len = *p < 0x80 ? 1 : *p < 0xE0 ? 2 : *p < 0xF0 ? 3 : 4;
    uint32_t u = len == 1 ? *p : len == 2 ? *p & 0x1F : len == 3 ? *p & 0x0F : *p & 0x07;
    for (int i = 1; i < len; i++) {
      if ((p[i] & 0xC0) != 0x80) { len = i; break; }
      u = (u << 6) | (p[i] & 0x3F);
    }
    int cw = heff_st_width(u);
    if (w + cw > width) break;
    buf_put(b, (const char *)p, (size_t)len);
    w += cw;
    p += len;
  }
}

// (what is drawn cleared: the cursor is where it starts)
static void heff_st_clear(void) {
  if (heff_st_drawn == 0) return;
  fputs("\x1b[J", stderr);
  fflush(stderr);
  heff_st_drawn = 0;
  heff_st_dirty = heff_st_n > 0;
}

// (the newest lines drawn in place of what was, at once -- the cursor
// back where they start -- as one write, the terminal told to show it
// whole: the lock held)
static void heff_st_draw(void) {
  int cols, rows;
  heff_st_size(&cols, &rows);
  Buf b = {0};
  buf_str(&b, "\x1b[?2026h\x1b[J");
  int n = 0;
  for (; n < heff_st_n && n + 2 < rows; n++) {
    // (a column short of the width: a line that fills it wraps on some)
    heff_st_cut(&b, heff_st_lines[n], cols - 1);
#ifdef _WIN32
    buf_str(&b, "\r\n");
#else
    buf_str(&b, "\n");
#endif
  }
  if (n > 0) {
    buf_str(&b, "\r");
    for (int i = 0; i < n; i++) buf_str(&b, "\x1bM");
  }
  buf_str(&b, "\x1b[?2026l");
  fwrite(b.s, 1, b.n, stderr);
  fflush(stderr);
  free(b.s);
  heff_st_drawn = n;
  heff_st_dirty = 0;
}

#ifdef _WIN32
static DWORD WINAPI heff_st_loop(LPVOID u) {
#else
static void *heff_st_loop(void *u) {
#endif
  (void)u;
  heff_st_lock();
  while (heff_st_going) {
    heff_st_wait(80);
    if (heff_st_going && heff_st_dirty && heff_st_now() - heff_st_since >= 200) heff_st_draw();
  }
  heff_st_unlock();
  return 0;
}

static void heff_st_free(void) {
  for (int i = 0; i < heff_st_n; i++) free(heff_st_lines[i]);
  free(heff_st_lines);
  heff_st_lines = NULL;
  heff_st_n = 0;
}

// (what the streams' providers call: see `heff_lines`)
static void heff_st_hold(int what) {
  if (what == 0) {
    // (what was written out before the lines come back)
    if (heff_st_n > 0) fflush(stdout);
    heff_st_unlock();
    return;
  }
  heff_st_lock();
  heff_st_clear();
  if (what == 2) {
    heff_st_over = 1;
    heff_st_going = 0;
    heff_st_free();
    heff_st_wake();
    heff_st_unlock();
  }
}

static void heff_st_atexit(void) {
  if (heff_lines) heff_lines(2);
}

// (the lines given are those there are: the lock held)
static int heff_st_same(char **lines, int n) {
  if (n != heff_st_n) return 0;
  for (int i = 0; i < n; i++)
    if (strcmp(lines[i], heff_st_lines[i]) != 0) return 0;
  return 1;
}

// (the lines `l`, a list of strings, drawn from now on, unless they are
// those there are; none: nothing drawn, what was cleared at once.  The
// thread, once started, draws until the program ends: lines that come
// again later are drawn at its next turn, not after 200 ms -- zig waits
// once, too)
static void heff_st_show(V l) {
  if (!heff_st_terminal() || heff_st_over) return;
  int n = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) n++;
  char **lines = heff_alloc((size_t)(n ? n : 1) * sizeof(char *));
  int i = 0;
  // (a line with a NUL in it, which cannot be a C string, drawn empty)
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) {
    char *line = heff_cstr_text(heff_field(c, 0));
    lines[i++] = line ? line : strdup("");
  }
  heff_st_lock();
  if (heff_st_same(lines, n)) {
    heff_st_unlock();
    for (i = 0; i < n; i++) free(lines[i]);
    free(lines);
    return;
  }
  heff_st_free();
  heff_st_lines = lines;
  heff_st_n = n;
  heff_st_dirty = n > 0;
  if (n == 0) heff_st_clear();
  else if (!heff_st_going) {
    static int registered = 0;
    if (!registered) { registered = 1; atexit(heff_st_atexit); }
    heff_lines = heff_st_hold;
    heff_st_going = 1;
    heff_st_since = heff_st_now();
#ifdef _WIN32
    heff_st_thread = CreateThread(NULL, 0, heff_st_loop, NULL, 0, NULL);
    if (!heff_st_thread) heff_st_going = 0;
#else
    if (pthread_create(&heff_st_thread, NULL, heff_st_loop, NULL) != 0) heff_st_going = 0;
#endif
  }
  heff_st_unlock();
}

static uint32_t heff_st_ran_shape[3] = { LBL_ended, LBL_out, LBL_err };
static uint32_t heff_st_error_shape[4] = { LBL_code, LBL_name, LBL_message, LBL_path };

// (how a command ended, as std.process's `Ended`: `how` 0 by itself,
// its status `code`; 1 by the signal `code`; 3 not run, as the errno
// `code` says, the command `name` -- a string, taken -- at fault)
static V heff_st_ended(int how, int64_t code, V name) {
  V x = MK_INT(code);
  if (how == 0 || how == 1) {
    heff_drop(name);
    return heff_tag_n(how == 0 ? TAG_Exited : TAG_Signalled, 1, &x);
  }
  int err = code > 0 ? (int)code : EINVAL;
  const char *e = heff_errno_name(err);
  char number[24];
  if (e[1] == '?') {
    snprintf(number, sizeof number, "errno %d", err);
    e = number;
  }
  V f[4] = { heff_int(err), heff_str_text(e), heff_str_text(strerror(err)), name };
  x = heff_rec(4, heff_st_error_shape, f);
  return heff_tag_n(TAG_NotRun, 1, &x);
}

#ifndef _WIN32
// (a packet of zig's, the tasks of its tree, as a list of `MkKid`s)
static V heff_st_kids(const unsigned char *pk) {
  int n = pk[0];
  V l = NTAG(TAG_Nil);
  for (int i = n - 1; i >= 0; i--) {
    const unsigned char *s = pk + 1 + i * 128;
    uint32_t done = (uint32_t)s[0] | (uint32_t)s[1] << 8 | (uint32_t)s[2] << 16 | (uint32_t)s[3] << 24;
    uint32_t total = (uint32_t)s[4] | (uint32_t)s[5] << 8 | (uint32_t)s[6] << 16 | (uint32_t)s[7] << 24;
    char name[121];
    memcpy(name, s + 8, 120);
    name[120] = 0;
    V f[4] = { heff_str_text(name), MK_INT(done), MK_INT(total == 0xFFFFFFFFu ? 0 : total), MK_INT(pk[1 + n * 128 + i]) };
    l = heff_cons(heff_tag(TAG_MkKid, 4, f), l);
  }
  return l;
}

// (what the command has said of its progress, read: each whole packet
// taken, the newest one's tree given to `f`, whose lines are drawn)
static void heff_st_packets(Buf *pb, V f) {
  size_t at = 0, newest = (size_t)-1;
  while (pb->n - at >= 1) {
    size_t len = 1 + (size_t)(unsigned char)pb->s[at] * 129;
    if (pb->n - at < len) break;
    newest = at;
    at += len;
  }
  if (newest != (size_t)-1) {
    V lines = heff_tr(heff_app1(heff_dup(f), heff_st_kids((const unsigned char *)pb->s + newest)));
    heff_st_show(lines);
    heff_drop(lines);
  }
  memmove(pb->s, pb->s + at, pb->n - at);
  pb->n -= at;
}

extern char **environ;
// (the command `as` run as std.process's `run` runs it, no input given
// it, with `ZIG_PROGRESS` where `f` is given, its progress drawn by `f`
// as it comes: how it ended, as heff_st_ended says, its status, signal
// or errno `*code`)
static int heff_st_capture(char **as, Buf *bo, Buf *be, V f, int64_t *code) {
  int po[2], pe[2], pp[2] = { -1, -1 };
  *code = EINVAL;
  if (pipe(po) != 0) { *code = errno; return 3; }
  if (pipe(pe) != 0) { *code = errno; close(po[0]); close(po[1]); return 3; }
  if (f && pipe(pp) != 0) { *code = errno; close(po[0]); close(po[1]); close(pe[0]); close(pe[1]); return 3; }
  // (the environment, its ZIG_PROGRESS the pipe's end)
  int ne = 0;
  while (environ[ne]) ne++;
  char **env = heff_alloc((size_t)(ne + 2) * sizeof(char *));
  int k = 0;
  for (int i = 0; i < ne; i++)
    if (!f || strncmp(environ[i], "ZIG_PROGRESS=", 13) != 0) env[k++] = environ[i];
  char zp[32];
  snprintf(zp, sizeof zp, "ZIG_PROGRESS=%d", pp[1]);
  if (f) env[k++] = zp;
  env[k] = NULL;
  int null = open("/dev/null", O_RDONLY);
  int closed[4] = { po[0], pe[0], null, pp[0] };
  pid_t pid = heff_exec_in_dir(as, env, null, po[1], pe[1], closed, f ? 4 : 3);
  int ok = pid > 0;
  if (!ok) *code = errno ? errno : ENOENT;
  if (null >= 0) close(null);
  free(env);
  close(po[1]);
  close(pe[1]);
  if (f) close(pp[1]);
  // (its streams and its progress read together, until all are closed)
  struct pollfd fds[3] = { { po[0], POLLIN, 0 }, { pe[0], POLLIN, 0 }, { pp[0], POLLIN, 0 } };
  Buf pb = {0};
  int open = f ? 3 : 2;
  char chunk[65536];
  while (open > 0) {
    if (poll(fds, 3, -1) < 0) {
      if (errno == EINTR) continue;
      break;
    }
    for (int i = 0; i < 3; i++) {
      if (fds[i].fd < 0 || !(fds[i].revents & (POLLIN | POLLHUP | POLLERR))) continue;
      ssize_t got = read(fds[i].fd, chunk, sizeof chunk);
      if (got < 0 && errno == EINTR) continue;
      if (got <= 0) { close(fds[i].fd); fds[i].fd = -1; open--; }
      else if (i == 2) { buf_put(&pb, chunk, (size_t)got); heff_st_packets(&pb, f); }
      else buf_put(i == 0 ? bo : be, chunk, (size_t)got);
    }
  }
  for (int i = 0; i < 3; i++) if (fds[i].fd >= 0) close(fds[i].fd);
  free(pb.s);
  if (!ok) return 3;
  int st;
  pid_t w;
  while ((w = waitpid(pid, &st, 0)) < 0 && errno == EINTR) {}
  if (w == pid && WIFEXITED(st)) { *code = WEXITSTATUS(st); return 0; }
  if (w == pid && WIFSIGNALED(st)) { *code = WTERMSIG(st); return 1; }
  // (its end lost)
  *code = ECHILD;
  return 3;
}
#endif

static V heff_provider_terminal(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_IsTerminal: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_bool(heff_st_terminal()));
    return heff_tail(k, 1, &x);
  }
  case TAG_ShowLines: {
    heff_st_show(heff_field(p, 0));
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_ShowRun: {
    // (a command with a NUL in its name or an argument is not run, as
    // where it cannot be)
    char *c = heff_cstr_text(heff_field(p, 0));
    int ok = c != NULL;
    int64_t n = 0;
    for (V l = heff_field(p, 1); heff_tag_of(l) == TAG_Cons; l = heff_field(l, 1)) n++;
    char **as = heff_alloc((size_t)(n + 2) * sizeof(char *));
    as[0] = c;
    int64_t i = 1;
    for (V l = heff_field(p, 1); heff_tag_of(l) == TAG_Cons; l = heff_field(l, 1)) {
      as[i] = heff_cstr_text(heff_field(l, 0));
      ok = ok && as[i] != NULL;
      i++;
    }
    as[i] = NULL;
    V f = heff_dup(heff_field(p, 2)), r = heff_dup(heff_field(p, 3));
    V name = heff_dup(heff_field(p, 0));
    heff_drop(p);
    Buf bo = {0}, be = {0};
    int64_t code = 0;
#ifdef _WIN32
    // (no signals there: -1 its exit code where it could not be run)
    code = ok ? heff_capture(as, &bo, &be) : -1;
    int how = code == -1 ? 3 : 0;
    if (how == 3) code = ok ? ENOENT : EINVAL;
#else
    code = EINVAL;
    int how = !ok ? 3 : heff_st_capture(as, &bo, &be, heff_st_terminal() && !heff_st_over ? f : 0, &code);
#endif
    heff_drop(f);
    for (int64_t j = 0; j < i; j++) free(as[j]);
    free(as);
    V fs[3] = {
      heff_st_ended(how, code, name),
      heff_str_bytes(bo.s ? bo.s : "", (int64_t)bo.n),
      heff_str_bytes(be.s ? be.s : "", (int64_t)be.n),
    };
    free(bo.s);
    free(be.s);
    V x = heff_answer(r, heff_rec(3, heff_st_ran_shape, fs));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of terminal");
    return 0;
  }
}

// The terminal's side of std.terminal, for the C backend: an
// effect provider.
//
// `Begin` makes the terminal raw -- the standard input read a byte at a
// time as it is typed, not echoed, not a line at a time; its signals
// kept, so that Ctrl-C is SIGINT still -- and shows the alternate
// screen.  What was is kept, and put back by `Finish`, at the program's
// end (atexit: `exit`, a failure), and by a handler of the signals that
// end a program (SIGINT, SIGTERM, SIGHUP, SIGQUIT), which puts it back
// and raises the signal again, as it was, so that the program ends as it
// would have.  Ctrl-Z (SIGTSTP) puts it back while the program is
// stopped; SIGCONT, and a change of the terminal's size (SIGWINCH), make
// it raw again and have `ReadInput` answer "", so that the app is drawn
// anew.  A read that finds ESC alone waits 25 ms for what follows, so
// that the key Escape and the start of a sequence are told apart.
//
// On Windows there is no terminal of this kind yet: `Interactive` and
// `Begin` say no.

#ifndef _WIN32
#include <errno.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <termios.h>
#endif

static uint32_t heff_cn_size_shape[2] = { LBL_columns, LBL_rows };

#ifndef _WIN32
// (whether the terminal is raw now, and as it was before)
static volatile sig_atomic_t heff_cn_raw = 0;
static struct termios heff_cn_saved;
// (a change of size, or a program gone on: the app to be drawn anew)
static volatile sig_atomic_t heff_cn_anew = 0;
static int heff_cn_handled = 0;
static struct sigaction heff_cn_before[7];
static const int heff_cn_signals[7] = { SIGINT, SIGTERM, SIGHUP, SIGQUIT, SIGTSTP, SIGCONT, SIGWINCH };

// (all of `n` bytes written to the terminal: what a handler of a
// signal may do)
static void heff_cn_write(const char *s, size_t n) {
  while (n > 0) {
    ssize_t w = write(1, s, n);
    if (w < 0 && errno == EINTR) continue;
    if (w <= 0) return;
    s += w;
    n -= (size_t)w;
  }
}

static const char heff_cn_enter[] = "\x1b[?1049h\x1b[H\x1b[2J";
static const char heff_cn_leave[] = "\x1b[0m\x1b[?25h\x1b[?1049l";

// (raw, from the terminal as it was)
static void heff_cn_make_raw(void) {
  struct termios t = heff_cn_saved;
  t.c_iflag &= ~(tcflag_t)(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
  t.c_lflag &= ~(tcflag_t)(ECHO | ICANON | IEXTEN);
  t.c_cflag |= CS8;
  t.c_cc[VMIN] = 1;
  t.c_cc[VTIME] = 0;
  tcsetattr(0, TCSANOW, &t);
  heff_cn_write(heff_cn_enter, sizeof heff_cn_enter - 1);
}

// (the terminal as it was, where it is raw; `over`: for good)
static void heff_cn_put_back(int over) {
  if (!heff_cn_raw) return;
  heff_cn_write(heff_cn_leave, sizeof heff_cn_leave - 1);
  tcsetattr(0, TCSANOW, &heff_cn_saved);
  if (over) heff_cn_raw = 0;
}

static void heff_cn_atexit(void) { heff_cn_put_back(1); }

static void heff_cn_signal(int sig) {
  int saved = errno;
  if (sig == SIGWINCH) heff_cn_anew = 1;
  else if (sig == SIGCONT) {
    if (heff_cn_raw) heff_cn_make_raw();
    heff_cn_anew = 1;
  } else if (sig == SIGTSTP) {
    // (put back while stopped: stopped as it would have been, by the
    // default; raw again at SIGCONT)
    heff_cn_put_back(0);
    signal(SIGTSTP, SIG_DFL);
    raise(SIGTSTP);
    struct sigaction a;
    memset(&a, 0, sizeof a);
    a.sa_handler = heff_cn_signal;
    sigemptyset(&a.sa_mask);
    sigaction(SIGTSTP, &a, NULL);
  } else {
    // (an end: put back, then the signal as it was before)
    heff_cn_put_back(1);
    for (int i = 0; i < 7; i++)
      if (heff_cn_signals[i] == sig) sigaction(sig, &heff_cn_before[i], NULL);
    raise(sig);
  }
  errno = saved;
}

// (the handlers set, or those before put back)
static void heff_cn_handle(int on) {
  if (on == heff_cn_handled) return;
  heff_cn_handled = on;
  for (int i = 0; i < 7; i++) {
    if (on) {
      struct sigaction a;
      memset(&a, 0, sizeof a);
      a.sa_handler = heff_cn_signal;
      sigemptyset(&a.sa_mask);
      // (no SA_RESTART: a read waiting is interrupted, to draw anew)
      sigaction(heff_cn_signals[i], &a, &heff_cn_before[i]);
    } else sigaction(heff_cn_signals[i], &heff_cn_before[i], NULL);
  }
}

static int heff_cn_terminal(void) {
  const char *term = getenv("TERM");
  return isatty(0) && isatty(1) && !(term && strcmp(term, "dumb") == 0);
}

static int heff_cn_begin(void) {
  if (heff_cn_raw) return 1;
  if (!heff_cn_terminal() || tcgetattr(0, &heff_cn_saved) != 0) return 0;
  static int registered = 0;
  if (!registered) { registered = 1; atexit(heff_cn_atexit); }
  fflush(stdout);
  fflush(stderr);
  heff_cn_raw = 1;
  heff_cn_handle(1);
  heff_cn_make_raw();
  return 1;
}

static void heff_cn_finish(void) {
  fflush(stdout);
  heff_cn_put_back(1);
  heff_cn_handle(0);
}

// (what is typed next: Just it, Just "" where the app is to be drawn
// anew, Nothing at the end of the input)
static V heff_cn_read(void) {
  char buf[512];
  for (;;) {
    if (heff_cn_anew) {
      heff_cn_anew = 0;
      return heff_just(heff_str_bytes("", 0));
    }
    ssize_t n = read(0, buf, sizeof buf - 64);
    if (n < 0 && errno == EINTR) continue;
    if (n <= 0) return heff_nothing;
    // (ESC last: what follows it, if it comes at once)
    if (buf[n - 1] == 0x1b) {
      struct pollfd p = { 0, POLLIN, 0 };
      if (poll(&p, 1, 25) > 0) {
        ssize_t m = read(0, buf + n, 64);
        if (m > 0) n += m;
      }
    }
    return heff_just(heff_str_bytes(buf, (int64_t)n));
  }
}
#endif

// (the terminal's columns and rows: 80 by 24 where it does not say)
static V heff_cn_measure(void) {
  int cols = 80, rows = 24;
#ifndef _WIN32
  struct winsize w;
  if (ioctl(1, TIOCGWINSZ, &w) == 0 && w.ws_col > 0 && w.ws_row > 0) {
    cols = w.ws_col;
    rows = w.ws_row;
  }
#endif
  V f[2] = { MK_INT(cols), MK_INT(rows) };
  return heff_rec(2, heff_cn_size_shape, f);
}

static V heff_provider_console(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Interactive: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
#ifdef _WIN32
    V x = heff_answer(f, heff_bool(0));
#else
    V x = heff_answer(f, heff_bool(heff_cn_terminal()));
#endif
    return heff_tail(k, 1, &x);
  }
  case TAG_Begin: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
#ifdef _WIN32
    V x = heff_answer(f, heff_bool(0));
#else
    V x = heff_answer(f, heff_bool(heff_cn_begin()));
#endif
    return heff_tail(k, 1, &x);
  }
  case TAG_Finish: {
    V x = heff_dup(heff_field(p, 0));
    heff_drop(p);
#ifndef _WIN32
    heff_cn_finish();
#endif
    return heff_tail(k, 1, &x);
  }
  case TAG_Measure: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_cn_measure());
    return heff_tail(k, 1, &x);
  }
  case TAG_ReadInput: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
#ifdef _WIN32
    V x = heff_answer(f, heff_nothing);
#else
    V x = heff_answer(f, heff_cn_read());
#endif
    return heff_tail(k, 1, &x);
  }
  case TAG_Draw: {
    fflush(stdout);
    size_t n = 0;
    char *s = heff_bytes(heff_field(p, 0), &n);
#ifdef _WIN32
    fwrite(s, 1, n, stdout);
    fflush(stdout);
#else
    heff_cn_write(s, n);
#endif
    free(s);
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of console");
    return 0;
  }
}

// Time's side of std.time, for the C backend: an effect provider.  A
// sleep is a wait of the runtime's reactor with a deadline and no
// descriptor: in a group of std.reactor's (an act boc awaits, in its
// worker's) it is pending, the other acts and behaviours going on until
// its time has passed; elsewhere the program waits where it is.  A
// clock is read there and then: the time of day (CLOCK_REALTIME), and
// one that only goes forward (CLOCK_MONOTONIC), each in nanoseconds.

#include <time.h>

// (the time of day, in nanoseconds since the epoch)
static int64_t tm_now_ns(void) {
  struct timespec t;
#ifdef _WIN32
  timespec_get(&t, TIME_UTC);
#else
  clock_gettime(CLOCK_REALTIME, &t);
#endif
  return (int64_t)t.tv_sec * 1000000000 + t.tv_nsec;
}

// (nanoseconds of a clock that only goes forward)
static int64_t tm_monotonic_ns(void) {
#ifdef _WIN32
  LARGE_INTEGER c, f;
  QueryPerformanceCounter(&c);
  QueryPerformanceFrequency(&f);
  return (int64_t)(c.QuadPart / f.QuadPart) * 1000000000
         + (int64_t)(c.QuadPart % f.QuadPart) * 1000000000 / f.QuadPart;
#else
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (int64_t)t.tv_sec * 1000000000 + t.tv_nsec;
#endif
}

// (a clock's reading given to the operation's function, and what it
// gives to the continuation)
static V tm_read(V p, int64_t ns, V k) {
  V f = heff_dup(heff_field(p, 0));
  heff_drop(p);
  V x = heff_tr(heff_app1(f, heff_int(ns)));
  return heff_tail(k, 1, &x);
}

// (a sleep pending: its wait, and what comes after it)
typedef struct { HeffWait w; V x; } TmSleep;

static int tm_step(HeffWait *w) {
  (void)w;
  return HEFF_STEP_WAIT;
}

static V tm_answer(HeffWait *w) {
  TmSleep *s = (TmSleep *)w;
  V x = s->x;
  free(s);
  return x;
}

static void tm_cancel(HeffWait *w) {
  TmSleep *s = (TmSleep *)w;
  heff_drop(s->x);
  free(s);
}

// (what comes after the sleep, given by the reactor as the wait's
// answer: given back as it is)
static V tm_then(V self, V *a) {
  heff_drop(self);
  return a[0];
}

static V heff_provider_time(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Sleep: {
    int64_t ms = INT_OF(heff_field(p, 0));
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    if (ms > 0 && heff_group) {
      TmSleep *s = heff_alloc(sizeof *s);
      memset(s, 0, sizeof *s);
      s->w.fd = -1;
      s->w.until = heff_now_ms() + ms;
      s->w.step = tm_step; s->w.answer = tm_answer; s->w.cancel = tm_cancel;
      s->x = x;
      return heff_outside(&s->w, heff_clo(tm_then, 1, 0, NULL), k);
    }
    if (ms > 0) {
#ifdef _WIN32
      Sleep((DWORD)ms);
#else
      struct timespec t = { (time_t)(ms / 1000), (long)(ms % 1000) * 1000000L };
      while (nanosleep(&t, &t) != 0) {}
#endif
    }
    return heff_tail(k, 1, &x);
  }
  case TAG_Now:
    return tm_read(p, tm_now_ns(), k);
  case TAG_Monotonic:
    return tm_read(p, tm_monotonic_ns(), k);
  default:
    heff_fail("not an operation of time");
    return 0;
  }
}

// std.reactor's side, for the C backend: an effect provider
// over the runtime's reactor, whose groups it
// opens, starts computations in, asks for what is finished and closes.
//
// A computation is started between a `Begin` and an `End`, in the
// world's own course, not handed to an operation: `Begin` runs what
// comes after it -- the computation, to its `End` -- there and then, in
// its group (`heff_group`), as `heff_reactor_start` runs a computation;
// the `End` of that run gives back its value and what comes after it,
// not running it, and `Begin` goes on from there, with `Just` the
// value.  Where the computation waits instead, `HEFF_PENDING` comes
// back, and `Begin` goes on from itself again, told `False`; once the
// wait is done, the rest is run by the reactor, and its `End`, not of a
// run of a `Begin`'s, gives back the value alone, one of the group's
// finished.  Where the group was opened with what a failure is
// finished as, each of these runs is under `heff_try`, and one that
// fails is finished so, its start told it waits.
//
// An `End` and a `Finished` are each a function given what to do with
// what they hold, their types erased: `rx_open` takes it -- an end's
// value and its function `k`, a finished's function `k` -- so that the
// provider has each apart, as boc's provider takes a `Some`.

// (what an end or a finished holds, where `rx_open` puts it)
static HEFF_TLS V rx_held[2];

// (the group whose `Begin` is running what comes after it, 0 none; and
// what its `End` gave back: the value, its function and what comes
// after it)
static HEFF_TLS int64_t rx_trying;
static HEFF_TLS V rx_ended[3];
static Obj rx_ended_obj = { IMMORTAL, K_STR, 0 };
#define RX_ENDED ((V)&rx_ended_obj)

static V rx_open_fn(V self, V *a) {
  int n = ((Clo *)self)->arity;
  for (int i = 0; i < n; i++) rx_held[i] = a[i];
  heff_drop(self);
  return NTAG(TAG_MkUnit);
}

// (`b` given a function of `n` arguments that keeps them: what it holds
// at `rx_held`; `b` consumed)
static void rx_open(V b, int n) {
  heff_drop(heff_answer(b, heff_clo(rx_open_fn, n, 0, NULL)));
}

static V heff_provider_reactor(V p, V k) {
  switch (heff_tag_of(p)) {
  // (a group opened, with what a failure of a step in it is finished
  // as, where `Just` that is given)
  case TAG_Open: {
    V failing = heff_field(p, 0);
    V failed = 0;
    if (heff_tag_of(failing) == TAG_Just) {
      rx_open(heff_dup(heff_field(failing, 0)), 1);
      failed = rx_held[0];
    }
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    V x = heff_answer(f, heff_int(heff_reactor_open(failed)));
    return heff_tail(k, 1, &x);
  }
  case TAG_Begin: {
    int64_t g = INT_OF(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    int64_t up = heff_group, upTrying = rx_trying;
    heff_group = g;
    rx_trying = g;
    V x = heff_answer(heff_dup(f), NTAG(TAG_True));
    V r;
    int failed = heff_group_step(g, heff_dup(k), x, &r);
    heff_group = up;
    rx_trying = upTrying;
    // (failed, where the group says what that is: finished so, and the
    // start told it waits)
    if (failed) {
      V y = heff_answer(f, NTAG(TAG_False));
      return heff_tail(k, 1, &y);
    }
    if (r == RX_ENDED) {
      heff_drop(f);
      heff_drop(k);
      V v = rx_ended[0], ef = rx_ended[1], ek = rx_ended[2];
      V y = heff_answer(ef, heff_just(v));
      return heff_tail(ek, 1, &y);
    }
    if (r == HEFF_PENDING) {
      V y = heff_answer(f, NTAG(TAG_False));
      return heff_tail(k, 1, &y);
    }
    // (the program came to its end within: what started was left
    // otherwise than by its `End`, a throw heard outside the scheduler)
    heff_drop(f);
    heff_drop(k);
    return r;
  }
  case TAG_End: {
    int64_t g = INT_OF(heff_field(p, 0));
    V b = heff_dup(heff_field(p, 1));
    heff_drop(p);
    rx_open(b, 2);
    V v = rx_held[0], f = rx_held[1];
    if (g == rx_trying) {
      rx_ended[0] = v;
      rx_ended[1] = f;
      rx_ended[2] = k;
      return RX_ENDED;
    }
    heff_drop(f);
    heff_drop(k);
    return v;
  }
  case TAG_Finish: {
    int64_t g = INT_OF(heff_field(p, 0));
    int wait = heff_field(p, 1) == NTAG(TAG_True);
    V b = heff_dup(heff_field(p, 2));
    heff_drop(p);
    rx_open(b, 1);
    V f = rx_held[0];
    V x = heff_answer(f, heff_reactor_finished(g, wait));
    return heff_tail(k, 1, &x);
  }
  case TAG_Within: {
    int64_t g = INT_OF(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    V x = heff_answer(f, heff_int(heff_reactor_open_within(g)));
    return heff_tail(k, 1, &x);
  }
  case TAG_Pending: {
    int64_t g = INT_OF(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    V x = heff_answer(f, heff_int(heff_reactor_pending(g)));
    return heff_tail(k, 1, &x);
  }
  case TAG_Wake: {
    int64_t g = INT_OF(heff_field(p, 0));
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    heff_reactor_wake_group(g);
    return heff_tail(k, 1, &x);
  }
  // (what gives up a group within another, from any thread, with what
  // it is then finished as)
  case TAG_MakeGiving: {
    int64_t g = INT_OF(heff_field(p, 0));
    rx_open(heff_dup(heff_field(p, 1)), 1);
    V gave = rx_held[0];
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    V x = heff_answer(f, heff_reactor_giving(g, gave));
    return heff_tail(k, 1, &x);
  }
  // (its group closed, here, where it is this thread's)
  case TAG_CloseGiving: {
    HeffGiving *gv = heff_foreign_ptr(heff_field(p, 0));
    int64_t g = gv->group;
    V x = heff_dup(heff_field(p, 1));
    // (closed before the thing may be let go of here, so that its end,
    // then, finds it closed)
    heff_reactor_close(g);
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_Close: {
    int64_t g = INT_OF(heff_field(p, 0));
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    heff_reactor_close(g);
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of reactor");
    return 0;
  }
}

static V heff_perform_8(V p, V k) { return heff_provider_stdio(p, k); }
static V heff_perform_9(V p, V k) { return heff_provider_process(p, k); }
static V heff_perform_7(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_8(q, k) : heff_perform_9(q, k); }
static V heff_perform_10(V p, V k) { return heff_provider_filesystem(p, k); }
static V heff_perform_6(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_7(q, k) : heff_perform_10(q, k); }
static V heff_perform_11(V p, V k) { return heff_provider_report(p, k); }
static V heff_perform_5(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_6(q, k) : heff_perform_11(q, k); }
static V heff_perform_12(V p, V k) { return heff_provider_rpc(p, k); }
static V heff_perform_4(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_5(q, k) : heff_perform_12(q, k); }
static V heff_perform_13(V p, V k) { return heff_provider_terminal(p, k); }
static V heff_perform_3(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_4(q, k) : heff_perform_13(q, k); }
static V heff_perform_14(V p, V k) { return heff_provider_console(p, k); }
static V heff_perform_2(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_3(q, k) : heff_perform_14(q, k); }
static V heff_perform_15(V p, V k) { return heff_provider_time(p, k); }
static V heff_perform_1(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_2(q, k) : heff_perform_15(q, k); }
static V heff_perform_16(V p, V k) { return heff_provider_reactor(p, k); }
static V heff_perform_0(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_1(q, k) : heff_perform_16(q, k); }
V heff_perform(V p, V k) { return heff_perform_0(p, k); }
V heff_performAt(int i, V p, V k) {
  
  switch (i) {
  case 0: return heff_provider_stdio(p, k);
  case 1: return heff_provider_process(p, k);
  case 2: return heff_provider_filesystem(p, k);
  case 3: return heff_provider_report(p, k);
  case 4: return heff_provider_rpc(p, k);
  case 5: return heff_provider_terminal(p, k);
  case 6: return heff_provider_console(p, k);
  case 7: return heff_provider_time(p, k);
  case 8: return heff_provider_reactor(p, k);
  default: return heff_abandon();
  }
}

static V heff_entry(void) { return g_run_24entry_get(); }
