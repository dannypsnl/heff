// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2earmNamed_24cpr(V, V);
HeffT3 g_heff_2ecompile_2eir_2eboolArms_24cpr(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo;
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdMap_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2econdMap_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_24dps_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdRels(V);
V g_heff_2ecompile_2eir_2econdRels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdRels_clo;
V g_heff_2ecompile_2eir_2econdShaped(V);
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdShaped_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_clo;
V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(V, V);
V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24dps_24cpr(V, V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2enamesTag(V, V);
V g_heff_2ecompile_2eir_2enamesTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enamesTag_clo;
V g_heff_2ecompile_2eir_2enubI_24dps(V, V);
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_24dps_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushArms_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushArms_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_clo;
HeffT2 g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24dps(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24dps_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_clo;
HeffT2 g_heff_2ecompile_2eonce_2evaluesOut_24cpr(V, V, V);
V g_heff_2ecompile_2erunes_2ereads(V);
V g_heff_2ecompile_2erunes_2ereads_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereads_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2etraverse_24s1760019503x148599044_24cpr(V, V);
V g_prelude_2etraverse_24s778989880x1564402942(V, V);
V g_prelude_2etraverse_24s778989880x1564402942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s778989880x1564402942_clo;
Clo g_heff_2ecompile_2eir_2econdMap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdMap_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdMap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    return NTAG(TAG_CTrue);
  }
  case TAG_CFalse: {
    return NTAG(TAG_CFalse);
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_x_243 = heff_field(v_x2_241, 1);
    V v_y_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CRel = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    V v_t_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_y_244}));
    return heff_tag_re_n(v_ru_24x2_241_24CRel, TAG_CRel, 3, 1ULL, (V[]){v_p_242, v_t_245, v_t_246});
  }
  case TAG_CTest: {
    V v_x_247 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CTest = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_247}));
    return heff_tag_at_n(v_ru_24x2_241_24CTest, TAG_CTest, 1, (V[]){v_t_248});
  }
  case TAG_CNot: {
    V v_c_249 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CNot = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24CNot, TAG_CNot, 1, (V[]){heff_hole()});
    V v_u_2411 = (g_heff_2ecompile_2eir_2econdMap_24dps(v_f_240, v_c_249, v_cell_2410, MK_INT(0LL)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  case TAG_CIf: {
    V v_a_2412 = heff_field(v_x2_241, 0);
    V v_b_2413 = heff_field(v_x2_241, 1);
    V v_c_2414 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CIf = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2415 = (g_heff_2ecompile_2eir_2econdMap(v_f_240, v_a_2412));
    V v_t_2416 = (g_heff_2ecompile_2eir_2econdMap(v_f_240, v_b_2413));
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24CIf, TAG_CIf, 3, (V[]){v_t_2415, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2eir_2econdMap_24dps(v_f_240, v_c_2414, v_cell_2417, MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdMap(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econdOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdOnto_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdOnto(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return v_rest_241;
  }
  case TAG_CFalse: {
    return v_rest_241;
  }
  case TAG_CRel: {
    V v_x_243 = heff_field(v_x1_240, 1);
    V v_y_244 = heff_field(v_x1_240, 2);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_y_244), v_rest_241})});
  }
  case TAG_CTest: {
    V v_x_245 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_rest_241});
  }
  case TAG_CNot: {
    V v_c_246 = heff_field(v_x1_240, 0);
    V t_0 = v_c_246;
    V t_1 = v_rest_241;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_b_248 = heff_field(v_x1_240, 1);
    V v_c_249 = heff_field(v_x1_240, 2);
    V v_t_2410 = (g_heff_2ecompile_2eir_2econdOnto(v_c_249, v_rest_241));
    V v_t_2411 = (g_heff_2ecompile_2eir_2econdOnto(v_b_248, v_t_2410));
    V t_0 = v_a_247;
    V t_1 = v_t_2411;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdOnto(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econdRels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdRels_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdRels(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_CFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_CRel: {
    V v_p_241 = heff_field(v_x1_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_p_241), NTAG(TAG_Nil)});
  }
  case TAG_CTest: {
    return NTAG(TAG_Nil);
  }
  case TAG_CNot: {
    V v_c_245 = heff_field(v_x1_240, 0);
    V t_0 = v_c_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_CIf: {
    V v_a_246 = heff_field(v_x1_240, 0);
    V v_b_247 = heff_field(v_x1_240, 1);
    V v_c_248 = heff_field(v_x1_240, 2);
    V v_t_249 = (g_heff_2ecompile_2eir_2econdRels(v_a_246));
    V v_t_2410 = (g_heff_2ecompile_2eir_2econdRels(v_b_247));
    V v_t_2411 = (g_heff_2ecompile_2eir_2econdRels(v_c_248));
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return (g_prelude_2e_2b_2b(v_t_249, v_t_2412));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdRels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdRels(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2enamesTag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enamesTag_entry, 2, 0};

V g_heff_2ecompile_2eir_2enamesTag(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      if (heff_strEq_c_lent(v_t_240, v_t2_244, 0)) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2enamesTag_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eir_2enamesTag(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2enubI_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_24dps_entry, 2, 0};

V g_heff_2ecompile_2eir_2enubI_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s930188071x496633547(v_x_242, v_xs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2enubI_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2epushArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushArms_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushArms(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_args_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_a_242, 2);
      heff_take_n(v_a_242, 4ULL, 3);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = ({ V a_0 = v_args_243; V a_1 = v_rest_241; V a_2 = v_cell_248; V r_ = (g_heff_2ecompile_2eir_2epushArms_24dps(a_0, a_1, a_2)); heff_drop(v_rest_241); r_; });
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushArms(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushFields_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_rest_241));
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_e2_246 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_247 = v_e2_246;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
    V t_0 = v_fs_244;
    V t_1 = v_rest_241;
    V t_2 = v_u_249;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eir_2epushFields_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eir_2ewaysMap_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysMap(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2411 = heff_tag_re_n(v_ru_24e_241_24ELet, TAG_ELet, 3, 3ULL, (V[]){v_x_248, v_a_249, heff_hole()});
    V v_u_2412 = ({ V a_0 = v_f_240; V a_1 = v_b_2410; V a_2 = v_cell_2411; V r_ = (g_heff_2ecompile_2eir_2ewaysMap_24dps(a_0, a_1, a_2)); heff_drop(v_f_240); r_; });
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  case TAG_ERecord: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_e_241, 0);
    V v_arms_2423 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_lam0, 1, 1, (V[]){v_f_240}), v_arms_2423));
    return heff_tag_re_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_2422, v_t_2429});
  }
  case TAG_EPrim: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBool: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ESet: {
    V v_xs_2443 = heff_field(v_e_241, 0);
    V v_a_2444 = heff_field(v_e_241, 1);
    V v_b_2445 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2446 = heff_tag_re_n(v_ru_24e_241_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2443, v_a_2444, heff_hole()});
    V v_u_2447 = ({ V a_0 = v_f_240; V a_1 = v_b_2445; V a_2 = v_cell_2446; V r_ = (g_heff_2ecompile_2eir_2ewaysMap_24dps(a_0, a_1, a_2)); heff_drop(v_f_240); r_; });
    heff_drop(v_u_2447);
    return v_cell_2446;
  }
  case TAG_EValues: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysMap(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2ewaysMap_lam0(V self, V *args) {
  V v_x2_2424 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkArm: {
    V v_t_2425 = heff_field(v_x2_2424, 0);
    V v_vs_2426 = heff_field(v_x2_2424, 1);
    V v_b_2427 = heff_field(v_x2_2424, 2);
    V v_ru_24x2_2424_24MkArm = heff_take_reuse_n(v_x2_2424, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2428 = heff_tr(g_heff_2ecompile_2eir_2ewaysMap(v_f_240, v_b_2427));
    return heff_tag_re_n(v_ru_24x2_2424_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2425, v_vs_2426, v_t_2428});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}

HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_e_27_248 = v_field_246;
      V v_n1_249 = v_field_247;
      V v_cell_2410 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e_27_248, heff_hole()});
      HeffT2 v_t_2411 = ({ V a_0 = v_m_240; V a_1 = v_n1_249; V a_2 = v_rest_244; V a_3 = v_cell_2410; HeffT2 r_ = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24dps_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_m_240); r_; });
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v__5f_2414 = v_field_2412;
        heff_drop(v__5f_2414);
        V v_n_2415 = v_field_2413;
        return ((HeffT2){{v_cell_2410, v_n_2415}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}

HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24dps_24cpr(V v_m_240, V v_n_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    V v_u_244 = heff_setFieldPeek(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_245 = heff_hole();
    return ((HeffT2){{v_f_245, v_n_241}});
  }
  case TAG_Cons: {
    V v_e_246 = heff_field(v_x4_242, 0);
    V v_rest_247 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_248 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_246));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_e_27_2411 = v_field_249;
      V v_n1_2412 = v_field_2410;
      V v_cell_2413 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e_27_2411, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2413);
      V t_0 = v_m_240;
      V t_1 = v_n1_2412;
      V t_2 = v_rest_247;
      V t_3 = v_u_2414;
      v_m_240 = t_0;
      v_n_241 = t_1;
      v_x4_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2eglobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eglobalsGo_entry, 1, 0};

V g_heff_2ecompile_2eir_2eglobalsGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_args_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_f_245));
    V v_t_248 = ({ V a_0 = v_args_246; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_246); r_; });
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EApp, v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(v_a_2410));
    V v_t_2413 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2411));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2412, v_t_2413));
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fs_2414; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a_0)); heff_drop(v_fs_2414); r_; });
  }
  case TAG_EProj: {
    V v_e2_2416 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 4);
    V t_0 = v_e2_2416;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2421 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_args_2421; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2421); r_; });
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x1_240, 0);
    V v_arms_2424 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2425 = (g_heff_2ecompile_2eir_2eglobalsGo(v_s_2423));
    V v_t_2426 = ({ V a_0 = v_arms_2424; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a_0)); heff_drop(v_arms_2424); r_; });
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EMatch, v_t_2425, v_t_2426));
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_args_2429 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return ({ V a_0 = v_args_2429; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2429); r_; });
  }
  case TAG_ECall: {
    V v_g_2430 = heff_field(v_x1_240, 0);
    V v_args_2431 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2432 = ({ V a_0 = v_args_2431; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2431); r_; });
    return heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){v_g_2430, v_t_2432});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    V v_c_2440 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_2441 = ({ V a_0 = v_c_2440; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2440); r_; });
    return ({ V a_0 = v_t_2441; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_t_2441); r_; });
  }
  case TAG_ESet: {
    V v_a_2443 = heff_field(v_x1_240, 1);
    V v_b_2444 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2445 = (g_heff_2ecompile_2eir_2eglobalsGo(v_a_2443));
    V v_t_2446 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2444));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2445, v_t_2446));
  }
  case TAG_EValues: {
    V v_es_2447 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ({ V a_0 = v_es_2447; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_es_2447); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eglobalsGo(a[0]);
}

HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_ELam: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_args_246 = heff_field(v_e_240, 1);
    HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_245));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_h_2410 = v_field_248;
      V v_bs_2411 = v_field_249;
      V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI(v_bs_2411, heff_dup(v_args_246)));
      return ((HeffT2){{v_h_2410, v_t_2412}});
    }
  }
  case TAG_ELet: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_ERecord: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EProj: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_ETag: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_ECall: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EInt: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EStr: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EBool: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_ESet: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EValues: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  case TAG_EFix: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}

HeffT2 g_heff_2ecompile_2eir_2earmNamed_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 0)) {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_b_246)}});
        }
        case TAG_Cons: {
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_vs_245)}});
        }
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eir_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdIf_entry, 3, 0};

V g_heff_2ecompile_2eir_2econdIf(V v_x1_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_CFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_CNot: {
    V v_c_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_c_243;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_CIf: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_c_246 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2431;
    switch (heff_tag_of(v_t_241)) {
    case TAG_CTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CFalse: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CRel: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CTest: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CNot: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CIf: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_CFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CFalse: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CRel: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CTest: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CNot: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CIf: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_CRel: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_CTest: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_CNot: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_CIf: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x1_240_24CIf, 3);
      heff_drop(v_t_2431);
      V v_t_2432 = (g_heff_2ecompile_2eir_2econdIf(v_b_245, heff_dup(v_t_241), heff_dup(v_e_242)));
      V v_t_2433 = (g_heff_2ecompile_2eir_2econdIf(v_c_246, v_t_241, v_e_242));
      V t_0 = v_a_244;
      V t_1 = v_t_2432;
      V t_2 = v_t_2433;
      v_x1_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2431);
      return heff_tag_at_n(v_ru_24x1_240_24CIf, TAG_CIf, 3, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_a_244, v_b_245, v_c_246}), v_t_241, v_e_242});
    }
  }
  default: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_CTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CFalse: {
        return v_x1_240;
      }
      case TAG_CRel: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CTest: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CNot: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CIf: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_CFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_CTrue: {
        switch (heff_tag_of(v_x1_240)) {
        case TAG_CTrue: {
          return NTAG(TAG_CFalse);
        }
        case TAG_CFalse: {
          return NTAG(TAG_CTrue);
        }
        case TAG_CRel: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        case TAG_CTest: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        case TAG_CNot: {
          V v_c_2446 = heff_field(v_x1_240, 0);
          heff_take_n(v_x1_240, 1ULL, 1);
          return v_c_2446;
        }
        case TAG_CIf: {
          return heff_tag_n(TAG_CNot, 1, (V[]){v_x1_240});
        }
        default: return heff_nomatch(v_x1_240);
        }
      }
      case TAG_CFalse: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CRel: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CTest: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CNot: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_CIf: {
        return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_CRel: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CTest: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CNot: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_CIf: {
      return heff_tag_n(TAG_CIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  }
}
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdIf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eir_2econdShaped_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdShaped_str1, 5, "False");
Clo g_heff_2ecompile_2eir_2econdShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdShaped_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdShaped(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    V v_e2_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 3);
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2econdShaped_str0), 2) || heff_strEq_c_lent(v_t_2416, ((V)&g_heff_2ecompile_2eir_2econdShaped_str1), 2)));
      heff_drop(v_t_2416);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    HeffT3 v_t_2423 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(v_arms_2422));
    {
      V v_field_2425 = v_t_2423.f[1];
      V v_field_2426 = v_t_2423.f[2];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_t_2427 = v_field_2425;
        V v_f_2428 = v_field_2426;
        V v_t_2429 = (g_heff_2ecompile_2eir_2econdShaped(v_t_2427));
        if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
          heff_drop(v_t_2429);
          V t_0 = v_f_2428;
          v_e_240 = t_0;
          goto top;
        } else {
          heff_drop(v_f_2428);
          heff_drop(v_t_2429);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_field_2425);
        heff_drop(v_field_2426);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2431 = heff_field(v_e_240, 0);
    V v_e2_2432 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2432)) {
    case TAG_Nil: {
      heff_drop(v_p_2431);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2434 = heff_field(v_e2_2432, 1);
      heff_take_n(v_e2_2432, 2ULL, 2);
      switch (heff_tag_of(v_e22_2434)) {
      case TAG_Nil: {
        heff_drop(v_p_2431);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2436 = heff_field(v_e22_2434, 1);
        heff_take_n(v_e22_2434, 2ULL, 2);
        switch (heff_tag_of(v_e222_2436)) {
        case TAG_Nil: {
          return ({ V a_0 = v_p_2431; V r_ = (g_heff_2ecompile_2eir_2eisRel(a_0)); heff_drop(v_p_2431); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2436, 0ULL, 2);
          heff_drop(v_p_2431);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2436);
        }
      }
      default: return heff_nomatch(v_e22_2434);
      }
    }
    default: return heff_nomatch(v_e2_2432);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_ESet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdShaped(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam2, 1, 4, (V[]){v_m_247, heff_dup(v_f_240), v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(v_f_240, v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam5, 1, 4, (V[]){v_m_2431, heff_dup(v_f_240), v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_t_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(v_f_240, v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_t_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_t_2440 = ({ V a_0 = v_f_240; V a_1 = v_c_2430; V r_ = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(a_0, a_1)); heff_drop(v_f_240); r_; });
      V v_x2_2441 = heff_tr(heff_call(v_t_2440, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_s_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_s_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_246 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_x_244));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam2, 1, 3, (V[]){v_m_246, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2415 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2416 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_x_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam3, 1, 1, (V[]){v_m_2416});
  }
  case TAG_CNot: {
    V v_c_2421 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2422 = (g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(v_c_2421));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam4, 1, 1, (V[]){v_m_2422});
  }
  case TAG_CIf: {
    V v_a_2427 = heff_field(v_x2_27_240, 0);
    V v_b_2428 = heff_field(v_x2_27_240, 1);
    V v_c_2429 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2430 = (g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(v_a_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam5, 1, 3, (V[]){v_m_2430, v_b_2428, v_c_2429});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam1(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam2(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_y_245));
    V v_x2_2412 = heff_tr(heff_call(v_t_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_249, v_x_2413}), v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam3(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2419}), v_n_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam4(V self, V *args) {
  V v_n_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_n_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2425}), v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651_lam5(V self, V *args) {
  V v_n_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_b_2428 = heff_env(self)[1];
  V v_c_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_n_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_n_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = (g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(v_b_2428));
    V v_x2_2436 = heff_tr(heff_call(v_t_2435, 1, (V[]){v_n_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_n_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_t_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s1137932307x1113395651(v_c_2429));
      V v_x2_2440 = heff_tr(heff_call(v_t_2439, 1, (V[]){v_n_2438}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_n_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2433, v_x_2437, v_x_2441}), v_n_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_246 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_x_244));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam2, 1, 3, (V[]){v_m_246, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2415 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2416 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_x_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam3, 1, 1, (V[]){v_m_2416});
  }
  case TAG_CNot: {
    V v_c_2421 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2422 = (g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098(v_c_2421));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam4, 1, 1, (V[]){v_m_2422});
  }
  case TAG_CIf: {
    V v_a_2427 = heff_field(v_x2_27_240, 0);
    V v_b_2428 = heff_field(v_x2_27_240, 1);
    V v_c_2429 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2430 = (g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098(v_a_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam5, 1, 3, (V[]){v_m_2430, v_b_2428, v_c_2429});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam1(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam2(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_y_245));
    V v_x2_2412 = heff_tr(heff_call(v_t_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_249, v_x_2413}), v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam3(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2419}), v_n_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam4(V self, V *args) {
  V v_n_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_n_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2425}), v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098_lam5(V self, V *args) {
  V v_n_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_b_2428 = heff_env(self)[1];
  V v_c_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_n_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_n_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = (g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098(v_b_2428));
    V v_x2_2436 = heff_tr(heff_call(v_t_2435, 1, (V[]){v_n_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_n_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_t_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s362914892x1682286098(v_c_2429));
      V v_x2_2440 = heff_tr(heff_call(v_t_2439, 1, (V[]){v_n_2438}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_n_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2433, v_x_2437, v_x_2441}), v_n_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EGlobal: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_ELam: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_EApp: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2412 = (g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr(v_lit_240, v_lit_241, v_b_2411));
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2415 = v_field_2414;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_re_n(v_ru_24e_242_24ELet, TAG_ELet, 3, 3ULL, (V[]){v_x_249, v_a_2410, v_x_2415})}});
      } else {
        heff_drop(v_x_249);
        heff_drop(v_a_2410);
        heff_drop_cell(v_ru_24e_242_24ELet, 3);
        heff_drop(v_field_2414);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ERecord: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_EProj: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 4); r_; });
  }
  case TAG_ETag: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 3); r_; });
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_242, 0);
    V v_arms_2426 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2435 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr_lam0, 1, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}); V a_1 = v_arms_2426; HeffT2 r_ = (g_prelude_2etraverse_24s1760019503x148599044_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2437 = v_t_2435.f[1];
      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
      if ((v_tag_2436 == ((int64_t)0ULL))) {
        V v_x_2438 = v_field_2437;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_re_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_s_2425, v_x_2438})}});
      } else {
        heff_drop(v_s_2425);
        heff_drop_cell(v_ru_24e_242_24EMatch, 2);
        heff_drop(v_field_2437);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EPrim: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EPrimCall: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_ECall: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_EInt: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EFloat: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EStr: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EBytes: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EFixed: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  case TAG_EFloat32: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eonce_2evaluesOut_24cpr(v_lit_240, heff_dup(v_lit_241), v_e_242);
  }
  case TAG_EBool: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_ESet: {
    V v_xs_2452 = heff_field(v_e_242, 0);
    V v_a_2453 = heff_field(v_e_242, 1);
    V v_b_2454 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2455 = (g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr(v_lit_240, v_lit_241, v_b_2454));
    {
      V v_field_2457 = v_t_2455.f[1];
      int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
      if ((v_tag_2456 == ((int64_t)0ULL))) {
        V v_x_2458 = v_field_2457;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_re_n(v_ru_24e_242_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2452, v_a_2453, v_x_2458})}});
      } else {
        heff_drop(v_xs_2452);
        heff_drop(v_a_2453);
        heff_drop_cell(v_ru_24e_242_24ESet, 3);
        heff_drop(v_field_2457);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EValues: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 1); r_; });
  }
  case TAG_EFix: {
    return ({ V a_0 = v_lit_240; V a_1 = heff_dup(v_lit_241); V a_2 = v_e_242; HeffT2 r_ = (g_heff_2ecompile_2eonce_2evaluesOut_24cpr(a_0, a_1, a_2)); heff_drop_tag(v_e_242, 2); r_; });
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr_lam0(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_field(v_x2_2427, 0);
    V v_vs_2429 = heff_field(v_x2_2427, 1);
    V v_b_2430 = heff_field(v_x2_2427, 2);
    V v_ru_24x2_2427_24MkArm = heff_take_reuse_n(v_x2_2427, 7ULL, 3);
    heff_clo_take(self, 2);
    HeffT2 v_t_2431 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_b_2430; HeffT2 r_ = (g_heff_2ecompile_2eir_2ewaysM_24s174552698x1567700187_24cpr(a_0, a_1, a_2)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_x_2434 = v_field_2433;
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_re_n(v_ru_24x2_2427_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2428, v_vs_2429, v_x_2434})});
      } else {
        heff_drop(v_t_2428);
        heff_drop(v_vs_2429);
        heff_drop_cell(v_ru_24x2_2427_24MkArm, 3);
        heff_drop(v_field_2433);
        return NTAG(TAG_Nothing);
      }
    }
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam22(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam23(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam24(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam25(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam26(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_entry, 2, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_246), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_g_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2415 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_2413}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam3, 1, 3, (V[]){v_m_2415, v_f_240, v_args_2414});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x2_241, 0);
    V v_a_2426 = heff_field(v_x2_241, 1);
    V v_b_2427 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2428 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2426}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam4, 1, 4, (V[]){v_m_2428, v_x_2425, v_f_240, v_b_2427});
  }
  case TAG_ERecord: {
    V v_fs_2438 = heff_field(v_x2_241, 0);
    V v_ts_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2448 = (g_prelude_2etraverse_24s778989880x1564402942(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam5, 1, 1, (V[]){v_f_240}), v_fs_2438));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam7, 1, 2, (V[]){v_m_2448, v_ts_2439});
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x2_241, 0);
    V v_l_2454 = heff_field(v_x2_241, 1);
    V v_sh_2455 = heff_field(v_x2_241, 2);
    V v_t_2456 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2457 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2453}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam8, 1, 4, (V[]){v_m_2457, v_l_2454, v_sh_2455, v_t_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_x2_241, 0);
    V v_args_2463 = heff_field(v_x2_241, 1);
    V v_ts_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2465 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2466 = (g_prelude_2etraverse_24s778989880x1564402942(v_t_2465, v_args_2463));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam9, 1, 3, (V[]){v_m_2466, v_t_2462, v_ts_2464});
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_x2_241, 0);
    V v_arms_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2473 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2471}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam10, 1, 3, (V[]){v_m_2473, v_f_240, v_arms_2472});
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam13, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2493 = heff_field(v_x2_241, 0);
    V v_args_2494 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2496 = (g_prelude_2etraverse_24s778989880x1564402942(v_t_2495, v_args_2494));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam14, 1, 2, (V[]){v_m_2496, v_p_2493});
  }
  case TAG_ECall: {
    V v_g_24101 = heff_field(v_x2_241, 0);
    V v_args_24102 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24103 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24104 = (g_prelude_2etraverse_24s778989880x1564402942(v_t_24103, v_args_24102));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam15, 1, 2, (V[]){v_m_24104, v_g_24101});
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam22, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBool: {
    V v_c_24123 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24124 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24125 = ({ V a_0 = v_t_24124; V a_1 = v_c_24123; V r_ = (g_heff_2ecompile_2eir_2econdTraverse_24s1139007761x1229801595(a_0, a_1)); heff_drop(v_t_24124); r_; });
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam23, 1, 1, (V[]){v_m_24125});
  }
  case TAG_ESet: {
    V v_xs_24130 = heff_field(v_x2_241, 0);
    V v_a_24131 = heff_field(v_x2_241, 1);
    V v_b_24132 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24133 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_24131}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam24, 1, 4, (V[]){v_m_24133, v_f_240, v_xs_24130, v_b_24132});
  }
  case TAG_EValues: {
    V v_es_24142 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24143 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24144 = (g_prelude_2etraverse_24s778989880x1564402942(v_t_24143, v_es_24142));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam25, 1, 1, (V[]){v_m_24144});
  }
  case TAG_EFix: {
    V v_x_24149 = heff_field(v_x2_241, 0);
    V v_b_24150 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24151 = heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_x_24149), NTAG(TAG_Nil)});
    V v_m_24152 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_24151, v_b_24150}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam26, 1, 2, (V[]){v_m_24152, v_x_24149});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_243});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_245});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam3(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_args_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2421 = (g_prelude_2etraverse_24s778989880x1564402942(v_t_2420, v_args_2414));
    V v_x2_2422 = heff_tr(heff_call(v_t_2421, 1, (V[]){v_s_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_s_2424 = heff_field(v_x2_2422, 1);
      V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_EApp, 2, (V[]){v_x_2418, v_x_2423}), v_s_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_b_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_Nil)});
    V v_m_2434 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2433, v_b_2427}));
    V v_x2_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_s_2432}));
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_s_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2425, v_x_2431, v_x_2436}), v_s_2437});
    }
    default: return heff_nomatch(v_x2_2435);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam6(V self, V *args) {
  V v_s_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_s_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2441, v_x_2446}), v_s_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam5(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_l_2441 = heff_field(v_x2_2440, 0);
    V v_e_2442 = heff_field(v_x2_2440, 1);
    heff_take_n(v_x2_2440, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_m_2443 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2442}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam6, 1, 2, (V[]){v_m_2443, v_l_2441});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam7(V self, V *args) {
  V v_s_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_ts_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_s_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2451, v_ts_2439}), v_s_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam8(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2454 = heff_env(self)[1];
  V v_sh_2455 = heff_env(self)[2];
  V v_t_2456 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2460, v_l_2454, v_sh_2455, v_t_2456}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam9(V self, V *args) {
  V v_s_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  V v_ts_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_s_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_s_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2462, v_x_2469, v_ts_2464}), v_s_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam12(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_t_2479 = heff_env(self)[1];
  V v_vs_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2479, v_vs_2480, v_x_2485}), v_s_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam11(V self, V *args) {
  V v_x2_2478 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkArm: {
    V v_t_2479 = heff_field(v_x2_2478, 0);
    V v_vs_2480 = heff_field(v_x2_2478, 1);
    V v_b_2481 = heff_field(v_x2_2478, 2);
    heff_take_n(v_x2_2478, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_m_2482 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_vs_2480), v_b_2481}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam12, 1, 3, (V[]){v_m_2482, v_t_2479, v_vs_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam10(V self, V *args) {
  V v_s_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_arms_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_s_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_s_2477 = heff_field(v_x2_2475, 1);
    V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
    V v_t_2487 = (g_prelude_2etraverse_24s778989880x1564402942(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam11, 1, 1, (V[]){v_f_240}), v_arms_2472));
    V v_x2_2488 = heff_tr(heff_call(v_t_2487, 1, (V[]){v_s_2477}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_s_2490 = heff_field(v_x2_2488, 1);
      V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_EMatch, 2, (V[]){v_x_2476, v_x_2489}), v_s_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam13(V self, V *args) {
  V v_s_2492 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_2492});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam14(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_p_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2493, v_x_2499}), v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam15(V self, V *args) {
  V v_s_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  V v_g_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_s_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_s_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24101, v_x_24107}), v_s_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam16(V self, V *args) {
  V v_s_24110 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24110});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam17(V self, V *args) {
  V v_s_24112 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24112});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam18(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24114});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam19(V self, V *args) {
  V v_s_24116 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24116});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam20(V self, V *args) {
  V v_s_24119 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24119});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam21(V self, V *args) {
  V v_s_24121 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24121});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam22(V self, V *args) {
  V v_s_24122 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24122});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam23(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24128}), v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam24(V self, V *args) {
  V v_s_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_24130 = heff_env(self)[2];
  V v_b_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_s_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_s_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_m_24138 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_24130), v_b_24132}));
    V v_x2_24139 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_s_24137}));
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_s_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24130, v_x_24136, v_x_24140}), v_s_24141});
    }
    default: return heff_nomatch(v_x2_24139);
    }
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam25(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24147}), v_s_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_lam26(V self, V *args) {
  V v_s_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_x_24149 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_s_24153}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_MkPair: {
    V v_x_24155 = heff_field(v_x2_24154, 0);
    V v_s_24156 = heff_field(v_x2_24154, 1);
    V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24149, v_x_24155}), v_s_24156});
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry, 4, 0};

V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EVar = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_a_245 = heff_strCompare_lent(v_x_244, v_lit_241, 0);
    if (heff_intLt_c_lent(v_a_245, MK_INT(0LL), 2)) {
      heff_drop(v_a_245);
      return heff_tag_re_n(v_ru_24e_243_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_244});
    } else {
      if (heff_intEq_c(v_a_245, MK_INT(0LL))) {
        heff_drop(v_x_244);
        return heff_tag_at_n(v_ru_24e_243_24EVar, TAG_EVar, 1, (V[]){heff_dup(v_lit_242)});
      } else {
        return heff_tag_re_n(v_ru_24e_243_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_244});
      }
    }
  }
  case TAG_EGlobal: {
    return v_e_243;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_243, 0);
    V v_b_248 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_cell_249 = heff_tag_re_n(v_ru_24e_243_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_247, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_248, v_cell_249, MK_INT(1LL)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_243, 0);
    V v_args_2412 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2413 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_f_2411));
    V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam0, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_args_2412));
    return heff_tag_at_n(v_ru_24e_243_24EApp, TAG_EApp, 2, (V[]){v_t_2413, v_t_2415});
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_e_243, 0);
    V v_a_2417 = heff_field(v_e_243, 1);
    V v_b_2418 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ELet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2419 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_a_2417));
    V v_cell_2420 = heff_tag_re_n(v_ru_24e_243_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2416, v_t_2419, heff_hole()});
    V v_u_2421 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_2418, v_cell_2420, MK_INT(2LL)));
    heff_drop(v_u_2421);
    return v_cell_2420;
  }
  case TAG_ERecord: {
    V v_fs_2422 = heff_field(v_e_243, 0);
    V v_ts_2423 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam1, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_fs_2422));
    return heff_tag_re_n(v_ru_24e_243_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_t_2428, v_ts_2423});
  }
  case TAG_EProj: {
    V v_e2_2429 = heff_field(v_e_243, 0);
    V v_l_2430 = heff_field(v_e_243, 1);
    V v_sh_2431 = heff_field(v_e_243, 2);
    V v_t_2432 = heff_field(v_e_243, 3);
    V v_ru_24e_243_24EProj = heff_take_reuse_n(v_e_243, 15ULL, 4);
    V v_t_2433 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_e2_2429));
    return heff_tag_re_n(v_ru_24e_243_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_t_2433, v_l_2430, v_sh_2431, v_t_2432});
  }
  case TAG_ETag: {
    V v_t_2434 = heff_field(v_e_243, 0);
    V v_args_2435 = heff_field(v_e_243, 1);
    V v_ts_2436 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ETag = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam2, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_args_2435));
    return heff_tag_re_n(v_ru_24e_243_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2434, v_t_2438, v_ts_2436});
  }
  case TAG_EMatch: {
    V v_s_2439 = heff_field(v_e_243, 0);
    V v_arms_2440 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2441 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_s_2439));
    V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam3, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_arms_2440));
    return heff_tag_at_n(v_ru_24e_243_24EMatch, TAG_EMatch, 2, (V[]){v_t_2441, v_t_2447});
  }
  case TAG_EPrim: {
    return v_e_243;
  }
  case TAG_EPrimCall: {
    V v_p_2449 = heff_field(v_e_243, 0);
    V v_args_2450 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam4, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_args_2450));
    return heff_tag_re_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_p_2449, v_t_2452});
  }
  case TAG_ECall: {
    V v_g_2453 = heff_field(v_e_243, 0);
    V v_args_2454 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2456 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam5, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_args_2454));
    return heff_tag_re_n(v_ru_24e_243_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2453, v_t_2456});
  }
  case TAG_EInt: {
    return v_e_243;
  }
  case TAG_EFloat: {
    return v_e_243;
  }
  case TAG_EStr: {
    return v_e_243;
  }
  case TAG_EBytes: {
    return v_e_243;
  }
  case TAG_EFixed: {
    return v_e_243;
  }
  case TAG_EFloat32: {
    return v_e_243;
  }
  case TAG_EAbandon: {
    return v_e_243;
  }
  case TAG_EBool: {
    V v_c_2464 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EBool = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_t_2466 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam6, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}); V a_1 = v_c_2464; V r_ = (g_heff_2ecompile_2eir_2econdMap(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_tag_at_n(v_ru_24e_243_24EBool, TAG_EBool, 1, (V[]){v_t_2466});
  }
  case TAG_ESet: {
    V v_xs_2467 = heff_field(v_e_243, 0);
    V v_a_2468 = heff_field(v_e_243, 1);
    V v_b_2469 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ESet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2470 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_a_2468));
    V v_cell_2471 = heff_tag_re_n(v_ru_24e_243_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_2467, v_t_2470, heff_hole()});
    V v_u_2472 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(v_lit_240, v_lit_241, v_lit_242, v_b_2469, v_cell_2471, MK_INT(2LL)));
    heff_drop(v_u_2472);
    return v_cell_2471;
  }
  case TAG_EValues: {
    V v_es_2473 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24EValues = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_t_2475 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam7, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242)}), v_es_2473));
    return heff_tag_at_n(v_ru_24e_243_24EValues, TAG_EValues, 1, (V[]){v_t_2475});
  }
  case TAG_EFix: {
    return v_e_243;
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam0(V self, V *args) {
  V v_a_2414 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam1(V self, V *args) {
  V v_p_2424 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  switch (heff_tag_of(v_p_2424)) {
  case TAG_MkPair: {
    V v_l_2425 = heff_field(v_p_2424, 0);
    V v_e2_2426 = heff_field(v_p_2424, 1);
    V v_ru_24p_2424_24MkPair = heff_take_reuse_n(v_p_2424, 3ULL, 2);
    heff_clo_take(self, 3);
    V v_t_2427 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_e2_2426; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    return heff_tag_re_n(v_ru_24p_2424_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_2425, v_t_2427});
  }
  default: return heff_nomatch(v_p_2424);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam2(V self, V *args) {
  V v_a_2437 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2437; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam3(V self, V *args) {
  V v_a_2442 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  switch (heff_tag_of(v_a_2442)) {
  case TAG_MkArm: {
    V v_t_2443 = heff_field(v_a_2442, 0);
    V v_vs_2444 = heff_field(v_a_2442, 1);
    V v_b_2445 = heff_field(v_a_2442, 2);
    V v_ru_24a_2442_24MkArm = heff_take_reuse_n(v_a_2442, 7ULL, 3);
    heff_clo_take(self, 3);
    V v_t_2446 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_b_2445; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    return heff_tag_re_n(v_ru_24a_2442_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2443, v_vs_2444, v_t_2446});
  }
  default: return heff_nomatch(v_a_2442);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam4(V self, V *args) {
  V v_a_2451 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2451; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam5(V self, V *args) {
  V v_a_2455 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2455; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam6(V self, V *args) {
  V v_a_2465 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2465; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_lam7(V self, V *args) {
  V v_a_2474 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2474; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
}
Clo g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_entry, 2, 0};

V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_240, 0);
    V v_es_243 = heff_field(v_x2_240, 1);
    V v_t_244;
    if ((heff_dup(v_acc_241) == NTAG(TAG_True))) {
      heff_drop(v_acc_241);
      v_t_244 = NTAG(TAG_True);
    } else {
      heff_drop(v_acc_241);
      v_t_244 = (g_heff_2ecompile_2erunes_2ereads(v_e_242));
    }
    V t_0 = v_es_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_24tok2_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushFields_24tok2(V v_tok_240, V v_x1_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x1_241, 0);
    V v_fs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_e2_246 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_247 = v_e2_246;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V v_cell_248 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = ({ V a_0 = v_fs_244; V a_1 = v_rest_242; V a_2 = v_cell_248; V r_ = (g_heff_2ecompile_2eir_2epushFields_24dps(a_0, a_1, a_2)); heff_drop(v_rest_242); r_; });
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields_24tok2(a[0], a[1], a[2]);
}