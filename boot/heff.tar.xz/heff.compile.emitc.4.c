// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FlatAll 51900
#define TAG_FlatNone 33150
#define TAG_FlatSome 51022
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkCArm 24694
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_UFixed 18334
#define TAG_UFn 31401
#define TAG_UOp 31682
#define TAG_URel 1603
#define TAG_UToDouble 51807
#define LBL_arity 294440695
#define LBL_bounce 563936691
#define LBL_byFun 295539138
#define LBL_ctype 296362551
#define LBL_entry 298026124
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_includes 835398315
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_leaf 9813029
#define LBL_lent 9813446
#define LBL_module 878357911
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_ops 319788
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_result 1012715336
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_tuples 1084651734
#define LBL_words 314676931
#define LBL_workers 1757018875
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2eaddLam(V, V, V);
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eaddLam_clo;
V g_heff_2ecompile_2eemitc_2eargLine(V, V);
V g_heff_2ecompile_2eemitc_2eargLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLine_clo;
V g_heff_2ecompile_2eemitc_2eargLines(V, V);
V g_heff_2ecompile_2eemitc_2eargLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLines_clo;
V g_heff_2ecompile_2eemitc_2eargLines_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eargLines_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLines_24dps_clo;
V g_heff_2ecompile_2eemitc_2eargTypeNames(V);
V g_heff_2ecompile_2eemitc_2eargTypeNames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargTypeNames_clo;
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2eassertLine(V, V);
V g_heff_2ecompile_2eemitc_2eassertLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eassertLine_clo;
V g_heff_2ecompile_2eemitc_2ecBytesGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ecBytesGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecBytesGo_clo;
V g_heff_2ecompile_2eemitc_2ecaseLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecaseLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecaseLines_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2eglobalH(V, V, V);
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalH_clo;
V g_heff_2ecompile_2eemitc_2eglueProvider(V);
V g_heff_2ecompile_2eemitc_2eglueProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueProvider_clo;
V g_heff_2ecompile_2eemitc_2ehelperLines(V, V);
V g_heff_2ecompile_2eemitc_2ehelperLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehelperLines_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2ekeyHashGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo;
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(V, V, V);
V g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_clo;
V g_heff_2ecompile_2eemitc_2enamesTable(V, V);
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesTable_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2eperformCode(V);
V g_heff_2ecompile_2eemitc_2eperformCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eperformCode_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2epointersGo(V, V);
V g_heff_2ecompile_2eemitc_2epointersGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointersGo_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etupleArm(V, V, V);
V g_heff_2ecompile_2eemitc_2etupleArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleArm_clo;
V g_heff_2ecompile_2eemitc_2etupleDecl(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleDecl_clo;
V g_heff_2ecompile_2eemitc_2eunboxed(V);
V g_heff_2ecompile_2eemitc_2eunboxed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxed_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eowned_2elendingPrim(V);
V g_heff_2ecompile_2eowned_2elendingPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2elendingPrim_clo;
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_intShow_get(void);
V g_list_2eall_24s2069645224x1221092236(V);
V g_list_2eall_24s2069645224x1221092236_entry(V self, V *a);
extern Clo g_list_2eall_24s2069645224x1221092236_clo;
V g_list_2eany_24s1520931887x1308972177(V, V, V, V, V, V, V, V);
V g_list_2eany_24s1520931887x1308972177_entry(V self, V *a);
extern Clo g_list_2eany_24s1520931887x1308972177_clo;
V g_list_2eany_24s1606644238x788321190(V, V);
V g_list_2eany_24s1606644238x788321190_entry(V self, V *a);
extern Clo g_list_2eany_24s1606644238x788321190_clo;
V g_list_2eany_24s280395686x983781620(V);
V g_list_2eany_24s280395686x983781620_entry(V self, V *a);
extern Clo g_list_2eany_24s280395686x983781620_clo;
V g_list_2eany_24s63755471x810534073(V, V);
V g_list_2eany_24s63755471x810534073_entry(V self, V *a);
extern Clo g_list_2eany_24s63755471x810534073_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1323813142x1311067101(V, V, V, V);
V g_list_2efoldl_24f1323813142x1311067101_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1323813142x1311067101_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1520027297x1040032870(V, V);
V g_list_2efoldl_24s1520027297x1040032870_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1520027297x1040032870_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s949876182x1887521458(V);
V g_list_2ekeepIf_24s949876182x1887521458_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s949876182x1887521458_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1217399696x462307458(V, V, V);
V g_list_2emap_24f1217399696x462307458_entry(V self, V *a);
extern Clo g_list_2emap_24f1217399696x462307458_clo;
V g_list_2emap_24f1512150482x179770396(V, V, V, V);
V g_list_2emap_24f1512150482x179770396_entry(V self, V *a);
extern Clo g_list_2emap_24f1512150482x179770396_clo;
V g_list_2emap_24f230958709x841260712(V, V, V, V, V, V);
V g_list_2emap_24f230958709x841260712_entry(V self, V *a);
extern Clo g_list_2emap_24f230958709x841260712_clo;
V g_list_2emap_24s1009200955x251267316(V);
V g_list_2emap_24s1009200955x251267316_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_clo;
V g_list_2emap_24s1386329375x1773300759(V);
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_clo;
V g_list_2emap_24s1518131677x2038133191(V, V, V);
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_clo;
V g_list_2emap_24s1566016224x493905666(V, V, V, V);
V g_list_2emap_24s1566016224x493905666_entry(V self, V *a);
extern Clo g_list_2emap_24s1566016224x493905666_clo;
V g_list_2emap_24s1613211967x1923010103(V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_clo;
V g_list_2emap_24s1936967306x1304226505(V, V, V, V);
V g_list_2emap_24s1936967306x1304226505_entry(V self, V *a);
extern Clo g_list_2emap_24s1936967306x1304226505_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2010608108x1221393166(V);
V g_list_2emap_24s2010608108x1221393166_entry(V self, V *a);
extern Clo g_list_2emap_24s2010608108x1221393166_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s379205986x2089287346(V, V, V, V, V, V, V, V);
V g_list_2emap_24s379205986x2089287346_entry(V self, V *a);
extern Clo g_list_2emap_24s379205986x2089287346_clo;
V g_list_2emap_24s430074199x1834682414(V, V, V, V);
V g_list_2emap_24s430074199x1834682414_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s693155583x821663253(V, V, V);
V g_list_2emap_24s693155583x821663253_entry(V self, V *a);
extern Clo g_list_2emap_24s693155583x821663253_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f292729551x60683815(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f292729551x60683815_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f292729551x60683815_clo;
V g_prelude_2e_2b_2b_24f354580856x2119298159(V, V, V, V);
V g_prelude_2e_2b_2b_24f354580856x2119298159_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f354580856x2119298159_clo;
V g_prelude_2e_2b_2b_24f603353378x1069129212(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f603353378x1069129212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f603353378x1069129212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2etagsLbls_str0, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etagsLbls_str1, 4, "True");
Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etagsLbls_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2etagsLbls(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_argv_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){v_f_245, v_argv_246})));
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_248, v_t_247));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return (g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(v_a_2410, v_b_2411, ((V)&g_heff_2ecompile_2eemitc_2etagsLbls_clo)));
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    V v_ls_2414 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2412)));
    V v_t_2415 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2412));
    V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_x2_2417 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2416, v_t_2415));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_ts_2418 = heff_field(v_x2_2417, 0);
      V v_ls2_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      V v_t_2420 = (g_prelude_2e_2b_2b(v_ls_2414, v_ls2_2419));
      return heff_tag_re_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_ts_2418, v_t_2420});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  case TAG_EProj: {
    V v_e_2421 = heff_field(v_x1_240, 0);
    V v_l_2422 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 4);
    V v_x2_2425 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_e_2421));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_ts_2426 = heff_field(v_x2_2425, 0);
      V v_ls2_2427 = heff_field(v_x2_2425, 1);
      V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
      return heff_tag_re_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_ts_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_l_2422, v_ls2_2427})});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  case TAG_ETag: {
    V v_t_2428 = heff_field(v_x1_240, 0);
    V v_argv_2429 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2429));
    V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_x2_2433 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2432, v_t_2431));
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_MkPair: {
      V v_ts2_2434 = heff_field(v_x2_2433, 0);
      V v_ls_2435 = heff_field(v_x2_2433, 1);
      V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
      V v_t_2436;
      if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2428, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2428, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)) {
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_t_2428);
        v_t_2436 = NTAG(TAG_Nil);
      }
      V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2436, v_ts2_2434));
      return heff_tag_re_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2437, v_ls_2435});
    }
    default: return heff_nomatch(v_x2_2433);
    }
  }
  case TAG_EMatch: {
    V v_s_2438 = heff_field(v_x1_240, 0);
    V v_arms_2439 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2440 = (g_list_2ekeepIf_24s949876182x1887521458(heff_dup(v_arms_2439)));
    V v_ts_2441 = (g_list_2emap_24s1009200955x251267316(v_t_2440));
    V v_t_2442 = (g_list_2emap_24s60612435x257154841(v_arms_2439));
    V v_es_2443 = heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2438, v_t_2442});
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2443));
    V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_x2_2446 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2445, v_t_2444));
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_MkPair: {
      V v_ts2_2447 = heff_field(v_x2_2446, 0);
      V v_ls_2448 = heff_field(v_x2_2446, 1);
      V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
      V v_t_2449 = ({ V a_0 = v_ts2_2447; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(35LL); V a_4 = v_ts_2441; V r_ = (g_prelude_2e_2b_2b_24f292729551x60683815(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts2_2447); r_; });
      return heff_tag_re_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2449, v_ls_2448});
    }
    default: return heff_nomatch(v_x2_2446);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_argv_2452 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2452));
    V v_t_2454 = heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2454, v_t_2453));
  }
  case TAG_ECall: {
    V v_argv_2456 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_t_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_2456));
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2458, v_t_2457));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_ru_24x1_240_24EFixed = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_EBool: {
    V v_c_2466 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_es_2467 = ({ V a_0 = v_c_2466; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2466); r_; });
    V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2467));
    V v_t_2469 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_x2_2470 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2469, v_t_2468));
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_MkPair: {
      V v_ts2_2471 = heff_field(v_x2_2470, 0);
      V v_ls_2472 = heff_field(v_x2_2470, 1);
      V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
      V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etagsLbls_str0), NTAG(TAG_Nil)});
      V v_t_2474 = ({ V a_0 = v_ts2_2471; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(35LL); V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etagsLbls_str1), v_t_2473}); V r_ = (g_prelude_2e_2b_2b_24f292729551x60683815(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts2_2471); r_; });
      return heff_tag_re_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2474, v_ls_2472});
    }
    default: return heff_nomatch(v_x2_2470);
    }
  }
  case TAG_ESet: {
    V v_a_2476 = heff_field(v_x1_240, 1);
    V v_b_2477 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return (g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(v_a_2476, v_b_2477, ((V)&g_heff_2ecompile_2eemitc_2etagsLbls_clo)));
  }
  case TAG_EValues: {
    V v_es_2478 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2478));
    V v_t_2480 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return (g_list_2efoldl_24s1659194469x1936830512(v_t_2480, v_t_2479));
  }
  case TAG_EFix: {
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etagsLbls(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eidentAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eidentAt_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eidentAt(V v_text_240, V v_start_241, V v_i_242) {
top: ;
  if ((heff_intLt_c_lent(v_i_242, heff_strLength_lent(v_text_240, 0), 2) && ({ V v_c_243 = heff_strByteAt_lent(v_text_240, v_i_242, 0); int c_ = ((((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)57ULL))))) || (heff_unbox_word(heff_strByteAt_lent(v_text_240, v_i_242, 0)) == ((int64_t)95ULL))); heff_drop(v_c_243); c_; }))) {
    V t_0 = v_text_240;
    V t_1 = v_start_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    v_text_240 = t_0;
    v_start_241 = t_1;
    v_i_242 = t_2;
    goto top;
  } else {
    return heff_strSlice_lent(v_text_240, v_start_241, v_i_242, 4);
  }
}
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eidentAt(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str1, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str2, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str3, 4, "_str");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str6, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str7, 3, "\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estrLit_str8, 1, ")");
Clo g_heff_2ecompile_2eemitc_2estrLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estrLit_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estrLit(V v_mac_240, V v_str_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2ecBytesGo(v_str_241, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estrLit_str0)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estrLit_str1), heff_dup(heff_rfield(v_s_242, 0)));
  V v_t_245 = heff_intShow(heff_dup(heff_rfield(v_s_242, 4)));
  V v_t_246 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str2)), v_t_245);
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_242, 4)), MK_INT(1LL));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_s_242, 0)), ((V)&g_heff_2ecompile_2eemitc_2estrLit_str3));
  V v_t_249 = heff_intShow(heff_take_field(v_s_242, 4));
  V v_t_2410 = heff_strAppend(heff_strAppend(v_mac_240, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str4)), heff_strAppend(v_t_248, v_t_249));
  V v_t_2411 = heff_intShow(heff_strLength_lent(v_str_241, 0));
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str5)), v_t_2411);
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str6)), v_t_243);
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str7))});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_s_242, 5)});
  V v_t_2416 = ({ V rv_4 = v_t_247; V rv_5 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_242, 207ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 61695u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2estrLit_str8)), v_t_2416});
}
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2estrLit(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2eaddLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eaddLam_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eaddLam(V v_proto_240, V v_def_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), v_def_241});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_take_field(v_s_242, 2)});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_242, 0)), v_proto_240});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_take_field(v_s_242, 3)});
  V v_t_247 = ({ V rv_2 = v_t_244; V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_242, 243ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 65295u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eaddLam(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str0, 1, "1");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str2, 2, "_c");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str5, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str6, 3, "_c(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str8, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str9, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str10, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str11, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str13, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str14, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str15, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str16, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str17, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str18, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str27, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str30, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str31, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str32, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str34, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str35, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str36, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str37, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str38, 19, " == NTAG(TAG_True))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str39, 1, "!");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str41, 4, " && ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str42, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str44, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str45, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str47, 3, " \? ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str48, 3, " : ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str49, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str50, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str51, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str52, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str53, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str54, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str55, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str56, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str57, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str58, 3, "({ ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str59, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str60, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str61, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str62, 11, "; int c_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str63, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etestC_str64, 6, "c_; })");
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etestC_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_lam1, 1, 0};
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etestC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etestC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etestC(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CondTrue: {
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam0_clo);
  }
  case TAG_CondFalse: {
    return ((V)&g_heff_2ecompile_2eemitc_2etestC_lam1_clo);
  }
  case TAG_CondRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eowned_2elendingPrim(v_p_244));
    V v_t_248;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2eall_24s2069645224x1221092236(v_es_245));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = (g_list_2eany_24s63755471x810534073(v_es_245, v_es_245));
      } else {
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_246);
      v_t_248 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return ({ V a_0 = heff_dup(v_k_240); V a_1 = v_p_244; V a_2 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str2); V a_3 = v_es_245; V r_ = (g_heff_2ecompile_2eemitc_2elentPrimC(a_0, a_1, a_2, a_3)); heff_drop(v_p_244); r_; });
    } else {
      heff_drop(v_t_248);
      V v_m_249 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_dup(heff_rfield(v_k_240, 0)), v_es_245));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam2, 1, 2, (V[]){v_m_249, v_p_244});
    }
  }
  case TAG_CondRelU: {
    V v_p_2420 = heff_field(v_x2_241, 0);
    V v_es_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2422 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_dup(heff_rfield(v_k_240, 0)), v_es_2421));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam3, 1, 2, (V[]){v_m_2422, v_p_2420});
  }
  case TAG_CondBool: {
    V v_e_2449 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_2449}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam4, 1, 1, (V[]){v_m_2450});
  }
  case TAG_CondNot: {
    V v_c_2456 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2457 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_2456));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam5, 1, 1, (V[]){v_m_2457});
  }
  case TAG_CondIf: {
    V v_a_2462 = heff_field(v_x2_241, 0);
    V v_b_2463 = heff_field(v_x2_241, 1);
    V v_x23_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    switch (heff_tag_of(v_x23_2464)) {
    case TAG_CondFalse: {
      V v_m_2465 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_a_2462));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam6, 1, 3, (V[]){v_m_2465, heff_dup(v_k_240), v_b_2463});
    }
    default: {
      switch (heff_tag_of(v_b_2463)) {
      case TAG_CondTrue: {
        V v_m_2476 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_a_2462));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam7, 1, 3, (V[]){v_m_2476, heff_dup(v_k_240), v_x23_2464});
      }
      default: {
        V v_m_2487 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_a_2462));
        return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam8, 1, 4, (V[]){v_m_2487, heff_dup(v_k_240), v_b_2463, v_x23_2464});
      }
      }
    }
    }
  }
  case TAG_CondLet: {
    V v_x_24103 = heff_field(v_x2_241, 0);
    V v_e_24104 = heff_field(v_x2_241, 1);
    V v_c_24105 = heff_field(v_x2_241, 2);
    V v_drops_24106 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_24107 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_24104}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etestC_lam9, 1, 5, (V[]){v_m_24107, heff_dup(v_k_240), v_c_24105, v_x_24103, v_drops_24106});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2etestC(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2etestC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str0), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etestC_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etestC_str1), v_s_243});
}
V g_heff_2ecompile_2eemitc_2etestC_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_t_2414 = ({ V a_0 = v_p_244; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_244); r_; });
    V v_t_2417;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x_2412, 0);
      V v_xs_2416 = heff_field(v_x_2412, 1);
      heff_take_n(v_x_2412, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str4); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str5), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2etestC_str6));
    V v_x_2419 = heff_strAppend(heff_strAppend(v_t_2418, v_t_2417), ((V)&g_heff_2ecompile_2eemitc_2etestC_str7));
    return heff_tag_re_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2419, v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_p_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_p_2427 = v_p_2420;
    V v_vs_2428 = v_x_2425;
    V v_u_2429 = (g_heff_2ecompile_2eemitc_2eunboxed(v_p_2427));
    V v_op_2435;
    switch (heff_tag_of(v_u_2429)) {
    case TAG_UFixed: {
      V v_op_2431 = heff_field(v_u_2429, 1);
      heff_take_n(v_u_2429, 2ULL, 2);
      switch (heff_tag_of(v_op_2431)) {
      case TAG_OpAdd: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str8);
        break;
      }
      case TAG_OpSub: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str9);
        break;
      }
      case TAG_OpMul: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str10);
        break;
      }
      case TAG_OpDiv: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str11);
        break;
      }
      case TAG_OpRem: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str12);
        break;
      }
      case TAG_OpEq: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str13);
        break;
      }
      case TAG_OpLt: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str14);
        break;
      }
      case TAG_OpLe: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str15);
        break;
      }
      case TAG_OpAnd: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str16);
        break;
      }
      case TAG_OpOr: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str17);
        break;
      }
      case TAG_OpXor: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str18);
        break;
      }
      case TAG_OpShl: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str19);
        break;
      }
      case TAG_OpShr: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str20);
        break;
      }
      case TAG_OpShow: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str21);
        break;
      }
      case TAG_OpFromInt: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str22);
        break;
      }
      case TAG_OpToInt: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str23);
        break;
      }
      case TAG_OpSqrt: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str24);
        break;
      }
      case TAG_OpFromFloat: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str25);
        break;
      }
      case TAG_OpToFloat: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str26);
        break;
      }
      case TAG_OpFloor: {
        v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str27);
        break;
      }
      default: heff_nomatch(v_op_2431);
      }
      break;
    }
    case TAG_URel: {
      V v_op_2432 = heff_field(v_u_2429, 0);
      heff_take_n(v_u_2429, 1ULL, 1);
      v_op_2435 = v_op_2432;
      break;
    }
    case TAG_UOp: {
      heff_take_n(v_u_2429, 0ULL, 1);
      v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str28);
      break;
    }
    case TAG_UFn: {
      heff_take_n(v_u_2429, 0ULL, 1);
      v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str29);
      break;
    }
    case TAG_UToDouble: {
      v_op_2435 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str30);
      break;
    }
    default: heff_nomatch(v_u_2429);
    }
    V v_t_2438;
    switch (heff_tag_of(v_vs_2428)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_dup(heff_field(v_vs_2428, 0));
      v_t_2438 = v_x_2436;
      break;
    }
    default: heff_nomatch(v_vs_2428);
    }
    HeffT3 v_t_2439 = ({ V a_0 = MK_INT(1LL); V a_1 = v_vs_2428; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_vs_2428); r_; });
    {
      V v_field_2441 = v_t_2439.f[1];
      V v_field_2442 = v_t_2439.f[2];
      int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
      V v_t_2445;
      if ((v_tag_2440 == ((int64_t)0ULL))) {
        V v_x_2443 = v_field_2441;
        V v_x12_2444 = v_field_2442;
        heff_drop(v_x12_2444);
        v_t_2445 = v_x_2443;
      } else {
        heff_drop(v_field_2441);
        heff_drop(v_field_2442);
        v_t_2445 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str32);
      }
      V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str33), v_t_2438), ((V)&g_heff_2ecompile_2eemitc_2etestC_str34));
      V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2446, v_op_2435), ((V)&g_heff_2ecompile_2eemitc_2etestC_str35));
      V v_x_2448 = heff_strAppend(heff_strAppend(v_t_2447, v_t_2445), ((V)&g_heff_2ecompile_2eemitc_2etestC_str36));
      return heff_tag_re_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2448, v_s_2426});
    }
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam4(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    V v_t_2455 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str37), v_x_2453), ((V)&g_heff_2ecompile_2eemitc_2etestC_str38));
    return heff_tag_re_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2455, v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam5(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str39), v_x_2460), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam6(V self, V *args) {
  V v_s_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_s_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_s_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    V v_t_2470 = ({ V a_0 = v_k_240; V a_1 = v_b_2463; V r_ = (g_heff_2ecompile_2eemitc_2etestC(a_0, a_1)); heff_drop_rec(v_k_240, 6); r_; });
    V v_x2_2471 = heff_tr(heff_call(v_t_2470, 1, (V[]){v_s_2469}));
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_s_2473 = heff_field(v_x2_2471, 1);
      heff_take_n(v_x2_2471, 3ULL, 2);
      V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str40), v_x_2468), ((V)&g_heff_2ecompile_2eemitc_2etestC_str41));
      V v_t_2475 = heff_strAppend(heff_strAppend(v_t_2474, v_x_2472), ((V)&g_heff_2ecompile_2eemitc_2etestC_str42));
      return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){v_t_2475, v_s_2473});
    }
    default: return heff_nomatch(v_x2_2471);
    }
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam7(V self, V *args) {
  V v_s_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x23_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_s_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    V v_t_2481 = ({ V a_0 = v_k_240; V a_1 = v_x23_2464; V r_ = (g_heff_2ecompile_2eemitc_2etestC(a_0, a_1)); heff_drop_rec(v_k_240, 6); r_; });
    V v_x2_2482 = heff_tr(heff_call(v_t_2481, 1, (V[]){v_s_2480}));
    switch (heff_tag_of(v_x2_2482)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_field(v_x2_2482, 0);
      V v_s_2484 = heff_field(v_x2_2482, 1);
      heff_take_n(v_x2_2482, 3ULL, 2);
      V v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str43), v_x_2479), ((V)&g_heff_2ecompile_2eemitc_2etestC_str44));
      V v_t_2486 = heff_strAppend(heff_strAppend(v_t_2485, v_x_2483), ((V)&g_heff_2ecompile_2eemitc_2etestC_str45));
      return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){v_t_2486, v_s_2484});
    }
    default: return heff_nomatch(v_x2_2482);
    }
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam8(V self, V *args) {
  V v_s_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_b_2463 = heff_env(self)[2];
  V v_x23_2464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_s_2488}));
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    V v_s_2491 = heff_field(v_x2_2489, 1);
    V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
    V v_t_2492 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_b_2463));
    V v_x2_2493 = heff_tr(heff_call(v_t_2492, 1, (V[]){v_s_2491}));
    switch (heff_tag_of(v_x2_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x2_2493, 0);
      V v_s_2495 = heff_field(v_x2_2493, 1);
      heff_take_n(v_x2_2493, 3ULL, 2);
      V v_t_2496 = ({ V a_0 = v_k_240; V a_1 = v_x23_2464; V r_ = (g_heff_2ecompile_2eemitc_2etestC(a_0, a_1)); heff_drop_rec(v_k_240, 6); r_; });
      V v_x2_2497 = heff_tr(heff_call(v_t_2496, 1, (V[]){v_s_2495}));
      switch (heff_tag_of(v_x2_2497)) {
      case TAG_MkPair: {
        V v_x_2498 = heff_field(v_x2_2497, 0);
        V v_s_2499 = heff_field(v_x2_2497, 1);
        heff_take_n(v_x2_2497, 3ULL, 2);
        V v_t_24100 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str46), v_x_2490), ((V)&g_heff_2ecompile_2eemitc_2etestC_str47));
        V v_t_24101 = heff_strAppend(heff_strAppend(v_t_24100, v_x_2494), ((V)&g_heff_2ecompile_2eemitc_2etestC_str48));
        V v_t_24102 = heff_strAppend(heff_strAppend(v_t_24101, v_x_2498), ((V)&g_heff_2ecompile_2eemitc_2etestC_str49));
        return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){v_t_24102, v_s_2499});
      }
      default: return heff_nomatch(v_x2_2497);
      }
    }
    default: return heff_nomatch(v_x2_2493);
    }
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_heff_2ecompile_2eemitc_2etestC_lam9(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_c_24105 = heff_env(self)[2];
  V v_x_24103 = heff_env(self)[3];
  V v_drops_24106 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24109 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    V v_ru_24x2_24109_24MkPair = heff_take_reuse_n(v_x2_24109, 3ULL, 2);
    V v_t_24112 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_24105));
    V v_x2_24113 = heff_tr(heff_call(v_t_24112, 1, (V[]){v_s_24111}));
    switch (heff_tag_of(v_x2_24113)) {
    case TAG_MkPair: {
      V v_x_24114 = heff_field(v_x2_24113, 0);
      V v_s_24115 = heff_field(v_x2_24113, 1);
      heff_take_n(v_x2_24113, 3ULL, 2);
      V v_t_24116 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_x_24103)}));
      V v_t_24117 = ({ V a_0 = v_x_24103; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str50); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_24103); r_; });
      V v_x2_24118 = (g_list_2emap_24s379205986x2089287346(((V)&g_heff_2ecompile_2eemitc_2etestC_str51), ((V)&g_heff_2ecompile_2eemitc_2etestC_str52), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etestC_str53), ((V)&g_heff_2ecompile_2eemitc_2etestC_str54), ((V)&g_heff_2ecompile_2eemitc_2etestC_str55), v_drops_24106));
      V v_t_24121;
      switch (heff_tag_of(v_x2_24118)) {
      case TAG_Nil: {
        v_t_24121 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str56);
        break;
      }
      case TAG_Cons: {
        V v_x_24119 = heff_field(v_x2_24118, 0);
        V v_xs_24120 = heff_field(v_x2_24118, 1);
        heff_take_n(v_x2_24118, 3ULL, 2);
        v_t_24121 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etestC_str57); V a_1 = v_x_24119; V a_2 = v_xs_24120; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24120); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24118);
      }
      V v_t_24122 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str58), v_t_24116), ((V)&g_heff_2ecompile_2eemitc_2etestC_str59));
      V v_t_24123 = heff_strAppend(v_t_24122, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etestC_str60), v_t_24117));
      V v_t_24124 = heff_strAppend(heff_strAppend(v_t_24123, ((V)&g_heff_2ecompile_2eemitc_2etestC_str61)), v_x_24110);
      V v_t_24125 = heff_strAppend(heff_strAppend(v_t_24124, ((V)&g_heff_2ecompile_2eemitc_2etestC_str62)), v_x_24114);
      V v_t_24126 = heff_strAppend(heff_strAppend(v_t_24125, ((V)&g_heff_2ecompile_2eemitc_2etestC_str63)), v_t_24121);
      V v_x_24127 = heff_strAppend(v_t_24126, ((V)&g_heff_2ecompile_2eemitc_2etestC_str64));
      return heff_tag_at_n(v_ru_24x2_24109_24MkPair, TAG_MkPair, 2, (V[]){v_x_24127, v_s_24115});
    }
    default: return heff_nomatch(v_x2_24113);
    }
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str0, 10, "default: {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str2, 5, "case ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str3, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str4, 3, ": {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str6, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str7, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str8, 11, "heff_take_n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str10, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str11, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str12, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str15, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str16, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str17, 2, "V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str18, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str19, 20, " = heff_take_reuse_n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str20, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str21, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str22, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str23, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str24, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str25, 8, "  break;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2earmF_str26, 1, "}");
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2earmF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2earmF_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2earmF(V v_k_240, V v_sv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_fields_244 = heff_field(v_x3_242, 1);
    V v_flats_245 = heff_field(v_x3_242, 2);
    V v_sure_246 = heff_field(v_x3_242, 3);
    V v_plain_247 = heff_field(v_x3_242, 4);
    V v_take_248 = heff_field(v_x3_242, 5);
    V v_body_249 = heff_field(v_x3_242, 6);
    V v_leaves_2410 = heff_field(v_x3_242, 7);
    V v_m_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){heff_dup(v_body_249)}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2earmF_lam0, 1, 10, (V[]){v_m_2411, heff_dup(v_t_243), v_sv_241, heff_dup(v_plain_247), heff_dup(v_fields_244), v_k_240, heff_dup(v_sure_246), heff_dup(v_flats_245), heff_dup(v_take_248), heff_dup(v_leaves_2410)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2earmF(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2earmF_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_sv_241 = heff_env(self)[2];
  V v_plain_247 = heff_env(self)[3];
  V v_fields_244 = heff_env(self)[4];
  V v_k_240 = heff_env(self)[5];
  V v_sure_246 = heff_env(self)[6];
  V v_flats_245 = heff_env(self)[7];
  V v_take_248 = heff_env(self)[8];
  V v_leaves_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2418;
    if (heff_strEq_c(heff_dup(v_t_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()))) {
      heff_drop(v_t_243);
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str0);
    } else {
      V v_t_2416 = ({ V a_0 = v_t_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str1); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_243); r_; });
      V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str2), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str3), v_t_2416));
      v_t_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2earmF_str4));
    }
    V v_t_2419 = (g_list_2emap_24s1518131677x2038133191(heff_dup(v_sv_241), v_plain_247, v_fields_244));
    V v_t_2420 = (g_list_2emap_24s1936967306x1304226505(v_k_240, heff_dup(v_sv_241), v_sure_246, v_flats_245));
    V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2420));
    V v_sv_2422 = v_sv_241;
    V v_x2_2423 = v_take_248;
    V v_t_2443;
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_TakeNone: {
      heff_drop(v_sv_2422);
      v_t_2443 = NTAG(TAG_Nil);
      break;
    }
    case TAG_TakeN: {
      V v_fl_2424 = heff_field(v_x2_2423, 0);
      V v_mask_2425 = heff_field(v_x2_2423, 1);
      V v_n_2426 = heff_field(v_x2_2423, 2);
      heff_take_n(v_x2_2423, 7ULL, 3);
      V v_t_2427;
      switch (heff_tag_of(v_fl_2424)) {
      case TAG_FlatNone: {
        v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str5);
        break;
      }
      case TAG_FlatSome: {
        v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str6);
        break;
      }
      case TAG_FlatAll: {
        v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str7);
        break;
      }
      default: heff_nomatch(v_fl_2424);
      }
      V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str8), v_t_2427), ((V)&g_heff_2ecompile_2eemitc_2earmF_str9));
      V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, v_sv_2422), ((V)&g_heff_2ecompile_2eemitc_2earmF_str10));
      V v_t_2430 = heff_strAppend(v_t_2429, heff_intShow(v_mask_2425));
      V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2earmF_str11)), heff_intShow(v_n_2426));
      v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemitc_2earmF_str12)), NTAG(TAG_Nil)});
      break;
    }
    case TAG_TakeKeep: {
      V v_fl_2432 = heff_field(v_x2_2423, 0);
      V v_ru_2433 = heff_field(v_x2_2423, 1);
      V v_mask_2434 = heff_field(v_x2_2423, 2);
      V v_n_2435 = heff_field(v_x2_2423, 3);
      heff_take_n(v_x2_2423, 15ULL, 4);
      V v_t_2436 = ({ V a_0 = v_ru_2433; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str13); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_ru_2433); r_; });
      V v_t_2437;
      switch (heff_tag_of(v_fl_2432)) {
      case TAG_FlatNone: {
        v_t_2437 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str14);
        break;
      }
      case TAG_FlatSome: {
        v_t_2437 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str15);
        break;
      }
      case TAG_FlatAll: {
        v_t_2437 = ((V)&g_heff_2ecompile_2eemitc_2earmF_str16);
        break;
      }
      default: heff_nomatch(v_fl_2432);
      }
      V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str17), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2earmF_str18), v_t_2436));
      V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2earmF_str19)), v_t_2437);
      V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2eemitc_2earmF_str20)), v_sv_2422);
      V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2earmF_str21)), heff_intShow(v_mask_2434));
      V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2earmF_str22)), heff_intShow(v_n_2435));
      v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2eemitc_2earmF_str23)), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x2_2423);
    }
    V v_t_2444 = (g_list_2emap_24f1217399696x462307458(((V)&g_heff_2ecompile_2eemitc_2earmF_str24), v_t_2443, v_x_2414));
    V v_t_2445;
    if ((heff_dup(v_leaves_2410) == NTAG(TAG_True))) {
      heff_drop(v_leaves_2410);
      v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str25), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_leaves_2410);
      v_t_2445 = NTAG(TAG_Nil);
    }
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2earmF_str26), NTAG(TAG_Nil)});
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2445, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_t_2444, v_t_2447));
    V v_ys_2449 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2448));
    return heff_tag_re_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_ys_2449}), v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str1, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str2, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str3, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str4, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str5, 2, "])");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str6, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str7, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str8, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str9, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str10, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str11, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str12, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str13, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str14, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str15, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str16, 3, "]);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str17, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str18, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleArm_str19, 1, "{");
V g_heff_2ecompile_2eemitc_2etupleArm_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2etupleArm_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2etupleArm_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etupleArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleArm_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2etupleArm(V v_k_240, V v_sv_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkCArm: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_fields_244 = heff_field(v_x3_242, 1);
    V v_flats_245 = heff_field(v_x3_242, 2);
    V v_plain_247 = heff_field(v_x3_242, 4);
    V v_take_248 = heff_field(v_x3_242, 5);
    V v_body_249 = heff_field(v_x3_242, 6);
    V v_m_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){heff_dup(v_body_249)}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etupleArm_lam0, 1, 8, (V[]){v_m_2411, heff_dup(v_plain_247), v_sv_241, heff_dup(v_fields_244), heff_dup(v_t_243), v_k_240, heff_dup(v_flats_245), heff_dup(v_take_248)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2etupleArm_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2etupleArm(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2etupleArm_lam1(V self, V *args) {
  V v_p_2416 = args[0];
  V v_plain_247 = heff_env(self)[0];
  V v_sv_241 = heff_env(self)[1];
  V v_t_2419;
  switch (heff_tag_of(v_p_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_dup(heff_field(v_p_2416, 0));
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_p_2416);
  }
  V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2419); r_; });
  V v_t_2430;
  heff_clo_take(self, 2);
  if ((heff_dup(v_plain_247) == NTAG(TAG_True))) {
    heff_drop(v_plain_247);
    V v_t_2423;
    switch (heff_tag_of(v_p_2416)) {
    case TAG_MkPair: {
      V v_y_2422 = heff_field(v_p_2416, 1);
      heff_take_n(v_p_2416, 2ULL, 2);
      v_t_2423 = v_y_2422;
      break;
    }
    default: heff_nomatch(v_p_2416);
    }
    V v_t_2424 = heff_strAppend(heff_strAppend(v_sv_241, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str1)), heff_intShow(v_t_2423));
    v_t_2430 = heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str2));
  } else {
    heff_drop(v_plain_247);
    V v_t_2427;
    switch (heff_tag_of(v_p_2416)) {
    case TAG_MkPair: {
      V v_y_2426 = heff_field(v_p_2416, 1);
      heff_take_n(v_p_2416, 2ULL, 2);
      v_t_2427 = v_y_2426;
      break;
    }
    default: heff_nomatch(v_p_2416);
    }
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str3), v_sv_241), ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str4));
    V v_t_2429 = heff_strAppend(v_t_2428, heff_intShow(v_t_2427));
    v_t_2430 = heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str5));
  }
  V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str6), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str7), v_t_2420));
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str8)), v_t_2430);
  return heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str9));
}
V g_heff_2ecompile_2eemitc_2etupleArm_lam2(V self, V *args) {
  V v_i_2448 = args[0];
  V v_mask_2445 = heff_env(self)[0];
  V v_kinds_2442 = heff_env(self)[1];
  V v_t_2449 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_2448)));
  heff_clo_take(self, 2);
  V v_t_2450 = heff_intMod(heff_intDiv(v_mask_2445, v_t_2449), MK_INT(2LL));
  V v_x1_2451 = heff_bool((heff_peek_word(v_t_2450) == ((int64_t)1ULL)));
  heff_drop(v_t_2450);
  if (!(heff_dup(v_x1_2451) == NTAG(TAG_True))) {
    heff_drop(v_x1_2451);
    HeffT3 v_t_2452 = ({ V a_0 = v_i_2448; V a_1 = v_kinds_2442; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_kinds_2442); r_; });
    {
      V v_field_2454 = v_t_2452.f[1];
      V v_field_2455 = v_t_2452.f[2];
      int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
      if ((v_tag_2453 == ((int64_t)0ULL))) {
        V v_x_2456 = v_field_2454;
        V v_x12_2457 = v_field_2455;
        heff_drop(v_x12_2457);
        switch (heff_tag_of(v_x_2456)) {
        case TAG_RepV: {
          return NTAG(TAG_True);
        }
        case TAG_RepFix: {
          heff_take_n(v_x_2456, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_RepF64: {
          return NTAG(TAG_False);
        }
        case TAG_RepInt: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x_2456);
        }
      } else {
        heff_drop(v_field_2454);
        heff_drop(v_field_2455);
        return NTAG(TAG_True);
      }
    }
  } else {
    heff_drop(v_i_2448);
    heff_drop(v_kinds_2442);
    heff_drop(v_x1_2451);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2eemitc_2etupleArm_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_plain_247 = heff_env(self)[1];
  V v_sv_241 = heff_env(self)[2];
  V v_fields_244 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_k_240 = heff_env(self)[5];
  V v_flats_245 = heff_env(self)[6];
  V v_take_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2etupleArm_lam1, 1, 2, (V[]){v_plain_247, heff_dup(v_sv_241)}), v_fields_244));
    V v_s_2434 = heff_strSlice_lent(v_t_243, MK_INT(1LL), heff_strLength_lent(v_t_243, 0), 6);
    V v_t_2435 = ({ V a_0 = v_s_2434; V a_1 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str10); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str11), v_s_2434, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_2434); r_; });
    V v_t_2436 = (g_list_2emap_24s2010608108x1221393166(v_t_2435));
    V v_t_2437 = ({ V a_0 = v_k_240; V a_1 = heff_dup(v_sv_241); V a_2 = v_t_2436; V a_3 = v_flats_245; V r_ = (g_list_2emap_24s430074199x1834682414(a_0, a_1, a_2, a_3)); heff_drop(v_t_2436); r_; });
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2437));
    V v_sv_2439 = v_sv_241;
    V v_s_2440 = heff_strSlice(heff_dup(v_t_243), MK_INT(1LL), heff_strLength(v_t_243));
    V v_t_2441 = ({ V a_0 = v_s_2440; V a_1 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str12); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2etupleArm_str13), v_s_2440, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_2440); r_; });
    V v_kinds_2442 = (g_list_2emap_24s2010608108x1221393166(v_t_2441));
    V v_t_2443 = v_take_248;
    V v_t_2463;
    switch (heff_tag_of(v_t_2443)) {
    case TAG_TakeNone: {
      heff_drop(v_sv_2439);
      heff_drop(v_kinds_2442);
      v_t_2463 = NTAG(TAG_Nil);
      break;
    }
    case TAG_TakeN: {
      V v_mask_2445 = heff_field(v_t_2443, 1);
      V v_n_2446 = heff_field(v_t_2443, 2);
      heff_take_n(v_t_2443, 6ULL, 3);
      V v_t_2447 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2446, MK_INT(1LL))));
      v_t_2463 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str14); V a_1 = v_sv_2439; V a_2 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str15); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str16); V b_4 = heff_clo_n(g_heff_2ecompile_2eemitc_2etupleArm_lam2, 1, 2, (V[]){v_mask_2445, v_kinds_2442}); V a_5 = v_t_2447; V r_ = (g_list_2emap_24f230958709x841260712(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(v_sv_2439); heff_drop(b_4); r_; });
      break;
    }
    case TAG_TakeKeep: {
      heff_take_n(v_t_2443, 0ULL, 4);
      heff_drop(v_sv_2439);
      heff_drop(v_kinds_2442);
      v_t_2463 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2443);
    }
    V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleArm_str17), NTAG(TAG_Nil)});
    V v_t_2465 = (g_prelude_2e_2b_2b_24f354580856x2119298159(v_t_2464, ((V)&g_heff_2ecompile_2eemitc_2etupleArm_str18), v_t_2463, v_x_2414));
    V v_ys_2466 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2465));
    return heff_tag_re_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleArm_str19), v_ys_2466}), v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str0, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamList_str5, 2, ", ");
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eparamList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eparamList_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eparamList(V v_k_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str0);
  }
  case TAG_Cons: {
    V v_x2_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eparamList_lam0, 1, 1, (V[]){v_k_240}), v_xs_241));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eparamList_str4);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eparamList_str5); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eparamList(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eparamList_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_x_244)}));
  V v_t_246 = ({ V a_0 = v_x_244; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eparamList_str1); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
  return heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eparamList_str2)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eparamList_str3), v_t_246));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str1, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str2, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str5, 9, "  return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str6, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str8, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str9, 3, "V a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str10, 5, " = a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str15, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str16, 2, "a[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str17, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str20, 11, "heff_drop(a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str21, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str23, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str24, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str25, 7, " V r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str26, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str28, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryCall_str29, 10, " return r;");
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eentryCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eentryCall_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eentryCall(V v_key_240, V v_bi_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_bi_241)) {
  case TAG_Nil: {
    V v_t_243 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str0)));
    V v_x2_244 = (g_list_2emap_24f1512150482x179770396(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str1), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str2), MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str4); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str5), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str6), v_t_243));
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str7)), v_t_247);
    return heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str8));
  }
  case TAG_Cons: {
    V v_x2_2412 = (g_list_2emap_24s1613211967x1923010103(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str9), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str10), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str11), heff_dup(v_bi_241)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str12);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str13); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str14)));
    V v_t_2417 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_242, MK_INT(1LL))));
    V v_x2_2421 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2eentryCall_lam0, 1, 1, (V[]){heff_dup(v_bi_241)}), v_t_2417));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str19); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_x2_2425 = (g_list_2emap_24s693155583x821663253(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str20), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str21), v_bi_241));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str23); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str24), v_t_2415), ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str25));
    V v_t_2430 = heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str26), v_t_2416));
    V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str27)), v_t_2424);
    V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str28)), v_t_2428);
    return heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str29));
  }
  default: return heff_nomatch(v_bi_241);
  }
}
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eentryCall(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2eentryCall_lam0(V self, V *args) {
  V v_i_2418 = args[0];
  V v_bi_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = ({ V a_0 = v_i_2418; V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2eemitc_2eelemI(a_0, a_1)); heff_drop_tag(v_bi_241, 2); r_; });
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str15), heff_intShow(v_i_2418));
  } else {
    heff_drop(v_t_2419);
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eentryCall_str16), heff_intShow(v_i_2418));
    return heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2eentryCall_str17));
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str4, 8, "std.fuel");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str5, 81, "static V heff_perform(V p, V k) { heff_fuelTick(); return heff_perform_0(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str6, 64, "static V heff_perform(V p, V k) { return heff_perform_0(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str7, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str8, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str10, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str11, 8, "std.fuel");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str12, 18, "  heff_fuelTick();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str13, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str14, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str15, 33, "  default: return heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str16, 3, "  }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str17, 7, "  case ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str18, 23, ": return heff_provider_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str19, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str20, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str21, 7, "(p, k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str22, 14, "  switch (i) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eperformCode_str23, 42, "static V heff_performAt(int i, V p, V k) {");
Clo g_heff_2ecompile_2eemitc_2eperformCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eperformCode_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eperformCode(V v_eff_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(heff_dup(v_eff_240), MK_INT(0LL)));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    V v_x_244 = v_field_242;
    V v_y_245 = v_field_243;
    heff_drop(v_y_245);
    V v_t_246 = v_x_244;
    V v_t_247 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_240));
    V v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str0); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str1); V a_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str2); V a_5 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str3); V a_6 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str4); V a_7 = v_t_247; V r_ = (g_list_2eany_24s1520931887x1308972177(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_247); r_; });
    V v_t_249;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str5);
    } else {
      heff_drop(v_t_248);
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str6);
    }
    V v_eff_2410 = v_eff_240;
    V v_t_2411 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_2410));
    V v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str7); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str8); V a_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str9); V a_5 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str10); V a_6 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str11); V a_7 = v_t_2411; V r_ = (g_list_2eany_24s1520931887x1308972177(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2411); r_; });
    V v_t_2413;
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str12);
    } else {
      heff_drop(v_t_2412);
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str13);
    }
    V v_xs_2414 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_2410));
    V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    V v_t_2416 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(1LL))));
    V v_t_2417 = ({ V a_0 = v_eff_2410; V r_ = (g_heff_2eelab_2eeffect_2eleaves(a_0)); heff_drop(v_eff_2410); r_; });
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eperformCode_str14), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eperformCode_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eperformCode_str16), v_t_2418})});
    V v_ys_2420 = (g_prelude_2e_2b_2b_24f603353378x1069129212(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str17), ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str18), ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str19), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str20), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eperformCode_str21), v_t_2416, v_t_2417));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eperformCode_str22), v_ys_2420})});
    V v_ys_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eperformCode_str23), v_t_2421});
    return (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_ys_2422})));
  }
}
V g_heff_2ecompile_2eemitc_2eperformCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eperformCode(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str3, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str4, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str5, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str6, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str7, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str8, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str9, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str10, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str11, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str12, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str13, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str14, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str15, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str16, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str17, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str18, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str19, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str20, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str21, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str22, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str23, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str24, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str25, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str26, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str27, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str28, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str29, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str30, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str31, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str32, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str33, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str34, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str35, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str36, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str37, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str38, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str39, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str40, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str41, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str42, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str43, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str44, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str45, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str46, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str47, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str48, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str49, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str50, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str51, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str52, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str53, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str54, 6, "size_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str55, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str56, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str57, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str58, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str59, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str60, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str61, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str62, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str63, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str64, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str65, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str66, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str67, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str68, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str69, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str70, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str71, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str72, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str73, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str74, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str75, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str76, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str77, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str78, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str79, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str80, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str81, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargTypeNames_str82, 4, "void");
Clo g_heff_2ecompile_2eemitc_2eargTypeNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargTypeNames_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eargTypeNames(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_CInteger: {
    V v_t_245;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_242 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_245 = v_t_242;
      break;
    }
    case TAG_CDouble: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str0);
      break;
    }
    case TAG_CBool: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str1);
      break;
    }
    case TAG_CString: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str2);
      break;
    }
    case TAG_CText: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str4);
      break;
    }
    case TAG_CBytes: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str5);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str6);
      break;
    }
    case TAG_CPointer: {
      V v_t_243 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_245 = heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str7));
      break;
    }
    case TAG_CVoid: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str8);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  }
  case TAG_CDouble: {
    V v_t_249;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_246 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_249 = v_t_246;
      break;
    }
    case TAG_CDouble: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str9);
      break;
    }
    case TAG_CBool: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str10);
      break;
    }
    case TAG_CString: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str11);
      break;
    }
    case TAG_CText: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str12);
      break;
    }
    case TAG_COwnedString: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str13);
      break;
    }
    case TAG_CBytes: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str14);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str15);
      break;
    }
    case TAG_CPointer: {
      V v_t_247 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_249 = heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str16));
      break;
    }
    case TAG_CVoid: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str17);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  }
  case TAG_CBool: {
    V v_t_2413;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_2410 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_2413 = v_t_2410;
      break;
    }
    case TAG_CDouble: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str18);
      break;
    }
    case TAG_CBool: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str19);
      break;
    }
    case TAG_CString: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str20);
      break;
    }
    case TAG_CText: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str21);
      break;
    }
    case TAG_COwnedString: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str22);
      break;
    }
    case TAG_CBytes: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str23);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str24);
      break;
    }
    case TAG_CPointer: {
      V v_t_2411 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_2413 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str25));
      break;
    }
    case TAG_CVoid: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str26);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  }
  case TAG_CString: {
    V v_t_2417;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_2414 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_2417 = v_t_2414;
      break;
    }
    case TAG_CDouble: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str27);
      break;
    }
    case TAG_CBool: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str28);
      break;
    }
    case TAG_CString: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str29);
      break;
    }
    case TAG_CText: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str30);
      break;
    }
    case TAG_COwnedString: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str31);
      break;
    }
    case TAG_CBytes: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str32);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str33);
      break;
    }
    case TAG_CPointer: {
      V v_t_2415 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_2417 = heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str34));
      break;
    }
    case TAG_CVoid: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str35);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  }
  case TAG_CText: {
    V v_t_2421;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_2418 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_2421 = v_t_2418;
      break;
    }
    case TAG_CDouble: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str36);
      break;
    }
    case TAG_CBool: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str37);
      break;
    }
    case TAG_CString: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str38);
      break;
    }
    case TAG_CText: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str39);
      break;
    }
    case TAG_COwnedString: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str40);
      break;
    }
    case TAG_CBytes: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str41);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str42);
      break;
    }
    case TAG_CPointer: {
      V v_t_2419 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_2421 = heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str43));
      break;
    }
    case TAG_CVoid: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str44);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  }
  case TAG_COwnedString: {
    V v_t_2425;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_2422 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_2425 = v_t_2422;
      break;
    }
    case TAG_CDouble: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str45);
      break;
    }
    case TAG_CBool: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str46);
      break;
    }
    case TAG_CString: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str47);
      break;
    }
    case TAG_CText: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str48);
      break;
    }
    case TAG_COwnedString: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str49);
      break;
    }
    case TAG_CBytes: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str50);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str51);
      break;
    }
    case TAG_CPointer: {
      V v_t_2423 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_2425 = heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str52));
      break;
    }
    case TAG_CVoid: {
      v_t_2425 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str53);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
  }
  case TAG_CBytes: {
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str54), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str55), v_t_2426});
  }
  case TAG_COwnedBytes: {
    V v_t_2430;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_2427 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_2430 = v_t_2427;
      break;
    }
    case TAG_CDouble: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str56);
      break;
    }
    case TAG_CBool: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str57);
      break;
    }
    case TAG_CString: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str58);
      break;
    }
    case TAG_CText: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str59);
      break;
    }
    case TAG_COwnedString: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str60);
      break;
    }
    case TAG_CBytes: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str61);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str62);
      break;
    }
    case TAG_CPointer: {
      V v_t_2428 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_2430 = heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str63));
      break;
    }
    case TAG_CVoid: {
      v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str64);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  }
  case TAG_CPointer: {
    V v_t_2436;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_2433 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_2436 = v_t_2433;
      break;
    }
    case TAG_CDouble: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str65);
      break;
    }
    case TAG_CBool: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str66);
      break;
    }
    case TAG_CString: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str67);
      break;
    }
    case TAG_CText: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str68);
      break;
    }
    case TAG_COwnedString: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str69);
      break;
    }
    case TAG_CBytes: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str70);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str71);
      break;
    }
    case TAG_CPointer: {
      V v_t_2434 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_2436 = heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str72));
      break;
    }
    case TAG_CVoid: {
      v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str73);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
  }
  case TAG_CVoid: {
    V v_t_2440;
    switch (heff_tag_of(v_t_240)) {
    case TAG_CInteger: {
      V v_t_2437 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 1);
      v_t_2440 = v_t_2437;
      break;
    }
    case TAG_CDouble: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str74);
      break;
    }
    case TAG_CBool: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str75);
      break;
    }
    case TAG_CString: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str76);
      break;
    }
    case TAG_CText: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str77);
      break;
    }
    case TAG_COwnedString: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str78);
      break;
    }
    case TAG_CBytes: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str79);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str80);
      break;
    }
    case TAG_CPointer: {
      V v_t_2438 = heff_field(v_t_240, 0);
      heff_take_n(v_t_240, 1ULL, 2);
      v_t_2440 = heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str81));
      break;
    }
    case TAG_CVoid: {
      v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eargTypeNames_str82);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2eemitc_2eargTypeNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eargTypeNames(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str0, 4, "    ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str1, 2, " a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str2, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str3, 30, ")heff_int_low64(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str4, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str5, 7, "    V t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str6, 18, " = heff_tget_v(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str7, 11, "); double a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str8, 11, " = FLT_OF(t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str9, 14, "); heff_drop(t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str10, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str11, 10, "    bool a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str12, 17, " = heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str13, 20, ") == NTAG(TAG_True);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str14, 11, "    char *a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str15, 27, " = heff_cstr(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str16, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str17, 11, "    char *a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str18, 32, " = heff_cstr_text(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str19, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str21, 13, "    int64_t n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str22, 18, "; const uint8_t *a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str23, 33, " = heff_bytes_data(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str24, 5, "), &n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str25, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str27, 4, "    ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str28, 3, " *a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str29, 34, " = heff_foreign_ptr(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str30, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargLine_str31, 0, "");
Clo g_heff_2ecompile_2eemitc_2eargLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargLine_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eargLine(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CInteger: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str0), heff_dup(v_t_242)), ((V)&g_heff_2ecompile_2eemitc_2eargLine_str1));
    V v_t_244 = heff_strAppend(v_t_243, heff_intShow(heff_dup(v_i_240)));
    V v_t_245 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str2)), heff_dup(v_t_242));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str3)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str4));
  }
  case TAG_CDouble: {
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str5), heff_intShow(heff_dup(v_i_240)));
    V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str6)), heff_intShow(heff_dup(v_i_240)));
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str7)), heff_intShow(heff_dup(v_i_240)));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str8)), heff_intShow(heff_dup(v_i_240)));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str9)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str10));
  }
  case TAG_CBool: {
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str11), heff_intShow(heff_dup(v_i_240)));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str12)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str13));
  }
  case TAG_CString: {
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str14), heff_intShow(heff_dup(v_i_240)));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str15)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str16));
  }
  case TAG_CText: {
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str17), heff_intShow(heff_dup(v_i_240)));
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str18)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str19));
  }
  case TAG_COwnedString: {
    heff_drop(v_i_240);
    return ((V)&g_heff_2ecompile_2eemitc_2eargLine_str20);
  }
  case TAG_CBytes: {
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str21), heff_intShow(heff_dup(v_i_240)));
    V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str22)), heff_intShow(heff_dup(v_i_240)));
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str23)), heff_intShow(heff_dup(v_i_240)));
    V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str24)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str25));
  }
  case TAG_COwnedBytes: {
    heff_drop(v_i_240);
    return ((V)&g_heff_2ecompile_2eemitc_2eargLine_str26);
  }
  case TAG_CPointer: {
    V v_t_2422 = heff_field(v_x2_241, 0);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargLine_str27), heff_dup(v_t_2422)), ((V)&g_heff_2ecompile_2eemitc_2eargLine_str28));
    V v_t_2425 = heff_strAppend(v_t_2424, heff_intShow(heff_dup(v_i_240)));
    V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str29)), heff_intShow(v_i_240));
    return heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2eargLine_str30));
  }
  case TAG_CVoid: {
    heff_drop(v_i_240);
    return ((V)&g_heff_2ecompile_2eemitc_2eargLine_str31);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eargLine_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eargLine(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2eargLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargLines_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eargLines(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = ({ V a_0 = heff_dup(v_i_240); V a_1 = v_t_242; V r_ = (g_heff_2ecompile_2eemitc_2eargLine(a_0, a_1)); heff_drop(v_t_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2eemitc_2eargLines_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_rest_243, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eargLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eargLines(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str0, 9, "#include ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str1, 20, "#include <stdbool.h>");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str2, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str3, 35, "(V p, V k) { return heff_described_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str4, 9, "(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str5, 35, "    heff_fail(\"not an operation of ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str6, 3, "  }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str7, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str8, 15, " that C does\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str9, 13, "    return 0;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str10, 10, "  default:");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str11, 24, "static V heff_described_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str12, 12, "(V p, V k) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str13, 27, "  switch (heff_tag_of(p)) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str14, 3, "// ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str15, 4, "'s `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str16, 57, "` in C, as the module describes it: made by the compiler.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueProvider_str18, 1, "\012");
V g_heff_2ecompile_2eemitc_2eglueProvider_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eglueProvider_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglueProvider_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eglueProvider(V v_gl_240) {
top: ;
  V v_t_241 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str0), heff_dup(heff_rfield(v_gl_240, 2))));
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_243 = (g_list_2efoldl_24s1520027297x1040032870(NTAG(TAG_Nil), v_t_242));
  V v_t_244 = ({ V a_0 = v_t_243; V r_ = (g_list_2eany_24s280395686x983781620(a_0)); heff_drop(v_t_243); r_; });
  V v_t_245;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str1), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_244);
    v_t_245 = NTAG(TAG_Nil);
  }
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eassertLine_clo), 1, (V[]){heff_dup(heff_rfield(v_gl_240, 0))}));
  V v_t_247 = (g_list_2emap(v_t_246, heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_249 = (g_list_2efoldl_24s1520027297x1040032870(NTAG(TAG_Nil), v_t_248));
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2epointersGo(NTAG(TAG_Nil), v_t_249));
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2ehelperLines(heff_dup(v_gl_240), v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_2413 = (g_list_2efoldl_24s1520027297x1040032870(NTAG(TAG_Nil), v_t_2412));
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2epointersGo(NTAG(TAG_Nil), v_t_2413));
  V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_gl_240, 3))));
  V v_t_2419 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eglueProvider_lam0, 2, 2, (V[]){heff_dup(v_gl_240), v_t_2414}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2415; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2415); r_; });
  V v_t_2420 = heff_take_field(v_gl_240, 4);
  V v_t_2423;
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str2), heff_dup(heff_rfield(v_gl_240, 1)));
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str3)), heff_dup(heff_rfield(v_gl_240, 1)));
    v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str4)), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_2420);
    v_t_2423 = NTAG(TAG_Nil);
  }
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str5), heff_dup(heff_rfield(v_gl_240, 1)));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str7), v_t_2423})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str8)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str9), v_t_2425})});
  V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str10), v_t_2426})));
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str11), heff_dup(heff_rfield(v_gl_240, 1)));
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str12)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str13), v_t_2427})});
  V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2429));
  V v_t_2431 = (g_prelude_2e_2b_2b(v_t_247, v_t_2430));
  V v_t_2432 = (g_prelude_2e_2b_2b(v_t_245, v_t_2431));
  V v_t_2433 = (g_prelude_2e_2b_2b(v_t_241, v_t_2432));
  V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str14), heff_dup(heff_rfield(v_gl_240, 0)));
  V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str15)), heff_take_field(v_gl_240, 1));
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str16)), NTAG(TAG_Nil)});
  V v_x2_2437 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2433));
  V v_t_2440;
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_Nil: {
    v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str17);
    break;
  }
  case TAG_Cons: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_xs_2439 = heff_field(v_x2_2437, 1);
    heff_take_n(v_x2_2437, 3ULL, 2);
    v_t_2440 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglueProvider_str18); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2437);
  }
  return heff_rec_n(2, shape_module__text, (V[]){heff_get_n(v_gl_240, 0, 5), v_t_2440});
}
V g_heff_2ecompile_2eemitc_2eglueProvider_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglueProvider(a[0]);
}
V g_heff_2ecompile_2eemitc_2eglueProvider_lam0(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_x_2417 = args[1];
  V v_gl_240 = heff_env(self)[0];
  V v_t_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = ({ V a_0 = heff_take_field(v_gl_240, 0); V a_1 = heff_get_n(v_gl_240, 1, 5); V a_2 = v_t_2414; V a_3 = v_x_2417; V r_ = (g_heff_2ecompile_2eemitc_2ecaseLines(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
  return (g_prelude_2e_2b_2b(v_t_2418, v_acc_2416));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str0, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str1, 3, ", \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str2, 2, "\"}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str5, 9, "{0, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str7, 22, "static const HeffName ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str8, 6, "[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enamesTable_str9, 2, "};");
Clo g_heff_2ecompile_2eemitc_2enamesTable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesTable_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enamesTable(V v_name_240, V v_m_241) {
top: ;
  V v_t_242 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_m_241, NTAG(TAG_Nil)));
  V v_x2_243 = (g_list_2emap_24s1566016224x493905666(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str0), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str1), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str2), v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str4); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = (g_std_2eordmap_2esize(v_m_241));
  V v_t_248;
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str5);
  } else {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str6);
  }
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enamesTable_str7), v_name_240), ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str8));
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, v_t_246), v_t_248);
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2enamesTable_str9)), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2enamesTable_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enamesTable(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str2, 14, "static V gget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str3, 20, "(void) { return (V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str4, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str5, 7, "_clo; }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str6, 18, "heff_tag_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str7, 18, "heff_lbl_names_arr");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str9, 5, "gget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str12, 4, "_get");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str13, 2, "{\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str14, 3, "\", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str15, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str17, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str18, 12, "{NULL, NULL}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str20, 42, "static const Global heff_globals_arr[] = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str21, 18, "  heff_nglobals = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str22, 20, "  heff_ntag_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str23, 20, "  heff_nlbl_names = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str25, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str26, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str27, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str28, 38, "  heff_lbl_names = heff_lbl_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str29, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str30, 38, "  heff_tag_names = heff_tag_names_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str31, 35, "static void heff_check_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str32, 34, "  heff_globals = heff_globals_arr;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str33, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str34, 76, "static V heff_perform(V p, V k) { (void)p; (void)k; return heff_abandon(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckEnd_str35, 94, "static V heff_performAt(int i, V p, V k) { (void)i; (void)p; (void)k; return heff_abandon(); }");
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckEnd_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckEnd(V v_exports_240, V v_defs_241, V v_ce_242) {
top: ;
  V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam0, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_2 = heff_dup(v_exports_240); V r_ = (g_list_2efoldl_24f1428393365x1980555854(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2424 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam1, 2, 1, (V[]){heff_dup(v_ce_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_247); r_; });
  V v_t_2425 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str6), heff_rfield(v_ce_242, 0)));
  V v_t_2426 = (g_heff_2ecompile_2eemitc_2enamesTable(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str7), heff_rfield(v_ce_242, 1)));
  V v_t_2431 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam2, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_1 = heff_dup(v_exports_240); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_2449 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam3, 1, 1, (V[]){heff_dup(v_ce_242)}), v_t_2431));
  V v_t_2452;
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_Nil: {
    v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str16);
    break;
  }
  case TAG_Cons: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_xs_2451 = heff_field(v_x2_2449, 1);
    heff_take_n(v_x2_2449, 3ULL, 2);
    v_t_2452 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str17); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2449);
  }
  V v_x1_2457 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam4, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_1 = heff_dup(v_exports_240); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2460;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nil: {
    v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str18);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2457, 0ULL, 2);
    v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str19);
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V v_t_2465 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_clo_n(g_heff_2ecompile_2eemitc_2echeckEnd_lam5, 1, 1, (V[]){heff_dup(v_defs_241)}); V a_3 = v_exports_240; V r_ = (g_list_2efoldl_24f1323813142x1311067101(a_0, a_1, b_2, a_3)); heff_drop(b_2); heff_drop(v_exports_240); r_; });
  V v_t_2466 = (g_std_2eordmap_2esize(heff_rfield(v_ce_242, 0)));
  V v_t_2467 = ({ V b_0 = heff_get_n(v_ce_242, 1, 3); V r_ = (g_std_2eordmap_2esize(b_0)); heff_drop(b_0); r_; });
  V v_t_2468 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str20), v_t_2452), v_t_2460);
  V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str21), heff_intShow(v_t_2465));
  V v_t_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str22), heff_intShow(v_t_2466));
  V v_t_2471 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str23), heff_intShow(v_t_2467));
  V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str24), NTAG(TAG_Nil)});
  V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str25)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str26), v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2470, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str27)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str28), v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str29)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str30), v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str31), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str32), v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2468, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str33)), v_t_2476});
  V v_t_2478 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2477));
  V v_t_2479 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2478));
  V v_ys_2480 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2479));
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str34), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str35), v_ys_2480})});
}
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2echeckEnd(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_defs_241 = heff_env(self)[0];
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_245 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_t_246 = v_y_245;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_246; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1606644238x788321190(a_0, a_1)); heff_drop(v_t_246); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam1(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_ce_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ce_2410 = v_ce_242;
  V v_x2_2411 = v_x_249;
  V v_t_2423;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_key_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 2ULL, 2);
    V v_t_2414 = heff_get_n(heff_get_n(v_ce_2410, 2, 3), 0, 11);
    HeffT2 v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_key_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_x_2418 = v_field_2417;
        heff_drop(v_x_2418);
        V v_t_2419 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_2413, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str0)));
        V v_t_2420 = ({ V a_0 = v_key_2413; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str1); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2413); r_; });
        V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str2), v_t_2419), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str3));
        V v_t_2422 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str4), v_t_2420));
        v_t_2423 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str5)), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_key_2413);
        heff_drop_cell(v_ru_24x2_2411_24MkPair, 2);
        heff_drop(v_field_2417);
        v_t_2423 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return (g_prelude_2e_2b_2b(v_t_2423, v_acc_248));
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam2(V self, V *args) {
  V v_p_2427 = args[0];
  V v_defs_241 = heff_env(self)[0];
  V v_t_2430;
  switch (heff_tag_of(v_p_2427)) {
  case TAG_MkPair: {
    V v_y_2429 = heff_field(v_p_2427, 1);
    heff_take_n(v_p_2427, 2ULL, 2);
    v_t_2430 = v_y_2429;
    break;
  }
  default: heff_nomatch(v_p_2427);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_2430; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1606644238x788321190(a_0, a_1)); heff_drop(v_t_2430); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam3(V self, V *args) {
  V v_p_2432 = args[0];
  V v_ce_242 = heff_env(self)[0];
  V v_t_2435;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_dup(heff_field(v_p_2432, 0));
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  heff_clo_take(self, 1);
  V v_ce_2436 = v_ce_242;
  V v_key_2439;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_y_2438 = heff_field(v_p_2432, 1);
    heff_take_n(v_p_2432, 2ULL, 2);
    v_key_2439 = v_y_2438;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_t_2440 = heff_get_n(heff_get_n(v_ce_2436, 2, 3), 0, 11);
  HeffT2 v_t_2441 = ({ V a_0 = v_t_2440; V a_1 = v_key_2439; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2440); r_; });
  {
    V v_field_2443 = v_t_2441.f[1];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    V v_t_2447;
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      V v_x_2444 = v_field_2443;
      heff_drop(v_x_2444);
      V v_t_2445 = ({ V a_0 = v_key_2439; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str8); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2439); r_; });
      v_t_2447 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str9), v_t_2445);
    } else {
      heff_drop(v_field_2443);
      V v_t_2446 = ({ V a_0 = v_key_2439; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str10); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_2439); r_; });
      v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str11), v_t_2446), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str12));
    }
    V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str13), v_t_2435), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str14));
    return heff_strAppend(heff_strAppend(v_t_2448, v_t_2447), ((V)&g_heff_2ecompile_2eemitc_2echeckEnd_str15));
  }
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam4(V self, V *args) {
  V v_p_2453 = args[0];
  V v_defs_241 = heff_env(self)[0];
  V v_t_2456;
  switch (heff_tag_of(v_p_2453)) {
  case TAG_MkPair: {
    V v_y_2455 = heff_field(v_p_2453, 1);
    heff_take_n(v_p_2453, 2ULL, 2);
    v_t_2456 = v_y_2455;
    break;
  }
  default: heff_nomatch(v_p_2453);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_2456; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1606644238x788321190(a_0, a_1)); heff_drop(v_t_2456); heff_drop(v_defs_241); r_; });
}
V g_heff_2ecompile_2eemitc_2echeckEnd_lam5(V self, V *args) {
  V v_p_2461 = args[0];
  V v_defs_241 = heff_env(self)[0];
  V v_t_2464;
  switch (heff_tag_of(v_p_2461)) {
  case TAG_MkPair: {
    V v_y_2463 = heff_field(v_p_2461, 1);
    heff_take_n(v_p_2461, 2ULL, 2);
    v_t_2464 = v_y_2463;
    break;
  }
  default: heff_nomatch(v_p_2461);
  }
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_2464; V a_1 = v_defs_241; V r_ = (g_list_2eany_24s1606644238x788321190(a_0, a_1)); heff_drop(v_t_2464); heff_drop(v_defs_241); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1, 5, "float");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2, 6, "int8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3, 7, "int16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4, 7, "int32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6, 7, "uint8_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7, 8, "uint16_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8, 8, "uint32_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9, 8, "uint64_t");
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit10, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str9), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit11, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str8), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit10));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit12, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str7), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit11));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit13, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str6), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit12));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit14, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str5), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit13));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit15, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str4), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit14));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit16, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str3), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit15));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit17, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str2), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit16));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit18, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str1), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit17));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit19, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_str0), ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit18));

static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eunboxedCTypes_st;
static V g_heff_2ecompile_2eemitc_2eunboxedCTypes_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eunboxedCTypes_lit19);
}
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eunboxedCTypes_st)) return g_heff_2ecompile_2eemitc_2eunboxedCTypes_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eunboxedCTypes_val, &g_heff_2ecompile_2eemitc_2eunboxedCTypes_st, g_heff_2ecompile_2eemitc_2eunboxedCTypes_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str1, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str2, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str5, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str9, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str11, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str14, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str15, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str16, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str17, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleDecl_str19, 2, ");");
Clo g_heff_2ecompile_2eemitc_2etupleDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleDecl_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2etupleDecl(V v_k_240, V v_n_241, V v_x3_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_244 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str0)));
    V v_t_248;
    if (heff_intEq_c_lent(v_n_241, MK_INT(0LL), 2)) {
      heff_drop(v_n_241);
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str1);
    } else {
      V v_x2_245 = (g_list_2ereplicate(v_n_241, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str2)));
      switch (heff_tag_of(v_x2_245)) {
      case TAG_Nil: {
        v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_246 = heff_field(v_x2_245, 0);
        V v_xs_247 = heff_field(v_x2_245, 1);
        heff_take_n(v_x2_245, 3ULL, 2);
        v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str4); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
        break;
      }
      default: heff_nomatch(v_x2_245);
      }
    }
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str5), heff_intShow(v_t_243));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str6)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str7), v_t_244));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str8)), v_t_248);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str9)), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_sg_2412 = heff_field(v_x3_242, 0);
    heff_drop(v_n_241);
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str10)));
    V v_t_2414 = heff_dup(heff_rfield(v_sg_2412, 0));
    V v_t_2420;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str11);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2414, 0ULL, 2);
      V v_x2_2417 = (g_list_2emap_24s1386329375x1773300759(heff_dup(heff_rfield(v_sg_2412, 0))));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nil: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_xs_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str13); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2417);
      }
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str14), heff_intShow(v_t_243));
    V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str15), v_t_2413), ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str16));
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str17)), v_t_2422);
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str18)), v_t_2420);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2etupleDecl_str19)), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2etupleDecl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2etupleDecl(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epartsFrom_str0, 1, ".");
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartsFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2epartsFrom(V v_m_240, V v_b_241, V v_ps_242, V v_k_243) {
top: ;
  if (heff_intLe_c_lent(v_b_241, v_k_243, 0)) {
    heff_drop(v_k_243);
    return NTAG(TAG_Nil);
  } else {
    V v_n_244 = heff_strAppend(heff_strAppend(heff_dup(v_m_240), ((V)&g_heff_2ecompile_2eemitc_2epartsFrom_str0)), heff_intShow(heff_dup(v_k_243)));
    V v_qs_2410 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2epartsFrom_lam0, 1, 2, (V[]){heff_dup(v_b_241), heff_dup(v_k_243)}); V a_1 = heff_dup(v_ps_242); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_rest_2411 = (g_heff_2ecompile_2eemitc_2epartsFrom(v_m_240, v_b_241, v_ps_242, heff_intAdd(v_k_243, MK_INT(1LL))));
    switch (heff_tag_of(v_qs_2410)) {
    case TAG_Nil: {
      heff_drop(v_n_244);
      return v_rest_2411;
    }
    case TAG_Cons: {
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_n_244, v_qs_2410}), v_rest_2411});
    }
    default: return heff_nomatch(v_qs_2410);
    }
  }
}
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2epartsFrom(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2epartsFrom_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_b_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_t_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_d_246 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_248 = heff_get_n(v_d_246, 0, 3);
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_249 = ({ V a_0 = v_t_248; V a_1 = MK_INT(0LL); V a_2 = MK_INT(7LL); V r_ = (g_heff_2ecompile_2eemitc_2ekeyHashGo(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_ret_24bool = heff_bool(heff_intEq_c_lent(heff_intMod_lent(v_t_249, v_b_241, 0), v_k_243, 1));
  heff_drop(self);
  heff_drop(v_t_249);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str3, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str4, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str5, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str6, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str7, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str8, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str9, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str10, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str11, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str12, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str13, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str14, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str15, 3, "Int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str16, 2, "->");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str19, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglobalH_str21, 1, ",");
Clo g_heff_2ecompile_2eemitc_2eglobalH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglobalH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eglobalH(V v_ce_240, V v_g_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 0, 11);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_t_248;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = MK_INT(-1LL);
    }
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 1, 11);
    HeffT2 v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      V v_t_2414;
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2412;
        heff_drop(v_x_2413);
        v_t_2414 = MK_INT(1LL);
      } else {
        heff_drop(v_field_2412);
        v_t_2414 = MK_INT(0LL);
      }
      V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 3, 11);
      HeffT2 v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2415); r_; });
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        V v_t_2420;
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_x_2419 = v_field_2418;
          v_t_2420 = v_x_2419;
        } else {
          heff_drop(v_field_2418);
          v_t_2420 = NTAG(TAG_Nil);
        }
        V v_x2_2421 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2420));
        V v_t_2424;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_xs_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str1); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 4, 11);
        HeffT2 v_t_2426 = ({ V a_0 = v_t_2425; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2425); r_; });
        {
          V v_field_2428 = v_t_2426.f[1];
          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
          V v_t_2440;
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            V v_x_2429 = v_field_2428;
            V v_s_2430 = v_x_2429;
            V v_params_2431 = heff_take_field(v_s_2430, 0);
            V v_result_2432 = heff_get_n(v_s_2430, 1, 2);
            V v_x2_2433 = (g_list_2emap_24s2090270526x1588636862(v_params_2431));
            V v_t_2436;
            switch (heff_tag_of(v_x2_2433)) {
            case TAG_Nil: {
              v_t_2436 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str2);
              break;
            }
            case TAG_Cons: {
              V v_x_2434 = heff_field(v_x2_2433, 0);
              V v_xs_2435 = heff_field(v_x2_2433, 1);
              heff_take_n(v_x2_2433, 3ULL, 2);
              v_t_2436 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str3); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2433);
            }
            V v_t_2437 = v_result_2432;
            V v_t_2439;
            switch (heff_tag_of(v_t_2437)) {
            case TAG_RepV: {
              v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str4);
              break;
            }
            case TAG_RepFix: {
              V v_w_2438 = heff_field(v_t_2437, 0);
              heff_take_n(v_t_2437, 1ULL, 1);
              switch (heff_tag_of(v_w_2438)) {
              case TAG_I8: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str5);
                break;
              }
              case TAG_I16: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str6);
                break;
              }
              case TAG_I32: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str7);
                break;
              }
              case TAG_I64: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str8);
                break;
              }
              case TAG_U8: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str9);
                break;
              }
              case TAG_U16: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str10);
                break;
              }
              case TAG_U32: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str11);
                break;
              }
              case TAG_U64: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str12);
                break;
              }
              case TAG_F32: {
                v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str13);
                break;
              }
              default: heff_nomatch(v_w_2438);
              }
              break;
            }
            case TAG_RepF64: {
              v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str14);
              break;
            }
            case TAG_RepInt: {
              v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str15);
              break;
            }
            default: heff_nomatch(v_t_2437);
            }
            v_t_2440 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str16)), v_t_2439);
          } else {
            heff_drop(v_field_2428);
            v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str17);
          }
          V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 11);
          HeffT2 v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2441); r_; });
          {
            V v_field_2444 = v_t_2442.f[1];
            int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
            V v_t_2446;
            if ((v_tag_2443 == ((int64_t)0ULL))) {
              V v_x_2445 = v_field_2444;
              v_t_2446 = v_x_2445;
            } else {
              heff_drop(v_field_2444);
              v_t_2446 = MK_INT(0LL);
            }
            V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 9, 11);
            HeffT2 v_t_2448 = ({ V a_0 = v_t_2447; V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2447); r_; });
            {
              V v_field_2450 = v_t_2448.f[1];
              int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
              V v_t_2452;
              if ((v_tag_2449 == ((int64_t)0ULL))) {
                V v_x_2451 = v_field_2450;
                v_t_2452 = v_x_2451;
              } else {
                heff_drop(v_field_2450);
                v_t_2452 = NTAG(TAG_Nil);
              }
              V v_x2_2453 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2452));
              V v_t_2456;
              switch (heff_tag_of(v_x2_2453)) {
              case TAG_Nil: {
                v_t_2456 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str18);
                break;
              }
              case TAG_Cons: {
                V v_x_2454 = heff_field(v_x2_2453, 0);
                V v_xs_2455 = heff_field(v_x2_2453, 1);
                heff_take_n(v_x2_2453, 3ULL, 2);
                v_t_2456 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str19); V a_1 = v_x_2454; V a_2 = v_xs_2455; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2455); r_; });
                break;
              }
              default: heff_nomatch(v_x2_2453);
              }
              V v_t_2457 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 10, 11);
              HeffT2 v_t_2458 = ({ V b_0 = heff_get_n(v_t_2457, 0, 2); V a_1 = v_g_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2460 = v_t_2458.f[1];
                int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
                V v_t_2462;
                if ((v_tag_2459 == ((int64_t)0ULL))) {
                  V v_x_2461 = v_field_2460;
                  v_t_2462 = v_x_2461;
                } else {
                  heff_drop(v_field_2460);
                  v_t_2462 = NTAG(TAG_Nil);
                }
                V v_x2_2463 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2462));
                V v_t_2466;
                switch (heff_tag_of(v_x2_2463)) {
                case TAG_Nil: {
                  v_t_2466 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str20);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2464 = heff_field(v_x2_2463, 0);
                  V v_xs_2465 = heff_field(v_x2_2463, 1);
                  heff_take_n(v_x2_2463, 3ULL, 2);
                  v_t_2466 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglobalH_str21); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
                  break;
                }
                default: heff_nomatch(v_x2_2463);
                }
                V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2466}), v_rest_242});
                V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2456}), v_t_2467});
                V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2446}), v_t_2468});
                V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2440}), v_t_2469});
                V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2424}), v_t_2470});
                V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_2414}), v_t_2471});
                V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_248}), v_t_2472});
                return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_g_241}), v_t_2473});
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglobalH(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2epushOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epushOwn_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2epushOwn(V v_o_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x2_241, 0);
    V v_ls_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_o_240), v_l_243}), v_acc_242});
    V t_0 = v_o_240;
    V t_1 = v_ls_244;
    V t_2 = v_t_245;
    v_o_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2epushOwn(a0, a[1], a[2]); heff_drop(a0); return r;
}