// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_EFDefault 38038
#define TAG_EField 26142
#define TAG_ELetMut 54984
#define TAG_ESBind 62182
#define TAG_EWhile 39339
#define TAG_Get 18914
#define TAG_MkDAlts 45152
#define TAG_MkSep 6724
#define TAG_MkTF 48839
#define TAG_PAtom 50987
#define TAG_PList 40618
#define TAG_PParen 60953
#define TAG_Put 28059
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_blank 295177582
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_head 9693863
#define LBL_i 323
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_patAtom 1586746071
#define LBL_pattern 1588251091
#define LBL_raw 322210
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_heff_2esyntax_2ecst_2earmF(V, V, V);
V g_heff_2esyntax_2ecst_2earmF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earmF_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V, V, V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo;
V g_heff_2esyntax_2ecst_2ebindRhsF(V, V, V);
V g_heff_2esyntax_2ecst_2ebindRhsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebindRhsF_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblockGo(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_clo;
V g_heff_2esyntax_2ecst_2ecloseAfter(V, V, V);
V g_heff_2esyntax_2ecst_2ecloseAfter_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecloseAfter_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929(V, V, V);
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_clo;
V g_heff_2esyntax_2ecst_2efieldNameF(V, V, V, V);
V g_heff_2esyntax_2ecst_2efieldNameF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldNameF_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2eforF(V, V, V);
V g_heff_2esyntax_2ecst_2eforF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eforF_clo;
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eletMutF(V, V, V);
V g_heff_2esyntax_2ecst_2eletMutF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletMutF_clo;
V g_heff_2esyntax_2ecst_2eletStmtF(V, V, V);
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletStmtF_clo;
V g_heff_2esyntax_2ecst_2elocalDecl(V, V);
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elocalDecl_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eparenPatF(V, V, V);
V g_heff_2esyntax_2ecst_2eparenPatF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparenPatF_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2estmtF(V, V, V);
V g_heff_2esyntax_2ecst_2estmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estmtF_clo;
V g_heff_2esyntax_2ecst_2etheoryFieldName(V, V);
V g_heff_2esyntax_2ecst_2etheoryFieldName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etheoryFieldName_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_str2, 5, "where");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_str4, 4, "once");
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eblockGo(V v_item_240, V v_col_241, V v_acc_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam1, 1, 5, (V[]){v_hd_243, v_item_240, v_col_241, v_acc_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_246 = heff_dup(heff_rfield(v_s_245, 1));
  V v_top_247 = heff_take_field(v_s_245, 2);
  V v_stack_248 = heff_take_field(v_s_245, 3);
  return ({ V rv_2 = v_top_247; V rv_3 = v_stack_248; V rv_4 = v_x_246; V rr_ = heff_rec_reuse_nf(v_s_245, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_col_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_kind_2419 = heff_take_field(v_x_2418, 0);
  V v_first_2420 = heff_take_field(v_x_2418, 6);
  V v_col_2421 = heff_take_field(v_x_2418, 5);
  V v_text_2422 = heff_get_n(v_x_2418, 1, 9);
  if ((heff_strEq_c_lent(v_kind_2419, ((V)&g_heff_2esyntax_2ecst_2eblockGo_str0), 2) ? 0 : ((heff_dup(v_first_2420) == NTAG(TAG_True)) && (heff_intEq_c_lent(v_col_2421, v_col_241, 0) && ((heff_strEq_c_lent(v_kind_2419, ((V)&g_heff_2esyntax_2ecst_2eblockGo_str1), 2) && heff_strEq_c_lent(v_text_2422, ((V)&g_heff_2esyntax_2ecst_2eblockGo_str2), 2)) ? 0 : (heff_strEq_c_lent(v_kind_2419, ((V)&g_heff_2esyntax_2ecst_2eblockGo_str3), 2) ? !heff_strEq_c_lent(v_text_2422, ((V)&g_heff_2esyntax_2ecst_2eblockGo_str4), 2) : 1)))))) {
    heff_drop(v_kind_2419);
    heff_drop(v_first_2420);
    heff_drop(v_col_2421);
    heff_drop(v_text_2422);
    heff_clo_take(self, 6);
    return (g_heff_2esyntax_2ecst_2eblockGo(v_item_240, v_col_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_acc_242}), v_hd_243, v_k_244));
  } else {
    heff_clo_take(self, 6);
    heff_drop(v_col_241);
    heff_drop(v_item_240);
    heff_drop_rec(v_hd_243, 3);
    heff_drop(v_kind_2419);
    heff_drop(v_first_2420);
    heff_drop(v_col_2421);
    heff_drop(v_text_2422);
    V v_x_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_acc_242})));
    V f_ = v_k_244;
    args[0] = v_x_2423;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2416}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam4, 1, 6, (V[]){v_col_241, v_item_240, v_x_2415, v_acc_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_drop(v_x_2414);
  heff_clo_take(self, 5);
  V f_ = heff_dup(v_item_240);
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam3, 1, 5, (V[]){v_hd_243, v_col_241, v_item_240, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_t_2412 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam2, 1, 5, (V[]){v_item_240, v_hd_243, v_col_241, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo(V v_sep_240, V v_p_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam0, 1, 6, (V[]){heff_dup(v_sep_240), v_hd_244, v_p_241, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_sep_240; V a_1 = v_p_241; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_242}); V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_243}); V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2esyntax_2ecst_2esepGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_dup(v_p_241);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam2, 1, 7, (V[]){v_sep_240, v_p_241, v_items_242, v_x_249, v_seps_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_240))) {
    heff_clo_take(self, 6);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam1, 1, 6, (V[]){v_p_241, v_hd_244, v_sep_240, v_items_242, v_seps_243, v_k_245})));
  } else {
    heff_clo_take(self, 6);
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_p_241);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, v_t_2412});
    V f_ = v_k_245;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldsGo_str0, 5, "field");
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efieldsGo_entry, 3, 0};

V g_heff_2esyntax_2ecst_2efieldsGo(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam0, 1, 3, (V[]){v_hd_241, v_e_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efieldsGo(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_EField, 2, (V[]){v_e_240, v_x_246}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2efieldsGo_str0))) {
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  } else {
    heff_clo_take(self, 3);
    heff_drop_rec(v_hd_241, 3);
    V f_ = v_k_242;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str1, 17, "a variable's name");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str2, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str3, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str4, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletMutF_str5, 1, "=");
V g_heff_2esyntax_2ecst_2eletMutF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletMutF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletMutF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletMutF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletMutF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletMutF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletMutF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletMutF_lam7(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_x_2412})});
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ELetMut, 6, (V[]){v_x_243, v_x_244, v_x_245, v_t_2415, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletMutF_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_244 = heff_env(self)[6];
  V v_x_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam7, 1, 7, (V[]){v_x_2411, v_x_2412, v_k_242, v_x_243, v_x_244, v_x_245, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletMutF_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_x_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eletMutF_str4), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam6, 1, 8, (V[]){v_g_240, v_hd_241, v_x_2411, v_x_2412, v_k_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eletMutF_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_g_240, 0));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam5, 1, 7, (V[]){v_hd_241, v_g_240, v_x_2411, v_k_242, v_x_243, v_x_244, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletMutF_lam9(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = heff_tag_n(TAG_ELetMut, 6, (V[]){v_x_243, v_x_244, v_x_245, NTAG(TAG_Nothing), v_x_2416, v_x_2417});
  V f_ = v_k_242;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletMutF_lam8(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam9, 1, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_2416, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletMutF_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_kind_249 = heff_take_field(v_x_248, 0);
  V v_text_2410 = heff_get_n(v_x_248, 1, 9);
  if ((heff_strEq_c_lent(v_kind_249, ((V)&g_heff_2esyntax_2ecst_2eletMutF_str2), 2) && heff_strEq_c_lent(v_text_2410, ((V)&g_heff_2esyntax_2ecst_2eletMutF_str3), 2))) {
    heff_drop(v_kind_249);
    heff_drop(v_text_2410);
    heff_clo_take(self, 6);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam4, 1, 6, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245})));
  } else {
    heff_drop(v_kind_249);
    heff_drop(v_text_2410);
    heff_clo_take(self, 6);
    return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eletMutF_str5), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam8, 1, 6, (V[]){v_g_240, v_hd_241, v_x_243, v_x_244, v_x_245, v_k_242})));
  }
}
V g_heff_2esyntax_2ecst_2eletMutF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam3, 1, 6, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletMutF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2eletMutF_str0), ((V)&g_heff_2esyntax_2ecst_2eletMutF_str1), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2eletMutF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletMutF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str1, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str3, 3, "mut");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str5, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str7, 5, "while");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str8, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str9, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str10, 3, "for");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str11, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str12, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str13, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str14, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str15, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str16, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2estmtF_str17, 2, "<-");
V g_heff_2esyntax_2ecst_2estmtF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2estmtF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estmtF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2estmtF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam14(V self, V *args); static Clo g_heff_2esyntax_2ecst_2estmtF_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estmtF_lam14, 1, 0};
V g_heff_2esyntax_2ecst_2estmtF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2estmtF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2estmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estmtF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2estmtF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2estmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2estmtF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2estmtF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2estmtF_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EWhile, 4, (V[]){v_x_2415, v_x_2416, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estmtF_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock(heff_get_n(v_g_240, 14, 17), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam6, 1, 4, (V[]){v_k_242, v_x_2415, v_x_2416, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2estmtF_str8), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam5, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2415, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_240, 13));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam4, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2estmtF_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_tag_n(TAG_ESBind, 3, (V[]){heff_tag_n(TAG_PAtom, 1, (V[]){v_x_2419}), v_x_2420, v_x_2421});
  V f_ = v_k_242;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estmtF_lam8(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2ebindRhsF(v_g_240, v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam9, 1, 3, (V[]){v_x_2419, v_x_2420, v_k_242})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam8, 1, 4, (V[]){v_g_240, v_hd_241, v_x_2419, v_k_242})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam13(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ESBind, 3, (V[]){v_x_2427, v_x_2428, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estmtF_lam12(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2ebindRhsF(v_g_240, v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam13, 1, 3, (V[]){v_k_242, v_x_2427, v_x_2428})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam11(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2estmtF_str15), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam12, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2427})));
}
V g_heff_2esyntax_2ecst_2estmtF_lam10(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  if ((heff_dup(v_x_2426) == NTAG(TAG_True))) {
    heff_drop(v_x_2426);
    heff_clo_take(self, 3);
    V f_ = heff_dup(heff_rfield(v_g_240, 7));
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam11, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2426);
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2earmF(v_g_240, v_hd_241, v_k_242));
  }
}
V g_heff_2esyntax_2ecst_2estmtF_lam14(V self, V *args) {
  V v_s_2431 = args[0];
  V v_toks_2432 = heff_take_field(v_s_2431, 0);
  V v_i_2433 = heff_get_n(v_s_2431, 1, 5);
  V v_xs_2434 = heff_dup(v_toks_2432);
  V v_i_2435 = ({ V a_0 = v_toks_2432; V a_1 = v_i_2433; V a_2 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2ecst_2ecloseAfter(a_0, a_1, a_2)); heff_drop(v_toks_2432); r_; });
  if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2435, 1) && heff_intLt_c_lent(v_i_2435, heff_arrayLength_lent(v_xs_2434, 0), 2))) {
    V v_u_2436 = heff_arrayIndex(v_xs_2434, v_i_2435);
    V v_kind_2437 = heff_take_field(v_u_2436, 0);
    V v_text_2438 = heff_get_n(v_u_2436, 1, 9);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_kind_2437, ((V)&g_heff_2esyntax_2ecst_2estmtF_str16), 2) && heff_strEq_c_lent(v_text_2438, ((V)&g_heff_2esyntax_2ecst_2estmtF_str17), 2)));
    heff_drop(v_kind_2437);
    heff_drop(v_text_2438);
    return v_ret_24bool;
  } else {
    heff_drop(v_xs_2434);
    heff_drop(v_i_2435);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2ecst_2estmtF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_kind_246 = heff_env(self)[0];
  V v_text_247 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_kind_2413 = heff_take_field(v_x_2412, 0);
  V v_text_2414 = heff_get_n(v_x_2412, 1, 9);
  if (((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2estmtF_str0), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2estmtF_str1), 2)) && (heff_strEq_c_lent(v_kind_2413, ((V)&g_heff_2esyntax_2ecst_2estmtF_str2), 2) && heff_strEq_c_lent(v_text_2414, ((V)&g_heff_2esyntax_2ecst_2estmtF_str3), 2)))) {
    heff_clo_take(self, 5);
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    heff_drop(v_kind_2413);
    heff_drop(v_text_2414);
    return (g_heff_2esyntax_2ecst_2eletMutF(v_g_240, v_hd_241, v_k_242));
  } else {
    heff_drop(v_kind_2413);
    if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2estmtF_str4), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2estmtF_str5), 2))) {
      heff_clo_take(self, 5);
      heff_drop(v_kind_246);
      heff_drop(v_text_247);
      heff_drop(v_text_2414);
      return (g_heff_2esyntax_2ecst_2eletStmtF(v_g_240, v_hd_241, v_k_242));
    } else {
      if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2estmtF_str6), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2estmtF_str7), 2))) {
        heff_clo_take(self, 5);
        heff_drop(v_kind_246);
        heff_drop(v_text_247);
        heff_drop(v_text_2414);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam3, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
      } else {
        if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2estmtF_str9), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2estmtF_str10), 2))) {
          heff_clo_take(self, 5);
          heff_drop(v_kind_246);
          heff_drop(v_text_247);
          heff_drop(v_text_2414);
          return (g_heff_2esyntax_2ecst_2eforF(v_g_240, v_hd_241, v_k_242));
        } else {
          if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2estmtF_str11), 2) && heff_strEq_c_lent(v_text_2414, ((V)&g_heff_2esyntax_2ecst_2estmtF_str12), 2))) {
            heff_clo_take(self, 5);
            heff_drop(v_kind_246);
            heff_drop(v_text_247);
            heff_drop(v_text_2414);
            return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam7, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
          } else {
            heff_drop(v_text_2414);
            if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2estmtF_str13), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2estmtF_str14), 2))) {
              heff_clo_take(self, 5);
              heff_drop(v_kind_246);
              heff_drop(v_text_247);
              V v_hd_2423 = heff_dup(v_hd_241);
              V v_malg_2424 = heff_take_field(v_hd_2423, 2);
              V v_bind_2425 = heff_get_n(v_hd_2423, 1, 3);
              V v_k2_2430 = heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam10, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242});
              V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2estmtF_lam14_clo)})});
              V v_t_2440 = heff_tr(heff_call(v_malg_2424, 1, (V[]){v_t_2439}));
              V f_ = v_bind_2425;
              heff_room[0] = v_t_2440;
              heff_room[1] = v_k2_2430;
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            } else {
              heff_clo_take(self, 5);
              heff_drop(v_kind_246);
              heff_drop(v_text_247);
              return (g_heff_2esyntax_2ecst_2earmF(v_g_240, v_hd_241, v_k_242));
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2estmtF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_get_n(v_x_245, 1, 9);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2estmtF_lam1_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2410}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estmtF_lam2, 1, 5, (V[]){v_kind_246, v_text_247, v_g_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eparenPatF_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparenPatF_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparenPatF_str2, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparenPatF_str3, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparenPatF_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparenPatF_str5, 1, ")");
V g_heff_2esyntax_2ecst_2eparenPatF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eparenPatF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eparenPatF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eparenPatF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eparenPatF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eparenPatF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eparenPatF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eparenPatF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eparenPatF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eparenPatF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparenPatF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eparenPatF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eparenPatF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eparenPatF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_PList, 4, (V[]){v_x_243, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2411});
  V f_ = v_k_245;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_t_2422;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkSep: {
    V v_items_2420 = heff_field(v_x_2418, 0);
    V v_seps_2421 = heff_field(v_x_2418, 1);
    heff_take_n(v_x_2418, 3ULL, 2);
    v_t_2422 = heff_tag_n(TAG_PList, 4, (V[]){v_x_243, v_items_2420, v_seps_2421, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_245;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparenPatF_str4), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam7, 1, 3, (V[]){v_x_2418, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam8(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_PParen, 3, (V[]){v_x_243, v_x_2413, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_2416, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparenPatF_str2))) {
    heff_clo_take(self, 5);
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2eparenPatF_str3), heff_get_n(v_g_240, 5, 17), v_t_2417, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam6, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  } else {
    heff_clo_take(self, 5);
    heff_drop_rec(v_g_240, 17);
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparenPatF_str5), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam8, 1, 3, (V[]){v_k_245, v_x_243, v_x_2413})));
  }
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2414}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam5, 1, 5, (V[]){v_x_2413, v_g_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_kind_249 = heff_take_field(v_x_248, 0);
  V v_text_2410 = heff_get_n(v_x_248, 1, 9);
  if ((heff_strEq_c_lent(v_kind_249, ((V)&g_heff_2esyntax_2ecst_2eparenPatF_str0), 2) && heff_strEq_c_lent(v_text_2410, ((V)&g_heff_2esyntax_2ecst_2eparenPatF_str1), 2))) {
    heff_clo_take(self, 4);
    heff_drop_rec(v_g_240, 17);
    heff_drop(v_kind_249);
    heff_drop(v_text_2410);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam3, 1, 2, (V[]){v_x_243, v_k_245})));
  } else {
    heff_drop(v_kind_249);
    heff_drop(v_text_2410);
    heff_clo_take(self, 4);
    V f_ = heff_dup(heff_rfield(v_g_240, 5));
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam4, 1, 4, (V[]){v_hd_244, v_g_240, v_x_243, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam2, 1, 4, (V[]){v_hd_244, v_x_243, v_k_245, v_g_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eparenPatF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eparenPatF_lam1, 2, 2, (V[]){v_x_243, v_g_240}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_245, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_245, v_t_246));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam8(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_2411, v_x_2418, v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam8, 1, 3, (V[]){v_k_241, v_x_2411, v_x_2418})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_kind_2415 = heff_env(self)[0];
  V v_text_2416 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  if ((heff_strEq_c_lent(v_kind_2415, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str0), 2) && ((heff_strEq_c_lent(v_text_2416, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str1), 2) || heff_strEq_c_lent(v_text_2416, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_str2), 2)) && !(heff_dup(v_x_2417) == NTAG(TAG_True))))) {
    heff_drop(v_x_2417);
    heff_clo_take(self, 5);
    heff_drop(v_kind_2415);
    heff_drop(v_text_2416);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam7, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2411})));
  } else {
    heff_drop(v_x_2417);
    heff_clo_take(self, 5);
    heff_drop(v_kind_2415);
    heff_drop(v_text_2416);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_2411;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_kind_2415 = heff_take_field(v_x_2414, 0);
  V v_text_2416 = heff_get_n(v_x_2414, 1, 9);
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam6, 1, 5, (V[]){v_kind_2415, v_text_2416, v_hd_240, v_k_241, v_x_2411})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2412}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam5, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2410);
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam4, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldNameF(v_x_244, v_x_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam1_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1109768591x1142874476_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_245, v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam5, 1, 3, (V[]){v_k_241, v_x_245, v_x_2412})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_text_249 = heff_env(self)[0];
  V v_kind_2410 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  if ((heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_str0), 2) && (heff_strEq_c_lent(v_kind_2410, ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_str1), 2) && !(heff_dup(v_x_2411) == NTAG(TAG_True))))) {
    heff_drop(v_x_2411);
    heff_clo_take(self, 5);
    heff_drop(v_text_249);
    heff_drop(v_kind_2410);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_245})));
  } else {
    heff_drop(v_x_2411);
    heff_clo_take(self, 5);
    heff_drop(v_text_249);
    heff_drop(v_kind_2410);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_245;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_text_249 = heff_take_field(v_x_248, 1);
  V v_kind_2410 = heff_get_n(v_x_248, 0, 9);
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam3, 1, 5, (V[]){v_text_249, v_kind_2410, v_hd_240, v_k_241, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929(v_x_244, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1308559179x1762131639_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry, 7, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_hd_246) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0, 1, 7, (V[]){v_hd_246, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_s_2410, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2410, v_t_2411));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10(V self, V *args) {
  V v_x_2433 = args[0];
  V v_sep_2425 = heff_env(self)[0];
  V v_items_2426 = heff_env(self)[1];
  V v_seps_2427 = heff_env(self)[2];
  V v_hd_2428 = heff_env(self)[3];
  V v_k_2429 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2425, v_items_2426, v_x_2433, v_seps_2427, heff_dup(v_hd_2428), v_k_2429, v_hd_2428));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9(V self, V *args) {
  V v_x_2432 = args[0];
  V v_sep_2425 = heff_env(self)[0];
  V v_hd_2428 = heff_env(self)[1];
  V v_items_2426 = heff_env(self)[2];
  V v_seps_2427 = heff_env(self)[3];
  V v_k_2429 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_2432, 1, 9), heff_dup(v_sep_2425))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2428), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam10, 1, 5, (V[]){v_sep_2425, v_items_2426, v_seps_2427, v_hd_2428, v_k_2429})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_2425);
    heff_drop_rec(v_hd_2428, 3);
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2426));
    V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2427));
    V v_x_2436 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2434, v_t_2435});
    V f_ = v_k_2429;
    args[0] = v_x_2436;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8(V self, V *args) {
  V v_x_2424 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_sep_2425 = v_lit_240;
  V v_items_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_2416, v_x_2423, v_x_2424}), v_lit_241});
  V v_seps_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
  V v_hd_2428 = v_lit_244;
  V v_k_2429 = v_lit_245;
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2428, 2)), 1, (V[]){v_t_2430}));
  V f_ = heff_dup(heff_rfield(v_hd_2428, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam9, 1, 5, (V[]){v_sep_2425, v_hd_2428, v_items_2426, v_seps_2427, v_k_2429});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_246, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam8, 1, 8, (V[]){v_lit_240, v_x_2416, v_x_2423, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam12(V self, V *args) {
  V v_x_2445 = args[0];
  V v_sep_2437 = heff_env(self)[0];
  V v_items_2438 = heff_env(self)[1];
  V v_seps_2439 = heff_env(self)[2];
  V v_hd_2440 = heff_env(self)[3];
  V v_k_2441 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266(v_sep_2437, v_items_2438, v_x_2445, v_seps_2439, heff_dup(v_hd_2440), v_k_2441, v_hd_2440));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam11(V self, V *args) {
  V v_x_2444 = args[0];
  V v_sep_2437 = heff_env(self)[0];
  V v_hd_2440 = heff_env(self)[1];
  V v_items_2438 = heff_env(self)[2];
  V v_seps_2439 = heff_env(self)[3];
  V v_k_2441 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_2444, 1, 9), heff_dup(v_sep_2437))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2440), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam12, 1, 5, (V[]){v_sep_2437, v_items_2438, v_seps_2439, v_hd_2440, v_k_2441})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_2437);
    heff_drop_rec(v_hd_2440, 3);
    V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2438));
    V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_2439));
    V v_x_2448 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2446, v_t_2447});
    V f_ = v_k_2441;
    args[0] = v_x_2448;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_kind_2420 = heff_env(self)[0];
  V v_text_2421 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_lit_243 = heff_env(self)[7];
  V v_lit_244 = heff_env(self)[8];
  V v_lit_245 = heff_env(self)[9];
  if ((heff_strEq_c_lent(v_kind_2420, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str0), 2) && ((heff_strEq_c_lent(v_text_2421, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str1), 2) || heff_strEq_c_lent(v_text_2421, ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_str2), 2)) && !(heff_dup(v_x_2422) == NTAG(TAG_True))))) {
    heff_drop(v_x_2422);
    heff_clo_take(self, 10);
    heff_drop(v_kind_2420);
    heff_drop(v_text_2421);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam7, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_2416, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
  } else {
    heff_drop(v_x_2422);
    heff_clo_take(self, 10);
    heff_drop(v_kind_2420);
    heff_drop(v_text_2421);
    heff_drop_rec(v_hd_246, 3);
    V v_sep_2437 = v_lit_240;
    V v_items_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_lit_241});
    V v_seps_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_lit_243});
    V v_hd_2440 = v_lit_244;
    V v_k_2441 = v_lit_245;
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2440, 2)), 1, (V[]){v_t_2442}));
    V f_ = heff_dup(heff_rfield(v_hd_2440, 1));
    heff_room[0] = v_t_2443;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam11, 1, 5, (V[]){v_sep_2437, v_hd_2440, v_items_2438, v_seps_2439, v_k_2441});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  V v_kind_2420 = heff_take_field(v_x_2419, 0);
  V v_text_2421 = heff_get_n(v_x_2419, 1, 9);
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam6, 1, 10, (V[]){v_kind_2420, v_text_2421, v_hd_246, v_lit_240, v_x_2416, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2417}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam5, 1, 8, (V[]){v_hd_246, v_lit_240, v_x_2416, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  heff_drop(v_x_2415);
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam4, 1, 7, (V[]){v_hd_246, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_lit_244 = heff_env(self)[6];
  V v_lit_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2efieldNameF(v_x_249, v_x_2414, heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam3, 1, 7, (V[]){v_hd_246, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam1_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2412}));
  heff_clo_take(self, 7);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s1258428165x1601266266_lam2, 1, 8, (V[]){v_x_249, v_hd_246, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4, 28, "expected an expression, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str5, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str6, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str9, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2419, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
    heff_drop(v_x_245);
    heff_clo_take(self, 3);
    V v_span_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_take_field(v_x_244, 4)});
    V v_t_248;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0))) {
      heff_drop_rec(v_x_244, 9);
      v_t_248 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1);
    } else {
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2), heff_get_n(v_x_244, 1, 9));
      v_t_248 = heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3));
    }
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4), v_t_248), v_span_246, NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2410}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2411;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_245);
    V v_x1_2412 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_244)));
    if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
      heff_drop(v_x1_2412);
      heff_clo_take(self, 3);
      V v_span_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_take_field(v_x_244, 4)});
      V v_t_2415;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str5))) {
        heff_drop_rec(v_x_244, 9);
        v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str6);
      } else {
        V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str7), heff_get_n(v_x_244, 1, 9));
        v_t_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str8));
      }
      V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str9), v_t_2415), v_span_2413, NTAG(TAG_Nothing)});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2417}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2418;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x1_2412);
      heff_clo_take(self, 3);
      return (g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(v_x_244, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_sep_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_items_241}); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2etheoryFieldName(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_248, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1599280412x746180301_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2410, v_t_2411});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2elocalDecl_str2, 58, "an instance is declared at the top level, not in a `where`");
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elocalDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elocalDecl_entry, 2, 0};

V g_heff_2esyntax_2ecst_2elocalDecl(V v_st_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_st_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2elocalDecl_lam0, 1, 2, (V[]){v_st_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elocalDecl(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  if ((heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str1)))) {
    V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elocalDecl_str2), v_t_245, NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
    heff_clo_take(self, 2);
    V v_t_248 = heff_tr(heff_call(heff_take_field(v_st_240, 2), 1, (V[]){v_t_247}));
    V f_ = heff_get_n(v_st_240, 1, 3);
    heff_room[0] = v_t_248;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 2);
    return (g_heff_2esyntax_2ecst_2esigOrEqn(((V)&g_heff_2esyntax_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str2, 5, "where");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str4, 4, "once");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str5, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str6, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str7, 65, "an instance is declared at the top level, not in a `mutual` block");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str8, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str9, 7, "doctest");
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_x_245 = heff_dup(heff_rfield(v_s_244, 1));
  V v_top_246 = heff_take_field(v_s_244, 2);
  V v_stack_247 = heff_take_field(v_s_244, 3);
  return ({ V rv_2 = v_top_246; V rv_3 = v_stack_247; V rv_4 = v_x_245; V rr_ = heff_rec_reuse_nf(v_s_244, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_kind_2419 = heff_take_field(v_x_2418, 0);
  V v_first_2420 = heff_take_field(v_x_2418, 6);
  V v_col_2421 = heff_take_field(v_x_2418, 5);
  V v_text_2422 = heff_get_n(v_x_2418, 1, 9);
  if ((heff_strEq_c_lent(v_kind_2419, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str0), 2) ? 0 : ((heff_dup(v_first_2420) == NTAG(TAG_True)) && (heff_intEq_c_lent(v_col_2421, v_col_240, 0) && ((heff_strEq_c_lent(v_kind_2419, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str1), 2) && heff_strEq_c_lent(v_text_2422, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str2), 2)) ? 0 : (heff_strEq_c_lent(v_kind_2419, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str3), 2) ? !heff_strEq_c_lent(v_text_2422, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str4), 2) : 1)))))) {
    heff_drop(v_kind_2419);
    heff_drop(v_first_2420);
    heff_drop(v_col_2421);
    heff_drop(v_text_2422);
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697(v_col_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_acc_241}), v_hd_242, v_k_243));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_col_240);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_kind_2419);
    heff_drop(v_first_2420);
    heff_drop(v_col_2421);
    heff_drop(v_text_2422);
    V v_x_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2423;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2416}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam4, 1, 5, (V[]){v_col_240, v_x_2415, v_acc_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2424 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_DWatch, 2, (V[]){v_x_2432, v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_2414, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam7, 1, 2, (V[]){v_k_2424, v_x_2432})));
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  if ((heff_strEq_c(heff_dup(heff_rfield(v_x_2427, 0)), ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str5)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2427, 1)), ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str6)))) {
    V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2427, 3), heff_get_n(v_x_2427, 4, 9)});
    V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str7), v_t_2428, NTAG(TAG_Nothing)});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
    heff_clo_take(self, 2);
    V v_t_2431 = heff_tr(heff_call(heff_take_field(v_hd_2414, 2), 1, (V[]){v_t_2430}));
    V f_ = heff_get_n(v_hd_2414, 1, 3);
    heff_room[0] = v_t_2431;
    heff_room[1] = v_k_2424;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if ((heff_strEq_c(heff_dup(heff_rfield(v_x_2427, 0)), ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str8)) || heff_strEq_c(heff_dup(heff_rfield(v_x_2427, 0)), ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_str9)))) {
      heff_drop_rec(v_x_2427, 9);
      heff_clo_take(self, 2);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2414), heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam6, 1, 2, (V[]){v_hd_2414, v_k_2424})));
    } else {
      heff_clo_take(self, 2);
      return (g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(v_x_2427, v_hd_2414, v_k_2424));
    }
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_drop(v_x_2413);
  V v_hd_2414 = heff_dup(v_hd_242);
  heff_clo_take(self, 4);
  V v_k_2424 = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2414, 2)), 1, (V[]){v_t_2425}));
  V f_ = heff_dup(heff_rfield(v_hd_2414, 1));
  heff_room[0] = v_t_2426;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam5, 1, 2, (V[]){v_hd_2414, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s346702365x1508445697_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str6, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str8, 0, "");
Clo g_heff_2esyntax_2ecst_2efirstD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_242);
  }
  case TAG_DSig: {
    V v_ns_244 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_ns_244)) {
    case TAG_Nil: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str0), ((V)&g_heff_2esyntax_2ecst_2efirstD_str1), ((V)&g_heff_2esyntax_2ecst_2efirstD_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_ns_244, 0);
      switch (heff_tag_of(v_n_248)) {
      case TAG_Nil: {
        return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str3), ((V)&g_heff_2esyntax_2ecst_2efirstD_str4), ((V)&g_heff_2esyntax_2ecst_2efirstD_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_n_248, 0);
        return heff_dup(v_x_2410);
      }
      default: return heff_nomatch(v_n_248);
      }
    }
    default: return heff_nomatch(v_ns_244);
    }
  }
  case TAG_DInstance: {
    V v_kw_2412 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2412);
  }
  case TAG_DEqn: {
    V v_n_2416 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_n_2416)) {
    case TAG_Nil: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str6), ((V)&g_heff_2esyntax_2ecst_2efirstD_str7), ((V)&g_heff_2esyntax_2ecst_2efirstD_str8), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_n_2416, 0);
      return heff_dup(v_x_2421);
    }
    default: return heff_nomatch(v_n_2416);
    }
  }
  case TAG_DData: {
    V v_kw_2423 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2423);
  }
  case TAG_DType: {
    V v_kw_2428 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2428);
  }
  case TAG_DTheory: {
    V v_kw_2433 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2433);
  }
  case TAG_DMutual: {
    V v_kw_2438 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2438);
  }
  case TAG_DPrimitive: {
    V v_kw_2440 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2440);
  }
  case TAG_DTest: {
    V v_kw_2444 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2444);
  }
  case TAG_DWatch: {
    V v_w_2446 = heff_field(v_x1_240, 0);
    return heff_dup(v_w_2446);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstD(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    V v_ts_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ts_243));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nil: {
      return v_kw_242;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 2);
      heff_drop(v_kw_242);
      return v_x_245;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_DSig: {
    V v_ty_2410 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2410);
  }
  case TAG_DInstance: {
    V v_ty_2414 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2414);
  }
  case TAG_DEqn: {
    V v_rhs_2418 = heff_field(v_x1_240, 3);
    V v_x15_2419 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    switch (heff_tag_of(v_x15_2419)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_rhs_2418);
    }
    case TAG_Just: {
      V v_x151_2420 = heff_field(v_x15_2419, 0);
      heff_take_n(v_x15_2419, 1ULL, 1);
      heff_drop(v_rhs_2418);
      switch (heff_tag_of(v_x151_2420)) {
      case TAG_MkPair: {
        V v_kw_2421 = heff_field(v_x151_2420, 0);
        V v_ds_2422 = heff_field(v_x151_2420, 1);
        heff_take_n(v_x151_2420, 3ULL, 2);
        V v_x1_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_2422));
        switch (heff_tag_of(v_x1_2423)) {
        case TAG_Nil: {
          return v_kw_2421;
        }
        case TAG_Cons: {
          V v_x_2424 = heff_field(v_x1_2423, 0);
          heff_take_n(v_x1_2423, 1ULL, 2);
          heff_drop(v_kw_2421);
          V t_0 = v_x_2424;
          v_x1_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_x1_2423);
        }
      }
      default: return heff_nomatch(v_x151_2420);
      }
    }
    default: return heff_nomatch(v_x15_2419);
    }
  }
  case TAG_DData: {
    V v_name_2427 = heff_field(v_x1_240, 1);
    V v_params_2428 = heff_field(v_x1_240, 2);
    V v_universe_2429 = heff_field(v_x1_240, 3);
    V v_alts_2430 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 30ULL, 5);
    V v_name_2431 = v_name_2427;
    V v_params_2432 = v_params_2428;
    V v_universe_2433 = v_universe_2429;
    V v_x4_2434 = v_alts_2430;
    switch (heff_tag_of(v_x4_2434)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_universe_2433)) {
      case TAG_Nothing: {
        V v_x1_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_params_2432));
        switch (heff_tag_of(v_x1_2435)) {
        case TAG_Nil: {
          return v_name_2431;
        }
        case TAG_Cons: {
          V v_x_2436 = heff_field(v_x1_2435, 0);
          heff_take_n(v_x1_2435, 1ULL, 2);
          heff_drop(v_name_2431);
          HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_x_2436);
        }
        default: return heff_nomatch(v_x1_2435);
        }
      }
      case TAG_Just: {
        V v_x31_2438 = heff_field(v_universe_2433, 0);
        heff_take_n(v_universe_2433, 1ULL, 1);
        heff_drop(v_name_2431);
        heff_drop(v_params_2432);
        switch (heff_tag_of(v_x31_2438)) {
        case TAG_MkPair: {
          V v_u_2440 = heff_field(v_x31_2438, 1);
          heff_take_n(v_x31_2438, 2ULL, 2);
          HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_u_2440);
        }
        default: return heff_nomatch(v_x31_2438);
        }
      }
      default: return heff_nomatch(v_universe_2433);
      }
    }
    case TAG_Just: {
      V v_x41_2441 = heff_field(v_x4_2434, 0);
      heff_take_n(v_x4_2434, 1ULL, 1);
      switch (heff_tag_of(v_x41_2441)) {
      case TAG_MkDAlts: {
        V v_alts_2443 = heff_field(v_x41_2441, 1);
        heff_take_n(v_x41_2441, 2ULL, 3);
        V v_t_2451;
        switch (heff_tag_of(v_universe_2433)) {
        case TAG_Nothing: {
          V v_x1_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_params_2432));
          switch (heff_tag_of(v_x1_2445)) {
          case TAG_Nil: {
            v_t_2451 = v_name_2431;
            break;
          }
          case TAG_Cons: {
            V v_x_2446 = heff_field(v_x1_2445, 0);
            heff_take_n(v_x1_2445, 1ULL, 2);
            heff_drop(v_name_2431);
            v_t_2451 = (g_heff_2esyntax_2ecst_2elastE(v_x_2446));
            break;
          }
          default: heff_nomatch(v_x1_2445);
          }
          break;
        }
        case TAG_Just: {
          V v_x31_2448 = heff_field(v_universe_2433, 0);
          heff_take_n(v_universe_2433, 1ULL, 1);
          heff_drop(v_name_2431);
          heff_drop(v_params_2432);
          switch (heff_tag_of(v_x31_2448)) {
          case TAG_MkPair: {
            V v_u_2450 = heff_field(v_x31_2448, 1);
            heff_take_n(v_x31_2448, 2ULL, 2);
            v_t_2451 = (g_heff_2esyntax_2ecst_2elastE(v_u_2450));
            break;
          }
          default: heff_nomatch(v_x31_2448);
          }
          break;
        }
        default: heff_nomatch(v_universe_2433);
        }
        V v_x1_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_alts_2443));
        switch (heff_tag_of(v_x1_2452)) {
        case TAG_Nil: {
          return v_t_2451;
        }
        case TAG_Cons: {
          V v_x_2453 = heff_field(v_x1_2452, 0);
          heff_take_n(v_x1_2452, 1ULL, 2);
          heff_drop(v_t_2451);
          HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_x_2453);
        }
        default: return heff_nomatch(v_x1_2452);
        }
      }
      default: return heff_nomatch(v_x41_2441);
      }
    }
    default: return heff_nomatch(v_x4_2434);
    }
  }
  case TAG_DType: {
    V v_body_2459 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_body_2459);
  }
  case TAG_DTheory: {
    V v_w_2463 = heff_field(v_x1_240, 3);
    V v_fields_2464 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    V v_x1_2465 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fields_2464));
    switch (heff_tag_of(v_x1_2465)) {
    case TAG_Nil: {
      return v_w_2463;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x1_2465, 0);
      heff_take_n(v_x1_2465, 1ULL, 2);
      heff_drop(v_w_2463);
      switch (heff_tag_of(v_x_2466)) {
      case TAG_MkTF: {
        V v_ty_2471 = heff_field(v_x_2466, 3);
        V v_x15_2472 = heff_field(v_x_2466, 4);
        heff_take_n(v_x_2466, 24ULL, 5);
        switch (heff_tag_of(v_x15_2472)) {
        case TAG_Nothing: {
          HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2471);
        }
        case TAG_Just: {
          V v_x151_2473 = heff_field(v_x15_2472, 0);
          heff_take_n(v_x15_2472, 1ULL, 1);
          heff_drop(v_ty_2471);
          switch (heff_tag_of(v_x151_2473)) {
          case TAG_MkPair: {
            V v_d_2475 = heff_field(v_x151_2473, 1);
            heff_take_n(v_x151_2473, 2ULL, 2);
            HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_d_2475);
          }
          default: return heff_nomatch(v_x151_2473);
          }
        }
        default: return heff_nomatch(v_x15_2472);
        }
      }
      default: return heff_nomatch(v_x_2466);
      }
    }
    default: return heff_nomatch(v_x1_2465);
    }
  }
  case TAG_DMutual: {
    V v_kw_2476 = heff_field(v_x1_240, 0);
    V v_ds_2477 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_2477));
    switch (heff_tag_of(v_x1_2478)) {
    case TAG_Nil: {
      return v_kw_2476;
    }
    case TAG_Cons: {
      V v_x_2479 = heff_field(v_x1_2478, 0);
      heff_take_n(v_x1_2478, 1ULL, 2);
      heff_drop(v_kw_2476);
      V t_0 = v_x_2479;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2478);
    }
  }
  case TAG_DPrimitive: {
    V v_ty_2484 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2484);
  }
  case TAG_DTest: {
    V v_x_2486 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_x_2486;
  }
  case TAG_DWatch: {
    V v_e_2488 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_e_2488);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastD(a[0]);
}