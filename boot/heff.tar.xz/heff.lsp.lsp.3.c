// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_PathUri 23459
#define TAG_Send 26077
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_checked 974171621
#define LBL_current 1358797751
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_selection 2055983820
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_uses 10094739
#define LBL_watch 314261737
static uint32_t shape_at__text[] = {LBL_at, LBL_text};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2einFile(V, V, V);
V g_heff_2ebuild_2equery_2einFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFile_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205(V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739(V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159(V, V, V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(V);
V g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2elinesFrom_24dps(V, V, V);
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo;
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679(V, V);
V g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_clo;
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120(V, V, V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_24tok1_clo;
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481(V, V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212(V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212_clo;
V g_heff_2elsp_2elsp_2ezeroSpan_get(void);
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(V, V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_entry(V self, V *a);
extern Clo g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eascending_24s1053575971x1138989897(V, V, V);
V g_list_2eascending_24s1053575971x1138989897_entry(V self, V *a);
extern Clo g_list_2eascending_24s1053575971x1138989897_clo;
V g_list_2edescending_24s136597790x1673774577(V, V, V);
V g_list_2edescending_24s136597790x1673774577_entry(V self, V *a);
extern Clo g_list_2edescending_24s136597790x1673774577_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1392650298x1192381411(V, V, V);
V g_list_2emap_24s1392650298x1192381411_entry(V self, V *a);
extern Clo g_list_2emap_24s1392650298x1192381411_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s328130413x305756849(V, V, V, V);
V g_list_2emap_24s328130413x305756849_entry(V self, V *a);
extern Clo g_list_2emap_24s328130413x305756849_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s4199228x1154005405_24tok2(V, V);
V g_list_2emap_24s4199228x1154005405_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s655705766x180835539(V, V);
V g_list_2emergeRuns_24s655705766x180835539_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s655705766x180835539_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2elsp_2elsp_2eoffset16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffset16_entry, 4, 0};

V g_heff_2elsp_2elsp_2eoffset16(V v_src_240, V v_i_241, V v_e_242, V v_n_243) {
top: ;
  if ((heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2) || heff_intLe_c_lent(v_e_242, v_i_241, 0))) {
    heff_drop(v_n_243);
    if (heff_intLe_c_lent(v_i_241, v_e_242, 0)) {
      return v_i_241;
    } else {
      heff_drop(v_i_241);
      return heff_dup(v_e_242);
    }
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_e_242;
      V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_e_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      HeffT2 v_t_244 = heff_strRuneDecode_lent(v_src_240, v_i_241, 0);
      {
        V v_rune_245 = v_t_244.f[0];
        V v_width_246 = v_t_244.f[1];
        V v_t_247;
        if (heff_intLe_c(MK_INT(65536LL), heff_runeToInt(v_rune_245))) {
          v_t_247 = MK_INT(2LL);
        } else {
          v_t_247 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, v_width_246);
        V t_2 = v_e_242;
        V t_3 = heff_intSub(v_n_243, v_t_247);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_e_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eoffset16(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str0, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str1, 8, "position");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str2, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetIn_str3, 8, "position");
Clo g_heff_2elsp_2elsp_2eoffsetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetIn_entry, 2, 0};

V g_heff_2elsp_2elsp_2eoffsetIn(V v_src_240, V v_params_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_243 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str1), v_t_242}); V a_1 = heff_dup(v_params_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str2), NTAG(TAG_Nil)});
    HeffT2 v_t_247 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eoffsetIn_str3), v_t_246}); V a_1 = v_params_241; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2417;
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_it1_2410 = v_field_245;
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_JNull: {
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2412 = heff_field(v_it1_2410, 0);
          heff_take_n(v_it1_2410, 1ULL, 1);
          v_t_2417 = v_i_2412;
          break;
        }
        case TAG_JFloat: {
          double v_x_2413 = heff_tflat_f64(v_it1_2410, 0);
          heff_take_na(v_it1_2410, 0ULL, 1);
          v_t_2417 = heff_floor_f64(v_x_2413);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2410, 0ULL, 1);
          v_t_2417 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2410);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2417 = MK_INT(0LL);
      }
      V v_t_2425;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_it1_2418 = v_field_249;
        switch (heff_tag_of(v_it1_2418)) {
        case TAG_JNull: {
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2420 = heff_field(v_it1_2418, 0);
          heff_take_n(v_it1_2418, 1ULL, 1);
          v_t_2425 = v_i_2420;
          break;
        }
        case TAG_JFloat: {
          double v_x_2421 = heff_tflat_f64(v_it1_2418, 0);
          heff_take_na(v_it1_2418, 0ULL, 1);
          v_t_2425 = heff_floor_f64(v_x_2421);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2418, 0ULL, 1);
          v_t_2425 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2418);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2425 = MK_INT(0LL);
      }
      return ({ V a_0 = v_src_240; V a_1 = v_t_2417; V a_2 = v_t_2425; V a_3 = MK_INT(0LL); V a_4 = MK_INT(0LL); V r_ = (g_heff_2elsp_2elsp_2eoffsetGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2417); heff_drop(v_t_2425); r_; });
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eoffsetIn(a0, a[1]); heff_drop(a0); return r;
}
HEFF_REC_LIT(g_heff_2elsp_2elsp_2ezeroSpan_lit0, 2, shape_start__end, MK_INT(0LL), MK_INT(0LL));

static V g_heff_2elsp_2elsp_2ezeroSpan_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ezeroSpan_st;
static V g_heff_2elsp_2elsp_2ezeroSpan_init(void) {
  return ((V)&g_heff_2elsp_2elsp_2ezeroSpan_lit0);
}
V g_heff_2elsp_2elsp_2ezeroSpan_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ezeroSpan_st)) return g_heff_2elsp_2elsp_2ezeroSpan_val;
  return heff_global(&g_heff_2elsp_2elsp_2ezeroSpan_val, &g_heff_2elsp_2elsp_2ezeroSpan_st, g_heff_2elsp_2elsp_2ezeroSpan_init);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_24dps_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2elinesFrom_24dps_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2elinesFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elinesFrom_24dps_entry, 3, 0};

V g_heff_2elsp_2elsp_2elinesFrom_24dps(V v_src_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_src_240, 0), v_i_241, 1)) {
    heff_drop(v_i_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_d_243 = heff_strLength_lent(v_src_240, 0);
    V v_j_244 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_24dps_str0), v_src_240, v_i_241, 1);
    V v_t_245;
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      v_t_245 = v_d_243;
    } else {
      heff_drop(v_d_243);
      v_t_245 = v_j_244;
    }
    V v_d_246 = heff_strLength_lent(v_src_240, 0);
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2elinesFrom_24dps_str1), v_src_240, v_i_241, 1);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_248 = v_d_246;
    } else {
      heff_drop(v_d_246);
      v_t_248 = v_j_247;
    }
    V v_t_249 = heff_rec_n(2, shape_at__text, (V[]){heff_dup(v_i_241), heff_strSlice_lent(v_src_240, v_i_241, v_t_245, 6)});
    V v_cell_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2410);
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_t_248, MK_INT(1LL));
    V t_2 = v_u_2411;
    v_src_240 = t_0;
    v_i_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elinesFrom_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2elsp_2elsp_2elinesFrom_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str0, 6, "change");
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2ecapabilities_lit1, TAG_JInt, 1, MK_INT(1LL));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2ecapabilities_lit_v_t_240, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2ecapabilities_str0), ((V)&g_heff_2elsp_2elsp_2ecapabilities_lit1));
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str2, 11, "includeText");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str3, 4, "save");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str4, 9, "openClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str5, 16, "textDocumentSync");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str6, 1, ".");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str7, 17, "triggerCharacters");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str8, 18, "completionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str9, 15, "prepareProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str10, 14, "renameProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str11, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str12, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str13, 15, "codeActionKinds");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str14, 18, "codeActionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str15, 23, "workspaceSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str16, 22, "documentSymbolProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str17, 25, "documentHighlightProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str18, 18, "referencesProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str19, 26, "documentFormattingProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str20, 18, "definitionProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str21, 13, "hoverProvider");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str22, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str23, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str24, 10, "serverInfo");
HEFF_LIT(g_heff_2elsp_2elsp_2ecapabilities_str25, 12, "capabilities");

static V g_heff_2elsp_2elsp_2ecapabilities_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ecapabilities_st;
static V g_heff_2elsp_2elsp_2ecapabilities_init(void) {
  V v_t_240 = ((V)&g_heff_2elsp_2elsp_2ecapabilities_lit_v_t_240);
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str2), heff_dup(g_heff_2elsp_2elsp_2ejfalse_get())}), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str3), heff_tag_n(TAG_JObject, 1, (V[]){v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str4), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_240, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str5), heff_tag_n(TAG_JObject, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str6)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str7), heff_tag_n(TAG_JArray, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str8), heff_tag_n(TAG_JObject, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str9), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str10), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str11)}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str12)}), v_t_2412});
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str13), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str14), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str15), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2417});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str16), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str17), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str18), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str19), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str20), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str21), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str22), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str23)})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str24), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecapabilities_str25), v_t_2425}), v_t_2429});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2430});
}
V g_heff_2elsp_2elsp_2ecapabilities_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ecapabilities_st)) return g_heff_2elsp_2elsp_2ecapabilities_val;
  return heff_global(&g_heff_2elsp_2elsp_2ecapabilities_val, &g_heff_2elsp_2elsp_2ecapabilities_st, g_heff_2elsp_2elsp_2ecapabilities_init);
}
Clo g_heff_2elsp_2elsp_2enubRoots_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubRoots(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s689992630x418898235(v_r_241, v_rs_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_r_241, heff_hole()});
    V v_u_245 = (g_heff_2elsp_2elsp_2enubRoots_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubRoots(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str5, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str6, 0, "");
Clo g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_entry, 3, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406(V v_id_240, V v_code_241, V v_msg_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str1)})});
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_241})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_242})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str4), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str5), v_id_240}), v_t_248});
  V v_t_2410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_249})});
  V v_t_2411 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_str6); V a_1 = v_t_2410; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_2410, 1); r_; });
  V v_a_2412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return heff_tail(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){v_t_2416});
}
V g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_entry, 3, 0};

V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(V v_st_240, V v_f_241, V v_names_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam0, 2, 4, (V[]){v_c_243, v_st_240, v_f_241, v_names_242});
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam2(V self, V *args) {
  V v_n_2417 = args[0];
  V v_had_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_n_2417; V a_1 = v_had_2415; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_n_2417); heff_drop(v_had_2415); r_; });
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_names_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_t_247 = heff_dup(heff_rfield(v_st_240, 3));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_clo_take(self, 5);
    return (g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_pr_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_current_249 = heff_take_field(v_pr_248, 3);
    V v_root_2410 = heff_take_field(v_pr_248, 0);
    V v_names_2411 = heff_take_field(v_pr_248, 1);
    V v_program_2412 = heff_get_n(v_pr_248, 2, 5);
    V v_t_2413 = v_current_249;
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      if (heff_strEq_c(v_root_2410, heff_dup(heff_rfield(v_x_246, 0)))) {
        V v_t_2414 = v_names_2411;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_Nothing: {
          heff_drop_rec(v_x_246, 6);
          heff_clo_take(self, 5);
          heff_drop(v_f_241);
          heff_drop(v_names_242);
          heff_drop(v_hd_244);
          V f_ = v_k_245;
          args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_240, v_program_2412});
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Just: {
          V v_had_2415 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          heff_clo_take(self, 5);
          switch (heff_tag_of(v_names_242)) {
          case TAG_Nothing: {
            heff_drop(v_program_2412);
            heff_drop(v_had_2415);
            return (g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
          }
          case TAG_Just: {
            V v_wanted_2416 = heff_dup(heff_field(v_names_242, 0));
            V v_t_2418 = ({ V b_0 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam2, 1, 1, (V[]){v_had_2415}); V a_1 = v_wanted_2416; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_wanted_2416); r_; });
            if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
              heff_drop_rec(v_x_246, 6);
              heff_drop(v_f_241);
              heff_drop_tag(v_names_242, 1);
              heff_drop(v_hd_244);
              heff_drop(v_t_2418);
              V f_ = v_k_245;
              args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_240, v_program_2412});
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              heff_drop(v_program_2412);
              heff_drop(v_t_2418);
              return (g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
            }
          }
          default: return heff_nomatch(v_names_242);
          }
        }
        default: return heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop(v_names_2411);
        heff_drop(v_program_2412);
        heff_clo_take(self, 5);
        return (g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
      }
    } else {
      heff_drop(v_root_2410);
      heff_drop(v_names_2411);
      heff_drop(v_program_2412);
      heff_drop(v_t_2413);
      heff_clo_take(self, 5);
      return (g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124(v_st_240, heff_get_n(v_x_246, 0, 6), v_f_241, v_names_242, v_hd_244, v_k_245));
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_names_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_lam1, 1, 5, (V[]){v_st_240, v_f_241, v_names_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str0, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str1, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str2, 13, "containerName");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str3, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str5, 8, "location");
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam1, 1, 0};
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801(V v_st_240, V v_c_241, V v_y_242) {
top: ;
  V v_selection_243 = heff_take_field(v_y_242, 3);
  V v_name_244 = heff_take_field(v_y_242, 0);
  V v_kind_245 = heff_get_n(v_y_242, 1, 5);
  V v_path_246 = heff_take_field(v_c_241, 1);
  V v_source_247 = heff_take_field(v_c_241, 3);
  V v_module_248 = heff_get_n(v_c_241, 0, 14);
  V v_p_249 = v_path_246;
  HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_c_2421;
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_p_249);
      V v_d_2413 = v_field_2412;
      v_c_2421 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam0, 2, 1, (V[]){v_d_2413});
    } else {
      heff_drop(v_field_2412);
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_249, ((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam1_clo)})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
      v_c_2421 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
    }
    return heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam2, 2, 6, (V[]){v_c_2421, v_source_247, v_selection_243, v_name_244, v_kind_245, v_module_248});
  }
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  heff_drop(v_hd_2414);
  heff_clo_take(self, 1);
  V f_ = v_k_2415;
  args[0] = heff_get_n(v_d_2413, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  return v_u_2416;
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_source_247 = heff_env(self)[0];
  V v_selection_243 = heff_env(self)[1];
  V v_name_244 = heff_env(self)[2];
  V v_kind_245 = heff_env(self)[3];
  V v_module_248 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2425 = ({ V a_0 = v_source_247; V a_1 = v_selection_243; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_247); r_; });
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str0), heff_tag_n(TAG_JString, 1, (V[]){v_name_244})});
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_245})});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str2), heff_tag_n(TAG_JString, 1, (V[]){v_module_248})});
  V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str3), heff_tag_n(TAG_JString, 1, (V[]){v_x_2424})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str4), v_t_2425}), NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_str5), v_t_2431}), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2432})});
  V v_x_2434 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2433})});
  V f_ = v_k_2423;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_source_247 = heff_env(self)[1];
  V v_selection_243 = heff_env(self)[2];
  V v_name_244 = heff_env(self)[3];
  V v_kind_245 = heff_env(self)[4];
  V v_module_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1802894985x1905308801_lam3, 1, 6, (V[]){v_source_247, v_selection_243, v_name_244, v_kind_245, v_module_248, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str0, 10, "initialize");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str2, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str3, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str4, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str7, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str8, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str9, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str10, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str11, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str12, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str13, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str14, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str15, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str16, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str17, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str19, 12, "capabilities");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str20, 9, "workspace");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str21, 19, "dynamicRegistration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str22, 21, "didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str23, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str24, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str25, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str27, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str28, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str29, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str31, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str32, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str33, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str34, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str35, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str36, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str37, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str38, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str39, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str40, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str41, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str42, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str43, 18, "textDocument/hover");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str44, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str45, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str46, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str47, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str48, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str49, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str50, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str51, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str52, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str54, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str55, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str56, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str57, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str58, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str59, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str60, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str61, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str62, 23, "textDocument/definition");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str63, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str64, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str65, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str66, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str67, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str68, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str69, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str70, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str71, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str72, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str73, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str74, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str75, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str76, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str77, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str78, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str79, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str80, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str81, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str82, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str83, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str84, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str85, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str86, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str87, 30, "textDocument/documentHighlight");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str88, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str89, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str90, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str91, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str92, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str93, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str94, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str95, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str96, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str97, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str98, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str99, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str100, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str101, 23, "textDocument/completion");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str102, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str103, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str104, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str105, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str106, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str107, 27, "textDocument/documentSymbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str108, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str109, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str110, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str111, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str112, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str113, 16, "workspace/symbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str114, 5, "query");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str115, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str116, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str117, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str118, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str119, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str120, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str121, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str122, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str123, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str124, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str125, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str126, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str127, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str128, 23, "textDocument/references");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str129, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str130, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str131, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str132, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str133, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str134, 18, "includeDeclaration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str135, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str136, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str137, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str138, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str139, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str140, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str141, 26, "textDocument/prepareRename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str142, 19, "textDocument/rename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str143, 7, "newName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str144, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str145, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str146, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str147, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str148, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str149, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str150, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str151, 23, "textDocument/formatting");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str152, 23, "textDocument/codeAction");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str153, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str154, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str155, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str156, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str157, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str158, 15, "heff/moduleName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str159, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str160, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str161, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str162, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str163, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str164, 10, "no method ");
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam6, 1, 0};
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam22(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam24(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam23(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam25(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam21(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam26(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam27(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam31(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam30(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam29(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam28(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam34(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam33(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam32(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam36(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam35(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam37(V self, V *args);
Clo g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_entry, 6, 0};

V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837(V v_st_240, V v_m_241, V v_id_242, V v_p_243, V v_z_244, V v_z_245) {
top: ;
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str0), 2)) {
    heff_drop(v_m_241);
    V v_t_246 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str1), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str2), MK_INT(0LL)));
    V v_acc_247 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str3)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str4));
    V v_t_248 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str5), heff_strAppend(v_acc_247, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str6)), MK_INT(0LL)));
    V v_acc_249 = heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str7));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_acc_249, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str8)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str9));
    V v_t_2411 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str10), v_t_2410, MK_INT(0LL)));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str11)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str12));
    V v_acc_2413 = ({ V a_0 = v_t_2412; V a_1 = v_id_242; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_242); r_; });
    V v_t_2414 = heff_strAppend(heff_strAppend(v_acc_2413, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str13)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str14));
    V v_t_2415 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str15), v_t_2414, MK_INT(0LL)));
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str16)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str17));
    V v_acc_2417 = ({ V a_0 = v_t_2416; V b_1 = heff_dup(g_heff_2elsp_2elsp_2ecapabilities_get()); V r_ = (g_json_2estringify_2ewriteInto_240(a_0, b_1)); heff_drop(b_1); r_; });
    V v_a_2418 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2417, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str18)), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s535099379x685970669(v_t_2422, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam0, 1, 3, (V[]){v_p_243, v_st_240, v_z_245})));
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str23), 2)) {
      heff_drop(v_m_241);
      heff_drop(v_p_243);
      V v_t_2467 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str24), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str25), MK_INT(0LL)));
      V v_acc_2468 = heff_strAppend(heff_strAppend(v_t_2467, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str26)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str27));
      V v_t_2469 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str28), heff_strAppend(v_acc_2468, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str29)), MK_INT(0LL)));
      V v_acc_2470 = heff_strAppend(v_t_2469, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str30));
      V v_t_2471 = heff_strAppend(heff_strAppend(v_acc_2470, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str31)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str32));
      V v_t_2472 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str33), v_t_2471, MK_INT(0LL)));
      V v_t_2473 = heff_strAppend(heff_strAppend(v_t_2472, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str34)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str35));
      V v_acc_2474 = ({ V a_0 = v_t_2473; V a_1 = v_id_242; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_242); r_; });
      V v_t_2475 = heff_strAppend(heff_strAppend(v_acc_2474, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str36)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str37));
      V v_t_2476 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str38), v_t_2475, MK_INT(0LL)));
      V v_acc_2477 = heff_strAppend(heff_strAppend(v_t_2476, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str39)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str40));
      V v_t_2478 = heff_strAppend(heff_strAppend(v_acc_2477, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str41)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str42));
      V v_a_2479 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2478, NTAG(TAG_MkUnit)});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2479})});
      V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
      V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
      V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
      return (g_co_2eop_24s535099379x685970669(v_t_2483, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam1, 1, 2, (V[]){v_st_240, v_z_245})));
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str43), 2)) {
        heff_drop(v_m_241);
        V v_c_2490 = (g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(v_st_240, heff_dup(v_p_243)));
        return heff_tail(v_c_2490, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam2, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
      } else {
        if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str62), 2)) {
          heff_drop(v_m_241);
          V v_c_24111 = (g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(v_st_240, heff_dup(v_p_243)));
          return heff_tail(v_c_24111, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam4, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
        } else {
          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str87), 2)) {
            heff_drop(v_m_241);
            V v_c_24167 = (g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(v_st_240, heff_dup(v_p_243)));
            return heff_tail(v_c_24167, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam10, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
          } else {
            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str101), 2)) {
              heff_drop(v_m_241);
              V v_c_24227 = (g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(v_st_240, heff_dup(v_p_243)));
              return heff_tail(v_c_24227, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam12, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
            } else {
              if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str107), 2)) {
                heff_drop(v_m_241);
                V v_c_24250 = (g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(v_st_240, v_p_243));
                return heff_tail(v_c_24250, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam14, 1, 3, (V[]){v_id_242, v_z_244, v_z_245})});
              } else {
                if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str113), 2)) {
                  heff_drop(v_m_241);
                  V v_t_24273 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
                  V v_t_24274 = (g_list_2emap_24s1415906091x1371825187(v_t_24273));
                  V v_c_24275 = (g_heff_2elsp_2elsp_2erootsOf_24s1109162646x327979318(heff_dup(v_st_240), v_t_24274));
                  return heff_tail(v_c_24275, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam17, 1, 5, (V[]){v_st_240, v_z_244, v_p_243, v_id_242, v_z_245})});
                } else {
                  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str128), 2)) {
                    heff_drop(v_m_241);
                    V v_c_24308 = (g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212(v_st_240, heff_dup(v_p_243)));
                    return heff_tail(v_c_24308, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam21, 1, 4, (V[]){v_id_242, v_p_243, v_z_244, v_z_245})});
                  } else {
                    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str141), 2)) {
                      heff_drop(v_m_241);
                      V v_c_24356 = (g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212(v_st_240, v_p_243));
                      return heff_tail(v_c_24356, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam26, 1, 3, (V[]){v_id_242, v_z_244, v_z_245})});
                    } else {
                      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str142), 2)) {
                        heff_drop(v_m_241);
                        V v_c_24358 = (g_heff_2elsp_2elsp_2ewithTarget_24s184718144x462303212(v_st_240, heff_dup(v_p_243)));
                        return heff_tail(v_c_24358, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam27, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
                      } else {
                        if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str151), 2)) {
                          heff_drop(v_m_241);
                          V v_t_24372 = ({ V a_0 = v_st_240; V a_1 = v_id_242; V a_2 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eformatted_24s1213984448x1467825821(a_0, a_1, a_2)); heff_drop(v_id_242); r_; });
                          return heff_tail(v_t_24372, 2, (V[]){v_z_244, v_z_245});
                        } else {
                          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str152), 2)) {
                            heff_drop(v_m_241);
                            V v_c_24373 = (g_heff_2elsp_2elsp_2ewithProgram_24s1998621216x1434965923(v_st_240, heff_dup(v_p_243)));
                            return heff_tail(v_c_24373, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam28, 1, 4, (V[]){v_p_243, v_z_244, v_id_242, v_z_245})});
                          } else {
                            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str158), 2)) {
                              heff_drop(v_m_241);
                              V v_c_24390 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1968230736x1737675977(v_p_243));
                              V v_f_24405 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam32, 1, 2, (V[]){v_id_242, heff_dup(v_st_240)});
                              return heff_tail(v_c_24390, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam35, 1, 4, (V[]){v_f_24405, v_z_244, v_z_245, v_st_240})});
                            } else {
                              heff_drop(v_p_243);
                              V v_c_24411 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s1919494086x102858406(v_id_242, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str164), v_m_241)));
                              return heff_tail(v_c_24411, 2, (V[]){v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam37, 1, 2, (V[]){v_z_245, v_st_240})});
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam0(V self, V *args) {
  V v_x_2423 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_drop(v_x_2423);
  V v_w_2461;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_243)) {
  case TAG_JNull: {
    v_w_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_JBool: {
    heff_take_n(v_p_243, 0ULL, 1);
    v_w_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_JInt: {
    heff_take_n(v_p_243, 0ULL, 1);
    v_w_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_JFloat: {
    heff_take_na(v_p_243, 0ULL, 1);
    v_w_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_JString: {
    heff_take_n(v_p_243, 0ULL, 1);
    v_w_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_JArray: {
    heff_take_n(v_p_243, 0ULL, 1);
    v_w_2461 = NTAG(TAG_False);
    break;
  }
  case TAG_JObject: {
    V v_fs_2429 = heff_field(v_p_243, 0);
    heff_take_n(v_p_243, 1ULL, 1);
    HeffT2 v_t_2430 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str19); V a_1 = v_fs_2429; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2429); r_; });
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_p_2433 = v_field_2432;
        V v_t_2436;
        switch (heff_tag_of(v_p_2433)) {
        case TAG_MkPair: {
          V v_y_2435 = heff_field(v_p_2433, 1);
          heff_take_n(v_p_2433, 2ULL, 2);
          v_t_2436 = v_y_2435;
          break;
        }
        default: heff_nomatch(v_p_2433);
        }
        switch (heff_tag_of(v_t_2436)) {
        case TAG_JNull: {
          v_w_2461 = NTAG(TAG_False);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2436, 0ULL, 1);
          v_w_2461 = NTAG(TAG_False);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2436, 0ULL, 1);
          v_w_2461 = NTAG(TAG_False);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2436, 0ULL, 1);
          v_w_2461 = NTAG(TAG_False);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2436, 0ULL, 1);
          v_w_2461 = NTAG(TAG_False);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2436, 0ULL, 1);
          v_w_2461 = NTAG(TAG_False);
          break;
        }
        case TAG_JObject: {
          V v_fs_2442 = heff_field(v_t_2436, 0);
          heff_take_n(v_t_2436, 1ULL, 1);
          HeffT2 v_t_2443 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str20); V a_1 = v_fs_2442; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2442); r_; });
          {
            V v_field_2445 = v_t_2443.f[1];
            int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
            if ((v_tag_2444 == ((int64_t)0ULL))) {
              V v_p_2446 = v_field_2445;
              V v_t_2449;
              switch (heff_tag_of(v_p_2446)) {
              case TAG_MkPair: {
                V v_y_2448 = heff_field(v_p_2446, 1);
                heff_take_n(v_p_2446, 2ULL, 2);
                v_t_2449 = v_y_2448;
                break;
              }
              default: heff_nomatch(v_p_2446);
              }
              V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str21), NTAG(TAG_Nil)});
              HeffT2 v_t_2451 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str22), v_t_2450}); V a_1 = v_t_2449; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2453 = v_t_2451.f[1];
                int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
                if ((v_tag_2452 == ((int64_t)0ULL))) {
                  V v_it1_2454 = v_field_2453;
                  switch (heff_tag_of(v_it1_2454)) {
                  case TAG_JNull: {
                    v_w_2461 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JBool: {
                    V v_b_2455 = heff_field(v_it1_2454, 0);
                    heff_take_n(v_it1_2454, 1ULL, 1);
                    v_w_2461 = v_b_2455;
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2454, 0ULL, 1);
                    v_w_2461 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2454, 0ULL, 1);
                    v_w_2461 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JString: {
                    heff_take_n(v_it1_2454, 0ULL, 1);
                    v_w_2461 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2454, 0ULL, 1);
                    v_w_2461 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2454, 0ULL, 1);
                    v_w_2461 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_it1_2454);
                  }
                } else {
                  heff_drop(v_field_2453);
                  v_w_2461 = NTAG(TAG_False);
                }
              }
            } else {
              heff_drop(v_field_2445);
              v_w_2461 = NTAG(TAG_False);
            }
          }
          break;
        }
        default: heff_nomatch(v_t_2436);
        }
      } else {
        heff_drop(v_field_2432);
        v_w_2461 = NTAG(TAG_False);
      }
    }
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_due_2462 = heff_take_field(v_st_240, 2);
  V v_project_2463 = heff_take_field(v_st_240, 3);
  V v_shutdown_2464 = heff_take_field(v_st_240, 5);
  V v_lib_2465 = heff_take_field(v_st_240, 6);
  V v_t_2466 = ({ V rv_2 = v_due_2462; V rv_3 = v_project_2463; V rv_4 = v_w_2461; V rv_5 = v_shutdown_2464; V rv_6 = v_lib_2465; V rr_ = heff_rec_reuse_nf(v_st_240, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_z_245;
  args[0] = v_t_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam1(V self, V *args) {
  V v_x_2484 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_drop(v_x_2484);
  heff_clo_take(self, 2);
  V v_due_2485 = heff_take_field(v_st_240, 2);
  V v_project_2486 = heff_take_field(v_st_240, 3);
  V v_watch_2487 = heff_take_field(v_st_240, 4);
  V v_lib_2488 = heff_take_field(v_st_240, 6);
  V v_t_2489 = ({ V rv_2 = v_due_2485; V rv_3 = v_project_2486; V rv_4 = v_watch_2487; V rv_5 = NTAG(TAG_True); V rv_6 = v_lib_2488; V rr_ = heff_rec_reuse_nf(v_st_240, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_z_245;
  args[0] = v_t_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam3(V self, V *args) {
  V v_x_24110 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_x_2491 = heff_env(self)[1];
  heff_drop(v_x_24110);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = heff_get_n(v_x_2491, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam2(V self, V *args) {
  V v_x_2491 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_result_2492 = (g_heff_2elsp_2elsp_2ehoverOf(heff_dup(v_x_2491), v_p_243));
  V v_t_2493 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str44), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str45), MK_INT(0LL)));
  V v_acc_2494 = heff_strAppend(heff_strAppend(v_t_2493, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str46)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str47));
  V v_t_2495 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str48), heff_strAppend(v_acc_2494, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str49)), MK_INT(0LL)));
  V v_acc_2496 = heff_strAppend(v_t_2495, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str50));
  V v_t_2497 = heff_strAppend(heff_strAppend(v_acc_2496, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str51)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str52));
  V v_t_2498 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str53), v_t_2497, MK_INT(0LL)));
  V v_t_2499 = heff_strAppend(heff_strAppend(v_t_2498, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str54)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str55));
  V v_acc_24100 = ({ V a_0 = v_t_2499; V a_1 = v_id_242; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_242); r_; });
  V v_t_24101 = heff_strAppend(heff_strAppend(v_acc_24100, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str56)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str57));
  V v_t_24102 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str58), v_t_24101, MK_INT(0LL)));
  V v_t_24103 = heff_strAppend(heff_strAppend(v_t_24102, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str59)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str60));
  V v_acc_24104 = ({ V a_0 = v_t_24103; V a_1 = v_result_2492; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_result_2492); r_; });
  V v_a_24105 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_24104, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str61)), NTAG(TAG_MkUnit)});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
  return (g_co_2eop_24s535099379x685970669(v_t_24109, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam3, 1, 2, (V[]){v_z_245, v_x_2491})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam5(V self, V *args) {
  V v_hd_24139 = args[0];
  V v_k_24140 = args[1];
  V v_d_24138 = heff_env(self)[0];
  heff_drop(v_hd_24139);
  heff_clo_take(self, 1);
  V f_ = v_k_24140;
  args[0] = heff_get_n(v_d_24138, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam6(V self, V *args) {
  V v_u_24141 = args[0];
  return v_u_24141;
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam8(V self, V *args) {
  V v_x_24149 = args[0];
  V v_source_24132 = heff_env(self)[0];
  V v_span_24133 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_hd_24147 = heff_env(self)[3];
  V v_k_24148 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24150 = ({ V a_0 = v_source_24132; V a_1 = v_span_24133; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_24132); r_; });
  V v_t_24151 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str74), heff_tag_n(TAG_JString, 1, (V[]){v_x_24149})});
  V v_t_24152 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str75), v_t_24150}), NTAG(TAG_Nil)});
  V v_result_24153 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24151, v_t_24152})});
  V v_t_24154 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str76), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str77), MK_INT(0LL)));
  V v_acc_24155 = heff_strAppend(heff_strAppend(v_t_24154, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str78)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str79));
  V v_t_24156 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str80), heff_strAppend(v_acc_24155, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str81)), MK_INT(0LL)));
  V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str82), v_result_24153}), NTAG(TAG_Nil)});
  V v_t_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str83), v_id_242}), v_t_24157});
  V v_t_24159 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str84); V a_1 = heff_strAppend(v_t_24156, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str85)); V a_2 = v_t_24158; V r_ = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a_0, a_1, a_2)); heff_drop_tag(v_t_24158, 2); r_; });
  V v_a_24160 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24159, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str86)), NTAG(TAG_MkUnit)});
  V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24160})});
  V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
  V v_t_24163 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24162})});
  V v_t_24164 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})});
  return (g_co_2eop_24s535099379x685970669(v_t_24164, v_hd_24147, v_k_24148));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam7(V self, V *args) {
  V v_hd_24147 = args[0];
  V v_k_24148 = args[1];
  V v_c_24146 = heff_env(self)[0];
  V v_source_24132 = heff_env(self)[1];
  V v_span_24133 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24146;
  args[0] = heff_dup(v_hd_24147);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam8, 1, 5, (V[]){v_source_24132, v_span_24133, v_id_242, v_hd_24147, v_k_24148});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam9(V self, V *args) {
  V v_x_24166 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24115 = heff_env(self)[1];
  heff_drop(v_x_24166);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_24115;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam4(V self, V *args) {
  V v_x_24112 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_text_24113 = heff_take_field(v_x_24112, 1);
  V v_program_24114 = heff_take_field(v_x_24112, 2);
  V v_st_24115 = heff_get_n(v_x_24112, 0, 3);
  heff_clo_take(self, 4);
  V v_t_24116 = ({ V a_0 = v_text_24113; V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24113); r_; });
  V v_t_24117 = (g_heff_2ebuild_2equery_2edefinitionAt(v_program_24114, v_t_24116));
  V v_c_24165;
  switch (heff_tag_of(v_t_24117)) {
  case TAG_Nothing: {
    V v_t_24118 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str63), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str64), MK_INT(0LL)));
    V v_acc_24119 = heff_strAppend(heff_strAppend(v_t_24118, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str65)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str66));
    V v_t_24120 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str67), heff_strAppend(v_acc_24119, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str68)), MK_INT(0LL)));
    V v_t_24121 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str69), NTAG(TAG_JNull)});
    V v_t_24122 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
    V v_t_24123 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str70), v_id_242}), v_t_24122});
    V v_t_24124 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str71); V a_1 = heff_strAppend(v_t_24120, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str72)); V a_2 = v_t_24123; V r_ = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a_0, a_1, a_2)); heff_drop_tag(v_t_24123, 2); r_; });
    V v_a_24125 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24124, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str73)), NTAG(TAG_MkUnit)});
    V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24125})});
    V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
    V v_t_24128 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
    V v_t_24129 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24128})});
    v_c_24165 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){v_t_24129}));
    break;
  }
  case TAG_Just: {
    V v_d_24130 = heff_field(v_t_24117, 0);
    V v_ru_24t_24117_24Just = heff_take_reuse_n(v_t_24117, 1ULL, 1);
    V v_path_24131 = heff_take_field(v_d_24130, 0);
    V v_source_24132 = heff_take_field(v_d_24130, 1);
    V v_span_24133 = heff_get_n(v_d_24130, 2, 3);
    V v_p_24134 = v_path_24131;
    HeffT2 v_t_24135 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_24115, 0), v_p_24134));
    {
      V v_field_24137 = v_t_24135.f[1];
      int64_t v_tag_24136 = ((int64_t)v_t_24135.f[0]);
      V v_c_24146;
      if ((v_tag_24136 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24t_24117_24Just, 1);
        heff_drop(v_p_24134);
        V v_d_24138 = v_field_24137;
        v_c_24146 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam5, 2, 1, (V[]){v_d_24138});
      } else {
        heff_drop(v_field_24137);
        V v_t_24142 = heff_tag_at_n(v_ru_24t_24117_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_24134, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam6_clo)})});
        V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
        V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
        V v_t_24145 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24144})});
        v_c_24146 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24145})}));
      }
      v_c_24165 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam7, 2, 4, (V[]){v_c_24146, v_source_24132, v_span_24133, v_id_242});
    }
    break;
  }
  default: heff_nomatch(v_t_24117);
  }
  V f_ = v_c_24165;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam9, 1, 2, (V[]){v_z_245, v_st_24115});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam11(V self, V *args) {
  V v_x_24226 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24171 = heff_env(self)[1];
  heff_drop(v_x_24226);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_24171;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam10(V self, V *args) {
  V v_x_24168 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_program_24169 = heff_take_field(v_x_24168, 2);
  V v_text_24170 = heff_take_field(v_x_24168, 1);
  V v_st_24171 = heff_get_n(v_x_24168, 0, 3);
  V v_program_24172 = v_program_24169;
  heff_clo_take(self, 4);
  V v_off_24173 = ({ V a_0 = v_text_24170; V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24170); r_; });
  V v_x1_24174 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_24172)));
  V v_t_24212;
  switch (heff_tag_of(v_x1_24174)) {
  case TAG_Nil: {
    heff_drop(v_program_24172);
    heff_drop(v_off_24173);
    v_t_24212 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24175 = heff_field(v_x1_24174, 0);
    V v_ru_24x1_24174_24Cons = heff_take_reuse_n(v_x1_24174, 1ULL, 2);
    V v_x1_24177 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_24172)));
    switch (heff_tag_of(v_x1_24177)) {
    case TAG_Nil: {
      heff_drop(v_program_24172);
      heff_drop(v_off_24173);
      heff_drop(v_x_24175);
      heff_drop_cell(v_ru_24x1_24174_24Cons, 2);
      v_t_24212 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_x_24178 = heff_field(v_x1_24177, 0);
      V v_ru_24x1_24177_24Cons = heff_take_reuse_n(v_x1_24177, 1ULL, 2);
      V v_t_24180 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_24178, 4)));
      V v_t_24181 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_24180));
      V v_t_24182 = ({ V a_0 = v_program_24172; V a_1 = v_x_24178; V a_2 = v_t_24181; V a_3 = v_off_24173; V r_ = (g_heff_2ebuild_2equery_2etargetIn(a_0, a_1, a_2, a_3)); heff_drop(v_program_24172); r_; });
      switch (heff_tag_of(v_t_24182)) {
      case TAG_Nothing: {
        heff_drop(v_x_24175);
        heff_drop_cell(v_ru_24x1_24174_24Cons, 2);
        heff_drop_cell(v_ru_24x1_24177_24Cons, 2);
        v_t_24212 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_24183 = heff_field(v_t_24182, 0);
        heff_take_n(v_t_24182, 1ULL, 1);
        V v_target_24184 = heff_take_field(v_t_24183, 0);
        V v_name_24185 = heff_get_n(v_t_24183, 1, 2);
        V v_lit_24186 = v_x_24175;
        V v_t_24187 = v_target_24184;
        V v_name_24188 = v_name_24185;
        V v_t_24189 = heff_dup(heff_rfield(v_t_24187, 2));
        switch (heff_tag_of(v_t_24189)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_24174_24Cons, 2);
          heff_drop_cell(v_ru_24x1_24177_24Cons, 2);
          V v_t_24190 = (g_heff_2ebuild_2equery_2einFile(v_t_24187, v_name_24188, v_lit_24186));
          V v_z_24191 = (g_prelude_2e_2b_2b(v_t_24190, NTAG(TAG_Nil)));
          v_t_24212 = v_z_24191;
          break;
        }
        case TAG_Just: {
          V v_b_24192 = heff_field(v_t_24189, 0);
          heff_take_n(v_t_24189, 1ULL, 1);
          heff_drop(v_name_24188);
          if (heff_strEq_c(heff_dup(heff_rfield(v_lit_24186, 1)), heff_get_n(v_t_24187, 0, 3))) {
            V v_t_24193 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_lit_24186, 4)));
            HeffT2 v_t_24194 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_t_24193));
            {
              V v_field_24195 = v_t_24194.f[0];
              heff_drop(v_t_24194.f[1]);
              HeffT2 v_t_24197 = ({ V a_0 = v_b_24192; V a_1 = v_field_24195; HeffT2 r_ = (g_list_2efind_24s343666469x451168509_24cpr(a_0, a_1)); heff_drop(v_field_24195); r_; });
              {
                V v_field_24199 = v_t_24197.f[1];
                int64_t v_tag_24198 = ((int64_t)v_t_24197.f[0]);
                if ((v_tag_24198 == ((int64_t)0ULL))) {
                  V v_l_24200 = v_field_24199;
                  V v_binder_24201 = heff_take_field(v_l_24200, 1);
                  V v_uses_24202 = heff_get_n(v_l_24200, 2, 3);
                  V v_x_24203 = v_binder_24201;
                  V v_t_24204 = v_uses_24202;
                  V v_t_24210;
                  switch (heff_tag_of(v_t_24204)) {
                  case TAG_Nil: {
                    heff_drop_cell(v_ru_24x1_24177_24Cons, 2);
                    V v_t_24205 = heff_tag_at_n(v_ru_24x1_24174_24Cons, TAG_Cons, 2, (V[]){v_x_24203, NTAG(TAG_Nil)});
                    v_t_24210 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24205, NTAG(TAG_Nil)});
                    break;
                  }
                  case TAG_Cons: {
                    V v_y_24206 = heff_field(v_t_24204, 0);
                    V v_ys_24207 = heff_field(v_t_24204, 1);
                    heff_take_n(v_t_24204, 3ULL, 2);
                    if (heff_intLe_c(heff_dup(heff_rfield(v_x_24203, 0)), heff_dup(heff_rfield(v_y_24206, 0)))) {
                      V v_t_24208 = heff_tag_at_n(v_ru_24x1_24174_24Cons, TAG_Cons, 2, (V[]){v_x_24203, NTAG(TAG_Nil)});
                      v_t_24210 = (g_list_2eascending_24s1053575971x1138989897(heff_dup(v_y_24206), heff_tag_at_n(v_ru_24x1_24177_24Cons, TAG_Cons, 2, (V[]){v_y_24206, v_t_24208}), v_ys_24207));
                    } else {
                      V v_t_24209 = heff_tag_at_n(v_ru_24x1_24174_24Cons, TAG_Cons, 2, (V[]){v_x_24203, NTAG(TAG_Nil)});
                      v_t_24210 = (g_list_2edescending_24s136597790x1673774577(heff_dup(v_y_24206), heff_tag_at_n(v_ru_24x1_24177_24Cons, TAG_Cons, 2, (V[]){v_y_24206, v_t_24209}), v_ys_24207));
                    }
                    break;
                  }
                  default: heff_nomatch(v_t_24204);
                  }
                  V v_t_24211 = (g_list_2emergeRuns_24s655705766x180835539(NTAG(TAG_Nil), v_t_24210));
                  v_t_24212 = (g_list_2emap_24s1392650298x1192381411(v_b_24192, v_lit_24186, v_t_24211));
                } else {
                  heff_drop_cell(v_ru_24x1_24174_24Cons, 2);
                  heff_drop_cell(v_ru_24x1_24177_24Cons, 2);
                  heff_drop_rec(v_lit_24186, 14);
                  heff_drop(v_b_24192);
                  heff_drop(v_field_24199);
                  v_t_24212 = NTAG(TAG_Nil);
                }
              }
            }
          } else {
            heff_drop_cell(v_ru_24x1_24174_24Cons, 2);
            heff_drop_cell(v_ru_24x1_24177_24Cons, 2);
            heff_drop_rec(v_lit_24186, 14);
            heff_drop(v_b_24192);
            v_t_24212 = NTAG(TAG_Nil);
          }
          break;
        }
        default: heff_nomatch(v_t_24189);
        }
        break;
      }
      default: heff_nomatch(v_t_24182);
      }
      break;
    }
    default: heff_nomatch(v_x1_24177);
    }
    break;
  }
  default: heff_nomatch(v_x1_24174);
  }
  V v_t_24213 = (g_list_2emap_24s328130413x305756849(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str88), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str89), MK_INT(1LL), v_t_24212));
  V v_result_24214 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24213});
  V v_t_24215 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str90), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str91), MK_INT(0LL)));
  V v_acc_24216 = heff_strAppend(heff_strAppend(v_t_24215, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str92)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str93));
  V v_t_24217 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str94), heff_strAppend(v_acc_24216, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str95)), MK_INT(0LL)));
  V v_t_24218 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str96), v_result_24214}), NTAG(TAG_Nil)});
  V v_t_24219 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str97), v_id_242}), v_t_24218});
  V v_t_24220 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str98); V a_1 = heff_strAppend(v_t_24217, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str99)); V a_2 = v_t_24219; V r_ = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a_0, a_1, a_2)); heff_drop_tag(v_t_24219, 2); r_; });
  V v_a_24221 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24220, ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str100)), NTAG(TAG_MkUnit)});
  V v_t_24222 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24221})});
  V v_t_24223 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24222})});
  V v_t_24224 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24223})});
  V v_t_24225 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24224})});
  return (g_co_2eop_24s535099379x685970669(v_t_24225, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam11, 1, 2, (V[]){v_z_245, v_st_24171})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam13(V self, V *args) {
  V v_x_24249 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24231 = heff_env(self)[1];
  heff_drop(v_x_24249);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_24231;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam12(V self, V *args) {
  V v_x_24228 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_program_24229 = heff_take_field(v_x_24228, 2);
  V v_text_24230 = heff_take_field(v_x_24228, 1);
  V v_st_24231 = heff_get_n(v_x_24228, 0, 3);
  V v_x1_24232 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24229));
  V v_t_24237;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x1_24232)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    heff_drop(v_text_24230);
    v_t_24237 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24233 = heff_field(v_x1_24232, 0);
    V v_ru_24x1_24232_24Cons = heff_take_reuse_n(v_x1_24232, 1ULL, 2);
    V v_t_24235 = ({ V a_0 = v_text_24230; V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24230); r_; });
    V v_t_24236 = (g_heff_2ebuild_2equery_2ecompletionsAt(v_x_24233, v_t_24235));
    v_t_24237 = (g_list_2emap_24s4199228x1154005405_24tok2(v_ru_24x1_24232_24Cons, v_t_24236));
    break;
  }
  default: heff_nomatch(v_x1_24232);
  }
  V v_result_24238 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24237});
  V v_t_24239 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str102), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str103)})});
  V v_t_24240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str104), v_result_24238}), NTAG(TAG_Nil)});
  V v_t_24241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str105), v_id_242}), v_t_24240});
  V v_t_24242 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24239, v_t_24241})});
  V v_t_24243 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str106); V a_1 = v_t_24242; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24242, 1); r_; });
  V v_a_24244 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24243, NTAG(TAG_MkUnit)});
  V v_t_24245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24244})});
  V v_t_24246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24245})});
  V v_t_24247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24246})});
  V v_t_24248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24247})});
  return (g_co_2eop_24s535099379x685970669(v_t_24248, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam13, 1, 2, (V[]){v_z_245, v_st_24231})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam15(V self, V *args) {
  V v_y_24259 = args[0];
  V v_text_24253 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2elsp_2edocSymbol(v_text_24253, v_y_24259));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam16(V self, V *args) {
  V v_x_24272 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24254 = heff_env(self)[1];
  heff_drop(v_x_24272);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_24254;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam14(V self, V *args) {
  V v_x_24251 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_program_24252 = heff_take_field(v_x_24251, 2);
  V v_text_24253 = heff_take_field(v_x_24251, 1);
  V v_st_24254 = heff_get_n(v_x_24251, 0, 3);
  V v_x1_24255 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24252));
  V v_t_24260;
  switch (heff_tag_of(v_x1_24255)) {
  case TAG_Nil: {
    heff_drop(v_text_24253);
    v_t_24260 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24256 = heff_field(v_x1_24255, 0);
    V v_ru_24x1_24255_24Cons = heff_take_reuse_n(v_x1_24255, 1ULL, 2);
    V v_t_24258 = (g_heff_2ebuild_2equery_2esymbols(v_x_24256));
    v_t_24260 = (g_list_2emap_24tok2(v_ru_24x1_24255_24Cons, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam15, 1, 1, (V[]){v_text_24253}), v_t_24258));
    break;
  }
  default: heff_nomatch(v_x1_24255);
  }
  V v_result_24261 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24260});
  V v_t_24262 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str108), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str109)})});
  V v_t_24263 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str110), v_result_24261}), NTAG(TAG_Nil)});
  heff_clo_take(self, 3);
  V v_t_24264 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str111), v_id_242}), v_t_24263});
  V v_t_24265 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24262, v_t_24264})});
  V v_t_24266 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str112); V a_1 = v_t_24265; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24265, 1); r_; });
  V v_a_24267 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24266, NTAG(TAG_MkUnit)});
  V v_t_24268 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24267})});
  V v_t_24269 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24268})});
  V v_t_24270 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24269})});
  V v_t_24271 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24270})});
  return (g_co_2eop_24s535099379x685970669(v_t_24271, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam16, 1, 2, (V[]){v_z_245, v_st_24254})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam20(V self, V *args) {
  V v_x_24307 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24280 = heff_env(self)[1];
  heff_drop(v_x_24307);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_24280;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam19(V self, V *args) {
  V v_x_24295 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_st_24280 = heff_env(self)[3];
  V v_t_24296 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str123), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str124)})});
  V v_t_24297 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str125), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24295})});
  V v_t_24298 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24297, NTAG(TAG_Nil)});
  heff_clo_take(self, 4);
  V v_t_24299 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str126), v_id_242}), v_t_24298});
  V v_t_24300 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24296, v_t_24299})});
  V v_t_24301 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str127); V a_1 = v_t_24300; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24300, 1); r_; });
  V v_a_24302 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24301, NTAG(TAG_MkUnit)});
  V v_t_24303 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24302})});
  V v_t_24304 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24303})});
  V v_t_24305 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24304})});
  V v_t_24306 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24305})});
  return (g_co_2eop_24s535099379x685970669(v_t_24306, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam20, 1, 2, (V[]){v_z_245, v_st_24280})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam18(V self, V *args) {
  V v_x_24278 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_program_24279 = heff_take_field(v_x_24278, 1);
  V v_st_24280 = heff_get_n(v_x_24278, 0, 2);
  V v_t_24281 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str114), NTAG(TAG_Nil)});
  heff_clo_take(self, 4);
  HeffT2 v_t_24282 = ({ V a_0 = v_t_24281; V a_1 = v_p_243; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_24281, 2); r_; });
  {
    V v_field_24284 = v_t_24282.f[1];
    int64_t v_tag_24283 = ((int64_t)v_t_24282.f[0]);
    V v_t_24292;
    if ((v_tag_24283 == ((int64_t)0ULL))) {
      V v_it1_24285 = v_field_24284;
      switch (heff_tag_of(v_it1_24285)) {
      case TAG_JNull: {
        v_t_24292 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str115);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24285, 0ULL, 1);
        v_t_24292 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str116);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24285, 0ULL, 1);
        v_t_24292 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str117);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24285, 0ULL, 1);
        v_t_24292 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str118);
        break;
      }
      case TAG_JString: {
        V v_s_24289 = heff_field(v_it1_24285, 0);
        heff_take_n(v_it1_24285, 1ULL, 1);
        v_t_24292 = v_s_24289;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24285, 0ULL, 1);
        v_t_24292 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str119);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24285, 0ULL, 1);
        v_t_24292 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str120);
        break;
      }
      default: heff_nomatch(v_it1_24285);
      }
    } else {
      heff_drop(v_field_24284);
      v_t_24292 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str121);
    }
    V v_t_24293 = ({ V a_0 = v_t_24292; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str122); V r_ = (g_heff_2elsp_2elsp_2elowerGo(a_0, a_1, a_2)); heff_drop(v_t_24292); r_; });
    V v_t_24294 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24279));
    return ({ V a_0 = heff_dup(v_st_24280); V a_1 = v_t_24293; V a_2 = v_t_24294; V a_3 = heff_dup(v_z_244); V a_4 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam19, 1, 4, (V[]){v_id_242, v_z_244, v_z_245, v_st_24280}); V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s277703883x1560507481(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_24293); heff_drop(v_t_24294); r_; });
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam17(V self, V *args) {
  V v_x_24276 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_t_24277 = (g_heff_2elsp_2elsp_2enubRoots(v_x_24276));
  heff_clo_take(self, 5);
  return ({ V a_0 = v_st_240; V a_1 = v_t_24277; V a_2 = heff_dup(v_z_244); V a_3 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam18, 1, 4, (V[]){v_p_243, v_z_244, v_id_242, v_z_245}); V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120(a_0, a_1, a_2, a_3)); heff_drop(v_t_24277); r_; });
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam22(V self, V *args) {
  V v_o_24325 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_t_24326 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str134), NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  HeffT2 v_t_24327 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str135), v_t_24326}); V a_1 = v_p_243; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_24329 = v_t_24327.f[1];
    int64_t v_tag_24328 = ((int64_t)v_t_24327.f[0]);
    V v_t_24337;
    if ((v_tag_24328 == ((int64_t)0ULL))) {
      V v_it1_24330 = v_field_24329;
      switch (heff_tag_of(v_it1_24330)) {
      case TAG_JNull: {
        v_t_24337 = NTAG(TAG_True);
        break;
      }
      case TAG_JBool: {
        V v_b_24331 = heff_field(v_it1_24330, 0);
        heff_take_n(v_it1_24330, 1ULL, 1);
        v_t_24337 = v_b_24331;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24330, 0ULL, 1);
        v_t_24337 = NTAG(TAG_True);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24330, 0ULL, 1);
        v_t_24337 = NTAG(TAG_True);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_24330, 0ULL, 1);
        v_t_24337 = NTAG(TAG_True);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24330, 0ULL, 1);
        v_t_24337 = NTAG(TAG_True);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24330, 0ULL, 1);
        v_t_24337 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it1_24330);
      }
    } else {
      heff_drop(v_field_24329);
      v_t_24337 = NTAG(TAG_True);
    }
    V v_ret_24bool = heff_bool(((heff_dup(v_t_24337) == NTAG(TAG_True)) || !(heff_dup(heff_rfield(v_o_24325, 3)) == NTAG(TAG_True))));
    heff_drop_rec(v_o_24325, 4);
    heff_drop(v_t_24337);
    return v_ret_24bool;
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam24(V self, V *args) {
  V v_x_24342 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24340 = heff_env(self)[1];
  V v_k_24341 = heff_env(self)[2];
  V v_t_24343 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str136), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str137)})});
  V v_t_24344 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str138), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24342})});
  V v_t_24345 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24344, NTAG(TAG_Nil)});
  heff_clo_take(self, 3);
  V v_t_24346 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str139), v_id_242}), v_t_24345});
  V v_t_24347 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24343, v_t_24346})});
  V v_t_24348 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str140); V a_1 = v_t_24347; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24347, 1); r_; });
  V v_a_24349 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24348, NTAG(TAG_MkUnit)});
  V v_t_24350 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24349})});
  V v_t_24351 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24350})});
  V v_t_24352 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24351})});
  V v_t_24353 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24352})});
  return (g_co_2eop_24s535099379x685970669(v_t_24353, v_hd_24340, v_k_24341));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam23(V self, V *args) {
  V v_hd_24340 = args[0];
  V v_k_24341 = args[1];
  V v_c_24339 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24339;
  args[0] = heff_dup(v_hd_24340);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam24, 1, 3, (V[]){v_id_242, v_hd_24340, v_k_24341});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam25(V self, V *args) {
  V v_x_24355 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24311 = heff_env(self)[1];
  heff_drop(v_x_24355);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_24311;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam21(V self, V *args) {
  V v_x_24309 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_target_24310 = heff_take_field(v_x_24309, 2);
  V v_st_24311 = heff_get_n(v_x_24309, 0, 3);
  V v_t_24312 = v_target_24310;
  V v_c_24354;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_t_24312)) {
  case TAG_Nothing: {
    heff_drop(v_p_243);
    V v_t_24313 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str129), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str130)})});
    V v_t_24314 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str131), NTAG(TAG_JNull)});
    V v_t_24315 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24314, NTAG(TAG_Nil)});
    V v_t_24316 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str132), v_id_242}), v_t_24315});
    V v_t_24317 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24313, v_t_24316})});
    V v_t_24318 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str133); V a_1 = v_t_24317; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24317, 1); r_; });
    V v_a_24319 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24318, NTAG(TAG_MkUnit)});
    V v_t_24320 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24319})});
    V v_t_24321 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24320})});
    V v_t_24322 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24321})});
    V v_t_24323 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24322})});
    v_c_24354 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){v_t_24323}));
    break;
  }
  case TAG_Just: {
    V v_t_24324 = heff_field(v_t_24312, 0);
    heff_take_n(v_t_24312, 1ULL, 1);
    V v_t_24338 = ({ V b_0 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam22, 1, 1, (V[]){v_p_243}); V a_1 = heff_get_n(v_t_24324, 3, 4); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_24339 = (g_heff_2elsp_2elsp_2elocations_24s1472111343x401960679(heff_dup(v_st_24311), v_t_24338));
    v_c_24354 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam23, 2, 2, (V[]){v_c_24339, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_24312);
  }
  V f_ = v_c_24354;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam25, 1, 2, (V[]){v_z_245, v_st_24311});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam26(V self, V *args) {
  V v_x_24357 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eprepared_24s829931096x144854147(v_id_242, v_x_24357, v_z_244, v_z_245));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam27(V self, V *args) {
  V v_x_24359 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_t_24360 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str143), NTAG(TAG_Nil)});
  heff_clo_take(self, 4);
  HeffT2 v_t_24361 = ({ V a_0 = v_t_24360; V a_1 = v_p_243; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_24360, 2); r_; });
  {
    V v_field_24363 = v_t_24361.f[1];
    int64_t v_tag_24362 = ((int64_t)v_t_24361.f[0]);
    V v_t_24371;
    if ((v_tag_24362 == ((int64_t)0ULL))) {
      V v_it1_24364 = v_field_24363;
      switch (heff_tag_of(v_it1_24364)) {
      case TAG_JNull: {
        v_t_24371 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str144);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24364, 0ULL, 1);
        v_t_24371 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str145);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24364, 0ULL, 1);
        v_t_24371 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str146);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24364, 0ULL, 1);
        v_t_24371 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str147);
        break;
      }
      case TAG_JString: {
        V v_s_24368 = heff_field(v_it1_24364, 0);
        heff_take_n(v_it1_24364, 1ULL, 1);
        v_t_24371 = v_s_24368;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24364, 0ULL, 1);
        v_t_24371 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str148);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24364, 0ULL, 1);
        v_t_24371 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str149);
        break;
      }
      default: heff_nomatch(v_it1_24364);
      }
    } else {
      heff_drop(v_field_24363);
      v_t_24371 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str150);
    }
    return (g_heff_2elsp_2elsp_2erenamed_24s246582203x831213438(v_id_242, v_t_24371, v_x_24359, v_z_244, v_z_245));
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam31(V self, V *args) {
  V v_x_24389 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_x_24374 = heff_env(self)[1];
  heff_drop(v_x_24389);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = heff_get_n(v_x_24374, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam30(V self, V *args) {
  V v_x_24376 = args[0];
  V v_x_24375 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_x_24374 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24377 = (g_prelude_2e_2b_2b(v_x_24376, v_x_24375));
  V v_result_24378 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24377});
  V v_t_24379 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str153), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str154)})});
  V v_t_24380 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str155), v_result_24378}), NTAG(TAG_Nil)});
  V v_t_24381 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str156), v_id_242}), v_t_24380});
  V v_t_24382 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24379, v_t_24381})});
  V v_t_24383 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str157); V a_1 = v_t_24382; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24382, 1); r_; });
  V v_a_24384 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24383, NTAG(TAG_MkUnit)});
  V v_t_24385 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24384})});
  V v_t_24386 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24385})});
  V v_t_24387 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24386})});
  V v_t_24388 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24387})});
  return (g_co_2eop_24s535099379x685970669(v_t_24388, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam31, 1, 2, (V[]){v_z_245, v_x_24374})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam29(V self, V *args) {
  V v_x_24375 = args[0];
  V v_x_24374 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2elsp_2elsp_2eclaimFixes_24s1620183939x816136205(heff_dup(heff_rfield(v_x_24374, 0)), v_p_243, heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam30, 1, 5, (V[]){v_x_24375, v_id_242, v_z_244, v_z_245, v_x_24374})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam28(V self, V *args) {
  V v_x_24374 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2elsp_2elsp_2ecodeActions_24s1098897112x1480599159(heff_dup(v_x_24374), heff_dup(v_p_243), heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam29, 1, 5, (V[]){v_x_24374, v_p_243, v_z_244, v_id_242, v_z_245})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam34(V self, V *args) {
  V v_x_24404 = args[0];
  V v_k_24399 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_24404);
  heff_clo_take(self, 2);
  V f_ = v_k_24399;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam33(V self, V *args) {
  V v_hd_24398 = args[0];
  V v_k_24399 = args[1];
  V v_a_24397 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24400 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24397})});
  V v_t_24401 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24400})});
  V v_t_24402 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24401})});
  V v_t_24403 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24402})});
  return (g_co_2eop_24s535099379x685970669(v_t_24403, v_hd_24398, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam34, 1, 2, (V[]){v_k_24399, v_st_240})));
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam32(V self, V *args) {
  V v_n_24391 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_24392 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str159), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str160)})});
  V v_t_24393 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str161), v_n_24391}), NTAG(TAG_Nil)});
  heff_clo_take(self, 2);
  V v_t_24394 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str162), v_id_242}), v_t_24393});
  V v_t_24395 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24392, v_t_24394})});
  V v_t_24396 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_str163); V a_1 = v_t_24395; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24395, 1); r_; });
  V v_a_24397 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24396, NTAG(TAG_MkUnit)});
  return heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam33, 2, 2, (V[]){v_a_24397, v_st_240});
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam36(V self, V *args) {
  V v_x_24408 = args[0];
  V v_f_24405 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_t_24410;
  switch (heff_tag_of(v_x_24408)) {
  case TAG_Nothing: {
    v_t_24410 = NTAG(TAG_JNull);
    break;
  }
  case TAG_Just: {
    V v_n_24409 = heff_field(v_x_24408, 0);
    V v_ru_24x_24408_24Just = heff_take_reuse_n(v_x_24408, 1ULL, 1);
    v_t_24410 = heff_tag_at_n(v_ru_24x_24408_24Just, TAG_JString, 1, (V[]){v_n_24409});
    break;
  }
  default: heff_nomatch(v_x_24408);
  }
  heff_clo_take(self, 3);
  V f_ = v_f_24405;
  heff_room[0] = v_t_24410;
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam35(V self, V *args) {
  V v_x_24406 = args[0];
  V v_f_24405 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  switch (heff_tag_of(v_x_24406)) {
  case TAG_Nothing: {
    heff_clo_take(self, 4);
    heff_drop_rec(v_st_240, 7);
    V f_ = v_f_24405;
    heff_room[0] = NTAG(TAG_JNull);
    heff_room[1] = v_z_244;
    heff_room[2] = v_z_245;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Just: {
    V v_f_24407 = heff_field(v_x_24406, 0);
    heff_take_n(v_x_24406, 1ULL, 1);
    heff_clo_take(self, 4);
    return (g_heff_2elsp_2elsp_2eclaimOf_24s1207267783x1756765739(v_st_240, v_f_24407, heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam36, 1, 3, (V[]){v_f_24405, v_z_244, v_z_245})));
  }
  default: return heff_nomatch(v_x_24406);
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1826206437x238573837_lam37(V self, V *args) {
  V v_x_24412 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_24412);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_entry, 7, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2(V v_tok_240, V v_a_241, V v_f_242, V v_off_243, V v_t_244, V v_z_245, V v_z_246) {
top: ;
  V v_target_247 = heff_take_field(v_t_244, 0);
  V v_name_248 = heff_get_n(v_t_244, 1, 2);
  V v_st_249 = heff_take_field(v_a_241, 0);
  V v_program_2410 = heff_get_n(v_a_241, 2, 3);
  V v_t_2411 = heff_dup(heff_rfield(v_target_247, 2));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_name_248), NTAG(TAG_Nil)});
    V v_c_2413 = (g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(v_st_249, heff_dup(v_f_242), heff_tag_n(TAG_Just, 1, (V[]){v_t_2412})));
    return heff_tail(v_c_2413, 2, (V[]){v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_lam0, 1, 6, (V[]){v_name_248, v_program_2410, v_target_247, v_f_242, v_z_246, v_off_243})});
  }
  case TAG_Just: {
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_z_245);
    V v_name_2425 = heff_dup(v_name_248);
    V v_occurrences_2426 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_2410, heff_dup(v_target_247), v_name_248));
    V v_target_2427 = heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2425, v_occurrences_2426})});
    return heff_tail(v_z_246, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_249, v_off_243, v_target_2427})});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s1087410387x1122533152_24tok2_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_name_248 = heff_env(self)[0];
  V v_program_2410 = heff_env(self)[1];
  V v_target_247 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_off_243 = heff_env(self)[5];
  V v_program_2415 = heff_take_field(v_x_2414, 1);
  V v_st_2416 = heff_get_n(v_x_2414, 0, 2);
  V v_name_2417 = heff_dup(v_name_248);
  V v_t_2418 = heff_dup(v_program_2415);
  V v_t_2421;
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nil: {
    heff_drop(v_program_2415);
    v_t_2421 = v_program_2410;
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2418, 0ULL, 2);
    heff_drop(v_program_2410);
    v_t_2421 = v_program_2415;
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_occurrences_2422 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2421, heff_dup(v_target_247), v_name_248));
  V v_target_2423 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2417, v_occurrences_2422})});
  V f_ = v_z_246;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2416, v_off_243, v_target_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}