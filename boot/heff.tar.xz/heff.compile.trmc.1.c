// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_MkArm 55352
#define TAG_StrAppend 34515
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_es 10005
#define LBL_field 298786068
#define LBL_key 315609
#define LBL_m 327
#define LBL_n 328
#define LBL_name 9869138
#define LBL_tag 324116
#define LBL_ts 10470
#define LBL_underLam 296337946
#define LBL_vs 10532
#define LBL_xs 10594
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__arity[] = {LBL_key, LBL_arity};
static uint32_t shape_key__at[] = {LBL_key, LBL_at};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
static uint32_t shape_tag__field__args__vs__es__ts[] = {LBL_tag, LBL_field, LBL_args, LBL_vs, LBL_es, LBL_ts};
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2etrmc_2eappendEnds(V, V);
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo;
V g_heff_2ecompile_2etrmc_2eappendedTo(V, V);
V g_heff_2ecompile_2etrmc_2eappendedTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendedTo_clo;
V g_heff_2ecompile_2etrmc_2earound(V, V);
V g_heff_2ecompile_2etrmc_2earound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2earound_clo;
V g_heff_2ecompile_2etrmc_2ecells(V, V, V, V);
V g_heff_2ecompile_2etrmc_2ecells_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2ecells_clo;
V g_heff_2ecompile_2etrmc_2echainHole(V);
V g_heff_2ecompile_2etrmc_2echainHole_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2echainHole_clo;
V g_heff_2ecompile_2etrmc_2echainTo(V, V, V);
V g_heff_2ecompile_2etrmc_2echainTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2echainTo_clo;
V g_heff_2ecompile_2etrmc_2econsEnds(V, V);
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2econsEnds_clo;
V g_heff_2ecompile_2etrmc_2edefT(V);
V g_heff_2ecompile_2etrmc_2edefT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edefT_clo;
V g_heff_2ecompile_2etrmc_2edestined(V, V, V, V);
V g_heff_2ecompile_2etrmc_2edestined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2edestined_clo;
V g_heff_2ecompile_2etrmc_2efill(V, V, V, V, V);
V g_heff_2ecompile_2etrmc_2efill_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2efill_clo;
V g_heff_2ecompile_2etrmc_2egather(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egather_clo;
V g_heff_2ecompile_2etrmc_2egathered(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egathered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egathered_clo;
V g_heff_2ecompile_2etrmc_2ehole_get(void);
V g_heff_2ecompile_2etrmc_2eholesAt(V, V);
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eholesAt_clo;
V g_heff_2ecompile_2etrmc_2einitOf(V);
V g_heff_2ecompile_2etrmc_2einitOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2einitOf_clo;
V g_heff_2ecompile_2etrmc_2einitOf_24dps(V, V);
V g_heff_2ecompile_2etrmc_2einitOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2einitOf_24dps_clo;
V g_heff_2ecompile_2etrmc_2eletsAround(V, V);
V g_heff_2ecompile_2etrmc_2eletsAround_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eletsAround_clo;
V g_heff_2ecompile_2etrmc_2eletsAround_24dps(V, V, V);
V g_heff_2ecompile_2etrmc_2eletsAround_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eletsAround_24dps_clo;
V g_heff_2ecompile_2etrmc_2enthOr(V, V, V);
V g_heff_2ecompile_2etrmc_2enthOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2enthOr_clo;
HeffT2 g_heff_2ecompile_2etrmc_2eprodCall_24cpr(V, V, V);
V g_heff_2ecompile_2etrmc_2eprodFill(V, V, V, V, V, V);
V g_heff_2ecompile_2etrmc_2eprodFill_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eprodFill_clo;
HeffT2 g_heff_2ecompile_2etrmc_2eprodOf_24cpr(V, V);
V g_heff_2ecompile_2etrmc_2eprodStart(V, V, V, V);
V g_heff_2ecompile_2etrmc_2eprodStart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eprodStart_clo;
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327(V, V, V, V, V);
V g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327_clo;
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927(V, V, V, V, V, V, V);
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_clo;
V g_heff_2ecompile_2etrmc_2eprodWays(V, V);
V g_heff_2ecompile_2etrmc_2eprodWays_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eprodWays_clo;
V g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344(V, V, V, V, V, V, V);
V g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_clo;
V g_heff_2ecompile_2etrmc_2eselfCall(V, V);
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eselfCall_clo;
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void);
V g_heff_2ecompile_2etrmc_2estartCell(V, V, V);
V g_heff_2ecompile_2etrmc_2estartCell_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartCell_clo;
V g_heff_2ecompile_2etrmc_2eunbound(V, V);
V g_heff_2ecompile_2etrmc_2eunbound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eunbound_clo;
V g_heff_2ecompile_2etrmc_2eunbound_24dps(V, V, V);
V g_heff_2ecompile_2etrmc_2eunbound_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eunbound_24dps_clo;
V g_list_2eall_24s2006536460x193465515(V, V, V);
V g_list_2eall_24s2006536460x193465515_entry(V self, V *a);
extern Clo g_list_2eall_24s2006536460x193465515_clo;
V g_list_2eall_24s262401054x194288545(V, V);
V g_list_2eall_24s262401054x194288545_entry(V self, V *a);
extern Clo g_list_2eall_24s262401054x194288545_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1950894567x1295732556(V, V);
V g_list_2efoldl_24s1950894567x1295732556_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1950894567x1295732556_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2ekeepIf_24s169989113x752694770(V);
V g_list_2ekeepIf_24s169989113x752694770_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s169989113x752694770_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s511663487x682582558(V, V, V, V);
V g_list_2ezipWith_24s511663487x682582558_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s511663487x682582558_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636(V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
V g_prelude_2etraverse_24s544736993x1914601267(V);
V g_prelude_2etraverse_24s544736993x1914601267_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s544736993x1914601267_clo;
V g_std_2eordmap_2eempty_get(void);
Clo g_heff_2ecompile_2etrmc_2einitOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2einitOf_entry, 1, 0};

V g_heff_2ecompile_2etrmc_2einitOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2etrmc_2einitOf_24dps(v_x12_242, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2etrmc_2einitOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2einitOf(a[0]);
}
Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eappendEnds_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eappendEnds(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_x21_2423 = heff_field(v_x2_241, 0);
    V v_x22_2424 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_2423)) {
    case TAG_StrAppend: {
      switch (heff_tag_of(v_x22_2424)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x222_2426 = heff_field(v_x22_2424, 1);
        switch (heff_tag_of(v_x222_2426)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_r_2427 = heff_field(v_x222_2426, 0);
          V v_x2222_2428 = heff_field(v_x222_2426, 1);
          switch (heff_tag_of(v_x2222_2428)) {
          case TAG_Nil: {
            V v_t_2429 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_r_2427));
            if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
              heff_drop(v_t_2429);
              return NTAG(TAG_True);
            } else {
              heff_drop(v_t_2429);
              V t_0 = v_s_240;
              V t_1 = v_r_2427;
              v_s_240 = t_0;
              v_x2_241 = t_1;
              goto top;
            }
          }
          case TAG_Cons: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x2222_2428);
          }
        }
        default: return heff_nomatch(v_x222_2426);
        }
      }
      default: return heff_nomatch(v_x22_2424);
      }
    }
    default: {
      return NTAG(TAG_False);
    }
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2eappendEnds(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2efill_str0, 5, "cell$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2efill_str1, 2, "u$");
V g_heff_2ecompile_2etrmc_2efill_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2efill_lam4(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2efill_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2efill_entry, 5, 0};

V g_heff_2ecompile_2etrmc_2efill(V v_s_240, V v_p_241, V v_d_242, V v_i_243, V v_e_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_e_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_s_240);
    heff_drop(v_t_245);
    switch (heff_tag_of(v_e_244)) {
    case TAG_ECall: {
      V v_args_247 = heff_field(v_e_244, 1);
      V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 2ULL, 2);
      V v_t_248 = heff_take_field(v_p_241, 1);
      V v_t_2411;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, NTAG(TAG_Nil)});
        v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, v_t_249});
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_248, 0ULL, 1);
        heff_drop(v_i_243);
        v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2412 = (g_prelude_2e_2b_2b(v_args_247, v_t_2411));
      V v_x_2413 = heff_tag_at_n(v_ru_24e_244_24ECall, TAG_ECall, 2, (V[]){heff_get_n(v_p_241, 0, 2), v_t_2412});
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam0, 1, 1, (V[]){v_x_2413});
    }
    default: {
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_d_242);
      heff_drop(v_i_243);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam1, 1, 1, (V[]){v_e_244});
    }
    }
  } else {
    heff_drop(v_t_245);
    V v_t_2416 = (g_heff_2ecompile_2etrmc_2econsEnds(v_s_240, heff_dup(v_e_244)));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      switch (heff_tag_of(v_e_244)) {
      case TAG_ETag: {
        V v_t_2417 = heff_dup(heff_field(v_e_244, 0));
        V v_args_2418 = heff_dup(heff_field(v_e_244, 1));
        V v_ts_2419 = heff_dup(heff_field(v_e_244, 2));
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam2, 1, 8, (V[]){v_args_2418, v_e_244, v_s_240, v_p_241, v_ts_2419, v_d_242, v_i_243, v_t_2417});
      }
      default: {
        heff_drop(v_s_240);
        heff_drop_rec(v_p_241, 2);
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam3, 1, 1, (V[]){v_e_244});
      }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop_rec(v_p_241, 2);
      heff_drop(v_t_2416);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2efill_lam4, 1, 3, (V[]){v_e_244, v_d_242, v_i_243});
    }
  }
}
V g_heff_2ecompile_2etrmc_2efill_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2efill(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2etrmc_2efill_lam0(V self, V *args) {
  V v_n_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_n_2414});
}
V g_heff_2ecompile_2etrmc_2efill_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2415});
}
V g_heff_2ecompile_2etrmc_2efill_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_args_2418 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_s_240 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  V v_ts_2419 = heff_env(self)[4];
  V v_d_242 = heff_env(self)[5];
  V v_i_243 = heff_env(self)[6];
  V v_t_2417 = heff_env(self)[7];
  V v_x_2421 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2efill_str0), heff_intShow(heff_dup(v_n_2420)));
  V v_n_2422 = heff_intAdd(v_n_2420, MK_INT(1LL));
  V v_x_2423 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2efill_str1), heff_intShow(heff_dup(v_n_2422)));
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2418));
  V v_x1_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2418)));
  V v_t_2428;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_Nil: {
    v_t_2428 = v_e_244;
    break;
  }
  case TAG_Cons: {
    V v_x_2426 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 2);
    heff_drop_tag(v_e_244, 3);
    v_t_2428 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x1_2425);
  }
  V v_t_2429 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_t_2424, MK_INT(1LL))});
  V v_m_2430 = (g_heff_2ecompile_2etrmc_2efill(v_s_240, v_p_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2423)}), v_t_2429, v_t_2428));
  V v_x2_2431 = heff_tr(heff_call(v_m_2430, 1, (V[]){heff_intAdd(v_n_2422, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_n_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), NTAG(TAG_Nil)});
    V v_t_2435 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2434, v_args_2418));
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), NTAG(TAG_Nil)});
    V v_t_2437 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2436, v_ts_2419));
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2421)}), NTAG(TAG_Nil)});
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2423, heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2esetFieldPrim_get()), v_t_2439}), v_x_2432});
    V v_x_2441 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2421, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2417, v_t_2435, v_t_2437}), v_t_2440});
    return heff_tag_re_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2441, v_n_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2etrmc_2efill_lam3(V self, V *args) {
  V v_n_2442 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_244, v_n_2442});
}
V g_heff_2ecompile_2etrmc_2efill_lam4(V self, V *args) {
  V v_n_2443 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_i_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_t_2444})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2esetFieldPrim_get()), v_t_2445}), v_n_2443});
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartCell_str0, 5, "cell$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartCell_str1, 2, "u$");
V g_heff_2ecompile_2etrmc_2estartCell_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartCell_lam2(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2estartCell_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2estartCell_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2estartCell(V v_s_240, V v_p_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2etrmc_2econsEnds(v_s_240, heff_dup(v_e_242)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_e_242)) {
    case TAG_ETag: {
      V v_t_244 = heff_dup(heff_field(v_e_242, 0));
      V v_args_245 = heff_dup(heff_field(v_e_242, 1));
      V v_ts_246 = heff_dup(heff_field(v_e_242, 2));
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam0, 1, 6, (V[]){v_args_245, v_e_242, v_s_240, v_p_241, v_ts_246, v_t_244});
    }
    default: {
      heff_drop(v_s_240);
      heff_drop(v_p_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam1, 1, 1, (V[]){v_e_242});
    }
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_p_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2estartCell_lam2, 1, 1, (V[]){v_e_242});
  }
}
V g_heff_2ecompile_2etrmc_2estartCell_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2estartCell(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2estartCell_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_args_245 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_s_240 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  V v_ts_246 = heff_env(self)[4];
  V v_t_244 = heff_env(self)[5];
  V v_x_248 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartCell_str0), heff_intShow(heff_dup(v_n_247)));
  V v_n_249 = heff_intAdd(v_n_247, MK_INT(1LL));
  V v_x_2410 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartCell_str1), heff_intShow(heff_dup(v_n_249)));
  V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_245));
  V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_245)));
  V v_t_2415;
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nil: {
    v_t_2415 = v_e_242;
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 2);
    heff_drop_tag(v_e_242, 3);
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_t_2416 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_t_2411, MK_INT(1LL))});
  V v_m_2417 = (g_heff_2ecompile_2etrmc_2efill(v_s_240, v_p_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_248)}), v_t_2416, v_t_2415));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){heff_intAdd(v_n_249, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2421, v_args_245));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2423, v_ts_246));
    V v_t_2425 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2410, v_x_2419, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_248)})});
    V v_x_2426 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, heff_tag_n(TAG_ETag, 3, (V[]){v_t_244, v_t_2422, v_t_2424}), v_t_2425});
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2426, v_n_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2etrmc_2estartCell_lam1(V self, V *args) {
  V v_n_2427 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2427});
}
V g_heff_2ecompile_2etrmc_2estartCell_lam2(V self, V *args) {
  V v_n_2428 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2428});
}
Clo g_heff_2ecompile_2etrmc_2eappendedTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eappendedTo_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eappendedTo(V v_acc_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EPrimCall: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_243 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_StrAppend: {
      switch (heff_tag_of(v_e2_243)) {
      case TAG_Nil: {
        V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_acc_240), v_t_244})});
      }
      case TAG_Cons: {
        V v_a_245 = heff_field(v_e2_243, 0);
        V v_e22_246 = heff_field(v_e2_243, 1);
        V v_ru_24e2_243_24Cons = heff_take_reuse_n(v_e2_243, 3ULL, 2);
        switch (heff_tag_of(v_e22_246)) {
        case TAG_Nil: {
          heff_drop(v_a_245);
          V v_t_247 = heff_tag_at_n(v_ru_24e2_243_24Cons, TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_acc_240), v_t_247})});
        }
        case TAG_Cons: {
          V v_b_248 = heff_field(v_e22_246, 0);
          V v_e222_249 = heff_field(v_e22_246, 1);
          V v_ru_24e22_246_24Cons = heff_take_reuse_n(v_e22_246, 3ULL, 2);
          switch (heff_tag_of(v_e222_249)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_241, 2);
            V v_a_2410 = (g_heff_2ecompile_2etrmc_2eappendedTo(v_acc_240, v_a_245));
            V v_t_2411 = heff_tag_at_n(v_ru_24e2_243_24Cons, TAG_Cons, 2, (V[]){v_b_248, NTAG(TAG_Nil)});
            return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_at_n(v_ru_24e22_246_24Cons, TAG_Cons, 2, (V[]){v_a_2410, v_t_2411})});
          }
          case TAG_Cons: {
            V v_ru_24e222_249_24Cons = heff_take_reuse_n(v_e222_249, 0ULL, 2);
            heff_drop(v_a_245);
            heff_drop(v_b_248);
            V v_t_2414 = heff_tag_at_n(v_ru_24e2_243_24Cons, TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
            return heff_tag_at_n(v_ru_24e222_249_24Cons, TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_at_n(v_ru_24e22_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_acc_240), v_t_2414})});
          }
          default: return heff_nomatch(v_e222_249);
          }
        }
        default: return heff_nomatch(v_e22_246);
        }
      }
      default: return heff_nomatch(v_e2_243);
      }
    }
    default: {
      heff_drop(v_e1_242);
      heff_drop(v_e2_243);
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_acc_240), v_t_2415})});
    }
    }
  }
  default: {
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_StrAppend), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_acc_240), v_t_2416})});
  }
  }
}
V g_heff_2ecompile_2etrmc_2eappendedTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2etrmc_2eappendedTo(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2egather_str0, 2, "s$");
V g_heff_2ecompile_2etrmc_2egather_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2egather_lam7(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2egather_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2egather_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2egather(V v_s_240, V v_ak_241, V v_acc_242, V v_e_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_e_243));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_s_240);
    heff_drop(v_t_244);
    switch (heff_tag_of(v_e_243)) {
    case TAG_ECall: {
      V v_args_246 = heff_field(v_e_243, 1);
      V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 2ULL, 2);
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_acc_242, NTAG(TAG_Nil)});
      V v_t_248 = (g_prelude_2e_2b_2b(v_args_246, v_t_247));
      V v_x_249 = heff_tag_at_n(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_ak_241, v_t_248});
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam0, 1, 1, (V[]){v_x_249});
    }
    default: {
      heff_drop(v_ak_241);
      heff_drop(v_acc_242);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam1, 1, 1, (V[]){v_e_243});
    }
    }
  } else {
    heff_drop(v_t_244);
    V v_t_2412 = (g_heff_2ecompile_2etrmc_2eappendEnds(v_s_240, v_e_243));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      switch (heff_tag_of(v_e_243)) {
      case TAG_EPrimCall: {
        V v_it2_2414 = heff_dup(heff_field(v_e_243, 1));
        switch (heff_tag_of(v_it2_2414)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          heff_drop(v_ak_241);
          heff_drop(v_acc_242);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam2, 1, 1, (V[]){v_e_243});
        }
        case TAG_Cons: {
          V v_a_2416 = heff_field(v_it2_2414, 0);
          V v_it22_2417 = heff_field(v_it2_2414, 1);
          heff_take_n(v_it2_2414, 3ULL, 2);
          switch (heff_tag_of(v_it22_2417)) {
          case TAG_Nil: {
            heff_drop(v_s_240);
            heff_drop(v_ak_241);
            heff_drop(v_acc_242);
            heff_drop(v_a_2416);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam3, 1, 1, (V[]){v_e_243});
          }
          case TAG_Cons: {
            V v_r_2419 = heff_field(v_it22_2417, 0);
            V v_it222_2420 = heff_field(v_it22_2417, 1);
            heff_take_n(v_it22_2417, 3ULL, 2);
            switch (heff_tag_of(v_it222_2420)) {
            case TAG_Nil: {
              heff_drop_tag(v_e_243, 2);
              return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam4, 1, 5, (V[]){v_s_240, v_ak_241, v_r_2419, v_acc_242, v_a_2416});
            }
            case TAG_Cons: {
              heff_take_n(v_it222_2420, 0ULL, 2);
              heff_drop(v_s_240);
              heff_drop(v_ak_241);
              heff_drop(v_acc_242);
              heff_drop(v_a_2416);
              heff_drop(v_r_2419);
              return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam5, 1, 1, (V[]){v_e_243});
            }
            default: return heff_nomatch(v_it222_2420);
            }
          }
          default: return heff_nomatch(v_it22_2417);
          }
        }
        default: return heff_nomatch(v_it2_2414);
        }
      }
      default: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        heff_drop(v_acc_242);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam6, 1, 1, (V[]){v_e_243});
      }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      heff_drop(v_t_2412);
      V v_x_2433 = ({ V a_0 = v_acc_242; V a_1 = v_e_243; V r_ = (g_heff_2ecompile_2etrmc_2eappendedTo(a_0, a_1)); heff_drop(v_acc_242); r_; });
      return heff_clo_n(g_heff_2ecompile_2etrmc_2egather_lam7, 1, 1, (V[]){v_x_2433});
    }
  }
}
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2egather(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2egather_lam0(V self, V *args) {
  V v_n_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_n_2410});
}
V g_heff_2ecompile_2etrmc_2egather_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2411});
}
V g_heff_2ecompile_2etrmc_2egather_lam2(V self, V *args) {
  V v_n_2415 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2415});
}
V g_heff_2ecompile_2etrmc_2egather_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2418});
}
V g_heff_2ecompile_2etrmc_2egather_lam4(V self, V *args) {
  V v_n_2421 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_ak_241 = heff_env(self)[1];
  V v_r_2419 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_a_2416 = heff_env(self)[4];
  V v_x_2422 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2egather_str0), heff_intShow(heff_dup(v_n_2421)));
  heff_clo_take(self, 5);
  V v_m_2423 = (g_heff_2ecompile_2etrmc_2egather(v_s_240, v_ak_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2422)}), v_r_2419));
  V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){heff_intAdd(v_n_2421, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_t_2427 = ({ V a_0 = v_acc_242; V a_1 = v_a_2416; V r_ = (g_heff_2ecompile_2etrmc_2eappendedTo(a_0, a_1)); heff_drop(v_acc_242); r_; });
    V v_x_2428 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2422, v_t_2427, v_x_2425});
    return heff_tag_re_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2428, v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2etrmc_2egather_lam5(V self, V *args) {
  V v_n_2431 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2431});
}
V g_heff_2ecompile_2etrmc_2egather_lam6(V self, V *args) {
  V v_n_2432 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2432});
}
V g_heff_2ecompile_2etrmc_2egather_lam7(V self, V *args) {
  V v_n_2434 = args[0];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2433, v_n_2434});
}
Clo g_heff_2ecompile_2etrmc_2enthOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2enthOr_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2enthOr(V v_d_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return heff_dup(v_d_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c_lent(v_k_241, MK_INT(0LL), 2)) {
      heff_drop(v_k_241);
      return heff_dup(v_x_243);
    } else {
      V t_0 = v_d_240;
      V t_1 = heff_intSub(v_k_241, MK_INT(1LL));
      V t_2 = v_xs_244;
      v_d_240 = t_0;
      v_k_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2etrmc_2enthOr_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2etrmc_2enthOr(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2eprodCall_24cpr_str0, 1, "_");

HeffT2 g_heff_2ecompile_2etrmc_2eprodCall_24cpr(V v_s_240, V v_c_241, V v_arms_242) {
top: ;
  V v_key_243 = heff_take_field(v_s_240, 0);
  V v_arity_244 = heff_get_n(v_s_240, 1, 2);
  switch (heff_tag_of(v_c_241)) {
  case TAG_EVar: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    V v_g_2428 = heff_field(v_c_241, 0);
    V v_args_2429 = heff_field(v_c_241, 1);
    if ((heff_strEq_c_lent(v_g_2428, v_key_243, 0) && ({ V v_t_24110 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2429)); int c_ = heff_intEq_c_lent(v_t_24110, v_arity_244, 0); heff_drop(v_t_24110); c_; }))) {
      heff_drop(v_key_243);
      heff_drop(v_arity_244);
      switch (heff_tag_of(v_arms_242)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_a_2430 = heff_field(v_arms_242, 0);
        V v_arms2_2431 = heff_field(v_arms_242, 1);
        switch (heff_tag_of(v_arms2_2431)) {
        case TAG_Nil: {
          V v_args_2432 = heff_dup(v_args_2429);
          V v_a_2433 = heff_dup(v_a_2430);
          switch (heff_tag_of(v_a_2433)) {
          case TAG_MkArm: {
            V v_t_2434 = heff_field(v_a_2433, 0);
            V v_vs_2435 = heff_field(v_a_2433, 1);
            V v_a3_2436 = heff_field(v_a_2433, 2);
            heff_take_n(v_a_2433, 7ULL, 3);
            switch (heff_tag_of(v_a3_2436)) {
            case TAG_EVar: {
              heff_take_n(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EGlobal: {
              heff_take_n(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_ELam: {
              heff_take_n(v_a3_2436, 0ULL, 2);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EApp: {
              heff_take_n(v_a3_2436, 0ULL, 2);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_ELet: {
              heff_take_n(v_a3_2436, 0ULL, 3);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_ERecord: {
              heff_take_n(v_a3_2436, 0ULL, 2);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EProj: {
              heff_take_n(v_a3_2436, 0ULL, 4);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_ETag: {
              V v_t2_2452 = heff_field(v_a3_2436, 0);
              V v_es_2453 = heff_field(v_a3_2436, 1);
              V v_ts_2454 = heff_field(v_a3_2436, 2);
              heff_take_n(v_a3_2436, 7ULL, 3);
              if ((heff_strEq_c_lent(v_t_2434, v_t2_2452, 0) && ({ V v_t_24111 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2435)); int c_ = ({ V v_t_24112 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_2453)); int c_ = heff_intEq_c_lent(v_t_24111, v_t_24112, 0); heff_drop(v_t_24112); c_; }); heff_drop(v_t_24111); c_; }))) {
                heff_drop(v_t2_2452);
                V v_vs_2455 = heff_dup(v_vs_2435);
                V v_es_2456 = heff_dup(v_es_2453);
                V v_t_2457 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2455));
                V v_t_2458 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2457, MK_INT(1LL))));
                V v_t_2459 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_vs_2455), v_es_2456));
                V v_t_2460 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2458, v_t_2459));
                V v_ps_2461 = (g_list_2ekeepIf_24s169989113x752694770(v_t_2460));
                V v_x3_2471;
                switch (heff_tag_of(v_ps_2461)) {
                case TAG_Nil: {
                  heff_drop(v_vs_2455);
                  v_x3_2471 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Cons: {
                  V v_ps1_2462 = heff_field(v_ps_2461, 0);
                  V v_ps2_2463 = heff_field(v_ps_2461, 1);
                  heff_take_n(v_ps_2461, 3ULL, 2);
                  switch (heff_tag_of(v_ps1_2462)) {
                  case TAG_MkPair: {
                    V v_j_2464 = heff_field(v_ps1_2462, 0);
                    V v_ps12_2465 = heff_field(v_ps1_2462, 1);
                    heff_take_n(v_ps1_2462, 3ULL, 2);
                    switch (heff_tag_of(v_ps12_2465)) {
                    case TAG_MkPair: {
                      V v_v_2466 = heff_field(v_ps12_2465, 0);
                      V v_e_2467 = heff_field(v_ps12_2465, 1);
                      heff_take_n(v_ps12_2465, 3ULL, 2);
                      switch (heff_tag_of(v_ps2_2463)) {
                      case TAG_Nil: {
                        if (!heff_strEq_c_lent(v_v_2466, ((V)&g_heff_2ecompile_2etrmc_2eprodCall_24cpr_str0), 2)) {
                          V v_t_2468 = ({ V a_0 = v_v_2466; V a_1 = v_vs_2455; V a_2 = v_e_2467; V r_ = (g_heff_2ecompile_2etrmc_2echainTo(a_0, a_1, a_2)); heff_drop(v_v_2466); heff_drop(v_vs_2455); r_; });
                          if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
                            heff_drop(v_t_2468);
                            v_x3_2471 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2464});
                          } else {
                            heff_drop(v_j_2464);
                            heff_drop(v_t_2468);
                            v_x3_2471 = NTAG(TAG_Nothing);
                          }
                        } else {
                          heff_drop(v_vs_2455);
                          heff_drop(v_j_2464);
                          heff_drop(v_v_2466);
                          heff_drop(v_e_2467);
                          v_x3_2471 = NTAG(TAG_Nothing);
                        }
                        break;
                      }
                      case TAG_Cons: {
                        heff_take_n(v_ps2_2463, 0ULL, 2);
                        heff_drop(v_vs_2455);
                        heff_drop(v_j_2464);
                        heff_drop(v_v_2466);
                        heff_drop(v_e_2467);
                        v_x3_2471 = NTAG(TAG_Nothing);
                        break;
                      }
                      default: heff_nomatch(v_ps2_2463);
                      }
                      break;
                    }
                    default: heff_nomatch(v_ps12_2465);
                    }
                    break;
                  }
                  default: heff_nomatch(v_ps1_2462);
                  }
                  break;
                }
                default: heff_nomatch(v_ps_2461);
                }
                switch (heff_tag_of(v_x3_2471)) {
                case TAG_Nothing: {
                  heff_drop(v_args_2432);
                  heff_drop(v_t_2434);
                  heff_drop(v_vs_2435);
                  heff_drop(v_es_2453);
                  heff_drop(v_ts_2454);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x_2472 = heff_field(v_x3_2471, 0);
                  heff_take_n(v_x3_2471, 1ULL, 1);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(6, shape_tag__field__args__vs__es__ts, (V[]){v_t_2434, v_x_2472, v_args_2432, v_vs_2435, v_es_2453, v_ts_2454})}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2471)}});
                }
              } else {
                heff_drop(v_args_2432);
                heff_drop(v_t_2434);
                heff_drop(v_vs_2435);
                heff_drop(v_t2_2452);
                heff_drop(v_es_2453);
                heff_drop(v_ts_2454);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
            case TAG_EMatch: {
              heff_take_n(v_a3_2436, 0ULL, 2);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EPrim: {
              heff_take_n(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EPrimCall: {
              heff_take_n(v_a3_2436, 0ULL, 2);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_ECall: {
              heff_take_n(v_a3_2436, 0ULL, 2);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EInt: {
              heff_take_n(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EFloat: {
              heff_take_nf(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EStr: {
              heff_take_n(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EBytes: {
              heff_take_n(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EFixed: {
              heff_take_n(v_a3_2436, 0ULL, 2);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EFloat32: {
              heff_take_na(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EAbandon: {
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EBool: {
              heff_take_n(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_ESet: {
              heff_take_n(v_a3_2436, 0ULL, 3);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EValues: {
              heff_take_n(v_a3_2436, 0ULL, 1);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_EFix: {
              heff_take_n(v_a3_2436, 0ULL, 2);
              heff_drop(v_args_2432);
              heff_drop(v_t_2434);
              heff_drop(v_vs_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_a3_2436)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_a_2433)}});
          }
        }
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_arms2_2431)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_arms_242)}});
      }
    } else {
      heff_drop(v_key_243);
      heff_drop(v_arity_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_drop(v_key_243);
    heff_drop(v_arity_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_c_241)}});
  }
}

HeffT2 g_heff_2ecompile_2etrmc_2eprodOf_24cpr(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    V v_c_2420 = heff_field(v_e_241, 0);
    V v_arms_2421 = heff_field(v_e_241, 1);
    return (g_heff_2ecompile_2etrmc_2eprodCall_24cpr(v_s_240, v_c_2420, v_arms_2421));
  }
  case TAG_EPrim: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_drop(v_s_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2ecells_str0, 5, "cell$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2ecells_str1, 2, "u$");
V g_heff_2ecompile_2etrmc_2ecells_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2ecells_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2ecells_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2ecells(V v_d_240, V v_i_241, V v_e_242, V v_k_243) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ETag: {
    V v_t_244 = heff_field(v_e_242, 0);
    V v_args_245 = heff_field(v_e_242, 1);
    V v_ts_246 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2ecells_lam0, 1, 6, (V[]){v_args_245, v_k_243, v_ts_246, v_d_240, v_i_241, v_t_244});
  }
  default: {
    heff_drop(v_e_242);
    return heff_tail(v_k_243, 2, (V[]){v_d_240, v_i_241});
  }
  }
}
V g_heff_2ecompile_2etrmc_2ecells_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2ecells(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2ecells_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_args_245 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_ts_246 = heff_env(self)[2];
  V v_d_240 = heff_env(self)[3];
  V v_i_241 = heff_env(self)[4];
  V v_t_244 = heff_env(self)[5];
  V v_x_248 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2ecells_str0), heff_intShow(heff_dup(v_n_247)));
  V v_n_249 = heff_intAdd(v_n_247, MK_INT(1LL));
  V v_x_2410 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2ecells_str1), heff_intShow(heff_dup(v_n_249)));
  V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_245));
  V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_245)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nil: {
    v_t_2415 = NTAG(TAG_EAbandon);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 2);
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_t_2416 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_t_2411, MK_INT(1LL))});
  heff_clo_take(self, 6);
  V v_m_2417 = heff_tr(g_heff_2ecompile_2etrmc_2ecells(heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2410)}), v_t_2416, v_t_2415, v_k_243));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){heff_intAdd(v_n_249, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2421, v_args_245));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2423, v_ts_246));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_248)}), NTAG(TAG_Nil)});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, heff_tag_n(TAG_Cons, 2, (V[]){v_i_241, v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2410, heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2esetFieldPrim_get()), v_t_2426}), v_x_2419});
    V v_x_2428 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, heff_tag_n(TAG_ETag, 3, (V[]){v_t_244, v_t_2422, v_t_2424}), v_t_2427});
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2428, v_n_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
Clo g_heff_2ecompile_2etrmc_2eletsAround_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eletsAround_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eletsAround(V v_x1_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_b_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_e_245 = heff_field(v_x11_242, 1);
      V v_cell_246 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_e_245), heff_hole()});
      V v_u_247 = ({ V a_0 = v_rest_243; V a_1 = v_b_241; V a_2 = v_cell_246; V r_ = (g_heff_2ecompile_2etrmc_2eletsAround_24dps(a_0, a_1, a_2)); heff_drop(v_b_241); r_; });
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2etrmc_2eletsAround_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2etrmc_2eletsAround(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2eprodFill_str0, 2, "u$");
V g_heff_2ecompile_2etrmc_2eprodFill_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodFill_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodFill_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodFill_lam3(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eprodFill_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eprodFill_entry, 6, 0};

V g_heff_2ecompile_2etrmc_2eprodFill(V v_s_240, V v_p_241, V v_d_242, V v_i_243, V v_j_244, V v_e_245) {
top: ;
  V v_at_246 = heff_take_field(v_p_241, 1);
  V v_key_247 = heff_get_n(v_p_241, 0, 2);
  switch (heff_tag_of(v_e_245)) {
  case TAG_ETag: {
    V v_t_248 = heff_field(v_e_245, 0);
    V v_es_249 = heff_field(v_e_245, 1);
    V v_ts_2410 = heff_field(v_e_245, 2);
    heff_take_n(v_e_245, 7ULL, 3);
    heff_drop(v_s_240);
    heff_drop(v_at_246);
    heff_drop(v_key_247);
    V v_m_2411 = (g_prelude_2etraverse_24s544736993x1914601267(v_es_249));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodFill_lam0, 1, 6, (V[]){v_m_2411, v_j_244, v_ts_2410, v_d_242, v_i_243, v_t_248});
  }
  default: {
    HeffT2 v_t_2431 = (g_heff_2ecompile_2etrmc_2eprodOf_24cpr(v_s_240, v_e_245));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        heff_drop(v_e_245);
        V v_q_2434 = v_field_2433;
        V v_es_2435 = heff_take_field(v_q_2434, 4);
        V v_args_2436 = heff_get_n(v_q_2434, 2, 6);
        V v_t_2437 = ({ V a_0 = NTAG(TAG_EAbandon); V a_1 = v_j_244; V a_2 = v_es_2435; V r_ = (g_heff_2ecompile_2etrmc_2enthOr(a_0, a_1, a_2)); heff_drop(v_es_2435); r_; });
        return (g_heff_2ecompile_2etrmc_2ecells(v_d_242, v_i_243, v_t_2437, heff_clo_n(g_heff_2ecompile_2etrmc_2eprodFill_lam1, 2, 3, (V[]){v_at_246, v_args_2436, v_key_247})));
      } else {
        heff_drop(v_d_242);
        heff_drop(v_i_243);
        heff_drop(v_j_244);
        heff_drop(v_at_246);
        heff_drop(v_key_247);
        heff_drop(v_field_2433);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodFill_lam3, 1, 1, (V[]){v_e_245});
      }
    }
  }
  }
}
V g_heff_2ecompile_2etrmc_2eprodFill_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eprodFill(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2etrmc_2eprodFill_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_j_244 = heff_env(self)[1];
  V v_ts_2410 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_i_243 = heff_env(self)[4];
  V v_t_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_es2_2416 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_x_2414)));
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2414));
    V v_t_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1950894567x1295732556(a_0, a_1)); heff_drop(v_t_2417); r_; });
    V v_t_2419 = (g_heff_2ecompile_2etrmc_2enthOr(NTAG(TAG_EAbandon), heff_dup(v_j_244), v_es2_2416));
    V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es2_2416));
    V v_t_2421 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2420, MK_INT(1LL))));
    V v_t_2422 = (g_list_2ezipWith_24s511663487x682582558(heff_dup(v_j_244), heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), v_t_2421, v_es2_2416));
    V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2410));
    V v_t_2424 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2423, MK_INT(1LL))));
    V v_t_2425 = (g_list_2ezipWith_24s511663487x682582558(v_j_244, NTAG(TAG_FtAny), v_t_2424, v_ts_2410));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2eprodFill_str0), heff_intShow(heff_dup(v_n_2415)));
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_ELet, 3, (V[]){v_t_2426, heff_tag_n(TAG_EPrimCall, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2esetFieldPrim_get()), v_t_2428}), heff_tag_n(TAG_ETag, 3, (V[]){v_t_248, v_t_2422, v_t_2425})});
    V v_x_2430 = ({ V a_0 = v_t_2418; V a_1 = v_t_2429; V r_ = (g_heff_2ecompile_2etrmc_2eletsAround(a_0, a_1)); heff_drop(v_t_2418); r_; });
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2430, heff_intAdd(v_n_2415, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2etrmc_2eprodFill_lam2(V self, V *args) {
  V v_n_2446 = args[0];
  V v_x_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2445, v_n_2446});
}
V g_heff_2ecompile_2etrmc_2eprodFill_lam1(V self, V *args) {
  V v_d2_2438 = args[0];
  V v_i2_2439 = args[1];
  V v_at_246 = heff_env(self)[0];
  V v_args_2436 = heff_env(self)[1];
  V v_key_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2440 = v_at_246;
  V v_t_2443;
  switch (heff_tag_of(v_t_2440)) {
  case TAG_Nothing: {
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_i2_2439, NTAG(TAG_Nil)});
    v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_d2_2438, v_t_2441});
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_2440, 0ULL, 1);
    heff_drop(v_i2_2439);
    v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_d2_2438, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2440);
  }
  V v_t_2444 = (g_prelude_2e_2b_2b(v_args_2436, v_t_2443));
  V v_x_2445 = heff_tag_n(TAG_ECall, 2, (V[]){v_key_247, v_t_2444});
  return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodFill_lam2, 1, 1, (V[]){v_x_2445});
}
V g_heff_2ecompile_2etrmc_2eprodFill_lam3(V self, V *args) {
  V v_n_2447 = args[0];
  V v_e_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_245, v_n_2447});
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2eprodStart_str0, 5, "cell$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2eprodStart_str1, 1, "_");
V g_heff_2ecompile_2etrmc_2eprodStart_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodStart_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodStart_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodStart_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodStart_lam4(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eprodStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eprodStart_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2eprodStart(V v_s_240, V v_p_241, V v_j_242, V v_e_243) {
top: ;
  V v_at_244 = heff_take_field(v_p_241, 1);
  V v_key_245 = heff_get_n(v_p_241, 0, 2);
  HeffT2 v_t_246 = (g_heff_2ecompile_2etrmc_2eprodOf_24cpr(v_s_240, v_e_243));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_q_249 = v_field_248;
      V v_es_2410 = heff_take_field(v_q_249, 4);
      V v_args_2411 = heff_take_field(v_q_249, 2);
      V v_vs_2412 = heff_take_field(v_q_249, 3);
      V v_tag_2413 = heff_take_field(v_q_249, 0);
      V v_ts_2414 = heff_get_n(v_q_249, 5, 6);
      V v_t_2415 = (g_heff_2ecompile_2etrmc_2enthOr(NTAG(TAG_EAbandon), heff_dup(v_j_242), v_es_2410));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_ETag: {
        V v_t_2416 = heff_field(v_t_2415, 0);
        V v_args_2417 = heff_field(v_t_2415, 1);
        V v_ts_2418 = heff_field(v_t_2415, 2);
        heff_take_n(v_t_2415, 7ULL, 3);
        heff_drop(v_e_243);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodStart_lam0, 1, 11, (V[]){v_args_2417, v_at_244, v_args_2411, v_vs_2412, v_j_242, v_es_2410, v_tag_2413, v_ts_2414, v_key_245, v_ts_2418, v_t_2416});
      }
      default: {
        heff_drop(v_j_242);
        heff_drop(v_at_244);
        heff_drop(v_key_245);
        heff_drop(v_es_2410);
        heff_drop(v_args_2411);
        heff_drop(v_vs_2412);
        heff_drop(v_tag_2413);
        heff_drop(v_ts_2414);
        heff_drop(v_t_2415);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodStart_lam3, 1, 1, (V[]){v_e_243});
      }
      }
    } else {
      heff_drop(v_j_242);
      heff_drop(v_at_244);
      heff_drop(v_key_245);
      heff_drop(v_field_248);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodStart_lam4, 1, 1, (V[]){v_e_243});
    }
  }
}
V g_heff_2ecompile_2etrmc_2eprodStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eprodStart(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2eprodStart_lam2(V self, V *args) {
  V v_n_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_n_2445});
}
V g_heff_2ecompile_2etrmc_2eprodStart_lam1(V self, V *args) {
  V v_d2_2427 = args[0];
  V v_i2_2428 = args[1];
  V v_at_244 = heff_env(self)[0];
  V v_args_2411 = heff_env(self)[1];
  V v_vs_2412 = heff_env(self)[2];
  V v_j_242 = heff_env(self)[3];
  V v_es_2410 = heff_env(self)[4];
  V v_x_2420 = heff_env(self)[5];
  V v_tag_2413 = heff_env(self)[6];
  V v_ts_2414 = heff_env(self)[7];
  V v_key_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2429 = v_at_244;
  V v_t_2432;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_i2_2428, NTAG(TAG_Nil)});
    v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_d2_2427, v_t_2430});
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_2429, 0ULL, 1);
    heff_drop(v_i2_2428);
    v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_d2_2427, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  V v_t_2433 = (g_prelude_2e_2b_2b(v_args_2411, v_t_2432));
  V v_ys_2434 = v_vs_2412;
  V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2434));
  V v_t_2436 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2435, MK_INT(1LL))));
  V v_t_2437 = (g_list_2ezipWith_24s511663487x682582558(heff_dup(v_j_242), ((V)&g_heff_2ecompile_2etrmc_2eprodStart_str1), v_t_2436, v_ys_2434));
  V v_ys_2438 = v_es_2410;
  V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2438));
  V v_t_2440 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2439, MK_INT(1LL))));
  V v_t_2441 = (g_list_2ezipWith_24s511663487x682582558(v_j_242, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2420}), v_t_2440, v_ys_2438));
  V v_t_2442 = heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(v_tag_2413), v_t_2437, heff_tag_n(TAG_ETag, 3, (V[]){v_tag_2413, v_t_2441, v_ts_2414})});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
  V v_x_2444 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_key_245, v_t_2433}), v_t_2443});
  return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodStart_lam2, 1, 1, (V[]){v_x_2444});
}
V g_heff_2ecompile_2etrmc_2eprodStart_lam0(V self, V *args) {
  V v_n_2419 = args[0];
  V v_args_2417 = heff_env(self)[0];
  V v_at_244 = heff_env(self)[1];
  V v_args_2411 = heff_env(self)[2];
  V v_vs_2412 = heff_env(self)[3];
  V v_j_242 = heff_env(self)[4];
  V v_es_2410 = heff_env(self)[5];
  V v_tag_2413 = heff_env(self)[6];
  V v_ts_2414 = heff_env(self)[7];
  V v_key_245 = heff_env(self)[8];
  V v_ts_2418 = heff_env(self)[9];
  V v_t_2416 = heff_env(self)[10];
  V v_x_2420 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2eprodStart_str0), heff_intShow(heff_dup(v_n_2419)));
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2417));
  V v_x1_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2417)));
  V v_t_2425;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nil: {
    v_t_2425 = NTAG(TAG_EAbandon);
    break;
  }
  case TAG_Cons: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 2);
    v_t_2425 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_t_2426 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_t_2421, MK_INT(1LL))});
  heff_clo_take(self, 11);
  V v_m_2446 = heff_tr(g_heff_2ecompile_2etrmc_2ecells(heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2420)}), v_t_2426, v_t_2425, heff_clo_n(g_heff_2ecompile_2etrmc_2eprodStart_lam1, 2, 9, (V[]){v_at_244, v_args_2411, v_vs_2412, v_j_242, v_es_2410, heff_dup(v_x_2420), v_tag_2413, v_ts_2414, v_key_245})));
  V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){heff_intAdd(v_n_2419, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_n_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2etrmc_2ehole_get()), NTAG(TAG_Nil)});
    V v_t_2451 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2450, v_args_2417));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), NTAG(TAG_Nil)});
    V v_t_2453 = (g_prelude_2e_2b_2b_24f709746438x971999636(v_t_2452, v_ts_2418));
    V v_x_2454 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_2420, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2416, v_t_2451, v_t_2453}), v_x_2448});
    return heff_tag_re_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2454, v_n_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2etrmc_2eprodStart_lam3(V self, V *args) {
  V v_n_2455 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2455});
}
V g_heff_2ecompile_2etrmc_2eprodStart_lam4(V self, V *args) {
  V v_n_2456 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_n_2456});
}
Clo g_heff_2ecompile_2etrmc_2earound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2earound_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2earound(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 3);
    V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2418));
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 2);
      V v_t_2462;
      switch (heff_tag_of(v_x_2421)) {
      case TAG_EVar: {
        V v_w_2423 = heff_dup(heff_field(v_x_2421, 0));
        v_t_2462 = heff_bool(heff_strEq_c_lent(v_r_240, v_w_2423, 0));
        heff_drop(v_w_2423);
        break;
      }
      case TAG_EGlobal: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2462 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2421);
      }
      if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
        heff_drop(v_x_2421);
        heff_drop(v_t_2462);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2462);
        V t_0 = v_r_240;
        V t_1 = v_x_2421;
        v_r_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x1_2420);
    }
  }
  case TAG_EMatch: {
    V v_c_2463 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 2);
    switch (heff_tag_of(v_c_2463)) {
    case TAG_EVar: {
      V v_w_2465 = heff_field(v_c_2463, 0);
      heff_take_n(v_c_2463, 1ULL, 1);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_r_240, v_w_2465, 0));
      heff_drop(v_w_2465);
      return v_ret_24bool;
    }
    case TAG_EGlobal: {
      heff_take_n(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_take_n(v_c_2463, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_take_n(v_c_2463, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_c_2463, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_c_2463, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_c_2463, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_c_2463, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_c_2463, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_c_2463, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_c_2463, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_nf(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_take_n(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_c_2463, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_na(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_take_n(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_take_n(v_c_2463, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_take_n(v_c_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_c_2463, 0ULL, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_c_2463);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_e1_24105 = heff_field(v_e_241, 0);
    V v_e2_24106 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_24105)) {
    case TAG_StrAppend: {
      switch (heff_tag_of(v_e2_24106)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e22_24108 = heff_field(v_e2_24106, 1);
        heff_take_n(v_e2_24106, 2ULL, 2);
        switch (heff_tag_of(v_e22_24108)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_b_24109 = heff_field(v_e22_24108, 0);
          V v_e222_24110 = heff_field(v_e22_24108, 1);
          heff_take_n(v_e22_24108, 3ULL, 2);
          switch (heff_tag_of(v_e222_24110)) {
          case TAG_Nil: {
            V v_t_24150;
            switch (heff_tag_of(v_b_24109)) {
            case TAG_EVar: {
              V v_w_24111 = heff_dup(heff_field(v_b_24109, 0));
              v_t_24150 = heff_bool(heff_strEq_c_lent(v_r_240, v_w_24111, 0));
              heff_drop(v_w_24111);
              break;
            }
            case TAG_EGlobal: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_ELam: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EApp: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_ELet: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_ERecord: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EProj: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_ETag: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EMatch: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EPrim: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EPrimCall: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_ECall: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EInt: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EFloat: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EStr: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EBytes: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EFixed: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EFloat32: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EAbandon: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EBool: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_ESet: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EValues: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            case TAG_EFix: {
              v_t_24150 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_b_24109);
            }
            if ((heff_dup(v_t_24150) == NTAG(TAG_True))) {
              heff_drop(v_b_24109);
              heff_drop(v_t_24150);
              return NTAG(TAG_True);
            } else {
              heff_drop(v_t_24150);
              V t_0 = v_r_240;
              V t_1 = v_b_24109;
              v_r_240 = t_0;
              v_e_241 = t_1;
              goto top;
            }
          }
          case TAG_Cons: {
            heff_take_n(v_e222_24110, 0ULL, 2);
            heff_drop(v_b_24109);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_e222_24110);
          }
        }
        default: return heff_nomatch(v_e22_24108);
        }
      }
      default: return heff_nomatch(v_e2_24106);
      }
    }
    default: {
      heff_drop(v_e1_24105);
      heff_drop(v_e2_24106);
      return NTAG(TAG_False);
    }
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2earound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2etrmc_2earound(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2etrmc_2eunbound_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eunbound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eunbound_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eunbound(V v_s_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    return v_e_241;
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    V v_r_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_s_2411 = heff_dup(v_s_240);
    V v_r_2412 = v_r_248;
    V v_a_2413 = v_a_249;
    V v_b_2414 = (g_heff_2ecompile_2etrmc_2eunbound(v_s_240, v_b_2410));
    V v_t_2415 = (g_heff_2ecompile_2etrmc_2eselfCall(v_s_2411, v_a_2413));
    if (((heff_dup(v_t_2415) == NTAG(TAG_True)) && ({ V v_c_2458 = (g_heff_2ecompile_2etrmc_2earound(v_r_2412, heff_dup(v_b_2414))); int c_ = ((heff_dup(v_c_2458) == NTAG(TAG_True)) && ({ V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2414), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2417 = (g_heff_2ecompile_2eir_2ecountW(v_r_2412, MK_INT(0LL), heff_dup(v_t_2416))); int c_ = ({ V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2414), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2419 = (g_heff_2ecompile_2eir_2elamW(v_r_2412, heff_dup(v_t_2418))); int c_ = ({ V v_t_2459 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2417), heff_dup(v_t_2419)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_2459, MK_INT(1LL), 2); heff_drop(v_t_2459); c_; }); heff_drop(v_t_2419); c_; }); heff_drop(v_t_2418); c_; }); heff_drop(v_t_2417); c_; }); heff_drop(v_t_2416); c_; })); heff_drop(v_c_2458); c_; }))) {
      heff_drop_cell(v_ru_24e_241_24ELet, 3);
      heff_drop(v_t_2415);
      return ({ V a_0 = MK_INT(1LL); V a_1 = v_r_2412; V a_2 = v_a_2413; V a_3 = v_b_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(a_0, a_1, a_2, a_3)); heff_drop(v_r_2412); heff_drop(v_a_2413); r_; });
    } else {
      heff_drop(v_t_2415);
      return heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_r_2412, v_a_2413, v_b_2414});
    }
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_c_2429 = heff_field(v_e_241, 0);
    V v_arms_2430 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2etrmc_2eunbound_lam0, 1, 1, (V[]){heff_dup(v_s_240)}), v_arms_2430));
    return heff_tag_re_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, 1ULL, (V[]){v_c_2429, v_t_2436});
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EBool: {
    return v_e_241;
  }
  case TAG_ESet: {
    V v_xs_2450 = heff_field(v_e_241, 0);
    V v_a_2451 = heff_field(v_e_241, 1);
    V v_b_2452 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2453 = heff_tag_re_n(v_ru_24e_241_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2450, v_a_2451, heff_hole()});
    V v_u_2454 = (g_heff_2ecompile_2etrmc_2eunbound_24dps(v_s_240, v_b_2452, v_cell_2453));
    heff_drop(v_u_2454);
    return v_cell_2453;
  }
  case TAG_EValues: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eunbound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2etrmc_2eunbound(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2etrmc_2eunbound_lam0(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_s_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkArm: {
    V v_t_2432 = heff_field(v_x2_2431, 0);
    V v_vs_2433 = heff_field(v_x2_2431, 1);
    V v_b_2434 = heff_field(v_x2_2431, 2);
    V v_ru_24x2_2431_24MkArm = heff_take_reuse_n(v_x2_2431, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2435 = ({ V a_0 = v_s_240; V a_1 = v_b_2434; V r_ = (g_heff_2ecompile_2etrmc_2eunbound(a_0, a_1)); heff_drop(v_s_240); r_; });
    return heff_tag_re_n(v_ru_24x2_2431_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2432, v_vs_2433, v_t_2435});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str0, 4, "$dps");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str1, 2, "d$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str2, 2, "i$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2edestined_str3, 4, "$dps");
V g_heff_2ecompile_2etrmc_2edestined_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2edestined_lam1(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2edestined_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2edestined_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2edestined(V v_s_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_xs_244 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b_243, NTAG(TAG_Nil)));
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_x1_249 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2edestined_lam0, 2, 1, (V[]){heff_dup(v_s_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_245); r_; });
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nil: {
    v_t_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_k_2410 = heff_field(v_x1_249, 0);
    V v_ks_2411 = heff_field(v_x1_249, 1);
    heff_take_n(v_x1_249, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = v_k_2410; V a_1 = v_ks_2411; V r_ = (g_list_2eall_24s262401054x194288545(a_0, a_1)); heff_drop(v_ks_2411); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_k_2410});
    } else {
      heff_drop(v_k_2410);
      heff_drop(v_t_2412);
      v_t_2413 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_t_2414 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2etrmc_2edestined_str0));
  V v_p_2415 = heff_rec_n(2, shape_key__at, (V[]){v_t_2414, v_t_2413});
  V v_m_2416 = (g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(v_s_240, v_p_2415, heff_dup(v_b_243)));
  return heff_clo_n(g_heff_2ecompile_2etrmc_2edestined_lam1, 1, 6, (V[]){v_m_2416, v_xs_242, v_b_243, v_p_2415, v_s_240, v_d_241});
}
V g_heff_2ecompile_2etrmc_2edestined_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2edestined(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2edestined_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = ({ V a_0 = v_s_240; V a_1 = v_x_247; V r_ = (g_heff_2ecompile_2etrmc_2eholesAt(a_0, a_1)); heff_drop(v_s_240); r_; });
  return (g_prelude_2e_2b_2b(v_t_248, v_acc_246));
}
V g_heff_2ecompile_2etrmc_2edestined_lam1(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  V v_b_243 = heff_env(self)[2];
  V v_p_2415 = heff_env(self)[3];
  V v_s_240 = heff_env(self)[4];
  V v_d_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), v_n_2420, NTAG(TAG_Nil)});
    V v_v_2422 = (g_list_2efoldl_24s690313412x1307839513(v_t_2421, heff_dup(v_xs_242)));
    V v_m_2423 = heff_take_field(v_v_2422, 0);
    V v_n_2424 = heff_take_field(v_v_2422, 1);
    V v_xs_2425 = heff_get_n(v_v_2422, 2, 3);
    HeffT2 v_t_2426 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2423, v_n_2424, v_b_243));
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_field_2428 = v_t_2426.f[1];
      V v_b_27_2429 = v_field_2427;
      V v_n_27_2430 = v_field_2428;
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
      V v_x_2432 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2edestined_str1), heff_intShow(heff_dup(v_n_27_2430)));
      V v_n_2433 = heff_intAdd(v_n_27_2430, MK_INT(1LL));
      V v_x_2434 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2edestined_str2), heff_intShow(heff_dup(v_n_2433)));
      V v_t_2435 = heff_dup(heff_rfield(v_p_2415, 1));
      V v_t_2437;
      switch (heff_tag_of(v_t_2435)) {
      case TAG_Nothing: {
        v_t_2437 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2434)});
        break;
      }
      case TAG_Just: {
        V v_k_2436 = heff_field(v_t_2435, 0);
        V v_ru_24t_2435_24Just = heff_take_reuse_n(v_t_2435, 1ULL, 1);
        v_t_2437 = heff_tag_at_n(v_ru_24t_2435_24Just, TAG_EInt, 1, (V[]){v_k_2436});
        break;
      }
      default: heff_nomatch(v_t_2435);
      }
      V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2efill_clo), 4, (V[]){v_s_240, heff_dup(v_p_2415), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2432)}), v_t_2437}));
      V v_m_2439 = ({ V a_0 = v_t_2438; V a_1 = v_b_27_2429; V r_ = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(a_0, a_1)); heff_drop(v_t_2438); r_; });
      V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){heff_intAdd(v_n_2433, MK_INT(1LL))}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_n_2442 = heff_field(v_x2_2440, 1);
        V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
        V v_t_2443 = heff_take_field(v_p_2415, 1);
        V v_t_2446;
        switch (heff_tag_of(v_t_2443)) {
        case TAG_Nothing: {
          V v_t_2444 = heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
          v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2432, v_t_2444});
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2443, 0ULL, 1);
          heff_drop(v_x_2434);
          v_t_2446 = heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2443);
        }
        V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2446));
        V v_body_2448 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2447, v_x_2441});
        V v_t_2449 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 1)), ((V)&g_heff_2ecompile_2etrmc_2edestined_str3));
        V v_x_2450 = heff_rec_n(3, shape_key__name__body, (V[]){heff_get_n(v_p_2415, 0, 2), v_t_2449, v_body_2448});
        V v_t_2451 = ({ V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_x_2419}); V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2450, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2452}), v_n_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str0, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str1, 4, "acc$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str2, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str3, 4, "$acc");
HEFF_LIT(g_heff_2ecompile_2etrmc_2egathered_str4, 4, "$acc");
V g_heff_2ecompile_2etrmc_2egathered_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2egathered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2egathered_entry, 4, 0};

V g_heff_2ecompile_2etrmc_2egathered(V v_s_240, V v_d_241, V v_xs_242, V v_b_243) {
top: ;
  V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2etrmc_2egathered_str0));
  V v_m_245 = ({ V a_0 = v_s_240; V a_1 = v_t_244; V a_2 = heff_dup(v_b_243); V r_ = (g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  return heff_clo_n(g_heff_2ecompile_2etrmc_2egathered_lam0, 1, 5, (V[]){v_m_245, v_xs_242, v_b_243, v_d_241, v_s_240});
}
V g_heff_2ecompile_2etrmc_2egathered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2egathered(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2etrmc_2egathered_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  V v_b_243 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_s_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), v_n_249, NTAG(TAG_Nil)});
    V v_v_2411 = (g_list_2efoldl_24s690313412x1307839513(v_t_2410, heff_dup(v_xs_242)));
    V v_m_2412 = heff_take_field(v_v_2411, 0);
    V v_n_2413 = heff_take_field(v_v_2411, 1);
    V v_xs_2414 = heff_get_n(v_v_2411, 2, 3);
    HeffT2 v_t_2415 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2412, v_n_2413, v_b_243));
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_b_27_2418 = v_field_2416;
      V v_n_27_2419 = v_field_2417;
      V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
      V v_x_2421 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2egathered_str1), heff_intShow(heff_dup(v_n_27_2419)));
      V v_t_2422 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2etrmc_2egathered_str2));
      V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2egather_clo), 3, (V[]){v_s_240, v_t_2422, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2421)})}));
      V v_m_2424 = ({ V a_0 = v_t_2423; V a_1 = v_b_27_2418; V r_ = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(a_0, a_1)); heff_drop(v_t_2423); r_; });
      V v_x2_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){heff_intAdd(v_n_27_2419, MK_INT(1LL))}));
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_MkPair: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        V v_n_2427 = heff_field(v_x2_2425, 1);
        V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
        V v_t_2428 = heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_Cons, 2, (V[]){v_x_2421, NTAG(TAG_Nil)});
        V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2428));
        V v_body_2430 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2429, v_x_2426});
        V v_t_2431 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 0)), ((V)&g_heff_2ecompile_2etrmc_2egathered_str3));
        V v_t_2432 = heff_strAppend(heff_dup(heff_rfield(v_d_241, 1)), ((V)&g_heff_2ecompile_2etrmc_2egathered_str4));
        V v_x_2433 = heff_rec_n(3, shape_key__name__body, (V[]){v_t_2431, v_t_2432, v_body_2430});
        V v_t_2434 = ({ V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_x_248}); V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2433, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2435}), v_n_2427});
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam4(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_entry, 7, 0};

V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_s_245, V v_e_246) {
top: ;
  switch (heff_tag_of(v_e_246)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EGlobal: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_e_246, 0);
    V v_a_2414 = heff_field(v_e_246, 1);
    V v_b_2415 = heff_field(v_e_246, 2);
    heff_take_n(v_e_246, 7ULL, 3);
    V v_m_2416 = heff_tr(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_s_245, v_b_2415));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam0, 1, 3, (V[]){v_m_2416, v_x_2413, v_a_2414});
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EMatch: {
    V v_c_2430 = heff_field(v_e_246, 0);
    V v_arms_2431 = heff_field(v_e_246, 1);
    V v_ru_24e_246_24EMatch = heff_take_reuse_n(v_e_246, 3ULL, 2);
    HeffT2 v_t_2432 = (g_heff_2ecompile_2etrmc_2eprodCall_24cpr(heff_dup(v_s_245), v_c_2430, v_arms_2431));
    {
      V v_field_2434 = v_t_2432.f[1];
      int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
      if ((v_tag_2433 == ((int64_t)0ULL))) {
        V v_x11_2435 = v_field_2434;
        heff_drop(v_x11_2435);
        return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), heff_tag_re_n(v_ru_24e_246_24EMatch, TAG_EMatch, 2, 3ULL, (V[]){v_c_2430, v_arms_2431})));
      } else {
        heff_drop_cell(v_ru_24e_246_24EMatch, 2);
        heff_drop(v_field_2434);
        V v_m_2445 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam1, 1, 6, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), heff_dup(v_s_245)}), v_arms_2431));
        return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam3, 1, 2, (V[]){v_m_2445, v_c_2430});
      }
    }
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EBytes: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EBool: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_ESet: {
    V v_xs_2463 = heff_field(v_e_246, 0);
    V v_a_2464 = heff_field(v_e_246, 1);
    V v_b_2465 = heff_field(v_e_246, 2);
    heff_take_n(v_e_246, 7ULL, 3);
    V v_m_2466 = heff_tr(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_s_245, v_b_2465));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam4, 1, 3, (V[]){v_m_2466, v_xs_2463, v_a_2464});
  }
  case TAG_EValues: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2etrmc_2eprodFill(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_e_246));
  }
  default: return heff_nomatch(v_e_246);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927(a0, a1, a2, a3, a4, a5, a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam0(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_a_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2413, v_a_2414, v_x_2419}), v_n_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam2(V self, V *args) {
  V v_n_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_t_2437 = heff_env(self)[1];
  V v_vs_2438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_n_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2437, v_vs_2438, v_x_2443}), v_n_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam1(V self, V *args) {
  V v_x2_2436 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_s_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkArm: {
    V v_t_2437 = heff_field(v_x2_2436, 0);
    V v_vs_2438 = heff_field(v_x2_2436, 1);
    V v_b_2439 = heff_field(v_x2_2436, 2);
    heff_take_n(v_x2_2436, 7ULL, 3);
    heff_clo_take(self, 6);
    V v_m_2440 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_s_245; V a_6 = v_b_2439; V r_ = heff_tr(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); heff_drop(v_lit_243); heff_drop(v_lit_244); heff_drop(v_s_245); r_; });
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam2, 1, 3, (V[]){v_m_2440, v_t_2437, v_vs_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam3(V self, V *args) {
  V v_n_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_c_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_n_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_n_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_c_2430, v_x_2448}), v_n_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927_lam4(V self, V *args) {
  V v_n_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_xs_2463 = heff_env(self)[1];
  V v_a_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_n_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_n_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2463, v_a_2464, v_x_2469}), v_n_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_str0, 4, "$dps");
HEFF_LIT(g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_str1, 2, "d$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_str2, 2, "i$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_str3, 4, "$dps");
V g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_lam1(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_entry, 7, 0};

V g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344(V v_lit_240, V v_lit_241, V v_s_242, V v_d_243, V v_xs_244, V v_b_245, V v_j_246) {
top: ;
  V v_t_247 = ({ V a_0 = NTAG(TAG_EAbandon); V a_1 = heff_dup(v_j_246); V b_2 = heff_get_n(v_lit_240, 4, 6); V r_ = (g_heff_2ecompile_2etrmc_2enthOr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_248 = (g_heff_2ecompile_2etrmc_2echainHole(v_t_247));
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_lam0, 1, 1, (V[]){heff_dup(v_j_246)}), v_lit_241));
  V v_t_2412 = ({ V a_0 = v_t_248; V a_1 = v_t_2411; V r_ = (g_list_2eall_24s262401054x194288545(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
  } else {
    heff_drop(v_t_248);
    heff_drop(v_t_2412);
    v_t_2413 = NTAG(TAG_Nothing);
  }
  V v_t_2414 = heff_strAppend(heff_dup(heff_rfield(v_d_243, 0)), ((V)&g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_str0));
  V v_p_2415 = heff_rec_n(2, shape_key__at, (V[]){v_t_2414, v_t_2413});
  V v_m_2416 = (g_heff_2ecompile_2etrmc_2eprodTails_24s1057252282x14564327(v_s_242, v_p_2415, v_j_246, v_s_242, heff_dup(v_b_245)));
  return heff_clo_n(g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_lam1, 1, 7, (V[]){v_m_2416, v_xs_244, v_b_245, v_p_2415, heff_dup(v_s_242), v_j_246, v_d_243});
}
V g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_lam0(V self, V *args) {
  V v_q_249 = args[0];
  V v_j_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = ({ V a_0 = NTAG(TAG_EAbandon); V a_1 = v_j_246; V b_2 = heff_get_n(v_q_249, 4, 6); V r_ = (g_heff_2ecompile_2etrmc_2enthOr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return (g_heff_2ecompile_2etrmc_2echainHole(v_t_2410));
}
V g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_lam1(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  V v_b_245 = heff_env(self)[2];
  V v_p_2415 = heff_env(self)[3];
  V v_s_242 = heff_env(self)[4];
  V v_j_246 = heff_env(self)[5];
  V v_d_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), v_n_2420, NTAG(TAG_Nil)});
    V v_v_2422 = (g_list_2efoldl_24s690313412x1307839513(v_t_2421, heff_dup(v_xs_244)));
    V v_m_2423 = heff_take_field(v_v_2422, 0);
    V v_n_2424 = heff_take_field(v_v_2422, 1);
    V v_xs_2425 = heff_get_n(v_v_2422, 2, 3);
    HeffT2 v_t_2426 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2423, v_n_2424, v_b_245));
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_field_2428 = v_t_2426.f[1];
      V v_b_27_2429 = v_field_2427;
      V v_n_27_2430 = v_field_2428;
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
      V v_x_2432 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_str1), heff_intShow(heff_dup(v_n_27_2430)));
      V v_n_2433 = heff_intAdd(v_n_27_2430, MK_INT(1LL));
      V v_x_2434 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_str2), heff_intShow(heff_dup(v_n_2433)));
      V v_t_2435 = heff_dup(heff_rfield(v_p_2415, 1));
      V v_t_2437;
      switch (heff_tag_of(v_t_2435)) {
      case TAG_Nothing: {
        v_t_2437 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2434)});
        break;
      }
      case TAG_Just: {
        V v_k_2436 = heff_field(v_t_2435, 0);
        V v_ru_24t_2435_24Just = heff_take_reuse_n(v_t_2435, 1ULL, 1);
        v_t_2437 = heff_tag_at_n(v_ru_24t_2435_24Just, TAG_EInt, 1, (V[]){v_k_2436});
        break;
      }
      default: heff_nomatch(v_t_2435);
      }
      V v_m_2438 = ({ V a_0 = v_s_242; V a_1 = v_p_2415; V b_2 = heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2432)}); V a_3 = v_t_2437; V a_4 = v_j_246; V a_5 = v_s_242; V a_6 = v_b_27_2429; V r_ = heff_tr(g_heff_2ecompile_2etrmc_2eprodTails_24s465973528x1247286927(a_0, a_1, b_2, a_3, a_4, a_5, a_6)); heff_drop(b_2); heff_drop(v_t_2437); heff_drop(v_j_246); heff_drop(v_s_242); r_; });
      V v_x2_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){heff_intAdd(v_n_2433, MK_INT(1LL))}));
      switch (heff_tag_of(v_x2_2439)) {
      case TAG_MkPair: {
        V v_x_2440 = heff_field(v_x2_2439, 0);
        V v_n_2441 = heff_field(v_x2_2439, 1);
        V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
        V v_t_2442 = heff_take_field(v_p_2415, 1);
        V v_t_2445;
        switch (heff_tag_of(v_t_2442)) {
        case TAG_Nothing: {
          V v_t_2443 = heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
          v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2432, v_t_2443});
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2442, 0ULL, 1);
          heff_drop(v_x_2434);
          v_t_2445 = heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2442);
        }
        V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2445));
        V v_body_2447 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2446, v_x_2440});
        V v_t_2448 = heff_strAppend(heff_dup(heff_rfield(v_d_243, 1)), ((V)&g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344_str3));
        V v_x_2449 = heff_rec_n(3, shape_key__name__body, (V[]){heff_get_n(v_p_2415, 0, 2), v_t_2448, v_body_2447});
        V v_t_2450 = ({ V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_244, v_x_2419}); V rr_ = heff_rec_reuse_nf(v_d_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2449, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_t_2451}), v_n_2441});
      }
      default: return heff_nomatch(v_x2_2439);
      }
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2etrmc_2edefT_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2edefT_lam2(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2edefT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2edefT_entry, 1, 0};

V g_heff_2ecompile_2etrmc_2edefT(V v_d_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_d_240, 2));
  switch (heff_tag_of(v_t_241)) {
  case TAG_ELam: {
    V v_xs_242 = heff_field(v_t_241, 0);
    V v_b0_243 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_242));
    V v_s_245 = heff_rec_n(2, shape_key__arity, (V[]){heff_dup(heff_rfield(v_d_240, 0)), v_t_244});
    V v_b_246 = (g_heff_2ecompile_2etrmc_2eunbound(v_s_245, v_b0_243));
    V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2econsEnds_clo), 1, (V[]){heff_dup(v_s_245)}));
    V v_t_248 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b_246, NTAG(TAG_Nil)));
    V v_t_249 = ({ V a_0 = v_t_247; V a_1 = v_t_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_247); heff_drop(v_t_248); r_; });
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      return (g_heff_2ecompile_2etrmc_2edestined(v_s_245, v_d_240, v_xs_242, v_b_246));
    } else {
      heff_drop(v_t_249);
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2etrmc_2eappendEnds_clo), 1, (V[]){heff_dup(v_s_245)}));
      V v_t_2411 = (g_heff_2ecompile_2eir_2ewaysOnto(v_b_246, NTAG(TAG_Nil)));
      V v_t_2412 = ({ V a_0 = v_t_2410; V a_1 = v_t_2411; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2410); heff_drop(v_t_2411); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        return (g_heff_2ecompile_2etrmc_2egathered(v_s_245, v_d_240, v_xs_242, v_b_246));
      } else {
        heff_drop(v_t_2412);
        V v_s_2413 = heff_dup(v_s_245);
        V v_b_2414 = heff_dup(v_b_246);
        V v_ways_2415 = (g_heff_2ecompile_2etrmc_2eprodWays(v_s_2413, v_b_2414));
        V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ways_2415)));
        V v_prods_2424 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam0, 2, 1, (V[]){heff_dup(v_s_2413)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2416; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2416); r_; });
        V v_x5_2428;
        switch (heff_tag_of(v_prods_2424)) {
        case TAG_Nil: {
          heff_drop(v_s_2413);
          heff_drop(v_ways_2415);
          v_x5_2428 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_q_2425 = heff_dup(heff_field(v_prods_2424, 0));
          V v_t_2427 = ({ V a_0 = v_s_2413; V a_1 = v_q_2425; V a_2 = v_ways_2415; V r_ = (g_list_2eall_24s2006536460x193465515(a_0, a_1, a_2)); heff_drop(v_s_2413); heff_drop(v_q_2425); heff_drop(v_ways_2415); r_; });
          if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
            heff_drop(v_t_2427);
            v_x5_2428 = v_prods_2424;
          } else {
            heff_drop_tag(v_prods_2424, 2);
            heff_drop(v_t_2427);
            v_x5_2428 = NTAG(TAG_Nil);
          }
          break;
        }
        default: heff_nomatch(v_prods_2424);
        }
        switch (heff_tag_of(v_x5_2428)) {
        case TAG_Nil: {
          heff_drop(v_xs_242);
          heff_drop_rec(v_s_245, 2);
          heff_drop(v_b_246);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam1, 1, 1, (V[]){v_d_240});
        }
        case TAG_Cons: {
          V v_q_2431 = heff_field(v_x5_2428, 0);
          V v_rest_2432 = heff_field(v_x5_2428, 1);
          heff_take_n(v_x5_2428, 3ULL, 2);
          return ({ V a_0 = heff_dup(v_q_2431); V a_1 = v_rest_2432; V a_2 = v_s_245; V a_3 = v_d_240; V a_4 = v_xs_242; V a_5 = v_b_246; V a_6 = heff_get_n(v_q_2431, 1, 6); V r_ = (g_heff_2ecompile_2etrmc_2eproducted_24s201663420x6809344(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_rec(v_s_245, 2); r_; });
        }
        default: return heff_nomatch(v_x5_2428);
        }
      }
    }
  }
  default: {
    heff_drop(v_t_241);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2edefT_lam2, 1, 1, (V[]){v_d_240});
  }
  }
}
V g_heff_2ecompile_2etrmc_2edefT_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2edefT(a[0]);
}
V g_heff_2ecompile_2etrmc_2edefT_lam0(V self, V *args) {
  V v_acc_2417 = args[0];
  V v_x_2418 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = ({ V a_0 = v_s_2413; V a_1 = v_x_2418; HeffT2 r_ = (g_heff_2ecompile_2etrmc_2eprodOf_24cpr(a_0, a_1)); heff_drop(v_x_2418); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    V v_t_2423;
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2422 = v_field_2421;
      v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_field_2421);
      v_t_2423 = NTAG(TAG_Nil);
    }
    return (g_prelude_2e_2b_2b(v_t_2423, v_acc_2417));
  }
}
V g_heff_2ecompile_2etrmc_2edefT_lam1(V self, V *args) {
  V v_n_2429 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_n_2429});
}
V g_heff_2ecompile_2etrmc_2edefT_lam2(V self, V *args) {
  V v_n_2433 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_n_2433});
}