// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define LBL_end 310101
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2epatValue_23mutual_24s1010356602x802557410_24cpr(V);
V g_heff_2esyntax_2epresyntax_2erightTupleP(V, V);
V g_heff_2esyntax_2epresyntax_2erightTupleP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erightTupleP_clo;
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_clo;
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_clo;
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_get(void);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1023238561x651750209(V, V, V);
V g_list_2efoldl_24f1023238561x651750209_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1023238561x651750209_clo;
V g_list_2efoldl_24s57109758x1528051153(V, V);
V g_list_2efoldl_24s57109758x1528051153_entry(V self, V *a);
extern Clo g_list_2efoldl_24s57109758x1528051153_clo;
V g_list_2emap_24s1508885855x632034084(V);
V g_list_2emap_24s1508885855x632034084_entry(V self, V *a);
extern Clo g_list_2emap_24s1508885855x632034084_clo;
V g_list_2emap_24s2104241550x137541639(V);
V g_list_2emap_24s2104241550x137541639_entry(V self, V *a);
extern Clo g_list_2emap_24s2104241550x137541639_clo;

static V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_st;
static V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_init(void) {
  return ((V)&g_list_2emap_24s2104241550x137541639_clo);
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_st)) return g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_val, &g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_st, g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epats_240_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str1, 5, "False");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str2, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str3, 4, "Cons");
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam0(V self, V *args);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam1(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(V v_sp_240, V v_bs_241, V v_has_242) {
top: ;
  V v_t_243 = (g_list_2emap_24s2104241550x137541639(v_bs_241));
  V v_t_244 = (g_list_2emap_24s1508885855x632034084(v_t_243));
  V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam0, 1, 2, (V[]){v_has_242, heff_dup(v_sp_240)}); V a_2 = v_t_244; V r_ = (g_list_2efoldl_24f1023238561x651750209(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str2)}), heff_dup(v_sp_240)});
  return ({ V b_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam1, 2, 1, (V[]){v_sp_240}); V a_1 = v_t_2410; V a_2 = v_t_249; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_249); r_; });
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam0(V self, V *args) {
  V v_vs_245 = args[0];
  V v_has_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_has_242, 1, (V[]){v_vs_245}));
  V v_t_247;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_247 = ((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str0);
  } else {
    heff_drop(v_t_246);
    v_t_247 = ((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str1);
  }
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){v_t_247}), v_sp_240});
  return (g_heff_2esyntax_2epresyntax_2eboolOf(v_t_248));
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_lam1(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2eflags_242_str3)}), v_sp_240});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_acc_2411, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_t_2414})));
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str4, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str5, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str6, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str7, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str8, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str9, 104, "a pattern a `with` binds whose names are set is one its value is built back from: names, tuples and tags");
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243(V v_sp_240, V v_body_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_p_242)) {
  case TAG_At: {
    V v_p1_243 = heff_field(v_p_242, 0);
    V v_psp_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24At = heff_take_reuse_n(v_p_242, 3ULL, 2);
    switch (heff_tag_of(v_p1_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_p1_243, 0);
      V v_ru_24p1_243_24PatVar = heff_take_reuse_n(v_p1_243, 1ULL, 1);
      heff_drop(v_sp_240);
      heff_drop(v_body_241);
      return heff_tag_re_n(v_ru_24p_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24p1_243_24PatVar, TAG_EVar, 1, (V[]){v_x_245}), v_psp_244});
    }
    case TAG_PatTag: {
      heff_take_n(v_p1_243, 0ULL, 3);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str0)}), v_sp_240});
    }
    case TAG_PatOp: {
      heff_take_n(v_p1_243, 0ULL, 3);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str1)}), v_sp_240});
    }
    case TAG_PatInt: {
      V v_ru_24p1_243_24PatInt = heff_take_reuse_n(v_p1_243, 0ULL, 1);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24p1_243_24PatInt, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str2)}), v_sp_240});
    }
    case TAG_PatFloat: {
      V v_ru_24p1_243_24PatFloat = heff_take_reuse_n(v_p1_243, 0ULL, 1);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24p1_243_24PatFloat, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str3)}), v_sp_240});
    }
    case TAG_PatString: {
      V v_ru_24p1_243_24PatString = heff_take_reuse_n(v_p1_243, 0ULL, 1);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24p1_243_24PatString, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str4)}), v_sp_240});
    }
    case TAG_PatBinary: {
      V v_ru_24p1_243_24PatBinary = heff_take_reuse_n(v_p1_243, 0ULL, 1);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24p1_243_24PatBinary, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str5)}), v_sp_240});
    }
    case TAG_PatRune: {
      V v_ru_24p1_243_24PatRune = heff_take_reuse_n(v_p1_243, 0ULL, 1);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24p1_243_24PatRune, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str6)}), v_sp_240});
    }
    case TAG_PatRecord: {
      V v_ru_24p1_243_24PatRecord = heff_take_reuse_n(v_p1_243, 0ULL, 1);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24p1_243_24PatRecord, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str7)}), v_sp_240});
    }
    case TAG_PatWord: {
      V v_ru_24p1_243_24PatWord = heff_take_reuse_n(v_p1_243, 0ULL, 1);
      heff_drop(v_body_241);
      heff_drop(v_psp_244);
      return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24p1_243_24PatWord, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str8)}), v_sp_240});
    }
    case TAG_PatAs: {
      V v_whole_2419 = heff_field(v_p1_243, 0);
      V v_wsp_2420 = heff_field(v_p1_243, 1);
      V v_q_2421 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 7ULL, 3);
      heff_drop(v_sp_240);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_q_2421)));
      V v_t_2425 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_lam0, 1, 1, (V[]){v_body_241}); V a_1 = v_t_2422; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2422); r_; });
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop(v_whole_2419);
        heff_drop(v_wsp_2420);
        heff_drop(v_t_2425);
        V v_d_2426 = heff_tag_re_n(v_ru_24p_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_str9)}), v_psp_244});
        HeffT2 v_t_2427 = (g_heff_2esyntax_2epresyntax_2epatValue_23mutual_24s1010356602x802557410_24cpr(v_q_2421));
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            heff_drop_tag(v_d_2426, 2);
            V v_x_2430 = v_field_2429;
            return v_x_2430;
          } else {
            heff_drop(v_field_2429);
            return v_d_2426;
          }
        }
      } else {
        heff_drop(v_psp_244);
        heff_drop(v_q_2421);
        heff_drop(v_t_2425);
        return heff_tag_at_n(v_ru_24p_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_whole_2419}), v_wsp_2420});
      }
    }
    default: return heff_nomatch(v_p1_243);
    }
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2egiven_243_lam0(V self, V *args) {
  V v_x_2423 = args[0];
  V v_body_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2424 = (g_list_2efoldl_24s57109758x1528051153(NTAG(TAG_Nil), v_body_241));
  return ({ V a_0 = v_x_2423; V a_1 = v_xs_2424; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_x_2423); heff_drop(v_xs_2424); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str0, 6, "bound#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str1, 6, "bound#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str2, 6, "bound#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str3, 6, "bound#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str4, 6, "bound#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str5, 6, "bound#");
Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244(V v_sp_240, V v_bs_241, V v_inner_242) {
top: ;
  V v_it_243 = (g_list_2emap_24s2104241550x137541639(v_bs_241));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nil: {
    V v_p_244 = (g_heff_2esyntax_2epresyntax_2erightTupleP(v_sp_240, v_it_243));
    V v_t_247;
    switch (heff_tag_of(v_p_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_p_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_p_244);
    }
    V v_t_2410;
    switch (heff_tag_of(v_inner_242)) {
    case TAG_At: {
      V v_s_249 = heff_dup(heff_field(v_inner_242, 1));
      v_t_2410 = v_s_249;
      break;
    }
    default: heff_nomatch(v_inner_242);
    }
    V v_t_2411 = ({ V rv_1 = heff_get_n(v_t_2410, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_247, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_inner_242}), v_t_2411});
    V v_alts_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
    V v_t_2414 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
    V v_t_2415 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str0), v_t_2414), heff_dup(v_sp_240)});
    V v_t_2416 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
    V v_t_2417 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str1), v_t_2416)});
    V v_t_2418 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2417, heff_dup(v_sp_240)}), v_alts_2413});
    V v_t_2419 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2415, heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_Cons: {
    V v_it1_2420 = heff_dup(heff_field(v_it_243, 0));
    V v_it2_2421 = heff_dup(heff_field(v_it_243, 1));
    switch (heff_tag_of(v_it1_2420)) {
    case TAG_At: {
      V v_it11_2422 = heff_field(v_it1_2420, 0);
      V v_xsp_2423 = heff_field(v_it1_2420, 1);
      V v_ru_24it1_2420_24At = heff_take_reuse_n(v_it1_2420, 3ULL, 2);
      switch (heff_tag_of(v_it11_2422)) {
      case TAG_PatVar: {
        V v_x_2424 = heff_field(v_it11_2422, 0);
        V v_ru_24it11_2422_24PatVar = heff_take_reuse_n(v_it11_2422, 1ULL, 1);
        switch (heff_tag_of(v_it2_2421)) {
        case TAG_Nil: {
          heff_drop_tag(v_it_243, 2);
          heff_drop_cell(v_ru_24it11_2422_24PatVar, 1);
          V v_t_2425 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_2424, v_xsp_2423}), v_inner_242});
          return heff_tag_at_n(v_ru_24it1_2420_24At, TAG_At, 2, (V[]){v_t_2425, v_sp_240});
        }
        case TAG_Cons: {
          V v_ru_24it2_2421_24Cons = heff_take_reuse_n(v_it2_2421, 0ULL, 2);
          heff_drop(v_xsp_2423);
          heff_drop(v_x_2424);
          V v_p_2428 = (g_heff_2esyntax_2epresyntax_2erightTupleP(v_sp_240, v_it_243));
          V v_t_2431;
          switch (heff_tag_of(v_p_2428)) {
          case TAG_At: {
            V v_s_2430 = heff_dup(heff_field(v_p_2428, 1));
            v_t_2431 = v_s_2430;
            break;
          }
          default: heff_nomatch(v_p_2428);
          }
          V v_t_2434;
          switch (heff_tag_of(v_inner_242)) {
          case TAG_At: {
            V v_s_2433 = heff_dup(heff_field(v_inner_242, 1));
            v_t_2434 = v_s_2433;
            break;
          }
          default: heff_nomatch(v_inner_242);
          }
          V v_t_2435 = ({ V rv_1 = heff_get_n(v_t_2434, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2431, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2436 = heff_tag_at_n(v_ru_24it1_2420_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2428, v_inner_242}), v_t_2435});
          V v_alts_2437 = heff_tag_at_n(v_ru_24it2_2421_24Cons, TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
          V v_t_2438 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
          V v_t_2439 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str2), v_t_2438), heff_dup(v_sp_240)});
          V v_t_2440 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
          V v_t_2441 = heff_tag_at_n(v_ru_24it11_2422_24PatVar, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str3), v_t_2440)});
          V v_t_2442 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_240)}), v_alts_2437});
          V v_t_2443 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2439, heff_tag_n(TAG_At, 2, (V[]){v_t_2442, heff_dup(v_sp_240)})});
          return heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_sp_240});
        }
        default: return heff_nomatch(v_it2_2421);
        }
      }
      default: {
        heff_drop(v_it2_2421);
        heff_drop(v_it11_2422);
        heff_drop(v_xsp_2423);
        V v_p_2444 = (g_heff_2esyntax_2epresyntax_2erightTupleP(v_sp_240, v_it_243));
        V v_t_2447;
        switch (heff_tag_of(v_p_2444)) {
        case TAG_At: {
          V v_s_2446 = heff_dup(heff_field(v_p_2444, 1));
          v_t_2447 = v_s_2446;
          break;
        }
        default: heff_nomatch(v_p_2444);
        }
        V v_t_2450;
        switch (heff_tag_of(v_inner_242)) {
        case TAG_At: {
          V v_s_2449 = heff_dup(heff_field(v_inner_242, 1));
          v_t_2450 = v_s_2449;
          break;
        }
        default: heff_nomatch(v_inner_242);
        }
        V v_t_2451 = ({ V rv_1 = heff_get_n(v_t_2450, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2447, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2452 = heff_tag_at_n(v_ru_24it1_2420_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2444, v_inner_242}), v_t_2451});
        V v_alts_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
        V v_t_2454 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
        V v_t_2455 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str4), v_t_2454), heff_dup(v_sp_240)});
        V v_t_2456 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
        V v_t_2457 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_str5), v_t_2456)});
        V v_t_2458 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2457, heff_dup(v_sp_240)}), v_alts_2453});
        V v_t_2459 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2455, heff_tag_n(TAG_At, 2, (V[]){v_t_2458, heff_dup(v_sp_240)})});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2459, v_sp_240});
      }
      }
    }
    default: return heff_nomatch(v_it1_2420);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewithBoundOf_2epatsLam_244(a[0], a[1], a[2]);
}