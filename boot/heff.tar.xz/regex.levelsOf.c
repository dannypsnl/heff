// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_regex_2elevelsOf_2ecut_240(V, V, V, V, V, V);
V g_regex_2elevelsOf_2ecut_240_entry(V self, V *a);
extern Clo g_regex_2elevelsOf_2ecut_240_clo;
Clo g_regex_2elevelsOf_2ecut_240_clo = {{0x80000000u, K_CLO, 0}, g_regex_2elevelsOf_2ecut_240_entry, 6, 0};

V g_regex_2elevelsOf_2ecut_240(V v_s_240, V v_from_241, V v_box_24i_242, V v_inClass_243, V v_depth_244, V v_acc_245) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_242)) {
    heff_drop(v_inClass_243);
    heff_drop(v_depth_244);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_from_241, heff_box_word(v_i_242), 6), NTAG(TAG_Nil)});
    return (g_list_2efoldl_24s1370882877x364361272(v_t_246, v_acc_245));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2)) == ((int64_t)92ULL))) {
      V t_0 = v_s_240;
      V t_1 = v_from_241;
      int64_t t_2 = (v_i_242 + ((int64_t)2ULL));
      V t_3 = v_inClass_243;
      V t_4 = v_depth_244;
      V t_5 = v_acc_245;
      v_s_240 = t_0;
      v_from_241 = t_1;
      v_i_242 = t_2;
      v_inClass_243 = t_3;
      v_depth_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      if ((heff_dup(v_inClass_243) == NTAG(TAG_True))) {
        heff_drop(v_inClass_243);
        V v_t_247 = heff_bool(!(heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2)) == ((int64_t)93ULL)));
        V t_0 = v_s_240;
        V t_1 = v_from_241;
        int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
        V t_3 = v_t_247;
        V t_4 = v_depth_244;
        V t_5 = v_acc_245;
        v_s_240 = t_0;
        v_from_241 = t_1;
        v_i_242 = t_2;
        v_inClass_243 = t_3;
        v_depth_244 = t_4;
        v_acc_245 = t_5;
        goto top;
      } else {
        heff_drop(v_inClass_243);
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2)) == ((int64_t)91ULL))) {
          V t_0 = v_s_240;
          V t_1 = v_from_241;
          int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
          V t_3 = NTAG(TAG_True);
          V t_4 = v_depth_244;
          V t_5 = v_acc_245;
          v_s_240 = t_0;
          v_from_241 = t_1;
          v_i_242 = t_2;
          v_inClass_243 = t_3;
          v_depth_244 = t_4;
          v_acc_245 = t_5;
          goto top;
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2)) == ((int64_t)40ULL))) {
            V t_0 = v_s_240;
            V t_1 = v_from_241;
            int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
            V t_3 = NTAG(TAG_False);
            V t_4 = heff_intAdd(v_depth_244, MK_INT(1LL));
            V t_5 = v_acc_245;
            v_s_240 = t_0;
            v_from_241 = t_1;
            v_i_242 = t_2;
            v_inClass_243 = t_3;
            v_depth_244 = t_4;
            v_acc_245 = t_5;
            goto top;
          } else {
            if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2)) == ((int64_t)41ULL))) {
              V t_0 = v_s_240;
              V t_1 = v_from_241;
              int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
              V t_3 = NTAG(TAG_False);
              V t_4 = heff_intSub(v_depth_244, MK_INT(1LL));
              V t_5 = v_acc_245;
              v_s_240 = t_0;
              v_from_241 = t_1;
              v_i_242 = t_2;
              v_inClass_243 = t_3;
              v_depth_244 = t_4;
              v_acc_245 = t_5;
              goto top;
            } else {
              if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2)) == ((int64_t)47ULL)) && heff_intEq_c_lent(v_depth_244, MK_INT(0LL), 2))) {
                V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_from_241, heff_box_word(v_i_242), 6), v_acc_245});
                V t_0 = v_s_240;
                V t_1 = heff_box_word((v_i_242 + ((int64_t)1ULL)));
                int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
                V t_3 = NTAG(TAG_False);
                V t_4 = v_depth_244;
                V t_5 = v_t_248;
                v_s_240 = t_0;
                v_from_241 = t_1;
                v_i_242 = t_2;
                v_inClass_243 = t_3;
                v_depth_244 = t_4;
                v_acc_245 = t_5;
                goto top;
              } else {
                V t_0 = v_s_240;
                V t_1 = v_from_241;
                int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
                V t_3 = NTAG(TAG_False);
                V t_4 = v_depth_244;
                V t_5 = v_acc_245;
                v_s_240 = t_0;
                v_from_241 = t_1;
                v_i_242 = t_2;
                v_inClass_243 = t_3;
                v_depth_244 = t_4;
                v_acc_245 = t_5;
                goto top;
              }
            }
          }
        }
      }
    }
  }
}
V g_regex_2elevelsOf_2ecut_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_regex_2elevelsOf_2ecut_240(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}