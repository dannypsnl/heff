// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Windows 49101
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_str3, 1, ".");
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam2, 2, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam3(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam3, 1, 0};
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0(V v_hd_240, V v_p_241, V v_rest_242, V v_acc_243, V v_k_244, V v_top_245, V v_x_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s535099379x685970669(v_t_2413, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam1, 1, 7, (V[]){v_x_246, v_p_241, v_rest_242, v_acc_243, v_hd_240, v_k_244, heff_dup(v_top_245)})));
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam3(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_2435 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Left: {
    heff_take_n(v_x_2441, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2435;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2443 = heff_field(v_x_2441, 0);
    heff_take_n(v_x_2441, 1ULL, 1);
    switch (heff_tag_of(v_y_2443)) {
    case TAG_Left: {
      heff_take_n(v_y_2443, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2435;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2443, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2435;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2443);
    }
  }
  default: return heff_nomatch(v_x_2441);
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam4(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_a_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2433})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2440, v_hd_2434, heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam5, 1, 1, (V[]){v_k_2435})));
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam7(V self, V *args) {
  V v_n_2450 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2415), v_p_241));
  V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2415), v_n_2450));
  V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
  V v_t_2454 = ({ V a_0 = v_st_2415; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2453); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_t_2454});
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_rest_242 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_y_2421 = heff_env(self)[4];
  V v_st_2415 = heff_env(self)[5];
  V v_p_241 = heff_env(self)[6];
  if ((heff_dup(v_x_2447) == NTAG(TAG_True))) {
    heff_drop(v_x_2447);
    heff_clo_take(self, 7);
    heff_drop(v_y_2421);
    heff_drop(v_st_2415);
    heff_drop(v_p_241);
    V v_t_2448 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_rest_242, v_acc_243));
    V f_ = v_t_2448;
    heff_room[0] = v_hd_240;
    heff_room[1] = v_k_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2447);
    heff_clo_take(self, 7);
    V v_t_2449 = (g_list_2ekeepIf_24s122741325x871243494(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_str3), v_y_2421));
    V v_t_2455 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_242, heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam7, 1, 2, (V[]){v_st_2415, v_p_241}), v_t_2449));
    V v_t_2456 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_t_2455, v_acc_243));
    V f_ = v_t_2456;
    heff_room[0] = v_hd_240;
    heff_room[1] = v_k_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_hd_240 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_top_245 = heff_env(self)[6];
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    heff_take_n(v_x_246, 0ULL, 1);
    heff_drop(v_top_245);
    heff_drop(v_st_2415);
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_241, 0)) - ((int64_t)3ULL));
    V v_t_2418 = heff_strSlice_lent(v_p_241, heff_box_word(v_t_2417), heff_strLength_lent(v_p_241, 0), 6);
    if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_str1))) {
      V v_t_2419 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_rest_242, heff_tag_n(TAG_Cons, 2, (V[]){v_p_241, v_acc_243})));
      V f_ = v_t_2419;
      heff_room[0] = v_hd_240;
      heff_room[1] = v_k_244;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_241);
      V v_t_2420 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_rest_242, v_acc_243));
      V f_ = v_t_2420;
      heff_room[0] = v_hd_240;
      heff_room[1] = v_k_244;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    V v_c_2446;
    if ((heff_dup(v_top_245) == NTAG(TAG_True))) {
      heff_drop(v_top_245);
      v_c_2446 = ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam2_clo);
    } else {
      heff_drop(v_top_245);
      V v_st_2424 = heff_dup(v_st_2415);
      V v_d_2425 = heff_dup(v_p_241);
      V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_2424), v_d_2425));
      V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2424), ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_str2)));
      V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
      V v_s_2429 = ({ V a_0 = v_st_2424; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); heff_drop(v_t_2428); r_; });
      V v_path_2430 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2429));
      V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2430; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2430); r_; });
      V v_a_2433 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2431, ((V)&g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam3_clo)});
      v_c_2446 = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam4, 2, 1, (V[]){v_a_2433});
    }
    V f_ = v_c_2446;
    heff_room[0] = heff_dup(v_hd_240);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_2ek_24l0_lam6, 1, 7, (V[]){v_rest_242, v_acc_243, v_hd_240, v_k_244, v_y_2421, v_st_2415, v_p_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_246);
  }
}