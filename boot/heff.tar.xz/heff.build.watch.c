// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_PathStatus 29154
#define TAG_Right 62770
#define TAG_Sleep 25229
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_clo;
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_clo;
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str1, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ewatch_2eproject_str2, 3, "app");
HEFF_TAG_LIT(g_heff_2ebuild_2ewatch_2eproject_lit3, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ewatch_2eproject_str2), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2ebuild_2ewatch_2eproject_lit4, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ewatch_2eproject_str1), ((V)&g_heff_2ebuild_2ewatch_2eproject_lit3));
HEFF_TAG_LIT(g_heff_2ebuild_2ewatch_2eproject_lit5, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ewatch_2eproject_str0), ((V)&g_heff_2ebuild_2ewatch_2eproject_lit4));

static V g_heff_2ebuild_2ewatch_2eproject_val;
static HEFF_ONCE g_heff_2ebuild_2ewatch_2eproject_st;
static V g_heff_2ebuild_2ewatch_2eproject_init(void) {
  return ((V)&g_heff_2ebuild_2ewatch_2eproject_lit5);
}
V g_heff_2ebuild_2ewatch_2eproject_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ewatch_2eproject_st)) return g_heff_2ebuild_2ewatch_2eproject_val;
  return heff_global(&g_heff_2ebuild_2ewatch_2eproject_val, &g_heff_2ebuild_2ewatch_2eproject_st, g_heff_2ebuild_2ewatch_2eproject_init);
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_lam0(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_lam0, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_lam1(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_entry, 5, 0};

V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850(V v_st_240, V v_acc_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_245)));
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
    V v_a_2410 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_248, NTAG(TAG_True), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_lam0_clo)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2415, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_lam1, 1, 6, (V[]){v_st_240, v_acc_241, heff_dup(v_rest_246), v_z_243, v_z_244, heff_dup(v_p_245)})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_x_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    heff_clo_take(self, 6);
    return (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(v_st_240, v_acc_241, v_rest_246, v_z_243, v_z_244, v_p_245, heff_tag_re_n(v_ru_24x_2416_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2417})));
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2418)) {
    case TAG_Left: {
      V v_err_2419 = heff_field(v_y_2418, 0);
      V v_ru_24y_2418_24Left = heff_take_reuse_n(v_y_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2416_24Right, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(v_st_240, v_acc_241, v_rest_246, v_z_243, v_z_244, v_p_245, heff_tag_re_n(v_ru_24y_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2419})));
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_y_2418, 0);
      heff_take_n(v_y_2418, 1ULL, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(v_st_240, v_acc_241, v_rest_246, v_z_243, v_z_244, v_p_245, heff_tag_at_n(v_ru_24x_2416_24Right, TAG_Right, 1, (V[]){v_x_2420})));
    }
    default: return heff_nomatch(v_y_2418);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_str1, 1, "\012");
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam2(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam1(V self, V *args);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam0(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_entry, 8, 0};

V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384(V v_clock_240, V v_st_241, V v_paths_242, V v_changed_243, V v_stamp_244, V v_now_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_248 = heff_tag_n(TAG_Sleep, 2, (V[]){heff_box_word((((int64_t)250999999ULL) / ((int64_t)1000000ULL))), NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(v_clock_240), 1, (V[]){v_t_248}));
  return (g_co_2eop_24s535099379x685970669(v_t_249, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam0, 1, 8, (V[]){v_st_241, heff_dup(v_paths_242), v_z_246, heff_dup(v_stamp_244), v_clock_240, v_changed_243, v_now_245, heff_dup(v_z_247)})));
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V a7 = a[7]; V r = g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384(a[0], a[1], a2, a[3], a4, a[5], a[6], a7); heff_drop(a2); heff_drop(a4); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_clock_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_paths_242 = heff_env(self)[2];
  V v_changed_243 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_clock_240; V a_1 = v_st_241; V a_2 = v_paths_242; V a_3 = v_changed_243; V a_4 = v_x_2414; V a_5 = v_x_2416; V a_6 = v_z_246; V a_7 = v_z_247; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_paths_242); heff_drop(v_x_2414); heff_drop(v_z_247); r_; });
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_stamp_244 = heff_env(self)[0];
  V v_clock_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_paths_242 = heff_env(self)[3];
  V v_changed_243 = heff_env(self)[4];
  V v_now_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  V v_x_2414;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nil: {
    v_x_2414 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x_2411, 0);
    V v_xs_2413 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 3ULL, 2);
    v_x_2414 = ({ V a_0 = ((V)&g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  if (heff_strEq_c_lent(v_x_2414, v_stamp_244, 0)) {
    heff_drop(v_x_2414);
    heff_clo_take(self, 8);
    return ({ V a_0 = v_clock_240; V a_1 = v_st_241; V a_2 = v_paths_242; V a_3 = v_changed_243; V a_4 = v_stamp_244; V a_5 = v_now_245; V a_6 = v_z_246; V a_7 = v_z_247; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_paths_242); heff_drop(v_stamp_244); heff_drop(v_z_247); r_; });
  } else {
    heff_clo_take(self, 8);
    heff_drop(v_stamp_244);
    V v_c_2415 = heff_tr(heff_call(heff_dup(v_changed_243), 1, (V[]){v_now_245}));
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_z_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam2, 1, 7, (V[]){v_clock_240, v_st_241, v_paths_242, v_changed_243, v_x_2414, v_z_246, v_z_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_paths_242 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_stamp_244 = heff_env(self)[3];
  V v_clock_240 = heff_env(self)[4];
  V v_changed_243 = heff_env(self)[5];
  V v_now_245 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  heff_drop(v_x_2410);
  heff_clo_take(self, 8);
  return ({ V a_0 = heff_dup(v_st_241); V a_1 = NTAG(TAG_Nil); V a_2 = v_paths_242; V a_3 = heff_dup(v_z_246); V a_4 = heff_clo_n(g_heff_2ebuild_2ewatch_2ewatchOver_24s1474070873x1868975384_lam1, 1, 8, (V[]){v_stamp_244, v_clock_240, v_st_241, heff_dup(v_paths_242), v_changed_243, v_now_245, v_z_246, v_z_247}); V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_paths_242); r_; });
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_lam0(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_lam0, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_lam1(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_entry, 6, 0};

V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(V v_tok_240, V v_st_241, V v_acc_242, V v_x3_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_st_241);
    heff_drop(v_z_244);
    return heff_tail(v_z_245, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_p_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_246)));
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_249, NTAG(TAG_True), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_lam0_clo)});
    V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2416, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_lam1, 1, 6, (V[]){v_st_241, v_acc_242, heff_dup(v_rest_247), v_z_244, v_z_245, heff_dup(v_p_246)})));
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_x_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    heff_clo_take(self, 6);
    return (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(v_st_241, v_acc_242, v_rest_247, v_z_244, v_z_245, v_p_246, heff_tag_re_n(v_ru_24x_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2418})));
  }
  case TAG_Right: {
    V v_y_2419 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    switch (heff_tag_of(v_y_2419)) {
    case TAG_Left: {
      V v_err_2420 = heff_field(v_y_2419, 0);
      V v_ru_24y_2419_24Left = heff_take_reuse_n(v_y_2419, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2417_24Right, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(v_st_241, v_acc_242, v_rest_247, v_z_244, v_z_245, v_p_246, heff_tag_re_n(v_ru_24y_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2420})));
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_y_2419, 0);
      heff_take_n(v_y_2419, 1ULL, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(v_st_241, v_acc_242, v_rest_247, v_z_244, v_z_245, v_p_246, heff_tag_at_n(v_ru_24x_2417_24Right, TAG_Right, 1, (V[]){v_x_2421})));
    }
    default: return heff_nomatch(v_y_2419);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}