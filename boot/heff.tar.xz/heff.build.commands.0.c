// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_build 295453320
#define LBL_cmt 308164
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_from 9647217
#define LBL_fuel 9649789
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_i 323
#define LBL_key 315609
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_outPath 1272254166
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_shipTo 1043811586
#define LBL_ships 310766033
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_start 311115900
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_watches 1357821955
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_paths__hashes__modules__fuel[] = {LBL_paths, LBL_hashes, LBL_modules, LBL_fuel};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486(V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_clo;
V g_heff_2ebuild_2ecommands_2elinkOf(V);
V g_heff_2ebuild_2ecommands_2elinkOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkOf_clo;
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674(V, V, V);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_clo;
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907(V, V, V);
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594(V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_clo;
V g_heff_2ebuild_2ecommands_2eruntimeOf(V, V, V);
V g_heff_2ebuild_2ecommands_2eruntimeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eruntimeOf_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_clo;
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eproject_2ebuildOf(V);
V g_heff_2ebuild_2eproject_2ebuildOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ebuildOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s130813166x1111413304(V, V);
V g_list_2eany_24s130813166x1111413304_entry(V self, V *a);
extern Clo g_list_2eany_24s130813166x1111413304_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eascending_24s1013929174x440984754(V, V, V, V, V);
V g_list_2eascending_24s1013929174x440984754_entry(V self, V *a);
extern Clo g_list_2eascending_24s1013929174x440984754_clo;
V g_list_2edescending_24s1467056061x388427999(V, V, V, V, V);
V g_list_2edescending_24s1467056061x388427999_entry(V self, V *a);
extern Clo g_list_2edescending_24s1467056061x388427999_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1442652634x1828296957(V, V);
V g_list_2efoldl_24s1442652634x1828296957_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1442652634x1828296957_clo;
V g_list_2efoldl_24s370525507x1787909101(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s370525507x1787909101_entry(V self, V *a);
extern Clo g_list_2efoldl_24s370525507x1787909101_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1181715076x1618420649(V, V, V, V, V, V);
V g_list_2ekeepIf_24s1181715076x1618420649_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1181715076x1618420649_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s107931167x1978109134(V);
V g_list_2emap_24s107931167x1978109134_entry(V self, V *a);
extern Clo g_list_2emap_24s107931167x1978109134_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s810789954x1170958779(V, V, V, V);
V g_list_2emergeRuns_24s810789954x1170958779_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s810789954x1170958779_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_242, v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2ecommands_2enubStrGo_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, heff_dup(v_seen_240)}), v_rest_243, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enubStrGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebacksOf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebacksOf(V v_id_240, V v_ps_241) {
top: ;
  return ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebacksOf_lam0, 2, 1, (V[]){heff_dup(v_id_240)}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ps_241; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
}
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ebacksOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ebacksOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_p_243 = args[1];
  V v_id_240 = heff_env(self)[0];
  V v_t_246;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_dup(heff_field(v_p_243, 0));
    v_t_246 = v_x_244;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_text_249;
  switch (heff_tag_of(v_p_243)) {
  case TAG_MkPair: {
    V v_y_248 = heff_field(v_p_243, 1);
    heff_take_n(v_p_243, 2ULL, 2);
    v_text_249 = v_y_248;
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  heff_clo_take(self, 1);
  HeffT3 v_t_2410 = ({ V a_0 = v_id_240; V a_1 = heff_dup(v_text_249); V a_2 = MK_INT(0LL); HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2ebackD_24cpr(a_0, a_1, a_2)); heff_drop(v_id_240); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    V v_field_2413 = v_t_2410.f[2];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_t_2416;
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2412;
      V v_j_2415 = v_field_2413;
      if (heff_intLe_c(heff_strLength(v_text_249), v_j_2415)) {
        v_t_2416 = v_x_2414;
      } else {
        heff_drop(v_x_2414);
        v_t_2416 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
      }
    } else {
      heff_drop(v_text_249);
      heff_drop(v_field_2412);
      heff_drop(v_field_2413);
      v_t_2416 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
    return ({ V a_0 = v_m_242; V a_1 = v_t_246; V a_2 = v_t_2416; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_246); heff_drop(v_t_2416); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268(V v_lit_240, V v_lit_241, V v_who_242, V v_st_243, V v_p_244, V v_dir_245, V v_out_246, V v_next_247) {
top: ;
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_245)));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam1, 2, 10, (V[]){v_a_2411, v_st_243, v_dir_245, v_p_244, v_lit_241, v_out_246, v_next_247, v_who_242, v_lit_240, v_path_248});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam3(V self, V *args) {
  V v_n_2424 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2424));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_248, v_t_2425));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  V v_path_248 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 11);
    heff_drop(v_path_248);
    return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1(v_st_243, v_dir_245, v_p_244, v_hd_2412, v_lit_241, v_out_246, v_next_247, v_k_2413, v_who_242, v_lit_240, heff_tag_re_n(v_ru_24x_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2420})));
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      V v_err_2422 = heff_field(v_y_2421, 0);
      V v_ru_24y_2421_24Left = heff_take_reuse_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 11);
      heff_drop(v_path_248);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1(v_st_243, v_dir_245, v_p_244, v_hd_2412, v_lit_241, v_out_246, v_next_247, v_k_2413, v_who_242, v_lit_240, heff_tag_re_n(v_ru_24y_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2422})));
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 11);
      V v_x_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam3, 1, 1, (V[]){v_path_248}), v_x_2423));
      V v_x_2427 = (g_list_2emap_24s219049803x1458391381(v_x_2426));
      return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_2ek_24l1(v_st_243, v_dir_245, v_p_244, v_hd_2412, v_lit_241, v_out_246, v_next_247, v_k_2413, v_who_242, v_lit_240, heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_x_2427})));
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  V v_st_243 = heff_env(self)[1];
  V v_dir_245 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_who_242 = heff_env(self)[7];
  V v_lit_240 = heff_env(self)[8];
  V v_path_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_lam2, 1, 11, (V[]){v_st_243, v_dir_245, v_p_244, v_hd_2412, v_lit_241, v_out_246, v_next_247, v_k_2413, v_who_242, v_lit_240, v_path_248})));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476(V v_ps_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam1(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    heff_clo_take(self, 3);
    return (g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0(v_k_242, v_ps_240, v_hd_241, heff_tag_re_n(v_ru_24x_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2414})));
  }
  case TAG_Right: {
    V v_y_2415 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    switch (heff_tag_of(v_y_2415)) {
    case TAG_Left: {
      V v_err_2416 = heff_field(v_y_2415, 0);
      V v_ru_24y_2415_24Left = heff_take_reuse_n(v_y_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2413_24Right, 1);
      heff_clo_take(self, 3);
      return (g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0(v_k_242, v_ps_240, v_hd_241, heff_tag_re_n(v_ru_24y_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2416})));
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_y_2415, 0);
      heff_take_n(v_y_2415, 1ULL, 1);
      heff_clo_take(self, 3);
      return (g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0(v_k_242, v_ps_240, v_hd_241, heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Right, 1, (V[]){v_x_2417})));
    }
    default: return heff_nomatch(v_y_2415);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_243));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam1_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2412, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_lam2, 1, 3, (V[]){v_k_242, v_ps_240, v_hd_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s535099379x685970669(v_t_2413, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam1, 1, 6, (V[]){v_n_245, heff_dup(v_parts_241), v_dir_240, v_p_243, v_rest_246, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam3(V self, V *args) {
  V v_r_2425 = args[0];
  return v_r_2425;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2428 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    heff_take_n(v_x_2434, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2428;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2436 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 1);
    switch (heff_tag_of(v_y_2436)) {
    case TAG_Left: {
      heff_take_n(v_y_2436, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2428;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2436, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2428;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2436);
    }
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_a_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2433, v_hd_2427, heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam5, 1, 1, (V[]){v_k_2428})));
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_drop(v_x_2440);
  heff_clo_take(self, 5);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  V v_t_2416 = (g_list_2eany_24s130813166x1111413304(v_n_245, v_parts_241));
  V v_c_2439;
  heff_clo_take(self, 6);
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_n_245);
    heff_drop(v_st_2415);
    heff_drop(v_t_2416);
    v_c_2439 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam2_clo);
  } else {
    heff_drop(v_t_2416);
    V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2415), heff_dup(v_dir_240)));
    V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2415), v_n_245));
    V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
    V v_s_2422 = ({ V a_0 = v_st_2415; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2421); r_; });
    V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
    V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
    V v_a_2426 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam3_clo)});
    v_c_2439 = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam4, 2, 1, (V[]){v_a_2426});
  }
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_lam6, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950(V v_path_240, V v_text_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_240));
    V v_t_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_245; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_245); r_; });
    V v_a_248 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_246, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam0_clo)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2413, v_z_243, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam1, 1, 1, (V[]){v_z_244})));
  }
  case TAG_Just: {
    V v_was_2419 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_was_2419, v_text_241, 1)) {
      heff_drop(v_path_240);
      heff_drop(v_text_241);
      heff_drop(v_z_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_True)});
    } else {
      V v_path_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_240));
      V v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2420; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2420); r_; });
      V v_a_2423 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2421, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam2_clo)});
      V v_t_2424 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2428, v_z_243, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam3, 1, 1, (V[]){v_z_244})));
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_244 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_z_244;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2416 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    switch (heff_tag_of(v_y_2416)) {
    case TAG_Left: {
      heff_take_n(v_y_2416, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2416, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2416);
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam2(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s2110870025x1505409950_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_244 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_z_244;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    switch (heff_tag_of(v_y_2431)) {
    case TAG_Left: {
      heff_take_n(v_y_2431, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2431, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2431);
    }
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674(V v_outPath_240, V v_flags_241, V v_done_242) {
top: ;
  switch (heff_tag_of(v_flags_241)) {
  case TAG_Nil: {
    V v_s_243 = (g_heff_2ebuild_2ecommands_2elinkOf(v_outPath_240));
    V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_243));
    V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
    V v_a_247 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam0_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam1, 2, 2, (V[]){v_a_247, v_done_242});
  }
  case TAG_Cons: {
    V v_s_2422 = (g_heff_2ebuild_2ecommands_2elinkOf(heff_dup(v_outPath_240)));
    V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
    V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
    V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam3_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam4, 2, 4, (V[]){v_a_2426, v_outPath_240, v_flags_241, v_done_242});
  }
  default: return heff_nomatch(v_flags_241);
  }
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    heff_take_n(v_x_2415, 0ULL, 1);
    heff_clo_take(self, 3);
    V f_ = v_done_242;
    heff_room[0] = v_hd_248;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      heff_take_n(v_y_2417, 0ULL, 1);
      heff_clo_take(self, 3);
      V f_ = v_done_242;
      heff_room[0] = v_hd_248;
      heff_room[1] = v_k_249;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Right: {
      heff_take_n(v_y_2417, 0ULL, 1);
      heff_clo_take(self, 3);
      V f_ = v_done_242;
      heff_room[0] = v_hd_248;
      heff_room[1] = v_k_249;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_a_247 = heff_env(self)[0];
  V v_done_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam2, 1, 3, (V[]){v_done_242, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam3(V self, V *args) {
  V v_r_2425 = args[0];
  return v_r_2425;
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_outPath_240 = heff_env(self)[0];
  V v_flags_241 = heff_env(self)[1];
  V v_hd_2427 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  V v_k_2428 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    V v_x_2435 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Left = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    heff_clo_take(self, 5);
    return ({ V a_0 = v_outPath_240; V a_1 = v_flags_241; V a_2 = v_hd_2427; V a_3 = v_done_242; V a_4 = v_k_2428; V a_5 = heff_tag_re_n(v_ru_24x_2434_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2435}); V r_ = (g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_tag(v_flags_241, 2); r_; });
  }
  case TAG_Right: {
    V v_y_2436 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Right = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    switch (heff_tag_of(v_y_2436)) {
    case TAG_Left: {
      V v_err_2437 = heff_field(v_y_2436, 0);
      V v_ru_24y_2436_24Left = heff_take_reuse_n(v_y_2436, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2434_24Right, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_outPath_240; V a_1 = v_flags_241; V a_2 = v_hd_2427; V a_3 = v_done_242; V a_4 = v_k_2428; V a_5 = heff_tag_re_n(v_ru_24y_2436_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2437}); V r_ = (g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_tag(v_flags_241, 2); r_; });
    }
    case TAG_Right: {
      V v_x_2438 = heff_field(v_y_2436, 0);
      heff_take_n(v_y_2436, 1ULL, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_outPath_240; V a_1 = v_flags_241; V a_2 = v_hd_2427; V a_3 = v_done_242; V a_4 = v_k_2428; V a_5 = heff_tag_at_n(v_ru_24x_2434_24Right, TAG_Right, 1, (V[]){v_x_2438}); V r_ = (g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_tag(v_flags_241, 2); r_; });
    }
    default: return heff_nomatch(v_y_2436);
    }
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_a_2426 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_flags_241 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2433, heff_dup(v_hd_2427), heff_clo_n(g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_lam5, 1, 5, (V[]){v_outPath_240, v_flags_241, v_hd_2427, v_done_242, v_k_2428})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str5, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_rt_244, V v_failed_245, V v_done_246, V v_c_247, V v_available_248, V v_z_249, V v_z_2410) {
top: ;
  V v_t_2411 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_247)));
  V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2411); r_; });
  V v_t_2413 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2412));
  V v_t_2415 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_lam0, 1, 1, (V[]){heff_dup(v_available_248)}); V a_1 = v_t_2413; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(v_t_2415, heff_dup(v_c_247), v_name_242));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      heff_drop_rec(v_bi_240, 4);
      heff_drop(v_outPath_243);
      heff_drop_rec(v_rt_244, 4);
      heff_drop(v_done_246);
      heff_drop_rec(v_c_247, 14);
      heff_drop(v_available_248);
      V v_why_2419 = v_field_2418;
      V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str0), heff_dup(v_file_241)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str1));
      V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, heff_dup(v_why_2419)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str2));
      V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2421, NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_lam1, 1, 5, (V[]){v_file_241, v_failed_245, v_why_2419, v_z_249, v_z_2410})));
    } else {
      heff_drop(v_file_241);
      heff_drop(v_failed_245);
      V v_r_2430 = v_field_2418;
      int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
      V v_t_2432 = heff_strSlice_lent(v_outPath_243, heff_box_word(v_t_2431), heff_strLength_lent(v_outPath_243, 0), 6);
      if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str5))) {
        int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(v_bi_240, heff_strSlice(v_outPath_243, MK_INT(0LL), heff_box_word(v_t_2433)), v_rt_244, v_done_246, v_c_247, v_available_248, v_r_2430, v_z_249, v_z_2410));
      } else {
        V v_t_2434 = (g_heff_2ebuild_2ecommands_2eruntimeOf(heff_rfield(v_bi_240, 3), v_available_248, heff_dup(v_rt_244)));
        V v_t_2435 = heff_get_n(heff_get_n(v_c_247, 5, 14), 0, 10);
        V v_t_2436 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_get_n(v_bi_240, 3, 4), v_t_2434, v_available_248, v_t_2435, heff_take_field(v_r_2430, 0), heff_get_n(v_r_2430, 1, 2)));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(v_outPath_243, heff_get_n(v_rt_244, 1, 4), v_done_246, v_t_2436, v_z_249, v_z_2410));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_lam0(V self, V *args) {
  V v_k_2414 = args[0];
  V v_available_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_248; V a_1 = v_k_2414; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_248); heff_drop(v_k_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2419 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_drop(v_x_2428);
  heff_clo_take(self, 5);
  V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str3), v_file_241), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_str4));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2429, v_why_2419);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str3, 19, ": it does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str4, 19, ": it does not check");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228(V v_fuel_240, V v_failed_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam0, 1, 9, (V[]){v_l_242, v_hd_247, v_fuel_240, v_file_245, v_failed_241, v_k_248, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  V v_sources_2414 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = ({ V a_0 = v_c_2416; V a_1 = v_sources_2414; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2414); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2419;
      V v_t_2421 = ({ V a_0 = v_x_2415; V a_1 = v_s_2420; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2415); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2416, v_t_2421));
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_field_2419);
      return v_c_2416;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_cs_2423 = heff_env(self)[1];
  V v_file_245 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_done_2412 = heff_env(self)[6];
  V v_l_242 = heff_env(self)[7];
  V v_hashes_2413 = heff_env(self)[8];
  V v_fuel_240 = heff_env(self)[9];
  V v_name_243 = heff_env(self)[10];
  V v_outPath_244 = heff_env(self)[11];
  V v_done_246 = heff_env(self)[12];
  heff_drop(v_x_2424);
  heff_clo_take(self, 13);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop(v_done_2412);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_hashes_2413);
    heff_drop(v_fuel_240);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    HeffT2 v_t_2425 = ({ V a_0 = v_cs_2423; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_cs_2423); r_; });
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      V v_t_2429;
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        heff_drop(v_file_245);
        V v_x_2428 = v_field_2427;
        v_t_2429 = v_x_2428;
      } else {
        heff_drop(v_field_2427);
        v_t_2429 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str3));
      }
      V f_ = v_failed_241;
      heff_room[0] = v_t_2429;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  } else {
    V v_t_2430 = (g_list_2eany_24s1740858080x874135214(v_cs_2423));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_done_2412);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_hashes_2413);
      heff_drop(v_fuel_240);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2430);
      HeffT2 v_t_2431 = ({ V a_0 = v_cs_2423; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_cs_2423); r_; });
      {
        V v_field_2433 = v_t_2431.f[1];
        int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
        V v_t_2435;
        if ((v_tag_2432 == ((int64_t)0ULL))) {
          heff_drop(v_file_245);
          V v_x_2434 = v_field_2433;
          v_t_2435 = v_x_2434;
        } else {
          heff_drop(v_field_2433);
          v_t_2435 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str4));
        }
        V f_ = v_failed_241;
        heff_room[0] = v_t_2435;
        heff_room[1] = v_hd_247;
        heff_room[2] = v_k_248;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
    } else {
      heff_drop(v_t_2430);
      V v_t_2436 = (g_list_2emap_24s1698496827x1884878103(v_done_2412));
      V v_t_2437 = heff_rec_n(4, shape_paths__hashes__modules__fuel, (V[]){heff_take_field(v_l_242, 2), v_hashes_2413, v_t_2436, v_fuel_240});
      return ({ V a_0 = v_t_2437; V a_1 = heff_get_n(v_l_242, 0, 5); V a_2 = v_file_245; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_failed_241; V a_6 = v_done_246; V a_7 = v_cs_2423; V a_8 = v_hd_247; V a_9 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_cs_2423); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_fuel_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_file_245 = heff_env(self)[4];
  V v_failed_241 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  V v_done_2412 = heff_take_field(v_x_2411, 0);
  V v_hashes_2413 = heff_get_n(v_x_2411, 1, 2);
  V v_sources_2414 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2415 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_str2), heff_dup(v_sources_2414)));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam2, 1, 2, (V[]){v_sources_2414, v_x_2415}), heff_dup(v_done_2412)));
  V v_cs_2423;
  if ((heff_dup(v_fuel_240) == NTAG(TAG_True))) {
    v_cs_2423 = v_x_2422;
  } else {
    v_cs_2423 = (g_list_2emap_24s107931167x1978109134(v_x_2422));
  }
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2423), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam3, 1, 13, (V[]){v_x_249, v_cs_2423, v_file_245, v_failed_241, v_hd_247, v_k_248, v_done_2412, v_l_242, v_hashes_2413, v_fuel_240, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_fuel_240 = heff_env(self)[2];
  V v_file_245 = heff_env(self)[3];
  V v_failed_241 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  V v_t_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_l_242)));
  heff_clo_take(self, 9);
  V f_ = v_t_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_lam1, 1, 10, (V[]){v_l_242, v_fuel_240, v_hd_247, v_x_249, v_file_245, v_failed_241, v_k_248, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str0, 5, "-- | ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str4, 27, "heff promote: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str6, 27, "heff promote: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363(V v_file_240, V v_badL_241, V v_cs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_242), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam0, 1, 5, (V[]){v_cs_242, heff_dup(v_badL_241), v_hd_243, v_k_244, v_file_240})));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam1(V self, V *args) {
  V v_r_2444 = args[0];
  return v_r_2444;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam3(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2460);
  V v_t_2461 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam4(V self, V *args) {
  V v_x_2476 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2476);
  V v_t_2477 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam2(V self, V *args) {
  V v_x_2451 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2451)) {
  case TAG_Left: {
    V v_ru_24x_2451_24Left = heff_take_reuse_n(v_x_2451, 0ULL, 1);
    heff_clo_take(self, 3);
    V v_t_2453 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str4), v_file_240), ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str5));
    V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2453, NTAG(TAG_MkUnit)});
    V v_t_2455 = heff_tag_at_n(v_ru_24x_2451_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam3, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
  case TAG_Right: {
    V v_y_2467 = heff_field(v_x_2451, 0);
    V v_ru_24x_2451_24Right = heff_take_reuse_n(v_x_2451, 1ULL, 1);
    switch (heff_tag_of(v_y_2467)) {
    case TAG_Left: {
      V v_ru_24y_2467_24Left = heff_take_reuse_n(v_y_2467, 0ULL, 1);
      heff_clo_take(self, 3);
      V v_t_2469 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str6), v_file_240), ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str7));
      V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2469, NTAG(TAG_MkUnit)});
      V v_t_2471 = heff_tag_at_n(v_ru_24x_2451_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2467_24Left, TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam4, 1, 2, (V[]){v_hd_243, v_k_244})));
    }
    case TAG_Right: {
      heff_take_n(v_y_2467, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_file_240);
      heff_drop(v_hd_243);
      heff_drop_cell(v_ru_24x_2451_24Right, 1);
      V f_ = v_k_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2467);
    }
  }
  default: return heff_nomatch(v_x_2451);
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_badL_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_file_240 = heff_env(self)[4];
  heff_drop(v_x_245);
  HeffT2 v_t_246 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_242));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_248;
      if ((heff_dup(v_badL_241) == NTAG(TAG_True))) {
        heff_clo_take(self, 5);
        heff_drop(v_cs_242);
        heff_drop(v_badL_241);
        heff_drop(v_file_240);
        heff_drop(v_c_249);
        V v_t_2410 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
        V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
        V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
        V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
        V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), v_hd_243, v_k_244));
      } else {
        heff_clo_take(self, 5);
        heff_drop(v_badL_241);
        V v_t_2416 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_242); r_; });
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_file_240);
          heff_drop(v_c_249);
          heff_drop(v_t_2416);
          V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
          V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
          V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
          V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
          V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
          V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
          return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_hd_243, v_k_244));
        } else {
          heff_drop(v_t_2416);
          V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_file_240)));
          V v_c_2424 = v_c_249;
          V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_c_2424, 5)), 4, 10);
          V v_x2_2426 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2424), v_t_2425));
          V v_t_2441;
          switch (heff_tag_of(v_x2_2426)) {
          case TAG_Nil: {
            v_t_2441 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_x_2427 = heff_field(v_x2_2426, 0);
            V v_xs_2428 = heff_field(v_x2_2426, 1);
            V v_ru_24x2_2426_24Cons = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
            V v_lit_2429 = MK_INT(0LL);
            V v_lit_2430 = MK_INT(0LL);
            V v_x_2431 = v_x_2427;
            V v_x3_2432 = v_xs_2428;
            V v_t_2440;
            switch (heff_tag_of(v_x3_2432)) {
            case TAG_Nil: {
              heff_drop(v_lit_2429);
              heff_drop(v_lit_2430);
              V v_t_2433 = heff_tag_at_n(v_ru_24x2_2426_24Cons, TAG_Cons, 2, (V[]){v_x_2431, NTAG(TAG_Nil)});
              v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
              break;
            }
            case TAG_Cons: {
              V v_y_2434 = heff_field(v_x3_2432, 0);
              V v_ys_2435 = heff_field(v_x3_2432, 1);
              V v_ru_24x3_2432_24Cons = heff_take_reuse_n(v_x3_2432, 3ULL, 2);
              V v_t_2436 = heff_intSub(heff_dup(v_lit_2429), heff_dup(heff_rfield(v_x_2431, 0)));
              V v_t_2437 = heff_intSub(heff_dup(v_lit_2430), heff_dup(heff_rfield(v_y_2434, 0)));
              if (heff_intLe_c(v_t_2436, v_t_2437)) {
                V v_t_2438 = heff_tag_at_n(v_ru_24x2_2426_24Cons, TAG_Cons, 2, (V[]){v_x_2431, NTAG(TAG_Nil)});
                v_t_2440 = ({ V a_0 = v_lit_2429; V a_1 = v_lit_2430; V a_2 = heff_dup(v_y_2434); V a_3 = heff_tag_re_n(v_ru_24x3_2432_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2434, v_t_2438}); V a_4 = v_ys_2435; V r_ = (g_list_2eascending_24s1013929174x440984754(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_2429); heff_drop(v_lit_2430); r_; });
              } else {
                V v_t_2439 = heff_tag_at_n(v_ru_24x2_2426_24Cons, TAG_Cons, 2, (V[]){v_x_2431, NTAG(TAG_Nil)});
                v_t_2440 = ({ V a_0 = v_lit_2429; V a_1 = v_lit_2430; V a_2 = heff_dup(v_y_2434); V a_3 = heff_tag_re_n(v_ru_24x3_2432_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2434, v_t_2439}); V a_4 = v_ys_2435; V r_ = (g_list_2edescending_24s1467056061x388427999(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_2429); heff_drop(v_lit_2430); r_; });
              }
              break;
            }
            default: heff_nomatch(v_x3_2432);
            }
            v_t_2441 = (g_list_2emergeRuns_24s810789954x1170958779(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2440));
            break;
          }
          default: heff_nomatch(v_x2_2426);
          }
          V v_text_2442 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str1); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str2); V a_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_str3); V a_5 = MK_INT(0LL); V a_6 = heff_get_n(v_c_2424, 3, 14); V a_7 = v_t_2441; V r_ = (g_list_2efoldl_24s370525507x1787909101(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2441); r_; });
          V v_t_2443 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
          V v_a_2445 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2443, v_text_2442, ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam1_clo)});
          V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2445})});
          V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
          V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
          V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
          V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
          return (g_co_2eop_24s1896221640x2141527803(v_t_2450, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1876735443x1372775363_lam2, 1, 3, (V[]){v_file_240, v_hd_243, v_k_244})));
        }
      }
    } else {
      heff_clo_take(self, 5);
      heff_drop(v_cs_242);
      heff_drop(v_badL_241);
      heff_drop(v_file_240);
      heff_drop(v_field_248);
      V v_t_2484 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
      V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2489}), v_hd_243, v_k_244));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str4, 1, ".");
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907(V v_o_240, V v_p_241, V v_p_242) {
top: ;
  V v_backend_243 = heff_take_field(v_o_240, 3);
  V v_outPath_244 = heff_get_n(v_o_240, 1, 5);
  V v_t_248;
  if (heff_strEq_c(v_backend_243, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str0))) {
    V v_s_245 = heff_dup(v_outPath_244);
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_s_245, 0)) - ((int64_t)1ULL));
    V v_t_247 = heff_strSlice(heff_dup(v_s_245), heff_box_word(v_t_246), heff_strLength(v_s_245));
    v_t_248 = heff_bool(heff_strEq_c_lent(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str1), 2));
    heff_drop(v_t_247);
  } else {
    v_t_248 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_p_241);
    heff_drop(v_outPath_244);
    heff_drop(v_t_248);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nothing)});
  } else {
    heff_drop(v_t_248);
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam0_clo)})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    HEFF_LAST return g_co_2eop_24s535099379x685970669(v_t_2415, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam1, 1, 3, (V[]){v_outPath_244, v_p_241, v_p_242}));
  }
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam0(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam2(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam4(V self, V *args) {
  V v_n_2444 = args[0];
  V v_path_2430 = heff_env(self)[0];
  V v_t_2445 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2444));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_2430, v_t_2445));
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam3(V self, V *args) {
  V v_x_2439 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_path_2430 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Left: {
    heff_take_n(v_x_2439, 0ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_path_2430);
    V f_ = v_p_242;
    args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2429});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2441 = heff_field(v_x_2439, 0);
    heff_take_n(v_x_2439, 1ULL, 1);
    switch (heff_tag_of(v_y_2441)) {
    case TAG_Left: {
      heff_take_n(v_y_2441, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_path_2430);
      V f_ = v_p_242;
      args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2429});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2443 = heff_field(v_y_2441, 0);
      heff_take_n(v_y_2441, 1ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_x_2429);
      V v_x_2446 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam4, 1, 1, (V[]){v_path_2430}), v_x_2443));
      V v_x_2447 = (g_list_2emap_24s219049803x1458391381(v_x_2446));
      heff_drop(v_x_2447);
      V f_ = v_p_242;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2441);
    }
  }
  default: return heff_nomatch(v_x_2439);
  }
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_outPath_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_st_2417;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str2))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 3);
  HeffT3 v_t_2418 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2417), v_outPath_244));
  {
    V v_field_2419 = v_t_2418.f[0];
    V v_field_2420 = v_t_2418.f[1];
    V v_field_2421 = v_t_2418.f[2];
    V v_d_2422 = v_field_2419;
    V v_a_2423 = v_field_2420;
    V v_xs_2424 = v_field_2421;
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    V v_xs_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2425; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2426));
    V v_t_2428 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2422, v_a_2423, v_t_2427});
    V v_x_2429 = ({ V a_0 = v_st_2417; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop_tag(v_t_2428, 3); r_; });
    V v_path_2430;
    if (heff_strEq_c_lent(v_x_2429, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str3), 2)) {
      v_path_2430 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_str4)));
    } else {
      v_path_2430 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2429)));
    }
    V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2430; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_2433 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam2_clo)});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2438, v_p_241, heff_clo_n(g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_lam3, 1, 3, (V[]){v_p_242, v_x_2429, v_path_2430})));
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str6, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str7, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_246));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_c_2412 = v_field_2411;
      V v_t_2413 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2412)));
      V v_t_2414 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2413); r_; });
      V v_t_2415 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2414));
      V v_xs_2416 = (g_list_2emap_24s89148281x951607804(((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str2), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str3), v_t_2415));
      V v_t_2417 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2416));
      V v_c_2418 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296(v_sources_241, v_t_2417));
      return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_lam0, 1, 8, (V[]){v_bi_240, v_file_242, heff_dup(v_name_243), v_outPath_244, v_done_245, v_c_2412, v_z_247, v_z_248})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_field_2411);
      V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str7), NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_lam1, 1, 2, (V[]){v_z_247, v_z_248})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740(a[0], a[1], a[2], a3, a[4], a[5], a6, a[7], a[8]); heff_drop(a3); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2412 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  V v_t_2420 = (g_list_2ekeepIf_24s1181715076x1618420649(((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str4), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str5), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_str6), v_x_2419));
  heff_clo_take(self, 8);
  return ({ V a_0 = v_bi_240; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2412; V a_6 = v_t_2420; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_name_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s906248424x472870740_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486(V v_checkOnly_240, V v_x2_241, V v_bad_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_checkOnly_240);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam0, 2, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_checkOnly_247 = heff_dup(v_checkOnly_240);
    V v_f_248 = v_f_245;
    V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_248)));
    V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_249); r_; });
    V v_a_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam1_clo)});
    V v_c_2425 = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam2, 2, 3, (V[]){v_a_2412, v_f_248, v_checkOnly_247});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam4, 2, 4, (V[]){v_c_2425, v_checkOnly_240, v_rest_246, v_bad_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_bad_242 = heff_env(self)[0];
  heff_drop(v_hd_243);
  heff_clo_take(self, 1);
  V f_ = v_k_244;
  args[0] = v_bad_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam1(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_248 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  V v_checkOnly_247 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_f_248; V a_1 = v_hd_2413; V a_2 = v_k_2414; V a_3 = v_checkOnly_247; V a_4 = heff_tag_re_n(v_ru_24x_2420_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2421}); V r_ = (g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_247); r_; });
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Right = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    switch (heff_tag_of(v_y_2422)) {
    case TAG_Left: {
      V v_err_2423 = heff_field(v_y_2422, 0);
      V v_ru_24y_2422_24Left = heff_take_reuse_n(v_y_2422, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2420_24Right, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_f_248; V a_1 = v_hd_2413; V a_2 = v_k_2414; V a_3 = v_checkOnly_247; V a_4 = heff_tag_re_n(v_ru_24y_2422_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2423}); V r_ = (g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_247); r_; });
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_y_2422, 0);
      heff_take_n(v_y_2422, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_f_248; V a_1 = v_hd_2413; V a_2 = v_k_2414; V a_3 = v_checkOnly_247; V a_4 = heff_tag_at_n(v_ru_24x_2420_24Right, TAG_Right, 1, (V[]){v_x_2424}); V r_ = (g_heff_2ebuild_2ecommands_2efmtOne_24s1903285653x754393443_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_247); r_; });
    }
    default: return heff_nomatch(v_y_2422);
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_a_2412 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_checkOnly_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2419, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam3, 1, 4, (V[]){v_f_248, v_hd_2413, v_k_2414, v_checkOnly_247})));
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_hd_2426 = heff_env(self)[3];
  V v_k_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2429 = (g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486(v_checkOnly_240, v_rest_246, heff_intAdd(v_bad_242, v_x_2428)));
  V f_ = v_t_2429;
  heff_room[0] = v_hd_2426;
  heff_room[1] = v_k_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_checkOnly_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_bad_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1008721653x1468252486_lam5, 1, 5, (V[]){v_checkOnly_240, v_rest_246, v_bad_242, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(V v_st_240, V v_t_241, V v_bp_242, V v_done_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    return heff_dup(v_done_243);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_name_247 = heff_dup(heff_rfield(v_a_245, 0));
    V v_build_248 = heff_dup(heff_rfield(v_a_245, 1));
    V v_t_249 = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(v_st_240, v_t_241, v_bp_242, v_done_243, v_rest_246));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_clo), 6, (V[]){heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_bp_242), v_name_247, v_build_248, v_t_249});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(a0, a1, a2, a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    return heff_dup(v_next_244);
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_t_248 = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529(v_st_240, v_t_241, v_home_242, v_sh_243, v_next_244, v_rest_247));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_clo), 6, (V[]){heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_home_242), heff_dup(v_sh_243), v_t_248, heff_dup(v_n_246)});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529(a0, a1, a2, a3, a4, a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str2, 17, "building programs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str3, 17, "building programs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str4, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751(V v_st_240, V v_t_241, V v_progs_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str0)));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str1)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_p_248 = ({ V a_0 = v_st_240; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_248));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  V v_s_2412 = ({ V a_0 = v_st_240; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
  V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2413; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2413); r_; });
  V v_a_2416 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam0_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2421, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam1, 1, 5, (V[]){v_progs_242, v_z_243, v_st_240, v_t_241, v_z_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam0(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam2(V self, V *args) {
  V v_t_2425 = args[0];
  return v_t_2425;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_next_2430 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_drop(v_x_2435);
  heff_clo_take(self, 3);
  V f_ = v_next_2430;
  heff_room[0] = v_hd_2431;
  heff_room[1] = v_k_2432;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_x_2428 = heff_env(self)[0];
  V v_next_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_tag_n(TAG_End, 2, (V[]){v_x_2428, NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam5, 1, 3, (V[]){v_next_2430, v_hd_2431, v_k_2432})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_t_2429 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768(v_st_240, v_t_241, heff_dup(v_progs_242), heff_dup(heff_rfield(v_t_241, 4))));
  V v_next_2430 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(v_st_240, heff_dup(v_t_241), v_t_2429, v_progs_242));
  heff_clo_take(self, 5);
  V v_t_2436 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2428; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam4, 2, 2, (V[]){heff_dup(v_x_2428), v_next_2430}); V a_4 = v_progs_242; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2428); heff_drop(b_3); heff_drop(v_progs_242); r_; });
  V f_ = v_t_2436;
  heff_room[0] = v_z_243;
  heff_room[1] = v_z_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam6(V self, V *args) {
  V v_t_2440 = args[0];
  return v_t_2440;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam9(V self, V *args) {
  V v_x_2450 = args[0];
  V v_next_2445 = heff_env(self)[0];
  V v_hd_2446 = heff_env(self)[1];
  V v_k_2447 = heff_env(self)[2];
  heff_drop(v_x_2450);
  heff_clo_take(self, 3);
  V f_ = v_next_2445;
  heff_room[0] = v_hd_2446;
  heff_room[1] = v_k_2447;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam8(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_x_2443 = heff_env(self)[0];
  V v_next_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_tag_n(TAG_End, 2, (V[]){v_x_2443, NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), heff_dup(v_hd_2446), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam9, 1, 3, (V[]){v_next_2445, v_hd_2446, v_k_2447})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_t_2444 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768(v_st_240, v_t_241, heff_dup(v_progs_242), heff_dup(heff_rfield(v_t_241, 4))));
  V v_next_2445 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(v_st_240, heff_dup(v_t_241), v_t_2444, v_progs_242));
  heff_clo_take(self, 5);
  V v_t_2451 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2443; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam8, 2, 2, (V[]){heff_dup(v_x_2443), v_next_2445}); V a_4 = v_progs_242; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2443); heff_drop(b_3); heff_drop(v_progs_242); r_; });
  V f_ = v_t_2451;
  heff_room[0] = v_z_243;
  heff_room[1] = v_z_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam10(V self, V *args) {
  V v_t_2454 = args[0];
  return v_t_2454;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam13(V self, V *args) {
  V v_x_2464 = args[0];
  V v_next_2459 = heff_env(self)[0];
  V v_hd_2460 = heff_env(self)[1];
  V v_k_2461 = heff_env(self)[2];
  heff_drop(v_x_2464);
  heff_clo_take(self, 3);
  V f_ = v_next_2459;
  heff_room[0] = v_hd_2460;
  heff_room[1] = v_k_2461;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam12(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_x_2457 = heff_env(self)[0];
  V v_next_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_tag_n(TAG_End, 2, (V[]){v_x_2457, NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), heff_dup(v_hd_2460), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam13, 1, 3, (V[]){v_next_2459, v_hd_2460, v_k_2461})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam11(V self, V *args) {
  V v_x_2457 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_t_2458 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768(v_st_240, v_t_241, heff_dup(v_progs_242), heff_dup(heff_rfield(v_t_241, 4))));
  V v_next_2459 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(v_st_240, heff_dup(v_t_241), v_t_2458, v_progs_242));
  heff_clo_take(self, 5);
  V v_t_2465 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2457; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam12, 2, 2, (V[]){heff_dup(v_x_2457), v_next_2459}); V a_4 = v_progs_242; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2457); heff_drop(b_3); heff_drop(v_progs_242); r_; });
  V f_ = v_t_2465;
  heff_room[0] = v_z_243;
  heff_room[1] = v_z_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 0ULL, 1);
    V v_total_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_242));
    V v_t_2426 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str2), v_total_2424, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam2_clo)})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    heff_clo_take(self, 5);
    return (g_co_2eop_24s535099379x685970669(v_t_2427, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam3, 1, 5, (V[]){v_st_240, v_t_241, v_progs_242, v_z_243, v_z_244})));
  }
  case TAG_Right: {
    V v_y_2437 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Right = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    switch (heff_tag_of(v_y_2437)) {
    case TAG_Left: {
      V v_ru_24y_2437_24Left = heff_take_reuse_n(v_y_2437, 0ULL, 1);
      V v_total_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_242));
      V v_t_2441 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str3), v_total_2439, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam6_clo)})});
      V v_t_2442 = heff_tag_at_n(v_ru_24y_2437_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      heff_clo_take(self, 5);
      return (g_co_2eop_24s535099379x685970669(v_t_2442, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam7, 1, 5, (V[]){v_st_240, v_t_241, v_progs_242, v_z_243, v_z_244})));
    }
    case TAG_Right: {
      V v_ru_24y_2437_24Right = heff_take_reuse_n(v_y_2437, 0ULL, 1);
      V v_total_2453 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_242));
      V v_t_2455 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_str4), v_total_2453, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam10_clo)})});
      V v_t_2456 = heff_tag_at_n(v_ru_24y_2437_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
      heff_clo_take(self, 5);
      return (g_co_2eop_24s535099379x685970669(v_t_2456, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s895421703x882671751_lam11, 1, 5, (V[]){v_st_240, v_t_241, v_progs_242, v_z_243, v_z_244})));
    }
    default: return heff_nomatch(v_y_2437);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_progs_243);
    return v_done_242;
  }
  case TAG_Just: {
    V v_home_245 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1442652634x1828296957(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_total_248 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_247));
    V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_str0), heff_dup(v_home_245));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam0, 2, 7, (V[]){v_t_249, v_total_248, v_progs_243, heff_dup(v_st_240), heff_dup(v_t_241), v_home_245, v_done_242});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  heff_drop(v_x_2423);
  heff_clo_take(self, 3);
  V f_ = v_done_242;
  heff_room[0] = v_hd_2419;
  heff_room[1] = v_k_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2415 = heff_env(self)[0];
  V v_done_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_2419), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam4, 1, 3, (V[]){v_done_242, v_hd_2419, v_k_2420})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_245 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1442652634x1828296957(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
  V v_t_2424 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_245; V a_3 = v_x_2415; V b_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam3, 2, 2, (V[]){heff_dup(v_x_2415), v_done_242}); V a_5 = v_t_2418; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(v_st_240); heff_drop(v_t_241); heff_drop(v_home_245); heff_drop(v_x_2415); heff_drop(b_4); heff_drop(v_t_2418); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_t_249 = heff_env(self)[0];
  V v_total_248 = heff_env(self)[1];
  V v_progs_243 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_home_245 = heff_env(self)[5];
  V v_done_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_249, v_total_248, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam1_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s535099379x685970669(v_t_2414, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831_lam2, 1, 7, (V[]){v_progs_243, v_st_240, v_t_241, v_home_245, v_done_242, v_hd_2410, v_k_2411})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str2, 17, "building programs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str3, 17, "building programs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str4, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str0)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str1)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_p_249 = ({ V a_0 = v_st_240; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_249));
  V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
  V v_s_2413 = ({ V a_0 = v_st_240; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2413));
  V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2414); r_; });
  V v_a_2417 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam0_clo)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2422, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam1, 1, 6, (V[]){v_progs_243, v_z_244, v_st_240, v_t_241, v_done_242, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam0(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam2(V self, V *args) {
  V v_t_2426 = args[0];
  return v_t_2426;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_next_2431 = heff_env(self)[0];
  V v_hd_2432 = heff_env(self)[1];
  V v_k_2433 = heff_env(self)[2];
  heff_drop(v_x_2436);
  heff_clo_take(self, 3);
  V f_ = v_next_2431;
  heff_room[0] = v_hd_2432;
  heff_room[1] = v_k_2433;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_x_2429 = heff_env(self)[0];
  V v_next_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam5, 1, 3, (V[]){v_next_2431, v_hd_2432, v_k_2433})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2430 = (g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831(v_st_240, v_t_241, v_done_242, heff_dup(v_progs_243), heff_dup(heff_rfield(v_t_241, 4))));
  V v_next_2431 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(v_st_240, heff_dup(v_t_241), v_t_2430, v_progs_243));
  V v_t_2437 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2429; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam4, 2, 2, (V[]){heff_dup(v_x_2429), v_next_2431}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2429); heff_drop(b_3); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2437;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam6(V self, V *args) {
  V v_t_2441 = args[0];
  return v_t_2441;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam9(V self, V *args) {
  V v_x_2451 = args[0];
  V v_next_2446 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_k_2448 = heff_env(self)[2];
  heff_drop(v_x_2451);
  heff_clo_take(self, 3);
  V f_ = v_next_2446;
  heff_room[0] = v_hd_2447;
  heff_room[1] = v_k_2448;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam8(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_x_2444 = heff_env(self)[0];
  V v_next_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2449 = heff_tag_n(TAG_End, 2, (V[]){v_x_2444, NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), heff_dup(v_hd_2447), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam9, 1, 3, (V[]){v_next_2446, v_hd_2447, v_k_2448})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam7(V self, V *args) {
  V v_x_2444 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2445 = (g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831(v_st_240, v_t_241, v_done_242, heff_dup(v_progs_243), heff_dup(heff_rfield(v_t_241, 4))));
  V v_next_2446 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(v_st_240, heff_dup(v_t_241), v_t_2445, v_progs_243));
  V v_t_2452 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2444; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam8, 2, 2, (V[]){heff_dup(v_x_2444), v_next_2446}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2444); heff_drop(b_3); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2452;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam10(V self, V *args) {
  V v_t_2455 = args[0];
  return v_t_2455;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam13(V self, V *args) {
  V v_x_2465 = args[0];
  V v_next_2460 = heff_env(self)[0];
  V v_hd_2461 = heff_env(self)[1];
  V v_k_2462 = heff_env(self)[2];
  heff_drop(v_x_2465);
  heff_clo_take(self, 3);
  V f_ = v_next_2460;
  heff_room[0] = v_hd_2461;
  heff_room[1] = v_k_2462;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam12(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_x_2458 = heff_env(self)[0];
  V v_next_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_tag_n(TAG_End, 2, (V[]){v_x_2458, NTAG(TAG_MkUnit)});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_dup(v_hd_2461), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam13, 1, 3, (V[]){v_next_2460, v_hd_2461, v_k_2462})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam11(V self, V *args) {
  V v_x_2458 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2459 = (g_heff_2ebuild_2ecommands_2eshipIn_24s325046260x359159831(v_st_240, v_t_241, v_done_242, heff_dup(v_progs_243), heff_dup(heff_rfield(v_t_241, 4))));
  V v_next_2460 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s406237135x597296868(v_st_240, heff_dup(v_t_241), v_t_2459, v_progs_243));
  V v_t_2466 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_2458; V b_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam12, 2, 2, (V[]){heff_dup(v_x_2458), v_next_2460}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s913535736x1355823343(a_0, a_1, a_2, b_3, a_4)); heff_drop(v_st_240); heff_drop_rec(v_t_241, 6); heff_drop(v_x_2458); heff_drop(b_3); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2466;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    V v_total_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str2), v_total_2425, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam2_clo)})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    heff_clo_take(self, 6);
    return (g_co_2eop_24s535099379x685970669(v_t_2428, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam3, 1, 6, (V[]){v_st_240, v_t_241, v_done_242, v_progs_243, v_z_244, v_z_245})));
  }
  case TAG_Right: {
    V v_y_2438 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    switch (heff_tag_of(v_y_2438)) {
    case TAG_Left: {
      V v_ru_24y_2438_24Left = heff_take_reuse_n(v_y_2438, 0ULL, 1);
      V v_total_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
      V v_t_2442 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str3), v_total_2440, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam6_clo)})});
      V v_t_2443 = heff_tag_at_n(v_ru_24y_2438_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
      heff_clo_take(self, 6);
      return (g_co_2eop_24s535099379x685970669(v_t_2443, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam7, 1, 6, (V[]){v_st_240, v_t_241, v_done_242, v_progs_243, v_z_244, v_z_245})));
    }
    case TAG_Right: {
      V v_ru_24y_2438_24Right = heff_take_reuse_n(v_y_2438, 0ULL, 1);
      V v_total_2454 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
      V v_t_2456 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_str4), v_total_2454, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam10_clo)})});
      V v_t_2457 = heff_tag_at_n(v_ru_24y_2438_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
      heff_clo_take(self, 6);
      return (g_co_2eop_24s535099379x685970669(v_t_2457, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1738470866x320128584_lam11, 1, 6, (V[]){v_st_240, v_t_241, v_done_242, v_progs_243, v_z_244, v_z_245})));
    }
    default: return heff_nomatch(v_y_2438);
    }
  }
  default: return heff_nomatch(v_x_2423);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str0, 4, "PATH");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str3, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str7, 14, "heff install: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str8, 60, " is not on the PATH: add it there to run them by their names");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s535099379x685970669(v_t_2410, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam1, 1, 4, (V[]){v_hd_242, v_st_240, v_bin_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam2(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam4(V self, V *args) {
  V v_d_2424 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_d_2424));
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str5)));
  V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
  V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2427); r_; });
  heff_clo_take(self, 2);
  V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_bin_241));
  V v_t_2430 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str6)));
  V v_t_2431 = (g_std_2epath_2ejoin(v_t_2429, v_t_2430));
  V v_t_2432 = ({ V a_0 = v_st_240; V a_1 = v_t_2431; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2431); r_; });
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2428, v_t_2432, 0));
  heff_drop(v_t_2428);
  heff_drop(v_t_2432);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  V v_path_2421;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    v_path_2421 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    v_path_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_sep_2422;
  heff_clo_take(self, 5);
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str2))) {
    v_sep_2422 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str3);
  } else {
    v_sep_2422 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str4);
  }
  V v_t_2423;
  if ((heff_unbox_word(heff_strLength_lent(v_sep_2422, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_sep_2422);
    v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_path_2421, NTAG(TAG_Nil)});
  } else {
    v_t_2423 = ({ V a_0 = v_path_2421; V a_1 = v_sep_2422; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(v_sep_2422, v_path_2421, MK_INT(0LL), 4); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_path_2421); heff_drop(v_sep_2422); r_; });
  }
  V v_t_2433 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2423; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2423); r_; });
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_bin_241);
    heff_drop(v_hd_242);
    heff_drop(v_t_2433);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2433);
    V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str7), v_bin_241), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str8));
    V v_t_2435 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str9)), NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_hd_242, v_k_243));
  }
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_str0), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2418, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s673983509x432115296_lam3, 1, 5, (V[]){v_x_2411, v_st_240, v_bin_241, v_k_243, v_hd_242})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594(V v_before_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_before_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam0_clo);
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_244)));
    V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
    V v_a_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam2, 2, 4, (V[]){v_a_249, v_path_244, v_before_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam1(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_x_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0(v_path_244, v_hd_2410, v_k_2411, v_before_240, v_rest_245, heff_tag_re_n(v_ru_24x_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2418})));
  }
  case TAG_Right: {
    V v_y_2419 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    switch (heff_tag_of(v_y_2419)) {
    case TAG_Left: {
      V v_err_2420 = heff_field(v_y_2419, 0);
      V v_ru_24y_2419_24Left = heff_take_reuse_n(v_y_2419, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2417_24Right, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0(v_path_244, v_hd_2410, v_k_2411, v_before_240, v_rest_245, heff_tag_re_n(v_ru_24y_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2420})));
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_y_2419, 0);
      heff_take_n(v_y_2419, 1ULL, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_2ek_24l0(v_path_244, v_hd_2410, v_k_2411, v_before_240, v_rest_245, heff_tag_at_n(v_ru_24x_2417_24Right, TAG_Right, 1, (V[]){v_x_2421})));
    }
    default: return heff_nomatch(v_y_2419);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_a_249 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2416, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s1693001668x391774594_lam3, 1, 5, (V[]){v_path_244, v_hd_2410, v_k_2411, v_before_240, v_rest_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_str2, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1(V v_tok_240, V v_lit_241, V v_st_242, V v_t_243, V v_acc_244, V v_x_245, V v_z_246, V v_z_247) {
top: ;
  V v_src_248 = heff_dup(v_lit_241);
  V v_t_249 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_2410 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_248, v_t_249, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  {
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[0]);
    heff_drop(v_t_2410.f[2]);
    V v_t_2414 = v_field_2412;
    V v_t_2429;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      V v_t_2415 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      HeffT3 v_t_2416 = ({ V a_0 = v_src_248; V a_1 = v_t_2415; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); HeffT3 r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_248); r_; });
      {
        V v_field_2417 = v_t_2416.f[0];
        heff_drop(v_t_2416.f[1]);
        heff_drop(v_t_2416.f[2]);
        HeffT2 v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_str1); V b_2 = heff_arrayFromList(v_field_2417); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_p_2423 = v_field_2422;
            v_t_2429 = heff_tag_at_n(v_tok_240, TAG_Left, 1, (V[]){v_p_2423});
          } else {
            heff_drop_cell(v_tok_240, 1);
            V v_x_2424 = v_field_2422;
            v_t_2429 = ({ V a_0 = v_x_2424; V r_ = (g_heff_2ebuild_2eproject_2ebuildOf(a_0)); heff_drop(v_x_2424); r_; });
          }
        }
      }
      break;
    }
    case TAG_Cons: {
      V v_e_2425 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 2);
      heff_drop(v_src_248);
      V v_start_2427 = heff_take_field(v_e_2425, 0);
      V v_msg_2428 = heff_get_n(v_e_2425, 2, 3);
      v_t_2429 = heff_tag_at_n(v_tok_240, TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_start_2427, v_msg_2428})});
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Left: {
      V v_p_2430 = heff_field(v_t_2429, 0);
      V v_ru_24t_2429_24Left = heff_take_reuse_n(v_t_2429, 1ULL, 1);
      V v_t_2431 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_242, v_t_243, v_x_245, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_str2)));
      V v_str_2432 = ({ V a_0 = v_t_2431; V a_1 = v_lit_241; V a_2 = v_p_2430; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_lit_241); r_; });
      V v_t_2433 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2432, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_str3)), NTAG(TAG_MkUnit)});
      V v_t_2434 = heff_tag_at_n(v_ru_24t_2429_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_z_246, heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_lam0, 1, 2, (V[]){v_acc_244, v_z_247})));
    }
    case TAG_Right: {
      V v_a_2442 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop(v_lit_241);
      V v_c_2443 = (g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811(heff_dup(v_st_242), heff_dup(v_t_243), heff_dup(heff_rfield(v_a_2442, 2))));
      return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_lam1, 1, 7, (V[]){v_st_242, v_t_243, v_acc_244, v_x_245, v_a_2442, v_z_246, v_z_247})});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_lam0(V self, V *args) {
  V v_x_2439 = args[0];
  V v_acc_244 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_drop(v_x_2439);
  heff_clo_take(self, 2);
  V v_t_2440 = heff_intAdd(heff_take_field(v_acc_244, 1), MK_INT(1LL));
  V v_t_2441 = ({ V rv_1 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_acc_244, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_t_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_lam1(V self, V *args) {
  V v_x_2444 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_a_2442 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621(v_st_242, v_t_243, v_acc_244, v_x_245, v_a_2442, v_x_2444, v_z_246, v_z_247));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str5, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1(V v_tok_240, V v_bi_241, V v_file_242, V v_name_243, V v_outPath_244, V v_rt_245, V v_failed_246, V v_done_247, V v_c_248, V v_available_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_248)));
  V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2413));
  V v_t_2416 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_lam0, 1, 1, (V[]){heff_dup(v_available_249)}); V a_1 = v_t_2414; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2417 = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(v_t_2416, heff_dup(v_c_248), v_name_243));
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      heff_drop_rec(v_bi_241, 4);
      heff_drop(v_outPath_244);
      heff_drop_rec(v_rt_245, 4);
      heff_drop(v_done_247);
      heff_drop_rec(v_c_248, 14);
      heff_drop(v_available_249);
      V v_why_2420 = v_field_2419;
      V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str0), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str1));
      V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, heff_dup(v_why_2420)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str2));
      V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
      V v_t_2424 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_z_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_lam1, 1, 5, (V[]){v_file_242, v_failed_246, v_why_2420, v_z_2410, v_z_2411})));
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_file_242);
      heff_drop(v_failed_246);
      V v_r_2431 = v_field_2419;
      int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
      V v_t_2433 = heff_strSlice_lent(v_outPath_244, heff_box_word(v_t_2432), heff_strLength_lent(v_outPath_244, 0), 6);
      if (heff_strEq_c(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str5))) {
        int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(v_bi_241, heff_strSlice(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2434)), v_rt_245, v_done_247, v_c_248, v_available_249, v_r_2431, v_z_2410, v_z_2411));
      } else {
        V v_t_2435 = (g_heff_2ebuild_2ecommands_2eruntimeOf(heff_rfield(v_bi_241, 3), v_available_249, heff_dup(v_rt_245)));
        V v_t_2436 = heff_get_n(heff_get_n(v_c_248, 5, 14), 0, 10);
        V v_t_2437 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_get_n(v_bi_241, 3, 4), v_t_2435, v_available_249, v_t_2436, heff_take_field(v_r_2431, 0), heff_get_n(v_r_2431, 1, 2)));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(v_outPath_244, heff_get_n(v_rt_245, 1, 4), v_done_247, v_t_2437, v_z_2410, v_z_2411));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_lam0(V self, V *args) {
  V v_k_2415 = args[0];
  V v_available_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_249; V a_1 = v_k_2415; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_249); heff_drop(v_k_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_246 = heff_env(self)[1];
  V v_why_2420 = heff_env(self)[2];
  V v_z_2410 = heff_env(self)[3];
  V v_z_2411 = heff_env(self)[4];
  heff_drop(v_x_2429);
  heff_clo_take(self, 5);
  V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str3), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_str4));
  V f_ = v_failed_246;
  heff_room[0] = heff_strAppend(v_t_2430, v_why_2420);
  heff_room[1] = v_z_2410;
  heff_room[2] = v_z_2411;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}