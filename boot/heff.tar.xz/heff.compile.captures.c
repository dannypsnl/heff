// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CDropSelf 14512
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CTakeSelf 23160
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkCArm 24694
#define TAG_MkCode 2932
#define TAG_MkDrop 35958
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define LBL_bor 307263
#define LBL_cs 9943
static uint32_t shape_cs__bor[] = {LBL_cs, LBL_bor};
V g_heff_2ecompile_2ecaptures_2ecapExp(V, V, V);
V g_heff_2ecompile_2ecaptures_2ecapExp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ecapExp_clo;
V g_heff_2ecompile_2ecaptures_2ecapExp_24dps(V, V, V, V, V);
V g_heff_2ecompile_2ecaptures_2ecapExp_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ecapExp_24dps_clo;
V g_heff_2ecompile_2ecaptures_2ecapSt(V, V, V);
V g_heff_2ecompile_2ecaptures_2ecapSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ecapSt_clo;
V g_heff_2ecompile_2ecaptures_2ecapStmts(V, V);
V g_heff_2ecompile_2ecaptures_2ecapStmts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ecapStmts_clo;
V g_heff_2ecompile_2ecaptures_2edroppedAtLast(V, V);
V g_heff_2ecompile_2ecaptures_2edroppedAtLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2edroppedAtLast_clo;
V g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps(V, V, V);
V g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps_clo;
V g_heff_2ecompile_2ecaptures_2edropsOne(V, V);
V g_heff_2ecompile_2ecaptures_2edropsOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2edropsOne_clo;
V g_heff_2ecompile_2ecaptures_2eelemS(V, V);
V g_heff_2ecompile_2ecaptures_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2eelemS_clo;
V g_heff_2ecompile_2ecaptures_2ekeeps(V, V);
V g_heff_2ecompile_2ecaptures_2ekeeps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ekeeps_clo;
V g_heff_2ecompile_2ecaptures_2ekeepsArg(V, V, V, V);
V g_heff_2ecompile_2ecaptures_2ekeepsArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ekeepsArg_clo;
V g_heff_2ecompile_2ecaptures_2ekeepsArgs(V, V, V, V, V);
V g_heff_2ecompile_2ecaptures_2ekeepsArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ekeepsArgs_clo;
V g_heff_2ecompile_2ecaptures_2ekeepsCond(V, V, V);
V g_heff_2ecompile_2ecaptures_2ekeepsCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ekeepsCond_clo;
V g_heff_2ecompile_2ecaptures_2ekeepsSt(V, V);
V g_heff_2ecompile_2ecaptures_2ekeepsSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2ekeepsSt_clo;
V g_heff_2ecompile_2ecaptures_2enames(V, V);
V g_heff_2ecompile_2ecaptures_2enames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2enames_clo;
V g_heff_2ecompile_2ecaptures_2eputOff(V, V, V);
V g_heff_2ecompile_2ecaptures_2eputOff_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2eputOff_clo;
V g_heff_2ecompile_2ecaptures_2eputOffOn(V, V, V, V);
V g_heff_2ecompile_2ecaptures_2eputOffOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecaptures_2eputOffOn_clo;
V g_heff_2ecompile_2eowned_2econdKids(V);
V g_heff_2ecompile_2eowned_2econdKids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2econdKids_clo;
V g_heff_2ecompile_2eowned_2ekids(V);
V g_heff_2ecompile_2eowned_2ekids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ekids_clo;
V g_heff_2ecompile_2eowned_2emapCond(V, V);
V g_heff_2ecompile_2eowned_2emapCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1602235202x783198227(V, V);
V g_list_2eany_24s1602235202x783198227_entry(V self, V *a);
extern Clo g_list_2eany_24s1602235202x783198227_clo;
V g_list_2eany_24s781693278x668067139(V, V);
V g_list_2eany_24s781693278x668067139_entry(V self, V *a);
extern Clo g_list_2eany_24s781693278x668067139_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1851573375x1006375246(V, V, V);
V g_list_2emap_24s1851573375x1006375246_entry(V self, V *a);
extern Clo g_list_2emap_24s1851573375x1006375246_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2ecaptures_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2ecaptures_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecaptures_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecaptures_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecaptures_2ekeepsArg_lam0(V self, V *args);
V g_heff_2ecompile_2ecaptures_2ekeepsArg_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2ekeepsArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ekeepsArg_entry, 4, 0};

V g_heff_2ecompile_2ecaptures_2ekeepsArg(V v_k_240, V v_h_241, V v_lent_242, V v_a_243) {
top: ;
  if ((heff_dup(v_lent_242) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_a_243)) {
    case TAG_Given: {
      V v_a1_244 = heff_dup(heff_field(v_a_243, 0));
      heff_drop_rec(v_h_241, 2);
      switch (heff_tag_of(v_a1_244)) {
      case TAG_RLocal: {
        heff_take_n(v_a1_244, 0ULL, 1);
        switch (heff_tag_of(v_a_243)) {
        case TAG_Given: {
          heff_take_n(v_a_243, 0ULL, 1);
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_243);
        }
      }
      default: {
        heff_drop(v_a1_244);
        V v_t_2413;
        switch (heff_tag_of(v_a_243)) {
        case TAG_Given: {
          V v_e_247 = heff_field(v_a_243, 0);
          heff_take_n(v_a_243, 1ULL, 1);
          v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_247, NTAG(TAG_Nil)});
          break;
        }
        case TAG_GivenU: {
          V v_e_249 = heff_field(v_a_243, 1);
          V v_ru_24a_243_24GivenU = heff_take_reuse_n(v_a_243, 2ULL, 2);
          v_t_2413 = heff_tag_at_n(v_ru_24a_243_24GivenU, TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
          break;
        }
        case TAG_LentVar: {
          heff_take_n(v_a_243, 0ULL, 2);
          v_t_2413 = NTAG(TAG_Nil);
          break;
        }
        case TAG_LentValue: {
          V v_e_2412 = heff_field(v_a_243, 0);
          heff_take_n(v_a_243, 1ULL, 1);
          v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2412, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_a_243);
        }
        return ({ V a_0 = v_k_240; V a_1 = v_t_2413; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2413); r_; });
      }
      }
    }
    case TAG_GivenU: {
      heff_drop_rec(v_h_241, 2);
      V v_t_2422;
      switch (heff_tag_of(v_a_243)) {
      case TAG_Given: {
        V v_e_2416 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2416, NTAG(TAG_Nil)});
        break;
      }
      case TAG_GivenU: {
        V v_e_2418 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24GivenU = heff_take_reuse_n(v_a_243, 2ULL, 2);
        v_t_2422 = heff_tag_at_n(v_ru_24a_243_24GivenU, TAG_Cons, 2, (V[]){v_e_2418, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LentVar: {
        heff_take_n(v_a_243, 0ULL, 2);
        v_t_2422 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LentValue: {
        V v_e_2421 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2421, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      return ({ V a_0 = v_k_240; V a_1 = v_t_2422; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2422); r_; });
    }
    case TAG_LentVar: {
      V v_drops_2424 = heff_field(v_a_243, 1);
      heff_take_n(v_a_243, 2ULL, 2);
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecaptures_2ekeepsArg_lam0, 1, 1, (V[]){v_h_241}); V a_1 = v_drops_2424; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_drops_2424); r_; });
    }
    case TAG_LentValue: {
      heff_drop_rec(v_h_241, 2);
      V v_t_2436;
      switch (heff_tag_of(v_a_243)) {
      case TAG_Given: {
        V v_e_2430 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2430, NTAG(TAG_Nil)});
        break;
      }
      case TAG_GivenU: {
        V v_e_2432 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24GivenU = heff_take_reuse_n(v_a_243, 2ULL, 2);
        v_t_2436 = heff_tag_at_n(v_ru_24a_243_24GivenU, TAG_Cons, 2, (V[]){v_e_2432, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LentVar: {
        heff_take_n(v_a_243, 0ULL, 2);
        v_t_2436 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LentValue: {
        V v_e_2435 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2435, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      return ({ V a_0 = v_k_240; V a_1 = v_t_2436; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2436); r_; });
    }
    default: return heff_nomatch(v_a_243);
    }
  } else {
    switch (heff_tag_of(v_a_243)) {
    case TAG_Given: {
      heff_drop_rec(v_h_241, 2);
      V v_t_2444;
      switch (heff_tag_of(v_a_243)) {
      case TAG_Given: {
        V v_e_2438 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2438, NTAG(TAG_Nil)});
        break;
      }
      case TAG_GivenU: {
        V v_e_2440 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24GivenU = heff_take_reuse_n(v_a_243, 2ULL, 2);
        v_t_2444 = heff_tag_at_n(v_ru_24a_243_24GivenU, TAG_Cons, 2, (V[]){v_e_2440, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LentVar: {
        heff_take_n(v_a_243, 0ULL, 2);
        v_t_2444 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LentValue: {
        V v_e_2443 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2443, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      return ({ V a_0 = v_k_240; V a_1 = v_t_2444; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2444); r_; });
    }
    case TAG_GivenU: {
      heff_drop_rec(v_h_241, 2);
      V v_t_2453;
      switch (heff_tag_of(v_a_243)) {
      case TAG_Given: {
        V v_e_2447 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2447, NTAG(TAG_Nil)});
        break;
      }
      case TAG_GivenU: {
        V v_e_2449 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24GivenU = heff_take_reuse_n(v_a_243, 2ULL, 2);
        v_t_2453 = heff_tag_at_n(v_ru_24a_243_24GivenU, TAG_Cons, 2, (V[]){v_e_2449, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LentVar: {
        heff_take_n(v_a_243, 0ULL, 2);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LentValue: {
        V v_e_2452 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2452, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      return ({ V a_0 = v_k_240; V a_1 = v_t_2453; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2453); r_; });
    }
    case TAG_LentVar: {
      V v_drops_2455 = heff_field(v_a_243, 1);
      heff_take_n(v_a_243, 2ULL, 2);
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecaptures_2ekeepsArg_lam1, 1, 1, (V[]){v_h_241}); V a_1 = v_drops_2455; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_drops_2455); r_; });
    }
    case TAG_LentValue: {
      heff_drop_rec(v_h_241, 2);
      V v_t_2467;
      switch (heff_tag_of(v_a_243)) {
      case TAG_Given: {
        V v_e_2461 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2461, NTAG(TAG_Nil)});
        break;
      }
      case TAG_GivenU: {
        V v_e_2463 = heff_field(v_a_243, 1);
        V v_ru_24a_243_24GivenU = heff_take_reuse_n(v_a_243, 2ULL, 2);
        v_t_2467 = heff_tag_at_n(v_ru_24a_243_24GivenU, TAG_Cons, 2, (V[]){v_e_2463, NTAG(TAG_Nil)});
        break;
      }
      case TAG_LentVar: {
        heff_take_n(v_a_243, 0ULL, 2);
        v_t_2467 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LentValue: {
        V v_e_2466 = heff_field(v_a_243, 0);
        heff_take_n(v_a_243, 1ULL, 1);
        v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2466, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      return ({ V a_0 = v_k_240; V a_1 = v_t_2467; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2467); r_; });
    }
    default: return heff_nomatch(v_a_243);
    }
  }
}
V g_heff_2ecompile_2ecaptures_2ekeepsArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecaptures_2ekeepsArg(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecaptures_2ekeepsArg_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_h_241 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkDrop: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    heff_take_n(v_x2_2425, 1ULL, 2);
    heff_clo_take(self, 1);
    V v_x1_2428 = ({ V a_0 = v_x_2426; V b_1 = heff_get_n(v_h_241, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(v_x_2426); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
    heff_drop(v_x1_2428);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2ecaptures_2ekeepsArg_lam1(V self, V *args) {
  V v_x2_2456 = args[0];
  V v_h_241 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkDrop: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    heff_take_n(v_x2_2456, 1ULL, 2);
    heff_clo_take(self, 1);
    V v_x1_2459 = ({ V a_0 = v_x_2457; V b_1 = heff_get_n(v_h_241, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(v_x_2457); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2459) == NTAG(TAG_True)));
    heff_drop(v_x1_2459);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
Clo g_heff_2ecompile_2ecaptures_2ekeepsArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ekeepsArgs_entry, 5, 0};

V g_heff_2ecompile_2ecaptures_2ekeepsArgs(V v_k_240, V v_h_241, V v_bi_242, V v_i_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_243);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_t_247 = (g_list_2eany_24s781693278x668067139(v_i_243, v_bi_242));
    V v_t_248 = ({ V a_0 = v_k_240; V a_1 = heff_dup(v_h_241); V a_2 = v_t_247; V a_3 = heff_dup(v_a_245); V r_ = (g_heff_2ecompile_2ecaptures_2ekeepsArg(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V t_0 = v_k_240;
      V t_1 = v_h_241;
      V t_2 = v_bi_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      V t_4 = v_rest_246;
      v_k_240 = t_0;
      v_h_241 = t_1;
      v_bi_242 = t_2;
      v_i_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    } else {
      heff_drop(v_i_243);
      heff_drop(v_t_248);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2ecaptures_2ekeepsArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2ecaptures_2ekeepsArgs(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2ecompile_2ecaptures_2ekeepsCond_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2ekeepsCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ekeepsCond_entry, 3, 0};

V g_heff_2ecompile_2ecaptures_2ekeepsCond(V v_k_240, V v_h_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CondTrue: {
    V v_t_243 = (g_heff_2ecompile_2eowned_2econdKids(v_x3_242));
    return ({ V a_0 = v_k_240; V a_1 = v_t_243; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_243); r_; });
  }
  case TAG_CondFalse: {
    V v_t_244 = (g_heff_2ecompile_2eowned_2econdKids(v_x3_242));
    return ({ V a_0 = v_k_240; V a_1 = v_t_244; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_244); r_; });
  }
  case TAG_CondRel: {
    V v_t_247 = (g_heff_2ecompile_2eowned_2econdKids(v_x3_242));
    return ({ V a_0 = v_k_240; V a_1 = v_t_247; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  case TAG_CondRelU: {
    V v_t_2410 = (g_heff_2ecompile_2eowned_2econdKids(v_x3_242));
    return ({ V a_0 = v_k_240; V a_1 = v_t_2410; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_CondBool: {
    V v_t_2412 = (g_heff_2ecompile_2eowned_2econdKids(v_x3_242));
    return ({ V a_0 = v_k_240; V a_1 = v_t_2412; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2412); r_; });
  }
  case TAG_CondNot: {
    V v_c_2413 = heff_field(v_x3_242, 0);
    V t_0 = v_k_240;
    V t_1 = v_h_241;
    V t_2 = v_c_2413;
    v_k_240 = t_0;
    v_h_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_CondIf: {
    V v_a_2414 = heff_field(v_x3_242, 0);
    V v_b_2415 = heff_field(v_x3_242, 1);
    V v_c_2416 = heff_field(v_x3_242, 2);
    V v_t_2417 = (g_heff_2ecompile_2ecaptures_2ekeepsCond(v_k_240, v_h_241, v_a_2414));
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      V v_t_2418 = (g_heff_2ecompile_2ecaptures_2ekeepsCond(v_k_240, v_h_241, v_b_2415));
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        V t_0 = v_k_240;
        V t_1 = v_h_241;
        V t_2 = v_c_2416;
        v_k_240 = t_0;
        v_h_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2418);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_2417);
      return NTAG(TAG_False);
    }
  }
  case TAG_CondLet: {
    V v_e_2420 = heff_field(v_x3_242, 1);
    V v_c_2421 = heff_field(v_x3_242, 2);
    V v_drops_2422 = heff_field(v_x3_242, 3);
    V v_t_2423 = heff_tr(heff_call(heff_dup(v_k_240), 1, (V[]){heff_dup(v_e_2420)}));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_t_2423);
      V v_t_2424 = (g_heff_2ecompile_2ecaptures_2ekeepsCond(v_k_240, v_h_241, v_c_2421));
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_t_2424);
        return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecaptures_2ekeepsCond_lam0, 1, 1, (V[]){heff_dup(v_h_241)}); V a_1 = v_drops_2422; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_t_2424);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_2423);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecaptures_2ekeepsCond_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecaptures_2ekeepsCond(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecaptures_2ekeepsCond_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_h_241 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkDrop: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    heff_take_n(v_x2_2425, 1ULL, 2);
    heff_clo_take(self, 1);
    V v_x1_2428 = ({ V a_0 = v_x_2426; V b_1 = heff_get_n(v_h_241, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(v_x_2426); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
    heff_drop(v_x1_2428);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2ecaptures_2ekeeps_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2ekeeps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ekeeps_entry, 2, 0};

V g_heff_2ecompile_2ecaptures_2ekeeps(V v_h_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_RLocal: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_x1_243 = ({ V a_0 = v_x_242; V b_1 = heff_get_n(v_h_240, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(v_x_242); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_243) == NTAG(TAG_True)));
    heff_drop(v_x1_243);
    return v_ret_24bool;
  }
  case TAG_RRecIn: {
    V v_x_244 = heff_field(v_e_241, 0);
    V v_fs_2410 = heff_field(v_e_241, 6);
    heff_take_n(v_e_241, 65ULL, 8);
    V v_x1_2412 = ({ V a_0 = v_x_244; V a_1 = heff_rfield(v_h_240, 0); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, a_1)); heff_drop(v_x_244); r_; });
    if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
      heff_drop(v_x1_2412);
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecaptures_2ekeeps_lam0, 1, 1, (V[]){v_h_240}); V a_1 = v_fs_2410; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2410); r_; });
    } else {
      heff_drop_rec(v_h_240, 2);
      heff_drop(v_fs_2410);
      heff_drop(v_x1_2412);
      return NTAG(TAG_False);
    }
  }
  case TAG_RField: {
    V v_e1_2417 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_2417)) {
    case TAG_RLocal: {
      heff_take_n(v_e1_2417, 0ULL, 1);
      heff_drop_rec(v_h_240, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_RField: {
        heff_take_n(v_e_241, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: {
      heff_drop(v_e1_2417);
      V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){v_h_240}));
      V v_t_2423 = (g_heff_2ecompile_2eowned_2ekids(v_e_241));
      return ({ V a_0 = v_t_2422; V a_1 = v_t_2423; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2422); heff_drop(v_t_2423); r_; });
    }
    }
  }
  case TAG_RFieldU: {
    V v_e3_2426 = heff_dup(heff_field(v_e_241, 2));
    switch (heff_tag_of(v_e3_2426)) {
    case TAG_RLocal: {
      heff_take_n(v_e3_2426, 0ULL, 1);
      heff_drop_rec(v_h_240, 2);
      switch (heff_tag_of(v_e_241)) {
      case TAG_RFieldU: {
        heff_take_n(v_e_241, 0ULL, 4);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: {
      heff_drop(v_e3_2426);
      V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){v_h_240}));
      V v_t_2434 = (g_heff_2ecompile_2eowned_2ekids(v_e_241));
      return ({ V a_0 = v_t_2433; V a_1 = v_t_2434; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2433); heff_drop(v_t_2434); r_; });
    }
    }
  }
  case TAG_RTakeField: {
    V v_x_2435 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 2);
    V v_x1_2437 = ({ V a_0 = v_x_2435; V b_1 = heff_get_n(v_h_240, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(v_x_2435); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2437) == NTAG(TAG_True)));
    heff_drop(v_x1_2437);
    return v_ret_24bool;
  }
  case TAG_RCall: {
    V v_g_2438 = heff_field(v_e_241, 0);
    V v_args_2441 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 9ULL, 4);
    V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){heff_dup(v_h_240)}));
    HeffT2 v_t_2443 = ({ V a_0 = heff_rfield(v_h_240, 1); V a_1 = v_g_2438; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2438); r_; });
    {
      V v_field_2445 = v_t_2443.f[1];
      int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
      V v_t_2447;
      if ((v_tag_2444 == ((int64_t)0ULL))) {
        V v_x_2446 = v_field_2445;
        v_t_2447 = v_x_2446;
      } else {
        heff_drop(v_field_2445);
        v_t_2447 = NTAG(TAG_Nil);
      }
      return ({ V a_0 = v_t_2442; V a_1 = v_h_240; V a_2 = v_t_2447; V a_3 = MK_INT(0LL); V a_4 = v_args_2441; V r_ = (g_heff_2ecompile_2ecaptures_2ekeepsArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2442); heff_drop_rec(v_h_240, 2); heff_drop(v_t_2447); heff_drop(v_args_2441); r_; });
    }
  }
  case TAG_RBool: {
    V v_c_2448 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){heff_dup(v_h_240)}));
    return ({ V a_0 = v_t_2449; V a_1 = v_h_240; V a_2 = v_c_2448; V r_ = (g_heff_2ecompile_2ecaptures_2ekeepsCond(a_0, a_1, a_2)); heff_drop(v_t_2449); heff_drop_rec(v_h_240, 2); heff_drop(v_c_2448); r_; });
  }
  default: {
    V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){v_h_240}));
    V v_t_2451 = (g_heff_2ecompile_2eowned_2ekids(v_e_241));
    return ({ V a_0 = v_t_2450; V a_1 = v_t_2451; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2450); heff_drop(v_t_2451); r_; });
  }
  }
}
V g_heff_2ecompile_2ecaptures_2ekeeps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecaptures_2ekeeps(a[0], a[1]);
}
V g_heff_2ecompile_2ecaptures_2ekeeps_lam0(V self, V *args) {
  V v_f_2413 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_t_2416;
  switch (heff_tag_of(v_f_2413)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_f_2413, 1);
    heff_take_n(v_f_2413, 2ULL, 2);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_f_2413);
  }
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2ecaptures_2ekeeps(v_h_240, v_t_2416));
}
Clo g_heff_2ecompile_2ecaptures_2enames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2enames_entry, 2, 0};

V g_heff_2ecompile_2ecaptures_2enames(V v_h_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_RLocal: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    return ({ V a_0 = v_x_242; V b_1 = heff_get_n(v_h_240, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(v_x_242); heff_drop(b_1); r_; });
  }
  case TAG_RDup: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    return ({ V a_0 = v_x_243; V b_1 = heff_get_n(v_h_240, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(v_x_243); heff_drop(b_1); r_; });
  }
  default: {
    V v_x1_244 = (g_heff_2ecompile_2ecaptures_2ekeeps(heff_dup(v_h_240), heff_dup(v_e_241)));
    if (!(heff_dup(v_x1_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_h_240, 2);
      heff_drop(v_e_241);
      heff_drop(v_x1_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_x1_244);
      V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2enames_clo), 1, (V[]){v_h_240}));
      V v_t_246 = (g_heff_2ecompile_2eowned_2ekids(v_e_241));
      return ({ V a_0 = v_t_245; V a_1 = v_t_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_245); heff_drop(v_t_246); r_; });
    }
  }
  }
}
V g_heff_2ecompile_2ecaptures_2enames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecaptures_2enames(a[0], a[1]);
}
V g_heff_2ecompile_2ecaptures_2ekeepsSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2ekeepsSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ekeepsSt_entry, 2, 0};

V g_heff_2ecompile_2ecaptures_2ekeepsSt(V v_h_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_CDrop: {
    V v_d_242 = heff_field(v_s_241, 0);
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_d_242, 0);
      V v_x1_245 = ({ V a_0 = v_x_243; V b_1 = heff_get_n(v_h_240, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
      heff_drop(v_x1_245);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_d_242);
    }
  }
  case TAG_CLet: {
    V v_e_247 = heff_field(v_s_241, 1);
    HEFF_LAST return g_heff_2ecompile_2ecaptures_2ekeeps(v_h_240, heff_dup(v_e_247));
  }
  case TAG_CDecl: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_CSet: {
    V v_x_249 = heff_field(v_s_241, 0);
    V v_e_2410 = heff_field(v_s_241, 1);
    V v_x1_2411 = (g_heff_2ecompile_2ecaptures_2eelemS(v_x_249, heff_rfield(v_h_240, 0)));
    if (!(heff_dup(v_x1_2411) == NTAG(TAG_True))) {
      heff_drop(v_x1_2411);
      HEFF_LAST return g_heff_2ecompile_2ecaptures_2ekeeps(v_h_240, heff_dup(v_e_2410));
    } else {
      heff_drop_rec(v_h_240, 2);
      heff_drop(v_x1_2411);
      return NTAG(TAG_False);
    }
  }
  case TAG_CAbandon: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_True);
  }
  case TAG_CIf: {
    V v_c_2412 = heff_field(v_s_241, 0);
    V v_a_2413 = heff_field(v_s_241, 1);
    V v_b_2414 = heff_field(v_s_241, 2);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){heff_dup(v_h_240)}));
    V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_h_240; V a_2 = v_c_2412; V r_ = (g_heff_2ecompile_2ecaptures_2ekeepsCond(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeepsSt_clo), 1, (V[]){heff_dup(v_h_240)}));
      V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_a_2413; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2417); r_; });
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeepsSt_clo), 1, (V[]){v_h_240}));
        return ({ V a_0 = v_t_2419; V a_1 = v_b_2414; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2419); r_; });
      } else {
        heff_drop_rec(v_h_240, 2);
        heff_drop(v_t_2418);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop_rec(v_h_240, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
  }
  case TAG_CSwitch: {
    V v_e_2420 = heff_field(v_s_241, 0);
    V v_arms_2421 = heff_field(v_s_241, 1);
    V v_x1_2423 = (g_heff_2ecompile_2ecaptures_2enames(heff_dup(v_h_240), heff_dup(v_e_2420)));
    if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
      heff_drop(v_x1_2423);
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecaptures_2ekeepsSt_lam0, 1, 1, (V[]){v_h_240}); V a_1 = v_arms_2421; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
    } else {
      heff_drop_rec(v_h_240, 2);
      heff_drop(v_x1_2423);
      return NTAG(TAG_False);
    }
  }
  case TAG_CReturn: {
    V v_e_2435 = heff_field(v_s_241, 0);
    HEFF_LAST return g_heff_2ecompile_2ecaptures_2ekeeps(v_h_240, heff_dup(v_e_2435));
  }
  case TAG_CInPlace: {
    V v_f_2436 = heff_field(v_s_241, 0);
    V v_es_2437 = heff_field(v_s_241, 1);
    V v_p_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){v_h_240}));
    V v_t_2439 = heff_tr(heff_call(heff_dup(v_p_2438), 1, (V[]){heff_dup(v_f_2436)}));
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_t_2439);
      return ({ V a_0 = v_p_2438; V a_1 = v_es_2437; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_p_2438); r_; });
    } else {
      heff_drop(v_p_2438);
      heff_drop(v_t_2439);
      return NTAG(TAG_False);
    }
  }
  case TAG_CRoomed: {
    V v_f_2440 = heff_field(v_s_241, 0);
    V v_es_2441 = heff_field(v_s_241, 1);
    V v_p_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){v_h_240}));
    V v_t_2443 = heff_tr(heff_call(heff_dup(v_p_2442), 1, (V[]){heff_dup(v_f_2440)}));
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      return ({ V a_0 = v_p_2442; V a_1 = v_es_2441; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_p_2442); r_; });
    } else {
      heff_drop(v_p_2442);
      heff_drop(v_t_2443);
      return NTAG(TAG_False);
    }
  }
  case TAG_CTail: {
    V v_f_2444 = heff_field(v_s_241, 0);
    V v_es_2445 = heff_field(v_s_241, 1);
    V v_p_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){v_h_240}));
    V v_t_2447 = heff_tr(heff_call(heff_dup(v_p_2446), 1, (V[]){heff_dup(v_f_2444)}));
    if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
      heff_drop(v_t_2447);
      return ({ V a_0 = v_p_2446; V a_1 = v_es_2445; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_p_2446); r_; });
    } else {
      heff_drop(v_p_2446);
      heff_drop(v_t_2447);
      return NTAG(TAG_False);
    }
  }
  case TAG_CLoop: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CLoopTo: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CLabel: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CJump: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CTakeSelf: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CDropSelf: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2ecaptures_2ekeepsSt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecaptures_2ekeepsSt(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecaptures_2ekeepsSt_lam0(V self, V *args) {
  V v_arm_2424 = args[0];
  V v_h_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeepsSt_clo), 1, (V[]){v_h_240}));
  V v_t_2434;
  switch (heff_tag_of(v_arm_2424)) {
  case TAG_MkCArm: {
    V v_body_2432 = heff_field(v_arm_2424, 6);
    heff_take_n(v_arm_2424, 64ULL, 8);
    v_t_2434 = v_body_2432;
    break;
  }
  default: heff_nomatch(v_arm_2424);
  }
  return ({ V a_0 = v_t_2425; V a_1 = v_t_2434; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_2425); heff_drop(v_t_2434); r_; });
}
Clo g_heff_2ecompile_2ecaptures_2edropsOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2edropsOne_entry, 2, 0};

V g_heff_2ecompile_2ecaptures_2edropsOne(V v_h_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_CDrop: {
    V v_d_242 = heff_field(v_s_241, 0);
    V v_x1_246;
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_d_242, 0);
      V v_x1_245 = ({ V a_0 = v_x_243; V b_1 = heff_get_n(v_h_240, 0, 2); V r_ = (g_heff_2ecompile_2ecaptures_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      v_x1_246 = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
      heff_drop(v_x1_245);
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
    heff_drop(v_x1_246);
    return v_ret_24bool;
  }
  case TAG_CLet: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CDecl: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CSet: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CAbandon: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CIf: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CSwitch: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CReturn: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CInPlace: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CRoomed: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CTail: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CLoop: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CLoopTo: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CLabel: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CJump: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CTakeSelf: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_CDropSelf: {
    heff_drop_rec(v_h_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2ecaptures_2edropsOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecaptures_2edropsOne(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecaptures_2edroppedAtLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2edroppedAtLast_entry, 2, 0};

V g_heff_2ecompile_2ecaptures_2edroppedAtLast(V v_h_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2ecaptures_2edropsOne(heff_dup(v_h_240), v_s_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_s_242);
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2eany_24s1602235202x783198227(v_h_240, v_rest_243));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_245);
        V t_0 = v_h_240;
        V t_1 = v_rest_243;
        v_h_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_245);
        return heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 2ULL, (V[]){NTAG(TAG_CDropSelf), v_rest_243});
      }
    } else {
      heff_drop(v_t_244);
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_s_242, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps(v_h_240, v_rest_243, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecaptures_2edroppedAtLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecaptures_2edroppedAtLast(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps(V v_h_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2ecaptures_2edropsOne(heff_dup(v_h_240), v_s_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_s_243);
      heff_drop(v_t_245);
      V v_t_246 = (g_list_2eany_24s1602235202x783198227(v_h_240, v_rest_244));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_246);
        V t_0 = v_h_240;
        V t_1 = v_rest_244;
        V t_2 = v_d_242;
        v_h_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_246);
        V v_t_247 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 2ULL, (V[]){NTAG(TAG_CDropSelf), v_rest_244});
        return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_247);
      }
    } else {
      heff_drop(v_t_245);
      V v_cell_248 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_s_243, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_h_240;
      V t_1 = v_rest_244;
      V t_2 = v_u_249;
      v_h_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2ecaptures_2edroppedAtLast_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2ecaptures_2eputOffOn_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2eputOffOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2eputOffOn_entry, 4, 0};

V g_heff_2ecompile_2ecaptures_2eputOffOn(V v_go_240, V v_h_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_h_241);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_x42_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_CIf: {
      V v_c_246 = heff_dup(heff_field(v_x41_244, 0));
      V v_a_247 = heff_dup(heff_field(v_x41_244, 1));
      V v_b_248 = heff_dup(heff_field(v_x41_244, 2));
      switch (heff_tag_of(v_x42_245)) {
      case TAG_Nil: {
        heff_drop_tag(v_x41_244, 3);
        V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ekeeps_clo), 1, (V[]){heff_dup(v_h_241)}));
        V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_h_241; V a_2 = v_c_246; V r_ = (g_heff_2ecompile_2ecaptures_2ekeepsCond(a_0, a_1, a_2)); heff_drop(v_t_249); heff_drop(v_h_241); r_; });
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_n_242);
          heff_drop(v_t_2410);
          V v_t_2411 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_247}));
          V v_t_2412 = heff_tr(heff_call(v_go_240, 1, (V[]){v_b_248}));
          return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_c_246, v_t_2411, v_t_2412}), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_go_240);
          heff_drop(v_t_2410);
          V v_t_2413 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_c_246, v_a_247, v_b_248}), NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), v_t_2413});
        }
      }
      case TAG_Cons: {
        heff_drop(v_c_246);
        heff_drop(v_a_247);
        heff_drop(v_b_248);
        switch (heff_tag_of(v_x42_245)) {
        case TAG_Nil: {
          heff_drop(v_go_240);
          heff_drop(v_h_241);
          return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x41_244, v_x42_245})});
        }
        case TAG_Cons: {
          V v_t_2418 = (g_heff_2ecompile_2ecaptures_2ekeepsSt(v_h_241, v_x41_244));
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop(v_n_242);
            heff_drop(v_t_2418);
            V v_t_2419 = heff_tr(heff_call(v_go_240, 1, (V[]){v_x42_245}));
            return heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x41_244, v_t_2419});
          } else {
            heff_drop(v_go_240);
            heff_drop(v_t_2418);
            return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x41_244, v_x42_245})});
          }
        }
        default: return heff_nomatch(v_x42_245);
        }
      }
      default: return heff_nomatch(v_x42_245);
      }
    }
    case TAG_CSwitch: {
      V v_e_2420 = heff_dup(heff_field(v_x41_244, 0));
      V v_arms_2421 = heff_dup(heff_field(v_x41_244, 1));
      V v_r_2422 = heff_dup(heff_field(v_x41_244, 2));
      switch (heff_tag_of(v_x42_245)) {
      case TAG_Nil: {
        heff_drop_tag(v_x41_244, 3);
        V v_t_2423 = (g_heff_2ecompile_2ecaptures_2enames(v_h_241, heff_dup(v_e_2420)));
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_go_240);
          heff_drop(v_t_2423);
          V v_t_2424 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CSwitch, 3, (V[]){v_e_2420, v_arms_2421, v_r_2422}), NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), v_t_2424});
        } else {
          heff_drop(v_n_242);
          heff_drop(v_t_2423);
          V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecaptures_2eputOffOn_lam0, 1, 1, (V[]){v_go_240}), v_arms_2421));
          return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CSwitch, 3, (V[]){v_e_2420, v_t_2435, v_r_2422}), NTAG(TAG_Nil)});
        }
      }
      case TAG_Cons: {
        heff_drop(v_e_2420);
        heff_drop(v_arms_2421);
        heff_drop(v_r_2422);
        switch (heff_tag_of(v_x42_245)) {
        case TAG_Nil: {
          heff_drop(v_go_240);
          heff_drop(v_h_241);
          return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x41_244, v_x42_245})});
        }
        case TAG_Cons: {
          V v_t_2440 = (g_heff_2ecompile_2ecaptures_2ekeepsSt(v_h_241, v_x41_244));
          if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
            heff_drop(v_n_242);
            heff_drop(v_t_2440);
            V v_t_2441 = heff_tr(heff_call(v_go_240, 1, (V[]){v_x42_245}));
            return heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x41_244, v_t_2441});
          } else {
            heff_drop(v_go_240);
            heff_drop(v_t_2440);
            return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x41_244, v_x42_245})});
          }
        }
        default: return heff_nomatch(v_x42_245);
        }
      }
      default: return heff_nomatch(v_x42_245);
      }
    }
    default: {
      switch (heff_tag_of(v_x42_245)) {
      case TAG_Nil: {
        heff_drop(v_go_240);
        heff_drop(v_h_241);
        return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x41_244, v_x42_245})});
      }
      case TAG_Cons: {
        V v_t_2444 = (g_heff_2ecompile_2ecaptures_2ekeepsSt(v_h_241, v_x41_244));
        if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
          heff_drop(v_n_242);
          heff_drop(v_t_2444);
          V v_t_2445 = heff_tr(heff_call(v_go_240, 1, (V[]){v_x42_245}));
          return heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x41_244, v_t_2445});
        } else {
          heff_drop(v_go_240);
          heff_drop(v_t_2444);
          return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CTakeSelf, 1, (V[]){v_n_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x41_244, v_x42_245})});
        }
      }
      default: return heff_nomatch(v_x42_245);
      }
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecaptures_2eputOffOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecaptures_2eputOffOn(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecaptures_2eputOffOn_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_go_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkCArm: {
    V v_t_2426 = heff_field(v_x2_2425, 0);
    V v_fs_2427 = heff_field(v_x2_2425, 1);
    V v_fl_2428 = heff_field(v_x2_2425, 2);
    V v_su_2429 = heff_field(v_x2_2425, 3);
    V v_pl_2430 = heff_field(v_x2_2425, 4);
    V v_tk_2431 = heff_field(v_x2_2425, 5);
    V v_body_2432 = heff_field(v_x2_2425, 6);
    V v_lv_2433 = heff_field(v_x2_2425, 7);
    V v_ru_24x2_2425_24MkCArm = heff_take_reuse_n(v_x2_2425, 255ULL, 8);
    heff_clo_take(self, 1);
    V v_t_2434 = heff_tr(heff_call(v_go_240, 1, (V[]){v_body_2432}));
    return heff_tag_re_n(v_ru_24x2_2425_24MkCArm, TAG_MkCArm, 8, 191ULL, (V[]){v_t_2426, v_fs_2427, v_fl_2428, v_su_2429, v_pl_2430, v_tk_2431, v_t_2434, v_lv_2433});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2ecaptures_2eputOff_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2eputOff_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2eputOff_entry, 3, 0};

V g_heff_2ecompile_2ecaptures_2eputOff(V v_h_240, V v_n_241, V v_ss_242) {
top: ;
  V v_t_245 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2ecaptures_2eputOff_lam0, 1, 1, (V[]){heff_dup(v_h_240)}); V a_1 = v_ss_242; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); r_; });
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = (g_list_2eany_24s1602235202x783198227(v_h_240, v_ss_242));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_n_241);
      heff_drop(v_t_246);
      return ({ V a_0 = v_h_240; V a_1 = v_ss_242; V r_ = (g_heff_2ecompile_2ecaptures_2edroppedAtLast(a_0, a_1)); heff_drop(v_h_240); r_; });
    } else {
      heff_drop(v_t_246);
      V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2eputOff_clo), 2, (V[]){heff_dup(v_h_240), heff_dup(v_n_241)}));
      return (g_heff_2ecompile_2ecaptures_2eputOffOn(v_t_247, v_h_240, v_n_241, v_ss_242));
    }
  } else {
    heff_drop(v_t_245);
    V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2eputOff_clo), 2, (V[]){heff_dup(v_h_240), heff_dup(v_n_241)}));
    return (g_heff_2ecompile_2ecaptures_2eputOffOn(v_t_248, v_h_240, v_n_241, v_ss_242));
  }
}
V g_heff_2ecompile_2ecaptures_2eputOff_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecaptures_2eputOff(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecaptures_2eputOff_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_t_244 = (g_heff_2ecompile_2ecaptures_2edropsOne(heff_dup(v_h_240), v_s_243));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_s_243);
    heff_drop(self);
    heff_drop(v_t_244);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_244);
    heff_clo_take(self, 1);
    return ({ V a_0 = v_h_240; V a_1 = v_s_243; V r_ = (g_heff_2ecompile_2ecaptures_2ekeepsSt(a_0, a_1)); heff_drop(v_s_243); r_; });
  }
}
V g_heff_2ecompile_2ecaptures_2ecapExp_lam0(V self, V *args);
V g_heff_2ecompile_2ecaptures_2ecapExp_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2ecapExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ecapExp_entry, 3, 0};

V g_heff_2ecompile_2ecaptures_2ecapExp(V v_bor_240, V v_go_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_RLocal: {
    return v_x3_242;
  }
  case TAG_RDup: {
    return v_x3_242;
  }
  case TAG_RClo: {
    return v_x3_242;
  }
  case TAG_RGet: {
    return v_x3_242;
  }
  case TAG_RGetRaw: {
    return v_x3_242;
  }
  case TAG_RInt: {
    return v_x3_242;
  }
  case TAG_RFloat: {
    return v_x3_242;
  }
  case TAG_RStr: {
    return v_x3_242;
  }
  case TAG_RBytes: {
    return v_x3_242;
  }
  case TAG_RFixed: {
    return v_x3_242;
  }
  case TAG_RF32: {
    return v_x3_242;
  }
  case TAG_RNTag: {
    return v_x3_242;
  }
  case TAG_RStatic: {
    return v_x3_242;
  }
  case TAG_RTag: {
    V v_t_2418 = heff_field(v_x3_242, 0);
    V v_b_2419 = heff_field(v_x3_242, 1);
    V v_es_2420 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24RTag = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_2422 = (g_list_2emap(v_t_2421, v_es_2420));
    return heff_tag_re_n(v_ru_24x3_242_24RTag, TAG_RTag, 3, 3ULL, (V[]){v_t_2418, v_b_2419, v_t_2422});
  }
  case TAG_RTagIn: {
    V v_e_2423 = heff_field(v_x3_242, 0);
    V v_t_2424 = heff_field(v_x3_242, 1);
    V v_b_2425 = heff_field(v_x3_242, 2);
    V v_sm_2426 = heff_field(v_x3_242, 3);
    V v_es_2427 = heff_field(v_x3_242, 4);
    V v_ru_24x3_242_24RTagIn = heff_take_reuse_n(v_x3_242, 31ULL, 5);
    V v_t_2428 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2423));
    V v_t_2429 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_2430 = (g_list_2emap(v_t_2429, v_es_2427));
    return heff_tag_re_n(v_ru_24x3_242_24RTagIn, TAG_RTagIn, 5, 14ULL, (V[]){v_t_2428, v_t_2424, v_b_2425, v_sm_2426, v_t_2430});
  }
  case TAG_RRec: {
    V v_ls_2431 = heff_field(v_x3_242, 0);
    V v_b_2432 = heff_field(v_x3_242, 1);
    V v_es_2433 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24RRec = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_2435 = (g_list_2emap(v_t_2434, v_es_2433));
    return heff_tag_re_n(v_ru_24x3_242_24RRec, TAG_RRec, 3, 3ULL, (V[]){v_ls_2431, v_b_2432, v_t_2435});
  }
  case TAG_RRecIn: {
    V v_x_2436 = heff_field(v_x3_242, 0);
    V v_n_2437 = heff_field(v_x3_242, 1);
    V v_k_2438 = heff_field(v_x3_242, 2);
    V v_f_2439 = heff_field(v_x3_242, 3);
    V v_s_2440 = heff_field(v_x3_242, 4);
    V v_ls_2441 = heff_field(v_x3_242, 5);
    V v_fs_2442 = heff_field(v_x3_242, 6);
    V v_sure_2443 = heff_field(v_x3_242, 7);
    V v_ru_24x3_242_24RRecIn = heff_take_reuse_n(v_x3_242, 255ULL, 8);
    V v_t_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecaptures_2ecapExp_lam0, 1, 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}), v_fs_2442));
    return heff_tag_re_n(v_ru_24x3_242_24RRecIn, TAG_RRecIn, 8, 191ULL, (V[]){v_x_2436, v_n_2437, v_k_2438, v_f_2439, v_s_2440, v_ls_2441, v_t_2452, v_sure_2443});
  }
  case TAG_RField: {
    V v_e_2453 = heff_field(v_x3_242, 0);
    V v_i_2454 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RField = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2455 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2453));
    return heff_tag_re_n(v_ru_24x3_242_24RField, TAG_RField, 2, 2ULL, (V[]){v_t_2455, v_i_2454});
  }
  case TAG_RDupE: {
    V v_e_2456 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24RDupE = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_cell_2457 = heff_tag_at_n(v_ru_24x3_242_24RDupE, TAG_RDupE, 1, (V[]){heff_hole()});
    V v_u_2458 = (g_heff_2ecompile_2ecaptures_2ecapExp_24dps(v_bor_240, v_go_241, v_e_2456, v_cell_2457, MK_INT(0LL)));
    heff_drop(v_u_2458);
    return v_cell_2457;
  }
  case TAG_RFieldV: {
    V v_e_2459 = heff_field(v_x3_242, 0);
    V v_i_2460 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RFieldV = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2461 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2459));
    return heff_tag_re_n(v_ru_24x3_242_24RFieldV, TAG_RFieldV, 2, 2ULL, (V[]){v_t_2461, v_i_2460});
  }
  case TAG_RGetN: {
    V v_e_2462 = heff_field(v_x3_242, 0);
    V v_i_2463 = heff_field(v_x3_242, 1);
    V v_n_2464 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24RGetN = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2465 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2462));
    return heff_tag_re_n(v_ru_24x3_242_24RGetN, TAG_RGetN, 3, 6ULL, (V[]){v_t_2465, v_i_2463, v_n_2464});
  }
  case TAG_RFieldU: {
    V v_r_2466 = heff_field(v_x3_242, 0);
    V v_s_2467 = heff_field(v_x3_242, 1);
    V v_e_2468 = heff_field(v_x3_242, 2);
    V v_i_2469 = heff_field(v_x3_242, 3);
    V v_ru_24x3_242_24RFieldU = heff_take_reuse_n(v_x3_242, 15ULL, 4);
    V v_t_2470 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2468));
    return heff_tag_re_n(v_ru_24x3_242_24RFieldU, TAG_RFieldU, 4, 11ULL, (V[]){v_r_2466, v_s_2467, v_t_2470, v_i_2469});
  }
  case TAG_RGetNU: {
    V v_r_2471 = heff_field(v_x3_242, 0);
    V v_s_2472 = heff_field(v_x3_242, 1);
    V v_e_2473 = heff_field(v_x3_242, 2);
    V v_i_2474 = heff_field(v_x3_242, 3);
    V v_n_2475 = heff_field(v_x3_242, 4);
    V v_ru_24x3_242_24RGetNU = heff_take_reuse_n(v_x3_242, 31ULL, 5);
    V v_t_2476 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2473));
    return heff_tag_re_n(v_ru_24x3_242_24RGetNU, TAG_RGetNU, 5, 27ULL, (V[]){v_r_2471, v_s_2472, v_t_2476, v_i_2474, v_n_2475});
  }
  case TAG_RWord: {
    V v_r_2477 = heff_field(v_x3_242, 0);
    V v_e_2478 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RWord = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_cell_2479 = heff_tag_re_n(v_ru_24x3_242_24RWord, TAG_RWord, 2, 1ULL, (V[]){v_r_2477, heff_hole()});
    V v_u_2480 = (g_heff_2ecompile_2ecaptures_2ecapExp_24dps(v_bor_240, v_go_241, v_e_2478, v_cell_2479, MK_INT(1LL)));
    heff_drop(v_u_2480);
    return v_cell_2479;
  }
  case TAG_RTakeField: {
    return v_x3_242;
  }
  case TAG_RGetLabel: {
    V v_e_2483 = heff_field(v_x3_242, 0);
    V v_l_2484 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RGetLabel = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2485 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2483));
    return heff_tag_re_n(v_ru_24x3_242_24RGetLabel, TAG_RGetLabel, 2, 2ULL, (V[]){v_t_2485, v_l_2484});
  }
  case TAG_RPrimFn: {
    return v_x3_242;
  }
  case TAG_RPrim: {
    V v_p_2487 = heff_field(v_x3_242, 0);
    V v_es_2488 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RPrim = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2489 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_2490 = (g_list_2emap(v_t_2489, v_es_2488));
    return heff_tag_re_n(v_ru_24x3_242_24RPrim, TAG_RPrim, 2, 1ULL, (V[]){v_p_2487, v_t_2490});
  }
  case TAG_RLam: {
    V v_xs_2491 = heff_field(v_x3_242, 0);
    V v_fv_2492 = heff_field(v_x3_242, 1);
    V v_held_2493 = heff_field(v_x3_242, 2);
    V v_x34_2494 = heff_field(v_x3_242, 3);
    V v_ru_24x3_242_24RLam = heff_take_reuse_n(v_x3_242, 15ULL, 4);
    switch (heff_tag_of(v_x34_2494)) {
    case TAG_MkCode: {
      V v_body_2495 = heff_field(v_x34_2494, 0);
      V v_ru_24x34_2494_24MkCode = heff_take_reuse_n(v_x34_2494, 1ULL, 1);
      V v_t_2496 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
      V v_t_2497 = (g_list_2emap(v_t_2496, v_held_2493));
      V v_bor_2498 = heff_dup(v_bor_240);
      V v_fv_2499 = heff_dup(v_fv_2492);
      V v_ss_24100 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_body_2495}));
      V v_t_24134;
      switch (heff_tag_of(v_ss_24100)) {
      case TAG_Nil: {
        heff_drop(v_bor_2498);
        heff_drop(v_fv_2499);
        v_t_24134 = v_ss_24100;
        break;
      }
      case TAG_Cons: {
        V v_ss1_24101 = heff_dup(heff_field(v_ss_24100, 0));
        switch (heff_tag_of(v_ss1_24101)) {
        case TAG_CDrop: {
          heff_take_n(v_ss1_24101, 0ULL, 1);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CLet: {
          heff_take_n(v_ss1_24101, 0ULL, 2);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CDecl: {
          heff_take_n(v_ss1_24101, 0ULL, 1);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CSet: {
          heff_take_n(v_ss1_24101, 0ULL, 2);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CAbandon: {
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CIf: {
          heff_take_n(v_ss1_24101, 0ULL, 3);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CSwitch: {
          heff_take_n(v_ss1_24101, 0ULL, 3);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CReturn: {
          heff_take_n(v_ss1_24101, 0ULL, 1);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CInPlace: {
          heff_take_n(v_ss1_24101, 0ULL, 2);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CRoomed: {
          heff_take_n(v_ss1_24101, 0ULL, 2);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CTail: {
          heff_take_n(v_ss1_24101, 0ULL, 2);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CLoop: {
          heff_take_n(v_ss1_24101, 0ULL, 2);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CLoopTo: {
          heff_take_n(v_ss1_24101, 0ULL, 3);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CLabel: {
          heff_take_n(v_ss1_24101, 0ULL, 1);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CJump: {
          heff_take_n(v_ss1_24101, 0ULL, 3);
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        case TAG_CTakeSelf: {
          V v_n_24131 = heff_field(v_ss1_24101, 0);
          heff_take_n(v_ss1_24101, 1ULL, 1);
          switch (heff_tag_of(v_ss_24100)) {
          case TAG_Cons: {
            V v_rest_24133 = heff_field(v_ss_24100, 1);
            heff_take_n(v_ss_24100, 2ULL, 2);
            v_t_24134 = (g_heff_2ecompile_2ecaptures_2eputOff(heff_rec_n(2, shape_cs__bor, (V[]){v_fv_2499, v_bor_2498}), v_n_24131, v_rest_24133));
            break;
          }
          default: heff_nomatch(v_ss_24100);
          }
          break;
        }
        case TAG_CDropSelf: {
          heff_drop(v_bor_2498);
          heff_drop(v_fv_2499);
          v_t_24134 = v_ss_24100;
          break;
        }
        default: heff_nomatch(v_ss1_24101);
        }
        break;
      }
      default: heff_nomatch(v_ss_24100);
      }
      return heff_tag_re_n(v_ru_24x3_242_24RLam, TAG_RLam, 4, 3ULL, (V[]){v_xs_2491, v_fv_2492, v_t_2497, heff_tag_at_n(v_ru_24x34_2494_24MkCode, TAG_MkCode, 1, (V[]){v_t_24134})});
    }
    default: return heff_nomatch(v_x34_2494);
    }
  }
  case TAG_RCall: {
    V v_g_24135 = heff_field(v_x3_242, 0);
    V v_tr_24136 = heff_field(v_x3_242, 1);
    V v_w_24137 = heff_field(v_x3_242, 2);
    V v_args_24138 = heff_field(v_x3_242, 3);
    V v_ru_24x3_242_24RCall = heff_take_reuse_n(v_x3_242, 15ULL, 4);
    V v_f_24139 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24150 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecaptures_2ecapExp_lam1, 1, 1, (V[]){v_f_24139}), v_args_24138));
    return heff_tag_re_n(v_ru_24x3_242_24RCall, TAG_RCall, 4, 7ULL, (V[]){v_g_24135, v_tr_24136, v_w_24137, v_t_24150});
  }
  case TAG_RApply: {
    V v_f_24151 = heff_field(v_x3_242, 0);
    V v_es_24152 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RApply = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24153 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_f_24151));
    V v_t_24154 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24155 = (g_list_2emap(v_t_24154, v_es_24152));
    return heff_tag_at_n(v_ru_24x3_242_24RApply, TAG_RApply, 2, (V[]){v_t_24153, v_t_24155});
  }
  case TAG_RBool: {
    V v_c_24156 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24RBool = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_24157 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24158 = ({ V a_0 = v_t_24157; V a_1 = v_c_24156; V r_ = (g_heff_2ecompile_2eowned_2emapCond(a_0, a_1)); heff_drop(v_t_24157); r_; });
    return heff_tag_at_n(v_ru_24x3_242_24RBool, TAG_RBool, 1, (V[]){v_t_24158});
  }
  case TAG_RAbandon: {
    return v_x3_242;
  }
  case TAG_RBox: {
    V v_r_24159 = heff_field(v_x3_242, 0);
    V v_e_24160 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RBox = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_cell_24161 = heff_tag_re_n(v_ru_24x3_242_24RBox, TAG_RBox, 2, 1ULL, (V[]){v_r_24159, heff_hole()});
    V v_u_24162 = (g_heff_2ecompile_2ecaptures_2ecapExp_24dps(v_bor_240, v_go_241, v_e_24160, v_cell_24161, MK_INT(1LL)));
    heff_drop(v_u_24162);
    return v_cell_24161;
  }
  case TAG_RUnbox: {
    V v_r_24163 = heff_field(v_x3_242, 0);
    V v_e_24164 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RUnbox = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_cell_24165 = heff_tag_re_n(v_ru_24x3_242_24RUnbox, TAG_RUnbox, 2, 1ULL, (V[]){v_r_24163, heff_hole()});
    V v_u_24166 = (g_heff_2ecompile_2ecaptures_2ecapExp_24dps(v_bor_240, v_go_241, v_e_24164, v_cell_24165, MK_INT(1LL)));
    heff_drop(v_u_24166);
    return v_cell_24165;
  }
  case TAG_RPeek: {
    V v_r_24167 = heff_field(v_x3_242, 0);
    V v_e_24168 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RPeek = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_cell_24169 = heff_tag_re_n(v_ru_24x3_242_24RPeek, TAG_RPeek, 2, 1ULL, (V[]){v_r_24167, heff_hole()});
    V v_u_24170 = (g_heff_2ecompile_2ecaptures_2ecapExp_24dps(v_bor_240, v_go_241, v_e_24168, v_cell_24169, MK_INT(1LL)));
    heff_drop(v_u_24170);
    return v_cell_24169;
  }
  case TAG_RPrimU: {
    V v_p_24171 = heff_field(v_x3_242, 0);
    V v_es_24172 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RPrimU = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24173 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24174 = (g_list_2emap(v_t_24173, v_es_24172));
    return heff_tag_re_n(v_ru_24x3_242_24RPrimU, TAG_RPrimU, 2, 1ULL, (V[]){v_p_24171, v_t_24174});
  }
  case TAG_RPrimAt: {
    V v_p_24175 = heff_field(v_x3_242, 0);
    V v_r_24176 = heff_field(v_x3_242, 1);
    V v_es_24177 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24RPrimAt = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_24178 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24179 = (g_list_2emap(v_t_24178, v_es_24177));
    return heff_tag_re_n(v_ru_24x3_242_24RPrimAt, TAG_RPrimAt, 3, 3ULL, (V[]){v_p_24175, v_r_24176, v_t_24179});
  }
  case TAG_RFixU: {
    return v_x3_242;
  }
  case TAG_RF32U: {
    return v_x3_242;
  }
  case TAG_RF64U: {
    return v_x3_242;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecaptures_2ecapExp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecaptures_2ecapExp(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecaptures_2ecapExp_lam0(V self, V *args) {
  V v_p_2444 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_go_241 = heff_env(self)[1];
  V v_t_2447;
  switch (heff_tag_of(v_p_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_dup(heff_field(v_p_2444, 0));
    v_t_2447 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_p_2444);
  }
  V v_t_2450;
  switch (heff_tag_of(v_p_2444)) {
  case TAG_MkPair: {
    V v_y_2449 = heff_field(v_p_2444, 1);
    heff_take_n(v_p_2444, 2ULL, 2);
    v_t_2450 = v_y_2449;
    break;
  }
  default: heff_nomatch(v_p_2444);
  }
  heff_clo_take(self, 2);
  V v_t_2451 = ({ V a_0 = v_bor_240; V a_1 = v_go_241; V a_2 = v_t_2450; V r_ = (g_heff_2ecompile_2ecaptures_2ecapExp(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_go_241); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2447, v_t_2451});
}
V g_heff_2ecompile_2ecaptures_2ecapExp_lam1(V self, V *args) {
  V v_a_24140 = args[0];
  V v_f_24139 = heff_env(self)[0];
  switch (heff_tag_of(v_a_24140)) {
  case TAG_Given: {
    V v_e_24141 = heff_field(v_a_24140, 0);
    V v_ru_24a_24140_24Given = heff_take_reuse_n(v_a_24140, 1ULL, 1);
    heff_clo_take(self, 1);
    V v_t_24142 = heff_tr(heff_call(v_f_24139, 1, (V[]){v_e_24141}));
    return heff_tag_at_n(v_ru_24a_24140_24Given, TAG_Given, 1, (V[]){v_t_24142});
  }
  case TAG_GivenU: {
    V v_r_24143 = heff_field(v_a_24140, 0);
    V v_e_24144 = heff_field(v_a_24140, 1);
    V v_ru_24a_24140_24GivenU = heff_take_reuse_n(v_a_24140, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_t_24145 = heff_tr(heff_call(v_f_24139, 1, (V[]){v_e_24144}));
    return heff_tag_re_n(v_ru_24a_24140_24GivenU, TAG_GivenU, 2, 1ULL, (V[]){v_r_24143, v_t_24145});
  }
  case TAG_LentVar: {
    heff_drop(self);
    return v_a_24140;
  }
  case TAG_LentValue: {
    V v_e_24148 = heff_field(v_a_24140, 0);
    V v_ru_24a_24140_24LentValue = heff_take_reuse_n(v_a_24140, 1ULL, 1);
    heff_clo_take(self, 1);
    V v_t_24149 = heff_tr(heff_call(v_f_24139, 1, (V[]){v_e_24148}));
    return heff_tag_at_n(v_ru_24a_24140_24LentValue, TAG_LentValue, 1, (V[]){v_t_24149});
  }
  default: return heff_nomatch(v_a_24140);
  }
}
V g_heff_2ecompile_2ecaptures_2ecapExp_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2ecaptures_2ecapExp_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2ecapExp_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ecapExp_24dps_entry, 5, 0};

V g_heff_2ecompile_2ecaptures_2ecapExp_24dps(V v_bor_240, V v_go_241, V v_x3_242, V v_d_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_RLocal: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RDup: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RClo: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RGet: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RGetRaw: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RInt: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RFloat: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RStr: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RBytes: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RFixed: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RF32: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RNTag: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RStatic: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RTag: {
    V v_t_2420 = heff_field(v_x3_242, 0);
    V v_b_2421 = heff_field(v_x3_242, 1);
    V v_es_2422 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_2424 = (g_list_2emap(v_t_2423, v_es_2422));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RTag, 3, (V[]){v_t_2420, v_b_2421, v_t_2424}));
  }
  case TAG_RTagIn: {
    V v_e_2425 = heff_field(v_x3_242, 0);
    V v_t_2426 = heff_field(v_x3_242, 1);
    V v_b_2427 = heff_field(v_x3_242, 2);
    V v_sm_2428 = heff_field(v_x3_242, 3);
    V v_es_2429 = heff_field(v_x3_242, 4);
    heff_take_n(v_x3_242, 31ULL, 5);
    V v_t_2430 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2425));
    V v_t_2431 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_2432 = (g_list_2emap(v_t_2431, v_es_2429));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RTagIn, 5, (V[]){v_t_2430, v_t_2426, v_b_2427, v_sm_2428, v_t_2432}));
  }
  case TAG_RRec: {
    V v_ls_2433 = heff_field(v_x3_242, 0);
    V v_b_2434 = heff_field(v_x3_242, 1);
    V v_es_2435 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_2437 = (g_list_2emap(v_t_2436, v_es_2435));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RRec, 3, (V[]){v_ls_2433, v_b_2434, v_t_2437}));
  }
  case TAG_RRecIn: {
    V v_x_2438 = heff_field(v_x3_242, 0);
    V v_n_2439 = heff_field(v_x3_242, 1);
    V v_k_2440 = heff_field(v_x3_242, 2);
    V v_f_2441 = heff_field(v_x3_242, 3);
    V v_s_2442 = heff_field(v_x3_242, 4);
    V v_ls_2443 = heff_field(v_x3_242, 5);
    V v_fs_2444 = heff_field(v_x3_242, 6);
    V v_sure_2445 = heff_field(v_x3_242, 7);
    heff_take_n(v_x3_242, 255ULL, 8);
    V v_t_2454 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecaptures_2ecapExp_24dps_lam0, 1, 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}), v_fs_2444));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RRecIn, 8, (V[]){v_x_2438, v_n_2439, v_k_2440, v_f_2441, v_s_2442, v_ls_2443, v_t_2454, v_sure_2445}));
  }
  case TAG_RField: {
    V v_e_2455 = heff_field(v_x3_242, 0);
    V v_i_2456 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2457 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2455));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RField, 2, (V[]){v_t_2457, v_i_2456}));
  }
  case TAG_RDupE: {
    V v_e_2458 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24RDupE = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_cell_2459 = heff_tag_at_n(v_ru_24x3_242_24RDupE, TAG_RDupE, 1, (V[]){heff_hole()});
    V v_u_2460 = heff_setFieldPeek(v_d_243, heff_dup(v_i_244), v_cell_2459);
    V t_0 = v_bor_240;
    V t_1 = v_go_241;
    V t_2 = v_e_2458;
    V t_3 = v_u_2460;
    V t_4 = MK_INT(0LL);
    v_bor_240 = t_0;
    v_go_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_RFieldV: {
    V v_e_2461 = heff_field(v_x3_242, 0);
    V v_i_2462 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2463 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2461));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RFieldV, 2, (V[]){v_t_2463, v_i_2462}));
  }
  case TAG_RGetN: {
    V v_e_2464 = heff_field(v_x3_242, 0);
    V v_i_2465 = heff_field(v_x3_242, 1);
    V v_n_2466 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_2467 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2464));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RGetN, 3, (V[]){v_t_2467, v_i_2465, v_n_2466}));
  }
  case TAG_RFieldU: {
    V v_r_2468 = heff_field(v_x3_242, 0);
    V v_s_2469 = heff_field(v_x3_242, 1);
    V v_e_2470 = heff_field(v_x3_242, 2);
    V v_i_2471 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 15ULL, 4);
    V v_t_2472 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2470));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RFieldU, 4, (V[]){v_r_2468, v_s_2469, v_t_2472, v_i_2471}));
  }
  case TAG_RGetNU: {
    V v_r_2473 = heff_field(v_x3_242, 0);
    V v_s_2474 = heff_field(v_x3_242, 1);
    V v_e_2475 = heff_field(v_x3_242, 2);
    V v_i_2476 = heff_field(v_x3_242, 3);
    V v_n_2477 = heff_field(v_x3_242, 4);
    heff_take_n(v_x3_242, 31ULL, 5);
    V v_t_2478 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2475));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RGetNU, 5, (V[]){v_r_2473, v_s_2474, v_t_2478, v_i_2476, v_n_2477}));
  }
  case TAG_RWord: {
    V v_r_2479 = heff_field(v_x3_242, 0);
    V v_e_2480 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RWord = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_cell_2481 = heff_tag_re_n(v_ru_24x3_242_24RWord, TAG_RWord, 2, 1ULL, (V[]){v_r_2479, heff_hole()});
    V v_u_2482 = heff_setFieldPeek(v_d_243, heff_dup(v_i_244), v_cell_2481);
    V t_0 = v_bor_240;
    V t_1 = v_go_241;
    V t_2 = v_e_2480;
    V t_3 = v_u_2482;
    V t_4 = MK_INT(1LL);
    v_bor_240 = t_0;
    v_go_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_RTakeField: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RGetLabel: {
    V v_e_2485 = heff_field(v_x3_242, 0);
    V v_l_2486 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2487 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_e_2485));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_2487, v_l_2486}));
  }
  case TAG_RPrimFn: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RPrim: {
    V v_p_2489 = heff_field(v_x3_242, 0);
    V v_es_2490 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RPrim = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2491 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_2492 = (g_list_2emap_24tok2(v_ru_24x3_242_24RPrim, v_t_2491, v_es_2490));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RPrim, 2, (V[]){v_p_2489, v_t_2492}));
  }
  case TAG_RLam: {
    V v_xs_2493 = heff_field(v_x3_242, 0);
    V v_fv_2494 = heff_field(v_x3_242, 1);
    V v_held_2495 = heff_field(v_x3_242, 2);
    V v_x34_2496 = heff_field(v_x3_242, 3);
    V v_ru_24x3_242_24RLam = heff_take_reuse_n(v_x3_242, 15ULL, 4);
    switch (heff_tag_of(v_x34_2496)) {
    case TAG_MkCode: {
      V v_body_2497 = heff_field(v_x34_2496, 0);
      V v_ru_24x34_2496_24MkCode = heff_take_reuse_n(v_x34_2496, 1ULL, 1);
      V v_t_2498 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
      V v_t_2499 = (g_list_2emap(v_t_2498, v_held_2495));
      V v_bor_24100 = heff_dup(v_bor_240);
      V v_fv_24101 = heff_dup(v_fv_2494);
      V v_ss_24102 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_body_2497}));
      V v_t_24136;
      switch (heff_tag_of(v_ss_24102)) {
      case TAG_Nil: {
        heff_drop(v_bor_24100);
        heff_drop(v_fv_24101);
        v_t_24136 = v_ss_24102;
        break;
      }
      case TAG_Cons: {
        V v_ss1_24103 = heff_dup(heff_field(v_ss_24102, 0));
        switch (heff_tag_of(v_ss1_24103)) {
        case TAG_CDrop: {
          heff_take_n(v_ss1_24103, 0ULL, 1);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CLet: {
          heff_take_n(v_ss1_24103, 0ULL, 2);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CDecl: {
          heff_take_n(v_ss1_24103, 0ULL, 1);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CSet: {
          heff_take_n(v_ss1_24103, 0ULL, 2);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CAbandon: {
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CIf: {
          heff_take_n(v_ss1_24103, 0ULL, 3);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CSwitch: {
          heff_take_n(v_ss1_24103, 0ULL, 3);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CReturn: {
          heff_take_n(v_ss1_24103, 0ULL, 1);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CInPlace: {
          heff_take_n(v_ss1_24103, 0ULL, 2);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CRoomed: {
          heff_take_n(v_ss1_24103, 0ULL, 2);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CTail: {
          heff_take_n(v_ss1_24103, 0ULL, 2);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CLoop: {
          heff_take_n(v_ss1_24103, 0ULL, 2);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CLoopTo: {
          heff_take_n(v_ss1_24103, 0ULL, 3);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CLabel: {
          heff_take_n(v_ss1_24103, 0ULL, 1);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CJump: {
          heff_take_n(v_ss1_24103, 0ULL, 3);
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        case TAG_CTakeSelf: {
          V v_n_24133 = heff_field(v_ss1_24103, 0);
          heff_take_n(v_ss1_24103, 1ULL, 1);
          switch (heff_tag_of(v_ss_24102)) {
          case TAG_Cons: {
            V v_rest_24135 = heff_field(v_ss_24102, 1);
            heff_take_n(v_ss_24102, 2ULL, 2);
            v_t_24136 = (g_heff_2ecompile_2ecaptures_2eputOff(heff_rec_n(2, shape_cs__bor, (V[]){v_fv_24101, v_bor_24100}), v_n_24133, v_rest_24135));
            break;
          }
          default: heff_nomatch(v_ss_24102);
          }
          break;
        }
        case TAG_CDropSelf: {
          heff_drop(v_bor_24100);
          heff_drop(v_fv_24101);
          v_t_24136 = v_ss_24102;
          break;
        }
        default: heff_nomatch(v_ss1_24103);
        }
        break;
      }
      default: heff_nomatch(v_ss_24102);
      }
      V v_t_24137 = heff_tag_re_n(v_ru_24x3_242_24RLam, TAG_RLam, 4, 3ULL, (V[]){v_xs_2493, v_fv_2494, v_t_2499, heff_tag_at_n(v_ru_24x34_2496_24MkCode, TAG_MkCode, 1, (V[]){v_t_24136})});
      return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_t_24137);
    }
    default: return heff_nomatch(v_x34_2496);
    }
  }
  case TAG_RCall: {
    V v_g_24138 = heff_field(v_x3_242, 0);
    V v_tr_24139 = heff_field(v_x3_242, 1);
    V v_w_24140 = heff_field(v_x3_242, 2);
    V v_args_24141 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 15ULL, 4);
    V v_f_24142 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24153 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecaptures_2ecapExp_24dps_lam1, 1, 1, (V[]){v_f_24142}), v_args_24141));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RCall, 4, (V[]){v_g_24138, v_tr_24139, v_w_24140, v_t_24153}));
  }
  case TAG_RApply: {
    V v_f_24154 = heff_field(v_x3_242, 0);
    V v_es_24155 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RApply = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24156 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_f_24154));
    V v_t_24157 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24158 = (g_list_2emap_24tok2(v_ru_24x3_242_24RApply, v_t_24157, v_es_24155));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RApply, 2, (V[]){v_t_24156, v_t_24158}));
  }
  case TAG_RBool: {
    V v_c_24159 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_24160 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24161 = ({ V a_0 = v_t_24160; V a_1 = v_c_24159; V r_ = (g_heff_2ecompile_2eowned_2emapCond(a_0, a_1)); heff_drop(v_t_24160); r_; });
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RBool, 1, (V[]){v_t_24161}));
  }
  case TAG_RAbandon: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RBox: {
    V v_r_24162 = heff_field(v_x3_242, 0);
    V v_e_24163 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RBox = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_cell_24164 = heff_tag_re_n(v_ru_24x3_242_24RBox, TAG_RBox, 2, 1ULL, (V[]){v_r_24162, heff_hole()});
    V v_u_24165 = heff_setFieldPeek(v_d_243, heff_dup(v_i_244), v_cell_24164);
    V t_0 = v_bor_240;
    V t_1 = v_go_241;
    V t_2 = v_e_24163;
    V t_3 = v_u_24165;
    V t_4 = MK_INT(1LL);
    v_bor_240 = t_0;
    v_go_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_RUnbox: {
    V v_r_24166 = heff_field(v_x3_242, 0);
    V v_e_24167 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RUnbox = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_cell_24168 = heff_tag_re_n(v_ru_24x3_242_24RUnbox, TAG_RUnbox, 2, 1ULL, (V[]){v_r_24166, heff_hole()});
    V v_u_24169 = heff_setFieldPeek(v_d_243, heff_dup(v_i_244), v_cell_24168);
    V t_0 = v_bor_240;
    V t_1 = v_go_241;
    V t_2 = v_e_24167;
    V t_3 = v_u_24169;
    V t_4 = MK_INT(1LL);
    v_bor_240 = t_0;
    v_go_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_RPeek: {
    V v_r_24170 = heff_field(v_x3_242, 0);
    V v_e_24171 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RPeek = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_cell_24172 = heff_tag_re_n(v_ru_24x3_242_24RPeek, TAG_RPeek, 2, 1ULL, (V[]){v_r_24170, heff_hole()});
    V v_u_24173 = heff_setFieldPeek(v_d_243, heff_dup(v_i_244), v_cell_24172);
    V t_0 = v_bor_240;
    V t_1 = v_go_241;
    V t_2 = v_e_24171;
    V t_3 = v_u_24173;
    V t_4 = MK_INT(1LL);
    v_bor_240 = t_0;
    v_go_241 = t_1;
    v_x3_242 = t_2;
    v_d_243 = t_3;
    v_i_244 = t_4;
    goto top;
  }
  case TAG_RPrimU: {
    V v_p_24174 = heff_field(v_x3_242, 0);
    V v_es_24175 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24RPrimU = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24176 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24177 = (g_list_2emap_24tok2(v_ru_24x3_242_24RPrimU, v_t_24176, v_es_24175));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RPrimU, 2, (V[]){v_p_24174, v_t_24177}));
  }
  case TAG_RPrimAt: {
    V v_p_24178 = heff_field(v_x3_242, 0);
    V v_r_24179 = heff_field(v_x3_242, 1);
    V v_es_24180 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_24181 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){heff_dup(v_bor_240), heff_dup(v_go_241)}));
    V v_t_24182 = (g_list_2emap(v_t_24181, v_es_24180));
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_24178, v_r_24179, v_t_24182}));
  }
  case TAG_RFixU: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RF32U: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  case TAG_RF64U: {
    return heff_setField(heff_dup(v_d_243), heff_dup(v_i_244), v_x3_242);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecaptures_2ecapExp_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2ecaptures_2ecapExp_24dps(a0, a1, a[2], a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ecompile_2ecaptures_2ecapExp_24dps_lam0(V self, V *args) {
  V v_p_2446 = args[0];
  V v_bor_240 = heff_env(self)[0];
  V v_go_241 = heff_env(self)[1];
  V v_t_2449;
  switch (heff_tag_of(v_p_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_dup(heff_field(v_p_2446, 0));
    v_t_2449 = v_x_2447;
    break;
  }
  default: heff_nomatch(v_p_2446);
  }
  V v_t_2452;
  switch (heff_tag_of(v_p_2446)) {
  case TAG_MkPair: {
    V v_y_2451 = heff_field(v_p_2446, 1);
    heff_take_n(v_p_2446, 2ULL, 2);
    v_t_2452 = v_y_2451;
    break;
  }
  default: heff_nomatch(v_p_2446);
  }
  heff_clo_take(self, 2);
  V v_t_2453 = ({ V a_0 = v_bor_240; V a_1 = v_go_241; V a_2 = v_t_2452; V r_ = (g_heff_2ecompile_2ecaptures_2ecapExp(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_go_241); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2449, v_t_2453});
}
V g_heff_2ecompile_2ecaptures_2ecapExp_24dps_lam1(V self, V *args) {
  V v_a_24143 = args[0];
  V v_f_24142 = heff_env(self)[0];
  switch (heff_tag_of(v_a_24143)) {
  case TAG_Given: {
    V v_e_24144 = heff_field(v_a_24143, 0);
    V v_ru_24a_24143_24Given = heff_take_reuse_n(v_a_24143, 1ULL, 1);
    heff_clo_take(self, 1);
    V v_t_24145 = heff_tr(heff_call(v_f_24142, 1, (V[]){v_e_24144}));
    return heff_tag_at_n(v_ru_24a_24143_24Given, TAG_Given, 1, (V[]){v_t_24145});
  }
  case TAG_GivenU: {
    V v_r_24146 = heff_field(v_a_24143, 0);
    V v_e_24147 = heff_field(v_a_24143, 1);
    V v_ru_24a_24143_24GivenU = heff_take_reuse_n(v_a_24143, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_t_24148 = heff_tr(heff_call(v_f_24142, 1, (V[]){v_e_24147}));
    return heff_tag_re_n(v_ru_24a_24143_24GivenU, TAG_GivenU, 2, 1ULL, (V[]){v_r_24146, v_t_24148});
  }
  case TAG_LentVar: {
    heff_drop(self);
    return v_a_24143;
  }
  case TAG_LentValue: {
    V v_e_24151 = heff_field(v_a_24143, 0);
    V v_ru_24a_24143_24LentValue = heff_take_reuse_n(v_a_24143, 1ULL, 1);
    heff_clo_take(self, 1);
    V v_t_24152 = heff_tr(heff_call(v_f_24142, 1, (V[]){v_e_24151}));
    return heff_tag_at_n(v_ru_24a_24143_24LentValue, TAG_LentValue, 1, (V[]){v_t_24152});
  }
  default: return heff_nomatch(v_a_24143);
  }
}
V g_heff_2ecompile_2ecaptures_2ecapSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecaptures_2ecapSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ecapSt_entry, 3, 0};

V g_heff_2ecompile_2ecaptures_2ecapSt(V v_bor_240, V v_go_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_CDrop: {
    heff_drop(v_bor_240);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CLet: {
    V v_x_244 = heff_field(v_s_242, 0);
    V v_e_245 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CLet = heff_take_reuse_n(v_s_242, 3ULL, 2);
    V v_t_246 = ({ V a_0 = v_bor_240; V a_1 = v_go_241; V a_2 = v_e_245; V r_ = (g_heff_2ecompile_2ecaptures_2ecapExp(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_go_241); r_; });
    return heff_tag_re_n(v_ru_24s_242_24CLet, TAG_CLet, 2, 1ULL, (V[]){v_x_244, v_t_246});
  }
  case TAG_CDecl: {
    heff_drop(v_bor_240);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CSet: {
    V v_x_248 = heff_field(v_s_242, 0);
    V v_e_249 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CSet = heff_take_reuse_n(v_s_242, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = v_bor_240; V a_1 = v_go_241; V a_2 = v_e_249; V r_ = (g_heff_2ecompile_2ecaptures_2ecapExp(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_go_241); r_; });
    return heff_tag_re_n(v_ru_24s_242_24CSet, TAG_CSet, 2, 1ULL, (V[]){v_x_248, v_t_2410});
  }
  case TAG_CAbandon: {
    heff_drop(v_bor_240);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CIf: {
    V v_c_2411 = heff_field(v_s_242, 0);
    V v_a_2412 = heff_field(v_s_242, 1);
    V v_b_2413 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CIf = heff_take_reuse_n(v_s_242, 7ULL, 3);
    V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){v_bor_240, heff_dup(v_go_241)}));
    V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_c_2411; V r_ = (g_heff_2ecompile_2eowned_2emapCond(a_0, a_1)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_a_2412}));
    V v_t_2417 = heff_tr(heff_call(v_go_241, 1, (V[]){v_b_2413}));
    return heff_tag_at_n(v_ru_24s_242_24CIf, TAG_CIf, 3, (V[]){v_t_2415, v_t_2416, v_t_2417});
  }
  case TAG_CSwitch: {
    V v_e_2418 = heff_field(v_s_242, 0);
    V v_arms_2419 = heff_field(v_s_242, 1);
    V v_r_2420 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CSwitch = heff_take_reuse_n(v_s_242, 7ULL, 3);
    V v_t_2421 = ({ V a_0 = v_bor_240; V a_1 = v_go_241; V a_2 = v_e_2418; V r_ = (g_heff_2ecompile_2ecaptures_2ecapExp(a_0, a_1, a_2)); heff_drop(v_bor_240); r_; });
    V v_t_2432 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecaptures_2ecapSt_lam0, 1, 1, (V[]){v_go_241}), v_arms_2419));
    return heff_tag_re_n(v_ru_24s_242_24CSwitch, TAG_CSwitch, 3, 4ULL, (V[]){v_t_2421, v_t_2432, v_r_2420});
  }
  case TAG_CReturn: {
    V v_e_2433 = heff_field(v_s_242, 0);
    V v_ru_24s_242_24CReturn = heff_take_reuse_n(v_s_242, 1ULL, 1);
    V v_t_2434 = ({ V a_0 = v_bor_240; V a_1 = v_go_241; V a_2 = v_e_2433; V r_ = (g_heff_2ecompile_2ecaptures_2ecapExp(a_0, a_1, a_2)); heff_drop(v_bor_240); heff_drop(v_go_241); r_; });
    return heff_tag_at_n(v_ru_24s_242_24CReturn, TAG_CReturn, 1, (V[]){v_t_2434});
  }
  case TAG_CInPlace: {
    V v_f_2435 = heff_field(v_s_242, 0);
    V v_es_2436 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CInPlace = heff_take_reuse_n(v_s_242, 3ULL, 2);
    V v_t_2437 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_f_2435));
    V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){v_bor_240, v_go_241}));
    V v_t_2439 = (g_list_2emap(v_t_2438, v_es_2436));
    return heff_tag_at_n(v_ru_24s_242_24CInPlace, TAG_CInPlace, 2, (V[]){v_t_2437, v_t_2439});
  }
  case TAG_CRoomed: {
    V v_f_2440 = heff_field(v_s_242, 0);
    V v_es_2441 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CRoomed = heff_take_reuse_n(v_s_242, 3ULL, 2);
    V v_t_2442 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_f_2440));
    V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){v_bor_240, v_go_241}));
    V v_t_2444 = (g_list_2emap(v_t_2443, v_es_2441));
    return heff_tag_at_n(v_ru_24s_242_24CRoomed, TAG_CRoomed, 2, (V[]){v_t_2442, v_t_2444});
  }
  case TAG_CTail: {
    V v_f_2445 = heff_field(v_s_242, 0);
    V v_es_2446 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CTail = heff_take_reuse_n(v_s_242, 3ULL, 2);
    V v_t_2447 = (g_heff_2ecompile_2ecaptures_2ecapExp(v_bor_240, v_go_241, v_f_2445));
    V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){v_bor_240, v_go_241}));
    V v_t_2449 = (g_list_2emap(v_t_2448, v_es_2446));
    return heff_tag_at_n(v_ru_24s_242_24CTail, TAG_CTail, 2, (V[]){v_t_2447, v_t_2449});
  }
  case TAG_CLoop: {
    V v_ps_2450 = heff_field(v_s_242, 0);
    V v_es_2451 = heff_field(v_s_242, 1);
    V v_ru_24s_242_24CLoop = heff_take_reuse_n(v_s_242, 3ULL, 2);
    V v_t_2452 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){v_bor_240, v_go_241}));
    V v_t_2453 = (g_list_2emap(v_t_2452, v_es_2451));
    return heff_tag_re_n(v_ru_24s_242_24CLoop, TAG_CLoop, 2, 1ULL, (V[]){v_ps_2450, v_t_2453});
  }
  case TAG_CLoopTo: {
    V v_t_2454 = heff_field(v_s_242, 0);
    V v_ps_2455 = heff_field(v_s_242, 1);
    V v_es_2456 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CLoopTo = heff_take_reuse_n(v_s_242, 7ULL, 3);
    V v_t_2457 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){v_bor_240, v_go_241}));
    V v_t_2458 = (g_list_2emap(v_t_2457, v_es_2456));
    return heff_tag_re_n(v_ru_24s_242_24CLoopTo, TAG_CLoopTo, 3, 3ULL, (V[]){v_t_2454, v_ps_2455, v_t_2458});
  }
  case TAG_CLabel: {
    heff_drop(v_bor_240);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CJump: {
    V v_g_2460 = heff_field(v_s_242, 0);
    V v_w_2461 = heff_field(v_s_242, 1);
    V v_es_2462 = heff_field(v_s_242, 2);
    V v_ru_24s_242_24CJump = heff_take_reuse_n(v_s_242, 7ULL, 3);
    V v_t_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapExp_clo), 2, (V[]){v_bor_240, v_go_241}));
    V v_t_2464 = (g_list_2emap(v_t_2463, v_es_2462));
    return heff_tag_re_n(v_ru_24s_242_24CJump, TAG_CJump, 3, 3ULL, (V[]){v_g_2460, v_w_2461, v_t_2464});
  }
  case TAG_CTakeSelf: {
    heff_drop(v_bor_240);
    heff_drop(v_go_241);
    return v_s_242;
  }
  case TAG_CDropSelf: {
    heff_drop(v_bor_240);
    heff_drop(v_go_241);
    return v_s_242;
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2ecaptures_2ecapSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecaptures_2ecapSt(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecaptures_2ecapSt_lam0(V self, V *args) {
  V v_x2_2422 = args[0];
  V v_go_241 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkCArm: {
    V v_t_2423 = heff_field(v_x2_2422, 0);
    V v_fs_2424 = heff_field(v_x2_2422, 1);
    V v_fl_2425 = heff_field(v_x2_2422, 2);
    V v_su_2426 = heff_field(v_x2_2422, 3);
    V v_pl_2427 = heff_field(v_x2_2422, 4);
    V v_tk_2428 = heff_field(v_x2_2422, 5);
    V v_body_2429 = heff_field(v_x2_2422, 6);
    V v_lv_2430 = heff_field(v_x2_2422, 7);
    V v_ru_24x2_2422_24MkCArm = heff_take_reuse_n(v_x2_2422, 255ULL, 8);
    heff_clo_take(self, 1);
    V v_t_2431 = heff_tr(heff_call(v_go_241, 1, (V[]){v_body_2429}));
    return heff_tag_re_n(v_ru_24x2_2422_24MkCArm, TAG_MkCArm, 8, 191ULL, (V[]){v_t_2423, v_fs_2424, v_fl_2425, v_su_2426, v_pl_2427, v_tk_2428, v_t_2431, v_lv_2430});
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
Clo g_heff_2ecompile_2ecaptures_2ecapStmts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecaptures_2ecapStmts_entry, 2, 0};

V g_heff_2ecompile_2ecaptures_2ecapStmts(V v_bor_240, V v_ss_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecaptures_2ecapStmts_clo), 1, (V[]){heff_dup(v_bor_240)}));
  return (g_list_2emap_24s1851573375x1006375246(v_bor_240, v_t_242, v_ss_241));
}
V g_heff_2ecompile_2ecaptures_2ecapStmts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecaptures_2ecapStmts(a[0], a[1]);
}