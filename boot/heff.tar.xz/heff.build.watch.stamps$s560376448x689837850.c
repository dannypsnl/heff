// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Directory 35277
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Other 45236
#define TAG_ReadDirectory 46629
#define TAG_Regular 40886
#define TAG_Right 62770
#define LBL_kind 9787483
#define LBL_modified 129625309
#define LBL_size 10026184
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850(V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_clo;
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1_clo;
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_clo;
V g_list_2ekeepIf_24f1923479042x405847724(V, V, V, V);
V g_list_2ekeepIf_24f1923479042x405847724_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1923479042x405847724_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_str2, 1, " ");
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(V v_st_240, V v_acc_241, V v_rest_242, V v_hd_243, V v_k_244, V v_p_245, V v_x_246) {
top: ;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    V v_ru_24x_246_24Left = heff_take_reuse_n(v_x_246, 0ULL, 1);
    heff_drop(v_p_245);
    return ({ V a_0 = v_ru_24x_246_24Left; V a_1 = v_st_240; V a_2 = v_acc_241; V a_3 = v_rest_242; V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_242); r_; });
  }
  case TAG_Right: {
    V v_s_248 = heff_field(v_x_246, 0);
    V v_ru_24x_246_24Right = heff_take_reuse_n(v_x_246, 1ULL, 1);
    V v_kind_249 = heff_take_field(v_s_248, 0);
    V v_modified_2410 = heff_take_field(v_s_248, 2);
    V v_size_2411 = heff_get_n(v_s_248, 1, 4);
    V v_t_2412 = v_kind_249;
    V v_t_2413;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Regular: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_Directory: {
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_Link: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_Other: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_modified_2410);
      heff_drop(v_size_2411);
      heff_drop(v_t_2413);
      V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_245)));
      V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
      V v_a_2417 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam0_clo)});
      V v_t_2418 = heff_tag_at_n(v_ru_24x_246_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2422, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam1, 1, 7, (V[]){v_st_240, v_acc_241, v_rest_242, v_hd_243, v_k_244, v_path_2414, v_p_245})));
    } else {
      heff_drop(v_t_2413);
      V v_t_2437 = heff_strAppend(heff_strAppend(v_p_245, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_str1)), heff_intShow(v_modified_2410));
      V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_str2)), heff_intShow(v_size_2411));
      return ({ V a_0 = v_ru_24x_246_24Right; V a_1 = v_st_240; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_acc_241}); V a_3 = v_rest_242; V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_242); r_; });
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam0(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam2(V self, V *args) {
  V v_n_2428 = args[0];
  V v_path_2414 = heff_env(self)[0];
  V v_t_2429 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2428));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_2414, v_t_2429));
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam3(V self, V *args) {
  V v_n_2432 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_245));
  V v_t_2434 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_2432));
  V v_t_2435 = (g_std_2epath_2ejoin(v_t_2433, v_t_2434));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2435); r_; });
}
V g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_path_2414 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_path_2414);
    heff_drop(v_p_245);
    return ({ V a_0 = v_ru_24x_2423_24Left; V a_1 = v_st_240; V a_2 = v_acc_241; V a_3 = v_rest_242; V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_242); r_; });
  }
  case TAG_Right: {
    V v_y_2425 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    switch (heff_tag_of(v_y_2425)) {
    case TAG_Left: {
      heff_take_n(v_y_2425, 0ULL, 1);
      heff_clo_take(self, 7);
      heff_drop(v_path_2414);
      heff_drop(v_p_245);
      return ({ V a_0 = v_ru_24x_2423_24Right; V a_1 = v_st_240; V a_2 = v_acc_241; V a_3 = v_rest_242; V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_242); r_; });
    }
    case TAG_Right: {
      V v_x_2427 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      heff_clo_take(self, 7);
      V v_x_2430 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam2, 1, 1, (V[]){v_path_2414}), v_x_2427));
      V v_t_2431 = (g_list_2ekeepIf_24f1923479042x405847724(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_str0), v_x_2430));
      V v_t_2436 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_242, heff_clo_n(g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_2ek_24l0_lam3, 1, 2, (V[]){heff_dup(v_st_240), v_p_245}), v_t_2431));
      return ({ V a_0 = v_ru_24x_2423_24Right; V a_1 = v_st_240; V a_2 = v_acc_241; V a_3 = v_t_2436; V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ewatch_2estamps_24s560376448x689837850_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2436); r_; });
    }
    default: return heff_nomatch(v_y_2425);
    }
  }
  default: return heff_nomatch(v_x_2423);
  }
}