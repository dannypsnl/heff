// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Backspace 1027
#define TAG_Char 10597
#define TAG_Control 37853
#define TAG_Enter 13030
#define TAG_Escape 55216
#define TAG_Sequence 46672
#define TAG_Tab 31265
V g_std_2eterminal_2ewidget_2ecsiEnd(V, V);
V g_std_2eterminal_2ewidget_2ecsiEnd_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecsiEnd_clo;
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244(V, V);
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_clo;
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps(V, V, V);
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_clo;
HeffT2 g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_24cpr(V, V);
V g_std_2eterminal_2ewidget_2efinalKey(V, V, V);
V g_std_2eterminal_2ewidget_2efinalKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efinalKey_clo;
HEFF_LIT(g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_24cpr_str0, 0, "");

HeffT2 g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_24cpr(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)27ULL))) {
    V v_s_242 = v_s_240;
    V v_i_243 = v_i_241;
    V v_t_244 = heff_strByteAt_lent(v_s_242, heff_intAdd_lent(v_i_243, MK_INT(1LL), 2), 2);
    if ((heff_unbox_word(v_t_244) == ((int64_t)91ULL))) {
      V v_s_245 = v_s_242;
      V v_i_246 = v_i_243;
      V v_t_247 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_245, heff_intAdd_lent(v_i_246, MK_INT(2LL), 2)));
      if (heff_intLt_c(v_t_247, MK_INT(0LL))) {
        V v_t_248 = heff_strSlice_lent(v_s_245, v_i_246, heff_strLength_lent(v_s_245, 0), 6);
        V v_f_249 = heff_tag_n(TAG_Sequence, 1, (V[]){v_t_248});
        V v_f_2410 = heff_strLength(v_s_245);
        return ((HeffT2){{v_f_249, v_f_2410}});
      } else {
        V v_t_2411 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_245, heff_intAdd_lent(v_i_246, MK_INT(2LL), 2)));
        V v_t_2412 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_245, heff_intAdd_lent(v_i_246, MK_INT(2LL), 2)));
        V v_t_2413 = (g_std_2eterminal_2ewidget_2ecsiEnd(v_s_245, heff_intAdd_lent(v_i_246, MK_INT(2LL), 2)));
        V v_t_2414 = heff_strSlice(heff_dup(v_s_245), heff_dup(v_i_246), heff_intAdd(v_t_2411, MK_INT(1LL)));
        V v_t_2415 = heff_strSlice_lent(v_s_245, heff_intAdd_lent(v_i_246, MK_INT(2LL), 2), v_t_2412, 6);
        V v_t_2416 = ({ V a_0 = v_t_2414; V a_1 = v_t_2415; V a_2 = heff_strByteAt_lent(v_s_245, v_t_2413, 2); V r_ = (g_std_2eterminal_2ewidget_2efinalKey(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
        V v_t_2417 = ({ V a_0 = v_s_245; V a_1 = heff_intAdd(v_i_246, MK_INT(2LL)); V r_ = (g_std_2eterminal_2ewidget_2ecsiEnd(a_0, a_1)); heff_drop(v_s_245); r_; });
        V v_f_2418 = heff_intAdd(v_t_2417, MK_INT(1LL));
        return ((HeffT2){{v_t_2416, v_f_2418}});
      }
    } else {
      V v_t_2419 = heff_strByteAt_lent(v_s_242, heff_intAdd_lent(v_i_243, MK_INT(1LL), 2), 2);
      if ((heff_unbox_word(v_t_2419) == ((int64_t)79ULL))) {
        V v_s_2420 = v_s_242;
        V v_i_2421 = v_i_243;
        if (heff_intLe_c(heff_strLength_lent(v_s_2420, 0), heff_intAdd_lent(v_i_2421, MK_INT(2LL), 2))) {
          heff_drop(v_s_2420);
          V v_f_2422 = heff_intAdd(v_i_2421, MK_INT(1LL));
          return ((HeffT2){{NTAG(TAG_Escape), v_f_2422}});
        } else {
          V v_t_2423 = heff_strSlice_lent(v_s_2420, v_i_2421, heff_intAdd_lent(v_i_2421, MK_INT(3LL), 2), 4);
          V v_t_2424 = heff_strByteAt(v_s_2420, heff_intAdd_lent(v_i_2421, MK_INT(2LL), 2));
          V v_t_2425 = (g_std_2eterminal_2ewidget_2efinalKey(v_t_2423, ((V)&g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_24cpr_str0), v_t_2424));
          V v_f_2426 = heff_intAdd(v_i_2421, MK_INT(3LL));
          return ((HeffT2){{v_t_2425, v_f_2426}});
        }
      } else {
        heff_drop(v_s_242);
        V v_f_2427 = heff_intAdd(v_i_243, MK_INT(1LL));
        return ((HeffT2){{NTAG(TAG_Escape), v_f_2427}});
      }
    }
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) < ((int64_t)32ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)127ULL)))) {
      V v_b_2428 = heff_strByteAt_lent(v_s_240, v_i_241, 1);
      V v_t_2431;
      if ((heff_peek_word(v_b_2428) == ((int64_t)13ULL))) {
        heff_drop(v_b_2428);
        v_t_2431 = NTAG(TAG_Enter);
      } else {
        if ((heff_peek_word(v_b_2428) == ((int64_t)10ULL))) {
          heff_drop(v_b_2428);
          v_t_2431 = NTAG(TAG_Enter);
        } else {
          if ((heff_peek_word(v_b_2428) == ((int64_t)9ULL))) {
            heff_drop(v_b_2428);
            v_t_2431 = NTAG(TAG_Tab);
          } else {
            if ((heff_peek_word(v_b_2428) == ((int64_t)8ULL))) {
              heff_drop(v_b_2428);
              v_t_2431 = NTAG(TAG_Backspace);
            } else {
              if ((heff_peek_word(v_b_2428) == ((int64_t)127ULL))) {
                heff_drop(v_b_2428);
                v_t_2431 = NTAG(TAG_Backspace);
              } else {
                if (((((int64_t)1ULL) <= heff_peek_word(v_b_2428)) && (heff_peek_word(v_b_2428) <= ((int64_t)26ULL)))) {
                  V v_t_2429 = heff_runeFromInt(heff_box_word((heff_unbox_word(v_b_2428) + ((int64_t)96ULL))));
                  v_t_2431 = heff_tag_n(TAG_Control, 1, (V[]){v_t_2429});
                } else {
                  V v_t_2430 = heff_runeFromInt(heff_box_word((heff_unbox_word(v_b_2428) + ((int64_t)64ULL))));
                  v_t_2431 = heff_tag_n(TAG_Control, 1, (V[]){v_t_2430});
                }
              }
            }
          }
        }
      }
      V v_f_2432 = heff_intAdd(v_i_241, MK_INT(1LL));
      return ((HeffT2){{v_t_2431, v_f_2432}});
    } else {
      HeffT2 v_t_2433 = heff_strRuneDecode_lent(v_s_240, v_i_241, 1);
      {
        V v_rune_2434 = v_t_2433.f[0];
        V v_width_2435 = v_t_2433.f[1];
        V v_f_2436 = heff_tag_n(TAG_Char, 1, (V[]){v_rune_2434});
        V v_f_2437 = heff_intAdd(v_i_241, v_width_2435);
        return ((HeffT2){{v_f_2436, v_f_2437}});
      }
    }
  }
}
Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_entry, 2, 0};

V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  } else {
    HeffT2 v_t_242 = (g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_24cpr(heff_dup(v_s_240), heff_dup(v_i_241)));
    {
      V v_field_243 = v_t_242.f[0];
      heff_drop(v_t_242.f[1]);
      HeffT2 v_t_245 = (g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_24cpr(heff_dup(v_s_240), v_i_241));
      {
        V v_field_247 = v_t_245.f[1];
        heff_drop(v_t_245.f[0]);
        V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_243, heff_hole()});
        V v_u_249 = ({ V a_0 = v_s_240; V a_1 = v_field_247; V a_2 = v_cell_248; V r_ = (g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps(a_0, a_1, a_2)); heff_drop(v_s_240); r_; });
        heff_drop(v_u_249);
        return v_cell_248;
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244(a[0], a[1]);
}
Clo g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_entry, 3, 0};

V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps(V v_s_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1)) {
    heff_drop(v_i_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    HeffT2 v_t_243 = (g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_24cpr(heff_dup(v_s_240), heff_dup(v_i_241)));
    {
      V v_field_244 = v_t_243.f[0];
      heff_drop(v_t_243.f[1]);
      HeffT2 v_t_246 = (g_std_2eterminal_2ewidget_2edecode_2ekeyAt_243_24cpr(heff_dup(v_s_240), v_i_241));
      {
        V v_field_248 = v_t_246.f[1];
        heff_drop(v_t_246.f[0]);
        V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_244, heff_hole()});
        V v_u_2410 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_249);
        V t_0 = v_s_240;
        V t_1 = v_field_248;
        V t_2 = v_u_2410;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_std_2eterminal_2ewidget_2edecode_2edecodeFrom_244_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}