// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_ArrayIndex 31774
#define TAG_ArrayPeek 2264
#define TAG_CDecl 45531
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CLet 49341
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187 7242
#define TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565 57410
#define TAG_F32 16337
#define TAG_FlatAll 51900
#define TAG_FlatNone 33150
#define TAG_FlatSome 51022
#define TAG_Given 9359
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_IntAdd 18227
#define TAG_IntAnd 18537
#define TAG_IntDiv 21283
#define TAG_IntEq 36665
#define TAG_IntHash 50175
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMod 30100
#define TAG_IntMul 30294
#define TAG_IntOr 36976
#define TAG_IntShl 35657
#define TAG_IntShow 56864
#define TAG_IntShr 35663
#define TAG_IntSub 36050
#define TAG_IntXor 40685
#define TAG_KnownTag 34380
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RCall 39004
#define TAG_RFieldU 15753
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RLocal 34280
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Reuse 22912
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_key 315609
#define LBL_lam 316434
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_tokens 1078955205
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543_clo;
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_clo;
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo;
V g_heff_2ecompile_2erefcount_2eboolName_get(void);
V g_heff_2ecompile_2erefcount_2ecallAs(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecallAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallAs_clo;
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(V, V, V);
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_clo;
V g_heff_2ecompile_2erefcount_2ecoerce(V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok1_clo;
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecoerce_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecoerce_24tok2_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V, V, V);
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_clo;
V g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619_clo;
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3_clo;
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_clo;
HeffT2 g_heff_2ecompile_2erefcount_2edeclRun_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
HeffT3 g_heff_2ecompile_2erefcount_2efillOf_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2eflatnessOf(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
V g_heff_2ecompile_2erefcount_2efvArm(V);
V g_heff_2ecompile_2erefcount_2efvArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvArm_clo;
V g_heff_2ecompile_2erefcount_2efvRest(V, V);
V g_heff_2ecompile_2erefcount_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvRest_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eintAt(V, V);
V g_heff_2ecompile_2erefcount_2eintAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eintAt_clo;
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263_clo;
V g_heff_2ecompile_2erefcount_2elentThen(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2elentThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2elentThen_clo;
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_clo;
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps_clo;
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs(V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok2_clo;
V g_heff_2ecompile_2erefcount_2epeekPrim_get(void);
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_clo;
V g_heff_2ecompile_2erefcount_2eprojAs_24s312851212x1919573772(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2eprojAs_24s312851212x1919573772_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eprojAs_24s312851212x1919573772_clo;
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065_clo;
V g_heff_2ecompile_2erefcount_2ereusing(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereusing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereusing_clo;
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(V, V);
V g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571_clo;
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(V, V);
V g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533_clo;
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2evalF_24s816614248x747648904(V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalF_24s816614248x747648904_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalF_24s816614248x747648904_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany_24s1678884672x1211895143(V, V);
V g_list_2eany_24s1678884672x1211895143_entry(V self, V *a);
extern Clo g_list_2eany_24s1678884672x1211895143_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24s1050197499x1941129217(V, V);
V g_list_2efoldl_24s1050197499x1941129217_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1050197499x1941129217_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f889159142x1775976195(V, V, V, V);
V g_list_2emap_24f889159142x1775976195_entry(V self, V *a);
extern Clo g_list_2emap_24f889159142x1775976195_clo;
V g_list_2emap_24s1068270568x176847536(V);
V g_list_2emap_24s1068270568x176847536_entry(V self, V *a);
extern Clo g_list_2emap_24s1068270568x176847536_clo;
V g_list_2emap_24s1341404685x1564972929(V);
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24s698037429x265256386(V);
V g_list_2emap_24s698037429x265256386_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2erefcount_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, v_j_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eelemI(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2ejustsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2ejustsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_rest_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ejustsOf_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2epow2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epow2_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2epow2(V v_n_240) {
top: ;
  if (heff_intEq_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2ecompile_2erefcount_2epow2(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_241);
  }
}
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2epow2(a[0]);
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2eflatnessOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eflatnessOf_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2eflatnessOf(V v_x1_240, V v_su_241, V v_mask_242, V v_n_243) {
top: ;
  if ((heff_dup(v_x1_240) == NTAG(TAG_True))) {
    V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_243, MK_INT(1LL))));
    V v_t_248 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2eflatnessOf_lam0, 1, 2, (V[]){v_mask_242, heff_dup(v_su_241)}); V a_1 = v_t_244; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_244); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_FlatAll);
    } else {
      heff_drop(v_t_248);
      return NTAG(TAG_FlatSome);
    }
  } else {
    heff_drop(v_mask_242);
    heff_drop(v_n_243);
    return NTAG(TAG_FlatNone);
  }
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eflatnessOf(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2eflatnessOf_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_mask_242 = heff_env(self)[0];
  V v_su_241 = heff_env(self)[1];
  V v_t_246 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_245)));
  heff_clo_take(self, 2);
  V v_t_247 = heff_intMod(heff_intDiv(v_mask_242, v_t_246), MK_INT(2LL));
  if ((heff_unbox_word(v_t_247) == ((int64_t)1ULL))) {
    heff_drop(v_i_245);
    heff_drop(v_su_241);
    return NTAG(TAG_True);
  } else {
    return ({ V a_0 = v_i_245; V a_1 = v_su_241; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_i_245); heff_drop(v_su_241); r_; });
  }
}

static V g_heff_2ecompile_2erefcount_2epeekPrim_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2epeekPrim_st;
static V g_heff_2ecompile_2erefcount_2epeekPrim_init(void) {
  return NTAG(TAG_ArrayPeek);
}
V g_heff_2ecompile_2erefcount_2epeekPrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2epeekPrim_st)) return g_heff_2ecompile_2erefcount_2epeekPrim_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2epeekPrim_val, &g_heff_2ecompile_2erefcount_2epeekPrim_st, g_heff_2ecompile_2erefcount_2epeekPrim_init);
}
Clo g_heff_2ecompile_2erefcount_2eintAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eintAt_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eintAt(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_IVal: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SVar: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SGlobal: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SInt: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SFloat: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SStr: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SBytes: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SFixed: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SFloat32: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SPrimFn: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      V v_p_2424 = heff_field(v_x21_242, 0);
      V v_argv_2425 = heff_field(v_x21_242, 1);
      V v_t_2426;
      switch (heff_tag_of(v_p_2424)) {
      case TAG_IntAdd: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntSub: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntMul: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntDiv: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntMod: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntEq: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntLt: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntLe: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShow: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntAnd: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntOr: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntXor: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShl: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShr: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      case TAG_IntHash: {
        v_t_2426 = NTAG(TAG_True);
        break;
      }
      default: {
        v_t_2426 = NTAG(TAG_False);
        break;
      }
      }
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        return ({ V a_0 = v_x_240; V a_1 = v_argv_2425; V r_ = (g_list_2eany_24s1678884672x1211895143(a_0, a_1)); heff_drop(v_x_240); r_; });
      } else {
        heff_drop(v_x_240);
        heff_drop(v_t_2426);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_IOp: {
    V v_x21_2427 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_2427)) {
    case TAG_OSimple: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_OCall: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_OApply: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_OPrim: {
      V v_p_2433 = heff_field(v_x21_2427, 0);
      V v_argv_2434 = heff_field(v_x21_2427, 1);
      V v_t_2435;
      switch (heff_tag_of(v_p_2433)) {
      case TAG_IntAdd: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntSub: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntMul: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntDiv: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntMod: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntEq: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntLt: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntLe: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShow: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntAnd: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntOr: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntXor: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShl: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShr: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      case TAG_IntHash: {
        v_t_2435 = NTAG(TAG_True);
        break;
      }
      default: {
        v_t_2435 = NTAG(TAG_False);
        break;
      }
      }
      if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
        heff_drop(v_t_2435);
        return ({ V a_0 = v_x_240; V a_1 = v_argv_2434; V r_ = (g_list_2eany_24s1678884672x1211895143(a_0, a_1)); heff_drop(v_x_240); r_; });
      } else {
        heff_drop(v_x_240);
        heff_drop(v_t_2435);
        return NTAG(TAG_False);
      }
    }
    case TAG_OAbandon: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_OBool: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_2427);
    }
  }
  case TAG_ICond: {
    V v_x21_2437 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_2437)) {
    case TAG_PTrue: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_PFalse: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_PRel: {
      V v_p_2438 = heff_field(v_x21_2437, 0);
      V v_a_2439 = heff_field(v_x21_2437, 1);
      V v_b_2440 = heff_field(v_x21_2437, 2);
      V v_lit_2441 = heff_dup(v_a_2439);
      V v_lit_2442 = heff_dup(v_b_2440);
      V v_x_2443 = v_x_240;
      V v_p_2444 = heff_dup(v_p_2438);
      V v_t_2445;
      switch (heff_tag_of(v_p_2444)) {
      case TAG_IntAdd: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntSub: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntMul: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntDiv: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntMod: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntEq: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntLt: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntLe: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShow: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntAnd: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntOr: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntXor: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShl: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntShr: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_IntHash: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      default: {
        heff_drop(v_p_2444);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      }
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_t_2445);
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_2442, NTAG(TAG_Nil)});
        return ({ V a_0 = v_x_2443; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_2441, v_t_2446}); V r_ = (g_list_2eany_24s1678884672x1211895143(a_0, b_1)); heff_drop(v_x_2443); heff_drop(b_1); r_; });
      } else {
        heff_drop(v_lit_2441);
        heff_drop(v_lit_2442);
        heff_drop(v_x_2443);
        heff_drop(v_t_2445);
        return NTAG(TAG_False);
      }
    }
    case TAG_PBool: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_PNot: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_PIf: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_PLet: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_2437);
    }
  }
  case TAG_ISts: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ITl: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eintAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eintAt(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2eprojAs_24s312851212x1919573772_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprojAs_24s312851212x1919573772_entry, 12, 0};

V g_heff_2ecompile_2erefcount_2eprojAs_24s312851212x1919573772(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_ce_244, V v_live_245, V v_want_246, V v_e_247, V v_su_248, V v_n_249, V v_x9_2410, V v_rp_2411) {
top: ;
  switch (heff_tag_of(v_x9_2410)) {
  case TAG_Nothing: {
    heff_drop(v_e_247);
    heff_drop(v_su_248);
    heff_drop(v_n_249);
    heff_drop(v_rp_2411);
    V v_t_2412 = (g_heff_2ecompile_2erefcount_2evalF_24s816614248x747648904(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_ce_244, v_live_245));
    return (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_246, v_t_2412));
  }
  case TAG_Just: {
    V v_i_2413 = heff_field(v_x9_2410, 0);
    V v_ru_24x9_2410_24Just = heff_take_reuse_n(v_x9_2410, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_rp_2411)) {
    case TAG_RepV: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      switch (heff_tag_of(v_want_246)) {
      case TAG_RepV: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_246);
      }
      break;
    }
    case TAG_RepF64: {
      switch (heff_tag_of(v_want_246)) {
      case TAG_RepV: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_246);
      }
      break;
    }
    case TAG_RepInt: {
      switch (heff_tag_of(v_want_246)) {
      case TAG_RepV: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2418 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_246);
      }
      break;
    }
    default: heff_nomatch(v_rp_2411);
    }
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_e_247);
      heff_drop(v_su_248);
      heff_drop(v_n_249);
      heff_drop(v_rp_2411);
      heff_drop(v_i_2413);
      heff_drop(v_t_2418);
      V v_t_2419 = (g_heff_2ecompile_2erefcount_2evalF_24s816614248x747648904(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_ce_244, v_live_245));
      return (g_heff_2ecompile_2erefcount_2ecoerce_24tok1(v_ru_24x9_2410_24Just, NTAG(TAG_RepV), v_want_246, v_t_2419));
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_t_2418);
      V v_ce_2420 = v_ce_244;
      V v_live_2421 = v_live_245;
      V v_e_2422 = heff_dup(v_e_247);
      V v_rp_2423 = heff_dup(v_rp_2411);
      V v_su_2424 = v_su_248;
      V v_i_2425 = v_i_2413;
      V v_n_2426 = v_n_249;
      V v_x9_2450;
      switch (heff_tag_of(v_e_247)) {
      case TAG_SVar: {
        V v_x_2427 = heff_dup(heff_field(v_e_247, 0));
        v_x9_2450 = heff_tag_at_n(v_ru_24x9_2410_24Just, TAG_Just, 1, (V[]){v_x_2427});
        break;
      }
      case TAG_SGlobal: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_drop_cell(v_ru_24x9_2410_24Just, 1);
        v_x9_2450 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_247);
      }
      V v_x10_2474;
      switch (heff_tag_of(v_e_247)) {
      case TAG_SVar: {
        heff_take_n(v_e_247, 0ULL, 1);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_g_2452 = heff_field(v_e_247, 0);
        V v_ru_24e_247_24SGlobal = heff_take_reuse_n(v_e_247, 1ULL, 1);
        v_x10_2474 = heff_tag_at_n(v_ru_24e_247_24SGlobal, TAG_Just, 1, (V[]){v_g_2452});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_e_247, 0ULL, 1);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_e_247, 0ULL, 1);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_e_247, 0ULL, 1);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_e_247, 0ULL, 1);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_e_247, 0ULL, 2);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_e_247, 0ULL, 1);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_e_247, 0ULL, 1);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_e_247, 0ULL, 2);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_e_247, 0ULL, 3);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_e_247, 0ULL, 2);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_e_247, 0ULL, 4);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_e_247, 0ULL, 2);
        v_x10_2474 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_247);
      }
      V v_t_2480;
      switch (heff_tag_of(v_x9_2450)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x10_2474)) {
        case TAG_Nothing: {
          V v_t_2475 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2420, v_live_2421, NTAG(TAG_RepV), v_e_2422));
          v_t_2480 = heff_tag_n(TAG_RGetNU, 5, (V[]){v_rp_2423, v_su_2424, v_t_2475, v_i_2425, v_n_2426});
          break;
        }
        case TAG_Just: {
          V v_g_2476 = heff_field(v_x10_2474, 0);
          V v_ru_24x10_2474_24Just = heff_take_reuse_n(v_x10_2474, 1ULL, 1);
          heff_drop_rec(v_ce_2420, 17);
          heff_drop(v_live_2421);
          heff_drop(v_e_2422);
          heff_drop(v_n_2426);
          v_t_2480 = heff_tag_n(TAG_RFieldU, 4, (V[]){v_rp_2423, v_su_2424, heff_tag_at_n(v_ru_24x10_2474_24Just, TAG_RGetRaw, 1, (V[]){v_g_2476}), v_i_2425});
          break;
        }
        default: heff_nomatch(v_x10_2474);
        }
        break;
      }
      case TAG_Just: {
        V v_x_2477 = heff_field(v_x9_2450, 0);
        V v_ru_24x9_2450_24Just = heff_take_reuse_n(v_x9_2450, 1ULL, 1);
        heff_drop(v_e_2422);
        heff_drop(v_x10_2474);
        V v_t_2478 = ({ V a_0 = v_x_2477; V a_1 = v_live_2421; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_live_2421); r_; });
        if ((heff_dup(v_t_2478) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_2420, 17);
          heff_drop(v_n_2426);
          heff_drop(v_t_2478);
          v_t_2480 = heff_tag_n(TAG_RFieldU, 4, (V[]){v_rp_2423, v_su_2424, heff_tag_at_n(v_ru_24x9_2450_24Just, TAG_RLocal, 1, (V[]){v_x_2477}), v_i_2425});
        } else {
          heff_drop(v_t_2478);
          V v_t_2479 = ({ V a_0 = v_x_2477; V b_1 = heff_get_n(v_ce_2420, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_t_2479) == NTAG(TAG_True))) {
            heff_drop(v_n_2426);
            heff_drop(v_t_2479);
            v_t_2480 = heff_tag_n(TAG_RFieldU, 4, (V[]){v_rp_2423, v_su_2424, heff_tag_at_n(v_ru_24x9_2450_24Just, TAG_RLocal, 1, (V[]){v_x_2477}), v_i_2425});
          } else {
            heff_drop(v_t_2479);
            v_t_2480 = heff_tag_n(TAG_RGetNU, 5, (V[]){v_rp_2423, v_su_2424, heff_tag_at_n(v_ru_24x9_2450_24Just, TAG_RLocal, 1, (V[]){v_x_2477}), v_i_2425, v_n_2426});
          }
        }
        break;
      }
      default: heff_nomatch(v_x9_2450);
      }
      return (g_heff_2ecompile_2erefcount_2ecoerce(v_rp_2411, v_want_246, v_t_2480));
    }
  }
  default: return heff_nomatch(v_x9_2410);
  }
}
V g_heff_2ecompile_2erefcount_2eprojAs_24s312851212x1919573772_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2eprojAs_24s312851212x1919573772(a[0], a[1], a2, a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(V v_ce_240, V v_live_241, V v_x4_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_x5_243);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rp_245 = heff_field(v_x4_242, 0);
    V v_rps_246 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x5_243)) {
    case TAG_Nil: {
      heff_drop(v_rp_245);
      heff_drop(v_rps_246);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_247 = heff_field(v_x5_243, 0);
      V v_es_248 = heff_field(v_x5_243, 1);
      V v_ru_24x5_243_24Cons = heff_take_reuse_n(v_x5_243, 3ULL, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_248)));
      V v_t_2410 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_249));
      V v_live_2411 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x5_243_24Cons, v_t_2410, heff_dup(v_live_241)));
      V v_t_2412 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2411, v_rp_245, v_e_247));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2413);
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_rps_246;
      V t_3 = v_es_248;
      V t_4 = v_u_2414;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_x4_242 = t_2;
      v_x5_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x5_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_24dps(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(V v_ce_240, V v_live_241, V v_p_242, V v_argv_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_p_242)) {
    case TAG_Reuse: {
      return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_argv_243; V r_ = (g_heff_2ecompile_2erefcount_2ereuseVal_24s1612049039x276824065(a_0, a_1, a_2)); heff_drop(v_argv_243); r_; });
    }
    default: {
      V v_t_245 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_243));
      return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_242, v_t_245});
    }
    }
  }
  case TAG_Just: {
    V v_e_246 = heff_field(v_x6_244, 0);
    V v_ru_24x6_244_24Just = heff_take_reuse_n(v_x6_244, 1ULL, 1);
    V v_ce_247 = heff_dup(v_ce_240);
    V v_live_248 = v_live_241;
    V v_p_249 = v_p_242;
    V v_argv_2410 = heff_dup(v_argv_243);
    V v_e_2411 = heff_dup(v_e_246);
    V v_ce_2412 = v_ce_240;
    HeffT3 v_t_2413 = ({ V a_0 = v_e_246; V a_1 = v_argv_243; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_argv_243); r_; });
    {
      V v_field_2415 = v_t_2413.f[1];
      V v_field_2416 = v_t_2413.f[2];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      V v_v_2419;
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x6_244_24Just, 1);
        V v_x_2417 = v_field_2415;
        V v_x12_2418 = v_field_2416;
        heff_drop(v_x12_2418);
        v_v_2419 = v_x_2417;
      } else {
        heff_drop(v_field_2415);
        heff_drop(v_field_2416);
        v_v_2419 = heff_tag_at_n(v_ru_24x6_244_24Just, TAG_SInt, 1, (V[]){MK_INT(0LL)});
      }
      V v_rp_2451;
      switch (heff_tag_of(v_v_2419)) {
      case TAG_SVar: {
        V v_x_2420 = heff_field(v_v_2419, 0);
        heff_take_n(v_v_2419, 1ULL, 1);
        HeffT2 v_t_2421 = ({ V b_0 = heff_get_n(v_ce_2412, 10, 17); V a_1 = v_x_2420; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2420); r_; });
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_x_2424 = v_field_2423;
            v_rp_2451 = v_x_2424;
          } else {
            heff_drop(v_field_2423);
            v_rp_2451 = NTAG(TAG_RepV);
          }
        }
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_v_2419, 0ULL, 1);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_v_2419, 0ULL, 1);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_v_2419, 0ULL, 1);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepF64);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_v_2419, 0ULL, 1);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_v_2419, 0ULL, 1);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_SFixed: {
        V v_w_2430 = heff_field(v_v_2419, 0);
        heff_take_n(v_v_2419, 1ULL, 2);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = heff_tag_n(TAG_RepFix, 1, (V[]){v_w_2430});
        break;
      }
      case TAG_SFloat32: {
        V v_ru_24v_2419_24SFloat32 = heff_take_reuse_na(v_v_2419, 0ULL, 1);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = heff_tag_at_n(v_ru_24v_2419_24SFloat32, TAG_RepFix, 1, (V[]){NTAG(TAG_F32)});
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_v_2419, 0ULL, 1);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_v_2419, 0ULL, 2);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_v_2419, 0ULL, 3);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_v_2419, 0ULL, 2);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_v_2419, 0ULL, 4);
        heff_drop_rec(v_ce_2412, 17);
        v_rp_2451 = NTAG(TAG_RepV);
        break;
      }
      case TAG_SPrim: {
        V v_p_2445 = heff_field(v_v_2419, 0);
        heff_take_n(v_v_2419, 1ULL, 2);
        heff_drop_rec(v_ce_2412, 17);
        HeffT2 v_t_2447 = ({ V a_0 = v_p_2445; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2445); r_; });
        {
          V v_field_2449 = v_t_2447.f[1];
          int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
          if ((v_tag_2448 == ((int64_t)0ULL))) {
            V v_s_2450 = v_field_2449;
            v_rp_2451 = heff_get_n(v_s_2450, 1, 2);
          } else {
            heff_drop(v_field_2449);
            v_rp_2451 = NTAG(TAG_RepV);
          }
        }
        break;
      }
      default: heff_nomatch(v_v_2419);
      }
      V v_t_2453;
      switch (heff_tag_of(v_rp_2451)) {
      case TAG_RepV: {
        v_t_2453 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2453 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2453 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2453 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_rp_2451);
      }
      if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
        heff_drop(v_e_2411);
        heff_drop(v_rp_2451);
        heff_drop(v_t_2453);
        V v_t_2454 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_247, v_live_248, v_argv_2410));
        return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_249, v_t_2454});
      } else {
        heff_drop(v_t_2453);
        V v_t_2456;
        switch (heff_tag_of(v_rp_2451)) {
        case TAG_RepV: {
          v_t_2456 = NTAG(TAG_False);
          break;
        }
        case TAG_RepFix: {
          v_t_2456 = NTAG(TAG_False);
          break;
        }
        case TAG_RepF64: {
          v_t_2456 = NTAG(TAG_False);
          break;
        }
        case TAG_RepInt: {
          v_t_2456 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_rp_2451);
        }
        if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
          heff_drop(v_rp_2451);
          heff_drop(v_t_2456);
          V v_t_2457 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2410));
          V v_t_2458 = (g_list_2emap_24f889159142x1775976195(v_e_2411, NTAG(TAG_RepV), MK_INT(0LL), heff_intSub(v_t_2457, MK_INT(1LL))));
          V v_t_2459 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_247, v_live_248, v_t_2458, v_argv_2410));
          return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_249, v_t_2459});
        } else {
          heff_drop(v_t_2456);
          V v_t_2460 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2410));
          V v_t_2461 = (g_list_2emap_24f889159142x1775976195(v_e_2411, heff_dup(v_rp_2451), MK_INT(0LL), heff_intSub(v_t_2460, MK_INT(1LL))));
          V v_t_2462 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_247, v_live_248, v_t_2461, v_argv_2410));
          return heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_249, v_rp_2451, v_t_2462});
        }
      }
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eprimVal_24s537334524x949769495(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V v_ce_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_CondTrue);
  }
  case TAG_PFalse: {
    heff_drop_rec(v_ce_240, 17);
    return NTAG(TAG_CondFalse);
  }
  case TAG_PRel: {
    V v_p_242 = heff_field(v_x3_241, 0);
    V v_a_243 = heff_field(v_x3_241, 1);
    V v_b_244 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_245 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_242));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_sh_248 = v_field_247;
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, NTAG(TAG_Nil)});
        V v_t_2410 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_240, NTAG(TAG_Nil), heff_get_n(v_sh_248, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_t_249})));
        return heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_242, v_t_2410});
      } else {
        heff_drop(v_field_247);
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_244, NTAG(TAG_Nil)});
        V v_t_2412 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_t_2411})));
        return heff_tag_n(TAG_CondRel, 2, (V[]){v_p_242, v_t_2412});
      }
    }
  }
  case TAG_PBool: {
    V v_v_2413 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PBool = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_2414 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_2413));
    return heff_tag_at_n(v_ru_24x3_241_24PBool, TAG_CondBool, 1, (V[]){v_t_2414});
  }
  case TAG_PNot: {
    V v_c_2415 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PNot = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_2416 = heff_tag_at_n(v_ru_24x3_241_24PNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2417 = ({ V a_0 = v_ce_240; V a_1 = v_c_2415; V a_2 = v_cell_2416; V a_3 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(a_0, a_1, a_2, a_3)); heff_drop_rec(v_ce_240, 17); r_; });
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  case TAG_PIf: {
    V v_a_2418 = heff_field(v_x3_241, 0);
    V v_b_2419 = heff_field(v_x3_241, 1);
    V v_c_2420 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24PIf = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_a_2418));
    V v_t_2422 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_b_2419));
    V v_cell_2423 = heff_tag_at_n(v_ru_24x3_241_24PIf, TAG_CondIf, 3, (V[]){v_t_2421, v_t_2422, heff_hole()});
    V v_u_2424 = ({ V a_0 = v_ce_240; V a_1 = v_c_2420; V a_2 = v_cell_2423; V a_3 = MK_INT(2LL); V r_ = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(a_0, a_1, a_2, a_3)); heff_drop_rec(v_ce_240, 17); r_; });
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  case TAG_PLet: {
    V v_x_2425 = heff_field(v_x3_241, 0);
    V v_o_2426 = heff_field(v_x3_241, 1);
    V v_c_2427 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_2428 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 10), v_x_2425));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      V v_t_2432;
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_x_2431 = v_field_2430;
        v_t_2432 = v_x_2431;
      } else {
        heff_drop(v_field_2430);
        v_t_2432 = NTAG(TAG_RepV);
      }
      V v_t_2433 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2432, v_o_2426));
      V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), heff_dup(heff_rfield(v_ce_240, 6))});
      V v_t_2435 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2434, heff_dup(v_ce_240)));
      V v_t_2436 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2435, v_c_2427));
      HeffT2 v_t_2437 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2425; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2439 = v_t_2437.f[1];
        int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
        V v_t_2441;
        if ((v_tag_2438 == ((int64_t)0ULL))) {
          V v_x_2440 = v_field_2439;
          heff_drop(v_x_2440);
          v_t_2441 = NTAG(TAG_Nil);
        } else {
          heff_drop(v_field_2439);
          v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_Nil)});
        }
        V v_t_2442 = (g_list_2emap_24s1068270568x176847536(v_t_2441));
        return heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2425, v_t_2433, v_t_2436, v_t_2442});
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(a[0], a[1]);
}
Clo g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    return (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_240, v_live_241, NTAG(TAG_RepV), v_v_243));
  }
  case TAG_OCall: {
    V v_g_244 = heff_field(v_x4_242, 0);
    V v_argv_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_240, 1), v_g_244));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2410 = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x_249 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x_249); c_; })));
      heff_drop(v_field_248);
      HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_g_244));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        V v_t_2415;
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2413;
          v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2414, 1, 2)});
        } else {
          heff_drop(v_field_2413);
          v_t_2415 = NTAG(TAG_Nothing);
        }
        HeffT2 v_t_2416 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 7), v_g_244));
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          V v_t_2420;
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x_2419 = v_field_2418;
            v_t_2420 = v_x_2419;
          } else {
            heff_drop(v_field_2418);
            v_t_2420 = NTAG(TAG_Nil);
          }
          HeffT2 v_t_2421 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_g_244));
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            V v_t_2425;
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              V v_s_2424 = v_field_2423;
              v_t_2425 = heff_get_n(v_s_2424, 0, 2);
            } else {
              heff_drop(v_field_2423);
              v_t_2425 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_argv_245)));
            }
            V v_t_2426 = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(v_ce_240, v_live_241, NTAG(TAG_Nil), v_t_2420, MK_INT(0LL), v_t_2425, v_argv_245));
            return heff_tag_n(TAG_RCall, 4, (V[]){v_g_244, v_t_2410, v_t_2415, v_t_2426});
          }
        }
      }
    }
  }
  case TAG_OApply: {
    V v_f_2427 = heff_field(v_x4_242, 0);
    V v_argv_2428 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24OApply = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_argv_2428)));
    V v_t_2430 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_2429));
    V v_live_2431 = (g_prelude_2e_2b_2b(v_t_2430, heff_dup(v_live_241)));
    V v_fv_2432 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2431, NTAG(TAG_RepV), v_f_2427));
    V v_vs_2433 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2428));
    return heff_tag_at_n(v_ru_24x4_242_24OApply, TAG_RApply, 2, (V[]){v_fv_2432, v_vs_2433});
  }
  case TAG_OPrim: {
    V v_p_2434 = heff_field(v_x4_242, 0);
    V v_argv_2435 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24OPrim = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2436 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_240, v_live_241, v_argv_2435));
    return heff_tag_at_n(v_ru_24x4_242_24OPrim, TAG_RPrim, 2, (V[]){v_p_2434, v_t_2436});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    return NTAG(TAG_RAbandon);
  }
  case TAG_OBool: {
    V v_c_2437 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24OBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_t_2438 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 6))));
    V v_t_2439 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2438, v_ce_240));
    V v_t_2440 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2439));
    V v_t_2441 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2440, v_c_2437));
    return heff_tag_at_n(v_ru_24x4_242_24OBool, TAG_RBool, 1, (V[]){v_t_2441});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecompV_24s234741192x1760842603(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816(V v_lit_240, V v_lit_241, V v_ce_242, V v_c_243, V v_wanted_244) {
top: ;
  V v_xs_247 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam0, 1, 1, (V[]){heff_dup(v_wanted_244)}); V a_1 = heff_dup(heff_rfield(v_ce_242, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_242), v_xs_247));
  V v_t_249 = (g_list_2emap_24s1796125103x644876049(v_t_248));
  V v_t_2411 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam1, 1, 1, (V[]){heff_dup(v_wanted_244)}); V a_1 = heff_dup(heff_rfield(v_ce_242, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_ce_2412 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2411, heff_dup(v_wanted_244), heff_dup(v_ce_242)));
  V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_2412, 4)), heff_dup(heff_rfield(v_ce_2412, 6))));
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2413, v_ce_2412));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2414));
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2415, v_c_243));
  V v_t_2418 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam2, 1, 1, (V[]){heff_dup(v_wanted_244)}); V a_1 = heff_dup(heff_rfield(v_ce_242, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2418, heff_dup(heff_rfield(v_ce_242, 5)), heff_dup(v_ce_242)));
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(v_lit_240, v_t_2419));
  V v_t_2422 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam3, 1, 1, (V[]){v_wanted_244}); V a_1 = heff_dup(heff_rfield(v_ce_242, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2423 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2422, heff_dup(heff_rfield(v_ce_242, 5)), v_ce_242));
  V v_t_2424 = (g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(v_lit_241, v_t_2423));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2416, v_t_2420, v_t_2424}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_249, v_t_2425));
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam0(V self, V *args) {
  V v_v_245 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = ({ V a_0 = v_v_245; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_245); heff_drop(v_wanted_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
  heff_drop(v_x1_246);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam1(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2410; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam2(V self, V *args) {
  V v_v_2417 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2417; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2417); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s753411708x148256816_lam3(V self, V *args) {
  V v_v_2421 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2421; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2421); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_ce_244, V v_p_245, V v_fa_246, V v_wb_247) {
top: ;
  V v_wanted_248 = (g_prelude_2e_2b_2b(heff_dup(v_fa_246), heff_dup(v_wb_247)));
  V v_xs_2411 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam0, 1, 1, (V[]){v_wanted_248}); V a_1 = heff_dup(heff_rfield(v_ce_244, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2412 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_244), v_xs_2411));
  V v_t_2413 = (g_list_2emap_24s1796125103x644876049(v_t_2412));
  V v_wanted_2414 = (g_prelude_2e_2b_2b(v_fa_246, heff_dup(v_wb_247)));
  V v_t_2416 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam1, 1, 1, (V[]){v_wanted_2414}); V a_1 = heff_dup(heff_rfield(v_ce_244, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_ce_2417 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2416, heff_dup(v_wb_247), heff_dup(v_ce_244)));
  HeffT2 v_t_2418 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_245));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    V v_t_2426;
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_sh_2421 = v_field_2420;
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_243, NTAG(TAG_Nil)});
      V v_t_2423 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(v_ce_2417, heff_dup(v_wb_247), heff_get_n(v_sh_2421, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_t_2422})));
      v_t_2426 = heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_245, v_t_2423});
    } else {
      heff_drop(v_field_2420);
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_243, NTAG(TAG_Nil)});
      V v_t_2425 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(v_ce_2417, heff_dup(v_wb_247), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_t_2424})));
      v_t_2426 = heff_tag_n(TAG_CondRel, 2, (V[]){v_p_245, v_t_2425});
    }
    V v_t_2428 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam2, 1, 1, (V[]){heff_dup(v_wb_247)}); V a_1 = heff_dup(heff_rfield(v_ce_244, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2429 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2428, heff_dup(heff_rfield(v_ce_244, 5)), heff_dup(v_ce_244)));
    V v_t_2430 = (g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(v_lit_241, v_t_2429));
    V v_t_2432 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam3, 1, 1, (V[]){v_wb_247}); V a_1 = heff_dup(heff_rfield(v_ce_244, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2433 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2432, heff_dup(heff_rfield(v_ce_244, 5)), v_ce_244));
    V v_t_2434 = (g_heff_2ecompile_2erefcount_2econdArm_24s1869497853x160056915(v_lit_240, v_t_2433));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2426, v_t_2430, v_t_2434}), NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(v_t_2413, v_t_2435));
  }
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_wanted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = ({ V a_0 = v_v_249; V a_1 = v_wanted_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_249); heff_drop(v_wanted_248); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
  heff_drop(v_x1_2410);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam1(V self, V *args) {
  V v_v_2415 = args[0];
  V v_wanted_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V a_1 = v_wanted_2414; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2415); heff_drop(v_wanted_2414); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam2(V self, V *args) {
  V v_v_2427 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2427; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2427); heff_drop(v_wb_247); r_; });
}
V g_heff_2ecompile_2erefcount_2econdWith_24s338106510x930541835_lam3(V self, V *args) {
  V v_v_2431 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2431; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2431); heff_drop(v_wb_247); r_; });
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(V v_ce_240, V v_returns_241, V v_v_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2erefcount_2escrutF_24s1746964072x581259571(heff_dup(v_ce_240), heff_dup(v_v_242)));
  V v_t_2487 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0, 1, 2, (V[]){v_ce_240, v_v_242}), v_arms_243));
  return heff_tag_n(TAG_CSwitch, 3, (V[]){v_t_244, v_t_2487, v_returns_241});
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_it1_246 = heff_field(v_p_245, 0);
    V v_b_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_t_248 = heff_field(v_it1_246, 0);
      V v_vs_249 = heff_field(v_it1_246, 1);
      heff_take_n(v_it1_246, 3ULL, 2);
      V v_ce0_2410 = heff_dup(v_ce_240);
      V v_held_2435;
      heff_clo_take(self, 2);
      switch (heff_tag_of(v_v_242)) {
      case TAG_SVar: {
        V v_x_2411 = heff_dup(heff_field(v_v_242, 0));
        V v_t_2412 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_2411, heff_rfield(v_ce_240, 4)));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          v_held_2435 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
        } else {
          heff_drop(v_x_2411);
          heff_drop(v_t_2412);
          v_held_2435 = NTAG(TAG_Nothing);
        }
        break;
      }
      case TAG_SGlobal: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_held_2435 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_v_242);
      }
      V v_lent_2459;
      switch (heff_tag_of(v_v_242)) {
      case TAG_SVar: {
        V v_x_2436 = heff_field(v_v_242, 0);
        heff_take_n(v_v_242, 1ULL, 1);
        v_lent_2459 = ({ V a_0 = v_x_2436; V b_1 = heff_get_n(v_ce_240, 6, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_x_2436); heff_drop(b_1); r_; });
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_v_242, 0ULL, 1);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_v_242, 0ULL, 1);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_v_242, 0ULL, 1);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_v_242, 0ULL, 1);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_v_242, 0ULL, 1);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_v_242, 0ULL, 2);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_v_242, 0ULL, 1);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_v_242, 0ULL, 1);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_v_242, 0ULL, 2);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_v_242, 0ULL, 3);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_v_242, 0ULL, 2);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_v_242, 0ULL, 4);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_v_242, 0ULL, 2);
        heff_drop_rec(v_ce_240, 17);
        v_lent_2459 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_v_242);
      }
      V v_t_2460 = v_t_248;
      V v_vs_2461 = v_vs_249;
      V v_b_2462 = v_b_247;
      if (heff_strEq_c(heff_dup(v_t_2460), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get()))) {
        heff_drop(v_held_2435);
        V v_fb_2463 = (g_heff_2ecompile_2erefcount_2efvArm(heff_dup(v_b_2462)));
        V v_t_2466;
        switch (heff_tag_of(v_b_2462)) {
        case TAG_ATail: {
          v_t_2466 = NTAG(TAG_False);
          break;
        }
        case TAG_ASts: {
          v_t_2466 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_b_2462);
        }
        V v_t_2467 = (g_heff_2ecompile_2erefcount_2ereusing(heff_dup(heff_rfield(v_ce0_2410, 15)), NTAG(TAG_Nothing), heff_dup(v_t_2460), v_vs_2461, v_b_2462));
        return ({ V a_0 = v_ce0_2410; V a_1 = NTAG(TAG_Nothing); V a_2 = v_lent_2459; V a_3 = v_t_2460; V a_4 = v_vs_2461; V a_5 = v_fb_2463; V a_6 = v_t_2466; V a_7 = v_t_2467; V r_ = (g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_lent_2459); r_; });
      } else {
        V v_n_2468 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2461));
        V v_ce_2470;
        switch (heff_tag_of(v_held_2435)) {
        case TAG_Nothing: {
          heff_drop(v_n_2468);
          v_ce_2470 = v_ce0_2410;
          break;
        }
        case TAG_Just: {
          V v_x_2469 = heff_dup(heff_field(v_held_2435, 0));
          v_ce_2470 = ({ V a_0 = v_x_2469; V b_1 = heff_tag_n(TAG_KnownTag, 1, (V[]){v_n_2468}); V a_2 = v_ce0_2410; V r_ = (g_heff_2ecompile_2erefcount_2ewithKnown(a_0, b_1, a_2)); heff_drop(v_x_2469); heff_drop(b_1); r_; });
          break;
        }
        default: heff_nomatch(v_held_2435);
        }
        V v_fb_2471 = (g_heff_2ecompile_2erefcount_2efvArm(heff_dup(v_b_2462)));
        V v_ce_2472 = heff_dup(v_ce_2470);
        V v_x2_2473 = v_held_2435;
        V v_vs_2474 = heff_dup(v_vs_2461);
        V v_fb_2475 = heff_dup(v_fb_2471);
        V v_taken_2482;
        switch (heff_tag_of(v_x2_2473)) {
        case TAG_Nothing: {
          heff_drop_rec(v_ce_2472, 17);
          heff_drop(v_vs_2474);
          heff_drop(v_fb_2475);
          v_taken_2482 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x_2476 = heff_field(v_x2_2473, 0);
          V v_ru_24x2_2473_24Just = heff_take_reuse_n(v_x2_2473, 1ULL, 1);
          switch (heff_tag_of(v_vs_2474)) {
          case TAG_Nil: {
            heff_drop_rec(v_ce_2472, 17);
            heff_drop(v_fb_2475);
            heff_drop(v_x_2476);
            heff_drop_cell(v_ru_24x2_2473_24Just, 1);
            v_taken_2482 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_t_2479 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_2474; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_vs_2474, 2); r_; });
            if (heff_intLe_c(v_t_2479, MK_INT(60LL))) {
              V v_x1_2480 = ({ V a_0 = v_x_2476; V a_1 = v_fb_2475; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_fb_2475); r_; });
              if (!(heff_dup(v_x1_2480) == NTAG(TAG_True))) {
                heff_drop(v_x1_2480);
                V v_x1_2481 = ({ V a_0 = v_x_2476; V b_1 = heff_get_n(v_ce_2472, 5, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
                if (!(heff_dup(v_x1_2481) == NTAG(TAG_True))) {
                  heff_drop(v_x1_2481);
                  v_taken_2482 = heff_tag_re_n(v_ru_24x2_2473_24Just, TAG_Just, 1, 1ULL, (V[]){v_x_2476});
                } else {
                  heff_drop(v_x_2476);
                  heff_drop_cell(v_ru_24x2_2473_24Just, 1);
                  heff_drop(v_x1_2481);
                  v_taken_2482 = NTAG(TAG_Nothing);
                }
              } else {
                heff_drop_rec(v_ce_2472, 17);
                heff_drop(v_x_2476);
                heff_drop_cell(v_ru_24x2_2473_24Just, 1);
                heff_drop(v_x1_2480);
                v_taken_2482 = NTAG(TAG_Nothing);
              }
            } else {
              heff_drop_rec(v_ce_2472, 17);
              heff_drop(v_fb_2475);
              heff_drop(v_x_2476);
              heff_drop_cell(v_ru_24x2_2473_24Just, 1);
              v_taken_2482 = NTAG(TAG_Nothing);
            }
            break;
          }
          default: heff_nomatch(v_vs_2474);
          }
          break;
        }
        default: heff_nomatch(v_x2_2473);
        }
        V v_t_2485;
        switch (heff_tag_of(v_b_2462)) {
        case TAG_ATail: {
          v_t_2485 = NTAG(TAG_False);
          break;
        }
        case TAG_ASts: {
          v_t_2485 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_b_2462);
        }
        V v_t_2486 = (g_heff_2ecompile_2erefcount_2ereusing(heff_dup(heff_rfield(v_ce_2470, 15)), heff_dup(v_taken_2482), heff_dup(v_t_2460), v_vs_2461, v_b_2462));
        return ({ V a_0 = v_ce_2470; V a_1 = v_taken_2482; V a_2 = v_lent_2459; V a_3 = v_t_2460; V a_4 = v_vs_2461; V a_5 = v_fb_2471; V a_6 = v_t_2485; V a_7 = v_t_2486; V r_ = (g_heff_2ecompile_2erefcount_2earmKept_24s1427784023x2046881543(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_lent_2459); r_; });
      }
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam3(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam4(V self, V *args);
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam5(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819(V v_ce_240, V v_xs_241, V v_st_242, V v_rest_243, V v_after_244, V v_wb_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_st_242), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
  HeffT2 v_t_248 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_247));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_bs_2411 = v_field_249;
    V v_ms_2412 = v_field_2410;
    V v_ms_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2412));
    V v_t_2414 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2411; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2411); r_; });
    V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2413; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
    V v_wanted_2416 = (g_prelude_2e_2b_2b(v_t_2415, heff_dup(v_wb_245)));
    V v_xs_2419 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam0, 1, 1, (V[]){v_wanted_2416}); V a_1 = heff_dup(heff_rfield(v_ce_240, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2420 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2419));
    V v_t_2421 = (g_list_2emap_24s1796125103x644876049(v_t_2420));
    V v_t_2422 = (g_list_2emap_24s698037429x265256386(heff_dup(v_xs_241)));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_st_242), NTAG(TAG_Nil)});
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_t_2423}), NTAG(TAG_Nil)});
    HeffT2 v_t_2425 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2424));
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_bs_2428 = v_field_2426;
      V v_ms_2429 = v_field_2427;
      V v_ms_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2429));
      V v_t_2431 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2428; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2428); r_; });
      V v_t_2432 = ({ V a_0 = v_t_2431; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2430; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2431); r_; });
      V v_wanted_2433 = (g_prelude_2e_2b_2b(v_t_2432, heff_dup(v_wb_245)));
      V v_t_2435 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam1, 1, 1, (V[]){v_wanted_2433}); V a_1 = heff_dup(heff_rfield(v_ce_240, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2436 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2435, heff_dup(v_wb_245), heff_dup(v_ce_240)));
      V v_t_2437 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2436));
      V v_t_2438 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_t_2437, v_st_242));
      V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2422, v_t_2438));
      V v_xs_2442 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam2, 1, 1, (V[]){heff_dup(v_wb_245)}); V a_1 = heff_dup(v_xs_241); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2443 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2442));
      V v_t_2444 = (g_list_2emap_24s1796125103x644876049(v_t_2443));
      V v_t_2446 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam3, 1, 1, (V[]){heff_dup(v_wb_245)}); V a_1 = heff_dup(heff_rfield(v_ce_240, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_xs_2448 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam4, 1, 1, (V[]){v_wb_245}); V a_1 = v_xs_241; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2454 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam5, 1, 1, (V[]){heff_dup(v_ce_240)}); V a_1 = v_xs_2448; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2455 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2454));
      V v_t_2456 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), heff_dup(v_ce_240)));
      V v_ce_2457 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2455, heff_get_n(v_ce_240, 5, 17), v_t_2456));
      V v_t_2458 = ({ V a_0 = v_ce_2457; V a_1 = v_rest_243; V a_2 = v_after_244; V r_ = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(a_0, a_1, a_2)); heff_drop(v_ce_2457); r_; });
      V v_t_2459 = (g_prelude_2e_2b_2b(v_t_2444, v_t_2458));
      V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2459));
      return (g_prelude_2e_2b_2b(v_t_2421, v_t_2460));
    }
  }
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam0(V self, V *args) {
  V v_v_2417 = args[0];
  V v_wanted_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2418 = ({ V a_0 = v_v_2417; V a_1 = v_wanted_2416; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2417); heff_drop(v_wanted_2416); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
  heff_drop(v_x1_2418);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam1(V self, V *args) {
  V v_v_2434 = args[0];
  V v_wanted_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2434; V a_1 = v_wanted_2433; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2434); heff_drop(v_wanted_2433); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam2(V self, V *args) {
  V v_x_2440 = args[0];
  V v_wb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2441 = ({ V a_0 = v_x_2440; V a_1 = v_wb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2440); heff_drop(v_wb_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2441) == NTAG(TAG_True)));
  heff_drop(v_x1_2441);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam3(V self, V *args) {
  V v_v_2445 = args[0];
  V v_wb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2445; V a_1 = v_wb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2445); heff_drop(v_wb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam4(V self, V *args) {
  V v_x_2447 = args[0];
  V v_wb_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2447; V a_1 = v_wb_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_x_2447); heff_drop(v_wb_245); r_; });
}
V g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2450 = ({ V b_0 = heff_get_n(v_ce_240, 10, 17); V a_1 = v_x_2449; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2449); r_; });
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2451 == ((int64_t)0ULL)) ? ({ V v_x_2453 = heff_dup(v_field_2452); int c_ = 0; heff_drop(v_x_2453); c_; }) : 1));
    heff_drop(v_field_2452);
    return v_ret_24bool;
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str7, 0, "");
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry, 6, 0};

V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(V v_tag_240, V v_ce_241, V v_x3_242, V v_after_243, V v_ce_244, V v_x3_245) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187: {
    top_TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187: ;
    heff_drop(v_x3_245);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_t_246 = heff_field(v_after_243, 0);
        heff_take_n(v_after_243, 1ULL, 1);
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565);
        V t_1 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str0);
        V t_2 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str1);
        V t_3 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str2);
        V t_4 = v_ce_241;
        V t_5 = v_t_246;
        v_tag_240 = t_0;
        v_ce_241 = t_1;
        v_x3_242 = t_2;
        v_after_243 = t_3;
        v_ce_244 = t_4;
        v_x3_245 = t_5;
        goto top_TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565;
      }
      default: return heff_nomatch(v_after_243);
      }
    }
    case TAG_Cons: {
      V v_x31_247 = heff_field(v_x3_242, 0);
      V v_x32_248 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_SLet: {
        V v_x_249 = heff_field(v_x31_247, 0);
        V v_o_2410 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24SLet = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        V v_ce_2411 = heff_dup(v_ce_241);
        V v_x_2412 = v_x_249;
        V v_o_2413 = heff_dup(v_o_2410);
        V v_rest_2414 = v_x32_248;
        V v_after_2415 = v_after_243;
        HeffT3 v_t_2416 = ({ V a_0 = heff_dup(v_ce_241); V a_1 = v_o_2410; HeffT3 r_ = (g_heff_2ecompile_2erefcount_2efillOf_24cpr(a_0, a_1)); heff_drop(v_o_2410); r_; });
        {
          V v_field_2418 = v_t_2416.f[1];
          V v_field_2419 = v_t_2416.f[2];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            heff_drop(v_o_2413);
            V v_d_2420 = v_field_2418;
            V v_iv_2421 = v_field_2419;
            V v_t_2422 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_2414), heff_dup(v_after_2415)));
            V v_t_2423 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2422, heff_dup(heff_rfield(v_ce_2411, 5))));
            return (g_heff_2ecompile_2erefcount_2ebindFill_24s316269978x848286747_24tok2(v_ru_24x31_247_24SLet, v_ce_2411, v_x_2412, v_d_2420, v_iv_2421, v_rest_2414, v_after_2415, v_t_2423));
          } else {
            heff_drop(v_field_2418);
            heff_drop(v_field_2419);
            V v_ce_2424 = heff_dup(v_ce_2411);
            V v_x_2425 = heff_dup(v_x_2412);
            V v_o_2426 = heff_dup(v_o_2413);
            V v_rest_2429;
            switch (heff_tag_of(v_after_2415)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x31_247_24SLet, 2);
              v_rest_2429 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_2414)}), NTAG(TAG_Nil)});
              break;
            }
            case TAG_Just: {
              V v_t_2427 = heff_dup(heff_field(v_after_2415, 0));
              V v_t_2428 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2427}), NTAG(TAG_Nil)});
              v_rest_2429 = heff_tag_at_n(v_ru_24x31_247_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_2414)}), v_t_2428});
              break;
            }
            default: heff_nomatch(v_after_2415);
            }
            V v_t_2461;
            switch (heff_tag_of(v_o_2426)) {
            case TAG_OSimple: {
              V v_o1_2430 = heff_field(v_o_2426, 0);
              V v_ru_24o_2426_24OSimple = heff_take_reuse_n(v_o_2426, 1ULL, 1);
              switch (heff_tag_of(v_o1_2430)) {
              case TAG_SVar: {
                heff_take_n(v_o1_2430, 0ULL, 1);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SGlobal: {
                heff_take_n(v_o1_2430, 0ULL, 1);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SInt: {
                heff_take_n(v_o1_2430, 0ULL, 1);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SFloat: {
                heff_take_na(v_o1_2430, 0ULL, 1);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SStr: {
                heff_take_n(v_o1_2430, 0ULL, 1);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SBytes: {
                heff_take_n(v_o1_2430, 0ULL, 1);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SFixed: {
                heff_take_n(v_o1_2430, 0ULL, 2);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SFloat32: {
                heff_take_na(v_o1_2430, 0ULL, 1);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SPrimFn: {
                heff_take_n(v_o1_2430, 0ULL, 1);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SLam: {
                heff_take_n(v_o1_2430, 0ULL, 2);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_STag: {
                heff_take_n(v_o1_2430, 0ULL, 3);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SRec: {
                heff_take_n(v_o1_2430, 0ULL, 2);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SProj: {
                heff_take_n(v_o1_2430, 0ULL, 4);
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_SPrim: {
                V v_o11_2452 = heff_field(v_o1_2430, 0);
                V v_argv_2453 = heff_field(v_o1_2430, 1);
                heff_take_n(v_o1_2430, 3ULL, 2);
                switch (heff_tag_of(v_o11_2452)) {
                case TAG_ArrayIndex: {
                  v_t_2461 = (g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(v_ru_24o_2426_24OSimple, v_ce_2424, v_x_2425, v_argv_2453, v_rest_2429));
                  break;
                }
                default: {
                  heff_drop(v_ce_2424);
                  heff_drop(v_x_2425);
                  heff_drop(v_rest_2429);
                  heff_drop_cell(v_ru_24o_2426_24OSimple, 1);
                  heff_drop(v_o11_2452);
                  heff_drop(v_argv_2453);
                  v_t_2461 = NTAG(TAG_Nothing);
                  break;
                }
                }
                break;
              }
              default: heff_nomatch(v_o1_2430);
              }
              break;
            }
            case TAG_OCall: {
              heff_take_n(v_o_2426, 0ULL, 2);
              heff_drop(v_ce_2424);
              heff_drop(v_x_2425);
              heff_drop(v_rest_2429);
              v_t_2461 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_OApply: {
              heff_take_n(v_o_2426, 0ULL, 2);
              heff_drop(v_ce_2424);
              heff_drop(v_x_2425);
              heff_drop(v_rest_2429);
              v_t_2461 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_OPrim: {
              V v_o1_2458 = heff_field(v_o_2426, 0);
              V v_argv_2459 = heff_field(v_o_2426, 1);
              V v_ru_24o_2426_24OPrim = heff_take_reuse_n(v_o_2426, 3ULL, 2);
              switch (heff_tag_of(v_o1_2458)) {
              case TAG_ArrayIndex: {
                v_t_2461 = (g_heff_2ecompile_2erefcount_2epeekArgs_24tok2(v_ru_24o_2426_24OPrim, v_ce_2424, v_x_2425, v_argv_2459, v_rest_2429));
                break;
              }
              default: {
                heff_drop(v_ce_2424);
                heff_drop(v_x_2425);
                heff_drop(v_rest_2429);
                heff_drop(v_o1_2458);
                heff_drop(v_argv_2459);
                heff_drop_cell(v_ru_24o_2426_24OPrim, 2);
                v_t_2461 = NTAG(TAG_Nothing);
                break;
              }
              }
              break;
            }
            case TAG_OAbandon: {
              heff_drop(v_ce_2424);
              heff_drop(v_x_2425);
              heff_drop(v_rest_2429);
              v_t_2461 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_OBool: {
              heff_take_n(v_o_2426, 0ULL, 1);
              heff_drop(v_ce_2424);
              heff_drop(v_x_2425);
              heff_drop(v_rest_2429);
              v_t_2461 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_o_2426);
            }
            return ({ V a_0 = v_ce_2411; V a_1 = v_x_2412; V a_2 = v_o_2413; V a_3 = v_rest_2414; V a_4 = v_after_2415; V a_5 = v_t_2461; V r_ = (g_heff_2ecompile_2erefcount_2eletOf_24s1888514151x438283377(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2461); r_; });
          }
        }
      }
      case TAG_SOnce: {
        V v_t_2464 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_241), v_x31_247));
        V v_t_2465 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
        return (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2464, v_t_2465));
      }
      case TAG_SDecl: {
        V v_x_2466 = heff_dup(heff_field(v_x31_247, 0));
        switch (heff_tag_of(v_x32_248)) {
        case TAG_Nil: {
          heff_drop(v_x_2466);
          V v_t_2467 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_241), v_x31_247));
          V v_t_2468 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
          return (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2467, v_t_2468));
        }
        case TAG_Cons: {
          V v_x321_2469 = heff_field(v_x32_248, 0);
          V v_more_2470 = heff_field(v_x32_248, 1);
          V v_ru_24x32_248_24Cons = heff_take_reuse_n(v_x32_248, 3ULL, 2);
          heff_drop_tag(v_x31_247, 1);
          switch (heff_tag_of(v_x321_2469)) {
          case TAG_SDecl: {
            V v_y_2471 = heff_field(v_x321_2469, 0);
            heff_take_n(v_x321_2469, 1ULL, 1);
            V v_t_2472 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_2471, NTAG(TAG_Nil)});
            HeffT2 v_t_2473 = (g_heff_2ecompile_2erefcount_2edeclRun_24cpr(heff_tag_at_n(v_ru_24x32_248_24Cons, TAG_Cons, 2, (V[]){v_x_2466, v_t_2472}), v_more_2470));
            {
              V v_field_2474 = v_t_2473.f[0];
              V v_field_2475 = v_t_2473.f[1];
              V v_xs_2476 = v_field_2474;
              V v_x32_2477 = v_field_2475;
              switch (heff_tag_of(v_x32_2477)) {
              case TAG_Nil: {
                heff_drop(v_xs_2476);
                switch (heff_tag_of(v_after_243)) {
                case TAG_Nothing: {
                  return NTAG(TAG_Nil);
                }
                case TAG_Just: {
                  V v_t_2478 = heff_field(v_after_243, 0);
                  heff_take_n(v_after_243, 1ULL, 1);
                  V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565);
                  V t_1 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str3);
                  V t_2 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str4);
                  V t_3 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str5);
                  V t_4 = v_ce_241;
                  V t_5 = v_t_2478;
                  v_tag_240 = t_0;
                  v_ce_241 = t_1;
                  v_x3_242 = t_2;
                  v_after_243 = t_3;
                  v_ce_244 = t_4;
                  v_x3_245 = t_5;
                  goto top_TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565;
                }
                default: return heff_nomatch(v_after_243);
                }
              }
              case TAG_Cons: {
                V v_st_2479 = heff_field(v_x32_2477, 0);
                V v_rest_2480 = heff_field(v_x32_2477, 1);
                V v_ru_24x32_2477_24Cons = heff_take_reuse_n(v_x32_2477, 3ULL, 2);
                V v_t_2481 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_rest_2480), heff_dup(v_after_243)));
                V v_t_2482 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x32_2477_24Cons, v_t_2481, heff_dup(heff_rfield(v_ce_241, 5))));
                HEFF_LAST return g_heff_2ecompile_2erefcount_2edeclsWith_24s48187084x895101819(heff_dup(v_ce_241), v_xs_2476, v_st_2479, v_rest_2480, v_after_243, v_t_2482);
              }
              default: return heff_nomatch(v_x32_2477);
              }
            }
          }
          default: {
            V v_t_2483 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x321_2469), NTAG(TAG_Nil)});
            V v_t_2484 = heff_tag_at_n(v_ru_24x32_248_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_t_2483}), NTAG(TAG_Nil)});
            HeffT2 v_t_2485 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2484));
            {
              V v_field_2486 = v_t_2485.f[0];
              V v_field_2487 = v_t_2485.f[1];
              V v_bs_2488 = v_field_2486;
              V v_ms_2489 = v_field_2487;
              V v_ms_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2489));
              V v_t_2491 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2488; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2488); r_; });
              V v_fa_2492 = ({ V a_0 = v_t_2491; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2490; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2491); r_; });
              V v_t_2493 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_more_2470), heff_dup(v_after_243)));
              V v_t_2494 = (g_prelude_2e_2b_2b(v_t_2493, heff_dup(heff_rfield(v_ce_241, 5))));
              return (g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(heff_dup(v_ce_241), heff_dup(v_x_2466), v_fa_2492, heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam0, 1, 2, (V[]){v_x321_2469, v_x_2466}), NTAG(TAG_Nothing), NTAG(TAG_Nil), v_more_2470, v_after_243, v_t_2494));
            }
          }
          }
        }
        default: return heff_nomatch(v_x32_248);
        }
      }
      case TAG_SSet: {
        V v_x_2497 = heff_field(v_x31_247, 0);
        V v_o_2498 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24SSet = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        V v_t_2499 = (g_heff_2ecompile_2erefcount_2efvRest(heff_dup(v_x32_248), heff_dup(v_after_243)));
        V v_live_24100 = (g_prelude_2e_2b_2b(v_t_2499, heff_dup(heff_rfield(v_ce_241, 5))));
        HeffT2 v_t_24101 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_241, 10), v_x_2497));
        {
          V v_field_24103 = v_t_24101.f[1];
          int64_t v_tag_24102 = ((int64_t)v_t_24101.f[0]);
          V v_t_24105;
          if ((v_tag_24102 == ((int64_t)0ULL))) {
            V v_x_24104 = v_field_24103;
            v_t_24105 = v_x_24104;
          } else {
            heff_drop(v_field_24103);
            v_t_24105 = NTAG(TAG_RepV);
          }
          V v_t_24106 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_241), v_live_24100, v_t_24105, heff_dup(v_o_2498)));
          V v_t_24119;
          switch (heff_tag_of(v_o_2498)) {
          case TAG_OSimple: {
            heff_take_n(v_o_2498, 0ULL, 1);
            v_t_24119 = NTAG(TAG_Nil);
            break;
          }
          case TAG_OCall: {
            heff_take_n(v_o_2498, 0ULL, 2);
            v_t_24119 = NTAG(TAG_Nil);
            break;
          }
          case TAG_OApply: {
            heff_take_n(v_o_2498, 0ULL, 2);
            v_t_24119 = NTAG(TAG_Nil);
            break;
          }
          case TAG_OPrim: {
            heff_take_n(v_o_2498, 0ULL, 2);
            v_t_24119 = NTAG(TAG_Nil);
            break;
          }
          case TAG_OAbandon: {
            v_t_24119 = NTAG(TAG_Nil);
            break;
          }
          case TAG_OBool: {
            V v_ru_24o_2498_24OBool = heff_take_reuse_n(v_o_2498, 0ULL, 1);
            V v_xs_24117 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam1, 1, 1, (V[]){heff_dup(v_ce_241)}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_24118 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_24117));
            v_t_24119 = (g_list_2emap_24s1796125103x644876049_24tok1(v_ru_24o_2498_24OBool, v_t_24118));
            break;
          }
          default: heff_nomatch(v_o_2498);
          }
          V v_t_24120 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
          V v_t_24121 = (g_prelude_2e_2b_2b(v_t_24119, v_t_24120));
          return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_247_24SSet, TAG_CSet, 2, (V[]){v_x_2497, v_t_24106}), v_t_24121});
        }
      }
      case TAG_SIf: {
        V v_t_24125 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_241), v_x31_247));
        V v_t_24126 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
        return (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_24125, v_t_24126));
      }
      case TAG_SCase: {
        V v_t_24129 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(heff_dup(v_ce_241), v_x31_247));
        V v_t_24130 = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(v_ce_241, v_x32_248, v_after_243));
        return (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_24129, v_t_24130));
      }
      default: return heff_nomatch(v_x31_247);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565: {
    top_TAG_Enter_24heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565: ;
    heff_drop(v_x3_242);
    heff_drop(v_after_243);
    switch (heff_tag_of(v_x3_245)) {
    case TAG_TSeq: {
      V v_ss_24131 = heff_field(v_x3_245, 0);
      V v_t_24132 = heff_field(v_x3_245, 1);
      heff_take_n(v_x3_245, 3ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187);
      V t_1 = v_ce_244;
      V t_2 = v_ss_24131;
      V t_3 = heff_tag_n(TAG_Just, 1, (V[]){v_t_24132});
      V t_4 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str6);
      V t_5 = ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_str7);
      v_tag_240 = t_0;
      v_ce_241 = t_1;
      v_x3_242 = t_2;
      v_after_243 = t_3;
      v_ce_244 = t_4;
      v_x3_245 = t_5;
      goto top_TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187;
    }
    case TAG_TReturn: {
      V v_x31_24133 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24TReturn = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_24133)) {
      case TAG_OSimple: {
        V v_want_24135 = heff_dup(heff_rfield(v_ce_244, 16));
        V v_t_24136 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_244), NTAG(TAG_Nil), v_want_24135, v_x31_24133));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24136}), NTAG(TAG_Nil)});
      }
      case TAG_OCall: {
        V v_g_24137 = heff_field(v_x31_24133, 0);
        V v_argv_24138 = heff_field(v_x31_24133, 1);
        heff_take_n(v_x31_24133, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_245_24TReturn, 1);
        return (g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(heff_dup(v_ce_244), v_g_24137, v_argv_24138));
      }
      case TAG_OApply: {
        V v_f_24139 = heff_field(v_x31_24133, 0);
        V v_argv_24140 = heff_field(v_x31_24133, 1);
        V v_ru_24x31_24133_24OApply = heff_take_reuse_n(v_x31_24133, 3ULL, 2);
        V v_t_24141 = heff_dup(heff_rfield(v_ce_244, 16));
        switch (heff_tag_of(v_t_24141)) {
        case TAG_RepV: {
          heff_drop_cell(v_ru_24x3_245_24TReturn, 1);
          V v_n_24142 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_24140));
          V v_t_24143 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_argv_24140)));
          V v_t_24144 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_24143));
          V v_live_24145 = (g_prelude_2e_2b_2b(v_t_24144, NTAG(TAG_Nil)));
          V v_t_24146 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_244), v_live_24145, NTAG(TAG_RepV), v_f_24139));
          V v_t_24147 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(heff_dup(v_ce_244), NTAG(TAG_Nil), v_argv_24140));
          V v_t_24148;
          if ((heff_intLt_c_lent(MK_INT(0LL), v_n_24142, 1) && heff_intLe_c(heff_dup(v_n_24142), heff_dup(heff_rfield(v_ce_244, 3))))) {
            heff_drop(v_n_24142);
            v_t_24148 = heff_tag_at_n(v_ru_24x31_24133_24OApply, TAG_CInPlace, 2, (V[]){v_t_24146, v_t_24147});
          } else {
            if ((heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_ce_244, 3))) && heff_intLe_c_lent(v_n_24142, MK_INT(4LL), 2))) {
              heff_drop(v_n_24142);
              v_t_24148 = heff_tag_at_n(v_ru_24x31_24133_24OApply, TAG_CRoomed, 2, (V[]){v_t_24146, v_t_24147});
            } else {
              heff_drop(v_n_24142);
              v_t_24148 = heff_tag_at_n(v_ru_24x31_24133_24OApply, TAG_CTail, 2, (V[]){v_t_24146, v_t_24147});
            }
          }
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24148, NTAG(TAG_Nil)});
        }
        case TAG_RepFix: {
          heff_take_n(v_t_24141, 0ULL, 1);
          V v_want_24150 = heff_dup(heff_rfield(v_ce_244, 16));
          V v_t_24151 = (g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044(v_f_24139, v_argv_24140, heff_dup(v_ce_244), NTAG(TAG_Nil), v_want_24150));
          return heff_tag_at_n(v_ru_24x31_24133_24OApply, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24151}), NTAG(TAG_Nil)});
        }
        case TAG_RepF64: {
          V v_want_24152 = heff_dup(heff_rfield(v_ce_244, 16));
          V v_t_24153 = (g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044(v_f_24139, v_argv_24140, heff_dup(v_ce_244), NTAG(TAG_Nil), v_want_24152));
          return heff_tag_at_n(v_ru_24x31_24133_24OApply, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24153}), NTAG(TAG_Nil)});
        }
        case TAG_RepInt: {
          V v_want_24154 = heff_dup(heff_rfield(v_ce_244, 16));
          V v_t_24155 = (g_heff_2ecompile_2erefcount_2ecompF_24s1698420325x171419044(v_f_24139, v_argv_24140, heff_dup(v_ce_244), NTAG(TAG_Nil), v_want_24154));
          return heff_tag_at_n(v_ru_24x31_24133_24OApply, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24155}), NTAG(TAG_Nil)});
        }
        default: return heff_nomatch(v_t_24141);
        }
      }
      case TAG_OPrim: {
        V v_want_24158 = heff_dup(heff_rfield(v_ce_244, 16));
        V v_t_24159 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_244), NTAG(TAG_Nil), v_want_24158, v_x31_24133));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24159}), NTAG(TAG_Nil)});
      }
      case TAG_OAbandon: {
        V v_want_24160 = heff_dup(heff_rfield(v_ce_244, 16));
        V v_t_24161 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_244), NTAG(TAG_Nil), v_want_24160, v_x31_24133));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_CReturn, 1, (V[]){v_t_24161}), NTAG(TAG_Nil)});
      }
      case TAG_OBool: {
        V v_c_24162 = heff_field(v_x31_24133, 0);
        V v_ru_24x31_24133_24OBool = heff_take_reuse_n(v_x31_24133, 1ULL, 1);
        V v_lit_24163 = v_c_24162;
        V v_ce_24164 = heff_dup(v_ce_244);
        V v_want_24165 = NTAG(TAG_RepV);
        V v_lit_24166 = v_lit_24163;
        V v_ce_24167 = v_ce_24164;
        V v_t_24168 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_24167, 4)), heff_dup(heff_rfield(v_ce_24167, 6))));
        V v_t_24169 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_24168, v_ce_24167));
        V v_t_24170 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_24169));
        V v_t_24171 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_24170, v_lit_24166));
        V v_t_24172 = (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), v_want_24165, heff_tag_at_n(v_ru_24x3_245_24TReturn, TAG_RBool, 1, (V[]){v_t_24171})));
        V v_xs_24173 = heff_dup(heff_rfield(v_ce_244, 4));
        V v_t_24174 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_244), v_xs_24173));
        V v_t_24175 = (g_list_2emap_24s1796125103x644876049(v_t_24174));
        V v_t_24176 = (g_heff_2ecompile_2erefcount_2ecoerce(NTAG(TAG_RepV), heff_dup(heff_rfield(v_ce_244, 16)), heff_tag_at_n(v_ru_24x31_24133_24OBool, TAG_RLocal, 1, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2eboolName_get())})));
        V v_t_24177 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_24176}), NTAG(TAG_Nil)});
        V v_t_24178 = (g_prelude_2e_2b_2b(v_t_24175, v_t_24177));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2eboolName_get()), v_t_24172}), v_t_24178});
      }
      default: return heff_nomatch(v_x31_24133);
      }
    }
    case TAG_TLoop: {
      V v_argv_24179 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24TLoop = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      V v_t_24180 = heff_dup(heff_rfield(v_ce_244, 2));
      switch (heff_tag_of(v_t_24180)) {
      case TAG_Nothing: {
        heff_drop(v_argv_24179);
        V v_t_24181 = heff_tag_at_n(v_ru_24x3_245_24TLoop, TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24181, NTAG(TAG_Nil)});
      }
      case TAG_Just: {
        V v_s_24182 = heff_field(v_t_24180, 0);
        heff_take_n(v_t_24180, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_245_24TLoop, 1);
        return (g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(heff_dup(v_ce_244), heff_get_n(v_s_24182, 0, 3), v_argv_24179));
      }
      default: return heff_nomatch(v_t_24180);
      }
    }
    case TAG_TIf: {
      V v_x31_24183 = heff_field(v_x3_245, 0);
      V v_t_24184 = heff_field(v_x3_245, 1);
      V v_e_24185 = heff_field(v_x3_245, 2);
      V v_ru_24x3_245_24TIf = heff_take_reuse_n(v_x3_245, 7ULL, 3);
      switch (heff_tag_of(v_x31_24183)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return (g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(v_e_24185, v_t_24184, heff_dup(v_ce_244), v_x31_24183));
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return (g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(v_e_24185, v_t_24184, heff_dup(v_ce_244), v_x31_24183));
      }
      case TAG_PRel: {
        V v_p_24186 = heff_field(v_x31_24183, 0);
        V v_a_24187 = heff_field(v_x31_24183, 1);
        V v_b_24188 = heff_field(v_x31_24183, 2);
        heff_take_n(v_x31_24183, 7ULL, 3);
        V v_t_24189 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_24187), NTAG(TAG_Nil)});
        V v_t_24190 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_24188), v_t_24189})));
        V v_t_24191 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ATail, 1, (V[]){heff_dup(v_t_24184)})));
        V v_t_24192 = (g_heff_2ecompile_2erefcount_2efvArm(heff_tag_n(TAG_ATail, 1, (V[]){heff_dup(v_e_24185)})));
        V v_t_24193 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_244, 5)), v_t_24191, v_t_24192));
        return (g_heff_2ecompile_2erefcount_2econdWith_24s1784199489x1137278239_24tok3(v_ru_24x3_245_24TIf, v_e_24185, v_t_24184, v_a_24187, v_b_24188, heff_dup(v_ce_244), v_p_24186, v_t_24190, v_t_24193));
      }
      case TAG_PBool: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return (g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(v_e_24185, v_t_24184, heff_dup(v_ce_244), v_x31_24183));
      }
      case TAG_PNot: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return (g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(v_e_24185, v_t_24184, heff_dup(v_ce_244), v_x31_24183));
      }
      case TAG_PIf: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return (g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(v_e_24185, v_t_24184, heff_dup(v_ce_244), v_x31_24183));
      }
      case TAG_PLet: {
        heff_drop_cell(v_ru_24x3_245_24TIf, 3);
        return (g_heff_2ecompile_2erefcount_2econdTest_24s1160124087x879725619(v_e_24185, v_t_24184, heff_dup(v_ce_244), v_x31_24183));
      }
      default: return heff_nomatch(v_x31_24183);
      }
    }
    case TAG_TCase: {
      V v_v_24202 = heff_field(v_x3_245, 0);
      V v_arms_24203 = heff_field(v_x3_245, 1);
      V v_ru_24x3_245_24TCase = heff_take_reuse_n(v_x3_245, 3ULL, 2);
      V v_t_24204 = (g_list_2emap_24s1341404685x1564972929(v_arms_24203));
      V v_t_24205 = (g_heff_2ecompile_2erefcount_2ematchOf_24s1627239267x1606658195(heff_dup(v_ce_244), NTAG(TAG_True), v_v_24202, v_t_24204));
      return heff_tag_at_n(v_ru_24x3_245_24TCase, TAG_Cons, 2, (V[]){v_t_24205, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(a0, a1, a[2], a[3], a4, a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam0(V self, V *args) {
  V v_ce2_2495 = args[0];
  V v_x321_2469 = heff_env(self)[0];
  V v_x_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2496 = (g_heff_2ecompile_2erefcount_2esetting_24s328519778x579905533(v_ce2_2495, v_x321_2469));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_2466}), v_t_2496});
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle_lam1(V self, V *args) {
  V v_v_24115 = args[0];
  V v_ce_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24116 = ({ V a_0 = v_v_24115; V b_1 = heff_get_n(v_ce_241, 5, 17); V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, b_1)); heff_drop(v_v_24115); heff_drop(b_1); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_24116) == NTAG(TAG_True)));
  heff_drop(v_x1_24116);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_str1, 0, "");
Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V v_ce_240, V v_x3_241, V v_after_242) {
top: ;
  return (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187), v_ce_240, v_x3_241, v_after_242, ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_str0), ((V)&g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_str1)));
}
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry, 7, 0};

V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(V v_ce_240, V v_live_241, V v_before_242, V v_bi_243, V v_i_244, V v_x7_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 17);
    heff_drop(v_live_241);
    heff_drop(v_before_242);
    heff_drop(v_bi_243);
    heff_drop(v_i_244);
    heff_drop(v_x8_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_247 = heff_field(v_x7_245, 0);
    V v_ps_248 = heff_field(v_x7_245, 1);
    V v_ru_24x7_245_24Cons = heff_take_reuse_n(v_x7_245, 3ULL, 2);
    switch (heff_tag_of(v_x8_246)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 17);
      heff_drop(v_live_241);
      heff_drop(v_before_242);
      heff_drop(v_bi_243);
      heff_drop(v_i_244);
      heff_drop(v_p_247);
      heff_drop(v_ps_248);
      heff_drop_cell(v_ru_24x7_245_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x8_246, 0);
      V v_es_2410 = heff_field(v_x8_246, 1);
      V v_ru_24x8_246_24Cons = heff_take_reuse_n(v_x8_246, 3ULL, 2);
      HeffT2 v_t_2411 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_240, 10), v_p_247));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        V v_t_2425;
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2413;
          heff_drop(v_x_2414);
          V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2410)));
          V v_t_2416 = (g_list_2efoldl_24s1050197499x1941129217(NTAG(TAG_Nil), v_t_2415));
          V v_t_2417 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x8_246_24Cons, v_t_2416, heff_dup(v_live_241)));
          V v_live_2418 = (g_prelude_2e_2b_2b(heff_dup(v_before_242), v_t_2417));
          HeffT2 v_t_2419 = ({ V a_0 = heff_rfield(v_ce_240, 10); V a_1 = v_p_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_p_247); r_; });
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            V v_t_2423;
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_x_2422 = v_field_2421;
              v_t_2423 = v_x_2422;
            } else {
              heff_drop(v_field_2421);
              v_t_2423 = NTAG(TAG_RepV);
            }
            V v_t_2424 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), v_live_2418, v_t_2423, heff_dup(v_e_249)));
            v_t_2425 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2424});
          }
        } else {
          heff_drop(v_p_247);
          heff_drop_cell(v_ru_24x8_246_24Cons, 2);
          heff_drop(v_field_2413);
          v_t_2425 = (g_heff_2ecompile_2erefcount_2elentAt_24s92070524x549394263(heff_dup(v_ce_240), heff_dup(v_live_241), heff_dup(v_before_242), heff_dup(v_bi_243), heff_dup(v_i_244), heff_dup(v_e_249), heff_dup(v_es_2410)));
        }
        V v_t_2426 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_bi_243; V a_2 = v_i_244; V a_3 = v_e_249; V a_4 = v_before_242; V r_ = (g_heff_2ecompile_2erefcount_2elentThen(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_e_249); r_; });
        V v_cell_2427 = heff_tag_at_n(v_ru_24x7_245_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
        V v_u_2428 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_t_2426; V a_3 = v_bi_243; V a_4 = heff_box_word((heff_unbox_word(v_i_244) + ((int64_t)1ULL))); V a_5 = v_ps_248; V a_6 = v_es_2410; V a_7 = v_cell_2427; V r_ = (g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_24dps(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop_rec(v_ce_240, 17); heff_drop(v_live_241); heff_drop(v_bi_243); r_; });
        heff_drop(v_u_2428);
        return v_cell_2427;
      }
    }
    default: return heff_nomatch(v_x8_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(V v_ce_240, V v_g_241, V v_argv_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 7), v_g_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_t_247;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_245;
      v_t_247 = v_x_246;
    } else {
      heff_drop(v_field_245);
      v_t_247 = NTAG(TAG_Nil);
    }
    V v_t_248 = heff_dup(heff_rfield(v_ce_240, 2));
    V v_t_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_s_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_t_2410 = heff_get_n(v_s_249, 1, 3);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2411 = (g_heff_2ecompile_2erefcount_2eloopOperands_24s183814675x704985436(heff_dup(v_ce_240), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_247, MK_INT(0LL), v_t_2410, heff_dup(v_argv_242)));
    HeffT2 v_t_2412 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 7), v_g_241));
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      V v_t_2416;
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2415 = v_field_2414;
        v_t_2416 = v_x_2415;
      } else {
        heff_drop(v_field_2414);
        v_t_2416 = NTAG(TAG_Nil);
      }
      HeffT2 v_t_2417 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_g_241));
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        V v_t_2421;
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_s_2420 = v_field_2419;
          v_t_2421 = heff_get_n(v_s_2420, 0, 2);
        } else {
          heff_drop(v_field_2419);
          v_t_2421 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_argv_242)));
        }
        V v_t_2422 = (g_heff_2ecompile_2erefcount_2esigOperands_24s2047254689x1606983596(heff_dup(v_ce_240), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2416, MK_INT(0LL), v_t_2421, heff_dup(v_argv_242)));
        return (g_heff_2ecompile_2erefcount_2ecallAs(v_ce_240, v_g_241, v_argv_242, v_t_2411, v_t_2422));
      }
    }
  }
}
V g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ecallLast_24s37021083x2023389091(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam2(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_entry, 8, 0};

V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1(V v_tok_240, V v_ce_241, V v_x_242, V v_a_243, V v_i_244, V v_rest_245, V v_after_246, V v_wb_247) {
top: ;
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_IVal, 1, (V[]){heff_dup(v_i_244)}), NTAG(TAG_Nil)});
  HeffT2 v_t_249 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_248));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_bs_2412 = v_field_2410;
    V v_ms_2413 = v_field_2411;
    V v_ms_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2413));
    V v_t_2415 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2412; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2412); r_; });
    V v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2414; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); r_; });
    V v_wanted_2417 = (g_prelude_2e_2b_2b(v_t_2416, heff_dup(v_wb_247)));
    V v_xs_2420 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam0, 1, 1, (V[]){v_wanted_2417}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2421 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_241), v_xs_2420));
    V v_t_2422 = (g_list_2emap_24s1796125103x644876049(v_t_2421));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){heff_dup(v_i_244)}), NTAG(TAG_Nil)});
    HeffT2 v_t_2424 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2423));
    {
      V v_field_2425 = v_t_2424.f[0];
      V v_field_2426 = v_t_2424.f[1];
      V v_bs_2427 = v_field_2425;
      V v_ms_2428 = v_field_2426;
      V v_ms_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2428));
      V v_t_2430 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2427; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2427); r_; });
      V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2429; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2430); r_; });
      V v_wanted_2432 = (g_prelude_2e_2b_2b(v_t_2431, heff_dup(v_wb_247)));
      V v_t_2434 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam1, 1, 1, (V[]){v_wanted_2432}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_ce_2435 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2434, heff_dup(v_wb_247), heff_dup(v_ce_241)));
      V v_t_2436 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(v_ce_2435, heff_dup(v_wb_247), NTAG(TAG_RepV), v_i_244));
      V v_t_2438 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam2, 1, 1, (V[]){v_wb_247}); V a_1 = heff_dup(heff_rfield(v_ce_241, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_dup(heff_rfield(v_ce_241, 6))});
      V v_t_2440 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2439, heff_dup(v_ce_241)));
      V v_ce_2441 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2438, heff_get_n(v_ce_241, 5, 17), v_t_2440));
      V v_t_2442 = ({ V a_0 = v_ce_2441; V a_1 = v_rest_245; V a_2 = v_after_246; V r_ = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(a_0, a_1, a_2)); heff_drop(v_ce_2441); r_; });
      V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
      V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_a_243}), v_t_2443});
      V v_t_2445 = heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, heff_tag_n(TAG_RPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2epeekPrim_get()), v_t_2444})});
      return (g_prelude_2e_2b_2b(v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2442})));
    }
  }
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam0(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wanted_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2419 = ({ V a_0 = v_v_2418; V a_1 = v_wanted_2417; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2418); heff_drop(v_wanted_2417); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2419) == NTAG(TAG_True)));
  heff_drop(v_x1_2419);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam1(V self, V *args) {
  V v_v_2433 = args[0];
  V v_wanted_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2433; V a_1 = v_wanted_2432; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2433); heff_drop(v_wanted_2432); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindPeek_24s453266776x971239646_24tok1_lam2(V self, V *args) {
  V v_v_2437 = args[0];
  V v_wb_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2437; V a_1 = v_wb_247; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2437); heff_drop(v_wb_247); r_; });
}