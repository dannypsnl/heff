// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_c 317
#define LBL_cmt 308164
#define LBL_command 1182252425
#define LBL_custody 1359790159
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_ended 298010324
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_file 9638467
#define LBL_first 298798794
#define LBL_fuel 9649789
#define LBL_globals 352931696
#define LBL_group 299987609
#define LBL_i 323
#define LBL_info 9732469
#define LBL_input 301716452
#define LBL_js 10160
#define LBL_keep 9783372
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_lines 304335641
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_outPath 1272254166
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_ships 310766033
#define LBL_source 1050636102
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_timeout 1065429926
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_info[] = {LBL_info};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
V g_co_2eop_24s1014403878x489449937(V, V, V, V, V);
V g_co_2eop_24s1014403878x489449937_entry(V self, V *a);
extern Clo g_co_2eop_24s1014403878x489449937_clo;
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_co_2eop_24s677923597x1834241003(V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s677923597x1834241003_entry(V self, V *a);
extern Clo g_co_2eop_24s677923597x1834241003_clo;
V g_co_2eop_24s774411652x2032095250(V, V, V, V, V, V, V, V);
V g_co_2eop_24s774411652x2032095250_entry(V self, V *a);
extern Clo g_co_2eop_24s774411652x2032095250_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_clo;
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624(V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144(V);
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_clo;
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907(V, V, V);
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2ecommands_2eruntimeOf(V, V, V);
V g_heff_2ebuild_2ecommands_2eruntimeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eruntimeOf_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efits(V, V);
V g_heff_2ebuild_2edriver_2efits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efits_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eproject_2ebuildOf(V);
V g_heff_2ebuild_2eproject_2ebuildOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ebuildOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
HeffT2 g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V);
HeffT2 g_heff_2ecompile_2elower_2efusedOf_24cpr(V, V);
V g_heff_2ecompile_2elower_2eshared(V, V, V, V);
V g_heff_2ecompile_2elower_2eshared_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eshared_clo;
HeffT3 g_heff_2ecompile_2elower_2esharedLowered_24cpr(V, V);
V g_heff_2ecompile_2eshake_2ereachGo(V, V, V);
V g_heff_2ecompile_2eshake_2ereachGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eshake_2ereachGo_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634(V, V, V);
V g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634_clo;
V g_list_2eany_24s1389940534x233790531(V);
V g_list_2eany_24s1389940534x233790531_entry(V self, V *a);
extern Clo g_list_2eany_24s1389940534x233790531_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eany_24s331724893x1262243254(V);
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a);
extern Clo g_list_2eany_24s331724893x1262243254_clo;
V g_list_2eany_24s636062554x368623714(V);
V g_list_2eany_24s636062554x368623714_entry(V self, V *a);
extern Clo g_list_2eany_24s636062554x368623714_clo;
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1442652634x1828296957(V, V);
V g_list_2efoldl_24s1442652634x1828296957_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1442652634x1828296957_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s644510009x1719377493(V, V);
V g_list_2efoldl_24s644510009x1719377493_entry(V self, V *a);
extern Clo g_list_2efoldl_24s644510009x1719377493_clo;
V g_list_2efoldl_24s650566757x317183241(V, V, V);
V g_list_2efoldl_24s650566757x317183241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s650566757x317183241_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24f428638463x2144521938(V, V, V, V);
V g_list_2ekeepIf_24f428638463x2144521938_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f428638463x2144521938_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f2124896334x71745266(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_clo;
V g_list_2emap_24s129316455x2072694707(V);
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s456574265x331130481(V, V, V, V, V);
V g_list_2emap_24s456574265x331130481_entry(V self, V *a);
extern Clo g_list_2emap_24s456574265x331130481_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2ewords_2ewordsFrom_240(V, V, V, V);
V g_prelude_2ewords_2ewordsFrom_240_entry(V self, V *a);
extern Clo g_prelude_2ewords_2ewordsFrom_240_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);

HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_s_242, 0));
    V v_path_245 = heff_dup(heff_rfield(v_s_242, 2));
    if (heff_strEq_c_lent(v_module_244, v_m_241, 1)) {
      V v_f_246 = v_path_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_path_245);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8, 1, "$");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_module_244 = heff_dup(heff_rfield(v_p_242, 0));
    V v_text_245 = heff_dup(heff_rfield(v_p_242, 1));
    V v_t_246 = (g_prelude_2esplit_2esplitFrom_240(v_k_241, ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1), v_k_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_x2_247 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    if (heff_strEq_c(v_module_244, v_t_2410)) {
      V v_t_2411 = (g_prelude_2esplit_2esplitFrom_240(v_k_241, ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5), v_k_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
      V v_t_2412 = ({ V a_0 = v_k_241; V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_text_2413 = v_text_245;
      V v_t_2414 = ({ V a_0 = v_text_2413; V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str6); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str7), v_text_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_2413); r_; });
      V v_t_2415 = (g_list_2emap_24s732475005x1616712052(v_t_2414));
      V v_t_2416 = (g_list_2ekeepIf_24f428638463x2144521938(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str8), v_t_2415));
      V v_t_2417 = ({ V a_0 = v_t_2412; V a_1 = v_t_2416; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_t_2416); r_; });
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_t_2417);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2417);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_text_245);
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeaf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eruntimeOf_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eruntimeOf_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eruntimeOf_str2, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eruntimeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eruntimeOf_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eruntimeOf(V v_fuel_240, V v_provs_241, V v_rt_242) {
top: ;
  V v_c_243 = heff_take_field(v_rt_242, 0);
  V v_fuel_244 = heff_take_field(v_rt_242, 2);
  V v_custody_245 = heff_get_n(v_rt_242, 3, 4);
  V v_c_247;
  if ((heff_dup(v_fuel_240) == NTAG(TAG_True))) {
    v_c_247 = heff_strAppend(heff_strAppend(v_c_243, ((V)&g_heff_2ebuild_2ecommands_2eruntimeOf_str0)), v_fuel_244);
  } else {
    V v_t_246 = (g_list_2eany_24s636062554x368623714(v_provs_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      v_c_247 = heff_strAppend(heff_strAppend(v_c_243, ((V)&g_heff_2ebuild_2ecommands_2eruntimeOf_str1)), v_fuel_244);
    } else {
      heff_drop(v_fuel_244);
      heff_drop(v_t_246);
      v_c_247 = v_c_243;
    }
  }
  V v_t_248 = (g_list_2eany_24s1389940534x233790531(v_provs_241));
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    return heff_strAppend(heff_strAppend(v_c_247, ((V)&g_heff_2ebuild_2ecommands_2eruntimeOf_str2)), v_custody_245);
  } else {
    heff_drop(v_custody_245);
    heff_drop(v_t_248);
    return v_c_247;
  }
}
V g_heff_2ebuild_2ecommands_2eruntimeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eruntimeOf(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s535099379x685970669(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2417));
  V v_t_2419;
  heff_clo_take(self, 2);
  if (heff_strEq_c(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_str0))) {
    v_t_2419 = NTAG(TAG_Windows);
  } else {
    v_t_2419 = NTAG(TAG_Posix);
  }
  V v_x_2420 = ({ V a_0 = v_t_2419; V a_1 = v_x_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); heff_drop(v_x_2418); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(v_t_2416, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_lam3, 1, 2, (V[]){v_x_249, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_strAppend(heff_dup(v_m_240), ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_str0)), v_l_245);
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s774411652x2032095250(v_m_240, v_rest_246, v_n_242, MK_INT(1LL), heff_dup(v_p_243), v_p_244, heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_p_243));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str0, 10, "pkg-config");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str3, 12, "`pkg-config ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str5, 21, "` could not say how: ");
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771(V v_what_240, V v_names_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    heff_drop(v_what_240);
    heff_drop(v_z_242);
    V v_t_244 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return heff_tail(v_z_243, 1, (V[]){v_t_244});
  }
  case TAG_Cons: {
    V v_c_247 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str0), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_what_240), heff_dup(v_names_241)}), heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_t_248 = (g_std_2eprocess_2edirFor(heff_rfield(v_c_247, 2)));
    V v_t_249 = ({ V rv_2 = v_t_248; V rr_ = heff_rec_reuse_nf(v_c_247, 1019ULL, 10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, 1048527u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_a_2411 = heff_tag_n(TAG_Run, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_lam0_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    V v_c_2417 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})}));
    return heff_tail(v_c_2417, 2, (V[]){v_z_242, heff_clo_n(g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_lam1, 1, 3, (V[]){v_names_241, v_what_240, v_z_243})});
  }
  default: return heff_nomatch(v_names_241);
  }
}
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_names_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_ended_2419 = heff_take_field(v_x_2418, 0);
  V v_out_2420 = heff_take_field(v_x_2418, 1);
  V v_err_2421 = heff_get_n(v_x_2418, 2, 3);
  V v_t_2422 = v_ended_2419;
  V v_t_2426;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Exited: {
    V v_n_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 1);
    v_t_2426 = heff_bool(heff_intEq_c_lent(v_n_2423, MK_INT(0LL), 2));
    heff_drop(v_n_2423);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2422, 0ULL, 1);
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2422, 0ULL, 1);
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  V v_x_2438;
  heff_clo_take(self, 3);
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_drop_tag(v_names_241, 2);
    heff_drop(v_what_240);
    heff_drop(v_err_2421);
    heff_drop(v_t_2426);
    V v_t_2427 = ({ V a_0 = v_out_2420; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_out_2420); r_; });
    v_x_2438 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2427});
  } else {
    heff_drop(v_out_2420);
    heff_drop(v_t_2426);
    V v_t_2430;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_names_241, 0);
      V v_xs_2429 = heff_field(v_names_241, 1);
      heff_take_n(v_names_241, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str2); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_s_2431 = v_err_2421;
    V v_t_2432 = (g_prelude_2eskipSpaces(v_s_2431, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_s_2431, 0)) - ((int64_t)1ULL));
    V v_t_2434 = (g_prelude_2eskipSpaces(v_s_2431, heff_box_word(v_t_2433), MK_INT(-1LL)));
    V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str3), v_what_240), ((V)&g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str4));
    V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, v_t_2430), ((V)&g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_str5));
    V v_t_2437 = heff_strSlice(v_s_2431, v_t_2432, heff_intAdd(v_t_2434, MK_INT(1LL)));
    v_x_2438 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2436, v_t_2437)});
  }
  V f_ = v_z_243;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam6, 2, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s535099379x685970669(v_t_2414, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam1, 1, 6, (V[]){v_dir_240, heff_dup(v_name_246), v_p_242, heff_dup(v_text_247), heff_dup(v_rest_245), v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam3(V self, V *args) {
  V v_r_2429 = args[0];
  return v_r_2429;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2432 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    heff_take_n(v_x_2438, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2432;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2438, 0);
    heff_take_n(v_x_2438, 1ULL, 1);
    switch (heff_tag_of(v_y_2440)) {
    case TAG_Left: {
      heff_take_n(v_y_2440, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2432;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2440, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2432;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2440);
    }
  }
  default: return heff_nomatch(v_x_2438);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_a_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2430})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2437, v_hd_2431, heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam5, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam6(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam7(V self, V *args) {
  V v_r_2448 = args[0];
  return v_r_2448;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam9(V self, V *args) {
  V v_x_2457 = args[0];
  V v_k_2451 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2457)) {
  case TAG_Left: {
    heff_take_n(v_x_2457, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2451;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2459 = heff_field(v_x_2457, 0);
    heff_take_n(v_x_2457, 1ULL, 1);
    switch (heff_tag_of(v_y_2459)) {
    case TAG_Left: {
      heff_take_n(v_y_2459, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2451;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2459, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2451;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2459);
    }
  }
  default: return heff_nomatch(v_x_2457);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam8(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_a_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2449})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2456, v_hd_2450, heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam9, 1, 1, (V[]){v_k_2451})));
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  if ((heff_dup(v_x_2463) == NTAG(TAG_True))) {
    heff_drop(v_x_2463);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_dir_240; V a_1 = v_rest_245; V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
  } else {
    heff_drop(v_x_2463);
    heff_clo_take(self, 4);
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_2416 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2416), heff_dup(v_dir_240)));
  heff_clo_take(self, 7);
  V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_name_246));
  V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
  V v_path_2426 = ({ V a_0 = v_st_2416; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2425); r_; });
  V v_c_2462;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    V v_path_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_2426));
    V v_t_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2427; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2427); r_; });
    V v_a_2430 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2428, v_text_247, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam3_clo)});
    v_c_2462 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam4, 2, 1, (V[]){v_a_2430});
    break;
  }
  case TAG_Just: {
    V v_was_2443 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    if (heff_strEq_c_lent(v_was_2443, v_text_247, 1)) {
      heff_drop(v_text_247);
      heff_drop(v_path_2426);
      v_c_2462 = ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam6_clo);
    } else {
      V v_path_2446 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_2426));
      V v_t_2447 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2446; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2446); r_; });
      V v_a_2449 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2447, v_text_247, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam7_clo)});
      v_c_2462 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam8, 2, 1, (V[]){v_a_2449});
    }
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_c_2462;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam10, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_st_2416;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_str0))) {
    v_st_2416 = NTAG(TAG_Windows);
  } else {
    v_st_2416 = NTAG(TAG_Posix);
  }
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2416), heff_dup(v_dir_240)));
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2416), heff_dup(v_name_246)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  V v_s_2420 = ({ V a_0 = v_st_2416; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2420));
  heff_clo_take(self, 6);
  return ({ V a_0 = v_t_2421; V a_1 = heff_dup(v_p_242); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_lam2, 1, 7, (V[]){v_st_2416, v_dir_240, v_name_246, v_text_247, v_p_242, v_rest_245, v_p_243}); V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s194152141x338186634(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str0, 31, " is not a computation, `Co h a`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str1, 14, "no definition ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str2, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str5, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str7, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736(V v_lit_240, V v_bi_241, V v_file_242, V v_outPath_243, V v_rt_244, V v_failed_245, V v_done_246, V v_c_247, V v_available_248, V v_z_249, V v_z_2410) {
top: ;
  V v_t_2411 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_247)));
  V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2411); r_; });
  V v_t_2413 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2412));
  V v_handled_2415 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_lam0, 1, 1, (V[]){heff_dup(v_available_248)}); V a_1 = v_t_2413; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2416 = (g_list_2efind_24s279352081x1530195138_24cpr(v_lit_240, heff_rfield(v_c_247, 7)));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_t_2425;
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_o_2419 = v_field_2418;
      HeffT2 v_t_2420 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(heff_dup(v_c_247), heff_rfield(v_o_2419, 1)));
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_eff_2423 = v_field_2422;
          V v_t_2424 = heff_rec_n(3, shape_name__key__effect, (V[]){v_lit_240, heff_get_n(v_o_2419, 1, 2), v_eff_2423});
          v_t_2425 = ({ V a_0 = v_handled_2415; V a_1 = v_t_2424; V r_ = (g_heff_2ebuild_2edriver_2efits(a_0, a_1)); heff_drop(v_handled_2415); r_; });
        } else {
          heff_drop(v_handled_2415);
          heff_drop_rec(v_o_2419, 2);
          heff_drop(v_field_2422);
          v_t_2425 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str0))});
        }
      }
    } else {
      heff_drop(v_handled_2415);
      heff_drop(v_field_2418);
      v_t_2425 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str1), v_lit_240)});
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Left: {
      V v_why_2426 = heff_field(v_t_2425, 0);
      V v_ru_24t_2425_24Left = heff_take_reuse_n(v_t_2425, 1ULL, 1);
      heff_drop_rec(v_bi_241, 4);
      heff_drop(v_outPath_243);
      heff_drop_rec(v_rt_244, 4);
      heff_drop(v_done_246);
      heff_drop_rec(v_c_247, 14);
      heff_drop(v_available_248);
      V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str2), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str3));
      V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, heff_dup(v_why_2426)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str4));
      V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
      V v_t_2430 = heff_tag_at_n(v_ru_24t_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_lam1, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2426, v_z_249, v_z_2410})));
    }
    case TAG_Right: {
      V v_r_2437 = heff_field(v_t_2425, 0);
      heff_take_n(v_t_2425, 1ULL, 1);
      heff_drop(v_file_242);
      heff_drop(v_failed_245);
      int64_t v_t_2438 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
      V v_t_2439 = heff_strSlice_lent(v_outPath_243, heff_box_word(v_t_2438), heff_strLength_lent(v_outPath_243, 0), 6);
      if (heff_strEq_c(v_t_2439, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str7))) {
        int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(v_bi_241, heff_strSlice(v_outPath_243, MK_INT(0LL), heff_box_word(v_t_2440)), v_rt_244, v_done_246, v_c_247, v_available_248, v_r_2437, v_z_249, v_z_2410));
      } else {
        V v_t_2441 = (g_heff_2ebuild_2ecommands_2eruntimeOf(heff_rfield(v_bi_241, 3), v_available_248, heff_dup(v_rt_244)));
        V v_t_2442 = heff_get_n(heff_get_n(v_c_247, 5, 14), 0, 10);
        V v_t_2443 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_get_n(v_bi_241, 3, 4), v_t_2441, v_available_248, v_t_2442, heff_take_field(v_r_2437, 0), heff_get_n(v_r_2437, 1, 2)));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(v_outPath_243, heff_get_n(v_rt_244, 1, 4), v_done_246, v_t_2443, v_z_249, v_z_2410));
      }
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_lam0(V self, V *args) {
  V v_k_2414 = args[0];
  V v_available_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_248; V a_1 = v_k_2414; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_248); heff_drop(v_k_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_lam1(V self, V *args) {
  V v_x_2435 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2426 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_drop(v_x_2435);
  heff_clo_take(self, 5);
  V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str5), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_str6));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2436, v_why_2426);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str1, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str2, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str3, 91, ": load it in a page with <script src=\"...\"> (it imports nothing: it opens from file:// too)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str5, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str7, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str10, 16, "export default {");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str14, 2, "};");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str17, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str18, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str19, 2, "$c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str20, 2, "()");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str21, 9, "undefined");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str22, 6, "  get ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str23, 17, "() { return $ext(");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str24, 5, "); },");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str25, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str26, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str27, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str28, 14, "heff compile: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str29, 19, ": no such directory");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str30, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624(V v_o_240, V v_hd_241, V v_k_242) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2emissingOutDir_24s1526918577x723214907(heff_dup(v_o_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam0, 1, 3, (V[]){v_o_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam7(V self, V *args) {
  V v_acc_2442 = args[0];
  V v_k_2443 = args[1];
  V v_g_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2444 = ({ V b_0 = heff_get_n(v_g_2440, 1, 8); V a_1 = v_k_2443; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_e_2447 = v_field_2446;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2443, v_e_2447}), v_acc_2442});
    } else {
      heff_drop(v_k_2443);
      heff_drop(v_field_2446);
      return v_acc_2442;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam8(V self, V *args) {
  V v_d_2464 = args[0];
  V v_reached_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2465 = ({ V a_0 = v_reached_2463; V b_1 = heff_get_n(v_d_2464, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_2463); heff_drop(b_1); r_; });
  {
    V v_field_2467 = v_t_2465.f[1];
    int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2466 == ((int64_t)0ULL)) && ({ V v_x_2468 = heff_dup(v_field_2467); int c_ = 1; heff_drop(v_x_2468); c_; })));
    heff_drop(v_field_2467);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam9(V self, V *args) {
  V v_d_2480 = args[0];
  V v_reached_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2481 = ({ V a_0 = v_reached_2479; V b_1 = heff_get_n(v_d_2480, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_reached_2479); heff_drop(b_1); r_; });
  {
    V v_field_2483 = v_t_2481.f[1];
    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2482 == ((int64_t)0ULL)) && ({ V v_x_2484 = heff_dup(v_field_2483); int c_ = 1; heff_drop(v_x_2484); c_; })));
    heff_drop(v_field_2483);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam10(V self, V *args) {
  V v_acc_2497 = args[0];
  V v_k_2498 = args[1];
  V v_shorts_2496 = heff_env(self)[0];
  V v_facts_2492 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2eemit_2einfoOne(v_shorts_2496, v_facts_2492, v_acc_2497, v_k_2498));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam11(V self, V *args) {
  V v_o_24111 = args[0];
  V v_globals_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24112 = ({ V a_0 = v_globals_24105; V b_1 = heff_get_n(v_o_24111, 1, 2); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, b_1)); heff_drop(v_globals_24105); heff_drop(b_1); r_; });
  {
    V v_field_24114 = v_t_24112.f[1];
    int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_24113 == ((int64_t)0ULL)) && ({ V v_x_24115 = heff_dup(v_field_24114); int c_ = 1; heff_drop(v_x_24115); c_; })));
    heff_drop(v_field_24114);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam12(V self, V *args) {
  V v_o_24118 = args[0];
  V v_globals_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_gs_24119 = v_globals_24105;
  V v_o_24120 = v_o_24118;
  V v_name_24121 = heff_take_field(v_o_24120, 0);
  V v_key_24122 = heff_get_n(v_o_24120, 1, 2);
  V v_x_24123 = v_name_24121;
  V v_t_24125;
  if ((heff_strEq_c_lent(v_x_24123, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str15), 2) ? 0 : ({ V v_t_24163 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_x_24123))); int c_ = heff_strEq_c_lent(v_t_24163, v_x_24123, 0); heff_drop(v_t_24163); c_; }))) {
    v_t_24125 = v_x_24123;
  } else {
    V v_t_24124 = ({ V a_0 = v_x_24123; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str16); V r_ = (g_heff_2ecompile_2eemit_2equoteGo(a_0, a_1, a_2)); heff_drop(v_x_24123); r_; });
    v_t_24125 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str17), v_t_24124), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str18));
  }
  HeffT2 v_t_24126 = ({ V a_0 = v_gs_24119; V a_1 = v_key_24122; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_gs_24119); heff_drop(v_key_24122); r_; });
  {
    V v_field_24128 = v_t_24126.f[1];
    int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
    V v_t_24134;
    if ((v_tag_24127 == ((int64_t)0ULL))) {
      V v_i_24129 = v_field_24128;
      V v_arity_24130 = heff_take_field(v_i_24129, 1);
      V v_js_24131 = heff_take_field(v_i_24129, 0);
      V v_lazy_24132 = heff_get_n(v_i_24129, 2, 4);
      if (heff_intLe_c(MK_INT(2LL), v_arity_24130)) {
        heff_drop(v_lazy_24132);
        v_t_24134 = heff_strAppend(v_js_24131, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str19));
      } else {
        V v_t_24133 = v_lazy_24132;
        if ((heff_dup(v_t_24133) == NTAG(TAG_True))) {
          heff_drop(v_t_24133);
          v_t_24134 = heff_strAppend(v_js_24131, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str20));
        } else {
          heff_drop(v_t_24133);
          v_t_24134 = v_js_24131;
        }
      }
    } else {
      heff_drop(v_field_24128);
      v_t_24134 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str21);
    }
    V v_t_24135 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str22), v_t_24125), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str23));
    return heff_strAppend(heff_strAppend(v_t_24135, v_t_24134), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str24));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_cs_2429 = heff_env(self)[0];
  V v_badL_2428 = heff_env(self)[1];
  V v_outPath_2427 = heff_env(self)[2];
  V v_hd_2430 = heff_env(self)[3];
  V v_k_2431 = heff_env(self)[4];
  heff_drop(v_x_2432);
  HeffT2 v_t_2433 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2429));
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      V v_c_2436 = v_field_2435;
      V v_top_2437 = heff_take_field(v_c_2436, 5);
      V v_own_2438 = heff_get_n(v_c_2436, 7, 14);
      V v_t_2439;
      heff_clo_take(self, 5);
      if ((heff_dup(v_badL_2428) == NTAG(TAG_True))) {
        heff_drop(v_cs_2429);
        heff_drop(v_badL_2428);
        v_t_2439 = NTAG(TAG_True);
      } else {
        heff_drop(v_badL_2428);
        v_t_2439 = ({ V a_0 = v_cs_2429; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_2429); r_; });
      }
      V v_g_2440 = heff_get_n(v_top_2437, 0, 10);
      V v_exports0_2441 = (g_list_2emap_24f2124896334x71745266(MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str7), MK_INT(0LL), MK_INT(97LL), MK_INT(0LL), MK_INT(0LL), MK_INT(122LL), MK_INT(65LL), MK_INT(0LL), MK_INT(0LL), MK_INT(90LL), v_own_2438));
      V v_exports_2451;
      switch (heff_tag_of(v_exports0_2441)) {
      case TAG_Nil: {
        V v_t_2448 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam7, 2, 1, (V[]){heff_dup(v_g_2440)}); V a_1 = NTAG(TAG_Nil); V a_2 = heff_rfield(v_g_2440, 0); V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        v_exports_2451 = (g_list_2emap_24s129316455x2072694707(v_t_2448));
        break;
      }
      case TAG_Cons: {
        v_exports_2451 = v_exports0_2441;
        break;
      }
      default: heff_nomatch(v_exports0_2441);
      }
      V v_roots_2452 = (g_list_2emap_24s152505078x225062837(heff_dup(v_exports_2451)));
      V v_roots_2453 = v_roots_2452;
      HeffT3 v_t_2454 = (g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(v_g_2440));
      {
        V v_field_2455 = v_t_2454.f[0];
        V v_field_2456 = v_t_2454.f[1];
        V v_field_2457 = v_t_2454.f[2];
        V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2455));
        V v_defs_2459 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2458; V r_ = (g_list_2efoldl_24s650566757x317183241(a_0, a_1, a_2)); heff_drop(v_t_2458); r_; });
        V v_t_2460 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2459));
        V v_defs_2461 = (g_list_2efoldl_24s644510009x1719377493(NTAG(TAG_Nil), v_t_2460));
        V v_t_2462 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2461));
        V v_reached_2463 = ({ V a_0 = v_t_2462; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_2453); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_2462); r_; });
        V v_t_2469 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam8, 1, 1, (V[]){v_reached_2463}); V a_1 = v_defs_2461; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
        V v_si_2470 = (g_heff_2ecompile_2esimplify_2esimplifyProgram(v_field_2457, v_t_2469));
        V v_roots_2471 = heff_dup(v_roots_2453);
        V v_errors_2472 = v_field_2456;
        HeffT2 v_t_2473 = (g_heff_2ecompile_2elower_2efusedOf_24cpr(v_roots_2453, v_si_2470));
        {
          V v_field_2474 = v_t_2473.f[0];
          V v_field_2475 = v_t_2473.f[1];
          V v_a_2476 = v_field_2475;
          V v_defs_2477 = v_field_2474;
          V v_t_2478 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_2477));
          V v_reached_2479 = ({ V a_0 = v_t_2478; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = heff_dup(v_roots_2471); V r_ = (g_heff_2ecompile_2eshake_2ereachGo(a_0, a_1, a_2)); heff_drop(v_t_2478); r_; });
          V v_a_2485 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam9, 1, 1, (V[]){v_reached_2479}); V a_1 = v_defs_2477; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_2486 = (g_heff_2ecompile_2elower_2eshared(NTAG(TAG_False), v_roots_2471, v_a_2476, v_a_2485));
          HeffT3 v_t_2487 = (g_heff_2ecompile_2elower_2esharedLowered_24cpr(v_errors_2472, v_t_2486));
          {
            V v_field_2488 = v_t_2487.f[0];
            V v_field_2489 = v_t_2487.f[1];
            V v_field_2490 = v_t_2487.f[2];
            V v_exports_2491 = heff_dup(v_exports_2451);
            V v_facts_2492 = v_field_2489;
            V v_defs_2493 = v_field_2488;
            V v_roots_2494 = (g_list_2emap_24s152505078x225062837(v_exports_2451));
            V v_keys_2495 = (g_list_2emap_24s1835183789x486277886(heff_dup(v_defs_2493)));
            V v_shorts_2496 = (g_list_2emap_24s456574265x331130481(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str8), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str9), MK_INT(0LL), heff_dup(v_keys_2495)));
            V v_t_2499 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam10, 2, 2, (V[]){v_shorts_2496, v_facts_2492}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_keys_2495; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_keys_2495); r_; });
            HeffT2 v_t_24100 = ({ V a_0 = heff_rec_n(1, shape_info, (V[]){v_t_2499}); V a_1 = v_defs_2493; V a_2 = v_roots_2494; V a_3 = heff_dup(g_std_2eordmap_2eempty_get()); HeffT2 r_ = (g_heff_2ecompile_2eemit_2eemitKeptIn_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_defs_2493); r_; });
            {
              V v_field_24101 = v_t_24100.f[0];
              heff_drop(v_t_24100.f[1]);
              V v_m_24103 = v_field_24101;
              V v_lines_24104 = heff_take_field(v_m_24103, 0);
              V v_globals_24105 = heff_get_n(v_m_24103, 1, 2);
              V v_t_24106 = (g_list_2eany_24s331724893x1262243254(v_lines_24104));
              V v_t_24107;
              if ((heff_dup(v_t_24106) == NTAG(TAG_True))) {
                heff_drop(v_t_24106);
                v_t_24107 = NTAG(TAG_Nil);
              } else {
                heff_drop(v_t_24106);
                v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
              }
              V v_t_24108 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str10), NTAG(TAG_Nil)});
              V v_t_24109 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eextStr_get()), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str11), v_t_24108})});
              V v_t_24110 = (g_prelude_2e_2b_2b(v_t_24107, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str12), v_t_24109})));
              V v_t_24116 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam11, 1, 1, (V[]){heff_dup(v_globals_24105)}); V a_1 = v_exports_2491; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
              V v_t_24117 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str13), NTAG(TAG_Nil)});
              V v_t_24136 = (g_prelude_2e_2b_2b_24f58476578x2140998212(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str14), v_t_24117}), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam12, 1, 1, (V[]){v_globals_24105}), v_t_24116));
              V v_t_24137 = (g_prelude_2e_2b_2b(v_t_24110, v_t_24136));
              V v_t_24138 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str25); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str26); V a_2 = v_lines_24104; V a_3 = v_t_24137; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_lines_24104); heff_drop(v_t_24137); r_; });
              return ({ V a_0 = v_outPath_2427; V a_1 = v_t_2439; V a_2 = heff_rec_n(2, shape_source__errors, (V[]){v_t_24138, v_field_2490}); V a_3 = v_hd_2430; V a_4 = v_k_2431; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2439); r_; });
            }
          }
        }
      }
    } else {
      heff_clo_take(self, 5);
      heff_drop(v_cs_2429);
      heff_drop(v_badL_2428);
      heff_drop(v_outPath_2427);
      heff_drop(v_field_2435);
      V v_t_24139 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})});
      V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
      V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
      V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
      V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24143})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24144}), v_hd_2430, v_k_2431));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_o_240 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_outPath_2427 = heff_get_n(v_o_240, 1, 5);
  V v_badL_2428 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2424, 1));
  heff_drop(v_x_2424);
  V v_cs_2429 = heff_get_n(v_x_2426, 0, 2);
  V v_hd_2430 = v_hd_241;
  V v_k_2431 = v_k_242;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2429), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam6, 1, 5, (V[]){v_cs_2429, v_badL_2428, v_outPath_2427, v_hd_2430, v_k_2431})));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_o_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(v_x_2423));
  V f_ = v_t_2425;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam5, 1, 4, (V[]){v_o_240, v_x_2424, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_o_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_t_2422 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2421, heff_dup(heff_rfield(v_x_2420, 4))));
  heff_clo_take(self, 4);
  V v_x_2423 = (g_list_2efoldl_24s571074576x1179600767(v_x_2420, v_t_2422));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str6), heff_dup(heff_rfield(v_x_2423, 1)), MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam4, 1, 4, (V[]){v_x_2423, v_hd_241, v_o_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam3, 1, 4, (V[]){v_x_2420, v_hd_241, v_o_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_file_2417 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_o_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2419, v_file_2417, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam2, 1, 3, (V[]){v_hd_241, v_o_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam13(V self, V *args) {
  V v_x_24156 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_drop(v_x_24156);
  V v_t_24157 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24158 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24157})});
  V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
  V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
  V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
  V v_t_24162 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24161})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24162}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_o_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  switch (heff_tag_of(v_x_243)) {
  case TAG_Nothing: {
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str0))) {
      heff_clo_take(self, 3);
      V v_t_244 = heff_take_field(v_o_240, 2);
      V v_t_246;
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nothing: {
        v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str1);
        break;
      }
      case TAG_Just: {
        V v_x_245 = heff_field(v_t_244, 0);
        heff_take_n(v_t_244, 1ULL, 1);
        v_t_246 = v_x_245;
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      V v_outPath_247 = heff_take_field(v_o_240, 1);
      V v_file_248 = heff_take_field(v_o_240, 0);
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str2), heff_dup(v_outPath_247)), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str3));
      V v_t_2410 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str4)), NTAG(TAG_MkUnit)});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})}));
      return ({ V a_0 = heff_get_n(v_o_240, 4, 5); V b_1 = heff_tag_n(TAG_Just, 1, (V[]){v_t_246}); V a_2 = v_outPath_247; V a_3 = v_file_248; V a_4 = v_t_2416; V a_5 = v_hd_241; V a_6 = v_k_242; V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str5))) {
        V v_file_2417 = heff_dup(heff_rfield(v_o_240, 0));
        V v_c_2418 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
        heff_clo_take(self, 3);
        V f_ = v_c_2418;
        heff_room[0] = heff_dup(v_hd_241);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam1, 1, 4, (V[]){v_file_2417, v_hd_241, v_o_240, v_k_242});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_clo_take(self, 3);
        V v_t_24145 = heff_take_field(v_o_240, 2);
        V v_t_24147;
        switch (heff_tag_of(v_t_24145)) {
        case TAG_Nothing: {
          v_t_24147 = ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str27);
          break;
        }
        case TAG_Just: {
          V v_x_24146 = heff_field(v_t_24145, 0);
          heff_take_n(v_t_24145, 1ULL, 1);
          v_t_24147 = v_x_24146;
          break;
        }
        default: heff_nomatch(v_t_24145);
        }
        return (g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100(heff_dup(heff_rfield(v_o_240, 4)), heff_tag_n(TAG_Just, 1, (V[]){v_t_24147}), heff_dup(heff_rfield(v_o_240, 1)), heff_get_n(v_o_240, 0, 5), v_hd_241, v_k_242));
      }
    }
  }
  case TAG_Just: {
    V v_dir_24148 = heff_field(v_x_243, 0);
    V v_ru_24x_243_24Just = heff_take_reuse_n(v_x_243, 1ULL, 1);
    heff_clo_take(self, 3);
    heff_drop_rec(v_o_240, 5);
    V v_t_24149 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str28), v_dir_24148), ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str29));
    V v_t_24150 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24149, ((V)&g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_str30)), NTAG(TAG_MkUnit)});
    V v_t_24151 = heff_tag_at_n(v_ru_24x_243_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
    V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
    V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
    V v_t_24154 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24153})});
    V v_t_24155 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24154})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24155}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_lam13, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144(V v_path_240) {
top: ;
  V v_path_241 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_240)));
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_244 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam1, 2, 3, (V[]){v_a_244, v_path_240, v_path_241});
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144(a[0]);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam3(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_246 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    heff_take_n(v_x_2423, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_246;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2425 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    switch (heff_tag_of(v_y_2425)) {
    case TAG_Left: {
      heff_take_n(v_y_2425, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2425, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2425);
    }
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam5(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_246 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2439)) {
  case TAG_Left: {
    heff_take_n(v_x_2439, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_246;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2441 = heff_field(v_x_2439, 0);
    heff_take_n(v_x_2439, 1ULL, 1);
    switch (heff_tag_of(v_y_2441)) {
    case TAG_Left: {
      heff_take_n(v_y_2441, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2441, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2441);
    }
  }
  default: return heff_nomatch(v_x_2439);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam7(V self, V *args) {
  V v_n_2445 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_t_2446 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2445));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_241, v_t_2446));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 0ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_path_241);
    V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_240));
    V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2414); r_; });
    V v_a_2417 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam3_clo)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2422, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam4, 1, 1, (V[]){v_k_246})));
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Left: {
      V v_ru_24y_2428_24Left = heff_take_reuse_n(v_y_2428, 0ULL, 1);
      heff_clo_take(self, 4);
      heff_drop(v_path_241);
      V v_path_2430 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_240));
      V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2430; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2430); r_; });
      V v_a_2433 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam5_clo)});
      V v_t_2434 = heff_tag_at_n(v_ru_24x_2412_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2428_24Left, TAG_InR, 1, (V[]){v_a_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2438, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam6, 1, 1, (V[]){v_k_246})));
    }
    case TAG_Right: {
      V v_x_2444 = heff_field(v_y_2428, 0);
      heff_take_n(v_y_2428, 1ULL, 1);
      heff_clo_take(self, 4);
      heff_drop(v_path_240);
      heff_drop(v_hd_245);
      heff_drop_cell(v_ru_24x_2412_24Right, 1);
      V v_x_2447 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam7, 1, 1, (V[]){v_path_241}), v_x_2444));
      V v_x_2448 = (g_list_2emap_24s219049803x1458391381(v_x_2447));
      heff_drop(v_x_2448);
      V f_ = v_k_246;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2428);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_a_244 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2411, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_lam2, 1, 4, (V[]){v_path_240, v_hd_245, v_k_246, v_path_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_str2, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285(V v_lit_240, V v_st_241, V v_t_242, V v_acc_243, V v_x_244, V v_z_245, V v_z_246) {
top: ;
  V v_src_247 = heff_dup(v_lit_240);
  V v_t_248 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_249 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_247, v_t_248, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  {
    V v_field_2411 = v_t_249.f[1];
    heff_drop(v_t_249.f[0]);
    heff_drop(v_t_249.f[2]);
    V v_t_2413 = v_field_2411;
    V v_t_2428;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      V v_t_2414 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      HeffT3 v_t_2415 = ({ V a_0 = v_src_247; V a_1 = v_t_2414; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); HeffT3 r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_247); r_; });
      {
        V v_field_2416 = v_t_2415.f[0];
        heff_drop(v_t_2415.f[1]);
        heff_drop(v_t_2415.f[2]);
        HeffT2 v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_str1); V b_2 = heff_arrayFromList(v_field_2416); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_p_2422 = v_field_2421;
            v_t_2428 = heff_tag_n(TAG_Left, 1, (V[]){v_p_2422});
          } else {
            V v_x_2423 = v_field_2421;
            v_t_2428 = ({ V a_0 = v_x_2423; V r_ = (g_heff_2ebuild_2eproject_2ebuildOf(a_0)); heff_drop(v_x_2423); r_; });
          }
        }
      }
      break;
    }
    case TAG_Cons: {
      V v_e_2424 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 2);
      heff_drop(v_src_247);
      V v_start_2426 = heff_take_field(v_e_2424, 0);
      V v_msg_2427 = heff_get_n(v_e_2424, 2, 3);
      v_t_2428 = heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_start_2426, v_msg_2427})});
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Left: {
      V v_p_2429 = heff_field(v_t_2428, 0);
      V v_ru_24t_2428_24Left = heff_take_reuse_n(v_t_2428, 1ULL, 1);
      V v_t_2430 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_241, v_t_242, v_x_244, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_str2)));
      V v_str_2431 = ({ V a_0 = v_t_2430; V a_1 = v_lit_240; V a_2 = v_p_2429; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
      V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2431, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_str3)), NTAG(TAG_MkUnit)});
      V v_t_2433 = heff_tag_at_n(v_ru_24t_2428_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_lam0, 1, 2, (V[]){v_acc_243, v_z_246})));
    }
    case TAG_Right: {
      V v_a_2441 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      heff_drop(v_lit_240);
      V v_c_2442 = (g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811(heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(heff_rfield(v_a_2441, 2))));
      return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_lam1, 1, 7, (V[]){v_st_241, v_t_242, v_acc_243, v_x_244, v_a_2441, v_z_245, v_z_246})});
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_lam0(V self, V *args) {
  V v_x_2438 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_drop(v_x_2438);
  heff_clo_take(self, 2);
  V v_t_2439 = heff_intAdd(heff_take_field(v_acc_243, 1), MK_INT(1LL));
  V v_t_2440 = ({ V rv_1 = v_t_2439; V rr_ = heff_rec_reuse_nf(v_acc_243, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_246;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_lam1(V self, V *args) {
  V v_x_2443 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_a_2441 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621(v_st_241, v_t_242, v_acc_243, v_x_244, v_a_2441, v_x_2443, v_z_245, v_z_246));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_str0, 8, "build.hf");
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(V v_st_240, V v_t_241, V v_rd_242, V v_acc_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_rd_242);
    heff_drop(v_z_245);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 0)));
    V v_x_248 = ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_acc_243, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_246, 1, (V[]){v_x_248});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x5_244, 0);
    V v_rest_2410 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_s_2411 = (g_heff_2ebuild_2ecommands_2eappFile(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_str0)));
    V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
    V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
    V v_a_2415 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam0_clo)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2420, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam1, 1, 8, (V[]){v_rd_242, v_st_240, v_t_241, v_acc_243, v_rest_2410, v_z_245, v_z_246, v_x_249})));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam0(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_rd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_2410 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_t_2431 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_242), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  heff_clo_take(self, 6);
  return (g_co_2eop_24s677923597x1834241003(v_st_240, v_t_241, v_rd_242, v_x_2430, v_rest_2410, heff_dup(v_z_245), v_z_246, heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_z_245));
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_rd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_x_249 = heff_env(self)[7];
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_ru_24x_2421_24Left = heff_take_reuse_n(v_x_2421, 0ULL, 1);
    heff_clo_take(self, 8);
    heff_drop(v_x_249);
    V v_t_2423 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_242), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2421_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s677923597x1834241003(v_st_240, v_t_241, v_rd_242, v_acc_243, v_rest_2410, heff_dup(v_z_245), v_z_246, heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_z_245));
  }
  case TAG_Right: {
    V v_y_2425 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    switch (heff_tag_of(v_y_2425)) {
    case TAG_Left: {
      V v_ru_24y_2425_24Left = heff_take_reuse_n(v_y_2425, 0ULL, 1);
      heff_clo_take(self, 8);
      heff_drop(v_x_249);
      V v_t_2427 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_242), NTAG(TAG_MkUnit)});
      V v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24y_2425_24Left, TAG_InL, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s677923597x1834241003(v_st_240, v_t_241, v_rd_242, v_acc_243, v_rest_2410, heff_dup(v_z_245), v_z_246, heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_z_245));
    }
    case TAG_Right: {
      V v_x_2429 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      heff_clo_take(self, 8);
      return (g_heff_2ebuild_2ecommands_2eappRead_24s1457830918x1190855285_24tok1(v_ru_24x_2421_24Right, v_x_2429, heff_dup(v_st_240), heff_dup(v_t_241), v_acc_243, v_x_249, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_lam2, 1, 6, (V[]){v_rd_242, v_st_240, v_t_241, v_rest_2410, v_z_245, v_z_246})));
    }
    default: return heff_nomatch(v_y_2425);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768(V v_st_240, V v_t_241, V v_progs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_progs_242);
    return ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam0_clo);
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_242)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1442652634x1828296957(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_total_249 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_248));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_str0), heff_dup(v_home_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam1, 2, 6, (V[]){v_t_2410, v_total_249, v_progs_242, heff_dup(v_st_240), heff_dup(v_t_241), v_home_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  heff_drop(v_a_244);
  V f_ = v_a_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_drop(v_x_2424);
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam4(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_2420, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam5, 1, 1, (V[]){v_k_2421})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_246 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_242));
  V v_xs_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1442652634x1828296957(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2418));
  V v_t_2425 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_246; V a_3 = v_x_2416; V b_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam4, 2, 1, (V[]){heff_dup(v_x_2416)}); V a_5 = v_t_2419; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1690885774x1549164529(a_0, a_1, a_2, a_3, b_4, a_5)); heff_drop(v_st_240); heff_drop(v_t_241); heff_drop(v_home_246); heff_drop(v_x_2416); heff_drop(b_4); heff_drop(v_t_2419); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_2410 = heff_env(self)[0];
  V v_total_249 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_home_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2410, v_total_249, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam2_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s535099379x685970669(v_t_2415, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1152957686x693379768_lam3, 1, 6, (V[]){v_progs_242, v_st_240, v_t_241, v_home_246, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2(V v_tok_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_str0), v_e_244), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_str1));
    V v_t_247 = heff_tag_at_n(v_tok_240, TAG_WriteErr, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s1014403878x489449937(v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_p_242));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2(a[0], a[1], a[2], a[3]);
}