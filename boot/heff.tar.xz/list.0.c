// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAbandon 62759
#define TAG_ECall 24489
#define TAG_ERecord 5518
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_FromLam 36578
#define TAG_FromNone 27319
#define TAG_FromVar 46193
#define TAG_HLocal 25864
#define TAG_I64 19315
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Kept 49931
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkPath 49630
#define TAG_MkSegment 38079
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SetField 47531
#define TAG_SpId 35501
#define TAG_Unreached 46435
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_detail 611917692
#define LBL_doc 309170
#define LBL_filter 672649891
#define LBL_from 9647217
#define LBL_id 10114
#define LBL_index 301704428
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_known 303562589
#define LBL_label 304085774
#define LBL_le 10208
#define LBL_lent 9813446
#define LBL_long 9823043
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_path 9928940
#define LBL_reprs 309759928
#define LBL_rune 10007553
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_shown 310772011
#define LBL_sol 323594
#define LBL_span 10032145
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_total 311908190
#define LBL_value 313331083
#define LBL_version 583465758
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2ecpr_2eleafExprs(V, V);
V g_heff_2ecompile_2ecpr_2eleafExprs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eleafExprs_clo;
V g_heff_2ecompile_2edefun_2eescape(V, V);
V g_heff_2ecompile_2edefun_2eescape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eescape_clo;
V g_heff_2ecompile_2edefun_2emarkBad(V, V);
V g_heff_2ecompile_2edefun_2emarkBad_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2emarkBad_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2etupleRead(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleRead_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eowned_2echain(V, V);
V g_heff_2ecompile_2eowned_2echain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2echain_clo;
V g_heff_2ecompile_2eowned_2eownedChain(V, V, V, V);
V g_heff_2ecompile_2eowned_2eownedChain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownedChain_clo;
V g_heff_2ecompile_2erefcount_2eelemI(V, V);
V g_heff_2ecompile_2erefcount_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemI_clo;
V g_heff_2ecompile_2erefcount_2ekeptFrom(V, V);
V g_heff_2ecompile_2erefcount_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeptFrom_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
V g_heff_2ecompile_2esimplify_2ehandlerArg(V, V);
V g_heff_2ecompile_2esimplify_2ehandlerArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerArg_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2eelab_2eprimitive_2eprimArity(V);
V g_heff_2eelab_2eprimitive_2eprimArity_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimArity_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2eprimitive_2eprimOfName(V);
V g_heff_2eelab_2eprimitive_2eprimOfName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimOfName_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2esegmentOdd(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentOdd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentOdd_clo;
V g_list_2eall_24s335630579x1560445122(V, V);
V g_list_2eall_24s335630579x1560445122_entry(V self, V *a);
extern Clo g_list_2eall_24s335630579x1560445122_clo;
V g_list_2eany_24s107933070x152985962(V, V, V, V, V);
V g_list_2eany_24s107933070x152985962_entry(V self, V *a);
extern Clo g_list_2eany_24s107933070x152985962_clo;
V g_list_2eany_24s1806601701x937560846(V, V);
V g_list_2eany_24s1806601701x937560846_entry(V self, V *a);
extern Clo g_list_2eany_24s1806601701x937560846_clo;
V g_list_2eany_24s1836353438x580818415(V, V);
V g_list_2eany_24s1836353438x580818415_entry(V self, V *a);
extern Clo g_list_2eany_24s1836353438x580818415_clo;
V g_list_2eany_24s277053946x716662586(V, V);
V g_list_2eany_24s277053946x716662586_entry(V self, V *a);
extern Clo g_list_2eany_24s277053946x716662586_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2eany_24s695184589x587274465(V, V, V);
V g_list_2eany_24s695184589x587274465_entry(V self, V *a);
extern Clo g_list_2eany_24s695184589x587274465_clo;
V g_list_2eascending_24s1013929174x440984754(V, V, V, V, V);
V g_list_2eascending_24s1013929174x440984754_entry(V self, V *a);
extern Clo g_list_2eascending_24s1013929174x440984754_clo;
V g_list_2eascending_24s1492869513x628919935(V, V, V, V, V);
V g_list_2eascending_24s1492869513x628919935_entry(V self, V *a);
extern Clo g_list_2eascending_24s1492869513x628919935_clo;
V g_list_2ecollapse_24s239375235x1062143192(V, V, V, V);
V g_list_2ecollapse_24s239375235x1062143192_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s239375235x1062143192_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1618362284x812128366_24cpr(V, V);
HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V, V);
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24f1625738412x188935108(V, V, V);
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1625738412x188935108_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24f1770886889x1685770680(V, V);
V g_list_2efoldl_24f1770886889x1685770680_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1770886889x1685770680_clo;
V g_list_2efoldl_24f2092936166x2062766724(V, V, V);
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2092936166x2062766724_clo;
V g_list_2efoldl_24s1061624263x1097104198(V, V);
V g_list_2efoldl_24s1061624263x1097104198_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061624263x1097104198_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1527809396x70961516(V, V);
V g_list_2efoldl_24s1527809396x70961516_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1527809396x70961516_clo;
V g_list_2efoldl_24s1668908788x1049324851(V, V);
V g_list_2efoldl_24s1668908788x1049324851_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1668908788x1049324851_clo;
V g_list_2efoldl_24s1943292369x853546653(V, V);
V g_list_2efoldl_24s1943292369x853546653_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1943292369x853546653_clo;
V g_list_2efoldl_24s1950894567x1295732556(V, V);
V g_list_2efoldl_24s1950894567x1295732556_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1950894567x1295732556_clo;
V g_list_2efoldl_24s1955438510x914057761(V, V);
V g_list_2efoldl_24s1955438510x914057761_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1955438510x914057761_clo;
V g_list_2efoldl_24s1975553568x1034350329(V, V);
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1975553568x1034350329_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s329749357x1092795161(V, V);
V g_list_2efoldl_24s329749357x1092795161_entry(V self, V *a);
extern Clo g_list_2efoldl_24s329749357x1092795161_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24dps(V, V, V);
V g_list_2ekeepIf_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24dps_clo;
V g_list_2ekeepIf_24s1201185697x960477413(V, V);
V g_list_2ekeepIf_24s1201185697x960477413_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_clo;
V g_list_2ekeepIf_24s1201185697x960477413_24dps(V, V, V);
V g_list_2ekeepIf_24s1201185697x960477413_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_24dps_clo;
V g_list_2ekeepIf_24s1405544077x1281126723_24dps(V, V, V);
V g_list_2ekeepIf_24s1405544077x1281126723_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1405544077x1281126723_24dps_clo;
V g_list_2ekeepIf_24s1613584875x1342487326_24dps(V, V, V);
V g_list_2ekeepIf_24s1613584875x1342487326_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1613584875x1342487326_24dps_clo;
V g_list_2ekeepIf_24s1814523351x214817707_24dps(V, V);
V g_list_2ekeepIf_24s1814523351x214817707_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1814523351x214817707_24dps_clo;
V g_list_2ekeepIf_24s3089255x286808945(V, V, V, V);
V g_list_2ekeepIf_24s3089255x286808945_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s3089255x286808945_clo;
V g_list_2ekeepIf_24s3089255x286808945_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s3089255x286808945_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s3089255x286808945_24dps_clo;
V g_list_2ekeepIf_24s44384897x1267641110_24dps(V, V);
V g_list_2ekeepIf_24s44384897x1267641110_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1285463828x1893111862_24dps(V, V, V, V);
V g_list_2emap_24f1285463828x1893111862_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1285463828x1893111862_24dps_clo;
V g_list_2emap_24f1512150482x179770396(V, V, V, V);
V g_list_2emap_24f1512150482x179770396_entry(V self, V *a);
extern Clo g_list_2emap_24f1512150482x179770396_clo;
V g_list_2emap_24f1632378148x1903828118(V, V);
V g_list_2emap_24f1632378148x1903828118_entry(V self, V *a);
extern Clo g_list_2emap_24f1632378148x1903828118_clo;
V g_list_2emap_24f1632378148x1903828118_24dps(V, V, V);
V g_list_2emap_24f1632378148x1903828118_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1632378148x1903828118_24dps_clo;
V g_list_2emap_24f525774350x554415833_24dps(V, V, V, V, V, V);
V g_list_2emap_24f525774350x554415833_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f525774350x554415833_24dps_clo;
V g_list_2emap_24f8874541x1844987517(V, V);
V g_list_2emap_24f8874541x1844987517_entry(V self, V *a);
extern Clo g_list_2emap_24f8874541x1844987517_clo;
V g_list_2emap_24f8874541x1844987517_24dps(V, V, V);
V g_list_2emap_24f8874541x1844987517_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f8874541x1844987517_24dps_clo;
V g_list_2emap_24s1009200955x251267316_24dps(V, V);
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1009200955x251267316_24dps_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s1044393341x1523302351_24dps(V, V);
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_24dps_clo;
V g_list_2emap_24s1381986540x1952410492_24dps(V, V);
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_24dps_clo;
V g_list_2emap_24s1517387949x485543551(V);
V g_list_2emap_24s1517387949x485543551_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_clo;
V g_list_2emap_24s1517387949x485543551_24dps(V, V);
V g_list_2emap_24s1517387949x485543551_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_24dps_clo;
V g_list_2emap_24s1700608285x1639860354_24dps(V, V);
V g_list_2emap_24s1700608285x1639860354_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1700608285x1639860354_24dps_clo;
V g_list_2emap_24s1729787689x465380098_24dps(V, V);
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_24dps_clo;
V g_list_2emap_24s1792553290x233563724(V);
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_clo;
V g_list_2emap_24s1792553290x233563724_24dps(V, V);
V g_list_2emap_24s1792553290x233563724_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_24dps_clo;
V g_list_2emap_24s1809017761x1063871171_24dps(V, V);
V g_list_2emap_24s1809017761x1063871171_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24dps_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1975257801x764827799(V);
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_clo;
V g_list_2emap_24s1975257801x764827799_24dps(V, V);
V g_list_2emap_24s1975257801x764827799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_24dps_clo;
V g_list_2emap_24s2139359291x1524787922_24dps(V, V);
V g_list_2emap_24s2139359291x1524787922_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_24dps_clo;
V g_list_2emap_24s219049803x1458391381_24dps(V, V);
V g_list_2emap_24s219049803x1458391381_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_24dps_clo;
V g_list_2emap_24s258116700x992061112_24dps(V, V, V);
V g_list_2emap_24s258116700x992061112_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_24dps_clo;
V g_list_2emap_24s273193875x235978955(V, V, V, V);
V g_list_2emap_24s273193875x235978955_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_clo;
V g_list_2emap_24s273193875x235978955_24dps(V, V, V, V, V);
V g_list_2emap_24s273193875x235978955_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_24dps_clo;
V g_list_2emap_24s323105787x487030640_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s323105787x487030640_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s323105787x487030640_24dps_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s34825065x1144190520_24dps(V, V);
V g_list_2emap_24s34825065x1144190520_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_24dps_clo;
V g_list_2emap_24s379205986x2089287346_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s379205986x2089287346_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s379205986x2089287346_24dps_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s380834591x871125279_24dps(V, V);
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_24dps_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s391931963x434308123_24dps(V, V);
V g_list_2emap_24s391931963x434308123_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_24dps_clo;
V g_list_2emap_24s4199228x1154005405_24dps(V, V);
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24dps_clo;
V g_list_2emap_24s430074199x1834682414(V, V, V, V);
V g_list_2emap_24s430074199x1834682414_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_clo;
V g_list_2emap_24s430074199x1834682414_24dps(V, V, V, V, V);
V g_list_2emap_24s430074199x1834682414_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s430074199x1834682414_24dps_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s502656580x1955732096_24dps(V, V);
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_24dps_clo;
V g_list_2emap_24s531657185x2070920831(V, V);
V g_list_2emap_24s531657185x2070920831_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_clo;
V g_list_2emap_24s531657185x2070920831_24dps(V, V, V);
V g_list_2emap_24s531657185x2070920831_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s531657185x2070920831_24dps_clo;
V g_list_2emap_24s584454411x1006678865_24dps(V, V);
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_24dps_clo;
V g_list_2emap_24s64066279x273522434_24dps(V, V);
V g_list_2emap_24s64066279x273522434_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s64066279x273522434_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emergeRuns(V, V, V);
V g_list_2emergeRuns_entry(V self, V *a);
extern Clo g_list_2emergeRuns_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2erunFrom(V, V, V);
V g_list_2erunFrom_entry(V self, V *a);
extern Clo g_list_2erunFrom_clo;
V g_list_2esortOn_24s1704298248x384812646(V, V, V, V, V, V, V);
V g_list_2esortOn_24s1704298248x384812646_entry(V self, V *a);
extern Clo g_list_2esortOn_24s1704298248x384812646_clo;
V g_list_2ezipWith_24s1530546918x299821644(V, V);
V g_list_2ezipWith_24s1530546918x299821644_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1530546918x299821644_clo;
V g_list_2ezipWith_24s634456687x1151454243_24dps(V, V, V);
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
Clo g_list_2ekeepIf_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_entry, 2, 0};

V g_list_2ekeepIf(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24dps(v_p_240, v_xs_243, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1044393341x1523302351_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1044393341x1523302351_entry, 1, 0};

V g_list_2emap_24s1044393341x1523302351(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_245 = ({ V a_0 = v_a_244; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_a_244); r_; });
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1044393341x1523302351_24dps(v_xs_242, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1044393341x1523302351(a[0]);
}
Clo g_list_2emap_24s584454411x1006678865_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s584454411x1006678865_24dps_entry, 2, 0};

V g_list_2emap_24s584454411x1006678865_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s584454411x1006678865_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s584454411x1006678865_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s258116700x992061112_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s258116700x992061112_24dps_entry, 3, 0};

V g_list_2emap_24s258116700x992061112_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s258116700x992061112_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s258116700x992061112_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1792553290x233563724_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1792553290x233563724_entry, 1, 0};

V g_list_2emap_24s1792553290x233563724(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Unreached), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1792553290x233563724_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1792553290x233563724(a[0]);
}
Clo g_list_2ekeepIf_24s1613584875x1342487326_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1613584875x1342487326_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1613584875x1342487326_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_243, 0)))) {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1613584875x1342487326_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s1613584875x1342487326_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s2139359291x1524787922_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2139359291x1524787922_24dps_entry, 2, 0};

V g_list_2emap_24s2139359291x1524787922_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, NTAG(TAG_Nil)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2139359291x1524787922_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s2139359291x1524787922_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s34825065x1144190520_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s34825065x1144190520_entry, 1, 0};

V g_list_2emap_24s34825065x1144190520(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkSegment: {
        V v_ty_246 = heff_field(v_x11_243, 1);
        V v_size_247 = heff_field(v_x11_243, 2);
        heff_take_n(v_x11_243, 6ULL, 5);
        v_t_2410 = ({ V a_0 = v_ty_246; V a_1 = v_size_247; V r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd(a_0, a_1)); heff_drop(v_ty_246); heff_drop(v_size_247); r_; });
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s34825065x1144190520_24dps(v_xs_242, v_cell_2411));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s34825065x1144190520(a[0]);
}
Clo g_list_2emap_24s1729787689x465380098_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729787689x465380098_24dps_entry, 2, 0};

V g_list_2emap_24s1729787689x465380098_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2418;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24SetField = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_249));
          v_t_2412 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2418 = heff_tag_re_n(v_ru_24a_244_24SetField, TAG_SetField, 3, 3ULL, (V[]){v_a_246, v_a_247, v_t_2412});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2413 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadFieldSet = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24a_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2417});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2420);
    V t_0 = v_xs_243;
    V t_1 = v_u_2421;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729787689x465380098_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1729787689x465380098_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s604143829x1495140576_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s604143829x1495140576_entry, 2, 0};

V g_list_2eany_24s604143829x1495140576(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2ehandlerArg(v_lit_240, heff_dup(v_x_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s604143829x1495140576(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s2070597502x591087275_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2070597502x591087275_entry, 2, 0};

V g_list_2efoldl_24s2070597502x591087275(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_acc_244 = v_z_240;
    V v_x2_245 = heff_dup(v_x_242);
    V v_t_2418;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Fresh: {
      V v_d_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      V v_body_247 = heff_take_field(v_d_246, 2);
      V v_key_248 = heff_get_n(v_d_246, 0, 3);
      V v_t_249 = ({ V a_0 = v_body_247; V r_ = (g_heff_2ecompile_2esimplify_2eflat(a_0)); heff_drop(v_body_247); r_; });
      v_t_2418 = ({ V a_0 = v_acc_244; V a_1 = v_key_248; V a_2 = v_t_249; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_key_248); heff_drop(v_t_249); r_; });
      break;
    }
    case TAG_Kept: {
      V v_k_2410 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 2);
      V v_sgSafe_2412 = heff_take_field(v_k_2410, 5);
      V v_key_2413 = heff_take_field(v_k_2410, 0);
      V v_sgTotal_2414 = heff_get_n(v_k_2410, 6, 7);
      V v_t_2415 = v_sgSafe_2412;
      V v_t_2416;
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        v_t_2416 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_acc_244, 0)), v_key_2413, NTAG(TAG_MkUnit)));
      } else {
        heff_drop(v_t_2415);
        v_t_2416 = heff_dup(heff_rfield(v_acc_244, 0));
      }
      V v_t_2417;
      if (heff_intLe_c_lent(MK_INT(0LL), v_sgTotal_2414, 1)) {
        v_t_2417 = ({ V a_0 = heff_get_n(v_acc_244, 1, 2); V a_1 = v_key_2413; V a_2 = v_sgTotal_2414; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_2413); heff_drop(v_sgTotal_2414); r_; });
      } else {
        heff_drop(v_key_2413);
        heff_drop(v_sgTotal_2414);
        v_t_2417 = heff_get_n(v_acc_244, 1, 2);
      }
      v_t_2418 = heff_rec_n(2, shape_safe__total, (V[]){v_t_2416, v_t_2417});
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V t_0 = v_t_2418;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2070597502x591087275(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s531657185x2070920831_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s531657185x2070920831_entry, 2, 0};

V g_list_2emap_24s531657185x2070920831(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_lit_240; V a_1 = v_x_242; V r_ = (g_heff_2ecompile_2erefcount_2ekeptFrom(a_0, a_1)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s531657185x2070920831_24dps(v_lit_240, v_xs_243, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s531657185x2070920831_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s531657185x2070920831(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2eall_24s335630579x1560445122_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s335630579x1560445122_entry, 2, 0};

V g_list_2eall_24s335630579x1560445122(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2erepr_2ereprEq(v_lit_240, v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s335630579x1560445122_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eall_24s335630579x1560445122(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1061624263x1097104198_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1061624263x1097104198_entry, 2, 0};

V g_list_2efoldl_24s1061624263x1097104198(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_f_244 = v_z_240;
    V v_x2_245 = v_x_242;
    V v_t_2421;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_j_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_f_244, 5), v_x_246));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_RepV: {
            V v_x1_2412 = (g_heff_2ecompile_2erefcount_2eelemI(v_j_247, heff_rfield(v_f_244, 2)));
            if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
              heff_drop(v_x1_2412);
              V v_t_2413 = (g_list_2efoldl_24s490001784x345683100(NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_244, 4))));
              V v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
              V v_t_2415 = ({ V a_0 = v_t_2413; V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2eowned_2echain(a_0, a_1)); heff_drop(v_t_2413); r_; });
              v_t_2421 = (g_heff_2ecompile_2eowned_2eownedChain(v_f_244, v_j_247, v_x_246, v_t_2415));
            } else {
              heff_drop_cell(v_ru_24x3_241_24Cons, 2);
              heff_drop(v_x_246);
              heff_drop(v_j_247);
              heff_drop(v_x1_2412);
              v_t_2421 = v_f_244;
            }
            break;
          }
          case TAG_RepFix: {
            heff_take_n(v_x_2411, 0ULL, 1);
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop(v_x_246);
            heff_drop(v_j_247);
            v_t_2421 = v_f_244;
            break;
          }
          case TAG_RepF64: {
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop(v_x_246);
            heff_drop(v_j_247);
            v_t_2421 = v_f_244;
            break;
          }
          case TAG_RepInt: {
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop(v_x_246);
            heff_drop(v_j_247);
            v_t_2421 = v_f_244;
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_2410);
          V v_x1_2417 = (g_heff_2ecompile_2erefcount_2eelemI(v_j_247, heff_rfield(v_f_244, 2)));
          if (!(heff_dup(v_x1_2417) == NTAG(TAG_True))) {
            heff_drop(v_x1_2417);
            V v_t_2418 = (g_list_2efoldl_24s490001784x345683100(NTAG(TAG_Nil), heff_dup(heff_rfield(v_f_244, 4))));
            V v_t_2419 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
            V v_t_2420 = ({ V a_0 = v_t_2418; V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2eowned_2echain(a_0, a_1)); heff_drop(v_t_2418); r_; });
            v_t_2421 = (g_heff_2ecompile_2eowned_2eownedChain(v_f_244, v_j_247, v_x_246, v_t_2420));
          } else {
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop(v_x_246);
            heff_drop(v_j_247);
            heff_drop(v_x1_2417);
            v_t_2421 = v_f_244;
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V t_0 = v_t_2421;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1061624263x1097104198_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1061624263x1097104198(a[0], a[1]);
}
Clo g_list_2emap_24s1700608285x1639860354_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1700608285x1639860354_24dps_entry, 2, 0};

V g_list_2emap_24s1700608285x1639860354_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1700608285x1639860354_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1700608285x1639860354_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s1527809396x70961516_lam0(V self, V *args);
V g_list_2efoldl_24s1527809396x70961516_lam1(V self, V *args);
Clo g_list_2efoldl_24s1527809396x70961516_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1527809396x70961516_entry, 2, 0};

V g_list_2efoldl_24s1527809396x70961516(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_acc_244 = v_z_240;
    V v_x2_245 = v_x_242;
    V v_t_2423;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_ERecord: {
      V v_fs_246 = heff_field(v_x2_245, 0);
      V v_ts_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24ERecord = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      V v_t_248 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_246)));
      V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_246; V r_ = (g_list_2efoldl_24f2092936166x2062766724(a_0, a_1, a_2)); heff_drop(v_fs_246); r_; });
      V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
      V v_t_2412 = (g_list_2emap(heff_clo_n(g_list_2efoldl_24s1527809396x70961516_lam0, 1, 1, (V[]){v_ts_247}), v_t_2410));
      v_t_2423 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_245_24ERecord, TAG_OutRecord, 2, (V[]){v_t_248, v_t_2412}), v_acc_244});
      break;
    }
    case TAG_ETag: {
      V v_t_2413 = heff_field(v_x2_245, 0);
      V v_args_2414 = heff_field(v_x2_245, 1);
      V v_ts_2415 = heff_field(v_x2_245, 2);
      heff_take_n(v_x2_245, 7ULL, 3);
      V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2414));
      V v_t_2417 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2416, MK_INT(1LL))));
      V v_t_2419 = (g_list_2emap(heff_clo_n(g_list_2efoldl_24s1527809396x70961516_lam1, 1, 1, (V[]){v_ts_2415}), v_t_2417));
      V v_t_2420 = (g_list_2ezipWith_24s1530546918x299821644(v_args_2414, v_t_2419));
      v_t_2423 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OutTag, 2, (V[]){v_t_2413, v_t_2420}), v_acc_244});
      break;
    }
    case TAG_ECall: {
      V v_g_2421 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 2);
      v_t_2423 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OutCall, 1, (V[]){v_g_2421}), v_acc_244});
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2423 = v_acc_244;
      break;
    }
    default: {
      heff_drop(v_x2_245);
      v_t_2423 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_OutOther), v_acc_244});
      break;
    }
    }
    V t_0 = v_t_2423;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1527809396x70961516_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1527809396x70961516(a[0], a[1]);
}
V g_list_2efoldl_24s1527809396x70961516_lam0(V self, V *args) {
  V v_i_2411 = args[0];
  V v_ts_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2411; V a_1 = v_ts_247; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_247); r_; });
}
V g_list_2efoldl_24s1527809396x70961516_lam1(V self, V *args) {
  V v_i_2418 = args[0];
  V v_ts_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2418; V a_1 = v_ts_2415; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2415); r_; });
}
Clo g_list_2efoldl_24s1943292369x853546653_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1943292369x853546653_entry, 2, 0};

V g_list_2efoldl_24s1943292369x853546653(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = ({ V a_0 = v_t_246; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2ecpr_2eleafExprs(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1943292369x853546653_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1943292369x853546653(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s273193875x235978955_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s273193875x235978955_entry, 4, 0};

V g_list_2emap_24s273193875x235978955(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_244, 0));
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_a_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 2ULL, 2);
      v_a_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_numbered_2412 = heff_take_field(v_a_2411, 1);
    V v_kinds_2413 = heff_get_n(v_a_2411, 2, 7);
    V v_t_2414 = v_numbered_2412;
    V v_t_2416;
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V v_t_2415 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2416 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2415, v_kinds_2413});
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_2414);
      v_t_2416 = v_kinds_2413;
    }
    V v_t_2417 = ({ V a_0 = v_lit_241; V a_1 = heff_dup(v_lit_242); V a_2 = v_t_2416; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_248, heff_dup(v_lit_240)), v_t_2417});
    V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_245; V a_4 = v_cell_2419; V r_ = (g_list_2emap_24s273193875x235978955_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_242); r_; });
    heff_drop(v_u_2420);
    return v_cell_2419;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s273193875x235978955_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s273193875x235978955(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1405544077x1281126723_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1405544077x1281126723_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1405544077x1281126723_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_std_2eordmap_2esize(heff_rfield(v_x_243, 1)));
    if (heff_intLt_c_lent(v_lit_240, v_a_245, 2)) {
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_247;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1405544077x1281126723_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s1405544077x1281126723_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s329749357x1092795161_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s329749357x1092795161_entry, 2, 0};

V g_list_2efoldl_24s329749357x1092795161(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FromLam: {
      V v_l_244 = heff_field(v_x_242, 0);
      v_t_246 = (g_heff_2ecompile_2edefun_2eescape(v_z_240, v_l_244));
      break;
    }
    case TAG_FromVar: {
      V v_y_245 = heff_field(v_x_242, 0);
      v_t_246 = (g_heff_2ecompile_2edefun_2emarkBad(v_y_245, v_z_240));
      break;
    }
    case TAG_FromNone: {
      v_t_246 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s329749357x1092795161_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s329749357x1092795161(a[0], a1); heff_drop(a1); return r;
}
V g_list_2emap_24s64066279x273522434_24dps_lam0(V self, V *args);
Clo g_list_2emap_24s64066279x273522434_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s64066279x273522434_24dps_entry, 2, 0};

V g_list_2emap_24s64066279x273522434_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2emap_24s64066279x273522434_24dps_lam0, 1, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s64066279x273522434_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s64066279x273522434_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_list_2emap_24s64066279x273522434_24dps_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_drop(v_a_244);
  heff_clo_take(self, 1);
  return v_x_242;
}
Clo g_list_2efoldl_24s410120642x105714730_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s410120642x105714730_entry, 2, 0};

V g_list_2efoldl_24s410120642x105714730(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_sol_244 = heff_take_field(v_x_242, 1);
    V v_name_245 = heff_take_field(v_x_242, 4);
    V v_span_246 = heff_get_n(v_x_242, 5, 6);
    V v_t_247 = v_sol_244;
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_name_245, v_span_246}), v_z_240});
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_name_245);
      heff_drop(v_span_246);
      v_t_249 = v_z_240;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s410120642x105714730(a[0], a[1]);
}
Clo g_list_2emap_24s323105787x487030640_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s323105787x487030640_24dps_entry, 8, 0};

V g_list_2emap_24s323105787x487030640_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_247), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_2410); r_; });
      V v_t_2413 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a_0)); heff_drop(v_a_2411); r_; });
      V v_t_2414 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2412), heff_dup(v_lit_243));
      V v_t_2415 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2414), heff_dup(v_lit_244));
      v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, v_t_2413), heff_dup(v_lit_245));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2417);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_u_2418;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s323105787x487030640_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a7 = a[7]; V r = g_list_2emap_24s323105787x487030640_24dps(a0, a1, a2, a3, a4, a5, a[6], a7); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a7); return r;
}
Clo g_list_2eany_24s1806601701x937560846_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1806601701x937560846_entry, 2, 0};

V g_list_2eany_24s1806601701x937560846(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_rune_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_key_245 = heff_dup(heff_rfield(v_x_242, 1));
    V v_at_246 = heff_dup(heff_rfield(v_x_242, 4));
    V v_a_247 = heff_dup(heff_rfield(v_lit_240, 0));
    V v_t_248 = heff_bool(((heff_dup(v_rune_244) == NTAG(TAG_True)) ? !(heff_dup(v_a_247) == NTAG(TAG_True)) : (heff_dup(v_a_247) == NTAG(TAG_True))));
    heff_drop(v_rune_244);
    heff_drop(v_a_247);
    if (((heff_dup(v_t_248) == NTAG(TAG_True)) && (heff_strEq_c(heff_dup(v_key_245), heff_dup(heff_rfield(v_lit_240, 1))) && heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 4)), heff_dup(v_at_246))))) {
      heff_drop(v_key_245);
      heff_drop(v_at_246);
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_key_245);
      heff_drop(v_at_246);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1806601701x937560846_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1806601701x937560846(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s277053946x716662586_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s277053946x716662586_entry, 2, 0};

V g_list_2eany_24s277053946x716662586(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_242), heff_dup(heff_rfield(v_lit_240, 0)))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s277053946x716662586_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s277053946x716662586(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1950894567x1295732556_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1950894567x1295732556_entry, 2, 0};

V g_list_2efoldl_24s1950894567x1295732556(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1950894567x1295732556_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1950894567x1295732556(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s391931963x434308123_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s391931963x434308123_entry, 1, 0};

V g_list_2emap_24s391931963x434308123(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2einterp_2eshowValGo(NTAG(TAG_False), v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s391931963x434308123_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s391931963x434308123_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s391931963x434308123(a[0]);
}
Clo g_list_2emap_24s1009200955x251267316_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1009200955x251267316_24dps_entry, 2, 0};

V g_list_2emap_24s1009200955x251267316_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 3);
      v_t_247 = v_t_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1009200955x251267316_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1009200955x251267316_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s379205986x2089287346_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s379205986x2089287346_24dps_entry, 9, 0};

V g_list_2emap_24s379205986x2089287346_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_d_248) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_248), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_247, 0);
    V v_xs_2410 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_249)) {
    case TAG_MkDrop: {
      V v_a_2411 = heff_field(v_x_249, 0);
      V v_a_2412 = heff_field(v_x_249, 1);
      heff_take_n(v_x_249, 3ULL, 2);
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Nothing: {
        V v_t_2413 = ({ V a_0 = v_a_2411; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_a_2411); r_; });
        V v_t_2414 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(heff_dup(v_lit_241), v_t_2413));
        v_t_2416 = heff_strAppend(v_t_2414, heff_dup(v_lit_245));
        break;
      }
      case TAG_Just: {
        V v_a_2415 = heff_field(v_a_2412, 0);
        heff_take_n(v_a_2412, 1ULL, 1);
        v_t_2416 = ({ V a_0 = v_a_2411; V a_1 = v_a_2415; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_a_2411); heff_drop(v_a_2415); r_; });
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, heff_dup(v_lit_246)), heff_hole()});
    V v_u_2418 = heff_setFieldPeek(v_d_248, MK_INT(1LL), v_cell_2417);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_xs_2410;
    V t_8 = v_u_2418;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_x2_247 = t_7;
    v_d_248 = t_8;
    goto top;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s379205986x2089287346_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a8 = a[8]; V r = g_list_2emap_24s379205986x2089287346_24dps(a0, a1, a2, a3, a4, a5, a6, a[7], a8); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a8); return r;
}
Clo g_list_2emap_24s430074199x1834682414_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s430074199x1834682414_entry, 4, 0};

V g_list_2emap_24s430074199x1834682414(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_lit_242; V a_3 = v_x_244; V r_ = (g_heff_2ecompile_2eemitc_2etupleRead(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_245; V a_4 = v_cell_247; V r_ = (g_list_2emap_24s430074199x1834682414_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s430074199x1834682414_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s430074199x1834682414(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1814523351x214817707_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1814523351x214817707_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1814523351x214817707_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = ({ V a_0 = v_t_246; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(v_t_246); heff_drop(b_1); r_; });
    if (!(heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_a_247);
      V v_cell_248 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
      V t_0 = v_xs_243;
      V t_1 = v_u_249;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_247);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1814523351x214817707_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s1814523351x214817707_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str0, 2, "a[");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str1, 1, "]");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str2, 0, "");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str3, 2, ", ");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str4, 14, "static V prim_");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str5, 42, "_entry(V self, V *a) { (void)self; return ");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str6, 5, "heff_");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str7, 1, "(");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str8, 16, "static Clo prim_");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str9, 38, "_clo = {{0x80000000u, K_CLO, 0}, prim_");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str10, 8, "_entry, ");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str11, 5, ", 0};");
HEFF_LIT(g_list_2efoldl_24s1668908788x1049324851_str12, 4, "); }");
Clo g_list_2efoldl_24s1668908788x1049324851_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1668908788x1049324851_entry, 2, 0};

V g_list_2efoldl_24s1668908788x1049324851(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2eelab_2eprimitive_2eprimOfName(a_0)); heff_drop(v_x_242); r_; });
    V v_t_2424;
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2424 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      V v_q_246 = v_a_245;
      V v_t_247 = (g_heff_2eelab_2eprimitive_2eprimName(v_q_246));
      V v_t_248 = (g_heff_2eelab_2eprimitive_2eprimName(v_q_246));
      V v_t_249 = (g_heff_2eelab_2eprimitive_2eprimArity(v_q_246));
      V v_x2_2410 = (g_list_2emap_24f1512150482x179770396(((V)&g_list_2efoldl_24s1668908788x1049324851_str0), ((V)&g_list_2efoldl_24s1668908788x1049324851_str1), MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_list_2efoldl_24s1668908788x1049324851_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_list_2efoldl_24s1668908788x1049324851_str3); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = (g_heff_2eelab_2eprimitive_2eprimName(v_q_246));
      V v_t_2415 = (g_heff_2eelab_2eprimitive_2eprimName(v_q_246));
      V v_t_2416 = ({ V a_0 = v_q_246; V r_ = (g_heff_2eelab_2eprimitive_2eprimArity(a_0)); heff_drop(v_q_246); r_; });
      V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_list_2efoldl_24s1668908788x1049324851_str4), v_t_247), ((V)&g_list_2efoldl_24s1668908788x1049324851_str5));
      V v_t_2418 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_list_2efoldl_24s1668908788x1049324851_str6), v_t_248));
      V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_list_2efoldl_24s1668908788x1049324851_str7)), v_t_2413);
      V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_list_2efoldl_24s1668908788x1049324851_str8), v_t_2414), ((V)&g_list_2efoldl_24s1668908788x1049324851_str9));
      V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, v_t_2415), ((V)&g_list_2efoldl_24s1668908788x1049324851_str10));
      V v_t_2422 = heff_strAppend(v_t_2421, heff_intShow(v_t_2416));
      V v_t_2423 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_list_2efoldl_24s1668908788x1049324851_str11)), NTAG(TAG_Nil)});
      v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_list_2efoldl_24s1668908788x1049324851_str12)), v_t_2423});
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2424, v_z_240));
    V t_0 = v_t_2425;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1668908788x1049324851_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1668908788x1049324851(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s380834591x871125279_str0, 11, "static V g_");
HEFF_LIT(g_list_2emap_24s380834591x871125279_str1, 5, "_val;");
HEFF_LIT(g_list_2emap_24s380834591x871125279_str2, 11, "_init(void)");
HEFF_LIT(g_list_2emap_24s380834591x871125279_str3, 22, "static V heff_perform(");
HEFF_LIT(g_list_2emap_24s380834591x871125279_str4, 24, "static V heff_performAt(");
HEFF_LIT(g_list_2emap_24s380834591x871125279_str5, 7, "static ");
HEFF_LIT(g_list_2emap_24s380834591x871125279_str6, 3, " g_");
HEFF_LIT(g_list_2emap_24s380834591x871125279_str7, 12, "static HeffT");
Clo g_list_2emap_24s380834591x871125279_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_entry, 1, 0};

V g_list_2emap_24s380834591x871125279(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_l_243 = v_x_241;
    V v_t_246;
    if ((heff_strEq_c(heff_strSlice_lent(v_l_243, MK_INT(0LL), MK_INT(11LL), 6), ((V)&g_list_2emap_24s380834591x871125279_str0)) && ({ int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_l_243, 0)) - ((int64_t)5ULL)); int c_ = ({ V v_t_249 = heff_strSlice_lent(v_l_243, heff_box_word(v_t_244), heff_strLength_lent(v_l_243, 0), 6); int c_ = (heff_strEq_c_lent(v_t_249, ((V)&g_list_2emap_24s380834591x871125279_str1), 2) ? 0 : !heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_list_2emap_24s380834591x871125279_str2), v_l_243, MK_INT(0LL), 5))); heff_drop(v_t_249); c_; }); c_; }))) {
      v_t_246 = heff_strSlice(heff_dup(v_l_243), MK_INT(7LL), heff_strLength(v_l_243));
    } else {
      if (heff_strEq_c(heff_strSlice_lent(v_l_243, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_list_2emap_24s380834591x871125279_str3))) {
        v_t_246 = heff_strSlice(heff_dup(v_l_243), MK_INT(7LL), heff_strLength(v_l_243));
      } else {
        if (heff_strEq_c(heff_strSlice_lent(v_l_243, MK_INT(0LL), MK_INT(24LL), 6), ((V)&g_list_2emap_24s380834591x871125279_str4))) {
          v_t_246 = heff_strSlice(heff_dup(v_l_243), MK_INT(7LL), heff_strLength(v_l_243));
        } else {
          V v_t_245 = ({ V a_0 = ((V)&g_list_2emap_24s380834591x871125279_str5); V a_1 = ((V)&g_list_2emap_24s380834591x871125279_str6); V a_2 = v_l_243; V a_3 = MK_INT(0LL); V b_4 = heff_dup(g_heff_2ecompile_2eemitc_2eunboxedCTypes_get()); V r_ = (g_list_2eany_24s107933070x152985962(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
          if (((heff_dup(v_t_245) == NTAG(TAG_True)) || heff_strEq_c(heff_strSlice_lent(v_l_243, MK_INT(0LL), MK_INT(12LL), 6), ((V)&g_list_2emap_24s380834591x871125279_str7)))) {
            heff_drop(v_t_245);
            v_t_246 = heff_strSlice(heff_dup(v_l_243), MK_INT(7LL), heff_strLength(v_l_243));
          } else {
            heff_drop(v_t_245);
            v_t_246 = v_l_243;
          }
        }
      }
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s380834591x871125279_24dps(v_xs_242, v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279(a[0]);
}
HEFF_LIT(g_list_2emap_24s502656580x1955732096_str0, 1, "_");
Clo g_list_2emap_24s502656580x1955732096_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s502656580x1955732096_entry, 1, 0};

V g_list_2emap_24s502656580x1955732096(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 0, 5);
    V v_t_2423;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_PatVar: {
        V v_x_246 = heff_field(v_x11_244, 0);
        V v_ru_24x11_244_24PatVar = heff_take_reuse_n(v_x11_244, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_246, ((V)&g_list_2emap_24s502656580x1955732096_str0), 2)) {
          heff_drop(v_x_246);
          heff_drop_cell(v_ru_24x11_244_24PatVar, 1);
          v_t_2423 = NTAG(TAG_Nothing);
        } else {
          v_t_2423 = heff_tag_at_n(v_ru_24x11_244_24PatVar, TAG_Just, 1, (V[]){v_x_246});
        }
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_244, 0ULL, 3);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = (g_list_2emap_24s502656580x1955732096_24dps(v_xs_242, v_cell_2424));
    heff_drop(v_u_2425);
    return v_cell_2424;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s502656580x1955732096(a[0]);
}
Clo g_list_2eascending_24s1013929174x440984754_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s1013929174x440984754_entry, 5, 0};

V g_list_2eascending_24s1013929174x440984754(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_242, 10);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_246 = heff_field(v_x4_244, 0);
    V v_ys_247 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_t_248 = heff_intSub(heff_dup(v_lit_240), heff_get_n(v_x_242, 0, 10));
    V v_t_249 = heff_intSub(heff_dup(v_lit_241), heff_dup(heff_rfield(v_y_246, 0)));
    if (heff_intLe_c(v_t_248, v_t_249)) {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_246);
      V t_3 = heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_246, v_acc_243});
      V t_4 = v_ys_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    } else {
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_246, v_ys_247})});
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2eascending_24s1013929174x440984754_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eascending_24s1013929174x440984754(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str3, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str4, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str5, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str6, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str7, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str8, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str9, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str10, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str11, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str12, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str13, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str14, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str15, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str16, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str17, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str18, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str19, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str20, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str21, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str22, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_str23, 0, "");
Clo g_list_2emap_24s1517387949x485543551_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1517387949x485543551_entry, 1, 0};

V g_list_2emap_24s1517387949x485543551(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_v_243 = v_x_241;
    V v_t_2417;
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_247 = heff_dup(heff_field(v_v_243, 1));
      v_t_2417 = v_vs_247;
      break;
    }
    case TAG_VInt: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_243);
    }
    HeffT3 v_t_2418 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2417; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    {
      V v_field_2420 = v_t_2418.f[1];
      V v_field_2421 = v_t_2418.f[2];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      V v_t_2437;
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_x_2422 = v_field_2420;
        V v_x12_2423 = v_field_2421;
        heff_drop(v_x12_2423);
        switch (heff_tag_of(v_x_2422)) {
        case TAG_VFun: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str0);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str1);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2422, 0ULL, 2);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str2);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str3);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str4);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str5);
          break;
        }
        case TAG_VStr: {
          V v_s_2431 = heff_field(v_x_2422, 0);
          heff_take_n(v_x_2422, 1ULL, 1);
          v_t_2437 = v_s_2431;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str6);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str7);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str8);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2422, 0ULL, 2);
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str9);
          break;
        }
        case TAG_VErased: {
          v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str10);
          break;
        }
        default: heff_nomatch(v_x_2422);
        }
      } else {
        heff_drop(v_field_2420);
        heff_drop(v_field_2421);
        v_t_2437 = ((V)&g_list_2emap_24s1517387949x485543551_str11);
      }
      V v_t_2451;
      switch (heff_tag_of(v_v_243)) {
      case TAG_VFun: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2441 = heff_field(v_v_243, 1);
        heff_take_n(v_v_243, 2ULL, 2);
        v_t_2451 = v_vs_2441;
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take_na(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        heff_take_n(v_v_243, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      HeffT3 v_t_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2451; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2451); r_; });
      {
        V v_field_2454 = v_t_2452.f[1];
        V v_field_2455 = v_t_2452.f[2];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        V v_t_2471;
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          V v_x_2456 = v_field_2454;
          V v_x12_2457 = v_field_2455;
          heff_drop(v_x12_2457);
          switch (heff_tag_of(v_x_2456)) {
          case TAG_VFun: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str12);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str13);
            break;
          }
          case TAG_VTag: {
            heff_take_n(v_x_2456, 0ULL, 2);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str14);
            break;
          }
          case TAG_VInt: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str15);
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_2456, 0ULL, 1);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str16);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str17);
            break;
          }
          case TAG_VStr: {
            V v_s_2465 = heff_field(v_x_2456, 0);
            heff_take_n(v_x_2456, 1ULL, 1);
            v_t_2471 = v_s_2465;
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str18);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str19);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str20);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_2456, 0ULL, 2);
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str21);
            break;
          }
          case TAG_VErased: {
            v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str22);
            break;
          }
          default: heff_nomatch(v_x_2456);
          }
        } else {
          heff_drop(v_field_2454);
          heff_drop(v_field_2455);
          v_t_2471 = ((V)&g_list_2emap_24s1517387949x485543551_str23);
        }
        V v_cell_2472 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_t_2471}), heff_hole()});
        V v_u_2473 = (g_list_2emap_24s1517387949x485543551_24dps(v_xs_242, v_cell_2472));
        heff_drop(v_u_2473);
        return v_cell_2472;
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1517387949x485543551_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1517387949x485543551(a[0]);
}
Clo g_list_2efoldl_24s1955438510x914057761_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1955438510x914057761_entry, 2, 0};

V g_list_2efoldl_24s1955438510x914057761(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_z_240, v_a_244));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_a_249 = v_field_248;
          heff_drop(v_a_249);
          v_t_2410 = v_z_240;
        } else {
          heff_drop(v_field_248);
          v_t_2410 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_a_244, v_a_245));
        }
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1955438510x914057761_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1955438510x914057761(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s634456687x1151454243_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634456687x1151454243_24dps_entry, 3, 0};

V g_list_2ezipWith_24s634456687x1151454243_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 0, 3), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s634456687x1151454243_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2ezipWith_24s634456687x1151454243_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_list_2esortOn_24s1704298248x384812646_lam0(V self, V *args);
V g_list_2esortOn_24s1704298248x384812646_lam1(V self, V *args);
Clo g_list_2esortOn_24s1704298248x384812646_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortOn_24s1704298248x384812646_entry, 7, 0};

V g_list_2esortOn_24s1704298248x384812646(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_ord_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop_rec(v_ord_245, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    V v_t_2435 = (g_list_2erunFrom(heff_clo_n(g_list_2esortOn_24s1704298248x384812646_lam0, 2, 6, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), heff_dup(v_ord_245)}), v_x_247, v_xs_248));
    return ({ V b_0 = heff_clo_n(g_list_2esortOn_24s1704298248x384812646_lam1, 2, 6, (V[]){heff_dup(v_lit_240), v_lit_241, heff_dup(v_lit_242), heff_dup(v_lit_243), heff_dup(v_lit_244), v_ord_245}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2435; V r_ = (g_list_2emergeRuns(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2esortOn_24s1704298248x384812646_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_list_2esortOn_24s1704298248x384812646(a0, a[1], a2, a3, a4, a[5], a[6]); heff_drop(a0); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
V g_list_2esortOn_24s1704298248x384812646_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_b_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_ord_245 = heff_env(self)[5];
  V v_version_2411 = heff_take_field(v_b_2410, 1);
  V v_path_2412 = heff_get_n(v_b_2410, 0, 3);
  V v_version_2413 = heff_take_field(v_a_249, 1);
  V v_path_2414 = heff_get_n(v_a_249, 0, 3);
  V v_a_2415 = v_version_2413;
  V v_t_2416 = (g_prelude_2esplit_2esplitFrom_240(v_a_2415, v_lit_240, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_2415, v_lit_243, 0), NTAG(TAG_Nil)));
  V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_2416); r_; });
  HeffT2 v_t_2418 = ({ V a_0 = v_a_2415; V a_1 = v_t_2417; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_a_2415); heff_drop(v_t_2417); r_; });
  {
    V v_field_2419 = v_t_2418.f[0];
    V v_field_2420 = v_t_2418.f[1];
    V v_a_2421 = v_field_2419;
    V v_a_2422 = v_field_2420;
    V v_t_2423 = heff_bool(heff_strEq_c_lent(v_a_2422, v_lit_244, 0));
    V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2421, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_a_2422})});
    V v_a_2425 = v_version_2411;
    heff_clo_take(self, 6);
    V v_t_2426 = ({ V a_0 = v_a_2425; V a_1 = v_lit_240; V a_2 = v_lit_241; V a_3 = heff_strFind_lent(v_lit_242, v_a_2425, v_lit_243, 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); r_; });
    V v_t_2427 = ({ V a_0 = v_t_2426; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_2426); r_; });
    HeffT2 v_t_2428 = ({ V a_0 = v_a_2425; V a_1 = v_t_2427; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_a_2425); heff_drop(v_t_2427); r_; });
    {
      V v_field_2429 = v_t_2428.f[0];
      V v_field_2430 = v_t_2428.f[1];
      V v_a_2431 = v_field_2429;
      V v_a_2432 = v_field_2430;
      V v_t_2433 = heff_bool(heff_strEq_c_lent(v_a_2432, v_lit_244, 0));
      heff_drop(v_lit_244);
      V v_t_2434 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2431, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_a_2432})});
      V f_ = heff_get_n(v_ord_245, 3, 4);
      args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_path_2414, v_t_2424});
      args[1] = heff_tag_n(TAG_MkPair, 2, (V[]){v_path_2412, v_t_2434});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
  }
}
V g_list_2esortOn_24s1704298248x384812646_lam1(V self, V *args) {
  V v_a_2436 = args[0];
  V v_b_2437 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_ord_245 = heff_env(self)[5];
  V v_version_2438 = heff_take_field(v_b_2437, 1);
  V v_path_2439 = heff_get_n(v_b_2437, 0, 3);
  V v_version_2440 = heff_take_field(v_a_2436, 1);
  V v_path_2441 = heff_get_n(v_a_2436, 0, 3);
  V v_a_2442 = v_version_2440;
  V v_t_2443 = (g_prelude_2esplit_2esplitFrom_240(v_a_2442, v_lit_240, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_a_2442, v_lit_243, 0), NTAG(TAG_Nil)));
  V v_t_2444 = ({ V a_0 = v_t_2443; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_2443); r_; });
  HeffT2 v_t_2445 = ({ V a_0 = v_a_2442; V a_1 = v_t_2444; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_a_2442); heff_drop(v_t_2444); r_; });
  {
    V v_field_2446 = v_t_2445.f[0];
    V v_field_2447 = v_t_2445.f[1];
    V v_a_2448 = v_field_2446;
    V v_a_2449 = v_field_2447;
    V v_t_2450 = heff_bool(heff_strEq_c_lent(v_a_2449, v_lit_244, 0));
    V v_t_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2448, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, v_a_2449})});
    V v_a_2452 = v_version_2438;
    heff_clo_take(self, 6);
    V v_t_2453 = ({ V a_0 = v_a_2452; V a_1 = v_lit_240; V a_2 = v_lit_241; V a_3 = heff_strFind_lent(v_lit_242, v_a_2452, v_lit_243, 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); r_; });
    V v_t_2454 = ({ V a_0 = v_t_2453; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_2453); r_; });
    HeffT2 v_t_2455 = ({ V a_0 = v_a_2452; V a_1 = v_t_2454; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_a_2452); heff_drop(v_t_2454); r_; });
    {
      V v_field_2456 = v_t_2455.f[0];
      V v_field_2457 = v_t_2455.f[1];
      V v_a_2458 = v_field_2456;
      V v_a_2459 = v_field_2457;
      V v_t_2460 = heff_bool(heff_strEq_c_lent(v_a_2459, v_lit_244, 0));
      heff_drop(v_lit_244);
      V v_t_2461 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2458, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2460, v_a_2459})});
      V f_ = heff_get_n(v_ord_245, 3, 4);
      args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_path_2441, v_t_2451});
      args[1] = heff_tag_n(TAG_MkPair, 2, (V[]){v_path_2439, v_t_2461});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
  }
}
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str0, 9, "{ name = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str1, 9, ", path = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str2, 12, ", version = ");
HEFF_LIT(g_list_2emap_24s1381986540x1952410492_24dps_str3, 2, " }");
Clo g_list_2emap_24s1381986540x1952410492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1381986540x1952410492_24dps_entry, 2, 0};

V g_list_2emap_24s1381986540x1952410492_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_path_245 = heff_take_field(v_x_242, 1);
    V v_version_246 = heff_get_n(v_x_242, 2, 3);
    V v_t_247 = ({ V a_0 = v_name_244; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_name_244); r_; });
    V v_t_248 = ({ V a_0 = v_path_245; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_path_245); r_; });
    V v_t_249 = ({ V a_0 = v_version_246; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_version_246); r_; });
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1381986540x1952410492_24dps_str0), v_t_247), ((V)&g_list_2emap_24s1381986540x1952410492_24dps_str1));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_t_248), ((V)&g_list_2emap_24s1381986540x1952410492_24dps_str2));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, v_t_249), ((V)&g_list_2emap_24s1381986540x1952410492_24dps_str3));
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2413);
    V t_0 = v_xs_243;
    V t_1 = v_u_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1381986540x1952410492_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1381986540x1952410492_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s219049803x1458391381_24dps_str0, 0, "");
Clo g_list_2emap_24s219049803x1458391381_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s219049803x1458391381_24dps_entry, 2, 0};

V g_list_2emap_24s219049803x1458391381_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPath: {
      V v_xs_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = v_xs_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x1_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_247));
    V v_t_2411;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_list_2emap_24s219049803x1458391381_24dps_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x1_248, 0);
      heff_take_n(v_x1_248, 1ULL, 2);
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2412);
    V t_0 = v_xs_243;
    V t_1 = v_u_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s219049803x1458391381_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s219049803x1458391381_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eascending_24s1492869513x628919935_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s1492869513x628919935_entry, 5, 0};

V g_list_2eascending_24s1492869513x628919935(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_242, 2);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_246 = heff_field(v_x4_244, 0);
    V v_ys_247 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_a_248 = heff_strCompare(heff_get_n(v_x_242, 0, 2), heff_dup(heff_rfield(v_y_246, 0)));
    if ((heff_intLt_c_lent(v_a_248, v_lit_240, 0) || heff_intEq_c_lent(v_a_248, v_lit_241, 0))) {
      heff_drop(v_a_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_246);
      V t_3 = heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_246, v_acc_243});
      V t_4 = v_ys_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    } else {
      heff_drop(v_a_248);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_246, v_ys_247})});
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2eascending_24s1492869513x628919935_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eascending_24s1492869513x628919935(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s54159557x1528472185_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s54159557x1528472185_entry, 2, 0};

V g_list_2efoldl_24s54159557x1528472185(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_x2_244 = heff_dup(v_x_242);
    V v_t_2438;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 1ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_DeclEquations: {
        V v_ty_2410 = heff_field(v_x21_245, 3);
        V v_eqs_2411 = heff_field(v_x21_245, 4);
        heff_take_n(v_x21_245, 24ULL, 5);
        V v_t_2412 = ({ V a_0 = v_ty_2410; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_ty_2410); r_; });
        V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_eqs_2411));
        V v_t_2414 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s496727651x1448898893(a_0, a_1)); heff_drop(v_t_2413); r_; });
        v_t_2438 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_244_24At, v_t_2412, v_t_2414));
        break;
      }
      case TAG_DeclDefine: {
        V v_ps_2417 = heff_field(v_x21_245, 2);
        V v_u_2418 = heff_field(v_x21_245, 3);
        V v_body_2419 = heff_field(v_x21_245, 4);
        heff_take_n(v_x21_245, 28ULL, 5);
        V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2417));
        V v_t_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s1975553568x1034350329(a_0, a_1)); heff_drop(v_t_2420); r_; });
        V v_t_2422 = ({ V a_0 = v_u_2418; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_u_2418); r_; });
        V v_t_2423 = ({ V a_0 = v_body_2419; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_body_2419); r_; });
        V v_t_2424 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_244_24At, v_t_2422, v_t_2423));
        v_t_2438 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2424));
        break;
      }
      case TAG_DeclTheory: {
        V v_ps_2427 = heff_field(v_x21_245, 2);
        V v_body_2428 = heff_field(v_x21_245, 3);
        heff_take_n(v_x21_245, 12ULL, 4);
        V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2427));
        V v_t_2430 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2429; V r_ = (g_list_2efoldl_24s1975553568x1034350329(a_0, a_1)); heff_drop(v_t_2429); r_; });
        V v_t_2431 = ({ V a_0 = v_body_2428; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_body_2428); r_; });
        v_t_2438 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_244_24At, v_t_2430, v_t_2431));
        break;
      }
      case TAG_DeclPrimitive: {
        V v_t_2434 = heff_field(v_x21_245, 2);
        heff_take_n(v_x21_245, 4ULL, 3);
        heff_drop_cell(v_ru_24x2_244_24At, 2);
        v_t_2438 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_t_2434); r_; });
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x2_244_24At, 2);
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      case TAG_DeclWatch: {
        V v_e_2437 = heff_field(v_x21_245, 0);
        heff_take_n(v_x21_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_244_24At, 2);
        v_t_2438 = ({ V a_0 = v_e_2437; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_e_2437); r_; });
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2438, v_z_240));
    V t_0 = v_t_2439;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s54159557x1528472185(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str0, 1, "(");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str1, 1, ")");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str2, 1, "(");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str3, 1, ")");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str4, 1, "(");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str5, 1, ")");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str6, 4, "(..)");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_str7, 0, "");
Clo g_list_2emap_24s1975257801x764827799_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1975257801x764827799_entry, 1, 0};

V g_list_2emap_24s1975257801x764827799(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_e_243 = v_x_241;
    V v_name_244 = heff_take_field(v_e_243, 0);
    V v_tags_245 = heff_get_n(v_e_243, 1, 3);
    V v_x_246 = heff_dup(v_name_244);
    V v_t_248;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_246, 0)))) {
      if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_246, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_246, MK_INT(0LL), 2)) <= ((int64_t)57ULL)) : 1)) {
        V v_t_247 = ({ V a_0 = v_x_246; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(a_0, a_1)); heff_drop(v_x_246); r_; });
        if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
          heff_drop(v_t_247);
          v_t_248 = v_name_244;
        } else {
          heff_drop(v_t_247);
          v_t_248 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1975257801x764827799_str0), v_name_244), ((V)&g_list_2emap_24s1975257801x764827799_str1));
        }
      } else {
        heff_drop(v_x_246);
        v_t_248 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1975257801x764827799_str2), v_name_244), ((V)&g_list_2emap_24s1975257801x764827799_str3));
      }
    } else {
      heff_drop(v_x_246);
      v_t_248 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1975257801x764827799_str4), v_name_244), ((V)&g_list_2emap_24s1975257801x764827799_str5));
    }
    V v_t_249 = v_tags_245;
    V v_t_2410;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2410 = ((V)&g_list_2emap_24s1975257801x764827799_str6);
    } else {
      heff_drop(v_t_249);
      v_t_2410 = ((V)&g_list_2emap_24s1975257801x764827799_str7);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, v_t_2410), heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1975257801x764827799_24dps(v_xs_242, v_cell_2411));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1975257801x764827799(a[0]);
}
V g_list_2ecollapse_24s239375235x1062143192_lam0(V self, V *args);
Clo g_list_2ecollapse_24s239375235x1062143192_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s239375235x1062143192_entry, 4, 0};

V g_list_2ecollapse_24s239375235x1062143192(V v_lit_240, V v_lit_241, V v_run_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return v_run_242;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_rest_245 = heff_field(v_x3_243, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_below_247 = heff_field(v_x31_244, 1);
      V v_t_2411 = (g_list_2emerge(heff_clo_n(g_list_2ecollapse_24s239375235x1062143192_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), heff_dup(v_below_247), v_run_242));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_2411;
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_run_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2ecollapse_24s239375235x1062143192_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2ecollapse_24s239375235x1062143192(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_list_2ecollapse_24s239375235x1062143192_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_249 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_a_2410 = heff_strCompare(heff_get_n(v_a_248, 0, 14), heff_get_n(v_a_249, 0, 14));
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2410, v_lit_240, 0) || heff_intEq_c_lent(v_a_2410, v_lit_241, 0)));
  heff_drop(self);
  heff_drop(v_a_2410);
  return v_ret_24bool;
}
Clo g_list_2eany_24s695184589x587274465_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s695184589x587274465_entry, 3, 0};

V g_list_2eany_24s695184589x587274465(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(heff_dup(v_lit_241)));
    if (heff_strEq_c_lent(v_t_245, v_x_243, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s695184589x587274465_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2eany_24s695184589x587274465(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2eany_24s1836353438x580818415_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1836353438x580818415_entry, 2, 0};

V g_list_2eany_24s1836353438x580818415(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(v_x_242))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1836353438x580818415_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1836353438x580818415(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str0, 5, "label");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str1, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_24dps_str2, 6, "detail");
Clo g_list_2emap_24s4199228x1154005405_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_24dps_entry, 2, 0};

V g_list_2emap_24s4199228x1154005405_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_label_244 = heff_take_field(v_x_242, 0);
    V v_detail_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str0), heff_tag_n(TAG_JString, 1, (V[]){v_label_244})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str1), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_24dps_str2), heff_tag_n(TAG_JString, 1, (V[]){v_detail_245})});
    V v_t_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
    V v_cell_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410}), heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2411);
    V t_0 = v_xs_243;
    V t_1 = v_u_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s4199228x1154005405_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1201185697x960477413_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1201185697x960477413_entry, 2, 0};

V g_list_2ekeepIf_24s1201185697x960477413(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_intLe_c_lent(v_t_246, v_lit_240, 1)) {
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1201185697x960477413_24dps(v_lit_240, v_xs_243, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1201185697x960477413_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1201185697x960477413(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s1618362284x812128366_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2ekeepIf_24s44384897x1267641110_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s44384897x1267641110_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s44384897x1267641110_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_xs_243;
      V t_1 = v_u_246;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s44384897x1267641110_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s44384897x1267641110_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s3089255x286808945_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s3089255x286808945_entry, 4, 0};

V g_list_2ekeepIf_24s3089255x286808945(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_lit_241, 2)), 0, 2);
    V v_t_247 = heff_strFind(heff_strOfRunes(v_t_246), heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242));
    if (heff_intLe_c_lent(v_lit_240, v_t_247, 2)) {
      V v_cell_248 = heff_tag_re_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2ekeepIf_24s3089255x286808945_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, v_cell_248));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s3089255x286808945_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s3089255x286808945(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1686830387x1555365313_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1686830387x1555365313_entry, 4, 0};

V g_list_2efoldl_24f1686830387x1555365313(V v_z_240, V v_f_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_x3_243);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      heff_take_n(v_x3_243, 3ULL, 2);
      V v_x_248 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){v_x_244, v_y_246}));
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_248, v_z_240});
      V t_1 = v_f_241;
      V t_2 = v_xs_245;
      V t_3 = v_ys_247;
      v_z_240 = t_0;
      v_f_241 = t_1;
      v_x2_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1686830387x1555365313(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_list_2emap_24f8874541x1844987517_lam1(V self, V *args);
V g_list_2emap_24f8874541x1844987517_lam0(V self, V *args);
Clo g_list_2emap_24f8874541x1844987517_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f8874541x1844987517_entry, 2, 0};

V g_list_2emap_24f8874541x1844987517(V v_a_240, V v_b_241) {
top: ;
  if (heff_intLt_c_lent(v_b_241, v_a_240, 0)) {
    heff_drop(v_a_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_clo_n(g_list_2emap_24f8874541x1844987517_lam0, 1, 1, (V[]){heff_dup(v_a_240)}), heff_hole()});
    V v_u_245 = ({ V a_0 = heff_intAdd(v_a_240, MK_INT(1LL)); V a_1 = v_b_241; V a_2 = v_cell_244; V r_ = (g_list_2emap_24f8874541x1844987517_24dps(a_0, a_1, a_2)); heff_drop(v_b_241); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
}
V g_list_2emap_24f8874541x1844987517_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f8874541x1844987517(a[0], a[1]);
}
V g_list_2emap_24f8874541x1844987517_lam1(V self, V *args) {
  V v_a_243 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_drop(v_a_243);
  heff_clo_take(self, 1);
  return v_a_242;
}
V g_list_2emap_24f8874541x1844987517_lam0(V self, V *args) {
  V v_a_242 = args[0];
  V v_a_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_a_240}), NTAG(TAG_SpId), heff_clo_n(g_list_2emap_24f8874541x1844987517_lam1, 1, 1, (V[]){v_a_242}), NTAG(TAG_Nothing)));
}
Clo g_list_2efoldl_24f1625738412x188935108_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1625738412x188935108_entry, 3, 0};

V g_list_2efoldl_24f1625738412x188935108(V v_z_240, V v_x1_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x1_241, 0);
    V v_ks_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop(v_k_243);
      heff_drop(v_ks_244);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x2_242, 0);
      V v_vs_246 = heff_field(v_x2_242, 1);
      V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
      V v_x_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_MkPair, 2, (V[]){v_k_243, v_v_245});
      V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_240});
      V t_1 = v_ks_244;
      V t_2 = v_vs_246;
      v_z_240 = t_0;
      v_x1_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1625738412x188935108(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f1770886889x1685770680_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1770886889x1685770680_entry, 2, 0};

V g_list_2efoldl_24f1770886889x1685770680(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_x_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1770886889x1685770680_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1770886889x1685770680(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24f1632378148x1903828118_str0, 13, "static Clo g_");
Clo g_list_2emap_24f1632378148x1903828118_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1632378148x1903828118_entry, 2, 0};

V g_list_2emap_24f1632378148x1903828118(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_242, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_list_2emap_24f1632378148x1903828118_str0))) {
      V v_t_244 = heff_strSlice(heff_dup(v_x_242), heff_dup(v_lit_240), heff_strLength(v_x_242));
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
      V v_u_246 = (g_list_2emap_24f1632378148x1903828118_24dps(v_lit_240, v_xs_243, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1632378148x1903828118_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f1632378148x1903828118(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f525774350x554415833_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f525774350x554415833_24dps_entry, 6, 0};

V g_list_2emap_24f525774350x554415833_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_248 = heff_dup(heff_rfield(v_lit_241, 9));
    V v_t_249;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_249 = heff_dup(v_lit_242);
    } else {
      heff_drop(v_t_248);
      v_t_249 = heff_dup(v_lit_243);
    }
    V v_x_2410 = heff_strAppend(v_t_249, v_x_246);
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_2410, heff_dup(v_lit_240)), heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_245, MK_INT(1LL), v_cell_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_u_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f525774350x554415833_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a5 = a[5]; V r = g_list_2emap_24f525774350x554415833_24dps(a0, a1, a2, a3, a[4], a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a5); return r;
}
HEFF_LIT(g_list_2emap_24f1285463828x1893111862_24dps_str0, 26, "abcdefghijklmnopqrstuvwxyz");
HEFF_LIT(g_list_2emap_24f1285463828x1893111862_24dps_str1, 1, "_");
Clo g_list_2emap_24f1285463828x1893111862_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1285463828x1893111862_24dps_entry, 4, 0};

V g_list_2emap_24f1285463828x1893111862_24dps(V v_lit_240, V v_i_241, V v_box_24n_242, V v_d_243) {
  int64_t v_n_242 = heff_peek_word(v_box_24n_242);
top: ;
  if ((v_n_242 <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_s_244 = heff_dup(v_lit_240);
    V v_i_245 = heff_dup(v_i_241);
    V v_t_249;
    if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_244, v_i_245, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_244, v_i_245, 0)) <= ((int64_t)90ULL)))) {
      int64_t v_t_246 = (heff_unbox_word(heff_strByteAt_lent(v_s_244, v_i_245, 0)) - ((int64_t)65ULL));
      int64_t v_t_247 = (heff_unbox_word(heff_strByteAt(v_s_244, v_i_245)) - ((int64_t)64ULL));
      v_t_249 = heff_strSlice(((V)&g_list_2emap_24f1285463828x1893111862_24dps_str0), heff_box_word(v_t_246), heff_box_word(v_t_247));
    } else {
      V v_c_248 = heff_strByteAt_lent(v_s_244, v_i_245, 0);
      if ((((((int64_t)97ULL) <= heff_peek_word(v_c_248)) && (heff_peek_word(v_c_248) <= ((int64_t)122ULL))) || (((((int64_t)48ULL) <= heff_peek_word(v_c_248)) && (heff_peek_word(v_c_248) <= ((int64_t)57ULL))) || (heff_peek_word(v_c_248) == ((int64_t)95ULL))))) {
        heff_drop(v_c_248);
        v_t_249 = heff_strSlice(v_s_244, heff_dup(v_i_245), heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))));
      } else {
        heff_drop(v_s_244);
        heff_drop(v_i_245);
        heff_drop(v_c_248);
        v_t_249 = ((V)&g_list_2emap_24f1285463828x1893111862_24dps_str1);
      }
    }
    V v_cell_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2410);
    V t_0 = v_lit_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    int64_t t_2 = v_n_242;
    V t_3 = v_u_2411;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f1285463828x1893111862_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24f1285463828x1893111862_24dps(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1425140065x1254143828_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1425140065x1254143828_entry, 4, 0};

V g_list_2efoldl_24f1425140065x1254143828(V v_lit_240, V v_z_241, V v_seen_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_seen_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_rest_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_244, v_seen_242));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_seen_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = heff_intAdd_lent(v_z_241, v_lit_240, 1);
      V t_2 = heff_tag_re_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, v_seen_242});
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_seen_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efoldl_24f1425140065x1254143828(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1809017761x1063871171_24tok2_entry, 2, 0};

V g_list_2emap_24s1809017761x1063871171_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1809017761x1063871171_24dps(v_xs_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1809017761x1063871171_24tok2(a[0], a[1]);
}