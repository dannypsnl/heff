// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_ByFields 9073
#define TAG_ByTags 55317
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkEquation 38417
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_decls 296817955
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_globals 352931696
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_own 320000
#define LBL_program 2069953735
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_title 311729778
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_uses 10094739
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_name__span__start__equals__end[] = {LBL_name, LBL_span, LBL_start, LBL_equals, LBL_end};
static uint32_t shape_program__kept[] = {LBL_program, LBL_kept};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_title__start__end__text[] = {LBL_title, LBL_start, LBL_end, LBL_text};
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2ecatMaybesL(V);
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_clo;
V g_heff_2elsp_2elsp_2ejfalse_get(void);
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots_24dps(V, V);
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources_24dps(V, V);
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo;
V g_heff_2elsp_2elsp_2eoffset16(V, V, V, V);
V g_heff_2elsp_2elsp_2eoffset16_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffset16_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_get(void);
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120(V, V, V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2eregistration_get(void);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewordEnd(V, V);
V g_heff_2elsp_2elsp_2ewordEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewordEnd_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
V g_heff_2elsp_2esplit_2ealiasedTag(V, V);
V g_heff_2elsp_2esplit_2ealiasedTag_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ealiasedTag_clo;
V g_heff_2elsp_2esplit_2earrowOutside(V, V, V);
V g_heff_2elsp_2esplit_2earrowOutside_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2earrowOutside_clo;
V g_heff_2elsp_2esplit_2ecatMaybesS(V);
V g_heff_2elsp_2esplit_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ecatMaybesS_clo;
V g_heff_2elsp_2esplit_2edeclsOf(V);
V g_heff_2elsp_2esplit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2edeclsOf_clo;
V g_heff_2elsp_2esplit_2eextentEnd(V, V, V);
V g_heff_2elsp_2esplit_2eextentEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eextentEnd_clo;
V g_heff_2elsp_2esplit_2efirstJust(V);
V g_heff_2elsp_2esplit_2efirstJust_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efirstJust_clo;
HeffT2 g_heff_2elsp_2esplit_2efirstJust_24cpr(V);
V g_heff_2elsp_2esplit_2efreshNames(V, V);
V g_heff_2elsp_2esplit_2efreshNames_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2efreshNames_clo;
V g_heff_2elsp_2esplit_2ehintOf(V, V);
V g_heff_2elsp_2esplit_2ehintOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ehintOf_clo;
V g_heff_2elsp_2esplit_2eisOperator(V);
V g_heff_2elsp_2esplit_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eisOperator_clo;
V g_heff_2elsp_2esplit_2elineStart(V, V);
V g_heff_2elsp_2esplit_2elineStart_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2elineStart_clo;
V g_heff_2elsp_2esplit_2enameEnd(V, V);
V g_heff_2elsp_2esplit_2enameEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2enameEnd_clo;
V g_heff_2elsp_2esplit_2evarIn(V, V);
V g_heff_2elsp_2esplit_2evarIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2evarIn_clo;
V g_heff_2elsp_2esplit_2ewordsIn(V, V, V, V);
V g_heff_2elsp_2esplit_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2ewordsIn_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HeffT2 g_list_2efind_24s1338461068x888657721_24cpr(V, V);
HeffT2 g_list_2efind_24s1953031388x2120050076_24cpr(V, V);
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
V g_list_2efind_24s633938771x532201311(V, V);
V g_list_2efind_24s633938771x532201311_entry(V self, V *a);
extern Clo g_list_2efind_24s633938771x532201311_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s661788424x2062432904(V, V);
V g_list_2efoldl_24s661788424x2062432904_entry(V self, V *a);
extern Clo g_list_2efoldl_24s661788424x2062432904_clo;
V g_list_2ekeepIf_24s1441124185x871809048(V, V);
V g_list_2ekeepIf_24s1441124185x871809048_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_clo;
V g_list_2ekeepIf_24s647917584x875728492(V, V);
V g_list_2ekeepIf_24s647917584x875728492_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s647917584x875728492_clo;
V g_list_2ekeepIf_24s689992630x418898235(V, V);
V g_list_2ekeepIf_24s689992630x418898235_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s689992630x418898235_clo;
V g_list_2elookup_24s1507486579x90027037(V, V);
V g_list_2elookup_24s1507486579x90027037_entry(V self, V *a);
extern Clo g_list_2elookup_24s1507486579x90027037_clo;
V g_list_2elookup_24s1507486579x90027037_24tok1(V, V, V);
V g_list_2elookup_24s1507486579x90027037_24tok1_entry(V self, V *a);
extern Clo g_list_2elookup_24s1507486579x90027037_24tok1_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1170504272x1852564147(V);
V g_list_2emap_24s1170504272x1852564147_entry(V self, V *a);
extern Clo g_list_2emap_24s1170504272x1852564147_clo;
V g_list_2emap_24s1387309293x1990579214(V);
V g_list_2emap_24s1387309293x1990579214_entry(V self, V *a);
extern Clo g_list_2emap_24s1387309293x1990579214_clo;
V g_list_2emap_24s1628253759x601849359(V, V, V);
V g_list_2emap_24s1628253759x601849359_entry(V self, V *a);
extern Clo g_list_2emap_24s1628253759x601849359_clo;
V g_list_2emap_24s580776739x648604941(V);
V g_list_2emap_24s580776739x648604941_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s2130584539x811126895(V, V, V);
V g_list_2ezipWith_24s2130584539x811126895_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2130584539x811126895_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2eempty_get(void);
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2ejfalse_lit0, TAG_JBool, 1, NTAG(TAG_False));

static V g_heff_2elsp_2elsp_2ejfalse_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejfalse_st;
static V g_heff_2elsp_2elsp_2ejfalse_init(void) {
  return ((V)&g_heff_2elsp_2elsp_2ejfalse_lit0);
}
V g_heff_2elsp_2elsp_2ejfalse_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejfalse_st)) return g_heff_2elsp_2elsp_2ejfalse_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejfalse_val, &g_heff_2elsp_2elsp_2ejfalse_st, g_heff_2elsp_2elsp_2ejfalse_init);
}
Clo g_heff_2elsp_2elsp_2eunits16Go_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eunits16Go_entry, 4, 0};

V g_heff_2elsp_2elsp_2eunits16Go(V v_src_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  if ((heff_intLe_c_lent(v_j_242, v_i_241, 0) || heff_intLe_c_lent(heff_strLength_lent(v_src_240, 0), v_i_241, 1))) {
    heff_drop(v_i_241);
    return v_n_243;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) < ((int64_t)128ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_n_243 = t_3;
      goto top;
    } else {
      HeffT2 v_t_244 = heff_strRuneDecode_lent(v_src_240, v_i_241, 0);
      {
        V v_rune_245 = v_t_244.f[0];
        V v_width_246 = v_t_244.f[1];
        V v_t_247;
        if (heff_intLe_c(MK_INT(65536LL), heff_runeToInt(v_rune_245))) {
          v_t_247 = MK_INT(2LL);
        } else {
          v_t_247 = MK_INT(1LL);
        }
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, v_width_246);
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, v_t_247);
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eunits16Go(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eoffsetGo_str1, 1, "\012");
Clo g_heff_2elsp_2elsp_2eoffsetGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eoffsetGo_entry, 5, 0};

V g_heff_2elsp_2elsp_2eoffsetGo(V v_src_240, V v_line_241, V v_ch_242, V v_i_243, V v_l_244) {
top: ;
  if (heff_intLe_c_lent(v_line_241, v_l_244, 0)) {
    heff_drop(v_l_244);
    V v_d_245 = heff_strLength_lent(v_src_240, 0);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str0), v_src_240, v_i_243, 1);
    V v_t_247;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_247 = v_d_245;
    } else {
      heff_drop(v_d_245);
      v_t_247 = v_j_246;
    }
    return ({ V a_0 = v_src_240; V a_1 = v_i_243; V a_2 = v_t_247; V a_3 = heff_dup(v_ch_242); V r_ = (g_heff_2elsp_2elsp_2eoffset16(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  } else {
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eoffsetGo_str1), v_src_240, v_i_243, 5);
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_l_244);
      heff_drop(v_j_248);
      return heff_strLength_lent(v_src_240, 0);
    } else {
      V t_0 = v_src_240;
      V t_1 = v_line_241;
      V t_2 = v_ch_242;
      V t_3 = heff_intAdd(v_j_248, MK_INT(1LL));
      V t_4 = heff_intAdd(v_l_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_line_241 = t_1;
      v_ch_242 = t_2;
      v_i_243 = t_3;
      v_l_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eoffsetGo(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str1, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str2, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str3, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str4, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str5, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str6, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str7, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str8, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str9, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_str10, 5, "range");
Clo g_heff_2elsp_2elsp_2ediagnostic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_entry, 2, 0};

V g_heff_2elsp_2elsp_2ediagnostic(V v_src_240, V v_d_241) {
top: ;
  V v_span_242 = heff_take_field(v_d_241, 3);
  V v_severity_243 = heff_take_field(v_d_241, 1);
  V v_note_244 = heff_take_field(v_d_241, 4);
  V v_msg_245 = heff_take_field(v_d_241, 2);
  V v_code_246 = heff_get_n(v_d_241, 0, 5);
  V v_t_247 = (g_heff_2elsp_2elsp_2erange(v_src_240, v_span_242));
  V v_t_248 = heff_dup(v_severity_243);
  V v_t_249;
  switch (heff_tag_of(v_t_248)) {
  case TAG_SError: {
    v_t_249 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_249 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_249 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2410 = v_note_244;
  V v_t_2412;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    v_t_2412 = v_msg_245;
    break;
  }
  case TAG_Just: {
    V v_n_2411 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    v_t_2412 = heff_strAppend(heff_strAppend(v_msg_245, ((V)&g_heff_2elsp_2elsp_2ediagnostic_str0)), v_n_2411);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_ys_2419;
  if (heff_intEq_c_lent(v_code_246, MK_INT(0LL), 2)) {
    heff_drop(v_severity_243);
    heff_drop(v_code_246);
    v_ys_2419 = NTAG(TAG_Nil);
  } else {
    V v_t_2413 = v_severity_243;
    V v_t_2414;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_SError: {
      v_t_2414 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str1);
      break;
    }
    case TAG_SWarning: {
      v_t_2414 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str2);
      break;
    }
    case TAG_SDebug: {
      v_t_2414 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_str3);
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    V v_t_2415 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(v_code_246)));
    V v_t_2416 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2415), ((V)&g_heff_2elsp_2elsp_2ediagnostic_str4)));
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2414, v_t_2416), heff_intShow(v_code_246));
    V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str5), heff_tag_n(TAG_JString, 1, (V[]){v_t_2417})});
    v_ys_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  }
  V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str6), heff_tag_n(TAG_JInt, 1, (V[]){v_t_249})});
  V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str7), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str8)})});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str9), heff_tag_n(TAG_JString, 1, (V[]){v_t_2412})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_ys_2419})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_str10), v_t_247}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2423})});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2424});
}
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2ediagnostic(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_entry, 1, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2elsp_2elsp_2ecatMaybesL_24dps(v_rest_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str1, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str2, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str3, 2, "{-");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str4, 6, "module");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_24dps_str5, 6, "import");
Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2edeclsGo_24dps(V v_x1_240, V v_key_241, V v_above_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_key_241);
    heff_drop(v_above_242);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_246 = heff_take_field(v_l_244, 1);
    V v_at_247 = heff_get_n(v_l_244, 0, 2);
    V v_l_248 = heff_dup(v_text_246);
    if ((heff_strEq_c(heff_strSlice_lent(v_l_248, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str0)) || heff_strEq_c(heff_strSlice_lent(v_l_248, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str1)))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_text_246);
      heff_drop(v_l_248);
      V v_t_2410;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_2410 = v_at_247;
        break;
      }
      case TAG_Just: {
        V v_x_249 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop(v_at_247);
        v_t_2410 = v_x_249;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_245;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
      V t_3 = v_d_243;
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_l_248);
      V v_l_2411 = heff_dup(v_text_246);
      V v_t_2415;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_l_2411, 0)))) {
        if (((heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)32ULL)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)9ULL)) ? 0 : !(heff_unbox_word(heff_strByteAt_lent(v_l_2411, MK_INT(0LL), 2)) == ((int64_t)13ULL))))) {
          if ((heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str2)) ? 0 : !heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str3)))) {
            V v_t_2412 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2411, MK_INT(0LL)));
            V v_x1_2414 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_l_2411, MK_INT(0LL), v_t_2412, 2), ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str4)) || ({ V v_t_2413 = (g_heff_2elsp_2elsp_2ewordEnd(v_l_2411, MK_INT(0LL))); int c_ = ({ V v_t_2428 = heff_strSlice_lent(v_l_2411, MK_INT(0LL), v_t_2413, 2); int c_ = heff_strEq_c_lent(v_t_2428, ((V)&g_heff_2elsp_2elsp_2edeclsGo_24dps_str5), 2); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2413); c_; })));
            heff_drop(v_l_2411);
            heff_drop(v_t_2412);
            v_t_2415 = heff_bool(!(heff_dup(v_x1_2414) == NTAG(TAG_True)));
            heff_drop(v_x1_2414);
          } else {
            heff_drop(v_l_2411);
            v_t_2415 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_l_2411);
          v_t_2415 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_l_2411);
        v_t_2415 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_t_2416 = (g_heff_2elsp_2elsp_2ekeyOf(v_text_246));
        V v_x1_2417 = heff_bool(heff_strEq_c_lent(v_t_2416, v_key_241, 0));
        heff_drop(v_t_2416);
        if (!(heff_dup(v_x1_2417) == NTAG(TAG_True))) {
          heff_drop(v_key_241);
          heff_drop(v_x1_2417);
          V v_cut_2419;
          switch (heff_tag_of(v_above_242)) {
          case TAG_Nothing: {
            v_cut_2419 = heff_dup(v_at_247);
            break;
          }
          case TAG_Just: {
            V v_x_2418 = heff_field(v_above_242, 0);
            heff_take_n(v_above_242, 1ULL, 1);
            v_cut_2419 = v_x_2418;
            break;
          }
          default: heff_nomatch(v_above_242);
          }
          V v_n_2420 = v_at_247;
          HeffT2 v_t_2421 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_text_246));
          {
            V v_field_2422 = v_t_2421.f[0];
            V v_field_2423 = v_t_2421.f[1];
            V v_t_2424 = ({ V a_0 = v_text_246; V r_ = (g_heff_2elsp_2elsp_2ekeyOf(a_0)); heff_drop(v_text_246); r_; });
            V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd_lent(v_field_2422, v_n_2420, 1), heff_intAdd(v_field_2423, v_n_2420)});
            V v_cell_2426 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_cut__name, (V[]){v_cut_2419, v_t_2425}), heff_hole()});
            V v_u_2427 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2426);
            V t_0 = v_rest_245;
            V t_1 = v_t_2424;
            V t_2 = NTAG(TAG_Nothing);
            V t_3 = v_u_2427;
            v_x1_240 = t_0;
            v_key_241 = t_1;
            v_above_242 = t_2;
            v_d_243 = t_3;
            goto top;
          }
        } else {
          heff_drop(v_above_242);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_text_246);
          heff_drop(v_at_247);
          heff_drop(v_x1_2417);
          V t_0 = v_rest_245;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_d_243;
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
      } else {
        heff_drop(v_above_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_text_246);
        heff_drop(v_at_247);
        heff_drop(v_t_2415);
        V t_0 = v_rest_245;
        V t_1 = v_key_241;
        V t_2 = NTAG(TAG_Nothing);
        V t_3 = v_d_243;
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2elsp_2edeclsGo_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2elsp_2elsp_2enubSources_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubSources_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubSources_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s1441124185x871809048(v_s_242, v_ss_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_s_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubSources_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2enubSources_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_cs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s647917584x875728492(v_c_241, v_cs_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_c_241, heff_hole()});
    V v_u_245 = (g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubCheckedPaths(a[0]);
}
Clo g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s647917584x875728492(v_c_242, v_cs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_c_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubCheckedPaths_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2enubCheckedPaths_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2elsp_2enubRoots_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubRoots_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2enubRoots_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s689992630x418898235(v_r_242, v_rs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_r_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubRoots_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2enubRoots_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str1, 3, "2.0");
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit2, TAG_JString, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_str1));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit3, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str0), ((V)&g_heff_2elsp_2elsp_2eregistration_lit2));
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str4, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str5, 10, "heff-watch");
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit6, TAG_JString, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_str5));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit7, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str4), ((V)&g_heff_2elsp_2elsp_2eregistration_lit6));
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str8, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str9, 25, "client/registerCapability");
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit10, TAG_JString, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_str9));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit11, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str8), ((V)&g_heff_2elsp_2elsp_2eregistration_lit10));
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str12, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str13, 13, "registrations");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str14, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str15, 10, "heff-watch");
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit16, TAG_JString, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_str15));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit17, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str14), ((V)&g_heff_2elsp_2elsp_2eregistration_lit16));
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str18, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str19, 31, "workspace/didChangeWatchedFiles");
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit20, TAG_JString, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_str19));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit21, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str18), ((V)&g_heff_2elsp_2elsp_2eregistration_lit20));
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str22, 15, "registerOptions");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str23, 8, "watchers");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str24, 11, "globPattern");
HEFF_LIT(g_heff_2elsp_2elsp_2eregistration_str25, 7, "**/*.hf");
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit26, TAG_JString, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_str25));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit27, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str24), ((V)&g_heff_2elsp_2elsp_2eregistration_lit26));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit28, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit27), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit29, TAG_JObject, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_lit28));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit30, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit29), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit31, TAG_JArray, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_lit30));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit32, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str23), ((V)&g_heff_2elsp_2elsp_2eregistration_lit31));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit33, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit32), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit34, TAG_JObject, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_lit33));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit35, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str22), ((V)&g_heff_2elsp_2elsp_2eregistration_lit34));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit36, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit35), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit37, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit21), ((V)&g_heff_2elsp_2elsp_2eregistration_lit36));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit38, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit17), ((V)&g_heff_2elsp_2elsp_2eregistration_lit37));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit39, TAG_JObject, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_lit38));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit40, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit39), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit41, TAG_JArray, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_lit40));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit42, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str13), ((V)&g_heff_2elsp_2elsp_2eregistration_lit41));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit43, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit42), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit44, TAG_JObject, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_lit43));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit45, TAG_MkPair, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_str12), ((V)&g_heff_2elsp_2elsp_2eregistration_lit44));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit46, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit45), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit47, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit11), ((V)&g_heff_2elsp_2elsp_2eregistration_lit46));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit48, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit7), ((V)&g_heff_2elsp_2elsp_2eregistration_lit47));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit49, TAG_Cons, 2, ((V)&g_heff_2elsp_2elsp_2eregistration_lit3), ((V)&g_heff_2elsp_2elsp_2eregistration_lit48));
HEFF_TAG_LIT(g_heff_2elsp_2elsp_2eregistration_lit50, TAG_JObject, 1, ((V)&g_heff_2elsp_2elsp_2eregistration_lit49));

static V g_heff_2elsp_2elsp_2eregistration_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eregistration_st;
static V g_heff_2elsp_2elsp_2eregistration_init(void) {
  return ((V)&g_heff_2elsp_2elsp_2eregistration_lit50);
}
V g_heff_2elsp_2elsp_2eregistration_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eregistration_st)) return g_heff_2elsp_2elsp_2eregistration_val;
  return heff_global(&g_heff_2elsp_2elsp_2eregistration_val, &g_heff_2elsp_2elsp_2eregistration_st, g_heff_2elsp_2elsp_2eregistration_init);
}

static V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_st;
static V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_init(void) {
  return heff_rec_n(2, shape_program__kept, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_st)) return g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_val;
  return heff_global(&g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_val, &g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_st, g_heff_2elsp_2elsp_2eprojectAnew_24s50942975x1347504124_24rec0_init);
}
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_entry, 4, 0};

V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120(V v_st_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    V v_t_244 = heff_rec_n(2, shape_st__program, (V[]){v_st_240, NTAG(TAG_Nil)});
    return heff_tail(v_z_243, 1, (V[]){v_t_244});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_248 = heff_field(v_x21_245, 1);
      V v_c_249 = (g_heff_2elsp_2elsp_2eprojectFor_24s1957285193x1626222673(v_st_240, heff_dup(v_f_248), NTAG(TAG_Nothing)));
      return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_lam0, 1, 3, (V[]){heff_dup(v_rest_246), v_z_242, v_z_243})});
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_program_2412 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_st_2414 = heff_take_field(v_x_2413, 0);
  V v_program_2415 = heff_take_field(v_x_2413, 1);
  V v_st_2416 = v_st_2414;
  heff_clo_take(self, 2);
  V v_program_2417 = (g_prelude_2e_2b_2b(v_program_2412, v_program_2415));
  V f_ = v_z_243;
  args[0] = ({ V rv_0 = v_st_2416; V rv_1 = v_program_2417; V rr_ = heff_rec_reuse_nf(v_x_2413, 0ULL, 2, shape_st__program, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_st_2411 = heff_take_field(v_x_2410, 0);
  V v_program_2412 = heff_get_n(v_x_2410, 1, 2);
  heff_clo_take(self, 3);
  return ({ V a_0 = v_st_2411; V a_1 = v_rest_246; V a_2 = v_z_242; V a_3 = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120_lam1, 1, 2, (V[]){v_program_2412, v_z_243}); V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1375617471x1801064120(a_0, a_1, a_2, a_3)); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str4, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str17, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str18, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str19, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str20, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str21, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str22, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str23, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str24, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str25, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str27, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str28, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str31, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str32, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str33, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str34, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str35, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str36, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str37, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str38, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str39, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str40, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str41, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str42, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str43, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str44, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str45, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str46, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str47, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str48, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str49, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str50, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str51, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str52, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str54, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str55, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str56, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str57, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str58, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str59, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str60, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str61, 1, "}");
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_entry, 6, 0};

V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597(V v_st_240, V v_id_241, V v_d_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_243, heff_dup(heff_rfield(v_d_242, 1))));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_242, 2);
      V v_x_249 = v_field_248;
      heff_drop(v_x_249);
      V v_t_2410 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str0), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str1), MK_INT(0LL)));
      V v_acc_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str2)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str3));
      V v_t_2412 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str4), heff_strAppend(v_acc_2411, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str5)), MK_INT(0LL)));
      V v_acc_2413 = heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str6));
      V v_t_2414 = heff_strAppend(heff_strAppend(v_acc_2413, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str7)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str8));
      V v_t_2415 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str9), v_t_2414, MK_INT(0LL)));
      V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str10)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str11));
      V v_acc_2417 = (g_json_2estringify_2ewriteInto_240(v_t_2416, v_id_241));
      V v_t_2418 = heff_strAppend(heff_strAppend(v_acc_2417, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str12)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str13));
      V v_t_2419 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str14), v_t_2418, MK_INT(0LL)));
      V v_acc_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str15)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str16));
      V v_t_2421 = heff_strAppend(heff_strAppend(v_acc_2420, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str17)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str18));
      V v_a_2422 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2421, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str19)), NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
      return (g_co_2eop_24s535099379x685970669(v_t_2426, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam0, 1, 2, (V[]){v_z_245, v_st_240})));
    } else {
      V v_t_2428 = v_field_248;
      if (heff_strEq_c(heff_dup(v_t_2428), heff_dup(heff_rfield(v_d_242, 1)))) {
        heff_drop_rec(v_d_242, 2);
        heff_drop(v_t_2428);
        V v_t_2429 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str20), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str21), MK_INT(0LL)));
        V v_acc_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str22)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str23));
        V v_t_2431 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str24), heff_strAppend(v_acc_2430, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str25)), MK_INT(0LL)));
        V v_acc_2432 = heff_strAppend(v_t_2431, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str26));
        V v_t_2433 = heff_strAppend(heff_strAppend(v_acc_2432, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str27)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str28));
        V v_t_2434 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str29), v_t_2433, MK_INT(0LL)));
        V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str30)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str31));
        V v_acc_2436 = (g_json_2estringify_2ewriteInto_240(v_t_2435, v_id_241));
        V v_t_2437 = heff_strAppend(heff_strAppend(v_acc_2436, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str32)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str33));
        V v_t_2438 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str34), v_t_2437, MK_INT(0LL)));
        V v_acc_2439 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str35)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str36));
        V v_t_2440 = heff_strAppend(heff_strAppend(v_acc_2439, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str37)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str38));
        V v_a_2441 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str39)), NTAG(TAG_MkUnit)});
        V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2441})});
        V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
        V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
        V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
        return (g_co_2eop_24s535099379x685970669(v_t_2445, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam1, 1, 2, (V[]){v_z_245, v_st_240})));
      } else {
        V v_src_2447 = heff_dup(heff_rfield(v_d_242, 1));
        V v_t_2448 = heff_strLength(heff_get_n(v_d_242, 1, 2));
        V v_t_2449 = (g_heff_2elsp_2elsp_2eposition(v_src_2447, MK_INT(0LL)));
        V v_t_2450;
        if ((((int64_t)0ULL) <= heff_peek_word(v_t_2448))) {
          v_t_2450 = v_t_2448;
        } else {
          heff_drop(v_t_2448);
          v_t_2450 = MK_INT(0LL);
        }
        V v_t_2451 = ({ V a_0 = v_src_2447; V a_1 = v_t_2450; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_2447); r_; });
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str40), v_t_2451}), NTAG(TAG_Nil)});
        V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str41), v_t_2449}), v_t_2452});
        V v_t_2454 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str42), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2453})});
        V v_t_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str43), heff_tag_n(TAG_JString, 1, (V[]){v_t_2428})});
        V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, NTAG(TAG_Nil)});
        V v_t_2457 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, v_t_2456})});
        V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
        V v_result_2459 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_2458});
        V v_t_2460 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str44), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str45), MK_INT(0LL)));
        V v_acc_2461 = heff_strAppend(heff_strAppend(v_t_2460, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str46)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str47));
        V v_t_2462 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str48), heff_strAppend(v_acc_2461, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str49)), MK_INT(0LL)));
        V v_acc_2463 = heff_strAppend(v_t_2462, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str50));
        V v_t_2464 = heff_strAppend(heff_strAppend(v_acc_2463, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str51)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str52));
        V v_t_2465 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str53), v_t_2464, MK_INT(0LL)));
        V v_t_2466 = heff_strAppend(heff_strAppend(v_t_2465, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str54)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str55));
        V v_acc_2467 = (g_json_2estringify_2ewriteInto_240(v_t_2466, v_id_241));
        V v_t_2468 = heff_strAppend(heff_strAppend(v_acc_2467, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str56)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str57));
        V v_t_2469 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str58), v_t_2468, MK_INT(0LL)));
        V v_t_2470 = heff_strAppend(heff_strAppend(v_t_2469, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str59)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str60));
        V v_acc_2471 = ({ V a_0 = v_t_2470; V a_1 = v_result_2459; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_result_2459, 1); r_; });
        V v_a_2472 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2471, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_str61)), NTAG(TAG_MkUnit)});
        V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2472})});
        V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
        V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
        V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
        return (g_co_2eop_24s535099379x685970669(v_t_2476, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam2, 1, 2, (V[]){v_z_245, v_st_240})));
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam0(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_2427);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam1(V self, V *args) {
  V v_x_2446 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_2446);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1123441518x773251597_lam2(V self, V *args) {
  V v_x_2477 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_drop(v_x_2477);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str0, 1, "=");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str1, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str2, 12, "prelude.Pair");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str3, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str4, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str5, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str6, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str8, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str9, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str11, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str12, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str13, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str14, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str15, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str16, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str17, 1, " ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str18, 1, "(");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str19, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str20, 3, " = ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str21, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str22, 2, ", ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str23, 2, "{ ");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str24, 2, " }");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str25, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str26, 7, "Split `");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str27, 12, "` into cases");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str28, 5, "title");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str29, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str30, 16, "refactor.rewrite");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str31, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str32, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str33, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str34, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str35, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str36, 4, "edit");
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_entry, 8, 0};

V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285(V v_st_240, V v_f_241, V v_uri_242, V v_program_243, V v_c_244, V v_off_245, V v_z_246, V v_z_247) {
top: ;
  V v_t_2464 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam0, 1, 2, (V[]){heff_dup(v_c_244), v_off_245}), heff_dup(heff_rfield(v_c_244, 4))));
  HeffT2 v_t_2465 = ({ V a_0 = v_t_2464; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2464); r_; });
  {
    V v_field_2467 = v_t_2465.f[1];
    int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
    if ((v_tag_2466 == ((int64_t)0ULL))) {
      V v_s_2468 = v_field_2467;
      V v_c_2469 = heff_dup(v_c_244);
      V v_s_2470 = heff_dup(v_s_2468);
      V v_t_2471 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_2469, 4)));
      HeffT2 v_t_2472 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_t_2471));
      {
        V v_field_2473 = v_t_2472.f[0];
        heff_drop(v_t_2472.f[1]);
        HeffT2 v_t_2475 = ({ V a_0 = v_s_2470; V a_1 = v_field_2473; HeffT2 r_ = (g_list_2efind_24s1338461068x888657721_24cpr(a_0, a_1)); heff_drop(v_field_2473); r_; });
        {
          V v_field_2477 = v_t_2475.f[1];
          int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
          V v_t_2492;
          if ((v_tag_2476 == ((int64_t)0ULL))) {
            V v_l_2478 = v_field_2477;
            V v_t_2479 = heff_get_n(v_l_2478, 2, 3);
            switch (heff_tag_of(v_t_2479)) {
            case TAG_Nil: {
              heff_drop_rec(v_c_2469, 14);
              heff_drop_rec(v_s_2470, 5);
              v_t_2492 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Cons: {
              V v_x_2480 = heff_field(v_t_2479, 0);
              heff_take_n(v_t_2479, 1ULL, 2);
              HeffT2 v_t_2482 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2469, heff_get_n(v_x_2480, 0, 2)));
              {
                V v_field_2484 = v_t_2482.f[1];
                int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
                if ((v_tag_2483 == ((int64_t)0ULL))) {
                  V v_i_2485 = v_field_2484;
                  V v_name_2486 = heff_take_field(v_i_2485, 1);
                  V v_key_2487 = heff_take_field(v_i_2485, 2);
                  V v_ty_2488 = heff_get_n(v_i_2485, 4, 5);
                  if (heff_strEq_c(v_name_2486, heff_get_n(v_s_2470, 0, 5))) {
                    V v_t_2489 = v_key_2487;
                    switch (heff_tag_of(v_t_2489)) {
                    case TAG_Nothing: {
                      V v_t_2490 = heff_tr(heff_call(v_ty_2488, 1, (V[]){NTAG(TAG_MkUnit)}));
                      v_t_2492 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2490});
                      break;
                    }
                    case TAG_Just: {
                      heff_take_n(v_t_2489, 0ULL, 1);
                      heff_drop(v_ty_2488);
                      v_t_2492 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_t_2489);
                    }
                  } else {
                    heff_drop(v_key_2487);
                    heff_drop(v_ty_2488);
                    v_t_2492 = NTAG(TAG_Nothing);
                  }
                } else {
                  heff_drop_rec(v_s_2470, 5);
                  heff_drop(v_field_2484);
                  v_t_2492 = NTAG(TAG_Nothing);
                }
              }
              break;
            }
            default: heff_nomatch(v_t_2479);
            }
          } else {
            heff_drop_rec(v_c_2469, 14);
            heff_drop_rec(v_s_2470, 5);
            heff_drop(v_field_2477);
            v_t_2492 = NTAG(TAG_Nothing);
          }
          V v_c_2496;
          switch (heff_tag_of(v_t_2492)) {
          case TAG_Nothing: {
            v_c_2496 = (g_heff_2elsp_2elsp_2eprobedType_24s1911385429x1417666199(v_st_240, v_f_241, heff_dup(v_program_243), heff_dup(v_c_244), heff_dup(v_s_2468)));
            break;
          }
          case TAG_Just: {
            V v_t_2493 = heff_field(v_t_2492, 0);
            heff_take_n(v_t_2492, 1ULL, 1);
            heff_drop(v_st_240);
            heff_drop(v_f_241);
            v_c_2496 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam3, 2, 1, (V[]){v_t_2493});
            break;
          }
          default: heff_nomatch(v_t_2492);
          }
          return heff_tail(v_c_2496, 2, (V[]){v_z_246, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam4, 1, 5, (V[]){v_program_243, v_c_244, v_s_2468, v_uri_242, v_z_247})});
        }
      }
    } else {
      heff_drop(v_st_240);
      heff_drop(v_f_241);
      heff_drop(v_uri_242);
      heff_drop(v_program_243);
      heff_drop_rec(v_c_244, 14);
      heff_drop(v_z_246);
      heff_drop(v_field_2467);
      return heff_tail(v_z_247, 1, (V[]){NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam2(V self, V *args) {
  V v_p_2426 = args[0];
  V v_off_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_off_2410; V a_1 = v_p_2426; V r_ = (g_heff_2elsp_2esplit_2evarIn(a_0, a_1)); heff_drop(v_off_2410); heff_drop(v_p_2426); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam1(V self, V *args) {
  V v_e_2419 = args[0];
  V v_off_2410 = heff_env(self)[0];
  V v_src_249 = heff_env(self)[1];
  switch (heff_tag_of(v_e_2419)) {
  case TAG_At: {
    V v_x31_2420 = heff_field(v_e_2419, 0);
    V v_sp_2421 = heff_field(v_e_2419, 1);
    V v_ru_24e_2419_24At = heff_take_reuse_n(v_e_2419, 3ULL, 2);
    switch (heff_tag_of(v_x31_2420)) {
    case TAG_MkEquation: {
      V v_ps_2424 = heff_field(v_x31_2420, 2);
      heff_take_n(v_x31_2420, 4ULL, 4);
      heff_clo_take(self, 2);
      V v_t_2427 = (g_list_2emap_24tok2(v_ru_24e_2419_24At, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam2, 1, 1, (V[]){v_off_2410}), heff_dup(v_ps_2424)));
      HeffT2 v_t_2428 = ({ V a_0 = v_t_2427; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_2427); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_v_2431 = v_field_2430;
          V v_src_2432 = v_src_249;
          V v_v_2433 = v_v_2431;
          V v_name_2434 = heff_take_field(v_v_2433, 0);
          V v_span_2435 = heff_get_n(v_v_2433, 1, 2);
          V v_sp_2436 = v_sp_2421;
          V v_start_2437 = heff_take_field(v_sp_2436, 0);
          V v_end_2438 = heff_get_n(v_sp_2436, 1, 2);
          V v_ps_2439 = v_ps_2424;
          V v_from_2440 = ({ V a_0 = heff_dup(v_start_2437); V a_1 = v_ps_2439; V r_ = (g_list_2efoldl_24s661788424x2062432904(a_0, a_1)); heff_drop(v_ps_2439); r_; });
          V v_j_2441 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str0), v_src_2432, v_from_2440, 5);
          if (heff_intLt_c_lent(v_j_2441, MK_INT(0LL), 2)) {
            heff_drop(v_src_2432);
            heff_drop(v_name_2434);
            heff_drop(v_span_2435);
            heff_drop(v_start_2437);
            heff_drop(v_end_2438);
            heff_drop(v_j_2441);
            return NTAG(TAG_Nothing);
          } else {
            V v_t_2442 = (g_heff_2elsp_2esplit_2elineStart(v_src_2432, heff_dup(v_start_2437)));
            V v_d_2443 = heff_strLength_lent(v_src_2432, 0);
            V v_j_2444 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str1), v_src_2432, v_end_2438, 5);
            V v_t_2445;
            if (heff_intLt_c_lent(v_j_2444, MK_INT(0LL), 2)) {
              heff_drop(v_j_2444);
              v_t_2445 = v_d_2443;
            } else {
              heff_drop(v_d_2443);
              v_t_2445 = v_j_2444;
            }
            V v_t_2446 = ({ V a_0 = v_src_2432; V b_1 = heff_intSub_lent(v_start_2437, v_t_2442, 2); V a_2 = v_t_2445; V r_ = (g_heff_2elsp_2esplit_2eextentEnd(a_0, b_1, a_2)); heff_drop(v_src_2432); heff_drop(b_1); r_; });
            V v_t_2447 = heff_rec_n(5, shape_name__span__start__equals__end, (V[]){v_name_2434, v_span_2435, v_start_2437, heff_intAdd(v_j_2441, MK_INT(1LL)), v_t_2446});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2447});
          }
        } else {
          heff_drop(v_src_249);
          heff_drop(v_sp_2421);
          heff_drop(v_ps_2424);
          heff_drop(v_field_2430);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_x31_2420);
    }
  }
  default: return heff_nomatch(v_e_2419);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam0(V self, V *args) {
  V v_d_248 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_off_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_src_249 = heff_get_n(v_c_244, 3, 14);
  V v_off_2410 = v_off_245;
  V v_x3_2411 = v_d_248;
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_At: {
    V v_x31_2412 = heff_field(v_x3_2411, 0);
    V v_ru_24x3_2411_24At = heff_take_reuse_n(v_x3_2411, 1ULL, 2);
    switch (heff_tag_of(v_x31_2412)) {
    case TAG_DeclEquations: {
      V v_eqs_2418 = heff_field(v_x31_2412, 4);
      heff_take_n(v_x31_2412, 16ULL, 5);
      V v_t_2448 = (g_list_2emap_24tok2(v_ru_24x3_2411_24At, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam1, 1, 2, (V[]){v_off_2410, v_src_249}), v_eqs_2418));
      return ({ V a_0 = v_t_2448; V r_ = (g_heff_2elsp_2esplit_2efirstJust(a_0)); heff_drop(v_t_2448); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x31_2412, 0ULL, 5);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x31_2412, 0ULL, 4);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x31_2412, 0ULL, 3);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTest: {
      heff_take_n(v_x31_2412, 0ULL, 2);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x31_2412, 0ULL, 1);
      heff_drop(v_src_249);
      heff_drop(v_off_2410);
      heff_drop_cell(v_ru_24x3_2411_24At, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_2412);
    }
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam3(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k_2495 = args[1];
  V v_t_2493 = heff_env(self)[0];
  heff_drop(v_hd_2494);
  heff_clo_take(self, 1);
  V f_ = v_k_2495;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2493});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam5(V self, V *args) {
  V v_c2_24122 = args[0];
  V v_k_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24123 = ({ V a_0 = v_k_24120; V a_1 = heff_rfield(v_c2_24122, 7); HeffT2 r_ = (g_list_2efind_24s1953031388x2120050076_24cpr(a_0, a_1)); heff_drop(v_k_24120); r_; });
  {
    V v_field_24125 = v_t_24123.f[1];
    int64_t v_tag_24124 = ((int64_t)v_t_24123.f[0]);
    if ((v_tag_24124 == ((int64_t)0ULL))) {
      V v_o_24126 = v_field_24125;
      V v_t_24127 = (g_heff_2elsp_2esplit_2edeclsOf(v_c2_24122));
      return ({ V a_0 = v_o_24126; V a_1 = v_t_24127; V r_ = (g_list_2efind_24s633938771x532201311(a_0, a_1)); heff_drop(v_o_24126); heff_drop(v_t_24127); r_; });
    } else {
      heff_drop_rec(v_c2_24122, 14);
      heff_drop(v_field_24125);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam7(V self, V *args) {
  V v_o_24249 = args[0];
  V v_c_24248 = heff_env(self)[0];
  V v_g_24247 = heff_env(self)[1];
  V v_t_24250 = (g_heff_2elsp_2esplit_2eisOperator(heff_rfield(v_o_24249, 0)));
  if ((heff_dup(v_t_24250) == NTAG(TAG_True))) {
    heff_drop(v_t_24250);
    V v_x_24251 = heff_get_n(v_o_24249, 0, 2);
    heff_clo_take(self, 2);
    HeffT2 v_t_24252 = ({ V a_0 = v_x_24251; V b_1 = heff_get_n(v_c_24248, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_24254 = v_t_24252.f[1];
      int64_t v_tag_24253 = ((int64_t)v_t_24252.f[0]);
      if ((v_tag_24253 == ((int64_t)0ULL))) {
        V v_o_24255 = v_field_24254;
        HeffT3 v_t_24256 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g_24247, v_x_24251));
        {
          V v_field_24258 = v_t_24256.f[1];
          V v_field_24259 = v_t_24256.f[2];
          int64_t v_tag_24257 = ((int64_t)v_t_24256.f[0]);
          if ((v_tag_24257 == ((int64_t)0ULL))) {
            heff_drop_rec(v_o_24255, 2);
            heff_drop(v_field_24259);
            V v_x_24260 = v_field_24258;
            heff_drop(v_x_24260);
            return NTAG(TAG_False);
          } else {
            if ((v_tag_24257 == ((int64_t)1ULL))) {
              heff_drop_rec(v_o_24255, 2);
              heff_drop(v_field_24258);
              heff_drop(v_field_24259);
              return NTAG(TAG_False);
            } else {
              if ((v_tag_24257 == ((int64_t)2ULL))) {
                V v_k2_24261 = v_field_24258;
                V v_x_24262 = v_field_24259;
                heff_drop(v_x_24262);
                V v_ret_24bool = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_o_24255, 1)), heff_dup(v_k2_24261)));
                heff_drop_rec(v_o_24255, 2);
                heff_drop(v_k2_24261);
                return v_ret_24bool;
              } else {
                heff_drop_rec(v_o_24255, 2);
                heff_drop(v_field_24258);
                heff_drop(v_field_24259);
                return NTAG(TAG_False);
              }
            }
          }
        }
      } else {
        heff_drop(v_g_24247);
        heff_drop(v_x_24251);
        heff_drop(v_field_24254);
        return NTAG(TAG_False);
      }
    }
  } else {
    heff_drop_rec(v_o_24249, 2);
    heff_drop(self);
    heff_drop(v_t_24250);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam8(V self, V *args) {
  V v_d_24265 = args[0];
  V v_g_24246 = heff_env(self)[0];
  V v_x_24245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_g_24266 = v_g_24246;
  V v_c_24267 = v_x_24245;
  V v_x3_24268 = v_d_24265;
  switch (heff_tag_of(v_x3_24268)) {
  case TAG_At: {
    V v_x31_24269 = heff_field(v_x3_24268, 0);
    V v_ru_24x3_24268_24At = heff_take_reuse_n(v_x3_24268, 1ULL, 2);
    switch (heff_tag_of(v_x31_24269)) {
    case TAG_DeclEquations: {
      V v_op_24271 = heff_field(v_x31_24269, 0);
      V v_x315_24275 = heff_field(v_x31_24269, 4);
      heff_take_n(v_x31_24269, 17ULL, 5);
      switch (heff_tag_of(v_x315_24275)) {
      case TAG_Nil: {
        heff_drop(v_g_24266);
        heff_drop_rec(v_c_24267, 14);
        heff_drop_cell(v_ru_24x3_24268_24At, 2);
        heff_drop(v_op_24271);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_e_24276 = heff_field(v_x315_24275, 0);
        V v_x3152_24277 = heff_field(v_x315_24275, 1);
        heff_take_n(v_x315_24275, 3ULL, 2);
        switch (heff_tag_of(v_x3152_24277)) {
        case TAG_Nil: {
          V v_t_24278 = (g_heff_2elsp_2esplit_2eisOperator(v_op_24271));
          if ((heff_dup(v_t_24278) == NTAG(TAG_True))) {
            heff_drop(v_t_24278);
            HeffT2 v_t_24279 = ({ V a_0 = v_op_24271; V b_1 = heff_get_n(v_c_24267, 7, 14); HeffT2 r_ = (g_list_2efind_24s279352081x1530195138_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
            {
              V v_field_24281 = v_t_24279.f[1];
              int64_t v_tag_24280 = ((int64_t)v_t_24279.f[0]);
              if ((v_tag_24280 == ((int64_t)0ULL))) {
                V v_o_24282 = v_field_24281;
                HeffT3 v_t_24283 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g_24266, heff_dup(v_op_24271)));
                {
                  V v_field_24285 = v_t_24283.f[1];
                  V v_field_24286 = v_t_24283.f[2];
                  int64_t v_tag_24284 = ((int64_t)v_t_24283.f[0]);
                  if ((v_tag_24284 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24x3_24268_24At, 2);
                    heff_drop(v_op_24271);
                    heff_drop(v_e_24276);
                    heff_drop_rec(v_o_24282, 2);
                    heff_drop(v_field_24286);
                    V v_x_24287 = v_field_24285;
                    heff_drop(v_x_24287);
                    return NTAG(TAG_Nothing);
                  } else {
                    if ((v_tag_24284 == ((int64_t)1ULL))) {
                      heff_drop_cell(v_ru_24x3_24268_24At, 2);
                      heff_drop(v_op_24271);
                      heff_drop(v_e_24276);
                      heff_drop_rec(v_o_24282, 2);
                      heff_drop(v_field_24285);
                      heff_drop(v_field_24286);
                      return NTAG(TAG_Nothing);
                    } else {
                      if ((v_tag_24284 == ((int64_t)2ULL))) {
                        V v_k2_24288 = v_field_24285;
                        V v_x_24289 = v_field_24286;
                        heff_drop(v_x_24289);
                        if (heff_strEq_c(heff_get_n(v_o_24282, 1, 2), v_k2_24288)) {
                          V v_t_24296;
                          switch (heff_tag_of(v_e_24276)) {
                          case TAG_At: {
                            V v_x11_24290 = heff_field(v_e_24276, 0);
                            heff_take_n(v_e_24276, 1ULL, 2);
                            switch (heff_tag_of(v_x11_24290)) {
                            case TAG_MkEquation: {
                              V v_ps_24294 = heff_field(v_x11_24290, 2);
                              V v_body_24295 = heff_field(v_x11_24290, 3);
                              heff_take_n(v_x11_24290, 12ULL, 4);
                              v_t_24296 = ({ V a_0 = v_ps_24294; V a_1 = v_body_24295; V r_ = (g_heff_2elsp_2esplit_2ealiasedTag(a_0, a_1)); heff_drop(v_body_24295); r_; });
                              break;
                            }
                            default: heff_nomatch(v_x11_24290);
                            }
                            break;
                          }
                          default: heff_nomatch(v_e_24276);
                          }
                          switch (heff_tag_of(v_t_24296)) {
                          case TAG_Nothing: {
                            heff_drop_cell(v_ru_24x3_24268_24At, 2);
                            heff_drop(v_op_24271);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_t_24297 = heff_field(v_t_24296, 0);
                            V v_ru_24t_24296_24Just = heff_take_reuse_n(v_t_24296, 1ULL, 1);
                            return heff_tag_at_n(v_ru_24t_24296_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x3_24268_24At, TAG_MkPair, 2, (V[]){v_t_24297, v_op_24271})});
                          }
                          default: return heff_nomatch(v_t_24296);
                          }
                        } else {
                          heff_drop_cell(v_ru_24x3_24268_24At, 2);
                          heff_drop(v_op_24271);
                          heff_drop(v_e_24276);
                          return NTAG(TAG_Nothing);
                        }
                      } else {
                        heff_drop_cell(v_ru_24x3_24268_24At, 2);
                        heff_drop(v_op_24271);
                        heff_drop(v_e_24276);
                        heff_drop_rec(v_o_24282, 2);
                        heff_drop(v_field_24285);
                        heff_drop(v_field_24286);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                }
              } else {
                heff_drop(v_g_24266);
                heff_drop_cell(v_ru_24x3_24268_24At, 2);
                heff_drop(v_op_24271);
                heff_drop(v_e_24276);
                heff_drop(v_field_24281);
                return NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_g_24266);
            heff_drop_rec(v_c_24267, 14);
            heff_drop_cell(v_ru_24x3_24268_24At, 2);
            heff_drop(v_op_24271);
            heff_drop(v_e_24276);
            heff_drop(v_t_24278);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x3152_24277, 0ULL, 2);
          heff_drop(v_g_24266);
          heff_drop_rec(v_c_24267, 14);
          heff_drop_cell(v_ru_24x3_24268_24At, 2);
          heff_drop(v_op_24271);
          heff_drop(v_e_24276);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x3152_24277);
        }
      }
      default: return heff_nomatch(v_x315_24275);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x31_24269, 0ULL, 5);
      heff_drop(v_g_24266);
      heff_drop_rec(v_c_24267, 14);
      heff_drop_cell(v_ru_24x3_24268_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x31_24269, 0ULL, 4);
      heff_drop(v_g_24266);
      heff_drop_rec(v_c_24267, 14);
      heff_drop_cell(v_ru_24x3_24268_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x31_24269, 0ULL, 3);
      heff_drop(v_g_24266);
      heff_drop_rec(v_c_24267, 14);
      heff_drop_cell(v_ru_24x3_24268_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclTest: {
      heff_take_n(v_x31_24269, 0ULL, 2);
      heff_drop(v_g_24266);
      heff_drop_rec(v_c_24267, 14);
      heff_drop_cell(v_ru_24x3_24268_24At, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x31_24269, 0ULL, 1);
      heff_drop(v_g_24266);
      heff_drop_rec(v_c_24267, 14);
      heff_drop_cell(v_ru_24x3_24268_24At, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_24269);
    }
  }
  default: return heff_nomatch(v_x3_24268);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam6(V self, V *args) {
  V v_acc_24244 = args[0];
  V v_x_24245 = args[1];
  V v_c_24242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_24246 = heff_get_n(heff_get_n(v_c_24242, 5, 14), 0, 10);
  V v_g_24247 = heff_dup(v_g_24246);
  V v_c_24248 = heff_dup(v_x_24245);
  V v_t_24263 = ({ V b_0 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam7, 1, 2, (V[]){heff_dup(v_c_24248), v_g_24247}); V b_1 = heff_get_n(v_c_24248, 7, 14); V r_ = (g_list_2eany(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_24316;
  if ((heff_dup(v_t_24263) == NTAG(TAG_True))) {
    heff_drop(v_t_24263);
    V v_t_24264 = (g_heff_2elsp_2esplit_2edeclsOf(heff_dup(v_x_24245)));
    V v_t_24315 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam8, 1, 2, (V[]){v_g_24246, v_x_24245}), v_t_24264));
    v_t_24316 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24315));
  } else {
    heff_drop(v_x_24245);
    heff_drop(v_g_24246);
    heff_drop(v_t_24263);
    v_t_24316 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_24316, v_acc_24244));
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam10(V self, V *args) {
  V v_a_24328 = args[0];
  V v_ps_24321 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_ps_24321; V a_1 = v_a_24328; V r_ = (g_heff_2elsp_2esplit_2ehintOf(a_0, a_1)); heff_drop(v_ps_24321); heff_drop(v_a_24328); r_; });
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam9(V self, V *args) {
  V v_t_24323 = args[0];
  V v_ops_24317 = heff_env(self)[0];
  V v_ps_24321 = heff_env(self)[1];
  V v_taken_24320 = heff_env(self)[2];
  V v_s_24319 = heff_env(self)[3];
  V v_src_24318 = heff_env(self)[4];
  V v_name_24324 = heff_take_field(v_t_24323, 0);
  V v_args_24325 = heff_get_n(v_t_24323, 1, 2);
  heff_clo_take(self, 5);
  V v_op_24326 = ({ V a_0 = v_name_24324; V a_1 = v_ops_24317; V r_ = (g_list_2elookup_24s1507486579x90027037(a_0, a_1)); heff_drop(v_ops_24317); r_; });
  V v_t_24327 = v_name_24324;
  V v_t_24329 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam10, 1, 1, (V[]){v_ps_24321}), v_args_24325));
  V v_xs_24330 = (g_heff_2elsp_2esplit_2efreshNames(v_taken_24320, v_t_24329));
  switch (heff_tag_of(v_xs_24330)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_24319, 5);
    heff_drop(v_src_24318);
    heff_drop(v_op_24326);
    return v_t_24327;
  }
  case TAG_Cons: {
    V v_x1_24333 = v_op_24326;
    V v_t_24334 = v_t_24327;
    V v_xs_24335 = v_xs_24330;
    V v_p_24356;
    switch (heff_tag_of(v_x1_24333)) {
    case TAG_Nothing: {
      V v_t_24338;
      switch (heff_tag_of(v_xs_24335)) {
      case TAG_Nil: {
        v_t_24338 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_24336 = heff_field(v_xs_24335, 0);
        V v_xs_24337 = heff_field(v_xs_24335, 1);
        heff_take_n(v_xs_24335, 3ULL, 2);
        v_t_24338 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str5); V a_1 = v_x_24336; V a_2 = v_xs_24337; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24337); r_; });
        break;
      }
      default: heff_nomatch(v_xs_24335);
      }
      v_p_24356 = heff_strAppend(heff_strAppend(v_t_24334, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str6)), v_t_24338);
      break;
    }
    case TAG_Just: {
      V v_op_24339 = heff_field(v_x1_24333, 0);
      heff_take_n(v_x1_24333, 1ULL, 1);
      switch (heff_tag_of(v_xs_24335)) {
      case TAG_Nil: {
        heff_drop(v_op_24339);
        V v_t_24342;
        switch (heff_tag_of(v_xs_24335)) {
        case TAG_Nil: {
          v_t_24342 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_24340 = heff_field(v_xs_24335, 0);
          V v_xs_24341 = heff_field(v_xs_24335, 1);
          heff_take_n(v_xs_24335, 3ULL, 2);
          v_t_24342 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str8); V a_1 = v_x_24340; V a_2 = v_xs_24341; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24341); r_; });
          break;
        }
        default: heff_nomatch(v_xs_24335);
        }
        v_p_24356 = heff_strAppend(heff_strAppend(v_t_24334, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str9)), v_t_24342);
        break;
      }
      case TAG_Cons: {
        V v_a_24343 = heff_dup(heff_field(v_xs_24335, 0));
        V v_xs2_24344 = heff_dup(heff_field(v_xs_24335, 1));
        switch (heff_tag_of(v_xs2_24344)) {
        case TAG_Nil: {
          heff_drop(v_op_24339);
          heff_drop(v_a_24343);
          V v_t_24347;
          switch (heff_tag_of(v_xs_24335)) {
          case TAG_Nil: {
            v_t_24347 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str10);
            break;
          }
          case TAG_Cons: {
            V v_x_24345 = heff_field(v_xs_24335, 0);
            V v_xs_24346 = heff_field(v_xs_24335, 1);
            heff_take_n(v_xs_24335, 3ULL, 2);
            v_t_24347 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str11); V a_1 = v_x_24345; V a_2 = v_xs_24346; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24346); r_; });
            break;
          }
          default: heff_nomatch(v_xs_24335);
          }
          v_p_24356 = heff_strAppend(heff_strAppend(v_t_24334, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str12)), v_t_24347);
          break;
        }
        case TAG_Cons: {
          V v_b_24348 = heff_field(v_xs2_24344, 0);
          V v_xs22_24349 = heff_field(v_xs2_24344, 1);
          heff_take_n(v_xs2_24344, 3ULL, 2);
          switch (heff_tag_of(v_xs22_24349)) {
          case TAG_Nil: {
            heff_drop(v_t_24334);
            heff_drop_tag(v_xs_24335, 2);
            V v_t_24350 = heff_strAppend(heff_strAppend(v_a_24343, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str13)), v_op_24339);
            v_p_24356 = heff_strAppend(heff_strAppend(v_t_24350, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str14)), v_b_24348);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_xs22_24349, 0ULL, 2);
            heff_drop(v_op_24339);
            heff_drop(v_a_24343);
            heff_drop(v_b_24348);
            V v_t_24355;
            switch (heff_tag_of(v_xs_24335)) {
            case TAG_Nil: {
              v_t_24355 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str15);
              break;
            }
            case TAG_Cons: {
              V v_x_24353 = heff_field(v_xs_24335, 0);
              V v_xs_24354 = heff_field(v_xs_24335, 1);
              heff_take_n(v_xs_24335, 3ULL, 2);
              v_t_24355 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str16); V a_1 = v_x_24353; V a_2 = v_xs_24354; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24354); r_; });
              break;
            }
            default: heff_nomatch(v_xs_24335);
            }
            v_p_24356 = heff_strAppend(heff_strAppend(v_t_24334, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str17)), v_t_24355);
            break;
          }
          default: heff_nomatch(v_xs22_24349);
          }
          break;
        }
        default: heff_nomatch(v_xs2_24344);
        }
        break;
      }
      default: heff_nomatch(v_xs_24335);
      }
      break;
    }
    default: heff_nomatch(v_x1_24333);
    }
    V v_t_24357 = heff_get_n(heff_dup(heff_rfield(v_s_24319, 1)), 0, 2);
    if ((heff_intLt_c_lent(MK_INT(0LL), v_t_24357, 1) && ({ V v_t_24358 = heff_get_n(heff_dup(heff_rfield(v_s_24319, 1)), 0, 2); int c_ = ({ V v_t_24405 = heff_strByteAt_lent(v_src_24318, heff_intSub_lent(v_t_24358, MK_INT(1LL), 2), 2); int c_ = ((heff_peek_word(v_t_24405) == ((int64_t)40ULL)) && ({ V v_t_24359 = heff_get_n(heff_dup(heff_rfield(v_s_24319, 1)), 1, 2); int c_ = ({ V v_t_24406 = heff_strByteAt_lent(v_src_24318, v_t_24359, 0); int c_ = (heff_peek_word(v_t_24406) == ((int64_t)41ULL)); heff_drop(v_t_24406); c_; }); heff_drop(v_t_24359); c_; })); heff_drop(v_t_24405); c_; }); heff_drop(v_t_24358); c_; }))) {
      heff_drop_rec(v_s_24319, 5);
      heff_drop(v_src_24318);
      heff_drop(v_t_24357);
      return v_p_24356;
    } else {
      heff_drop_rec(v_s_24319, 5);
      heff_drop(v_src_24318);
      heff_drop(v_t_24357);
      return heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str18), v_p_24356), ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str19));
    }
  }
  default: return heff_nomatch(v_xs_24330);
  }
}
V g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam4(V self, V *args) {
  V v_x_2497 = args[0];
  V v_program_243 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_s_2468 = heff_env(self)[2];
  V v_uri_242 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  V v_x_24404;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2497)) {
  case TAG_Nothing: {
    heff_drop(v_program_243);
    heff_drop_rec(v_c_244, 14);
    heff_drop(v_s_2468);
    heff_drop(v_uri_242);
    v_x_24404 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_t_2498 = heff_field(v_x_2497, 0);
    V v_ru_24x_2497_24Just = heff_take_reuse_n(v_x_2497, 1ULL, 1);
    V v_program_2499 = v_program_243;
    V v_c_24100 = heff_dup(v_c_244);
    V v_s_24101 = v_s_2468;
    V v_ty_24102 = v_t_2498;
    V v_t_24103 = v_ty_24102;
    V v_t_24106;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24103, 0)))) {
      V v_c_24104 = heff_strByteAt_lent(v_t_24103, MK_INT(0LL), 2);
      if (((((int64_t)65ULL) <= heff_peek_word(v_c_24104)) && (heff_peek_word(v_c_24104) <= ((int64_t)90ULL)))) {
        heff_drop(v_c_24104);
        V v_x1_24105 = (g_heff_2elsp_2esplit_2earrowOutside(v_t_24103, MK_INT(0LL), MK_INT(0LL)));
        v_t_24106 = heff_bool(!(heff_dup(v_x1_24105) == NTAG(TAG_True)));
        heff_drop(v_x1_24105);
      } else {
        heff_drop(v_c_24104);
        v_t_24106 = NTAG(TAG_False);
      }
    } else {
      v_t_24106 = NTAG(TAG_False);
    }
    V v_t_24109;
    if ((heff_dup(v_t_24106) == NTAG(TAG_True))) {
      heff_drop(v_t_24106);
      V v_t_24107 = (g_heff_2elsp_2esplit_2enameEnd(v_t_24103, MK_INT(0LL)));
      v_t_24109 = heff_tag_at_n(v_ru_24x_2497_24Just, TAG_Just, 1, (V[]){heff_strSlice(v_t_24103, MK_INT(0LL), v_t_24107)});
    } else {
      heff_drop(v_t_24106);
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24103, 0)))) {
        if ((heff_unbox_word(heff_strByteAt_lent(v_t_24103, MK_INT(0LL), 2)) == ((int64_t)40ULL))) {
          V v_x1_24108 = ({ V a_0 = v_t_24103; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V r_ = (g_heff_2elsp_2esplit_2earrowOutside(a_0, a_1, a_2)); heff_drop(v_t_24103); r_; });
          if (!(heff_dup(v_x1_24108) == NTAG(TAG_True))) {
            heff_drop(v_x1_24108);
            v_t_24109 = heff_tag_at_n(v_ru_24x_2497_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str2)});
          } else {
            heff_drop_cell(v_ru_24x_2497_24Just, 1);
            heff_drop(v_x1_24108);
            v_t_24109 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24x_2497_24Just, 1);
          heff_drop(v_t_24103);
          v_t_24109 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24x_2497_24Just, 1);
        heff_drop(v_t_24103);
        v_t_24109 = NTAG(TAG_Nothing);
      }
    }
    V v_t_24374;
    switch (heff_tag_of(v_t_24109)) {
    case TAG_Nothing: {
      heff_drop(v_program_2499);
      heff_drop_rec(v_c_24100, 14);
      heff_drop_rec(v_s_24101, 5);
      v_t_24374 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_h_24110 = heff_field(v_t_24109, 0);
      V v_ru_24t_24109_24Just = heff_take_reuse_n(v_t_24109, 1ULL, 1);
      V v_program_24111 = heff_dup(v_program_2499);
      V v_c_24112 = heff_dup(v_c_24100);
      V v_x_24113 = v_h_24110;
      V v_t_24114 = heff_get_n(heff_get_n(v_c_24112, 5, 14), 0, 10);
      HeffT3 v_t_24115 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_t_24114, v_x_24113));
      {
        V v_field_24117 = v_t_24115.f[1];
        V v_field_24118 = v_t_24115.f[2];
        int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
        V v_t_24229;
        if ((v_tag_24116 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24t_24109_24Just, 1);
          heff_drop(v_program_24111);
          heff_drop(v_field_24118);
          V v_x_24119 = v_field_24117;
          heff_drop(v_x_24119);
          v_t_24229 = NTAG(TAG_Nothing);
        } else {
          if ((v_tag_24116 == ((int64_t)1ULL))) {
            heff_drop_cell(v_ru_24t_24109_24Just, 1);
            heff_drop(v_program_24111);
            heff_drop(v_field_24117);
            heff_drop(v_field_24118);
            v_t_24229 = NTAG(TAG_Nothing);
          } else {
            if ((v_tag_24116 == ((int64_t)2ULL))) {
              V v_k_24120 = v_field_24117;
              V v_x_24121 = v_field_24118;
              heff_drop(v_x_24121);
              V v_t_24128 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam5, 1, 1, (V[]){v_k_24120}), v_program_24111));
              HeffT2 v_t_24129 = ({ V a_0 = v_t_24128; HeffT2 r_ = (g_heff_2elsp_2esplit_2efirstJust_24cpr(a_0)); heff_drop(v_t_24128); r_; });
              {
                V v_field_24131 = v_t_24129.f[1];
                int64_t v_tag_24130 = ((int64_t)v_t_24129.f[0]);
                if ((v_tag_24130 == ((int64_t)0ULL))) {
                  V v_d_24132 = v_field_24131;
                  switch (heff_tag_of(v_d_24132)) {
                  case TAG_At: {
                    V v_x11_24133 = heff_field(v_d_24132, 0);
                    V v_ru_24d_24132_24At = heff_take_reuse_n(v_d_24132, 1ULL, 2);
                    switch (heff_tag_of(v_x11_24133)) {
                    case TAG_DeclEquations: {
                      heff_take_n(v_x11_24133, 0ULL, 5);
                      heff_drop_cell(v_ru_24t_24109_24Just, 1);
                      heff_drop_cell(v_ru_24d_24132_24At, 2);
                      v_t_24229 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclDefine: {
                      V v_ps_24142 = heff_field(v_x11_24133, 2);
                      V v_body_24144 = heff_field(v_x11_24133, 4);
                      heff_take_n(v_x11_24133, 20ULL, 5);
                      V v_ps_24145 = (g_list_2emap_24s1170504272x1852564147(v_ps_24142));
                      V v_x2_24146 = v_body_24144;
                      switch (heff_tag_of(v_x2_24146)) {
                      case TAG_At: {
                        V v_x21_24147 = heff_field(v_x2_24146, 0);
                        heff_take_n(v_x2_24146, 1ULL, 2);
                        switch (heff_tag_of(v_x21_24147)) {
                        case TAG_EVar: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EImplicitVar: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ENotationVar: {
                          heff_take_n(v_x21_24147, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETag: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EInt: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EFloat: {
                          heff_take_nf(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EString: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EBinary: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ERune: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWord: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EApp: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EProject: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ENamed: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EPi: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELam: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EAnn: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ESpec: {
                          heff_take_n(v_x21_24147, 0ULL, 4);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ESig: {
                          V v_fs_24176 = heff_field(v_x21_24147, 0);
                          V v_ru_24x21_24147_24ESig = heff_take_reuse_n(v_x21_24147, 1ULL, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          switch (heff_tag_of(v_fs_24176)) {
                          case TAG_Nil: {
                            heff_drop_cell(v_ru_24t_24109_24Just, 1);
                            heff_drop_cell(v_ru_24x21_24147_24ESig, 1);
                            v_t_24229 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Cons: {
                            V v_t_24179 = (g_list_2emap_24s1387309293x1990579214(v_fs_24176));
                            V v_t_24180 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24179));
                            v_t_24229 = heff_tag_at_n(v_ru_24t_24109_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_24147_24ESig, TAG_ByFields, 1, (V[]){v_t_24180})});
                            break;
                          }
                          default: heff_nomatch(v_fs_24176);
                          }
                          break;
                        }
                        case TAG_ESum: {
                          V v_vs_24181 = heff_field(v_x21_24147, 0);
                          heff_take_n(v_x21_24147, 1ULL, 1);
                          switch (heff_tag_of(v_vs_24181)) {
                          case TAG_Nil: {
                            heff_drop_cell(v_ru_24t_24109_24Just, 1);
                            heff_drop_cell(v_ru_24d_24132_24At, 2);
                            heff_drop(v_ps_24145);
                            v_t_24229 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Cons: {
                            V v_t_24184 = (g_list_2emap_24s580776739x648604941(v_vs_24181));
                            V v_t_24185 = (g_heff_2elsp_2esplit_2ecatMaybesS(v_t_24184));
                            v_t_24229 = heff_tag_at_n(v_ru_24t_24109_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24d_24132_24At, TAG_ByTags, 2, (V[]){v_ps_24145, v_t_24185})});
                            break;
                          }
                          default: heff_nomatch(v_vs_24181);
                          }
                          break;
                        }
                        case TAG_EStruct: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EUpdate: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EMatch: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELetIn: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EDo: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELocal: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EInvalid: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EAssign: {
                          heff_take_n(v_x21_24147, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWhile: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EFor: {
                          heff_take_n(v_x21_24147, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EIfThen: {
                          heff_take_n(v_x21_24147, 0ULL, 2);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EBreak: {
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EContinue: {
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EReturn: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ENest: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ELazy: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETuple: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_ETry: {
                          heff_take_n(v_x21_24147, 0ULL, 1);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWith: {
                          heff_take_n(v_x21_24147, 0ULL, 4);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_EWithBound: {
                          heff_take_n(v_x21_24147, 0ULL, 3);
                          heff_drop_cell(v_ru_24t_24109_24Just, 1);
                          heff_drop_cell(v_ru_24d_24132_24At, 2);
                          heff_drop(v_ps_24145);
                          v_t_24229 = NTAG(TAG_Nothing);
                          break;
                        }
                        default: heff_nomatch(v_x21_24147);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x2_24146);
                      }
                      break;
                    }
                    case TAG_DeclTheory: {
                      heff_take_n(v_x11_24133, 0ULL, 4);
                      heff_drop_cell(v_ru_24t_24109_24Just, 1);
                      heff_drop_cell(v_ru_24d_24132_24At, 2);
                      v_t_24229 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclPrimitive: {
                      heff_take_n(v_x11_24133, 0ULL, 3);
                      heff_drop_cell(v_ru_24t_24109_24Just, 1);
                      heff_drop_cell(v_ru_24d_24132_24At, 2);
                      v_t_24229 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclTest: {
                      heff_take_n(v_x11_24133, 0ULL, 2);
                      heff_drop_cell(v_ru_24t_24109_24Just, 1);
                      heff_drop_cell(v_ru_24d_24132_24At, 2);
                      v_t_24229 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_DeclWatch: {
                      heff_take_n(v_x11_24133, 0ULL, 1);
                      heff_drop_cell(v_ru_24t_24109_24Just, 1);
                      heff_drop_cell(v_ru_24d_24132_24At, 2);
                      v_t_24229 = NTAG(TAG_Nothing);
                      break;
                    }
                    default: heff_nomatch(v_x11_24133);
                    }
                    break;
                  }
                  default: heff_nomatch(v_d_24132);
                  }
                } else {
                  heff_drop_cell(v_ru_24t_24109_24Just, 1);
                  heff_drop(v_field_24131);
                  v_t_24229 = NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop_cell(v_ru_24t_24109_24Just, 1);
              heff_drop(v_program_24111);
              heff_drop(v_field_24117);
              heff_drop(v_field_24118);
              v_t_24229 = NTAG(TAG_Nothing);
            }
          }
        }
        switch (heff_tag_of(v_t_24229)) {
        case TAG_Nothing: {
          heff_drop(v_program_2499);
          heff_drop_rec(v_c_24100, 14);
          heff_drop_rec(v_s_24101, 5);
          v_t_24374 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_m_24230 = heff_field(v_t_24229, 0);
          V v_ru_24t_24229_24Just = heff_take_reuse_n(v_t_24229, 1ULL, 1);
          V v_t_24231 = (g_heff_2elsp_2esplit_2elineStart(heff_rfield(v_c_24100, 3), heff_dup(heff_rfield(v_s_24101, 2))));
          V v_t_24232 = heff_strSlice(heff_dup(heff_rfield(v_c_24100, 3)), v_t_24231, heff_dup(heff_rfield(v_s_24101, 2)));
          V v_sep_24233 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str3), v_t_24232);
          V v_program_24234 = v_program_2499;
          V v_c_24235 = heff_dup(v_c_24100);
          V v_s_24236 = heff_dup(v_s_24101);
          V v_taken_24237 = (g_heff_2elsp_2esplit_2ewordsIn(heff_rfield(v_c_24100, 3), heff_dup(heff_rfield(v_s_24101, 2)), heff_rfield(v_s_24101, 4), NTAG(TAG_Nil)));
          V v_x5_24238 = v_m_24230;
          V v_t_24367;
          switch (heff_tag_of(v_x5_24238)) {
          case TAG_ByTags: {
            V v_ps_24239 = heff_field(v_x5_24238, 0);
            V v_tags_24240 = heff_field(v_x5_24238, 1);
            V v_ru_24x5_24238_24ByTags = heff_take_reuse_n(v_x5_24238, 3ULL, 2);
            V v_program_24241 = v_program_24234;
            V v_c_24242 = heff_dup(v_c_24235);
            V v_t_24243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24241));
            V v_ops_24317 = ({ V b_0 = heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam6, 2, 1, (V[]){v_c_24242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24243; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_24243); r_; });
            V v_src_24318 = heff_get_n(v_c_24235, 3, 14);
            V v_s_24319 = v_s_24236;
            V v_taken_24320 = v_taken_24237;
            V v_ps_24321 = v_ps_24239;
            V v_tags_24322 = v_tags_24240;
            v_t_24367 = (g_list_2emap_24tok2(v_ru_24x5_24238_24ByTags, heff_clo_n(g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_lam9, 1, 5, (V[]){v_ops_24317, v_ps_24321, v_taken_24320, v_s_24319, v_src_24318}), v_tags_24322));
            break;
          }
          case TAG_ByFields: {
            V v_fs_24360 = heff_field(v_x5_24238, 0);
            heff_take_n(v_x5_24238, 1ULL, 1);
            heff_drop(v_program_24234);
            heff_drop_rec(v_c_24235, 14);
            heff_drop(v_s_24236);
            V v_xs_24361 = (g_heff_2elsp_2esplit_2efreshNames(v_taken_24237, heff_dup(v_fs_24360)));
            V v_x2_24362 = (g_list_2ezipWith_24s2130584539x811126895(((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str20), v_fs_24360, v_xs_24361));
            V v_t_24365;
            switch (heff_tag_of(v_x2_24362)) {
            case TAG_Nil: {
              v_t_24365 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str21);
              break;
            }
            case TAG_Cons: {
              V v_x_24363 = heff_field(v_x2_24362, 0);
              V v_xs_24364 = heff_field(v_x2_24362, 1);
              heff_take_n(v_x2_24362, 3ULL, 2);
              v_t_24365 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str22); V a_1 = v_x_24363; V a_2 = v_xs_24364; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24364); r_; });
              break;
            }
            default: heff_nomatch(v_x2_24362);
            }
            V v_t_24366 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str23), v_t_24365), ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str24));
            v_t_24367 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24366, NTAG(TAG_Nil)});
            break;
          }
          default: heff_nomatch(v_x5_24238);
          }
          V v_x2_24368 = (g_list_2emap_24s1628253759x601849359(v_c_24100, heff_dup(v_s_24101), v_t_24367));
          V v_t_24371;
          switch (heff_tag_of(v_x2_24368)) {
          case TAG_Nil: {
            heff_drop(v_sep_24233);
            v_t_24371 = ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str25);
            break;
          }
          case TAG_Cons: {
            V v_x_24369 = heff_field(v_x2_24368, 0);
            V v_xs_24370 = heff_field(v_x2_24368, 1);
            heff_take_n(v_x2_24368, 3ULL, 2);
            v_t_24371 = ({ V a_0 = v_sep_24233; V a_1 = v_x_24369; V a_2 = v_xs_24370; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_sep_24233); heff_drop(v_xs_24370); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24368);
          }
          V v_t_24372 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str26), heff_take_field(v_s_24101, 0));
          V v_t_24373 = heff_rec_n(4, shape_title__start__end__text, (V[]){heff_strAppend(v_t_24372, ((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str27)), heff_take_field(v_s_24101, 2), heff_get_n(v_s_24101, 4, 5), v_t_24371});
          v_t_24374 = heff_tag_at_n(v_ru_24t_24229_24Just, TAG_Just, 1, (V[]){v_t_24373});
          break;
        }
        default: heff_nomatch(v_t_24229);
        }
      }
      break;
    }
    default: heff_nomatch(v_t_24109);
    }
    switch (heff_tag_of(v_t_24374)) {
    case TAG_Nothing: {
      heff_drop_rec(v_c_244, 14);
      heff_drop(v_uri_242);
      v_x_24404 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_24375 = heff_field(v_t_24374, 0);
      V v_ru_24t_24374_24Just = heff_take_reuse_n(v_t_24374, 1ULL, 1);
      V v_uri_24376 = v_uri_242;
      V v_src_24377 = heff_get_n(v_c_244, 3, 14);
      V v_x_24378 = v_x_24375;
      V v_start_24379 = heff_take_field(v_x_24378, 1);
      V v_end_24380 = heff_take_field(v_x_24378, 2);
      V v_title_24381 = heff_take_field(v_x_24378, 0);
      V v_text_24382 = heff_get_n(v_x_24378, 3, 4);
      V v_t_24383 = v_start_24379;
      V v_t_24384 = v_end_24380;
      V v_t_24385 = (g_heff_2elsp_2elsp_2eposition(v_src_24377, heff_dup(v_t_24383)));
      V v_t_24386;
      if (heff_intLe_c_lent(v_t_24383, v_t_24384, 0)) {
        heff_drop(v_t_24383);
        v_t_24386 = v_t_24384;
      } else {
        heff_drop(v_t_24384);
        v_t_24386 = v_t_24383;
      }
      V v_t_24387 = ({ V a_0 = v_src_24377; V a_1 = v_t_24386; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_24377); r_; });
      V v_t_24388 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str28), heff_tag_at_n(v_ru_24t_24374_24Just, TAG_JString, 1, (V[]){v_title_24381})});
      V v_t_24389 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str29), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str30)})});
      V v_t_24390 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str31), v_t_24387}), NTAG(TAG_Nil)});
      V v_t_24391 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str32), v_t_24385}), v_t_24390});
      V v_t_24392 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str33), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24391})});
      V v_t_24393 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str34), heff_tag_n(TAG_JString, 1, (V[]){v_text_24382})});
      V v_t_24394 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24393, NTAG(TAG_Nil)});
      V v_t_24395 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24392, v_t_24394})});
      V v_t_24396 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24395, NTAG(TAG_Nil)});
      V v_t_24397 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_24376, heff_tag_n(TAG_JArray, 1, (V[]){v_t_24396})});
      V v_t_24398 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24397, NTAG(TAG_Nil)});
      V v_t_24399 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str35), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24398})});
      V v_t_24400 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24399, NTAG(TAG_Nil)});
      V v_t_24401 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esplitIn_24s584525909x991141285_str36), heff_tag_n(TAG_JObject, 1, (V[]){v_t_24400})});
      V v_t_24402 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24401, NTAG(TAG_Nil)});
      V v_t_24403 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24388, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24389, v_t_24402})});
      v_x_24404 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_24403}), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_24374);
    }
    break;
  }
  default: heff_nomatch(v_x_2497);
  }
  V f_ = v_z_247;
  args[0] = v_x_24404;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}