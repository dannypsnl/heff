// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0(V, V, V);
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374(V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1(V, V, V, V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str0, 4, "test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str1, 4, "test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str2, 77, "heff test: no src/ nor test/ here: test at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str3, 4, "test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str4, 4, "test");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str5, 3, "src");
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_entry, 3, 0};

V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0(V v_hd_240, V v_k_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_x_242)) {
  case TAG_Left: {
    V v_ru_24x_242_24Left = heff_take_reuse_n(v_x_242, 0ULL, 1);
    V v_t_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str0)));
    return (g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1(v_ru_24x_242_24Left, v_t_244, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Right: {
    V v_ru_24x_242_24Right = heff_take_reuse_n(v_x_242, 0ULL, 1);
    V v_t_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str3)));
    return (g_heff_2eutil_2efiles_2ereadDirectory_24s1646698616x859301374_24tok1(v_ru_24x_242_24Right, v_t_2427, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  default: return heff_nomatch(v_x_242);
  }
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_drop(v_x_2421);
  heff_clo_take(self, 1);
  V f_ = v_k_241;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_240, heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam2, 1, 1, (V[]){v_k_241})));
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_it_247;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    v_it_247 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_245, 0ULL, 1);
    v_it_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str1), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  switch (heff_tag_of(v_it_247)) {
  case TAG_Nil: {
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str2), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    heff_clo_take(self, 2);
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Cons: {
    V v_t_2424 = (g_list_2emap_24s1420651609x666245096(v_it_247));
    V v_t_2425 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_t_2424, NTAG(TAG_Nil)));
    heff_clo_take(self, 2);
    V f_ = v_t_2425;
    heff_room[0] = v_hd_240;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_it_247);
  }
}
V g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_2430;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Nothing: {
    v_t_2430 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2428, 0ULL, 1);
    v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str4), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2431 = (g_list_2emap_24s1420651609x666245096(v_t_2430));
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2etesting_2etestFiles_24s1570410386x1718430506_2ek_24l0_str5)});
  V v_t_2433 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2431}), NTAG(TAG_Nil)));
  heff_clo_take(self, 2);
  V f_ = v_t_2433;
  heff_room[0] = v_hd_240;
  heff_room[1] = v_k_241;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}