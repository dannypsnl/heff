// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_style 311138763
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_str1, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0(V v_k_240, V v_ps_241, V v_hd_242, V v_x_243) {
top: ;
  switch (heff_tag_of(v_x_243)) {
  case TAG_Left: {
    heff_take_n(v_x_243, 0ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_hd_242);
    return heff_tail(v_k_240, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_str0)});
  }
  case TAG_Right: {
    V v_y_245 = heff_field(v_x_243, 0);
    V v_ru_24x_243_24Right = heff_take_reuse_n(v_x_243, 1ULL, 1);
    V v_d_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
    V v_st_247 = heff_dup(heff_rfield(v_ps_241, 5));
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_247), v_d_246));
    V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_247), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_str1)));
    V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
    V v_s_2411 = ({ V a_0 = v_st_247; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2410); r_; });
    V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
    V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
    V v_a_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_lam0_clo)});
    V v_t_2416 = heff_tag_at_n(v_ru_24x_243_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2420, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_lam1, 1, 4, (V[]){v_y_245, v_ps_241, v_hd_242, v_k_240})));
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_lam0(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_2ek_24l0_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_y_245 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_240 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_ru_24x_2421_24Left = heff_take_reuse_n(v_x_2421, 0ULL, 1);
    V v_t_2423 = (g_heff_2ebuild_2ecache_2ehashGo(v_y_245, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    heff_clo_take(self, 4);
    return (g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1(v_ru_24x_2421_24Left, v_ps_241, v_y_245, v_t_2423, v_hd_242, v_k_240));
  }
  case TAG_Right: {
    V v_y_2424 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    switch (heff_tag_of(v_y_2424)) {
    case TAG_Left: {
      heff_take_n(v_y_2424, 0ULL, 1);
      V v_t_2426 = (g_heff_2ebuild_2ecache_2ehashGo(v_y_245, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
      heff_clo_take(self, 4);
      return (g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1(v_ru_24x_2421_24Right, v_ps_241, v_y_245, v_t_2426, v_hd_242, v_k_240));
    }
    case TAG_Right: {
      V v_x_2427 = heff_field(v_y_2424, 0);
      heff_take_n(v_y_2424, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_ps_241; V a_1 = v_y_245; V b_2 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_Just, 1, (V[]){v_x_2427}); V a_3 = v_hd_242; V a_4 = v_k_240; V r_ = (g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    }
    default: return heff_nomatch(v_y_2424);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}