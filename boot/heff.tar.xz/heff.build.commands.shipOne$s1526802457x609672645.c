// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Move 53768
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define LBL_root 10001833
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_str0, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_str1, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_str2, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0(V v_st_240, V v_t_241, V v_n_242, V v_x_243, V v_hd_244, V v_k_245, V v_x_246) {
top: ;
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 0, 6)));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_t_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_249); r_; });
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_str0), v_t_2410), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_str1));
  V v_why_2412 = heff_strAppend(v_t_2411, v_x_243);
  V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_str2), v_why_2412), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_str3));
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_lam0, 1, 2, (V[]){v_hd_244, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a6); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1(V v_x_240, V v_st_241, V v_home_242, V v_n_243, V v_hd_244, V v_t_245, V v_x_246, V v_x_247, V v_next_248, V v_k_249, V v_x_2410) {
top: ;
  V v_path_2411 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_240)));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_home_242)));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_243)));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_s_2415 = ({ V a_0 = v_st_241; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_to_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2415));
  V v_t_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2411; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2411); r_; });
  V v_t_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2416; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2416); r_; });
  V v_a_2420 = heff_tag_n(TAG_Move, 3, (V[]){v_t_2417, v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam0_clo)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2425, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam1, 1, 10, (V[]){v_st_241, v_home_242, v_n_243, v_t_245, v_x_240, v_x_246, v_x_247, v_next_248, v_hd_244, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_entry(V self, V *a) {
  (void)self;
  V a10 = a[10]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10); heff_drop(a10); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam0(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_next_248 = heff_env(self)[0];
  V v_hd_2432 = heff_env(self)[1];
  V v_k_2433 = heff_env(self)[2];
  heff_drop(v_x_2436);
  heff_clo_take(self, 3);
  V f_ = v_next_248;
  heff_room[0] = v_hd_2432;
  heff_room[1] = v_k_2433;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam3, 1, 3, (V[]){v_next_248, v_hd_2432, v_k_2433})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam5(V self, V *args) {
  V v_x_2447 = args[0];
  V v_next_248 = heff_env(self)[0];
  V v_hd_2443 = heff_env(self)[1];
  V v_k_2444 = heff_env(self)[2];
  heff_drop(v_x_2447);
  heff_clo_take(self, 3);
  V f_ = v_next_248;
  heff_room[0] = v_hd_2443;
  heff_room[1] = v_k_2444;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam4(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(v_hd_2443), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam5, 1, 3, (V[]){v_next_248, v_hd_2443, v_k_2444})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam7(V self, V *args) {
  V v_x_2457 = args[0];
  V v_next_248 = heff_env(self)[0];
  V v_hd_2453 = heff_env(self)[1];
  V v_k_2454 = heff_env(self)[2];
  heff_drop(v_x_2457);
  heff_clo_take(self, 3);
  V f_ = v_next_248;
  heff_room[0] = v_hd_2453;
  heff_room[1] = v_k_2454;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam6(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_x_247 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), heff_dup(v_hd_2453), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam7, 1, 3, (V[]){v_next_248, v_hd_2453, v_k_2454})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_243 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_x_240 = heff_env(self)[4];
  V v_x_246 = heff_env(self)[5];
  V v_x_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_hd_244 = heff_env(self)[8];
  V v_k_249 = heff_env(self)[9];
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    heff_clo_take(self, 10);
    V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_home_242));
    V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_243));
    V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
    V v_t_2431 = ({ V a_0 = v_st_241; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2430); r_; });
    return (g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809(v_t_245, v_x_240, v_x_246, v_t_2431, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam2, 2, 2, (V[]){v_x_247, v_next_248}), NTAG(TAG_False), v_hd_244, v_k_249));
  }
  case TAG_Right: {
    V v_y_2437 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    switch (heff_tag_of(v_y_2437)) {
    case TAG_Left: {
      heff_take_n(v_y_2437, 0ULL, 1);
      heff_clo_take(self, 10);
      V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_home_242));
      V v_t_2440 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_243));
      V v_t_2441 = (g_std_2epath_2ejoin(v_t_2439, v_t_2440));
      V v_t_2442 = ({ V a_0 = v_st_241; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2441); r_; });
      return (g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809(v_t_245, v_x_240, v_x_246, v_t_2442, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam4, 2, 2, (V[]){v_x_247, v_next_248}), NTAG(TAG_False), v_hd_244, v_k_249));
    }
    case TAG_Right: {
      heff_take_n(v_y_2437, 0ULL, 1);
      heff_clo_take(self, 10);
      V v_t_2449 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_home_242));
      V v_t_2450 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_243));
      V v_t_2451 = (g_std_2epath_2ejoin(v_t_2449, v_t_2450));
      V v_t_2452 = ({ V a_0 = v_st_241; V a_1 = v_t_2451; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2451); r_; });
      return (g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809(v_t_245, v_x_240, v_x_246, v_t_2452, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1_lam6, 2, 2, (V[]){v_x_247, v_next_248}), NTAG(TAG_True), v_hd_244, v_k_249));
    }
    default: return heff_nomatch(v_y_2437);
    }
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2(V v_x_240, V v_hd_241, V v_st_242, V v_t_243, V v_n_244, V v_k_245, V v_home_246, V v_x_247, V v_x_248, V v_next_249, V v_x_2410) {
top: ;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    V v_ru_24x_2410_24Left = heff_take_reuse_n(v_x_2410, 0ULL, 1);
    heff_drop(v_home_246);
    heff_drop(v_x_247);
    heff_drop(v_x_248);
    heff_drop(v_next_249);
    V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_240)));
    V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
    V v_a_2415 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam0_clo)});
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2410_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2420, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam1, 1, 6, (V[]){v_st_242, v_t_243, v_n_244, v_x_240, v_hd_241, v_k_245})));
  }
  case TAG_Right: {
    V v_ru_24x_2410_24Right = heff_take_reuse_n(v_x_2410, 0ULL, 1);
    V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(v_home_246)));
    V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_242), heff_dup(v_n_244)));
    V v_t_2429 = (g_std_2epath_2ejoin(v_t_2427, v_t_2428));
    V v_s_2430 = ({ V a_0 = v_st_242; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_path_2431 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2430));
    V v_to_2432 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_247)));
    V v_t_2433 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2431; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2431); r_; });
    V v_t_2434 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2432; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2432); r_; });
    V v_a_2436 = heff_tag_n(TAG_Move, 3, (V[]){v_t_2433, v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam2_clo)});
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2410_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2441, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam3, 1, 10, (V[]){v_x_240, v_st_242, v_home_246, v_n_244, v_hd_241, v_t_243, v_x_247, v_x_248, v_next_249, v_k_245})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam0(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_n_244 = heff_env(self)[2];
  V v_x_240 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_x_2422 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Left = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_st_242; V a_1 = v_t_243; V a_2 = v_n_244; V a_3 = v_x_240; V a_4 = v_hd_241; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24x_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2422}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    switch (heff_tag_of(v_y_2423)) {
    case TAG_Left: {
      V v_err_2424 = heff_field(v_y_2423, 0);
      V v_ru_24y_2423_24Left = heff_take_reuse_n(v_y_2423, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2421_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_st_242; V a_1 = v_t_243; V a_2 = v_n_244; V a_3 = v_x_240; V a_4 = v_hd_241; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24y_2423_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2424}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_y_2423, 0);
      heff_take_n(v_y_2423, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_st_242; V a_1 = v_t_243; V a_2 = v_n_244; V a_3 = v_x_240; V a_4 = v_hd_241; V a_5 = v_k_245; V b_6 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_Right, 1, (V[]){v_x_2425}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2423);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam2(V self, V *args) {
  V v_r_2435 = args[0];
  return v_r_2435;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2_lam3(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_home_246 = heff_env(self)[2];
  V v_n_244 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_x_247 = heff_env(self)[6];
  V v_x_248 = heff_env(self)[7];
  V v_next_249 = heff_env(self)[8];
  V v_k_245 = heff_env(self)[9];
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    V v_x_2443 = heff_field(v_x_2442, 0);
    V v_ru_24x_2442_24Left = heff_take_reuse_n(v_x_2442, 1ULL, 1);
    heff_clo_take(self, 10);
    return ({ V a_0 = v_x_240; V a_1 = v_st_242; V a_2 = v_home_246; V a_3 = v_n_244; V a_4 = v_hd_241; V a_5 = v_t_243; V a_6 = v_x_247; V a_7 = v_x_248; V a_8 = v_next_249; V a_9 = v_k_245; V b_10 = heff_tag_re_n(v_ru_24x_2442_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2443}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
  }
  case TAG_Right: {
    V v_y_2444 = heff_field(v_x_2442, 0);
    V v_ru_24x_2442_24Right = heff_take_reuse_n(v_x_2442, 1ULL, 1);
    switch (heff_tag_of(v_y_2444)) {
    case TAG_Left: {
      V v_err_2445 = heff_field(v_y_2444, 0);
      V v_ru_24y_2444_24Left = heff_take_reuse_n(v_y_2444, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2442_24Right, 1);
      heff_clo_take(self, 10);
      return ({ V a_0 = v_x_240; V a_1 = v_st_242; V a_2 = v_home_246; V a_3 = v_n_244; V a_4 = v_hd_241; V a_5 = v_t_243; V a_6 = v_x_247; V a_7 = v_x_248; V a_8 = v_next_249; V a_9 = v_k_245; V b_10 = heff_tag_re_n(v_ru_24y_2444_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2445}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
    }
    case TAG_Right: {
      V v_x_2446 = heff_field(v_y_2444, 0);
      heff_take_n(v_y_2444, 1ULL, 1);
      heff_clo_take(self, 10);
      return ({ V a_0 = v_x_240; V a_1 = v_st_242; V a_2 = v_home_246; V a_3 = v_n_244; V a_4 = v_hd_241; V a_5 = v_t_243; V a_6 = v_x_247; V a_7 = v_x_248; V a_8 = v_next_249; V a_9 = v_k_245; V b_10 = heff_tag_at_n(v_ru_24x_2442_24Right, TAG_Right, 1, (V[]){v_x_2446}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l1(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
    }
    default: return heff_nomatch(v_y_2444);
    }
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3(V v_st_240, V v_t_241, V v_n_242, V v_x_243, V v_hd_244, V v_k_245, V v_home_246, V v_x_247, V v_x_248, V v_next_249, V v_x_2410) {
top: ;
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_242)));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_s_2414 = ({ V a_0 = v_st_240; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2413); r_; });
  V v_path_2415 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2414));
  V v_to_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_243)));
  V v_t_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2415; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2415); r_; });
  V v_t_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2416; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2416); r_; });
  V v_a_2420 = heff_tag_n(TAG_Copy, 3, (V[]){v_t_2417, v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_lam0_clo)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2425, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_lam1, 1, 10, (V[]){v_x_243, v_hd_244, v_st_240, v_t_241, v_n_242, v_k_245, v_home_246, v_x_247, v_x_248, v_next_249})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_entry(V self, V *a) {
  (void)self;
  V a10 = a[10]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10); heff_drop(a10); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_lam0(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_home_246 = heff_env(self)[6];
  V v_x_247 = heff_env(self)[7];
  V v_x_248 = heff_env(self)[8];
  V v_next_249 = heff_env(self)[9];
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    V v_x_2427 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Left = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    heff_clo_take(self, 10);
    return (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2(v_x_243, v_hd_244, v_st_240, v_t_241, v_n_242, v_k_245, v_home_246, v_x_247, v_x_248, v_next_249, heff_tag_re_n(v_ru_24x_2426_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2427})));
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2426, 0);
    V v_ru_24x_2426_24Right = heff_take_reuse_n(v_x_2426, 1ULL, 1);
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Left: {
      V v_err_2429 = heff_field(v_y_2428, 0);
      V v_ru_24y_2428_24Left = heff_take_reuse_n(v_y_2428, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2426_24Right, 1);
      heff_clo_take(self, 10);
      return (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2(v_x_243, v_hd_244, v_st_240, v_t_241, v_n_242, v_k_245, v_home_246, v_x_247, v_x_248, v_next_249, heff_tag_re_n(v_ru_24y_2428_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2429})));
    }
    case TAG_Right: {
      V v_x_2430 = heff_field(v_y_2428, 0);
      heff_take_n(v_y_2428, 1ULL, 1);
      heff_clo_take(self, 10);
      return (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l2(v_x_243, v_hd_244, v_st_240, v_t_241, v_n_242, v_k_245, v_home_246, v_x_247, v_x_248, v_next_249, heff_tag_at_n(v_ru_24x_2426_24Right, TAG_Right, 1, (V[]){v_x_2430})));
    }
    default: return heff_nomatch(v_y_2428);
    }
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4(V v_x_240, V v_hd_241, V v_st_242, V v_t_243, V v_n_244, V v_x_245, V v_k_246, V v_home_247, V v_x_248, V v_next_249, V v_x_2410) {
top: ;
  V v_path_2411 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_240)));
  V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2411; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2411); r_; });
  V v_a_2414 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_lam0_clo)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2419, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_lam1, 1, 10, (V[]){v_st_242, v_t_243, v_n_244, v_x_245, v_hd_241, v_k_246, v_home_247, v_x_240, v_x_248, v_next_249})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_entry(V self, V *a) {
  (void)self;
  V a10 = a[10]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10); heff_drop(a10); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_lam0(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_242 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  V v_n_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_home_247 = heff_env(self)[6];
  V v_x_240 = heff_env(self)[7];
  V v_x_248 = heff_env(self)[8];
  V v_next_249 = heff_env(self)[9];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    heff_clo_take(self, 10);
    return ({ V a_0 = v_st_242; V a_1 = v_t_243; V a_2 = v_n_244; V a_3 = v_x_245; V a_4 = v_hd_241; V a_5 = v_k_246; V a_6 = v_home_247; V a_7 = v_x_240; V a_8 = v_x_248; V a_9 = v_next_249; V b_10 = heff_tag_re_n(v_ru_24x_2420_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2421}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Right = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    switch (heff_tag_of(v_y_2422)) {
    case TAG_Left: {
      V v_err_2423 = heff_field(v_y_2422, 0);
      V v_ru_24y_2422_24Left = heff_take_reuse_n(v_y_2422, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2420_24Right, 1);
      heff_clo_take(self, 10);
      return ({ V a_0 = v_st_242; V a_1 = v_t_243; V a_2 = v_n_244; V a_3 = v_x_245; V a_4 = v_hd_241; V a_5 = v_k_246; V a_6 = v_home_247; V a_7 = v_x_240; V a_8 = v_x_248; V a_9 = v_next_249; V b_10 = heff_tag_re_n(v_ru_24y_2422_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2423}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_y_2422, 0);
      heff_take_n(v_y_2422, 1ULL, 1);
      heff_clo_take(self, 10);
      return ({ V a_0 = v_st_242; V a_1 = v_t_243; V a_2 = v_n_244; V a_3 = v_x_245; V a_4 = v_hd_241; V a_5 = v_k_246; V a_6 = v_home_247; V a_7 = v_x_240; V a_8 = v_x_248; V a_9 = v_next_249; V b_10 = heff_tag_at_n(v_ru_24x_2420_24Right, TAG_Right, 1, (V[]){v_x_2424}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l3(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
    }
    default: return heff_nomatch(v_y_2422);
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}