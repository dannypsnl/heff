// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_App 13485
#define TAG_Case 4415
#define TAG_DEqn 7245
#define TAG_DSig 20444
#define TAG_DType 23752
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_EBinding 25795
#define TAG_EBindingP 13114
#define TAG_ETry 51493
#define TAG_EWithBound 48916
#define TAG_Get 18914
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkSep 6724
#define TAG_OpRhs 36076
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_arm 306390
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blockArg 80527375
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_head 9693863
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_patAtom 1586746071
#define LBL_pattern 1588251091
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_clo;
V g_heff_2esyntax_2ecst_2earmF(V, V, V);
V g_heff_2esyntax_2ecst_2earmF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earmF_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_clo;
V g_heff_2esyntax_2ecst_2ebindingF(V, V, V);
V g_heff_2esyntax_2ecst_2ebindingF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebindingF_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_clo;
V g_heff_2esyntax_2ecst_2ecatchF(V, V, V);
V g_heff_2esyntax_2ecst_2ecatchF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecatchF_clo;
V g_heff_2esyntax_2ecst_2ecloseAfter(V, V, V);
V g_heff_2esyntax_2ecst_2ecloseAfter_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecloseAfter_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edeclAt(V, V, V, V);
V g_heff_2esyntax_2ecst_2edeclAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclAt_clo;
V g_heff_2esyntax_2ecst_2edeclNameLen(V, V, V);
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo;
V g_heff_2esyntax_2ecst_2edeclStep(V);
V g_heff_2esyntax_2ecst_2edeclStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclStep_clo;
V g_heff_2esyntax_2ecst_2edefaultedF(V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eifStmtAt(V, V, V, V);
V g_heff_2esyntax_2ecst_2eifStmtAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eifStmtAt_clo;
V g_heff_2esyntax_2ecst_2elamBinderF(V, V, V);
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinderF_clo;
V g_heff_2esyntax_2ecst_2elamBinders(V, V, V, V);
V g_heff_2esyntax_2ecst_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinders_clo;
V g_heff_2esyntax_2ecst_2elambdaF(V, V, V);
V g_heff_2esyntax_2ecst_2elambdaF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elambdaF_clo;
V g_heff_2esyntax_2ecst_2elocalDecl(V, V);
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elocalDecl_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2emanyParams(V, V, V);
V g_heff_2esyntax_2ecst_2emanyParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyParams_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2enextN(V, V, V);
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enextN_clo;
V g_heff_2esyntax_2ecst_2enoDoAfter(V, V, V);
V g_heff_2esyntax_2ecst_2enoDoAfter_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enoDoAfter_clo;
V g_heff_2esyntax_2ecst_2eonceClauseF(V, V, V, V);
V g_heff_2esyntax_2ecst_2eonceClauseF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eonceClauseF_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_clo;
HeffT2 g_heff_2esyntax_2ecst_2eprogramGo_24cpr(V, V);
V g_heff_2esyntax_2ecst_2ereadH_get(void);
V g_heff_2esyntax_2ecst_2escrutineeF(V, V, V);
V g_heff_2esyntax_2ecst_2escrutineeF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2escrutineeF_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_clo;
V g_heff_2esyntax_2ecst_2esigName(V, V);
V g_heff_2esyntax_2ecst_2esigName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigName_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2etypeDecl(V, V, V);
V g_heff_2esyntax_2ecst_2etypeDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etypeDecl_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_clo;
V g_heff_2esyntax_2ecst_2ewithAsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2ewithAsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ewithAsF_clo;
V g_heff_2esyntax_2ecst_2ewithF(V, V, V);
V g_heff_2esyntax_2ecst_2ewithF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ewithF_clo;
V g_list_2eany_24s1996181941x450667621(V, V);
V g_list_2eany_24s1996181941x450667621_entry(V self, V *a);
extern Clo g_list_2eany_24s1996181941x450667621_clo;
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str2, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str5, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str6, 7, "`, not ");
V g_heff_2esyntax_2ecst_2eexpectSym_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectSym_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectSym_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectSym(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectSym_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectSym(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectSym_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_take_field(v_x_245, 1);
  V v_start_248 = heff_take_field(v_x_245, 3);
  V v_end_249 = heff_get_n(v_x_245, 4, 9);
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str0), 2) && heff_strEq_c_lent(v_text_247, v_x_240, 0))) {
    heff_clo_take(self, 3);
    heff_drop(v_x_240);
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    heff_drop(v_start_248);
    heff_drop(v_end_249);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
  } else {
    V v_span_2410 = heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249});
    V v_t_2411;
    if (heff_strEq_c(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str1))) {
      heff_drop(v_text_247);
      v_t_2411 = ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str2);
    } else {
      v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str3), v_text_247), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str4));
    }
    heff_clo_take(self, 3);
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str5), v_x_240), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str6));
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2412, v_t_2411), v_span_2410, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str1, 4, "lazy");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str2, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str3, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str4, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str5, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str6, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str7, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str9, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str10, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str11, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str12, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str13, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str14, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str15, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str16, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str17, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str18, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str19, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str20, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str21, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str22, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str23, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str24, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str25, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str26, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str27, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str28, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str29, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str30, 2, "b[");
Clo g_heff_2esyntax_2ecst_2estartsAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estartsAtom_entry, 1, 0};

V g_heff_2esyntax_2ecst_2estartsAtom(V v_t_240) {
top: ;
  V v_t_245;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str0))) {
    v_t_245 = NTAG(TAG_True);
  } else {
    V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str1), NTAG(TAG_Nil)});
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str3), v_t_241})});
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str5), v_t_242})});
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str7), v_t_243})});
    v_t_245 = ({ V a_0 = v_t_240; V a_1 = v_t_244; V r_ = (g_list_2eany_24s1996181941x450667621(a_0, a_1)); heff_drop_tag(v_t_244, 2); r_; });
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_t_245);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_245);
    V v_t_2419;
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str8))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str9))) {
        v_t_2419 = NTAG(TAG_True);
      } else {
        V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str10), NTAG(TAG_Nil)});
        V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str12), v_t_246})});
        V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str14), v_t_247})});
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str16), v_t_248})});
        V v_t_2410 = ({ V a_0 = v_t_240; V a_1 = v_t_249; V r_ = (g_list_2eany_24s565534491x447967237(a_0, a_1)); heff_drop_tag(v_t_249, 2); r_; });
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          v_t_2419 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_2410);
          HeffT2 v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str17); V a_1 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str18); V a_2 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str19); V a_3 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str20); V a_4 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str21); V a_5 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str22); V a_6 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str23); V a_7 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str24); V a_8 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str25); V a_9 = heff_rfield(v_t_240, 1); V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            v_t_2419 = heff_bool(((v_tag_2412 == ((int64_t)0ULL)) && ({ V v_x_2414 = heff_dup(v_field_2413); int c_ = 1; heff_drop(v_x_2414); c_; })));
            heff_drop(v_field_2413);
          }
        }
      }
    } else {
      v_t_2419 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop_rec(v_t_240, 9);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str26)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str27)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str28)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str29)) || heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str30)))))));
      heff_drop_rec(v_t_240, 9);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
}
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2estartsAtom(a[0]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(V v_lit_240, V v_sep_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam0, 1, 6, (V[]){heff_dup(v_sep_241), v_hd_244, v_lit_240, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sep_241 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_lit_240; V a_1 = v_sep_241; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_242}); V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_243}); V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_sep_241); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_sep_241 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2edefaultedF(heff_dup(v_lit_240), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam2, 1, 7, (V[]){v_lit_240, v_sep_241, v_items_242, v_x_249, v_seps_243, v_hd_244, v_k_245})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_241))) {
    heff_clo_take(self, 6);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam1, 1, 6, (V[]){v_lit_240, v_hd_244, v_sep_241, v_items_242, v_seps_243, v_k_245})));
  } else {
    heff_clo_take(self, 6);
    heff_drop(v_sep_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_lit_240);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, v_t_2412});
    V f_ = v_k_245;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2especToksGo_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2especToksGo_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2especToksGo_str2, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2especToksGo_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2especToksGo_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2especToksGo_str5, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2especToksGo_str6, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2especToksGo_str7, 1, "-");
V g_heff_2esyntax_2ecst_2especToksGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2especToksGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2especToksGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2especToksGo_entry, 3, 0};

V g_heff_2esyntax_2ecst_2especToksGo(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2especToksGo_lam0, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2especToksGo(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2especToksGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2especToksGo_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_get_n(v_x_245, 1, 9);
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2especToksGo_str0), 2) || (heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2especToksGo_str1), 2) || ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2especToksGo_str2), 2) && (heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2especToksGo_str3), 2) || heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2especToksGo_str4), 2))) || ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2especToksGo_str5), 2) || heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2especToksGo_str6), 2)) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2especToksGo_str7), 2)))))) {
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2especToksGo_lam1, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
  } else {
    heff_clo_take(self, 3);
    heff_drop_rec(v_hd_241, 3);
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    V v_x_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elambdaF_str0, 2, "->");
V g_heff_2esyntax_2ecst_2elambdaF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elambdaF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elambdaF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elambdaF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elambdaF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elambdaF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Lam, 4, (V[]){v_x_243, heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_x_245}), v_x_246, v_x_247});
  V f_ = v_k_242;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elambdaF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam4, 1, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elambdaF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2elambdaF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam3, 1, 6, (V[]){v_g_240, v_hd_241, v_x_243, v_x_244, v_x_245, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(heff_dup(v_g_240), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_243, v_x_244, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2enoDoAfter_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2enoDoAfter_str1, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2enoDoAfter_str2, 57, " takes its statements as a block of its own: no `do` here");
HEFF_LIT(g_heff_2esyntax_2ecst_2enoDoAfter_str3, 65, "drop this `do`: the statements go on the lines under it, indented");
V g_heff_2esyntax_2ecst_2enoDoAfter_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2enoDoAfter_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enoDoAfter_entry, 3, 0};

V g_heff_2esyntax_2ecst_2enoDoAfter(V v_what_240, V v_hd_241, V v_k_242) {
top: ;
  V v_malg_243 = heff_take_field(v_hd_241, 2);
  V v_bind_244 = heff_get_n(v_hd_241, 1, 3);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(v_bind_244), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2enoDoAfter_lam0, 1, 4, (V[]){v_what_240, v_malg_243, v_bind_244, v_k_242})});
}
V g_heff_2esyntax_2ecst_2enoDoAfter_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2enoDoAfter(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2enoDoAfter_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_what_240 = heff_env(self)[0];
  V v_malg_243 = heff_env(self)[1];
  V v_bind_244 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_kind_248 = heff_take_field(v_x_247, 0);
  V v_text_249 = heff_take_field(v_x_247, 1);
  V v_start_2410 = heff_take_field(v_x_247, 3);
  V v_end_2411 = heff_get_n(v_x_247, 4, 9);
  if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2ecst_2enoDoAfter_str0), 2) && heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2ecst_2enoDoAfter_str1), 2))) {
    heff_drop(v_kind_248);
    heff_drop(v_text_249);
    heff_clo_take(self, 4);
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_what_240, ((V)&g_heff_2esyntax_2ecst_2enoDoAfter_str2)), heff_rec_n(2, shape_start__end, (V[]){v_start_2410, v_end_2411}), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2enoDoAfter_str3)})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2413}));
    V f_ = v_bind_244;
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 4);
    heff_drop(v_what_240);
    heff_drop(v_malg_243);
    heff_drop(v_bind_244);
    heff_drop(v_kind_248);
    heff_drop(v_text_249);
    heff_drop(v_start_2410);
    heff_drop(v_end_2411);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ebindingF_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebindingF_str1, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebindingF_str2, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebindingF_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebindingF_str4, 23, "the name a `with` binds");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebindingF_str5, 2, ":=");
V g_heff_2esyntax_2ecst_2ebindingF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2ebindingF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ebindingF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ebindingF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ebindingF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ebindingF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ebindingF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ebindingF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebindingF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ebindingF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_patAtom_243 = heff_take_field(v_g_240, 7);
  V v_head_244 = heff_get_n(v_g_240, 13, 17);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2ebindingF_lam0, 1, 4, (V[]){v_patAtom_243, v_hd_241, v_head_244, v_k_242})});
}
V g_heff_2esyntax_2ecst_2ebindingF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ebindingF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ebindingF_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EBindingP, 3, (V[]){v_x_2410, v_x_2411, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebindingF_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_head_244 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_head_244;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebindingF_lam3, 1, 3, (V[]){v_k_242, v_x_2410, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebindingF_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_head_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ebindingF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ebindingF_lam2, 1, 4, (V[]){v_head_244, v_hd_241, v_k_242, v_x_2410})));
}
V g_heff_2esyntax_2ecst_2ebindingF_lam6(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EBinding, 3, (V[]){v_x_2413, v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebindingF_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_head_244 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_head_244;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebindingF_lam6, 1, 3, (V[]){v_k_242, v_x_2413, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebindingF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_head_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ebindingF_str5), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ebindingF_lam5, 1, 4, (V[]){v_head_244, v_hd_241, v_k_242, v_x_2413})));
}
V g_heff_2esyntax_2ecst_2ebindingF_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_patAtom_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_head_244 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_kind_248 = heff_take_field(v_x_247, 0);
  V v_text_249 = heff_get_n(v_x_247, 1, 9);
  if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2ecst_2ebindingF_str0), 2) && heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2ecst_2ebindingF_str1), 2))) {
    heff_drop(v_kind_248);
    heff_drop(v_text_249);
    heff_clo_take(self, 4);
    V f_ = v_patAtom_243;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebindingF_lam1, 1, 3, (V[]){v_hd_241, v_head_244, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 4);
    heff_drop(v_patAtom_243);
    heff_drop(v_kind_248);
    heff_drop(v_text_249);
    return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2ebindingF_str3), ((V)&g_heff_2esyntax_2ecst_2ebindingF_str4), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ebindingF_lam4, 1, 3, (V[]){v_hd_241, v_head_244, v_k_242})));
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str2, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str3, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str5, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str6, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str7, 2, ":=");
V g_heff_2esyntax_2ecst_2ewithF_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ewithF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ewithF_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2ewithF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam9(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ewithF_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ewithF_lam9, 1, 0};
V g_heff_2esyntax_2ecst_2ewithF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ewithF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ewithF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ewithF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2ewithF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ewithF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ewithF_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2ewithF_lam8(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_x_2423 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EWithBound, 5, (V[]){v_x_243, v_x_2421, v_x_2422, v_x_2423, v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ewithF_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eblock(heff_get_n(v_g_240, 14, 17), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam8, 1, 5, (V[]){v_k_242, v_x_243, v_x_2421, v_x_2422, v_x_2423})));
}
V g_heff_2esyntax_2ecst_2ewithF_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2ewithF_str5), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam7, 1, 6, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_2421, v_x_2422})));
}
V g_heff_2esyntax_2ecst_2ewithF_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eonceClauseF(heff_dup(v_g_240), heff_dup(v_x_243), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam6, 1, 5, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_2421})));
}
V g_heff_2esyntax_2ecst_2ewithF_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_kind_247 = heff_env(self)[0];
  V v_kind_2414 = heff_env(self)[1];
  V v_text_2415 = heff_env(self)[2];
  V v_text_248 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_hd_241 = heff_env(self)[5];
  V v_x_243 = heff_env(self)[6];
  V v_k_242 = heff_env(self)[7];
  if (((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2ewithF_str0), 2) && (heff_strEq_c_lent(v_kind_2414, ((V)&g_heff_2esyntax_2ecst_2ewithF_str1), 2) && heff_strEq_c_lent(v_text_2415, ((V)&g_heff_2esyntax_2ecst_2ewithF_str2), 2))) || (heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2ecst_2ewithF_str3), 2) && (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2ecst_2ewithF_str4), 2) && (heff_dup(v_x_2419) == NTAG(TAG_True)))))) {
    heff_drop(v_x_2419);
    heff_clo_take(self, 8);
    heff_drop(v_kind_247);
    heff_drop(v_kind_2414);
    heff_drop(v_text_2415);
    heff_drop(v_text_248);
    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2ebindingF_clo), 1, (V[]){heff_dup(v_g_240)}));
    return (g_heff_2esyntax_2ecst_2eblock(v_t_2420, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam5, 1, 4, (V[]){v_g_240, v_x_243, v_hd_241, v_k_242})));
  } else {
    heff_drop(v_x_2419);
    heff_clo_take(self, 8);
    heff_drop(v_kind_247);
    heff_drop(v_kind_2414);
    heff_drop(v_text_2415);
    heff_drop(v_text_248);
    return (g_heff_2esyntax_2ecst_2ewithAsF(v_g_240, v_x_243, v_hd_241, v_k_242));
  }
}
V g_heff_2esyntax_2ecst_2ewithF_lam9(V self, V *args) {
  V v_s_2426 = args[0];
  V v_toks_2427 = heff_take_field(v_s_2426, 0);
  V v_i_2428 = heff_get_n(v_s_2426, 1, 5);
  V v_xs_2429 = heff_dup(v_toks_2427);
  V v_i_2430 = ({ V a_0 = v_toks_2427; V a_1 = v_i_2428; V a_2 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2ecst_2ecloseAfter(a_0, a_1, a_2)); heff_drop(v_toks_2427); r_; });
  if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2430, 1) && heff_intLt_c_lent(v_i_2430, heff_arrayLength_lent(v_xs_2429, 0), 2))) {
    V v_u_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
    V v_kind_2432 = heff_take_field(v_u_2431, 0);
    V v_text_2433 = heff_get_n(v_u_2431, 1, 9);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_kind_2432, ((V)&g_heff_2esyntax_2ecst_2ewithF_str6), 2) && heff_strEq_c_lent(v_text_2433, ((V)&g_heff_2esyntax_2ecst_2ewithF_str7), 2)));
    heff_drop(v_kind_2432);
    heff_drop(v_text_2433);
    return v_ret_24bool;
  } else {
    heff_drop(v_xs_2429);
    heff_drop(v_i_2430);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2ecst_2ewithF_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_kind_247 = heff_env(self)[1];
  V v_text_248 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  V v_kind_2414 = heff_take_field(v_x_2413, 0);
  V v_text_2415 = heff_get_n(v_x_2413, 1, 9);
  V v_hd_2416 = heff_dup(v_hd_241);
  V v_malg_2417 = heff_take_field(v_hd_2416, 2);
  V v_bind_2418 = heff_get_n(v_hd_2416, 1, 3);
  heff_clo_take(self, 6);
  V v_k2_2425 = heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam4, 1, 8, (V[]){v_kind_247, v_kind_2414, v_text_2415, v_text_248, v_g_240, v_hd_241, v_x_243, v_k_242});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ewithF_lam9_clo)})});
  V v_t_2435 = heff_tr(heff_call(v_malg_2417, 1, (V[]){v_t_2434}));
  V f_ = v_bind_2418;
  heff_room[0] = v_t_2435;
  heff_room[1] = v_k2_2425;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ewithF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_kind_247 = heff_take_field(v_x_246, 0);
  V v_text_248 = heff_get_n(v_x_246, 1, 9);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ewithF_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2411}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam3, 1, 6, (V[]){v_hd_241, v_kind_247, v_text_248, v_g_240, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ewithF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str1, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str4, 2, "of");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str7, 3, "try");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str8, 5, "`try`");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str9, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str10, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str13, 31, "a `try` has a `catch` arm, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str14, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str15, 5, "catch");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str16, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str18, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str19, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str20, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str21, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str22, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str23, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str24, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str25, 4, "with");
V g_heff_2esyntax_2ecst_2earmF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2earmF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earmF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2earmF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam19(V self, V *args); static Clo g_heff_2esyntax_2ecst_2earmF_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earmF_lam19, 1, 0};
V g_heff_2esyntax_2ecst_2earmF_lam21(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam20(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam23(V self, V *args); static Clo g_heff_2esyntax_2ecst_2earmF_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earmF_lam23, 1, 0};
V g_heff_2esyntax_2ecst_2earmF_lam25(V self, V *args); static Clo g_heff_2esyntax_2ecst_2earmF_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earmF_lam25, 1, 0};
V g_heff_2esyntax_2ecst_2earmF_lam27(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam26(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam24(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam22(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam30(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam29(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam28(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2earmF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earmF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2earmF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2earmF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2earmF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2earmF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2earmF_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eifStmtAt(v_g_240, heff_get_n(v_x_2417, 5, 9), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2earmF_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_EAlt, 3, (V[]){v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2earmF_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_2418, 15, 17);
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam10, 1, 3, (V[]){v_k_2425, v_x_2426, v_x_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_g_2418 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2earmF_str5), heff_dup(v_hd_2424), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam9, 1, 4, (V[]){v_g_2418, v_hd_2424, v_k_2425, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2earmF_lam7(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_g_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_g_2418, 5));
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam8, 1, 3, (V[]){v_hd_2424, v_g_2418, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2earmF_lam11(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Case, 4, (V[]){v_x_2421, v_x_2422, v_x_2423, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2earmF_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock(heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam7, 2, 1, (V[]){v_g_2418}), v_hd_2419, heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam11, 1, 4, (V[]){v_k_2420, v_x_2421, v_x_2422, v_x_2423})));
}
V g_heff_2esyntax_2ecst_2earmF_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2419 = heff_env(self)[0];
  V v_g_2418 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2earmF_str4), heff_dup(v_hd_2419), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam6, 1, 5, (V[]){v_g_2418, v_hd_2419, v_k_2420, v_x_2421, v_x_2422})));
}
V g_heff_2esyntax_2ecst_2earmF_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2escrutineeF(heff_dup(v_g_2418), heff_dup(v_hd_2419), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam5, 1, 4, (V[]){v_hd_2419, v_g_2418, v_k_2420, v_x_2421})));
}
V g_heff_2esyntax_2ecst_2earmF_lam17(V self, V *args) {
  V v_x_2452 = args[0];
  V v_malg_2447 = heff_env(self)[0];
  V v_bind_2448 = heff_env(self)[1];
  V v_p_2449 = heff_env(self)[2];
  V v_start_2453 = heff_take_field(v_x_2452, 3);
  V v_end_2454 = heff_take_field(v_x_2452, 4);
  V v_kind_2455 = heff_take_field(v_x_2452, 0);
  V v_text_2456 = heff_get_n(v_x_2452, 1, 9);
  V v_span_2457 = heff_rec_n(2, shape_start__end, (V[]){v_start_2453, v_end_2454});
  V v_t_2458;
  if (heff_strEq_c(v_kind_2455, ((V)&g_heff_2esyntax_2ecst_2earmF_str9))) {
    heff_drop(v_text_2456);
    v_t_2458 = ((V)&g_heff_2esyntax_2ecst_2earmF_str10);
  } else {
    v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2earmF_str11), v_text_2456), ((V)&g_heff_2esyntax_2ecst_2earmF_str12));
  }
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2earmF_str13), v_t_2458), v_span_2457, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  heff_clo_take(self, 3);
  V v_t_2461 = heff_tr(heff_call(v_malg_2447, 1, (V[]){v_t_2460}));
  V f_ = v_bind_2448;
  heff_room[0] = v_t_2461;
  heff_room[1] = v_p_2449;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam16(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_x_2436 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_hd_2431 = heff_env(self)[3];
  V v_k_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_kw_2442 = v_x_2433;
  V v_ty_2443 = v_x_2436;
  V v_body_2444 = v_x_2438;
  V v_x4_2445 = v_x_2441;
  V v_p_2446 = v_hd_2431;
  V v_malg_2447 = heff_take_field(v_p_2446, 2);
  V v_bind_2448 = heff_get_n(v_p_2446, 1, 3);
  V v_p_2449 = v_k_2432;
  switch (heff_tag_of(v_x4_2445)) {
  case TAG_Nothing: {
    heff_drop(v_kw_2442);
    heff_drop(v_ty_2443);
    heff_drop(v_body_2444);
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2451 = heff_tr(heff_call(heff_dup(v_malg_2447), 1, (V[]){v_t_2450}));
    V f_ = heff_dup(v_bind_2448);
    heff_room[0] = v_t_2451;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam17, 1, 3, (V[]){v_malg_2447, v_bind_2448, v_p_2449});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_c_2462 = heff_field(v_x4_2445, 0);
    heff_take_n(v_x4_2445, 1ULL, 1);
    heff_drop(v_malg_2447);
    heff_drop(v_bind_2448);
    V f_ = v_p_2449;
    args[0] = heff_tag_n(TAG_ETry, 4, (V[]){v_kw_2442, v_ty_2443, v_body_2444, v_c_2462});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x4_2445);
  }
}
V g_heff_2esyntax_2ecst_2earmF_lam19(V self, V *args) {
  V v_s_2471 = args[0];
  V v_t_2472 = heff_get_n(v_s_2471, 3, 5);
  switch (heff_tag_of(v_t_2472)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_2473 = heff_field(v_t_2472, 0);
    heff_take_n(v_t_2472, 1ULL, 2);
    return v_x_2473;
  }
  default: return heff_nomatch(v_t_2472);
  }
}
V g_heff_2esyntax_2ecst_2earmF_lam21(V self, V *args) {
  V v_x_2478 = args[0];
  V v_k_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2463;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2478});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2earmF_lam20(V self, V *args) {
  V v_x_2477 = args[0];
  V v_kind_2467 = heff_env(self)[0];
  V v_text_2468 = heff_env(self)[1];
  V v_first_2469 = heff_env(self)[2];
  V v_col_2470 = heff_env(self)[3];
  V v_part_2439 = heff_env(self)[4];
  V v_hd_2440 = heff_env(self)[5];
  V v_k_2463 = heff_env(self)[6];
  if (((heff_strEq_c_lent(v_kind_2467, ((V)&g_heff_2esyntax_2ecst_2earmF_str14), 2) && heff_strEq_c_lent(v_text_2468, ((V)&g_heff_2esyntax_2ecst_2earmF_str15), 2)) && ((heff_dup(v_first_2469) == NTAG(TAG_True)) ? heff_intLe_c_lent(v_x_2477, v_col_2470, 0) : 1))) {
    heff_drop(v_x_2477);
    heff_clo_take(self, 7);
    heff_drop(v_kind_2467);
    heff_drop(v_text_2468);
    heff_drop(v_first_2469);
    heff_drop(v_col_2470);
    V f_ = v_part_2439;
    heff_room[0] = v_hd_2440;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam21, 1, 1, (V[]){v_k_2463});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2477);
    heff_clo_take(self, 7);
    heff_drop(v_kind_2467);
    heff_drop(v_text_2468);
    heff_drop(v_first_2469);
    heff_drop(v_col_2470);
    heff_drop(v_part_2439);
    heff_drop_rec(v_hd_2440, 3);
    V f_ = v_k_2463;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2earmF_lam18(V self, V *args) {
  V v_x_2466 = args[0];
  V v_hd_2440 = heff_env(self)[0];
  V v_part_2439 = heff_env(self)[1];
  V v_k_2463 = heff_env(self)[2];
  V v_kind_2467 = heff_take_field(v_x_2466, 0);
  V v_text_2468 = heff_take_field(v_x_2466, 1);
  V v_first_2469 = heff_take_field(v_x_2466, 6);
  V v_col_2470 = heff_get_n(v_x_2466, 5, 9);
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2earmF_lam19_clo)})});
  V v_t_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2440, 2)), 1, (V[]){v_t_2475}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_2440, 1));
  heff_room[0] = v_t_2476;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam20, 1, 7, (V[]){v_kind_2467, v_text_2468, v_first_2469, v_col_2470, v_part_2439, v_hd_2440, v_k_2463});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam15(V self, V *args) {
  V v_x_2438 = args[0];
  V v_g_2430 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2436 = heff_env(self)[3];
  V v_k_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_part_2439 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2ecatchF_clo), 1, (V[]){v_g_2430}));
  V v_hd_2440 = heff_dup(v_hd_2431);
  V v_k_2463 = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam16, 1, 5, (V[]){v_x_2433, v_x_2436, v_x_2438, v_hd_2431, v_k_2432});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2440, 2)), 1, (V[]){v_t_2464}));
  V f_ = heff_dup(heff_rfield(v_hd_2440, 1));
  heff_room[0] = v_t_2465;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam18, 1, 3, (V[]){v_hd_2440, v_part_2439, v_k_2463});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam14(V self, V *args) {
  V v_x_2437 = args[0];
  V v_g_2430 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2436 = heff_env(self)[3];
  V v_k_2432 = heff_env(self)[4];
  heff_drop(v_x_2437);
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(v_g_2430, 14)), heff_dup(v_hd_2431), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam15, 1, 5, (V[]){v_g_2430, v_hd_2431, v_x_2433, v_x_2436, v_k_2432})));
}
V g_heff_2esyntax_2ecst_2earmF_lam13(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_2431 = heff_env(self)[0];
  V v_g_2430 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2enoDoAfter(((V)&g_heff_2esyntax_2ecst_2earmF_str8), heff_dup(v_hd_2431), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam14, 1, 5, (V[]){v_g_2430, v_hd_2431, v_x_2433, v_x_2436, v_k_2432})));
}
V g_heff_2esyntax_2ecst_2earmF_lam23(V self, V *args) {
  V v_s_2485 = args[0];
  V v_t_2486 = heff_intAdd(heff_dup(heff_rfield(v_s_2485, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2485, v_t_2486));
}
V g_heff_2esyntax_2ecst_2earmF_lam25(V self, V *args) {
  V v_s_2490 = args[0];
  V v_t_2491 = heff_intAdd(heff_dup(heff_rfield(v_s_2490, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2490, v_t_2491));
}
V g_heff_2esyntax_2ecst_2earmF_lam27(V self, V *args) {
  V v_x_2497 = args[0];
  V v_k_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2479;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2497});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2earmF_lam26(V self, V *args) {
  V v_x_2494 = args[0];
  V v_kind_2483 = heff_env(self)[0];
  V v_text_2484 = heff_env(self)[1];
  V v_x_2489 = heff_env(self)[2];
  V v_g_2434 = heff_env(self)[3];
  V v_hd_2435 = heff_env(self)[4];
  V v_k_2479 = heff_env(self)[5];
  V v_kind_2495 = heff_take_field(v_x_2494, 0);
  V v_text_2496 = heff_get_n(v_x_2494, 1, 9);
  if ((heff_strEq_c_lent(v_kind_2483, ((V)&g_heff_2esyntax_2ecst_2earmF_str16), 2) && (heff_strEq_c_lent(v_text_2484, ((V)&g_heff_2esyntax_2ecst_2earmF_str17), 2) && (heff_strEq_c(heff_dup(heff_rfield(v_x_2489, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str18)) && (heff_strEq_c_lent(v_kind_2495, ((V)&g_heff_2esyntax_2ecst_2earmF_str19), 2) && heff_strEq_c_lent(v_text_2496, ((V)&g_heff_2esyntax_2ecst_2earmF_str20), 2)))))) {
    heff_clo_take(self, 6);
    heff_drop(v_kind_2483);
    heff_drop(v_text_2484);
    heff_drop_rec(v_x_2489, 9);
    heff_drop(v_kind_2495);
    heff_drop(v_text_2496);
    V f_ = heff_get_n(v_g_2434, 4, 17);
    heff_room[0] = v_hd_2435;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam27, 1, 1, (V[]){v_k_2479});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 6);
    heff_drop(v_kind_2483);
    heff_drop(v_text_2484);
    heff_drop_rec(v_x_2489, 9);
    heff_drop_rec(v_g_2434, 17);
    heff_drop_rec(v_hd_2435, 3);
    heff_drop(v_kind_2495);
    heff_drop(v_text_2496);
    V f_ = v_k_2479;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2earmF_lam24(V self, V *args) {
  V v_x_2489 = args[0];
  V v_hd_2435 = heff_env(self)[0];
  V v_kind_2483 = heff_env(self)[1];
  V v_text_2484 = heff_env(self)[2];
  V v_g_2434 = heff_env(self)[3];
  V v_k_2479 = heff_env(self)[4];
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2earmF_lam25_clo)})});
  V v_t_2493 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2435, 2)), 1, (V[]){v_t_2492}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_hd_2435, 1));
  heff_room[0] = v_t_2493;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam26, 1, 6, (V[]){v_kind_2483, v_text_2484, v_x_2489, v_g_2434, v_hd_2435, v_k_2479});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam22(V self, V *args) {
  V v_x_2482 = args[0];
  V v_hd_2435 = heff_env(self)[0];
  V v_g_2434 = heff_env(self)[1];
  V v_k_2479 = heff_env(self)[2];
  V v_kind_2483 = heff_take_field(v_x_2482, 0);
  V v_text_2484 = heff_get_n(v_x_2482, 1, 9);
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2earmF_lam23_clo)})});
  V v_t_2488 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2435, 2)), 1, (V[]){v_t_2487}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_2435, 1));
  heff_room[0] = v_t_2488;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam24, 1, 5, (V[]){v_hd_2435, v_kind_2483, v_text_2484, v_g_2434, v_k_2479});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam12(V self, V *args) {
  V v_x_2433 = args[0];
  V v_g_2430 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  V v_g_2434 = heff_dup(v_g_2430);
  V v_hd_2435 = heff_dup(v_hd_2431);
  heff_clo_take(self, 3);
  V v_k_2479 = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam13, 1, 4, (V[]){v_hd_2431, v_g_2430, v_x_2433, v_k_2432});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2435, 2)), 1, (V[]){v_t_2480}));
  V f_ = heff_dup(heff_rfield(v_hd_2435, 1));
  heff_room[0] = v_t_2481;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam22, 1, 3, (V[]){v_hd_2435, v_g_2434, v_k_2479});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam30(V self, V *args) {
  V v_x_24100 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2498 = heff_env(self)[1];
  V v_x_2499 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EAssign, 3, (V[]){v_x_2498, v_x_2499, v_x_24100});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2earmF_lam29(V self, V *args) {
  V v_x_2499 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2498 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam30, 1, 3, (V[]){v_k_242, v_x_2498, v_x_2499});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam28(V self, V *args) {
  V v_x_2498 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam29, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2498})));
}
V g_heff_2esyntax_2ecst_2earmF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_kind_246 = heff_env(self)[0];
  V v_text_247 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_kind_2413 = heff_take_field(v_x_2412, 0);
  V v_text_2414 = heff_get_n(v_x_2412, 1, 9);
  if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2earmF_str0), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2earmF_str1), 2))) {
    heff_clo_take(self, 5);
    heff_drop(v_kind_246);
    heff_drop(v_text_247);
    heff_drop(v_kind_2413);
    heff_drop(v_text_2414);
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2415}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2416;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam3, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2earmF_str2), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2earmF_str3), 2))) {
      heff_clo_take(self, 5);
      heff_drop(v_kind_246);
      heff_drop(v_text_247);
      heff_drop(v_kind_2413);
      heff_drop(v_text_2414);
      V v_g_2418 = v_g_240;
      V v_hd_2419 = v_hd_241;
      V v_k_2420 = v_k_242;
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2419), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam4, 1, 3, (V[]){v_g_2418, v_hd_2419, v_k_2420})));
    } else {
      if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2earmF_str6), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2earmF_str7), 2))) {
        heff_clo_take(self, 5);
        heff_drop(v_kind_246);
        heff_drop(v_text_247);
        heff_drop(v_kind_2413);
        heff_drop(v_text_2414);
        V v_g_2430 = v_g_240;
        V v_hd_2431 = v_hd_241;
        V v_k_2432 = v_k_242;
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2431), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam12, 1, 3, (V[]){v_g_2430, v_hd_2431, v_k_2432})));
      } else {
        if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2earmF_str21), 2) && (heff_strEq_c_lent(v_kind_2413, ((V)&g_heff_2esyntax_2ecst_2earmF_str22), 2) && heff_strEq_c_lent(v_text_2414, ((V)&g_heff_2esyntax_2ecst_2earmF_str23), 2)))) {
          heff_clo_take(self, 5);
          heff_drop(v_kind_246);
          heff_drop(v_text_247);
          heff_drop(v_kind_2413);
          heff_drop(v_text_2414);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam28, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
        } else {
          heff_drop(v_kind_2413);
          heff_drop(v_text_2414);
          if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2esyntax_2ecst_2earmF_str24), 2) && heff_strEq_c_lent(v_text_247, ((V)&g_heff_2esyntax_2ecst_2earmF_str25), 2))) {
            heff_clo_take(self, 5);
            heff_drop(v_kind_246);
            heff_drop(v_text_247);
            return (g_heff_2esyntax_2ecst_2ewithF(v_g_240, v_hd_241, v_k_242));
          } else {
            heff_clo_take(self, 5);
            heff_drop(v_kind_246);
            heff_drop(v_text_247);
            V f_ = heff_get_n(v_g_240, 0, 17);
            heff_room[0] = v_hd_241;
            heff_room[1] = v_k_242;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2earmF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_kind_246 = heff_take_field(v_x_245, 0);
  V v_text_247 = heff_get_n(v_x_245, 1, 9);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2earmF_lam1_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2410}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam2, 1, 5, (V[]){v_kind_246, v_text_247, v_hd_241, v_g_240, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_sep_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_items_241}); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_248, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2410, v_t_2411});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_entry, 8, 0};

V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_hd_247) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam0, 1, 8, (V[]){v_hd_247, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2416, v_x_2417}), NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_x_249, v_t_2418));
  V v_x_2420 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_t_2419});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_x_2420}), v_lit_245});
  return (g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2421, v_lit_246));
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 14)), v_hd_247, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam5, 1, 10, (V[]){v_x_2416, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_kind_2413 = heff_env(self)[0];
  V v_text_2414 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_245 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_lit_242 = heff_env(self)[9];
  V v_lit_243 = heff_env(self)[10];
  V v_lit_246 = heff_env(self)[11];
  if (((heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 16)) == NTAG(TAG_True)) && ((heff_strEq_c_lent(v_kind_2413, ((V)&g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_str0), 2) && heff_strEq_c_lent(v_text_2414, ((V)&g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_str1), 2)) && !(heff_dup(v_x_2415) == NTAG(TAG_True))))) {
    heff_drop(v_x_2415);
    heff_clo_take(self, 12);
    heff_drop(v_kind_2413);
    heff_drop(v_text_2414);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam4, 1, 10, (V[]){v_hd_247, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
  } else {
    heff_drop(v_x_2415);
    heff_clo_take(self, 12);
    heff_drop(v_kind_2413);
    heff_drop(v_text_2414);
    heff_drop_rec(v_hd_247, 3);
    V v_t_2424;
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nil: {
      v_t_2424 = v_x_248;
      break;
    }
    case TAG_Cons: {
      v_t_2424 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_x_249});
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_t_2424}), v_lit_245});
    return (g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2425, v_lit_246));
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  V v_kind_2413 = heff_take_field(v_x_2412, 0);
  V v_text_2414 = heff_get_n(v_x_2412, 1, 9);
  heff_clo_take(self, 10);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam3, 1, 12, (V[]){v_kind_2413, v_text_2414, v_hd_247, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_lit_244 = heff_env(self)[2];
  V v_lit_245 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_lit_243 = heff_env(self)[7];
  V v_lit_246 = heff_env(self)[8];
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2410}));
  heff_clo_take(self, 9);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam2, 1, 10, (V[]){v_hd_247, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_lit_244 = heff_env(self)[1];
  V v_lit_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_lit_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam1, 1, 9, (V[]){v_hd_247, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str1, 18, "the name of a type");
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str2, 1, "=");
V g_heff_2esyntax_2ecst_2etypeDecl_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etypeDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etypeDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etypeDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_248 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_248, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2etypeDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etypeDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DType, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam4, 1, 5, (V[]){v_k_241, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2etypeDecl_str2), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2etypeDecl_str0), ((V)&g_heff_2esyntax_2ecst_2etypeDecl_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str0, 33, "a declaration cannot start with `");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str3, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str4, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str7, 5, "where");
V g_heff_2esyntax_2ecst_2esigOrEqn_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_entry, 4, 0};

V g_heff_2esyntax_2ecst_2esigOrEqn(V v_item_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam1, 1, 4, (V[]){v_hd_242, v_t_241, v_k_243, v_item_240})});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esigOrEqn(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_t_245 = heff_intAdd(heff_dup(heff_rfield(v_s_244, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_244, v_t_245));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam4(V self, V *args) {
  V v_s_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_intAdd(heff_dup(heff_rfield(v_s_2421, 1)), v_k_2420);
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2421, v_t_2422));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam9(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_t_2433;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkSep: {
    V v_names_2431 = heff_field(v_x_2428, 0);
    V v_commas_2432 = heff_field(v_x_2428, 1);
    heff_take_n(v_x_2428, 3ULL, 2);
    v_t_2433 = heff_tag_n(TAG_DSig, 4, (V[]){v_names_2431, v_commas_2432, v_x_2429, v_x_2430});
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V f_ = v_k_243;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_242, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam9, 1, 3, (V[]){v_x_2428, v_x_2429, v_k_243})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam8, 1, 3, (V[]){v_hd_242, v_x_2428, v_k_243})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2426, NTAG(TAG_Nil)});
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2esepGo_24s1439271434x1995380706(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str4), v_t_2427, NTAG(TAG_Nil), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam7, 1, 2, (V[]){v_hd_242, v_k_243})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam16(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_x_2435 = heff_env(self)[2];
  V v_x_2436 = heff_env(self)[3];
  V v_x_2437 = heff_env(self)[4];
  V v_x_2438 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_x_2445})});
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_DEqn, 5, (V[]){v_x_2435, v_x_2436, v_x_2437, v_x_2438, v_t_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam15(V self, V *args) {
  V v_x_2444 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  V v_x_2437 = heff_env(self)[5];
  V v_x_2438 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eblock(v_item_240, v_hd_242, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam16, 1, 6, (V[]){v_x_2444, v_k_243, v_x_2435, v_x_2436, v_x_2437, v_x_2438})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam14(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  V v_x_2437 = heff_env(self)[5];
  V v_x_2438 = heff_env(self)[6];
  V v_kind_2442 = heff_take_field(v_x_2441, 0);
  V v_text_2443 = heff_get_n(v_x_2441, 1, 9);
  if ((heff_strEq_c_lent(v_kind_2442, ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str6), 2) && heff_strEq_c_lent(v_text_2443, ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str7), 2))) {
    heff_drop(v_kind_2442);
    heff_drop(v_text_2443);
    heff_clo_take(self, 7);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam15, 1, 7, (V[]){v_item_240, v_hd_242, v_k_243, v_x_2435, v_x_2436, v_x_2437, v_x_2438})));
  } else {
    heff_clo_take(self, 7);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_item_240);
    heff_drop(v_kind_2442);
    heff_drop(v_text_2443);
    V v_t_2447 = heff_tag_n(TAG_DEqn, 5, (V[]){v_x_2435, v_x_2436, v_x_2437, v_x_2438, NTAG(TAG_Nothing)});
    V f_ = v_k_243;
    args[0] = v_t_2447;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam13(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  V v_x_2437 = heff_env(self)[5];
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2439}));
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2440;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam14, 1, 7, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2435, v_x_2436, v_x_2437, v_x_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam12(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam13, 1, 6, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2435, v_x_2436, v_x_2437})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam11(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str5), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam12, 1, 5, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2435, v_x_2436})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam10(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 7)), NTAG(TAG_Nil), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam11, 1, 4, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2435})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_item_240 = heff_env(self)[5];
  if ((heff_strEq_c(heff_dup(heff_rfield(v_x_2425, 1)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_x_2425, 1)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str3)))) {
    heff_drop_rec(v_x_2425, 9);
    heff_clo_take(self, 6);
    heff_drop_rec(v_t_241, 9);
    heff_drop(v_x_248);
    heff_drop(v_x_2413);
    heff_drop(v_item_240);
    return (g_heff_2esyntax_2ecst_2esigName(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam6, 1, 2, (V[]){v_hd_242, v_k_243})));
  } else {
    heff_drop_rec(v_x_2425, 9);
    heff_clo_take(self, 6);
    V v_t_2434 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_241, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2434, heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam10, 1, 3, (V[]){v_hd_242, v_item_240, v_k_243})));
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_item_240 = heff_env(self)[4];
  V v_t_2414 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_241), heff_dup(v_x_248), heff_dup(v_x_2413)));
  if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
    heff_drop(v_x_2413);
    heff_clo_take(self, 5);
    heff_drop(v_x_248);
    heff_drop(v_item_240);
    V v_span_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_take_field(v_t_241, 4)});
    V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str0), heff_get_n(v_t_241, 1, 9));
    V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str1)), v_span_2415, NTAG(TAG_Nothing)});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2418}));
    V f_ = heff_get_n(v_hd_242, 1, 3);
    heff_room[0] = v_t_2419;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_k_2420 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_241), heff_dup(v_x_248), heff_dup(v_x_2413)));
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam4, 1, 1, (V[]){v_k_2420})})});
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2423}));
    heff_clo_take(self, 5);
    V f_ = heff_dup(heff_rfield(v_hd_242, 1));
    heff_room[0] = v_t_2424;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam5, 1, 6, (V[]){v_hd_242, v_k_243, v_t_241, v_x_248, v_x_2413, v_item_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam3, 1, 5, (V[]){v_t_241, v_x_248, v_hd_242, v_k_243, v_item_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str2, 5, "where");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str4, 4, "once");
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_x_245 = heff_dup(heff_rfield(v_s_244, 1));
  V v_top_246 = heff_take_field(v_s_244, 2);
  V v_stack_247 = heff_take_field(v_s_244, 3);
  return ({ V rv_2 = v_top_246; V rv_3 = v_stack_247; V rv_4 = v_x_245; V rr_ = heff_rec_reuse_nf(v_s_244, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_kind_2418 = heff_take_field(v_x_2417, 0);
  V v_first_2419 = heff_take_field(v_x_2417, 6);
  V v_col_2420 = heff_take_field(v_x_2417, 5);
  V v_text_2421 = heff_get_n(v_x_2417, 1, 9);
  if ((heff_strEq_c_lent(v_kind_2418, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str0), 2) ? 0 : ((heff_dup(v_first_2419) == NTAG(TAG_True)) && (heff_intEq_c_lent(v_col_2420, v_col_240, 0) && ((heff_strEq_c_lent(v_kind_2418, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str1), 2) && heff_strEq_c_lent(v_text_2421, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str2), 2)) ? 0 : (heff_strEq_c_lent(v_kind_2418, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str3), 2) ? !heff_strEq_c_lent(v_text_2421, ((V)&g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_str4), 2) : 1)))))) {
    heff_drop(v_kind_2418);
    heff_drop(v_first_2419);
    heff_drop(v_col_2420);
    heff_drop(v_text_2421);
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(v_col_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_acc_241}), v_hd_242, v_k_243));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_col_240);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_kind_2418);
    heff_drop(v_first_2419);
    heff_drop(v_col_2420);
    heff_drop(v_text_2421);
    V v_x_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2415}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4, 1, 5, (V[]){v_col_240, v_x_2414, v_acc_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_drop(v_x_2413);
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elocalDecl(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edeclStep_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edeclStep_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclStep_lam0, 2, 0};
Clo g_heff_2esyntax_2ecst_2edeclStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclStep_entry, 1, 0};

V g_heff_2esyntax_2ecst_2edeclStep(V v_s_240) {
top: ;
  V v_top_241 = heff_dup(heff_rfield(v_s_240, 1));
  V v_start_242 = heff_dup(heff_rfield(v_s_240, 1));
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_st_244 = ({ V rv_2 = v_top_241; V rv_3 = v_t_243; V rv_4 = v_start_242; V rr_ = heff_rec_reuse_nf(v_s_240, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_t_245 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_st_244), heff_dup(heff_rfield(v_st_244, 1))));
  return (g_heff_2esyntax_2ecst_2edeclAt(v_t_245, heff_dup(g_heff_2esyntax_2ecst_2ereadH_get()), ((V)&g_heff_2esyntax_2ecst_2edeclStep_lam0_clo), v_st_244));
}
V g_heff_2esyntax_2ecst_2edeclStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclStep(a[0]);
}
V g_heff_2esyntax_2ecst_2edeclStep_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_247 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_246}), v_st_247});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str1, 35, "the file does not parse (at offset ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str2, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str4, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str7, 35, "the file does not parse (at offset ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str8, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str9, 1, ")");

HeffT2 g_heff_2esyntax_2ecst_2eprogramGo_24cpr(V v_s_240, V v_acc_241) {
top: ;
  V v_top_242 = heff_dup(heff_rfield(v_s_240, 1));
  V v_start_243 = heff_dup(heff_rfield(v_s_240, 1));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_245 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), v_top_242, v_t_244, v_start_243});
  V v_t_246 = (g_heff_2esyntax_2ecst_2etokAt(v_t_245, heff_dup(heff_rfield(v_s_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_246, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str0))) {
    heff_drop_rec(v_s_240, 5);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_247}});
  } else {
    V v_it_248 = heff_tr(g_heff_2esyntax_2ecst_2edeclStep(v_s_240));
    switch (heff_tag_of(v_it_248)) {
    case TAG_MkPair: {
      V v_it1_249 = heff_field(v_it_248, 0);
      V v_s2_2410 = heff_field(v_it_248, 1);
      V v_ru_24it_248_24MkPair = heff_take_reuse_n(v_it_248, 3ULL, 2);
      switch (heff_tag_of(v_it1_249)) {
      case TAG_Left: {
        V v_d_2411 = heff_field(v_it1_249, 0);
        heff_take_n(v_it1_249, 1ULL, 1);
        heff_drop(v_acc_241);
        heff_drop_rec(v_s2_2410, 5);
        heff_drop_cell(v_ru_24it_248_24MkPair, 2);
        V v_span_2412 = heff_take_field(v_d_2411, 3);
        V v_msg_2413 = heff_get_n(v_d_2411, 2, 5);
        V v_t_2414 = heff_intShow(heff_get_n(v_span_2412, 0, 2));
        V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str1), v_t_2414), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str2));
        V v_f_2416 = heff_strAppend(heff_strAppend(v_t_2415, v_msg_2413), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str3));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
      }
      case TAG_Right: {
        V v_d_2417 = heff_field(v_it1_249, 0);
        heff_take_n(v_it1_249, 1ULL, 1);
        V v_t_2418 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2410), heff_dup(heff_rfield(v_s2_2410, 1))));
        if (heff_strEq_c(heff_get_n(v_t_2418, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str4))) {
          V t_0 = v_s2_2410;
          V t_1 = heff_tag_at_n(v_ru_24it_248_24MkPair, TAG_Cons, 2, (V[]){v_d_2417, v_acc_241});
          v_s_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop_cell(v_ru_24it_248_24MkPair, 2);
          heff_drop(v_d_2417);
          V v_t_2419 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2410), heff_dup(heff_rfield(v_s2_2410, 1))));
          V v_t_2420 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2410), heff_get_n(v_s2_2410, 1, 5)));
          V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str5), heff_get_n(v_t_2420, 1, 9));
          V v_msg_2422 = heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str6));
          V v_t_2423 = heff_intShow(heff_get_n(v_t_2419, 3, 9));
          V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str7), v_t_2423), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str8));
          V v_f_2425 = heff_strAppend(heff_strAppend(v_t_2424, v_msg_2422), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str9));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it_248)}});
    }
  }
}