// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrowDown 21357
#define TAG_ArrowLeft 52976
#define TAG_ArrowRight 29566
#define TAG_ArrowUp 57900
#define TAG_BackTab 60780
#define TAG_Backspace 1027
#define TAG_Bold 53386
#define TAG_Char 10597
#define TAG_Continue 52606
#define TAG_Control 37853
#define TAG_Delete 50238
#define TAG_Dim 16148
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Enter 13030
#define TAG_Escape 55216
#define TAG_Home 35586
#define TAG_Inverse 25398
#define TAG_PageDown 11812
#define TAG_PageUp 3752
#define TAG_Plain 3036
#define TAG_Sequence 46672
#define TAG_Tab 31265
#define TAG_Underline 15894
#define LBL_at 9882
#define LBL_options 1129866465
#define LBL_style 311138763
#define LBL_text 10052084
static uint32_t shape_at[] = {LBL_at};
static uint32_t shape_options__at[] = {LBL_options, LBL_at};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eterminal_2ewidget_2ebold(V);
V g_std_2eterminal_2ewidget_2ebold_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ebold_clo;
V g_std_2eterminal_2ewidget_2echoiceKey(V, V);
V g_std_2eterminal_2ewidget_2echoiceKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2echoiceKey_clo;
V g_std_2eterminal_2ewidget_2ecolumns(V);
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecolumns_clo;
V g_std_2eterminal_2ewidget_2econtrolEdit(V, V);
V g_std_2eterminal_2ewidget_2econtrolEdit_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2econtrolEdit_clo;
V g_std_2eterminal_2ewidget_2econtrolMove(V, V, V);
V g_std_2eterminal_2ewidget_2econtrolMove_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2econtrolMove_clo;
V g_std_2eterminal_2ewidget_2ecsiEnd(V, V);
V g_std_2eterminal_2ewidget_2ecsiEnd_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecsiEnd_clo;
V g_std_2eterminal_2ewidget_2ecutRunes(V, V);
V g_std_2eterminal_2ewidget_2ecutRunes_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecutRunes_clo;
V g_std_2eterminal_2ewidget_2ecutRunes_24dps(V, V, V);
V g_std_2eterminal_2ewidget_2ecutRunes_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ecutRunes_24dps_clo;
V g_std_2eterminal_2ewidget_2efieldKey(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_clo;
V g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(V, V);
V g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_clo;
V g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_get(void);
V g_std_2eterminal_2ewidget_2efinalKey(V, V, V);
V g_std_2eterminal_2ewidget_2efinalKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2efinalKey_clo;
V g_std_2eterminal_2ewidget_2einverse(V);
V g_std_2eterminal_2ewidget_2einverse_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2einverse_clo;
V g_std_2eterminal_2ewidget_2emenu_get(void);
V g_std_2eterminal_2ewidget_2emenuKey(V, V, V);
V g_std_2eterminal_2ewidget_2emenuKey_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2emenuKey_clo;
V g_std_2eterminal_2ewidget_2epad(V, V);
V g_std_2eterminal_2ewidget_2epad_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epad_clo;
V g_std_2eterminal_2ewidget_2epaintSpans(V, V);
V g_std_2eterminal_2ewidget_2epaintSpans_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epaintSpans_clo;
V g_std_2eterminal_2ewidget_2epaintSpans_24acc(V, V, V);
V g_std_2eterminal_2ewidget_2epaintSpans_24acc_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2epaintSpans_24acc_clo;
HeffT2 g_std_2eterminal_2ewidget_2estepAll_24cpr(V, V, V);
V g_std_2eterminal_2ewidget_2ewordStart(V, V);
V g_std_2eterminal_2ewidget_2ewordStart_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewordStart_clo;
V g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240(V, V);
V g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240_clo;
Clo g_std_2eterminal_2ewidget_2ecsiEnd_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecsiEnd_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ecsiEnd(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_j_241, 1)) {
    heff_drop(v_j_241);
    return MK_INT(-1LL);
  } else {
    if (((((int64_t)64ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) <= ((int64_t)126ULL)))) {
      return v_j_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_j_241 = t_1;
      goto top;
    }
  }
}
V g_std_2eterminal_2ewidget_2ecsiEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ecsiEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2eterminal_2ewidget_2efinalKey_str0, 1, ";");
HEFF_LIT(g_std_2eterminal_2ewidget_2efinalKey_str1, 1, ";");
Clo g_std_2eterminal_2ewidget_2efinalKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2efinalKey_entry, 3, 0};

V g_std_2eterminal_2ewidget_2efinalKey(V v_seq_240, V v_params_241, V v_box_24b_242) {
  int64_t v_b_242 = heff_unbox_word(v_box_24b_242);
top: ;
  if ((v_b_242 == ((int64_t)65ULL))) {
    heff_drop(v_seq_240);
    return NTAG(TAG_ArrowUp);
  } else {
    if ((v_b_242 == ((int64_t)66ULL))) {
      heff_drop(v_seq_240);
      return NTAG(TAG_ArrowDown);
    } else {
      if ((v_b_242 == ((int64_t)67ULL))) {
        heff_drop(v_seq_240);
        return NTAG(TAG_ArrowRight);
      } else {
        if ((v_b_242 == ((int64_t)68ULL))) {
          heff_drop(v_seq_240);
          return NTAG(TAG_ArrowLeft);
        } else {
          if ((v_b_242 == ((int64_t)72ULL))) {
            heff_drop(v_seq_240);
            return NTAG(TAG_Home);
          } else {
            if ((v_b_242 == ((int64_t)70ULL))) {
              heff_drop(v_seq_240);
              return NTAG(TAG_End);
            } else {
              if ((v_b_242 == ((int64_t)90ULL))) {
                heff_drop(v_seq_240);
                return NTAG(TAG_BackTab);
              } else {
                if ((v_b_242 == ((int64_t)126ULL))) {
                  V v_seq_243 = v_seq_240;
                  V v_x1_244 = (g_prelude_2esplit_2esplitFrom_240(v_params_241, ((V)&g_std_2eterminal_2ewidget_2efinalKey_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_std_2eterminal_2ewidget_2efinalKey_str1), v_params_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
                  V v_n_2411;
                  switch (heff_tag_of(v_x1_244)) {
                  case TAG_Nil: {
                    v_n_2411 = MK_INT(0LL);
                    break;
                  }
                  case TAG_Cons: {
                    V v_x_245 = heff_field(v_x1_244, 0);
                    heff_take_n(v_x1_244, 1ULL, 2);
                    HeffT2 v_t_247 = ({ V a_0 = v_x_245; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_x_245); r_; });
                    {
                      V v_field_249 = v_t_247.f[1];
                      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
                      if ((v_tag_248 == ((int64_t)0ULL))) {
                        V v_x_2410 = v_field_249;
                        v_n_2411 = v_x_2410;
                      } else {
                        heff_drop(v_field_249);
                        v_n_2411 = MK_INT(0LL);
                      }
                    }
                    break;
                  }
                  default: heff_nomatch(v_x1_244);
                  }
                  if (heff_intEq_c_lent(v_n_2411, MK_INT(1LL), 2)) {
                    heff_drop(v_seq_243);
                    heff_drop(v_n_2411);
                    return NTAG(TAG_Home);
                  } else {
                    if (heff_intEq_c_lent(v_n_2411, MK_INT(7LL), 2)) {
                      heff_drop(v_seq_243);
                      heff_drop(v_n_2411);
                      return NTAG(TAG_Home);
                    } else {
                      if (heff_intEq_c_lent(v_n_2411, MK_INT(4LL), 2)) {
                        heff_drop(v_seq_243);
                        heff_drop(v_n_2411);
                        return NTAG(TAG_End);
                      } else {
                        if (heff_intEq_c_lent(v_n_2411, MK_INT(8LL), 2)) {
                          heff_drop(v_seq_243);
                          heff_drop(v_n_2411);
                          return NTAG(TAG_End);
                        } else {
                          if (heff_intEq_c_lent(v_n_2411, MK_INT(3LL), 2)) {
                            heff_drop(v_seq_243);
                            heff_drop(v_n_2411);
                            return NTAG(TAG_Delete);
                          } else {
                            if (heff_intEq_c_lent(v_n_2411, MK_INT(5LL), 2)) {
                              heff_drop(v_seq_243);
                              heff_drop(v_n_2411);
                              return NTAG(TAG_PageUp);
                            } else {
                              if (heff_intEq_c(v_n_2411, MK_INT(6LL))) {
                                heff_drop(v_seq_243);
                                return NTAG(TAG_PageDown);
                              } else {
                                return heff_tag_n(TAG_Sequence, 1, (V[]){v_seq_243});
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  return heff_tag_n(TAG_Sequence, 1, (V[]){v_seq_240});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2efinalKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2efinalKey(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2eterminal_2ewidget_2ecolumns_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecolumns_entry, 1, 0};

V g_std_2eterminal_2ewidget_2ecolumns(V v_c_240) {
top: ;
  if (((heff_runeLe_c(MK_INT(4352LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(4447LL))) || ((heff_runeLe_c(MK_INT(11904LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(42191LL))) || ((heff_runeLe_c(MK_INT(44032LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(55203LL))) || ((heff_runeLe_c(MK_INT(63744LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(64255LL))) || ((heff_runeLe_c(MK_INT(65072LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(65103LL))) || ((heff_runeLe_c(MK_INT(65280LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(65376LL))) || ((heff_runeLe_c(MK_INT(65504LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(65510LL))) || ((heff_runeLe_c(MK_INT(127744LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(128591LL))) || ((heff_runeLe_c(MK_INT(129280LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(129535LL))) || (heff_runeLe_c(MK_INT(131072LL), heff_dup(v_c_240)) && heff_runeLe_c(heff_dup(v_c_240), MK_INT(262141LL))))))))))))) {
    heff_drop(v_c_240);
    return MK_INT(2LL);
  } else {
    heff_drop(v_c_240);
    return MK_INT(1LL);
  }
}
V g_std_2eterminal_2ewidget_2ecolumns_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ecolumns(a[0]);
}
Clo g_std_2eterminal_2ewidget_2ecutRunes_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecutRunes_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ecutRunes(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_cs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_c_242)));
    if (heff_intLt_c_lent(v_w_240, v_x_244, 2)) {
      heff_drop(v_w_240);
      heff_drop(v_c_242);
      heff_drop(v_cs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_245 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_c_242)));
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_c_242, heff_hole()});
      V v_u_247 = (g_std_2eterminal_2ewidget_2ecutRunes_24dps(heff_intSub(v_w_240, v_t_245), v_cs_243, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eterminal_2ewidget_2ecutRunes_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ecutRunes(a[0], a[1]);
}
Clo g_std_2eterminal_2ewidget_2ecutRunes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ecutRunes_24dps_entry, 3, 0};

V g_std_2eterminal_2ewidget_2ecutRunes_24dps(V v_w_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_cs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_c_243)));
    if (heff_intLt_c_lent(v_w_240, v_x_245, 2)) {
      heff_drop(v_w_240);
      heff_drop(v_c_243);
      heff_drop(v_cs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_246 = (g_std_2eterminal_2ewidget_2ecolumns(heff_dup(v_c_243)));
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_c_243, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = heff_intSub(v_w_240, v_t_246);
      V t_1 = v_cs_244;
      V t_2 = v_u_248;
      v_w_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eterminal_2ewidget_2ecutRunes_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2eterminal_2ewidget_2ecutRunes_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_std_2eterminal_2ewidget_2epad_str0, 1, " ");
HEFF_LIT(g_std_2eterminal_2ewidget_2epad_str1, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2epad_str2, 0, "");
Clo g_std_2eterminal_2ewidget_2epad_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2epad_entry, 2, 0};

V g_std_2eterminal_2ewidget_2epad(V v_w_240, V v_s_241) {
top: ;
  V v_t_242 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), heff_strRunes(heff_dup(v_s_241))));
  V v_t_243 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), heff_strRunes(v_s_241)));
  V v_s_244 = heff_strOfRunes(v_t_243);
  V v_t_245 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(v_s_244); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x2_246 = (g_list_2ereplicate(heff_intSub(v_w_240, v_t_245), ((V)&g_std_2eterminal_2ewidget_2epad_str0)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_std_2eterminal_2ewidget_2epad_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_std_2eterminal_2ewidget_2epad_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  return heff_strAppend(heff_strOfRunes(v_t_242), v_t_249);
}
V g_std_2eterminal_2ewidget_2epad_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2epad(a[0], a[1]);
}
Clo g_std_2eterminal_2ewidget_2ebold_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ebold_entry, 1, 0};

V g_std_2eterminal_2ewidget_2ebold(V v_s_240) {
top: ;
  return heff_rec_n(2, shape_text__style, (V[]){v_s_240, NTAG(TAG_Bold)});
}
V g_std_2eterminal_2ewidget_2ebold_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2ebold(a[0]);
}
Clo g_std_2eterminal_2ewidget_2einverse_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2einverse_entry, 1, 0};

V g_std_2eterminal_2ewidget_2einverse(V v_s_240) {
top: ;
  return heff_rec_n(2, shape_text__style, (V[]){v_s_240, NTAG(TAG_Inverse)});
}
V g_std_2eterminal_2ewidget_2einverse_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2einverse(a[0]);
}
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str1, 4, "\033[0m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str2, 6, "\033[0;1m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str3, 6, "\033[0;2m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str4, 6, "\033[0;7m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_str5, 6, "\033[0;4m");
Clo g_std_2eterminal_2ewidget_2epaintSpans_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2epaintSpans_entry, 2, 0};

V g_std_2eterminal_2ewidget_2epaintSpans(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    return ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str0);
  }
  case TAG_Cons: {
    V v_sp_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_style_244 = heff_dup(heff_rfield(v_sp_242, 1));
    V v_text_245 = heff_dup(heff_rfield(v_sp_242, 0));
    V v_t_246 = v_style_244;
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Plain: {
      v_t_247 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str1);
      break;
    }
    case TAG_Bold: {
      v_t_247 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str2);
      break;
    }
    case TAG_Dim: {
      v_t_247 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str3);
      break;
    }
    case TAG_Inverse: {
      v_t_247 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str4);
      break;
    }
    case TAG_Underline: {
      v_t_247 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_str5);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_248 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), heff_strRunes(heff_dup(v_text_245))));
    V v_t_249 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), heff_strRunes(v_text_245)));
    V v_s_2410 = heff_strOfRunes(v_t_249);
    V v_t_2411 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(v_s_2410); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
    V v_s_2412 = heff_strAppend(v_t_247, heff_strOfRunes(v_t_248));
    return (g_std_2eterminal_2ewidget_2epaintSpans_24acc(heff_intSub(v_w_240, v_t_2411), v_rest_243, v_s_2412));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eterminal_2ewidget_2epaintSpans_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2epaintSpans(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str1, 4, "\033[0m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str2, 6, "\033[0;1m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str3, 6, "\033[0;2m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str4, 6, "\033[0;7m");
HEFF_LIT(g_std_2eterminal_2ewidget_2epaintSpans_24acc_str5, 6, "\033[0;4m");
Clo g_std_2eterminal_2ewidget_2epaintSpans_24acc_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2epaintSpans_24acc_entry, 3, 0};

V g_std_2eterminal_2ewidget_2epaintSpans_24acc(V v_w_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    return heff_strAppend(v_acc_242, ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str0));
  }
  case TAG_Cons: {
    V v_sp_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_style_245 = heff_dup(heff_rfield(v_sp_243, 1));
    V v_text_246 = heff_dup(heff_rfield(v_sp_243, 0));
    V v_t_247 = v_style_245;
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Plain: {
      v_t_248 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str1);
      break;
    }
    case TAG_Bold: {
      v_t_248 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str2);
      break;
    }
    case TAG_Dim: {
      v_t_248 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str3);
      break;
    }
    case TAG_Inverse: {
      v_t_248 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str4);
      break;
    }
    case TAG_Underline: {
      v_t_248 = ((V)&g_std_2eterminal_2ewidget_2epaintSpans_24acc_str5);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), heff_strRunes(heff_dup(v_text_246))));
    V v_t_2410 = (g_std_2eterminal_2ewidget_2ecutRunes(heff_dup(v_w_240), heff_strRunes(v_text_246)));
    V v_s_2411 = heff_strOfRunes(v_t_2410);
    V v_t_2412 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(v_s_2411); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
    V v_s_2413 = heff_strAppend(heff_strAppend(v_acc_242, v_t_248), heff_strOfRunes(v_t_249));
    V t_0 = heff_intSub(v_w_240, v_t_2412);
    V t_1 = v_rest_244;
    V t_2 = v_s_2413;
    v_w_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eterminal_2ewidget_2epaintSpans_24acc_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2epaintSpans_24acc(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_REC_LIT(g_std_2eterminal_2ewidget_2emenu_lit0, 1, shape_at, MK_INT(0LL));

static V g_std_2eterminal_2ewidget_2emenu_val;
static HEFF_ONCE g_std_2eterminal_2ewidget_2emenu_st;
static V g_std_2eterminal_2ewidget_2emenu_init(void) {
  return ((V)&g_std_2eterminal_2ewidget_2emenu_lit0);
}
V g_std_2eterminal_2ewidget_2emenu_get(void) {
  if (HEFF_DONE(g_std_2eterminal_2ewidget_2emenu_st)) return g_std_2eterminal_2ewidget_2emenu_val;
  return heff_global(&g_std_2eterminal_2ewidget_2emenu_val, &g_std_2eterminal_2ewidget_2emenu_st, g_std_2eterminal_2ewidget_2emenu_init);
}
Clo g_std_2eterminal_2ewidget_2econtrolMove_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2econtrolMove_entry, 3, 0};

V g_std_2eterminal_2ewidget_2econtrolMove(V v_n_240, V v_c_241, V v_m_242) {
top: ;
  if (heff_runeEq_c(heff_dup(v_c_241), MK_INT(110LL))) {
    heff_drop(v_c_241);
    V v_i_243 = heff_intAdd(heff_take_field(v_m_242, 0), MK_INT(1LL));
    V v_t_245;
    if (heff_intLe_c_lent(v_n_240, v_i_243, 0)) {
      heff_drop(v_i_243);
      V v_y_244 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_244, 1)) {
        v_t_245 = v_y_244;
      } else {
        heff_drop(v_y_244);
        v_t_245 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_243, MK_INT(0LL), 2)) {
        heff_drop(v_i_243);
        v_t_245 = MK_INT(0LL);
      } else {
        v_t_245 = v_i_243;
      }
    }
    return ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_m_242, 0ULL, 1, shape_at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    if (heff_runeEq_c(v_c_241, MK_INT(112LL))) {
      V v_i_246 = heff_intAdd(heff_take_field(v_m_242, 0), MK_INT(-1LL));
      V v_t_248;
      if (heff_intLe_c_lent(v_n_240, v_i_246, 0)) {
        heff_drop(v_i_246);
        V v_y_247 = heff_intSub(v_n_240, MK_INT(1LL));
        if (heff_intLe_c_lent(MK_INT(0LL), v_y_247, 1)) {
          v_t_248 = v_y_247;
        } else {
          heff_drop(v_y_247);
          v_t_248 = MK_INT(0LL);
        }
      } else {
        heff_drop(v_n_240);
        if (heff_intLt_c_lent(v_i_246, MK_INT(0LL), 2)) {
          heff_drop(v_i_246);
          v_t_248 = MK_INT(0LL);
        } else {
          v_t_248 = v_i_246;
        }
      }
      return ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_m_242, 0ULL, 1, shape_at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    } else {
      heff_drop(v_n_240);
      return v_m_242;
    }
  }
}
V g_std_2eterminal_2ewidget_2econtrolMove_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2econtrolMove(a[0], a[1], a[2]);
}
Clo g_std_2eterminal_2ewidget_2emenuKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2emenuKey_entry, 3, 0};

V g_std_2eterminal_2ewidget_2emenuKey(V v_n_240, V v_k_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_k_241)) {
  case TAG_Char: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Enter: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Escape: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Tab: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_BackTab: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Backspace: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Delete: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_ArrowUp: {
    V v_i_244 = heff_intAdd(heff_take_field(v_m_242, 0), MK_INT(-1LL));
    V v_t_246;
    if (heff_intLe_c_lent(v_n_240, v_i_244, 0)) {
      heff_drop(v_i_244);
      V v_y_245 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_245, 1)) {
        v_t_246 = v_y_245;
      } else {
        heff_drop(v_y_245);
        v_t_246 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_244, MK_INT(0LL), 2)) {
        heff_drop(v_i_244);
        v_t_246 = MK_INT(0LL);
      } else {
        v_t_246 = v_i_244;
      }
    }
    return ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_nf(v_m_242, 0ULL, 1, shape_at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_ArrowDown: {
    V v_i_247 = heff_intAdd(heff_take_field(v_m_242, 0), MK_INT(1LL));
    V v_t_249;
    if (heff_intLe_c_lent(v_n_240, v_i_247, 0)) {
      heff_drop(v_i_247);
      V v_y_248 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_248, 1)) {
        v_t_249 = v_y_248;
      } else {
        heff_drop(v_y_248);
        v_t_249 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_247, MK_INT(0LL), 2)) {
        heff_drop(v_i_247);
        v_t_249 = MK_INT(0LL);
      } else {
        v_t_249 = v_i_247;
      }
    }
    return ({ V rv_0 = v_t_249; V rr_ = heff_rec_reuse_nf(v_m_242, 0ULL, 1, shape_at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_ArrowLeft: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_ArrowRight: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Home: {
    heff_drop(v_n_240);
    heff_drop_rec(v_m_242, 1);
    return heff_rec_n(1, shape_at, (V[]){MK_INT(0LL)});
  }
  case TAG_End: {
    heff_drop_rec(v_m_242, 1);
    V v_i_2410 = heff_intSub_lent(v_n_240, MK_INT(1LL), 2);
    V v_t_2412;
    if (heff_intLe_c_lent(v_n_240, v_i_2410, 0)) {
      heff_drop(v_i_2410);
      V v_y_2411 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_2411, 1)) {
        v_t_2412 = v_y_2411;
      } else {
        heff_drop(v_y_2411);
        v_t_2412 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_2410, MK_INT(0LL), 2)) {
        heff_drop(v_i_2410);
        v_t_2412 = MK_INT(0LL);
      } else {
        v_t_2412 = v_i_2410;
      }
    }
    return heff_rec_n(1, shape_at, (V[]){v_t_2412});
  }
  case TAG_PageUp: {
    V v_i_2413 = heff_intAdd(heff_take_field(v_m_242, 0), MK_INT(-10LL));
    V v_t_2415;
    if (heff_intLe_c_lent(v_n_240, v_i_2413, 0)) {
      heff_drop(v_i_2413);
      V v_y_2414 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_2414, 1)) {
        v_t_2415 = v_y_2414;
      } else {
        heff_drop(v_y_2414);
        v_t_2415 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_2413, MK_INT(0LL), 2)) {
        heff_drop(v_i_2413);
        v_t_2415 = MK_INT(0LL);
      } else {
        v_t_2415 = v_i_2413;
      }
    }
    return ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_m_242, 0ULL, 1, shape_at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_PageDown: {
    V v_i_2416 = heff_intAdd(heff_take_field(v_m_242, 0), MK_INT(10LL));
    V v_t_2418;
    if (heff_intLe_c_lent(v_n_240, v_i_2416, 0)) {
      heff_drop(v_i_2416);
      V v_y_2417 = heff_intSub(v_n_240, MK_INT(1LL));
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_2417, 1)) {
        v_t_2418 = v_y_2417;
      } else {
        heff_drop(v_y_2417);
        v_t_2418 = MK_INT(0LL);
      }
    } else {
      heff_drop(v_n_240);
      if (heff_intLt_c_lent(v_i_2416, MK_INT(0LL), 2)) {
        heff_drop(v_i_2416);
        v_t_2418 = MK_INT(0LL);
      } else {
        v_t_2418 = v_i_2416;
      }
    }
    return ({ V rv_0 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_m_242, 0ULL, 1, shape_at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_Control: {
    V v_c_2419 = heff_field(v_k_241, 0);
    HEFF_LAST return g_std_2eterminal_2ewidget_2econtrolMove(v_n_240, heff_dup(v_c_2419), v_m_242);
  }
  case TAG_Sequence: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  default: return heff_nomatch(v_k_241);
  }
}
V g_std_2eterminal_2ewidget_2emenuKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eterminal_2ewidget_2emenuKey(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2eterminal_2ewidget_2ewordStart_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ewordStart_entry, 2, 0};

V g_std_2eterminal_2ewidget_2ewordStart(V v_rs_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    HeffT3 v_t_242 = (g_list_2edrop_24cpr(heff_intSub_lent(v_i_241, MK_INT(1LL), 2), v_rs_240));
    {
      V v_field_244 = v_t_242.f[1];
      V v_field_245 = v_t_242.f[2];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      V v_x1_248;
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_244;
        V v_x12_247 = v_field_245;
        heff_drop(v_x12_247);
        v_x1_248 = v_x_246;
      } else {
        heff_drop(v_field_244);
        heff_drop(v_field_245);
        v_x1_248 = MK_INT(32LL);
      }
      if ((heff_runeEq_c(heff_dup(v_x1_248), MK_INT(32LL)) || (heff_runeEq_c(heff_dup(v_x1_248), MK_INT(9LL)) || (heff_runeEq_c(heff_dup(v_x1_248), MK_INT(10LL)) || (heff_runeEq_c(heff_dup(v_x1_248), MK_INT(13LL)) || (heff_runeEq_c(heff_dup(v_x1_248), MK_INT(11LL)) || heff_runeEq_c(heff_dup(v_x1_248), MK_INT(12LL)))))))) {
        heff_drop(v_x1_248);
        V t_0 = v_rs_240;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_rs_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_x1_248);
        HEFF_LAST return g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240(v_rs_240, v_i_241);
      }
    }
  } else {
    HEFF_LAST return g_std_2eterminal_2ewidget_2ewordStart_2ewordFrom_240(v_rs_240, v_i_241);
  }
}
V g_std_2eterminal_2ewidget_2ewordStart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ewordStart(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2econtrolEdit_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2econtrolEdit_entry, 2, 0};

V g_std_2eterminal_2ewidget_2econtrolEdit(V v_c_240, V v_f_241) {
top: ;
  if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(97LL))) {
    heff_drop(v_c_240);
    V v_x_242 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_243;
    if (heff_intLe_c_lent(v_x_242, MK_INT(0LL), 2)) {
      v_y_243 = v_x_242;
    } else {
      heff_drop(v_x_242);
      v_y_243 = MK_INT(0LL);
    }
    V v_t_244;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_243, 1)) {
      v_t_244 = v_y_243;
    } else {
      heff_drop(v_y_243);
      v_t_244 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_244; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  } else {
    if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(101LL))) {
      heff_drop(v_c_240);
      V v_i_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
      V v_x_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
      V v_y_247;
      if (heff_intLe_c_lent(v_x_246, v_i_245, 0)) {
        heff_drop(v_i_245);
        v_y_247 = v_x_246;
      } else {
        heff_drop(v_x_246);
        v_y_247 = v_i_245;
      }
      V v_t_248;
      if (heff_intLe_c_lent(MK_INT(0LL), v_y_247, 1)) {
        v_t_248 = v_y_247;
      } else {
        heff_drop(v_y_247);
        v_t_248 = MK_INT(0LL);
      }
      return ({ V rv_1 = v_t_248; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    } else {
      if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(98LL))) {
        heff_drop(v_c_240);
        V v_i_249 = heff_intSub(heff_take_field(v_f_241, 1), MK_INT(1LL));
        V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
        V v_y_2411;
        if (heff_intLe_c_lent(v_x_2410, v_i_249, 0)) {
          heff_drop(v_i_249);
          v_y_2411 = v_x_2410;
        } else {
          heff_drop(v_x_2410);
          v_y_2411 = v_i_249;
        }
        V v_t_2412;
        if (heff_intLe_c_lent(MK_INT(0LL), v_y_2411, 1)) {
          v_t_2412 = v_y_2411;
        } else {
          heff_drop(v_y_2411);
          v_t_2412 = MK_INT(0LL);
        }
        return ({ V rv_1 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(102LL))) {
          heff_drop(v_c_240);
          V v_i_2413 = heff_intAdd(heff_take_field(v_f_241, 1), MK_INT(1LL));
          V v_x_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
          V v_y_2415;
          if (heff_intLe_c_lent(v_x_2414, v_i_2413, 0)) {
            heff_drop(v_i_2413);
            v_y_2415 = v_x_2414;
          } else {
            heff_drop(v_x_2414);
            v_y_2415 = v_i_2413;
          }
          V v_t_2416;
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_2415, 1)) {
            v_t_2416 = v_y_2415;
          } else {
            heff_drop(v_y_2415);
            v_t_2416 = MK_INT(0LL);
          }
          return ({ V rv_1 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        } else {
          if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(104LL))) {
            heff_drop(v_c_240);
            if (heff_intEq_c(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(0LL))) {
              return v_f_241;
            } else {
              V v_t_2417 = heff_intSub(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(1LL));
              V v_t_2418 = (g_list_2etake(v_t_2417, heff_dup(heff_rfield(v_f_241, 0))));
              V v_t_2419 = (g_list_2edrop(heff_dup(heff_rfield(v_f_241, 1)), heff_rfield(v_f_241, 0)));
              V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2419));
              V v_t_2421 = heff_intSub(heff_take_field(v_f_241, 1), MK_INT(1LL));
              return ({ V rv_0 = v_t_2420; V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_f_241, 0ULL, 2, shape_text__at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            }
          } else {
            if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(100LL))) {
              heff_drop(v_c_240);
              V v_t_2422 = (g_list_2etake(heff_dup(heff_rfield(v_f_241, 1)), heff_dup(heff_rfield(v_f_241, 0))));
              V v_t_2423 = heff_intAdd(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(1LL));
              V v_t_2424 = (g_list_2edrop(v_t_2423, heff_rfield(v_f_241, 0)));
              V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2422, v_t_2424));
              return ({ V rv_0 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_f_241, 2ULL, 2, shape_text__at, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            } else {
              if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(117LL))) {
                heff_drop(v_c_240);
                V v_t_2426 = (g_list_2edrop(heff_take_field(v_f_241, 1), heff_rfield(v_f_241, 0)));
                return ({ V rv_0 = v_t_2426; V rv_1 = MK_INT(0LL); V rr_ = heff_rec_reuse_nf(v_f_241, 0ULL, 2, shape_text__at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
              } else {
                if (heff_runeEq_c(heff_dup(v_c_240), MK_INT(107LL))) {
                  heff_drop(v_c_240);
                  V v_t_2427 = (g_list_2etake(heff_dup(heff_rfield(v_f_241, 1)), heff_take_field(v_f_241, 0)));
                  return ({ V rv_0 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_f_241, 2ULL, 2, shape_text__at, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                } else {
                  if (heff_runeEq_c(v_c_240, MK_INT(119LL))) {
                    V v_t_2428 = (g_std_2eterminal_2ewidget_2ewordStart(heff_rfield(v_f_241, 0), heff_dup(heff_rfield(v_f_241, 1))));
                    V v_t_2429 = (g_list_2etake(v_t_2428, heff_dup(heff_rfield(v_f_241, 0))));
                    V v_t_2430 = (g_list_2edrop(heff_dup(heff_rfield(v_f_241, 1)), heff_rfield(v_f_241, 0)));
                    V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2430));
                    V v_t_2432 = (g_std_2eterminal_2ewidget_2ewordStart(heff_rfield(v_f_241, 0), heff_take_field(v_f_241, 1)));
                    return ({ V rv_0 = v_t_2431; V rv_1 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_f_241, 0ULL, 2, shape_text__at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
                  } else {
                    return v_f_241;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2eterminal_2ewidget_2econtrolEdit_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2econtrolEdit(a[0], a[1]);
}
Clo g_std_2eterminal_2ewidget_2efieldKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2efieldKey_entry, 2, 0};

V g_std_2eterminal_2ewidget_2efieldKey(V v_k_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_c_242 = heff_field(v_k_240, 0);
    V v_t_243 = (g_list_2etake(heff_dup(heff_rfield(v_f_241, 1)), heff_dup(heff_rfield(v_f_241, 0))));
    V v_t_244 = (g_list_2edrop(heff_dup(heff_rfield(v_f_241, 1)), heff_rfield(v_f_241, 0)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_c_242), v_t_244})));
    V v_t_246 = heff_intAdd(heff_take_field(v_f_241, 1), MK_INT(1LL));
    return ({ V rv_0 = v_t_245; V rv_1 = v_t_246; V rr_ = heff_rec_reuse_nf(v_f_241, 0ULL, 2, shape_text__at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Enter: {
    return v_f_241;
  }
  case TAG_Escape: {
    return v_f_241;
  }
  case TAG_Tab: {
    return v_f_241;
  }
  case TAG_BackTab: {
    return v_f_241;
  }
  case TAG_Backspace: {
    if (heff_intEq_c(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(0LL))) {
      return v_f_241;
    } else {
      V v_t_247 = heff_intSub(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(1LL));
      V v_t_248 = (g_list_2etake(v_t_247, heff_dup(heff_rfield(v_f_241, 0))));
      V v_t_249 = (g_list_2edrop(heff_dup(heff_rfield(v_f_241, 1)), heff_rfield(v_f_241, 0)));
      V v_t_2410 = (g_prelude_2e_2b_2b(v_t_248, v_t_249));
      V v_t_2411 = heff_intSub(heff_take_field(v_f_241, 1), MK_INT(1LL));
      return ({ V rv_0 = v_t_2410; V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_f_241, 0ULL, 2, shape_text__at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
  }
  case TAG_Delete: {
    V v_t_2412 = (g_list_2etake(heff_dup(heff_rfield(v_f_241, 1)), heff_dup(heff_rfield(v_f_241, 0))));
    V v_t_2413 = heff_intAdd(heff_dup(heff_rfield(v_f_241, 1)), MK_INT(1LL));
    V v_t_2414 = (g_list_2edrop(v_t_2413, heff_rfield(v_f_241, 0)));
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2414));
    return ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_f_241, 2ULL, 2, shape_text__at, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_ArrowUp: {
    return v_f_241;
  }
  case TAG_ArrowDown: {
    return v_f_241;
  }
  case TAG_ArrowLeft: {
    V v_i_2416 = heff_intSub(heff_take_field(v_f_241, 1), MK_INT(1LL));
    V v_x_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_2418;
    if (heff_intLe_c_lent(v_x_2417, v_i_2416, 0)) {
      heff_drop(v_i_2416);
      v_y_2418 = v_x_2417;
    } else {
      heff_drop(v_x_2417);
      v_y_2418 = v_i_2416;
    }
    V v_t_2419;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2418, 1)) {
      v_t_2419 = v_y_2418;
    } else {
      heff_drop(v_y_2418);
      v_t_2419 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ArrowRight: {
    V v_i_2420 = heff_intAdd(heff_take_field(v_f_241, 1), MK_INT(1LL));
    V v_x_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_2422;
    if (heff_intLe_c_lent(v_x_2421, v_i_2420, 0)) {
      heff_drop(v_i_2420);
      v_y_2422 = v_x_2421;
    } else {
      heff_drop(v_x_2421);
      v_y_2422 = v_i_2420;
    }
    V v_t_2423;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2422, 1)) {
      v_t_2423 = v_y_2422;
    } else {
      heff_drop(v_y_2422);
      v_t_2423 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Home: {
    V v_x_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_2425;
    if (heff_intLe_c_lent(v_x_2424, MK_INT(0LL), 2)) {
      v_y_2425 = v_x_2424;
    } else {
      heff_drop(v_x_2424);
      v_y_2425 = MK_INT(0LL);
    }
    V v_t_2426;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2425, 1)) {
      v_t_2426 = v_y_2425;
    } else {
      heff_drop(v_y_2425);
      v_t_2426 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_End: {
    V v_i_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_x_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 0)));
    V v_y_2429;
    if (heff_intLe_c_lent(v_x_2428, v_i_2427, 0)) {
      heff_drop(v_i_2427);
      v_y_2429 = v_x_2428;
    } else {
      heff_drop(v_x_2428);
      v_y_2429 = v_i_2427;
    }
    V v_t_2430;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2429, 1)) {
      v_t_2430 = v_y_2429;
    } else {
      heff_drop(v_y_2429);
      v_t_2430 = MK_INT(0LL);
    }
    return ({ V rv_1 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_f_241, 1ULL, 2, shape_text__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_PageUp: {
    return v_f_241;
  }
  case TAG_PageDown: {
    return v_f_241;
  }
  case TAG_Control: {
    V v_c_2431 = heff_field(v_k_240, 0);
    HEFF_LAST return g_std_2eterminal_2ewidget_2econtrolEdit(heff_dup(v_c_2431), v_f_241);
  }
  case TAG_Sequence: {
    return v_f_241;
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2eterminal_2ewidget_2efieldKey_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2efieldKey(a0, a[1]); heff_drop(a0); return r;
}
Clo g_std_2eterminal_2ewidget_2echoiceKey_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2echoiceKey_entry, 2, 0};

V g_std_2eterminal_2ewidget_2echoiceKey(V v_k_240, V v_c_241) {
top: ;
  switch (heff_tag_of(v_k_240)) {
  case TAG_Char: {
    V v_x_242 = heff_field(v_k_240, 0);
    if ((heff_runeEq_c(heff_dup(v_x_242), MK_INT(32LL)) || heff_runeEq_c(heff_dup(v_x_242), MK_INT(108LL)))) {
      V v_t_243 = heff_dup(heff_rfield(v_c_241, 0));
      V v_t_249;
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nil: {
        v_t_249 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_243, 0ULL, 2);
        V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
        V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
        V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(1LL));
        v_t_249 = heff_intMod(heff_intAdd(v_t_248, v_t_246), v_t_247);
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      return ({ V rv_1 = v_t_249; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    } else {
      if (heff_runeEq_c(heff_dup(v_x_242), MK_INT(104LL))) {
        V v_t_2410 = heff_dup(heff_rfield(v_c_241, 0));
        V v_t_2416;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Nil: {
          v_t_2416 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2410, 0ULL, 2);
          V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
          V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
          V v_t_2415 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(-1LL));
          v_t_2416 = heff_intMod(heff_intAdd(v_t_2415, v_t_2413), v_t_2414);
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        return ({ V rv_1 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        return v_c_241;
      }
    }
  }
  case TAG_Enter: {
    return v_c_241;
  }
  case TAG_Escape: {
    return v_c_241;
  }
  case TAG_Tab: {
    return v_c_241;
  }
  case TAG_BackTab: {
    return v_c_241;
  }
  case TAG_Backspace: {
    return v_c_241;
  }
  case TAG_Delete: {
    return v_c_241;
  }
  case TAG_ArrowUp: {
    return v_c_241;
  }
  case TAG_ArrowDown: {
    return v_c_241;
  }
  case TAG_ArrowLeft: {
    V v_t_2417 = heff_dup(heff_rfield(v_c_241, 0));
    V v_t_2423;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nil: {
      v_t_2423 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2417, 0ULL, 2);
      V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
      V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
      V v_t_2422 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(-1LL));
      v_t_2423 = heff_intMod(heff_intAdd(v_t_2422, v_t_2420), v_t_2421);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    return ({ V rv_1 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ArrowRight: {
    V v_t_2424 = heff_dup(heff_rfield(v_c_241, 0));
    V v_t_2430;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      v_t_2430 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2424, 0ULL, 2);
      V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
      V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_c_241, 0)));
      V v_t_2429 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 1)), MK_INT(1LL));
      v_t_2430 = heff_intMod(heff_intAdd(v_t_2429, v_t_2427), v_t_2428);
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return ({ V rv_1 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_c_241, 1ULL, 2, shape_options__at, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Home: {
    return v_c_241;
  }
  case TAG_End: {
    return v_c_241;
  }
  case TAG_PageUp: {
    return v_c_241;
  }
  case TAG_PageDown: {
    return v_c_241;
  }
  case TAG_Control: {
    return v_c_241;
  }
  case TAG_Sequence: {
    return v_c_241;
  }
  default: return heff_nomatch(v_k_240);
  }
}
V g_std_2eterminal_2ewidget_2echoiceKey_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2echoiceKey(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_std_2eterminal_2ewidget_2estepAll_24cpr(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Continue: {
    V v_st_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_st_243}});
    }
    case TAG_Cons: {
      V v_k_244 = heff_field(v_x3_242, 0);
      V v_ks_245 = heff_field(v_x3_242, 1);
      V v_t_246 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){heff_dup(v_k_244), v_st_243}));
      V t_0 = v_f_240;
      V t_1 = v_t_246;
      V t_2 = v_ks_245;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  case TAG_Done: {
    V v_r_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_r_247}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_entry, 2, 0};

V g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(V v_lit_240, V v_f_241) {
top: ;
  V v_at_242 = heff_take_field(v_f_241, 1);
  V v_text_243 = heff_take_field(v_f_241, 0);
  V v_t_244 = (g_list_2etake(heff_dup(v_at_242), heff_dup(v_text_243)));
  V v_t_245 = ({ V a_0 = heff_dup(v_at_242); V a_1 = v_text_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_text_243); r_; });
  V v_t_246 = (g_prelude_2e_2b_2b(v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_240, v_t_245})));
  return ({ V rv_0 = v_t_246; V rv_1 = heff_intAdd(v_at_242, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_f_241, 0ULL, 2, shape_text__at, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734_entry(V self, V *a) {
  (void)self;
  return g_std_2eterminal_2ewidget_2efieldKey_24s1281405897x512615734(a[0], a[1]);
}

static V g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_val;
static HEFF_ONCE g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_st;
static V g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_init(void) {
  return ((V)&g_std_2eterminal_2ewidget_2econtrolEdit_clo);
}
V g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_get(void) {
  if (HEFF_DONE(g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_st)) return g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_val;
  return heff_global(&g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_val, &g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_st, g_std_2eterminal_2ewidget_2efieldKey_24s944263119x1377915483_init);
}