// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2ewords_2ewordsFrom_240(V, V, V, V);
V g_prelude_2ewords_2ewordsFrom_240_entry(V self, V *a);
extern Clo g_prelude_2ewords_2ewordsFrom_240_clo;
V g_prelude_2ewords_2ewordsFrom_240_2ebackwards_241(V, V);
V g_prelude_2ewords_2ewordsFrom_240_2ebackwards_241_entry(V self, V *a);
extern Clo g_prelude_2ewords_2ewordsFrom_240_2ebackwards_241_clo;
Clo g_prelude_2ewords_2ewordsFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ewords_2ewordsFrom_240_entry, 4, 0};

V g_prelude_2ewords_2ewordsFrom_240(V v_s_240, V v_start_241, V v_box_24i_242, V v_acc_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_242)) {
    V v_t_244;
    if (heff_intLt_c_lent(v_start_241, heff_box_word(v_i_242), 2)) {
      v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, heff_box_word(v_i_242), 6), v_acc_243});
    } else {
      heff_drop(v_start_241);
      v_t_244 = v_acc_243;
    }
    return (g_prelude_2ewords_2ewordsFrom_240_2ebackwards_241(v_t_244, NTAG(TAG_Nil)));
  } else {
    V v_c_245 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2);
    if (((heff_peek_word(v_c_245) == ((int64_t)32ULL)) || ((heff_peek_word(v_c_245) == ((int64_t)9ULL)) || ((heff_peek_word(v_c_245) == ((int64_t)10ULL)) || (heff_peek_word(v_c_245) == ((int64_t)13ULL)))))) {
      heff_drop(v_c_245);
      V v_t_246;
      if (heff_intLt_c_lent(v_start_241, heff_box_word(v_i_242), 2)) {
        v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, heff_box_word(v_i_242), 6), v_acc_243});
      } else {
        heff_drop(v_start_241);
        v_t_246 = v_acc_243;
      }
      V t_0 = v_s_240;
      V t_1 = heff_box_word((v_i_242 + ((int64_t)1ULL)));
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_246;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_c_245);
      V t_0 = v_s_240;
      V t_1 = v_start_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_prelude_2ewords_2ewordsFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2ewords_2ewordsFrom_240(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}