// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__dir__src__own__top__heff__scope[] = {LBL_path, LBL_dir, LBL_src, LBL_own, LBL_top, LBL_heff, LBL_scope};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2efreeName(V, V, V);
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efreeName_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eloadDone(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadDone_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_clo;
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_clo;
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559(V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708(V, V, V, V);
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_clo;
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_get(void);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2esameDir(V, V, V);
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameDir_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2etakeUntil_24dps(V, V, V);
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_clo;
V g_heff_2ebuild_2eproject_2eclaimMsg_get(void);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2eimportsOf_24cpr(V, V);
V g_heff_2eutil_2ehostpath_2eisUnder(V, V, V);
V g_heff_2eutil_2ehostpath_2eisUnder_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2eisUnder_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s241416889x826324235(V, V, V);
V g_list_2eany_24s241416889x826324235_entry(V self, V *a);
extern Clo g_list_2eany_24s241416889x826324235_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s18996220x10511024(V);
V g_list_2emap_24s18996220x10511024_entry(V self, V *a);
extern Clo g_list_2emap_24s18996220x10511024_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HeffT4 g_std_2epath_2erelative_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;

HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_style_243 = heff_take_field(v_ps_240, 5);
  V v_cwd_244 = heff_get_n(v_ps_240, 4, 6);
  V v_st_245 = heff_dup(v_style_243);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_d_241)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
  V v_st_2410 = heff_dup(v_style_243);
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_2410), heff_dup(v_cwd_244)));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2410), heff_dup(v_path_242)));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
  V v_t_2415 = (g_heff_2eutil_2ehostpath_2eisUnder(heff_dup(v_style_243), v_t_249, v_t_2414));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    V v_st_2416 = heff_dup(v_style_243);
    V v_st_2417 = heff_dup(v_style_243);
    V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_dup(v_cwd_244)));
    V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_d_241));
    V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
    V v_from_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
    V v_st_2422 = v_style_243;
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_cwd_244));
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_path_242));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    V v_to_2426 = ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_from_2421));
    V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_to_2426));
    HeffT4 v_t_2429 = (g_std_2epath_2erelative_24cpr(heff_dup(v_st_2416), v_t_2427, v_t_2428));
    {
      V v_field_2431 = v_t_2429.f[1];
      V v_field_2432 = v_t_2429.f[2];
      V v_field_2433 = v_t_2429.f[3];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_x_2434 = heff_tag_n(TAG_MkPath, 3, (V[]){v_field_2431, v_field_2432, v_field_2433});
        V v_t_2435 = ({ V a_0 = v_st_2416; V a_1 = v_x_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop_tag(v_x_2434, 3); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2435}});
      } else {
        heff_drop(v_st_2416);
        heff_drop(v_field_2431);
        heff_drop(v_field_2432);
        heff_drop(v_field_2433);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_style_243);
    heff_drop(v_cwd_244);
    heff_drop(v_t_2415);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str6, 1, ".");
Clo g_heff_2ebuild_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_ps_240, 5));
  HeffT2 v_t_243 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_path_241)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_p_2415;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_path_241);
      V v_rel_246 = v_field_245;
      v_p_2415 = v_rel_246;
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_247 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 1)), heff_dup(v_path_241)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_path_241);
          V v_rel_2410 = v_field_249;
          v_p_2415 = v_rel_2410;
        } else {
          heff_drop(v_field_249);
          HeffT2 v_t_2411 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 0, 6), heff_dup(v_path_241)));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop(v_path_241);
              V v_rel_2414 = v_field_2413;
              v_p_2415 = v_rel_2414;
            } else {
              heff_drop(v_field_2413);
              v_p_2415 = v_path_241;
            }
          }
        }
      }
    }
    int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_2415, 0)) - ((int64_t)3ULL));
    V v_t_2417 = heff_strSlice_lent(v_p_2415, heff_box_word(v_t_2416), heff_strLength_lent(v_p_2415, 0), 6);
    V v_t_2419;
    if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2eload_2emoduleOf_str0))) {
      int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_p_2415, 0)) - ((int64_t)3ULL));
      v_t_2419 = heff_strSlice(v_p_2415, MK_INT(0LL), heff_box_word(v_t_2418));
    } else {
      v_t_2419 = v_p_2415;
    }
    HeffT3 v_t_2420 = (g_std_2epath_2eparse_24cpr(v_st_242, v_t_2419));
    {
      V v_field_2421 = v_t_2420.f[0];
      V v_field_2422 = v_t_2420.f[1];
      V v_field_2423 = v_t_2420.f[2];
      V v_d_2424 = v_field_2421;
      heff_drop(v_d_2424);
      V v_a_2425 = v_field_2422;
      V v_xs_2426 = v_field_2423;
      V v_xs_2427 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str1); V a_1 = v_a_2425; V a_2 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str2); V a_3 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str3); V a_4 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2426; V r_ = (g_list_2efoldl_24s680990791x1764841948(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_2425); r_; });
      V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
      V v_x2_2429 = v_t_2428;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        return ((V)&g_heff_2ebuild_2eload_2emoduleOf_str5);
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        return ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str6); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
      }
      default: return heff_nomatch(v_x2_2429);
      }
    }
  }
}
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emoduleOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2einside_str0, 1, ".");
Clo g_heff_2ebuild_2eload_2einside_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2einside_entry, 3, 0};

V g_heff_2ebuild_2eload_2einside(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_style_243 = heff_take_field(v_ps_240, 5);
  V v_cwd_244 = heff_get_n(v_ps_240, 4, 6);
  if (heff_strEq_c_lent(v_d_241, ((V)&g_heff_2ebuild_2eload_2einside_str0), 2)) {
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_style_243);
    heff_drop(v_cwd_244);
    return NTAG(TAG_True);
  } else {
    V v_st_245 = heff_dup(v_style_243);
    V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
    V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_241));
    V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
    V v_st_2410 = heff_dup(v_style_243);
    V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_2410), v_cwd_244));
    V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2410), v_path_242));
    V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
    V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
    HEFF_LAST return g_heff_2eutil_2ehostpath_2eisUnder(v_style_243, v_t_249, v_t_2414);
  }
}
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2einside(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eload_2esameDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameDir_entry, 3, 0};

V g_heff_2ebuild_2eload_2esameDir(V v_h_240, V v_a_241, V v_b_242) {
top: ;
  V v_style_243 = heff_take_field(v_h_240, 3);
  V v_cwd_244 = heff_get_n(v_h_240, 2, 5);
  V v_st_245 = heff_dup(v_style_243);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_a_241));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_heff_2eutil_2ehostpath_2enormalize(heff_dup(v_style_243), v_t_249));
  V v_st_2411 = heff_dup(v_style_243);
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2411), v_cwd_244));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2411), v_b_242));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  V v_t_2415 = ({ V a_0 = v_st_2411; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2411); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_heff_2eutil_2ehostpath_2enormalize(v_style_243, v_t_2415));
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2410, v_t_2416, 0));
  heff_drop(v_t_2410);
  heff_drop(v_t_2416);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2esameDir(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eheffAt_str0, 3, "lib");
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eheffAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eheffAt_entry, 2, 0};

V g_heff_2ebuild_2eload_2eheffAt(V v_h_240, V v_d_241) {
top: ;
  V v_t_243 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2eload_2eheffAt_lam0, 1, 2, (V[]){heff_dup(v_h_240), heff_dup(v_d_241)}); V a_1 = heff_rfield(v_h_240, 4); V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop_rec(v_h_240, 5);
    heff_drop(v_d_241);
    heff_drop(v_t_243);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_243);
    V v_st_244 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_d_241));
    V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2eload_2eheffAt_str0)));
    V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
    V v_t_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
    return (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_240), heff_get_n(v_h_240, 0, 5), v_t_248));
  }
}
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eheffAt(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2eload_2esameDir(v_h_240, v_o_242, v_d_241));
}

HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_242, 0)), heff_dup(v_p_241))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_k_242)}});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2eload_2etakeUntil_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2etakeUntil_24dps_entry, 3, 0};

V g_heff_2ebuild_2eload_2etakeUntil_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      heff_drop(v_rest_244);
      V v_t_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_243, NTAG(TAG_Nil)});
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_245);
    } else {
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_243, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = v_x_240;
      V t_1 = v_rest_244;
      V t_2 = v_u_247;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2etakeUntil_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2eload_2etakeUntil_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s1006624359x760861690(v_path_243, v_stack_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_rest_244);
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ebuild_2eload_2etakeUntil(v_path_243, v_stack_241));
      V v_xs_247 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_path_243, v_t_246});
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
    } else {
      heff_drop(v_t_245);
      HeffT2 v_t_249 = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(v_pkgs_240, v_path_243));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_t_2413;
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_k_2412 = v_field_2411;
          v_t_2413 = (g_list_2emap_24s1173914895x100384474(heff_get_n(v_k_2412, 6, 7)));
        } else {
          heff_drop(v_field_2411);
          v_t_2413 = NTAG(TAG_Nil);
        }
        V v_x1_2414 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2413));
        V v_x2_2415 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nothing: {
          return v_x2_2415;
        }
        case TAG_Just: {
          V v_x_2416 = heff_field(v_x1_2414, 0);
          V v_ru_24x1_2414_24Just = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
          heff_drop(v_x2_2415);
          return heff_tag_re_n(v_ru_24x1_2414_24Just, TAG_Just, 1, 1ULL, (V[]){v_x_2416});
        }
        default: return heff_nomatch(v_x1_2414);
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2ecycleAmong(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str0, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eload_2efreeName_str1, 1, "_");
Clo g_heff_2ebuild_2eload_2efreeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2efreeName_entry, 3, 0};

V g_heff_2ebuild_2eload_2efreeName(V v_taken_240, V v_x_241, V v_n_242) {
top: ;
  V v_t_243;
  if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
    v_t_243 = heff_dup(v_x_241);
  } else {
    v_t_243 = heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ebuild_2eload_2efreeName_str0)), heff_intShow(heff_dup(v_n_242)));
  }
  V v_x1_244 = ({ V a_0 = v_t_243; V a_1 = v_taken_240; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_243); r_; });
  if (!(heff_dup(v_x1_244) == NTAG(TAG_True))) {
    heff_drop(v_x1_244);
    if (heff_intLt_c_lent(v_n_242, MK_INT(2LL), 2)) {
      heff_drop(v_n_242);
      return heff_dup(v_x_241);
    } else {
      return heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ebuild_2eload_2efreeName_str1)), heff_intShow(v_n_242));
    }
  } else {
    heff_drop(v_x1_244);
    V t_0 = v_taken_240;
    V t_1 = v_x_241;
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_taken_240 = t_0;
    v_x_241 = t_1;
    v_n_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2eload_2efreeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eload_2efreeName(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str3, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str7, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str10, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str11, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str14, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str15, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str17, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str18, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str19, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str21, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str22, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str23, 3, ".hf");
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args);
Clo g_heff_2ebuild_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2ebuild_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_from_242)));
  if (((heff_dup(v_t_244) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str0)))) {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_t_244);
    V v_base_245 = heff_dup(heff_rfield(v_ps_240, 2));
    V v_xs_246 = (g_prelude_2esplit_2esplitFrom_240(v_w_243, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str1), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str2), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
    V v_parts_2411;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      v_parts_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_248 = heff_field(v_t_247, 0);
      V v_before_249 = heff_field(v_t_247, 1);
      V v_ru_24t_247_24Cons = heff_take_reuse_n(v_t_247, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24t_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_248, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str3)), NTAG(TAG_Nil)});
      v_parts_2411 = (g_list_2efoldl_24s1370882877x364361272(v_t_2410, v_before_249));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2418 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam0, 2, 1, (V[]){v_ps_240}); V a_1 = heff_dup(v_base_245); V a_2 = v_parts_2411; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2418, v_base_245, v_parts_2411, v_w_243}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_244);
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2419 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2420 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2421 = ({ V a_0 = v_ps_240; V a_1 = v_deps_2420; V a_2 = v_project_2419; V a_3 = v_from_242; V r_ = (g_heff_2ebuild_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2420); heff_drop(v_project_2419); r_; });
      V v_t_2455;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2421, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str4))) {
        V v_base_2422 = heff_dup(heff_rfield(v_k_2421, 2));
        V v_xs_2423 = (g_prelude_2esplit_2esplitFrom_240(v_w_243, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str5), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str6), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
        V v_parts_2428;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nil: {
          v_parts_2428 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2425 = heff_field(v_t_2424, 0);
          V v_before_2426 = heff_field(v_t_2424, 1);
          V v_ru_24t_2424_24Cons = heff_take_reuse_n(v_t_2424, 3ULL, 2);
          V v_t_2427 = heff_tag_at_n(v_ru_24t_2424_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2425, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str7)), NTAG(TAG_Nil)});
          v_parts_2428 = (g_list_2efoldl_24s1370882877x364361272(v_t_2427, v_before_2426));
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        V v_t_2435 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam1, 2, 1, (V[]){heff_dup(v_ps_240)}); V a_1 = heff_dup(v_base_2422); V a_2 = v_parts_2428; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2435, v_base_2422, v_parts_2428, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      } else {
        V v_j_2436 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str8), v_w_243, MK_INT(0LL), 5);
        V v_t_2437;
        if (heff_intLt_c_lent(v_j_2436, MK_INT(0LL), 2)) {
          heff_drop(v_j_2436);
          v_t_2437 = heff_dup(v_w_243);
        } else {
          v_t_2437 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2436, 6);
        }
        if (heff_strEq_c(v_t_2437, heff_dup(heff_rfield(v_k_2421, 3)))) {
          V v_base_2438 = heff_dup(heff_rfield(v_k_2421, 2));
          V v_xs_2439 = (g_prelude_2esplit_2esplitFrom_240(v_w_243, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str9), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str10), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
          V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2439));
          V v_parts_2444;
          switch (heff_tag_of(v_t_2440)) {
          case TAG_Nil: {
            v_parts_2444 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2441 = heff_field(v_t_2440, 0);
            V v_before_2442 = heff_field(v_t_2440, 1);
            V v_ru_24t_2440_24Cons = heff_take_reuse_n(v_t_2440, 3ULL, 2);
            V v_t_2443 = heff_tag_at_n(v_ru_24t_2440_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2441, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str11)), NTAG(TAG_Nil)});
            v_parts_2444 = (g_list_2efoldl_24s1370882877x364361272(v_t_2443, v_before_2442));
            break;
          }
          default: heff_nomatch(v_t_2440);
          }
          V v_j_2445 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str12), v_w_243, MK_INT(0LL), 5);
          V v_t_2446;
          if (heff_intLt_c_lent(v_j_2445, MK_INT(0LL), 2)) {
            heff_drop(v_j_2445);
            v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str13);
          } else {
            v_t_2446 = heff_strSlice_lent(v_w_243, v_j_2445, heff_strLength_lent(v_w_243, 0), 6);
          }
          V v_m_2447 = heff_strAppend(heff_dup(heff_rfield(v_k_2421, 4)), v_t_2446);
          V v_t_2454 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam2, 2, 1, (V[]){heff_dup(v_ps_240)}); V a_1 = heff_dup(v_base_2438); V a_2 = v_parts_2444; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2454, v_base_2438, v_parts_2444, v_m_2447}), NTAG(TAG_Nil)});
        } else {
          v_t_2455 = NTAG(TAG_Nil);
        }
      }
      V v_j_2456 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str14), v_w_243, MK_INT(0LL), 5);
      V v_t_2457;
      if (heff_intLt_c_lent(v_j_2456, MK_INT(0LL), 2)) {
        heff_drop(v_j_2456);
        v_t_2457 = heff_dup(v_w_243);
      } else {
        v_t_2457 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2456, 6);
      }
      V v_j_2458 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str15), v_w_243, MK_INT(0LL), 5);
      V v_t_2459;
      if (heff_intLt_c_lent(v_j_2458, MK_INT(0LL), 2)) {
        heff_drop(v_j_2458);
        v_t_2459 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str16);
      } else {
        v_t_2459 = heff_strSlice_lent(v_w_243, v_j_2458, heff_strLength_lent(v_w_243, 0), 6);
      }
      V v_t_2460 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2421); V a_3 = v_t_2457; V a_4 = v_t_2459; V r_ = (g_heff_2ebuild_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_pkgs_241, 2); heff_drop(v_t_2457); r_; });
      V v_base_2461 = heff_dup(heff_rfield(v_ps_240, 2));
      V v_xs_2462 = (g_prelude_2esplit_2esplitFrom_240(v_w_243, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str17), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str18), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
      V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2462));
      V v_parts_2467;
      switch (heff_tag_of(v_t_2463)) {
      case TAG_Nil: {
        v_parts_2467 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2464 = heff_field(v_t_2463, 0);
        V v_before_2465 = heff_field(v_t_2463, 1);
        V v_ru_24t_2463_24Cons = heff_take_reuse_n(v_t_2463, 3ULL, 2);
        V v_t_2466 = heff_tag_at_n(v_ru_24t_2463_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2464, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str19)), NTAG(TAG_Nil)});
        v_parts_2467 = (g_list_2efoldl_24s1370882877x364361272(v_t_2466, v_before_2465));
        break;
      }
      default: heff_nomatch(v_t_2463);
      }
      V v_t_2474 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam3, 2, 1, (V[]){heff_dup(v_ps_240)}); V a_1 = heff_dup(v_base_2461); V a_2 = v_parts_2467; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_2475 = heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2474, v_base_2461, v_parts_2467, heff_dup(v_w_243)});
      V v_ys_2491;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2421, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str20))) {
        V v_x1_2476 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_take_field(v_k_2421, 2), v_from_242));
        if (!(heff_dup(v_x1_2476) == NTAG(TAG_True))) {
          heff_drop(v_x1_2476);
          V v_base_2477 = heff_get_n(v_k_2421, 1, 7);
          V v_xs_2478 = (g_prelude_2esplit_2esplitFrom_240(v_w_243, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str21), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str22), v_w_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
          V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2478));
          V v_parts_2483;
          switch (heff_tag_of(v_t_2479)) {
          case TAG_Nil: {
            v_parts_2483 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2480 = heff_field(v_t_2479, 0);
            V v_before_2481 = heff_field(v_t_2479, 1);
            V v_ru_24t_2479_24Cons = heff_take_reuse_n(v_t_2479, 3ULL, 2);
            V v_t_2482 = heff_tag_at_n(v_ru_24t_2479_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2480, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str23)), NTAG(TAG_Nil)});
            v_parts_2483 = (g_list_2efoldl_24s1370882877x364361272(v_t_2482, v_before_2481));
            break;
          }
          default: heff_nomatch(v_t_2479);
          }
          V v_t_2490 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam4, 2, 1, (V[]){v_ps_240}); V a_1 = heff_dup(v_base_2477); V a_2 = v_parts_2483; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          v_ys_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2490, v_base_2477, v_parts_2483, v_w_243}), NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_w_243);
          heff_drop_rec(v_k_2421, 7);
          heff_drop(v_x1_2476);
          v_ys_2491 = NTAG(TAG_Nil);
        }
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_from_242);
        heff_drop(v_w_243);
        heff_drop_rec(v_k_2421, 7);
        v_ys_2491 = NTAG(TAG_Nil);
      }
      V v_t_2492 = (g_prelude_2e_2b_2b(v_t_2460, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_ys_2491})));
      return (g_prelude_2e_2b_2b(v_t_2455, v_t_2492));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
}
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args) {
  V v_d_2412 = args[0];
  V v_p_2413 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2414 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_d_2412));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_p_2413));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  return ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2417); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args) {
  V v_d_2429 = args[0];
  V v_p_2430 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2431 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2431), v_d_2429));
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_2431), v_p_2430));
  V v_t_2434 = (g_std_2epath_2ejoin(v_t_2432, v_t_2433));
  return ({ V a_0 = v_st_2431; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2431); heff_drop(v_t_2434); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args) {
  V v_d_2448 = args[0];
  V v_p_2449 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2450 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_d_2448));
  V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_p_2449));
  V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
  return ({ V a_0 = v_st_2450; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); heff_drop(v_t_2453); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args) {
  V v_d_2468 = args[0];
  V v_p_2469 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2470 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2471 = (g_std_2epath_2eparse(heff_dup(v_st_2470), v_d_2468));
  V v_t_2472 = (g_std_2epath_2eparse(heff_dup(v_st_2470), v_p_2469));
  V v_t_2473 = (g_std_2epath_2ejoin(v_t_2471, v_t_2472));
  return ({ V a_0 = v_st_2470; V a_1 = v_t_2473; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2470); heff_drop(v_t_2473); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args) {
  V v_d_2484 = args[0];
  V v_p_2485 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2486 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2487 = (g_std_2epath_2eparse(heff_dup(v_st_2486), v_d_2484));
  V v_t_2488 = (g_std_2epath_2eparse(heff_dup(v_st_2486), v_p_2485));
  V v_t_2489 = (g_std_2epath_2ejoin(v_t_2487, v_t_2488));
  return ({ V a_0 = v_st_2486; V a_1 = v_t_2489; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2486); heff_drop(v_t_2489); r_; });
}
Clo g_heff_2ebuild_2eload_2eloadDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadDone_entry, 4, 0};

V g_heff_2ebuild_2eload_2eloadDone(V v_ps_240, V v_pk_241, V v_pkgs_242, V v_st_243) {
top: ;
  V v_errors_244 = heff_take_field(v_st_243, 2);
  V v_done_245 = heff_get_n(v_st_243, 0, 3);
  V v_t_249;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_246 = heff_dup(heff_field(v_pk_241, 0));
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_why_247 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_247, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      heff_take_n(v_x11_246, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x11_246);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_field(v_pkgs_242, 1);
    v_t_2412 = heff_dup(v_y_2411);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_errors_244));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2418;
  switch (heff_tag_of(v_pk_241)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x11_2415 = heff_field(v_pk_241, 0);
    V v_ru_24pk_241_24Just = heff_take_reuse_n(v_pk_241, 1ULL, 1);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      heff_take_n(v_x11_2415, 0ULL, 1);
      heff_drop_cell(v_ru_24pk_241_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_p_2417 = heff_field(v_x11_2415, 0);
      heff_take_n(v_x11_2415, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24pk_241_24Just, TAG_Just, 1, (V[]){v_p_2417});
      break;
    }
    default: heff_nomatch(v_x11_2415);
    }
    break;
  }
  default: heff_nomatch(v_pk_241);
  }
  V v_t_2421;
  switch (heff_tag_of(v_pkgs_242)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_pkgs_242, 0);
    v_t_2421 = heff_dup(v_x_2419);
    break;
  }
  default: heff_nomatch(v_pkgs_242);
  }
  return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){v_done_245, v_t_2414, v_ps_240, v_t_2418, v_t_2421});
}
V g_heff_2ebuild_2eload_2eloadDone_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eload_2eloadDone(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}

static V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_val;
static HEFF_ONCE g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_st;
static V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_init(void) {
  return heff_rec_n(2, shape_at__msg, (V[]){MK_INT(0LL), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_st)) return g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_val;
  return heff_global(&g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_val, &g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_st, g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_init);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_str2, 10, "package.hf");
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_entry, 4, 0};

V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708(V v_h_240, V v_ps_241, V v_z_242, V v_z_243) {
top: ;
  V v_st_244 = heff_dup(heff_rfield(v_ps_241, 5));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), heff_dup(heff_rfield(v_ps_241, 0))));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_s_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_248));
  V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_249); r_; });
  V v_a_2412 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_lam0_clo)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2417, v_z_242, heff_clo_n(g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_lam1, 1, 3, (V[]){v_z_243, v_h_240, v_ps_241})));
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_h_240);
    heff_drop_rec(v_ps_241, 6);
    V f_ = v_z_243;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2420 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    switch (heff_tag_of(v_y_2420)) {
    case TAG_Left: {
      heff_take_n(v_y_2420, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_h_240);
      heff_drop_rec(v_ps_241, 6);
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      V f_ = v_z_243;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2422 = heff_field(v_y_2420, 0);
      V v_ru_24y_2420_24Right = heff_take_reuse_n(v_y_2420, 1ULL, 1);
      heff_clo_take(self, 3);
      V v_h_2423 = v_h_240;
      V v_ps_2424 = v_ps_241;
      V v_root_2425 = heff_take_field(v_ps_2424, 0);
      V v_style_2426 = heff_get_n(v_ps_2424, 5, 6);
      V v_src_2427 = heff_dup(v_x_2422);
      HeffT2 v_t_2428 = ({ V a_0 = v_x_2422; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_x_2422); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        V v_x4_2433;
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          V v_p_2431 = v_field_2430;
          v_x4_2433 = heff_tag_at_n(v_ru_24y_2420_24Right, TAG_Left, 1, (V[]){v_p_2431});
        } else {
          heff_drop_cell(v_ru_24y_2420_24Right, 1);
          V v_x_2432 = v_field_2430;
          v_x4_2433 = ({ V a_0 = v_x_2432; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2432); r_; });
        }
        V v_t_2473;
        switch (heff_tag_of(v_x4_2433)) {
        case TAG_Left: {
          V v_p_2434 = heff_field(v_x4_2433, 0);
          V v_ru_24x4_2433_24Left = heff_take_reuse_n(v_x4_2433, 1ULL, 1);
          heff_drop_cell(v_ru_24x_2418_24Right, 1);
          heff_drop(v_h_2423);
          V v_d_2435 = v_root_2425;
          V v_st_2436 = v_style_2426;
          V v_t_2437 = (g_std_2epath_2eparse(heff_dup(v_st_2436), v_d_2435));
          V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_2436), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_str1)));
          V v_t_2439 = (g_std_2epath_2ejoin(v_t_2437, v_t_2438));
          V v_t_2440 = ({ V a_0 = v_st_2436; V a_1 = v_t_2439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); heff_drop(v_t_2439); r_; });
          V v_t_2441 = ({ V a_0 = v_t_2440; V a_1 = v_src_2427; V a_2 = v_p_2434; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2427); r_; });
          v_t_2473 = heff_tag_at_n(v_ru_24x4_2433_24Left, TAG_Left, 1, (V[]){v_t_2441});
          break;
        }
        case TAG_Right: {
          V v_pk_2442 = heff_field(v_x4_2433, 0);
          V v_ru_24x4_2433_24Right = heff_take_reuse_n(v_x4_2433, 1ULL, 1);
          if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2442, 0)), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
            V v_x1_2443 = (g_heff_2ebuild_2eload_2eheffAt(v_h_2423, heff_dup(v_root_2425)));
            if (!(heff_dup(v_x1_2443) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24x_2418_24Right, 1);
              heff_drop_rec(v_pk_2442, 4);
              heff_drop(v_x1_2443);
              V v_d_2444 = v_root_2425;
              V v_st_2445 = v_style_2426;
              V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2445), v_d_2444));
              V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2445), ((V)&g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_str2)));
              V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
              V v_t_2449 = ({ V a_0 = v_st_2445; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2445); heff_drop(v_t_2448); r_; });
              HeffT2 v_t_2450 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_src_2427));
              {
                V v_field_2452 = v_t_2450.f[1];
                int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                V v_t_2471;
                if ((v_tag_2451 == ((int64_t)0ULL))) {
                  V v_x11_2453 = v_field_2452;
                  heff_drop(v_x11_2453);
                  v_t_2471 = heff_dup(g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_get());
                } else {
                  V v_x_2454 = v_field_2452;
                  HeffT2 v_t_2455 = ({ V a_0 = heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()); V a_1 = v_x_2454; HeffT2 r_ = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(a_0, a_1)); heff_drop(v_x_2454); r_; });
                  {
                    V v_field_2457 = v_t_2455.f[1];
                    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
                    if ((v_tag_2456 == ((int64_t)0ULL))) {
                      V v_x_2458 = v_field_2457;
                      heff_drop(v_x_2458);
                      v_t_2471 = heff_dup(g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_get());
                    } else {
                      V v_x11_2459 = v_field_2457;
                      switch (heff_tag_of(v_x11_2459)) {
                      case TAG_Nil: {
                        v_t_2471 = heff_dup(g_heff_2ebuild_2eload_2ereadPackageAt_24s665509579x1514267708_24rec0_get());
                        break;
                      }
                      case TAG_Cons: {
                        V v_m_2460 = heff_field(v_x11_2459, 0);
                        heff_take_n(v_x11_2459, 1ULL, 2);
                        V v_t_2470;
                        switch (heff_tag_of(v_m_2460)) {
                        case TAG_LStr: {
                          V v_t_2463 = heff_field(v_m_2460, 1);
                          heff_take_n(v_m_2460, 2ULL, 2);
                          v_t_2470 = v_t_2463;
                          break;
                        }
                        case TAG_LTag: {
                          V v_t_2465 = heff_field(v_m_2460, 1);
                          heff_take_n(v_m_2460, 2ULL, 2);
                          v_t_2470 = v_t_2465;
                          break;
                        }
                        case TAG_LList: {
                          V v_t_2467 = heff_field(v_m_2460, 1);
                          heff_take_n(v_m_2460, 2ULL, 2);
                          v_t_2470 = v_t_2467;
                          break;
                        }
                        case TAG_LRec: {
                          V v_t_2469 = heff_field(v_m_2460, 1);
                          heff_take_n(v_m_2460, 2ULL, 2);
                          v_t_2470 = v_t_2469;
                          break;
                        }
                        default: heff_nomatch(v_m_2460);
                        }
                        v_t_2471 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2470, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2eclaimMsg_get())});
                        break;
                      }
                      default: heff_nomatch(v_x11_2459);
                      }
                    }
                  }
                }
                V v_t_2472 = ({ V a_0 = v_t_2449; V a_1 = v_src_2427; V a_2 = v_t_2471; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_src_2427); r_; });
                v_t_2473 = heff_tag_at_n(v_ru_24x4_2433_24Right, TAG_Left, 1, (V[]){v_t_2472});
              }
            } else {
              heff_drop(v_root_2425);
              heff_drop(v_style_2426);
              heff_drop(v_src_2427);
              heff_drop_cell(v_ru_24x4_2433_24Right, 1);
              heff_drop(v_x1_2443);
              v_t_2473 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Right, 1, (V[]){v_pk_2442});
            }
          } else {
            heff_drop(v_h_2423);
            heff_drop(v_root_2425);
            heff_drop(v_style_2426);
            heff_drop(v_src_2427);
            heff_drop_cell(v_ru_24x4_2433_24Right, 1);
            v_t_2473 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Right, 1, (V[]){v_pk_2442});
          }
          break;
        }
        default: heff_nomatch(v_x4_2433);
        }
        V v_x_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2473});
        V f_ = v_z_243;
        args[0] = v_x_2474;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_y_2420);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_str0, 5, ".hash");
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_entry, 6, 0};

V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_require_246 = heff_take_field(v_root_241, 2);
  V v_replace_247 = heff_get_n(v_root_241, 3, 4);
  V v_t_248 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_244, v_require_246));
  V v_t_2414;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_replace_247);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 2);
    V v_t_2411 = ({ V a_0 = v_r_249; V a_1 = v_replace_247; V r_ = (g_list_2ekeepIf_24s537296923x1092827761(a_0, a_1)); heff_drop(v_r_249); r_; });
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2412, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_t_2415 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_s_2416 = heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_str0));
    V v_path_2417 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2416));
    V v_t_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2417; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2417); r_; });
    V v_a_2420 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam0_clo)});
    return heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam1, 2, 6, (V[]){v_a_2420, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2433 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_d_2434 = heff_dup(heff_rfield(v_ps_240, 0));
    V v_st_2435 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2436 = (g_std_2epath_2eparse(heff_dup(v_st_2435), v_d_2434));
    V v_t_2437 = (g_std_2epath_2eparse(heff_dup(v_st_2435), v_d_2433));
    V v_t_2438 = (g_std_2epath_2ejoin(v_t_2436, v_t_2437));
    V v_t_2439 = ({ V a_0 = v_st_2435; V a_1 = v_t_2438; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2435); heff_drop(v_t_2438); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(v_ps_240, v_t_2439, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam0(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2422 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2421 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    V v_x_2429 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Left = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    heff_clo_take(self, 7);
    return (g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0(v_k_2422, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240, v_hd_2421, heff_tag_re_n(v_ru_24x_2428_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2429})));
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Right = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    switch (heff_tag_of(v_y_2430)) {
    case TAG_Left: {
      V v_err_2431 = heff_field(v_y_2430, 0);
      V v_ru_24y_2430_24Left = heff_take_reuse_n(v_y_2430, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2428_24Right, 1);
      heff_clo_take(self, 7);
      return (g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0(v_k_2422, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240, v_hd_2421, heff_tag_re_n(v_ru_24y_2430_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2431})));
    }
    case TAG_Right: {
      V v_x_2432 = heff_field(v_y_2430, 0);
      heff_take_n(v_y_2430, 1ULL, 1);
      heff_clo_take(self, 7);
      return (g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_2ek_24l0(v_k_2422, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240, v_hd_2421, heff_tag_at_n(v_ru_24x_2428_24Right, TAG_Right, 1, (V[]){v_x_2432})));
    }
    default: return heff_nomatch(v_y_2430);
    }
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_a_2420 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2427, heff_dup(v_hd_2421), heff_clo_n(g_heff_2ebuild_2eload_2ecachedPkg_24s818203292x1517564078_lam2, 1, 7, (V[]){v_k_2422, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240, v_hd_2421})));
}
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_str1, 3, "src");
V g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_entry, 4, 0};

V g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305(V v_ps_240, V v_root_241, V v_x_242, V v_pk_243) {
top: ;
  V v_require_244 = heff_take_field(v_pk_243, 2);
  V v_heff_245 = heff_get_n(v_pk_243, 1, 4);
  V v_path_246 = heff_take_field(v_x_242, 0);
  V v_version_247 = heff_get_n(v_x_242, 1, 3);
  V v_require_248 = heff_take_field(v_root_241, 2);
  V v_replace_249 = heff_get_n(v_root_241, 3, 4);
  V v_t_2410 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_246, v_require_248));
  V v_x_2421;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    heff_drop(v_replace_249);
    v_x_2421 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_246), v_version_247));
    break;
  }
  case TAG_Cons: {
    V v_r_2411 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 2);
    V v_t_2413 = ({ V a_0 = v_r_2411; V a_1 = v_replace_249; V r_ = (g_list_2ekeepIf_24s537296923x1092827761(a_0, a_1)); heff_drop(v_r_2411); r_; });
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      v_x_2421 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_246), v_version_247));
      break;
    }
    case TAG_Cons: {
      V v_p_2414 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 2);
      heff_drop(v_version_247);
      V v_d_2416 = heff_dup(heff_rfield(v_ps_240, 0));
      V v_st_2417 = heff_dup(heff_rfield(v_ps_240, 5));
      V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_d_2416));
      V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_get_n(v_p_2414, 1, 2)));
      V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
      v_x_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  return heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_lam0, 2, 5, (V[]){v_ps_240, v_x_2421, v_require_244, v_path_246, v_heff_245});
}
V g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_require_244 = heff_env(self)[2];
  V v_path_246 = heff_env(self)[3];
  V v_heff_245 = heff_env(self)[4];
  V v_k_2423 = heff_env(self)[5];
  V v_x_2439;
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_why_2431 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Left = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_x_2421);
    heff_drop(v_require_244);
    heff_drop(v_path_246);
    heff_drop(v_heff_245);
    v_x_2439 = heff_tag_re_n(v_ru_24x_2430_24Left, TAG_Left, 1, 1ULL, (V[]){v_why_2431});
    break;
  }
  case TAG_Right: {
    V v_name_2432 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Right = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    V v_st_2433 = heff_get_n(v_ps_240, 5, 6);
    V v_t_2434 = (g_std_2epath_2eparse(heff_dup(v_st_2433), heff_dup(v_x_2421)));
    V v_t_2435 = (g_std_2epath_2eparse(heff_dup(v_st_2433), ((V)&g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_str1)));
    V v_t_2436 = (g_std_2epath_2ejoin(v_t_2434, v_t_2435));
    V v_t_2437 = ({ V a_0 = v_st_2433; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2433); heff_drop(v_t_2436); r_; });
    V v_t_2438 = (g_list_2emap_24s18996220x10511024(v_require_244));
    v_x_2439 = heff_tag_at_n(v_ru_24x_2430_24Right, TAG_Right, 1, (V[]){heff_rec_n(7, shape_path__dir__src__own__top__heff__scope, (V[]){v_path_246, v_x_2421, v_t_2437, heff_dup(v_name_2432), v_name_2432, v_heff_245, v_t_2438})});
    break;
  }
  default: heff_nomatch(v_x_2430);
  }
  V f_ = v_k_2423;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_lam0(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_ps_240 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_require_244 = heff_env(self)[2];
  V v_path_246 = heff_env(self)[3];
  V v_heff_245 = heff_env(self)[4];
  V v_st_2424 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_2424), heff_dup(v_x_2421)));
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_2424), ((V)&g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_str0)));
  V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
  V v_t_2428 = ({ V a_0 = v_st_2424; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); heff_drop(v_t_2427); r_; });
  V v_t_2429 = (g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(heff_dup(v_ps_240), v_t_2428));
  heff_clo_take(self, 5);
  V f_ = v_t_2429;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305_lam1, 1, 6, (V[]){v_ps_240, v_x_2421, v_require_244, v_path_246, v_heff_245, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_entry, 5, 0};

V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615(V v_ps_240, V v_root_241, V v_x3_242, V v_acc_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam0, 2, 2, (V[]){heff_dup(v_acc_243), heff_dup(v_errs_244)});
  }
  case TAG_Cons: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_249 = heff_dup(heff_rfield(v_x31_247, 2));
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x31_247, 3);
      V t_0 = v_ps_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_acc_243;
      V t_4 = v_errs_244;
      v_ps_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_acc_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    }
    case TAG_Just: {
      V v_pk_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_c_2411 = (g_heff_2ebuild_2eload_2epkgOf_24s222584028x329622305(heff_dup(v_ps_240), heff_dup(v_root_241), v_x31_247, v_pk_2410));
      return heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam1, 2, 6, (V[]){v_c_2411, heff_dup(v_errs_244), heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_248, heff_dup(v_acc_243)});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615(a0, a1, a[2], a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_drop(v_hd_245);
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_errs_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_root_241 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2415, NTAG(TAG_Nil)});
    heff_clo_take(self, 7);
    V v_t_2417 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2416));
    V v_t_2418 = ({ V a_0 = v_ps_240; V a_1 = v_root_241; V a_2 = v_rest_248; V a_3 = v_acc_243; V a_4 = v_t_2417; V r_ = (g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ps_240); heff_drop(v_root_241); heff_drop(v_acc_243); heff_drop(v_t_2417); r_; });
    V f_ = v_t_2418;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_p_2419 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2419, NTAG(TAG_Nil)});
    heff_clo_take(self, 7);
    V v_t_2421 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2420));
    V v_t_2422 = ({ V a_0 = v_ps_240; V a_1 = v_root_241; V a_2 = v_rest_248; V a_3 = v_t_2421; V a_4 = v_errs_244; V r_ = (g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ps_240); heff_drop(v_root_241); heff_drop(v_t_2421); heff_drop(v_errs_244); r_; });
    V f_ = v_t_2422;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2epkgsOf_24s1709842309x1364471615_lam2, 1, 7, (V[]){v_errs_244, v_ps_240, v_root_241, v_rest_248, v_acc_243, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str2, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str7, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_entry, 8, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(V v_lit_240, V v_ps_241, V v_pkgs_242, V v_stack_243, V v_from_244, V v_x7_245, V v_st_246, V v_rs_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_stack_243);
    heff_drop(v_from_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam0, 2, 2, (V[]){v_st_246, v_rs_247});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_c_2413 = (g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559(v_t_2412));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam1, 2, 10, (V[]){v_c_2413, v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_st_246 = heff_env(self)[0];
  V v_rs_247 = heff_env(self)[1];
  heff_drop(v_hd_248);
  heff_clo_take(self, 2);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam4(V self, V *args) {
  V v_x_2472 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_module_2431 = heff_env(self)[1];
  V v_named_2435 = heff_env(self)[2];
  V v_path_2434 = heff_env(self)[3];
  V v_source_2433 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_w_2410 = heff_env(self)[6];
  V v_rs_247 = heff_env(self)[7];
  V v_pkgs_242 = heff_env(self)[8];
  V v_stack_243 = heff_env(self)[9];
  V v_from_244 = heff_env(self)[10];
  V v_rest_2411 = heff_env(self)[11];
  V v_hd_2414 = heff_env(self)[12];
  V v_k_2415 = heff_env(self)[13];
  V v_t_2475;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_x_2473 = heff_dup(heff_field(v_x_2472, 0));
    v_t_2475 = v_x_2473;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  V v_t_2478;
  switch (heff_tag_of(v_x_2472)) {
  case TAG_MkPair: {
    V v_y_2477 = heff_field(v_x_2472, 1);
    heff_take_n(v_x_2472, 2ULL, 2);
    v_t_2478 = v_y_2477;
    break;
  }
  default: heff_nomatch(v_x_2472);
  }
  heff_clo_take(self, 14);
  V v_t_2479 = (g_heff_2ebuild_2eload_2epushDone(v_t_2475, heff_dup(v_ps_241), heff_dup(v_module_2431), v_named_2435, v_path_2434, v_source_2433, heff_dup(v_lit_240), v_t_2478));
  V v_m_2480 = v_module_2431;
  V v_t_2481;
  if (heff_strEq_c_lent(v_w_2410, v_m_2480, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2480);
    v_t_2481 = v_rs_247;
  } else {
    v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2480}), v_rs_247});
  }
  V v_t_2482 = (g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2479, v_t_2481));
  V f_ = v_t_2482;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam3(V self, V *args) {
  V v_x_2456 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_source_2433 = heff_env(self)[1];
  V v_st_246 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_pkgs_242 = heff_env(self)[6];
  V v_module_2431 = heff_env(self)[7];
  V v_stack_243 = heff_env(self)[8];
  V v_path_2434 = heff_env(self)[9];
  V v_hd_2414 = heff_env(self)[10];
  V v_named_2435 = heff_env(self)[11];
  V v_rs_247 = heff_env(self)[12];
  V v_rest_2411 = heff_env(self)[13];
  V v_k_2415 = heff_env(self)[14];
  HeffT4 v_t_2457 = (g_heff_2esyntax_2eimport_2eimportsOf_24cpr(heff_dup(v_lit_240), v_source_2433));
  {
    V v_field_2458 = v_t_2457.f[0];
    heff_drop(v_t_2457.f[1]);
    heff_drop(v_t_2457.f[2]);
    heff_drop(v_t_2457.f[3]);
    V v_imps_2462 = v_field_2458;
    V v_t_2463 = (g_list_2emap_24s1817208647x1282894070(v_imps_2462));
    V v_t_2464 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2463));
    V v_t_2470;
    heff_clo_take(self, 15);
    switch (heff_tag_of(v_x_2456)) {
    case TAG_Nothing: {
      v_t_2470 = v_st_246;
      break;
    }
    case TAG_Just: {
      V v_why_2465 = heff_field(v_x_2456, 0);
      heff_take_n(v_x_2456, 1ULL, 1);
      V v_t_2466 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str9)), heff_dup(v_w_2410));
      V v_t_2467 = heff_strAppend(heff_strAppend(v_t_2466, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str10)), v_why_2465);
      V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
      V v_t_2469 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2468));
      v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      break;
    }
    default: heff_nomatch(v_x_2456);
    }
    V v_t_2471 = (g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(heff_dup(v_lit_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2431), heff_dup(v_stack_243)}), heff_dup(v_path_2434), v_t_2464, v_t_2470, NTAG(TAG_Nil)));
    V f_ = v_t_2471;
    heff_room[0] = heff_dup(v_hd_2414);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam4, 1, 14, (V[]){v_ps_241, v_module_2431, v_named_2435, v_path_2434, v_source_2433, v_lit_240, v_w_2410, v_rs_247, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_hd_2414, v_k_2415});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_pkgs_242 = heff_env(self)[1];
  V v_from_244 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_stack_243 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_hd_2414 = heff_env(self)[9];
  V v_k_2415 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nil: {
    V v_places_2417 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_241), heff_dup(v_pkgs_242), heff_dup(v_from_244), heff_dup(v_w_2410)));
    V v_x2_2418 = (g_list_2emap_24s435407392x1528135477(v_places_2417));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str1); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    heff_clo_take(self, 11);
    V v_t_2422 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str2)), v_w_2410);
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str3)), v_t_2421);
    V v_e_2424 = heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str4));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2424, NTAG(TAG_Nil)});
    V v_t_2426 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2425));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2428 = (g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2427, v_rs_247));
    V f_ = v_t_2428;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2429 = heff_dup(heff_field(v_x_2416, 0));
    V v_others_2430 = heff_dup(heff_field(v_x_2416, 1));
    V v_module_2431 = heff_take_field(v_f_2429, 3);
    V v_place_2432 = heff_take_field(v_f_2429, 2);
    V v_source_2433 = heff_take_field(v_f_2429, 1);
    V v_path_2434 = heff_take_field(v_f_2429, 0);
    V v_named_2435 = heff_get_n(v_f_2429, 4, 5);
    V v_t_2436 = (g_list_2eany_24s1006624359x760861690(v_module_2431, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2416, 2);
      heff_drop(v_others_2430);
      heff_drop_rec(v_place_2432, 4);
      heff_drop(v_source_2433);
      heff_drop(v_path_2434);
      heff_drop(v_named_2435);
      heff_drop(v_t_2436);
      V v_m_2437 = v_module_2431;
      V v_t_2438;
      heff_clo_take(self, 11);
      if (heff_strEq_c_lent(v_w_2410, v_m_2437, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2437);
        v_t_2438 = v_rs_247;
      } else {
        v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2437}), v_rs_247});
      }
      V v_t_2439 = (g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_st_246, v_t_2438));
      V f_ = v_t_2439;
      heff_room[0] = v_hd_2414;
      heff_room[1] = v_k_2415;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2436);
      V v_t_2440 = (g_list_2eany_24s1006624359x760861690(v_module_2431, v_stack_243));
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2416, 2);
        heff_drop(v_others_2430);
        heff_drop_rec(v_place_2432, 4);
        heff_drop(v_source_2433);
        heff_drop(v_path_2434);
        heff_drop(v_named_2435);
        heff_drop(v_t_2440);
        V v_m_2441 = heff_dup(v_module_2431);
        V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_243)));
        V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2441), NTAG(TAG_Nil)});
        V v_x2_2444 = (g_prelude_2e_2b_2b(v_t_2442, v_t_2443));
        V v_t_2447;
        switch (heff_tag_of(v_x2_2444)) {
        case TAG_Nil: {
          v_t_2447 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2445 = heff_field(v_x2_2444, 0);
          V v_xs_2446 = heff_field(v_x2_2444, 1);
          heff_take_n(v_x2_2444, 3ULL, 2);
          v_t_2447 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str6); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2444);
        }
        V v_t_2448 = heff_strAppend(heff_strAppend(heff_dup(v_from_244), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str7)), v_m_2441);
        V v_e_2449 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_str8)), v_t_2447);
        V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2449, NTAG(TAG_Nil)});
        heff_clo_take(self, 11);
        V v_t_2451 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2450));
        V v_m_2452 = v_module_2431;
        V v_t_2453;
        if (heff_strEq_c_lent(v_w_2410, v_m_2452, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2452);
          v_t_2453 = v_rs_247;
        } else {
          v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2452}), v_rs_247});
        }
        V v_t_2454 = ({ V rv_2 = v_t_2451; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2455 = (g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2454, v_t_2453));
        V f_ = v_t_2455;
        heff_room[0] = v_hd_2414;
        heff_room[1] = v_k_2415;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2440);
        switch (heff_tag_of(v_others_2430)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2416, 2);
          heff_clo_take(self, 11);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(heff_dup(v_ps_241), heff_dup(heff_rfield(v_place_2432, 1)), heff_get_n(v_place_2432, 2, 4), heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam3, 1, 15, (V[]){v_lit_240, v_source_2433, v_st_246, v_from_244, v_w_2410, v_ps_241, v_pkgs_242, v_module_2431, v_stack_243, v_path_2434, v_hd_2414, v_named_2435, v_rs_247, v_rest_2411, v_k_2415})));
        }
        case TAG_Cons: {
          V v_ru_24others_2430_24Cons = heff_take_reuse_n(v_others_2430, 0ULL, 2);
          heff_drop_rec(v_place_2432, 4);
          heff_drop(v_source_2433);
          heff_drop(v_path_2434);
          heff_drop(v_named_2435);
          V v_e_2485 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_241), v_x_2416, heff_dup(v_from_244), heff_dup(v_w_2410)));
          heff_clo_take(self, 11);
          V v_t_2486 = heff_take_field(v_st_246, 0);
          V v_t_2487 = heff_take_field(v_st_246, 1);
          V v_t_2488 = heff_tag_at_n(v_ru_24others_2430_24Cons, TAG_Cons, 2, (V[]){v_e_2485, NTAG(TAG_Nil)});
          V v_t_2489 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2488));
          V v_m_2490 = heff_dup(v_module_2431);
          V v_t_2491;
          if (heff_strEq_c_lent(v_w_2410, v_m_2490, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2490);
            v_t_2491 = v_rs_247;
          } else {
            v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2490}), v_rs_247});
          }
          V v_t_2492 = ({ V rv_0 = v_t_2486; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_module_2431, v_t_2487}); V rv_2 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_st_246, 0ULL, 3, shape_done__doneMods__errors, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_2493 = (g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821(v_lit_240, v_ps_241, v_pkgs_242, v_stack_243, v_from_244, v_rest_2411, v_t_2492, v_t_2491));
          V f_ = v_t_2493;
          heff_room[0] = v_hd_2414;
          heff_room[1] = v_k_2415;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2430);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_pkgs_242 = heff_env(self)[2];
  V v_from_244 = heff_env(self)[3];
  V v_w_2410 = heff_env(self)[4];
  V v_st_246 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_stack_243 = heff_env(self)[7];
  V v_rest_2411 = heff_env(self)[8];
  V v_rs_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s715394092x318644821_lam2, 1, 11, (V[]){v_ps_241, v_pkgs_242, v_from_244, v_w_2410, v_st_246, v_lit_240, v_stack_243, v_rest_2411, v_rs_247, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str2, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str7, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_entry, 10, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(V v_ps_240, V v_pkgs_241, V v_stack_242, V v_from_243, V v_imp_244, V v_x7_245, V v_st_246, V v_rs_247, V v_z_248, V v_z_249) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_pkgs_241);
    heff_drop(v_stack_242);
    heff_drop(v_from_243);
    heff_drop(v_imp_244);
    heff_drop(v_z_248);
    return heff_tail(v_z_249, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_st_246, v_rs_247})});
  }
  case TAG_Cons: {
    V v_w_2410 = heff_field(v_x7_245, 0);
    V v_rest_2411 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2412 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_c_2413 = (g_heff_2ebuild_2eload_2ereadEvery_24s1966291395x1443905559(v_t_2412));
    return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam0, 1, 11, (V[]){v_ps_240, v_pkgs_241, v_from_243, v_w_2410, v_st_246, v_stack_242, v_imp_244, v_rest_2411, v_rs_247, v_z_248, v_z_249})});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam2(V self, V *args) {
  V v_x_2467 = args[0];
  V v_imp_244 = heff_env(self)[0];
  V v_module_2428 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_named_2432 = heff_env(self)[3];
  V v_path_2431 = heff_env(self)[4];
  V v_source_2430 = heff_env(self)[5];
  V v_w_2410 = heff_env(self)[6];
  V v_rs_247 = heff_env(self)[7];
  V v_pkgs_241 = heff_env(self)[8];
  V v_stack_242 = heff_env(self)[9];
  V v_from_243 = heff_env(self)[10];
  V v_rest_2411 = heff_env(self)[11];
  V v_z_248 = heff_env(self)[12];
  V v_z_249 = heff_env(self)[13];
  V v_t_2470;
  switch (heff_tag_of(v_x_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_dup(heff_field(v_x_2467, 0));
    v_t_2470 = v_x_2468;
    break;
  }
  default: heff_nomatch(v_x_2467);
  }
  V v_t_2471 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(v_module_2428)}));
  V v_t_2474;
  switch (heff_tag_of(v_x_2467)) {
  case TAG_MkPair: {
    V v_y_2473 = heff_field(v_x_2467, 1);
    heff_take_n(v_x_2467, 2ULL, 2);
    v_t_2474 = v_y_2473;
    break;
  }
  default: heff_nomatch(v_x_2467);
  }
  heff_clo_take(self, 14);
  V v_t_2475 = (g_heff_2ebuild_2eload_2epushDone(v_t_2470, heff_dup(v_ps_240), heff_dup(v_module_2428), v_named_2432, v_path_2431, v_source_2430, v_t_2471, v_t_2474));
  V v_m_2476 = v_module_2428;
  V v_t_2477;
  if (heff_strEq_c_lent(v_w_2410, v_m_2476, 0)) {
    heff_drop(v_w_2410);
    heff_drop(v_m_2476);
    v_t_2477 = v_rs_247;
  } else {
    v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2476}), v_rs_247});
  }
  return (g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2475, v_t_2477, v_z_248, v_z_249));
}
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam1(V self, V *args) {
  V v_x_2451 = args[0];
  V v_imp_244 = heff_env(self)[0];
  V v_module_2428 = heff_env(self)[1];
  V v_source_2430 = heff_env(self)[2];
  V v_st_246 = heff_env(self)[3];
  V v_from_243 = heff_env(self)[4];
  V v_w_2410 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  V v_pkgs_241 = heff_env(self)[7];
  V v_stack_242 = heff_env(self)[8];
  V v_path_2431 = heff_env(self)[9];
  V v_z_248 = heff_env(self)[10];
  V v_named_2432 = heff_env(self)[11];
  V v_rs_247 = heff_env(self)[12];
  V v_rest_2411 = heff_env(self)[13];
  V v_z_249 = heff_env(self)[14];
  V v_t_2452 = heff_tr(heff_call(heff_dup(v_imp_244), 1, (V[]){heff_dup(v_module_2428)}));
  HeffT4 v_t_2453 = (g_heff_2esyntax_2eimport_2eimportsOf_24cpr(v_t_2452, v_source_2430));
  {
    V v_field_2454 = v_t_2453.f[0];
    heff_drop(v_t_2453.f[1]);
    heff_drop(v_t_2453.f[2]);
    heff_drop(v_t_2453.f[3]);
    V v_imps_2458 = v_field_2454;
    V v_t_2459 = (g_list_2emap_24s1817208647x1282894070(v_imps_2458));
    V v_t_2460 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2459));
    V v_t_2466;
    heff_clo_take(self, 15);
    switch (heff_tag_of(v_x_2451)) {
    case TAG_Nothing: {
      v_t_2466 = v_st_246;
      break;
    }
    case TAG_Just: {
      V v_why_2461 = heff_field(v_x_2451, 0);
      heff_take_n(v_x_2451, 1ULL, 1);
      V v_t_2462 = heff_strAppend(heff_strAppend(heff_dup(v_from_243), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str9)), heff_dup(v_w_2410));
      V v_t_2463 = heff_strAppend(heff_strAppend(v_t_2462, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str10)), v_why_2461);
      V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
      V v_t_2465 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2464));
      v_t_2466 = ({ V rv_2 = v_t_2465; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      break;
    }
    default: heff_nomatch(v_x_2451);
    }
    return (g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2428), heff_dup(v_stack_242)}), heff_dup(v_path_2431), heff_dup(v_imp_244), v_t_2460, v_t_2466, NTAG(TAG_Nil), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam2, 1, 14, (V[]){v_imp_244, v_module_2428, v_ps_240, v_named_2432, v_path_2431, v_source_2430, v_w_2410, v_rs_247, v_pkgs_241, v_stack_242, v_from_243, v_rest_2411, v_z_248, v_z_249})));
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_pkgs_241 = heff_env(self)[1];
  V v_from_243 = heff_env(self)[2];
  V v_w_2410 = heff_env(self)[3];
  V v_st_246 = heff_env(self)[4];
  V v_stack_242 = heff_env(self)[5];
  V v_imp_244 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_rs_247 = heff_env(self)[8];
  V v_z_248 = heff_env(self)[9];
  V v_z_249 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nil: {
    V v_places_2415 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_240), heff_dup(v_pkgs_241), heff_dup(v_from_243), heff_dup(v_w_2410)));
    V v_x2_2416 = (g_list_2emap_24s435407392x1528135477(v_places_2415));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str1); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    heff_clo_take(self, 11);
    V v_t_2420 = heff_strAppend(heff_strAppend(heff_dup(v_from_243), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str2)), v_w_2410);
    V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str3)), v_t_2419);
    V v_e_2422 = heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str4));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2422, NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2423));
    V v_t_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return (g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2425, v_rs_247, v_z_248, v_z_249));
  }
  case TAG_Cons: {
    V v_f_2426 = heff_dup(heff_field(v_x_2414, 0));
    V v_others_2427 = heff_dup(heff_field(v_x_2414, 1));
    V v_module_2428 = heff_take_field(v_f_2426, 3);
    V v_place_2429 = heff_take_field(v_f_2426, 2);
    V v_source_2430 = heff_take_field(v_f_2426, 1);
    V v_path_2431 = heff_take_field(v_f_2426, 0);
    V v_named_2432 = heff_get_n(v_f_2426, 4, 5);
    V v_t_2433 = (g_list_2eany_24s1006624359x760861690(v_module_2428, heff_rfield(v_st_246, 1)));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2414, 2);
      heff_drop(v_others_2427);
      heff_drop_rec(v_place_2429, 4);
      heff_drop(v_source_2430);
      heff_drop(v_path_2431);
      heff_drop(v_named_2432);
      heff_drop(v_t_2433);
      V v_m_2434 = v_module_2428;
      V v_t_2435;
      heff_clo_take(self, 11);
      if (heff_strEq_c_lent(v_w_2410, v_m_2434, 0)) {
        heff_drop(v_w_2410);
        heff_drop(v_m_2434);
        v_t_2435 = v_rs_247;
      } else {
        v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2434}), v_rs_247});
      }
      return (g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_st_246, v_t_2435, v_z_248, v_z_249));
    } else {
      heff_drop(v_t_2433);
      V v_t_2436 = (g_list_2eany_24s1006624359x760861690(v_module_2428, v_stack_242));
      if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2414, 2);
        heff_drop(v_others_2427);
        heff_drop_rec(v_place_2429, 4);
        heff_drop(v_source_2430);
        heff_drop(v_path_2431);
        heff_drop(v_named_2432);
        heff_drop(v_t_2436);
        V v_m_2437 = heff_dup(v_module_2428);
        V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_242)));
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2437), NTAG(TAG_Nil)});
        V v_x2_2440 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2439));
        V v_t_2443;
        switch (heff_tag_of(v_x2_2440)) {
        case TAG_Nil: {
          v_t_2443 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2441 = heff_field(v_x2_2440, 0);
          V v_xs_2442 = heff_field(v_x2_2440, 1);
          heff_take_n(v_x2_2440, 3ULL, 2);
          v_t_2443 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str6); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2440);
        }
        V v_t_2444 = heff_strAppend(heff_strAppend(heff_dup(v_from_243), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str7)), v_m_2437);
        V v_e_2445 = heff_strAppend(heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_str8)), v_t_2443);
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2445, NTAG(TAG_Nil)});
        heff_clo_take(self, 11);
        V v_t_2447 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2446));
        V v_m_2448 = v_module_2428;
        V v_t_2449;
        if (heff_strEq_c_lent(v_w_2410, v_m_2448, 0)) {
          heff_drop(v_w_2410);
          heff_drop(v_m_2448);
          v_t_2449 = v_rs_247;
        } else {
          v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2448}), v_rs_247});
        }
        V v_t_2450 = ({ V rv_2 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_st_246, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        return (g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2450, v_t_2449, v_z_248, v_z_249));
      } else {
        heff_drop(v_t_2436);
        switch (heff_tag_of(v_others_2427)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2414, 2);
          heff_clo_take(self, 11);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(heff_dup(v_ps_240), heff_dup(heff_rfield(v_place_2429, 1)), heff_get_n(v_place_2429, 2, 4), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746_lam1, 1, 15, (V[]){v_imp_244, v_module_2428, v_source_2430, v_st_246, v_from_243, v_w_2410, v_ps_240, v_pkgs_241, v_stack_242, v_path_2431, v_z_248, v_named_2432, v_rs_247, v_rest_2411, v_z_249})));
        }
        case TAG_Cons: {
          V v_ru_24others_2427_24Cons = heff_take_reuse_n(v_others_2427, 0ULL, 2);
          heff_drop_rec(v_place_2429, 4);
          heff_drop(v_source_2430);
          heff_drop(v_path_2431);
          heff_drop(v_named_2432);
          V v_e_2480 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_240), v_x_2414, heff_dup(v_from_243), heff_dup(v_w_2410)));
          heff_clo_take(self, 11);
          V v_t_2481 = heff_take_field(v_st_246, 0);
          V v_t_2482 = heff_take_field(v_st_246, 1);
          V v_t_2483 = heff_tag_at_n(v_ru_24others_2427_24Cons, TAG_Cons, 2, (V[]){v_e_2480, NTAG(TAG_Nil)});
          V v_t_2484 = (g_prelude_2e_2b_2b(heff_take_field(v_st_246, 2), v_t_2483));
          V v_m_2485 = heff_dup(v_module_2428);
          V v_t_2486;
          if (heff_strEq_c_lent(v_w_2410, v_m_2485, 0)) {
            heff_drop(v_w_2410);
            heff_drop(v_m_2485);
            v_t_2486 = v_rs_247;
          } else {
            v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2410, v_m_2485}), v_rs_247});
          }
          V v_t_2487 = ({ V rv_0 = v_t_2481; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_module_2428, v_t_2482}); V rv_2 = v_t_2484; V rr_ = heff_rec_reuse_nf(v_st_246, 0ULL, 3, shape_done__doneMods__errors, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          return (g_heff_2ebuild_2eload_2eloadMany_24s477091101x1985252746(v_ps_240, v_pkgs_241, v_stack_242, v_from_243, v_imp_244, v_rest_2411, v_t_2487, v_t_2486, v_z_248, v_z_249));
        }
        default: return heff_nomatch(v_others_2427);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_entry, 5, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018(V v_rd_240, V v_root_241, V v_x3_242, V v_seen_243, V v_errs_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam0, 2, 2, (V[]){heff_dup(v_seen_243), heff_dup(v_errs_244)});
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x3_242, 0);
    V v_rest_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_path_249 = heff_take_field(v_n_247, 1);
    V v_version_2410 = heff_take_field(v_n_247, 2);
    V v_by_2411 = heff_get_n(v_n_247, 0, 3);
    if (heff_strEq_c_lent(v_path_249, v_root_241, 0)) {
      heff_drop(v_path_249);
      heff_drop(v_version_2410);
      heff_drop(v_by_2411);
      V t_0 = v_rd_240;
      V t_1 = v_root_241;
      V t_2 = v_rest_248;
      V t_3 = v_seen_243;
      V t_4 = v_errs_244;
      v_rd_240 = t_0;
      v_root_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      v_errs_244 = t_4;
      goto top;
    } else {
      V v_t_2412 = (g_list_2eany_24s241416889x826324235(v_path_249, v_version_2410, v_seen_243));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_path_249);
        heff_drop(v_version_2410);
        heff_drop(v_by_2411);
        heff_drop(v_t_2412);
        V t_0 = v_rd_240;
        V t_1 = v_root_241;
        V t_2 = v_rest_248;
        V t_3 = v_seen_243;
        V t_4 = v_errs_244;
        v_rd_240 = t_0;
        v_root_241 = t_1;
        v_x3_242 = t_2;
        v_seen_243 = t_3;
        v_errs_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2412);
        V v_c_2413 = heff_tr(heff_call(heff_dup(v_rd_240), 3, (V[]){v_by_2411, heff_dup(v_path_249), heff_dup(v_version_2410)}));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam1, 2, 8, (V[]){v_c_2413, v_path_249, v_version_2410, heff_dup(v_seen_243), heff_dup(v_errs_244), heff_dup(v_rd_240), heff_dup(v_root_241), v_rest_248});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018(a0, a1, a[2], a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_seen_243 = heff_env(self)[0];
  V v_errs_244 = heff_env(self)[1];
  heff_drop(v_hd_245);
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_243, v_errs_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_path_249 = heff_env(self)[0];
  V v_version_2410 = heff_env(self)[1];
  V v_seen_243 = heff_env(self)[2];
  V v_errs_244 = heff_env(self)[3];
  V v_rd_240 = heff_env(self)[4];
  V v_root_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_why_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    heff_clo_take(self, 9);
    V v_t_2418 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_249, v_version_2410, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_t_2420 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2419));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2417, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_errs_244, v_t_2421));
    V v_t_2423 = ({ V a_0 = v_rd_240; V a_1 = v_root_241; V a_2 = v_rest_248; V a_3 = v_t_2420; V a_4 = v_t_2422; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rd_240); heff_drop(v_root_241); heff_drop(v_t_2420); heff_drop(v_t_2422); r_; });
    V f_ = v_t_2423;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2424 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    V v_t_2425 = heff_strAppend(heff_strAppend(heff_dup(v_path_249), ((V)&g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_str0)), heff_dup(v_version_2410));
    V v_t_2426 = (g_list_2emap_24s675147852x248982264(v_t_2425, heff_dup(heff_rfield(v_pk_2424, 2))));
    heff_clo_take(self, 9);
    V v_t_2427 = (g_prelude_2e_2b_2b(v_rest_248, v_t_2426));
    V v_t_2428 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_249, v_version_2410, heff_tag_n(TAG_Just, 1, (V[]){v_pk_2424})});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    V v_t_2430 = (g_prelude_2e_2b_2b(v_seen_243, v_t_2429));
    V v_t_2431 = ({ V a_0 = v_rd_240; V a_1 = v_root_241; V a_2 = v_t_2427; V a_3 = v_t_2430; V a_4 = v_errs_244; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rd_240); heff_drop(v_root_241); heff_drop(v_t_2430); heff_drop(v_errs_244); r_; });
    V f_ = v_t_2431;
    heff_room[0] = v_hd_2414;
    heff_room[1] = v_k_2415;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_path_249 = heff_env(self)[1];
  V v_version_2410 = heff_env(self)[2];
  V v_seen_243 = heff_env(self)[3];
  V v_errs_244 = heff_env(self)[4];
  V v_rd_240 = heff_env(self)[5];
  V v_root_241 = heff_env(self)[6];
  V v_rest_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_lam2, 1, 9, (V[]){v_path_249, v_version_2410, v_seen_243, v_errs_244, v_rd_240, v_root_241, v_rest_248, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str2, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str6, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str7, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_entry, 9, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(V v_lit_240, V v_read_241, V v_ps_242, V v_pkgs_243, V v_stack_244, V v_from_245, V v_x7_246, V v_st_247, V v_rs_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_read_241);
    heff_drop(v_ps_242);
    heff_drop(v_pkgs_243);
    heff_drop(v_stack_244);
    heff_drop(v_from_245);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam0, 2, 2, (V[]){v_st_247, v_rs_248});
  }
  case TAG_Cons: {
    V v_w_2411 = heff_field(v_x7_246, 0);
    V v_rest_2412 = heff_field(v_x7_246, 1);
    heff_take_n(v_x7_246, 3ULL, 2);
    V v_t_2413 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_c_2414 = (g_heff_2ebuild_2eload_2ereadEvery_24s2013036888x1467435889(heff_dup(v_read_241), v_t_2413));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam1, 2, 11, (V[]){v_c_2414, v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_st_247 = heff_env(self)[0];
  V v_rs_248 = heff_env(self)[1];
  heff_drop(v_hd_249);
  heff_clo_take(self, 2);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_247, v_rs_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam4(V self, V *args) {
  V v_x_2473 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_module_2432 = heff_env(self)[1];
  V v_named_2436 = heff_env(self)[2];
  V v_path_2435 = heff_env(self)[3];
  V v_source_2434 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_w_2411 = heff_env(self)[6];
  V v_rs_248 = heff_env(self)[7];
  V v_read_241 = heff_env(self)[8];
  V v_pkgs_243 = heff_env(self)[9];
  V v_stack_244 = heff_env(self)[10];
  V v_from_245 = heff_env(self)[11];
  V v_rest_2412 = heff_env(self)[12];
  V v_hd_2415 = heff_env(self)[13];
  V v_k_2416 = heff_env(self)[14];
  V v_t_2476;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_MkPair: {
    V v_x_2474 = heff_dup(heff_field(v_x_2473, 0));
    v_t_2476 = v_x_2474;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_t_2479;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_MkPair: {
    V v_y_2478 = heff_field(v_x_2473, 1);
    heff_take_n(v_x_2473, 2ULL, 2);
    v_t_2479 = v_y_2478;
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  heff_clo_take(self, 15);
  V v_t_2480 = (g_heff_2ebuild_2eload_2epushDone(v_t_2476, heff_dup(v_ps_242), heff_dup(v_module_2432), v_named_2436, v_path_2435, v_source_2434, heff_dup(v_lit_240), v_t_2479));
  V v_m_2481 = v_module_2432;
  V v_t_2482;
  if (heff_strEq_c_lent(v_w_2411, v_m_2481, 0)) {
    heff_drop(v_w_2411);
    heff_drop(v_m_2481);
    v_t_2482 = v_rs_248;
  } else {
    v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2481}), v_rs_248});
  }
  V v_t_2483 = (g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2480, v_t_2482));
  V f_ = v_t_2483;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam3(V self, V *args) {
  V v_x_2457 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_source_2434 = heff_env(self)[1];
  V v_st_247 = heff_env(self)[2];
  V v_from_245 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_read_241 = heff_env(self)[5];
  V v_ps_242 = heff_env(self)[6];
  V v_pkgs_243 = heff_env(self)[7];
  V v_module_2432 = heff_env(self)[8];
  V v_stack_244 = heff_env(self)[9];
  V v_path_2435 = heff_env(self)[10];
  V v_hd_2415 = heff_env(self)[11];
  V v_named_2436 = heff_env(self)[12];
  V v_rs_248 = heff_env(self)[13];
  V v_rest_2412 = heff_env(self)[14];
  V v_k_2416 = heff_env(self)[15];
  HeffT4 v_t_2458 = (g_heff_2esyntax_2eimport_2eimportsOf_24cpr(heff_dup(v_lit_240), v_source_2434));
  {
    V v_field_2459 = v_t_2458.f[0];
    heff_drop(v_t_2458.f[1]);
    heff_drop(v_t_2458.f[2]);
    heff_drop(v_t_2458.f[3]);
    V v_imps_2463 = v_field_2459;
    V v_t_2464 = (g_list_2emap_24s1817208647x1282894070(v_imps_2463));
    V v_t_2465 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2464));
    V v_t_2471;
    heff_clo_take(self, 16);
    switch (heff_tag_of(v_x_2457)) {
    case TAG_Nothing: {
      v_t_2471 = v_st_247;
      break;
    }
    case TAG_Just: {
      V v_why_2466 = heff_field(v_x_2457, 0);
      heff_take_n(v_x_2457, 1ULL, 1);
      V v_t_2467 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str9)), heff_dup(v_w_2411));
      V v_t_2468 = heff_strAppend(heff_strAppend(v_t_2467, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str10)), v_why_2466);
      V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
      V v_t_2470 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2469));
      v_t_2471 = ({ V rv_2 = v_t_2470; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      break;
    }
    default: heff_nomatch(v_x_2457);
    }
    V v_t_2472 = (g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(heff_dup(v_lit_240), heff_dup(v_read_241), heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2432), heff_dup(v_stack_244)}), heff_dup(v_path_2435), v_t_2465, v_t_2471, NTAG(TAG_Nil)));
    V f_ = v_t_2472;
    heff_room[0] = heff_dup(v_hd_2415);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam4, 1, 15, (V[]){v_ps_242, v_module_2432, v_named_2436, v_path_2435, v_source_2434, v_lit_240, v_w_2411, v_rs_248, v_read_241, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_hd_2415, v_k_2416});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_242 = heff_env(self)[0];
  V v_pkgs_243 = heff_env(self)[1];
  V v_from_245 = heff_env(self)[2];
  V v_w_2411 = heff_env(self)[3];
  V v_st_247 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_read_241 = heff_env(self)[6];
  V v_stack_244 = heff_env(self)[7];
  V v_rest_2412 = heff_env(self)[8];
  V v_rs_248 = heff_env(self)[9];
  V v_hd_2415 = heff_env(self)[10];
  V v_k_2416 = heff_env(self)[11];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    V v_places_2418 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_242), heff_dup(v_pkgs_243), heff_dup(v_from_245), heff_dup(v_w_2411)));
    V v_x2_2419 = (g_list_2emap_24s435407392x1528135477(v_places_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str1); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    heff_clo_take(self, 12);
    V v_t_2423 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str2)), v_w_2411);
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str3)), v_t_2422);
    V v_e_2425 = heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str4));
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2426));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2429 = (g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2428, v_rs_248));
    V f_ = v_t_2429;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2430 = heff_dup(heff_field(v_x_2417, 0));
    V v_others_2431 = heff_dup(heff_field(v_x_2417, 1));
    V v_module_2432 = heff_take_field(v_f_2430, 3);
    V v_place_2433 = heff_take_field(v_f_2430, 2);
    V v_source_2434 = heff_take_field(v_f_2430, 1);
    V v_path_2435 = heff_take_field(v_f_2430, 0);
    V v_named_2436 = heff_get_n(v_f_2430, 4, 5);
    V v_t_2437 = (g_list_2eany_24s1006624359x760861690(v_module_2432, heff_rfield(v_st_247, 1)));
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2417, 2);
      heff_drop(v_others_2431);
      heff_drop_rec(v_place_2433, 4);
      heff_drop(v_source_2434);
      heff_drop(v_path_2435);
      heff_drop(v_named_2436);
      heff_drop(v_t_2437);
      V v_m_2438 = v_module_2432;
      V v_t_2439;
      heff_clo_take(self, 12);
      if (heff_strEq_c_lent(v_w_2411, v_m_2438, 0)) {
        heff_drop(v_w_2411);
        heff_drop(v_m_2438);
        v_t_2439 = v_rs_248;
      } else {
        v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2438}), v_rs_248});
      }
      V v_t_2440 = (g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_st_247, v_t_2439));
      V f_ = v_t_2440;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2437);
      V v_t_2441 = (g_list_2eany_24s1006624359x760861690(v_module_2432, v_stack_244));
      if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2417, 2);
        heff_drop(v_others_2431);
        heff_drop_rec(v_place_2433, 4);
        heff_drop(v_source_2434);
        heff_drop(v_path_2435);
        heff_drop(v_named_2436);
        heff_drop(v_t_2441);
        V v_m_2442 = heff_dup(v_module_2432);
        V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_244)));
        V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_m_2442), NTAG(TAG_Nil)});
        V v_x2_2445 = (g_prelude_2e_2b_2b(v_t_2443, v_t_2444));
        V v_t_2448;
        switch (heff_tag_of(v_x2_2445)) {
        case TAG_Nil: {
          v_t_2448 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2446 = heff_field(v_x2_2445, 0);
          V v_xs_2447 = heff_field(v_x2_2445, 1);
          heff_take_n(v_x2_2445, 3ULL, 2);
          v_t_2448 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str6); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2445);
        }
        V v_t_2449 = heff_strAppend(heff_strAppend(heff_dup(v_from_245), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str7)), v_m_2442);
        V v_e_2450 = heff_strAppend(heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_str8)), v_t_2448);
        V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2450, NTAG(TAG_Nil)});
        heff_clo_take(self, 12);
        V v_t_2452 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2451));
        V v_m_2453 = v_module_2432;
        V v_t_2454;
        if (heff_strEq_c_lent(v_w_2411, v_m_2453, 0)) {
          heff_drop(v_w_2411);
          heff_drop(v_m_2453);
          v_t_2454 = v_rs_248;
        } else {
          v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2453}), v_rs_248});
        }
        V v_t_2455 = ({ V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_st_247, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2456 = (g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2455, v_t_2454));
        V f_ = v_t_2456;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2441);
        switch (heff_tag_of(v_others_2431)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2417, 2);
          heff_clo_take(self, 12);
          return (g_heff_2ebuild_2eload_2epartsNamed_24s994909413x946069472(heff_dup(v_ps_242), heff_dup(heff_rfield(v_place_2433, 1)), heff_get_n(v_place_2433, 2, 4), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam3, 1, 16, (V[]){v_lit_240, v_source_2434, v_st_247, v_from_245, v_w_2411, v_read_241, v_ps_242, v_pkgs_243, v_module_2432, v_stack_244, v_path_2435, v_hd_2415, v_named_2436, v_rs_248, v_rest_2412, v_k_2416})));
        }
        case TAG_Cons: {
          V v_ru_24others_2431_24Cons = heff_take_reuse_n(v_others_2431, 0ULL, 2);
          heff_drop_rec(v_place_2433, 4);
          heff_drop(v_source_2434);
          heff_drop(v_path_2435);
          heff_drop(v_named_2436);
          V v_e_2486 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_242), v_x_2417, heff_dup(v_from_245), heff_dup(v_w_2411)));
          heff_clo_take(self, 12);
          V v_t_2487 = heff_take_field(v_st_247, 0);
          V v_t_2488 = heff_take_field(v_st_247, 1);
          V v_t_2489 = heff_tag_at_n(v_ru_24others_2431_24Cons, TAG_Cons, 2, (V[]){v_e_2486, NTAG(TAG_Nil)});
          V v_t_2490 = (g_prelude_2e_2b_2b(heff_take_field(v_st_247, 2), v_t_2489));
          V v_m_2491 = heff_dup(v_module_2432);
          V v_t_2492;
          if (heff_strEq_c_lent(v_w_2411, v_m_2491, 0)) {
            heff_drop(v_w_2411);
            heff_drop(v_m_2491);
            v_t_2492 = v_rs_248;
          } else {
            v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2411, v_m_2491}), v_rs_248});
          }
          V v_t_2493 = ({ V rv_0 = v_t_2487; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_module_2432, v_t_2488}); V rv_2 = v_t_2490; V rr_ = heff_rec_reuse_nf(v_st_247, 0ULL, 3, shape_done__doneMods__errors, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V v_t_2494 = (g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(v_lit_240, v_read_241, v_ps_242, v_pkgs_243, v_stack_244, v_from_245, v_rest_2412, v_t_2493, v_t_2492));
          V f_ = v_t_2494;
          heff_room[0] = v_hd_2415;
          heff_room[1] = v_k_2416;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2431);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_ps_242 = heff_env(self)[1];
  V v_pkgs_243 = heff_env(self)[2];
  V v_from_245 = heff_env(self)[3];
  V v_w_2411 = heff_env(self)[4];
  V v_st_247 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_read_241 = heff_env(self)[7];
  V v_stack_244 = heff_env(self)[8];
  V v_rest_2412 = heff_env(self)[9];
  V v_rs_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715_lam2, 1, 12, (V[]){v_ps_242, v_pkgs_243, v_from_245, v_w_2411, v_st_247, v_lit_240, v_read_241, v_stack_244, v_rest_2412, v_rs_248, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_entry, 9, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855(V v_read_240, V v_ps_241, V v_pkgs_242, V v_from_243, V v_before_244, V v_x6_245, V v_st_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_from_243);
    heff_drop(v_before_244);
    heff_drop(v_z_247);
    return heff_tail(v_z_248, 1, (V[]){v_st_246});
  }
  case TAG_Cons: {
    V v_m_249 = heff_field(v_x6_245, 0);
    V v_ms_2410 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_249), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2ebuild_2eload_2eloadMany_24s115304085x2084877715(heff_dup(v_before_244), heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), NTAG(TAG_Nil), heff_dup(v_from_243), v_t_2411, v_st_246, NTAG(TAG_Nil)));
    return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_lam0, 1, 9, (V[]){v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410, v_z_247, v_z_248})});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_before_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_pkgs_242 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ms_2410 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_249, NTAG(TAG_Nil)});
  V v_t_2415 = (g_prelude_2e_2b_2b(v_before_244, v_t_2414));
  V v_t_2418;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 2);
    v_t_2418 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  return (g_heff_2ebuild_2eload_2emadeOfGo_24s444825395x962383855(v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_t_2415, v_ms_2410, v_t_2418, v_z_247, v_z_248));
}