// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_str0, 23, "heff doc: cannot write ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_str2, 23, "heff doc: cannot write ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_str3, 1, "\012");
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0(V v_path_240, V v_text_241, V v_hd_242, V v_k_243, V v_x_244) {
top: ;
  V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_240)));
  V v_t_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_245; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_245); r_; });
  V v_a_248 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_246, v_text_241, ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam0_clo)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2413, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam1, 1, 3, (V[]){v_path_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam3(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_drop(v_x_2439);
  V v_t_2440 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 0ULL, 1);
    heff_clo_take(self, 3);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_str0), v_path_240), ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_str1));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    switch (heff_tag_of(v_y_2430)) {
    case TAG_Left: {
      V v_ru_24y_2430_24Left = heff_take_reuse_n(v_y_2430, 0ULL, 1);
      heff_clo_take(self, 3);
      V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_str2), v_path_240), ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_str3));
      V v_t_2433 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2432, NTAG(TAG_MkUnit)});
      V v_t_2434 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2430_24Left, TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_lam3, 1, 2, (V[]){v_hd_242, v_k_243})));
    }
    case TAG_Right: {
      heff_take_n(v_y_2430, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_path_240);
      heff_drop(v_hd_242);
      heff_drop_cell(v_ru_24x_2414_24Right, 1);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2430);
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}