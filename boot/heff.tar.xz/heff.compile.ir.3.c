// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530 13050
#define TAG_Enter_24heff_2ecompile_2erunes_2ereads 18072
#define TAG_MkArm 55352
#define TAG_StrRuneAt 38304
#define TAG_StrRuneWidth 48503
V g_heff_2ecompile_2ecpr_2eoutRw(V, V);
V g_heff_2ecompile_2ecpr_2eoutRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2eoutRw_clo;
V g_heff_2ecompile_2efields_2ereadAt(V, V);
V g_heff_2ecompile_2efields_2ereadAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadAt_clo;
V g_heff_2ecompile_2efields_2ereadsAt(V, V, V);
V g_heff_2ecompile_2efields_2ereadsAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ereadsAt_clo;
V g_heff_2ecompile_2eir_2eallArms(V, V);
V g_heff_2ecompile_2eir_2eallArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallArms_clo;
V g_heff_2ecompile_2eir_2eallFields(V, V);
V g_heff_2ecompile_2eir_2eallFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallFields_clo;
V g_heff_2ecompile_2eir_2eallList(V, V);
V g_heff_2ecompile_2eir_2eallList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallList_clo;
V g_heff_2ecompile_2eir_2eallParts(V, V);
V g_heff_2ecompile_2eir_2eallParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallParts_clo;
V g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012(V);
V g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo;
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdShaped(V);
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdShaped_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884(V, V);
V g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884_clo;
V g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947(V, V);
V g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947_clo;
V g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393(V, V);
V g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393_clo;
V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(V, V);
V g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549_clo;
V g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle(V, V, V, V);
V g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24dps_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2ehasDefault(V);
V g_heff_2ecompile_2eir_2ehasDefault_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ehasDefault_clo;
V g_heff_2ecompile_2eir_2eifOf(V, V, V);
V g_heff_2ecompile_2eir_2eifOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eifOf_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esurelyBool(V);
V g_heff_2ecompile_2eir_2esurelyBool_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esurelyBool_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_clo;
V g_heff_2ecompile_2erunes_2ereads(V);
V g_heff_2ecompile_2erunes_2ereads_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erunes_2ereads_clo;
V g_heff_2ecompile_2eworlds_2eworldsIn(V, V);
V g_heff_2ecompile_2eworlds_2eworldsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2eworldsIn_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2023978511x2117594482(V);
V g_list_2eany_24s2023978511x2117594482_entry(V self, V *a);
extern Clo g_list_2eany_24s2023978511x2117594482_clo;
V g_prelude_2etraverse_24s1218231813x1819446478(V, V);
V g_prelude_2etraverse_24s1218231813x1819446478_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1218231813x1819446478_clo;
HeffT2 g_prelude_2etraverse_24s1462482035x919987020_24cpr(V, V);
V g_prelude_2etraverse_24s1587080482x1917521257(V, V);
V g_prelude_2etraverse_24s1587080482x1917521257_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1587080482x1917521257_clo;
V g_prelude_2etraverse_24s1736110006x954168809(V);
V g_prelude_2etraverse_24s1736110006x954168809_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1736110006x954168809_clo;
V g_prelude_2etraverse_24s924094738x742129811(V);
V g_prelude_2etraverse_24s924094738x742129811_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s924094738x742129811_clo;
Clo g_heff_2ecompile_2eir_2eallParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallParts_entry, 2, 0};

V g_heff_2ecompile_2eir_2eallParts(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(v_f_240, 2, (V[]){v_xs_244, v_b_245});
  }
  case TAG_EApp: {
    V v_g_246 = heff_field(v_x2_241, 0);
    V v_args_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_246}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return ({ V a_0 = v_f_240; V a_1 = v_args_247; V r_ = (g_heff_2ecompile_2eir_2eallList(a_0, a_1)); heff_drop(v_f_240); heff_drop(v_args_247); r_; });
    } else {
      heff_drop(v_f_240);
      heff_drop(v_args_247);
      heff_drop(v_t_248);
      return NTAG(TAG_False);
    }
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_x2_241, 0);
    V v_a_2410 = heff_field(v_x2_241, 1);
    V v_b_2411 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2410}));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, NTAG(TAG_Nil)});
      return heff_tail(v_f_240, 2, (V[]){v_t_2413, v_b_2411});
    } else {
      heff_drop(v_f_240);
      heff_drop(v_x_249);
      heff_drop(v_b_2411);
      heff_drop(v_t_2412);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = v_f_240; V a_1 = v_fs_2414; V r_ = (g_heff_2ecompile_2eir_2eallFields(a_0, a_1)); heff_drop(v_f_240); heff_drop(v_fs_2414); r_; });
  }
  case TAG_EProj: {
    V v_e_2416 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    return heff_tail(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2416});
  }
  case TAG_ETag: {
    V v_args_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    return ({ V a_0 = v_f_240; V a_1 = v_args_2421; V r_ = (g_heff_2ecompile_2eir_2eallList(a_0, a_1)); heff_drop(v_f_240); heff_drop(v_args_2421); r_; });
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x2_241, 0);
    V v_arms_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2425 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2423}));
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      return ({ V a_0 = v_f_240; V a_1 = v_arms_2424; V r_ = (g_heff_2ecompile_2eir_2eallArms(a_0, a_1)); heff_drop(v_f_240); heff_drop(v_arms_2424); r_; });
    } else {
      heff_drop(v_f_240);
      heff_drop(v_arms_2424);
      heff_drop(v_t_2425);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_args_2428 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    return ({ V a_0 = v_f_240; V a_1 = v_args_2428; V r_ = (g_heff_2ecompile_2eir_2eallList(a_0, a_1)); heff_drop(v_f_240); heff_drop(v_args_2428); r_; });
  }
  case TAG_ECall: {
    V v_args_2430 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    return ({ V a_0 = v_f_240; V a_1 = v_args_2430; V r_ = (g_heff_2ecompile_2eir_2eallList(a_0, a_1)); heff_drop(v_f_240); heff_drop(v_args_2430); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    V v_c_2438 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2439 = ({ V a_0 = v_c_2438; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2438); r_; });
    return ({ V a_0 = v_f_240; V a_1 = v_t_2439; V r_ = (g_heff_2ecompile_2eir_2eallList(a_0, a_1)); heff_drop(v_f_240); heff_drop(v_t_2439); r_; });
  }
  case TAG_ESet: {
    V v_xs_2440 = heff_field(v_x2_241, 0);
    V v_a_2441 = heff_field(v_x2_241, 1);
    V v_b_2442 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2443 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2441}));
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      return heff_tail(v_f_240, 2, (V[]){v_xs_2440, v_b_2442});
    } else {
      heff_drop(v_f_240);
      heff_drop(v_xs_2440);
      heff_drop(v_b_2442);
      heff_drop(v_t_2443);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_2444 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ({ V a_0 = v_f_240; V a_1 = v_es_2444; V r_ = (g_heff_2ecompile_2eir_2eallList(a_0, a_1)); heff_drop(v_f_240); heff_drop(v_es_2444); r_; });
  }
  case TAG_EFix: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_b_2446 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2447 = heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){v_x_2445, NTAG(TAG_Nil)});
    return heff_tail(v_f_240, 2, (V[]){v_t_2447, v_b_2446});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2eallParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eallParts(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2ehasDefault_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2ehasDefault_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ehasDefault_lam0, 2, 0};
Clo g_heff_2ecompile_2eir_2ehasDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ehasDefault_entry, 1, 0};

V g_heff_2ecompile_2eir_2ehasDefault(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EMatch: {
    V v_s_241 = heff_field(v_e_240, 0);
    V v_arms_242 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_243 = (g_list_2eany_24s2023978511x2117594482(v_arms_242));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_s_241);
      heff_drop(v_arms_242);
      heff_drop_cell(v_ru_24e_240_24EMatch, 2);
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V v_x1_247 = heff_tr(g_heff_2ecompile_2eir_2eallParts(((V)&g_heff_2ecompile_2eir_2ehasDefault_lam0_clo), heff_tag_re_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, 3ULL, (V[]){v_s_241, v_arms_242})));
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
      heff_drop(v_x1_247);
      return v_ret_24bool;
    }
  }
  default: {
    V v_x1_248 = ({ V a_0 = v_e_240; V r_ = (g_heff_2ecompile_2eir_2eallParts_24s1669176395x1867550012(a_0)); heff_drop(v_e_240); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
    heff_drop(v_x1_248);
    return v_ret_24bool;
  }
  }
}
V g_heff_2ecompile_2eir_2ehasDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ehasDefault(a[0]);
}
V g_heff_2ecompile_2eir_2ehasDefault_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_p_245 = args[1];
  heff_drop(v_x_244);
  V v_x1_246 = (g_heff_2ecompile_2eir_2ehasDefault(v_p_245));
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
  heff_drop(v_x1_246);
  return v_ret_24bool;
}

HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24dps_24cpr(V v_m_240, V v_n_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    V v_u_244 = heff_setFieldPeek(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_245 = heff_hole();
    return ((HeffT2){{v_f_245, v_n_241}});
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_242, 0);
    V v_rest_247 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_l_248 = heff_field(v_x41_246, 0);
      V v_e_249 = heff_field(v_x41_246, 1);
      V v_ru_24x41_246_24MkPair = heff_take_reuse_n(v_x41_246, 3ULL, 2);
      HeffT2 v_t_2410 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_e_27_2413 = v_field_2411;
        V v_n1_2414 = v_field_2412;
        V v_cell_2415 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x41_246_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_l_248, v_e_27_2413}), heff_hole()});
        V v_u_2416 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2415);
        V t_0 = v_m_240;
        V t_1 = v_n1_2414;
        V t_2 = v_rest_247;
        V t_3 = v_u_2416;
        v_m_240 = t_0;
        v_n_241 = t_1;
        v_x4_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2ecountW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ecountW_entry, 3, 0};

V g_heff_2ecompile_2eir_2ecountW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_246;
      if (heff_strEq_c_lent(v_y_245, v_x_240, 1)) {
        v_t_246 = heff_intAdd(v_n_241, MK_INT(1LL));
      } else {
        v_t_246 = v_n_241;
      }
      V t_0 = v_x_240;
      V t_1 = v_t_246;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_249 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_b_249, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x31_243, 0);
      V v_args_2411 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24EApp, v_args_2411, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2410, v_t_2412});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2414 = heff_field(v_x31_243, 1);
      V v_b_2415 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2415, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2416;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2417, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2419;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_e_2420, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2425 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      V v_t_2427 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2425, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2427;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2428 = heff_field(v_x31_243, 0);
      V v_arms_2429 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2430 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2429, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_t_2430});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2433 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2433, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2434;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2436 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2436, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2437;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2445 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2446 = ({ V a_0 = v_c_2445; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2445); r_; });
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2446;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2448 = heff_field(v_x31_243, 1);
      V v_b_2449 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2450 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2448, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2449, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2450;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2451 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2452 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2451, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2452;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2ecountW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2esizeB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esizeB_entry, 3, 0};

V g_heff_2ecompile_2eir_2esizeB(V v_lim_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intLt_c_lent(v_lim_240, v_n_241, 0)) {
      heff_drop(v_e_243);
      heff_drop(v_rest_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return v_n_241;
    } else {
      switch (heff_tag_of(v_e_243)) {
      case TAG_ELam: {
        V v_b_246 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_b_246, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EApp: {
        V v_f_247 = heff_field(v_e_243, 0);
        V v_args_248 = heff_field(v_e_243, 1);
        V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
        V v_t_249 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24e_243_24EApp, v_args_248, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_247, v_t_249});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELet: {
        V v_a_2411 = heff_field(v_e_243, 1);
        V v_b_2412 = heff_field(v_e_243, 2);
        heff_take_n(v_e_243, 6ULL, 3);
        V v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2412, v_rest_244})});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2413;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ERecord: {
        V v_fs_2414 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 2);
        V v_t_2416 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2414, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2416;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EProj: {
        V v_e2_2417 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 4);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_e2_2417, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ETag: {
        V v_args_2422 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 3);
        V v_t_2424 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2422, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2424;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EMatch: {
        V v_sc_2425 = heff_field(v_e_243, 0);
        V v_arms_2426 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 3ULL, 2);
        V v_t_2427 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2426, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2425, v_t_2427});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrimCall: {
        V v_args_2429 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V v_t_2430 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2429, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2430;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ECall: {
        V v_args_2432 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V v_t_2433 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2432, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2433;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EBool: {
        V v_c_2434 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2435 = ({ V a_0 = v_c_2434; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2434); r_; });
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2435;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ESet: {
        V v_a_2437 = heff_field(v_e_243, 1);
        V v_b_2438 = heff_field(v_e_243, 2);
        heff_take_n(v_e_243, 6ULL, 3);
        V v_t_2439 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2437, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2438, v_rest_244})});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2439;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EValues: {
        V v_es_2440 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 1);
        V v_t_2441 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2440, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2441;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: {
        heff_drop(v_e_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2esizeB(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_a_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_t_246));
    V v_t_248 = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_247, v_t_248));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eir_2eifOf_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2eifOf_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2eifOf_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2eifOf_str3, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2eifOf_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2eifOf_str5, 5, "False");
Clo g_heff_2ecompile_2eir_2eifOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eifOf_entry, 3, 0};

V g_heff_2ecompile_2eir_2eifOf(V v_s_240, V v_t_241, V v_f_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_t_241)));
  V v_t_246;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_f_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_t_241)));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_246 = NTAG(TAG_True);
      } else {
        heff_drop(v_t_245);
        v_t_246 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_f_242)));
      }
    } else {
      heff_drop(v_t_244);
      v_t_246 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_t_243);
    v_t_246 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = (g_heff_2ecompile_2eir_2econdOf(v_s_240));
    V v_t_248 = (g_heff_2ecompile_2eir_2econdOf(v_t_241));
    V v_t_249 = (g_heff_2ecompile_2eir_2econdOf(v_f_242));
    V v_c_2410 = (g_heff_2ecompile_2eir_2econdIf(v_t_247, v_t_248, v_t_249));
    switch (heff_tag_of(v_c_2410)) {
    case TAG_CTrue: {
      return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2eifOf_str0), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_CFalse: {
      return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2eifOf_str1), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    }
    case TAG_CRel: {
      return heff_tag_n(TAG_EBool, 1, (V[]){v_c_2410});
    }
    case TAG_CTest: {
      V v_e_2414 = heff_field(v_c_2410, 0);
      heff_take_n(v_c_2410, 1ULL, 1);
      return v_e_2414;
    }
    case TAG_CNot: {
      return heff_tag_n(TAG_EBool, 1, (V[]){v_c_2410});
    }
    case TAG_CIf: {
      return heff_tag_n(TAG_EBool, 1, (V[]){v_c_2410});
    }
    default: return heff_nomatch(v_c_2410);
    }
  } else {
    heff_drop(v_t_246);
    V v_c_2419 = (g_heff_2ecompile_2eir_2econdOf(v_s_240));
    V v_t_2428;
    switch (heff_tag_of(v_c_2419)) {
    case TAG_CTrue: {
      v_t_2428 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2eifOf_str2), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CFalse: {
      v_t_2428 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2eifOf_str3), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CRel: {
      v_t_2428 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2419});
      break;
    }
    case TAG_CTest: {
      V v_e_2423 = heff_field(v_c_2419, 0);
      heff_take_n(v_c_2419, 1ULL, 1);
      v_t_2428 = v_e_2423;
      break;
    }
    case TAG_CNot: {
      v_t_2428 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2419});
      break;
    }
    case TAG_CIf: {
      v_t_2428 = heff_tag_n(TAG_EBool, 1, (V[]){v_c_2419});
      break;
    }
    default: heff_nomatch(v_c_2419);
    }
    V v_t_2429 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2eifOf_str4), NTAG(TAG_Nil), v_t_241});
    V v_t_2430 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2eifOf_str5), NTAG(TAG_Nil), v_f_242});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2431})});
  }
}
V g_heff_2ecompile_2eir_2eifOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eifOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam22(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam23(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam24(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam25(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam26(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_entry, 2, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_246), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_g_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2415 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_2413}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam3, 1, 3, (V[]){v_m_2415, v_f_240, v_args_2414});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x2_241, 0);
    V v_a_2426 = heff_field(v_x2_241, 1);
    V v_b_2427 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2428 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2426}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam4, 1, 4, (V[]){v_m_2428, v_x_2425, v_f_240, v_b_2427});
  }
  case TAG_ERecord: {
    V v_fs_2438 = heff_field(v_x2_241, 0);
    V v_ts_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2448 = (g_prelude_2etraverse_24s1218231813x1819446478(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam5, 1, 1, (V[]){v_f_240}), v_fs_2438));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam7, 1, 2, (V[]){v_m_2448, v_ts_2439});
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x2_241, 0);
    V v_l_2454 = heff_field(v_x2_241, 1);
    V v_sh_2455 = heff_field(v_x2_241, 2);
    V v_t_2456 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2457 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2453}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam8, 1, 4, (V[]){v_m_2457, v_l_2454, v_sh_2455, v_t_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_x2_241, 0);
    V v_args_2463 = heff_field(v_x2_241, 1);
    V v_ts_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2465 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2466 = (g_prelude_2etraverse_24s1218231813x1819446478(v_t_2465, v_args_2463));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam9, 1, 3, (V[]){v_m_2466, v_t_2462, v_ts_2464});
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_x2_241, 0);
    V v_arms_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2473 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2471}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam10, 1, 3, (V[]){v_m_2473, v_f_240, v_arms_2472});
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam13, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2493 = heff_field(v_x2_241, 0);
    V v_args_2494 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2496 = (g_prelude_2etraverse_24s1218231813x1819446478(v_t_2495, v_args_2494));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam14, 1, 2, (V[]){v_m_2496, v_p_2493});
  }
  case TAG_ECall: {
    V v_g_24101 = heff_field(v_x2_241, 0);
    V v_args_24102 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24103 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24104 = (g_prelude_2etraverse_24s1218231813x1819446478(v_t_24103, v_args_24102));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam15, 1, 2, (V[]){v_m_24104, v_g_24101});
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam22, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBool: {
    V v_c_24123 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24124 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24125 = ({ V a_0 = v_t_24124; V a_1 = v_c_24123; V r_ = (g_heff_2ecompile_2eir_2econdTraverse_24s988316847x1289936609(a_0, a_1)); heff_drop(v_t_24124); r_; });
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam23, 1, 1, (V[]){v_m_24125});
  }
  case TAG_ESet: {
    V v_xs_24130 = heff_field(v_x2_241, 0);
    V v_a_24131 = heff_field(v_x2_241, 1);
    V v_b_24132 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24133 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_24131}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam24, 1, 4, (V[]){v_m_24133, v_f_240, v_xs_24130, v_b_24132});
  }
  case TAG_EValues: {
    V v_es_24142 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24143 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24144 = (g_prelude_2etraverse_24s1218231813x1819446478(v_t_24143, v_es_24142));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam25, 1, 1, (V[]){v_m_24144});
  }
  case TAG_EFix: {
    V v_x_24149 = heff_field(v_x2_241, 0);
    V v_b_24150 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24151 = heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_x_24149), NTAG(TAG_Nil)});
    V v_m_24152 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_24151, v_b_24150}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam26, 1, 2, (V[]){v_m_24152, v_x_24149});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_243});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_245});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam3(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_args_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_t_2421 = (g_prelude_2etraverse_24s1218231813x1819446478(v_t_2420, v_args_2414));
    V v_x2_2422 = heff_tr(heff_call(v_t_2421, 1, (V[]){v_s_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_s_2424 = heff_field(v_x2_2422, 1);
      V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_EApp, 2, (V[]){v_x_2418, v_x_2423}), v_s_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_b_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_Nil)});
    V v_m_2434 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2433, v_b_2427}));
    V v_x2_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_s_2432}));
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_s_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2425, v_x_2431, v_x_2436}), v_s_2437});
    }
    default: return heff_nomatch(v_x2_2435);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam6(V self, V *args) {
  V v_s_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_s_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2441, v_x_2446}), v_s_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam5(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_l_2441 = heff_field(v_x2_2440, 0);
    V v_e_2442 = heff_field(v_x2_2440, 1);
    heff_take_n(v_x2_2440, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_m_2443 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2442}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam6, 1, 2, (V[]){v_m_2443, v_l_2441});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam7(V self, V *args) {
  V v_s_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_ts_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_s_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2451, v_ts_2439}), v_s_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam8(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2454 = heff_env(self)[1];
  V v_sh_2455 = heff_env(self)[2];
  V v_t_2456 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2460, v_l_2454, v_sh_2455, v_t_2456}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam9(V self, V *args) {
  V v_s_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  V v_ts_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_s_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_s_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2462, v_x_2469, v_ts_2464}), v_s_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam12(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_t_2479 = heff_env(self)[1];
  V v_vs_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2479, v_vs_2480, v_x_2485}), v_s_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam11(V self, V *args) {
  V v_x2_2478 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkArm: {
    V v_t_2479 = heff_field(v_x2_2478, 0);
    V v_vs_2480 = heff_field(v_x2_2478, 1);
    V v_b_2481 = heff_field(v_x2_2478, 2);
    heff_take_n(v_x2_2478, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_m_2482 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_vs_2480), v_b_2481}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam12, 1, 3, (V[]){v_m_2482, v_t_2479, v_vs_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam10(V self, V *args) {
  V v_s_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_arms_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_s_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_s_2477 = heff_field(v_x2_2475, 1);
    V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
    V v_t_2487 = (g_prelude_2etraverse_24s1218231813x1819446478(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam11, 1, 1, (V[]){v_f_240}), v_arms_2472));
    V v_x2_2488 = heff_tr(heff_call(v_t_2487, 1, (V[]){v_s_2477}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_s_2490 = heff_field(v_x2_2488, 1);
      V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_EMatch, 2, (V[]){v_x_2476, v_x_2489}), v_s_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam13(V self, V *args) {
  V v_s_2492 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_2492});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam14(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_p_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2493, v_x_2499}), v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam15(V self, V *args) {
  V v_s_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  V v_g_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_s_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_s_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24101, v_x_24107}), v_s_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam16(V self, V *args) {
  V v_s_24110 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24110});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam17(V self, V *args) {
  V v_s_24112 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24112});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam18(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24114});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam19(V self, V *args) {
  V v_s_24116 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24116});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam20(V self, V *args) {
  V v_s_24119 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24119});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam21(V self, V *args) {
  V v_s_24121 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24121});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam22(V self, V *args) {
  V v_s_24122 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24122});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam23(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24128}), v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam24(V self, V *args) {
  V v_s_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_24130 = heff_env(self)[2];
  V v_b_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_s_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_s_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_m_24138 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_24130), v_b_24132}));
    V v_x2_24139 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_s_24137}));
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_s_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24130, v_x_24136, v_x_24140}), v_s_24141});
    }
    default: return heff_nomatch(v_x2_24139);
    }
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam25(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24147}), v_s_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1088936896x224150757_lam26(V self, V *args) {
  V v_s_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_x_24149 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_s_24153}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_MkPair: {
    V v_x_24155 = heff_field(v_x2_24154, 0);
    V v_s_24156 = heff_field(v_x2_24154, 1);
    V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24149, v_x_24155}), v_s_24156});
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam4(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(V v_lit_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2411 = (g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(v_lit_240, v_b_2410));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam0, 1, 3, (V[]){v_m_2411, v_x_248, v_a_249});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_241, 0);
    V v_arms_2426 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2436 = (g_prelude_2etraverse_24s1587080482x1917521257(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam1, 1, 1, (V[]){heff_dup(v_lit_240)}), v_arms_2426));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam3, 1, 2, (V[]){v_m_2436, v_s_2425});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_ESet: {
    V v_xs_2454 = heff_field(v_e_241, 0);
    V v_a_2455 = heff_field(v_e_241, 1);
    V v_b_2456 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2457 = (g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(v_lit_240, v_b_2456));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam4, 1, 3, (V[]){v_m_2457, v_xs_2454, v_a_2455});
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2ecpr_2eoutRw(heff_dup(v_lit_240), v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2414}), v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam2(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_t_2428 = heff_env(self)[1];
  V v_vs_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2428, v_vs_2429, v_x_2434}), v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam1(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_lit_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_field(v_x2_2427, 0);
    V v_vs_2429 = heff_field(v_x2_2427, 1);
    V v_b_2430 = heff_field(v_x2_2427, 2);
    heff_take_n(v_x2_2427, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_m_2431 = ({ V a_0 = v_lit_240; V a_1 = v_b_2430; V r_ = (g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835(a_0, a_1)); heff_drop(v_lit_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam2, 1, 3, (V[]){v_m_2431, v_t_2428, v_vs_2429});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam3(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_s_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2425, v_x_2439}), v_n_2440});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1961403631x876156835_lam4(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_xs_2454 = heff_env(self)[1];
  V v_a_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2454, v_a_2455, v_x_2460}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam22(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry, 1, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_240, 0);
    V v_b_246 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_247 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam2, 1, 2, (V[]){v_a_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_g_2415 = heff_field(v_x2_240, 0);
    V v_args_2416 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_2417 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_g_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam3, 1, 2, (V[]){v_a_2417, v_args_2416});
  }
  case TAG_ELet: {
    V v_x_2426 = heff_field(v_x2_240, 0);
    V v_a_2427 = heff_field(v_x2_240, 1);
    V v_b_2428 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_a_2429 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_a_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam4, 1, 3, (V[]){v_a_2429, v_b_2428, v_x_2426});
  }
  case TAG_ERecord: {
    V v_fs_2443 = heff_field(v_x2_240, 0);
    V v_ts_2444 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2445 = (g_prelude_2etraverse_24s1736110006x954168809(v_fs_2443));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam5, 1, 2, (V[]){v_m_2445, v_ts_2444});
  }
  case TAG_EProj: {
    V v_e_2450 = heff_field(v_x2_240, 0);
    V v_l_2451 = heff_field(v_x2_240, 1);
    V v_sh_2452 = heff_field(v_x2_240, 2);
    V v_t_2453 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_a_2454 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_e_2450));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam6, 1, 4, (V[]){v_a_2454, v_l_2451, v_sh_2452, v_t_2453});
  }
  case TAG_ETag: {
    V v_t_2459 = heff_field(v_x2_240, 0);
    V v_args_2460 = heff_field(v_x2_240, 1);
    V v_ts_2461 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2462 = (g_prelude_2etraverse_24s924094738x742129811(v_args_2460));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam7, 1, 3, (V[]){v_m_2462, v_t_2459, v_ts_2461});
  }
  case TAG_EMatch: {
    V v_s_2467 = heff_field(v_x2_240, 0);
    V v_arms_2468 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_2469 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_s_2467));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam8, 1, 2, (V[]){v_a_2469, v_arms_2468});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EPrimCall: {
    V v_p_2481 = heff_field(v_x2_240, 0);
    V v_args_2482 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2483 = (g_prelude_2etraverse_24s924094738x742129811(v_args_2482));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam10, 1, 2, (V[]){v_m_2483, v_p_2481});
  }
  case TAG_ECall: {
    V v_g_2488 = heff_field(v_x2_240, 0);
    V v_args_2489 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2490 = (g_prelude_2etraverse_24s924094738x742129811(v_args_2489));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam11, 1, 2, (V[]){v_m_2490, v_g_2488});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam12, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBool: {
    V v_c_24109 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24110 = (g_heff_2ecompile_2eir_2econdTraverse_24s1998655838x165603760(v_c_24109));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam19, 1, 1, (V[]){v_m_24110});
  }
  case TAG_ESet: {
    V v_xs_24115 = heff_field(v_x2_240, 0);
    V v_a_24116 = heff_field(v_x2_240, 1);
    V v_b_24117 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_a_24118 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_a_24116));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam20, 1, 3, (V[]){v_a_24118, v_b_24117, v_xs_24115});
  }
  case TAG_EValues: {
    V v_es_24130 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24131 = (g_prelude_2etraverse_24s924094738x742129811(v_es_24130));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam21, 1, 1, (V[]){v_m_24131});
  }
  case TAG_EFix: {
    V v_x_24136 = heff_field(v_x2_240, 0);
    V v_b_24137 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_24138 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_b_24137));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam22, 1, 2, (V[]){v_a_24138, v_x_24136});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(a[0]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_242});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_244});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_n_248}));
  V v_x2_2412;
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    heff_take_n(v_a_249, 3ULL, 2);
    v_x2_2412 = (g_heff_2ecompile_2efields_2ereadsAt(v_xs_245, v_a_2410, v_a_2411));
    break;
  }
  default: heff_nomatch(v_a_249);
  }
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2413}), v_n_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_a_2417 = heff_env(self)[0];
  V v_args_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2419 = heff_tr(heff_call(v_a_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_a_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_a_2419, 0);
    V v_n_2421 = heff_field(v_a_2419, 1);
    V v_ru_24a_2419_24MkPair = heff_take_reuse_n(v_a_2419, 3ULL, 2);
    V v_t_2422 = (g_prelude_2etraverse_24s924094738x742129811(v_args_2416));
    V v_x2_2423 = heff_tr(heff_call(v_t_2422, 1, (V[]){v_n_2421}));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_n_2425 = heff_field(v_x2_2423, 1);
      V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
      return heff_tag_at_n(v_ru_24a_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_EApp, 2, (V[]){v_x_2420, v_x_2424}), v_n_2425});
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  default: return heff_nomatch(v_a_2419);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam4(V self, V *args) {
  V v_n_2430 = args[0];
  V v_a_2429 = heff_env(self)[0];
  V v_b_2428 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2431 = heff_tr(heff_call(v_a_2429, 1, (V[]){v_n_2430}));
  switch (heff_tag_of(v_a_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_a_2431, 0);
    V v_n_2433 = heff_field(v_a_2431, 1);
    V v_ru_24a_2431_24MkPair = heff_take_reuse_n(v_a_2431, 3ULL, 2);
    V v_t_2434 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_b_2428));
    V v_a_2435 = heff_tr(heff_call(v_t_2434, 1, (V[]){v_n_2433}));
    V v_x2_2440;
    switch (heff_tag_of(v_a_2435)) {
    case TAG_MkPair: {
      V v_a_2436 = heff_field(v_a_2435, 0);
      V v_a_2437 = heff_field(v_a_2435, 1);
      heff_take_n(v_a_2435, 3ULL, 2);
      V v_t_2438 = (g_heff_2ecompile_2efields_2ereadAt(v_a_2436, heff_dup(v_x_2426)));
      V v_x2_2439 = heff_tr(heff_call(v_t_2438, 1, (V[]){v_a_2437}));
      v_x2_2440 = v_x2_2439;
      break;
    }
    default: heff_nomatch(v_a_2435);
    }
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_MkPair: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_n_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      return heff_tag_at_n(v_ru_24a_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2426, v_x_2432, v_x_2441}), v_n_2442});
    }
    default: return heff_nomatch(v_x2_2440);
    }
  }
  default: return heff_nomatch(v_a_2431);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam5(V self, V *args) {
  V v_n_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_ts_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_n_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_n_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2448, v_ts_2444}), v_n_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam6(V self, V *args) {
  V v_n_2455 = args[0];
  V v_a_2454 = heff_env(self)[0];
  V v_l_2451 = heff_env(self)[1];
  V v_sh_2452 = heff_env(self)[2];
  V v_t_2453 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_a_2456 = heff_tr(heff_call(v_a_2454, 1, (V[]){v_n_2455}));
  switch (heff_tag_of(v_a_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_a_2456, 0);
    V v_n_2458 = heff_field(v_a_2456, 1);
    V v_ru_24a_2456_24MkPair = heff_take_reuse_n(v_a_2456, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_2456_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2457, v_l_2451, v_sh_2452, v_t_2453}), v_n_2458});
  }
  default: return heff_nomatch(v_a_2456);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam7(V self, V *args) {
  V v_n_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  V v_t_2459 = heff_env(self)[1];
  V v_ts_2461 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_n_2463}));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_n_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2459, v_x_2465, v_ts_2461}), v_n_2466});
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam8(V self, V *args) {
  V v_n_2470 = args[0];
  V v_a_2469 = heff_env(self)[0];
  V v_arms_2468 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2471 = heff_tr(heff_call(v_a_2469, 1, (V[]){v_n_2470}));
  switch (heff_tag_of(v_a_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_a_2471, 0);
    V v_n_2473 = heff_field(v_a_2471, 1);
    V v_ru_24a_2471_24MkPair = heff_take_reuse_n(v_a_2471, 3ULL, 2);
    HeffT2 v_t_2474 = (g_prelude_2etraverse_24s1462482035x919987020_24cpr(v_arms_2468, v_n_2473));
    {
      V v_field_2475 = v_t_2474.f[0];
      V v_field_2476 = v_t_2474.f[1];
      V v_x_2477 = v_field_2475;
      V v_n_2478 = v_field_2476;
      return heff_tag_at_n(v_ru_24a_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2472, v_x_2477}), v_n_2478});
    }
  }
  default: return heff_nomatch(v_a_2471);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam9(V self, V *args) {
  V v_n_2480 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2480});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam10(V self, V *args) {
  V v_n_2484 = args[0];
  V v_m_2483 = heff_env(self)[0];
  V v_p_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2485 = heff_tr(heff_call(v_m_2483, 1, (V[]){v_n_2484}));
  switch (heff_tag_of(v_x2_2485)) {
  case TAG_MkPair: {
    V v_x_2486 = heff_field(v_x2_2485, 0);
    V v_n_2487 = heff_field(v_x2_2485, 1);
    V v_ru_24x2_2485_24MkPair = heff_take_reuse_n(v_x2_2485, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2485_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2481, v_x_2486}), v_n_2487});
  }
  default: return heff_nomatch(v_x2_2485);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam11(V self, V *args) {
  V v_n_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_g_2488 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_n_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_n_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2488, v_x_2493}), v_n_2494});
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam12(V self, V *args) {
  V v_n_2496 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2496});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam13(V self, V *args) {
  V v_n_2498 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2498});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam14(V self, V *args) {
  V v_n_24100 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24100});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam15(V self, V *args) {
  V v_n_24102 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24102});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam16(V self, V *args) {
  V v_n_24105 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24105});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam17(V self, V *args) {
  V v_n_24107 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24107});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam18(V self, V *args) {
  V v_n_24108 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24108});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam19(V self, V *args) {
  V v_n_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_n_24111}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_MkPair: {
    V v_x_24113 = heff_field(v_x2_24112, 0);
    V v_n_24114 = heff_field(v_x2_24112, 1);
    V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24112_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24113}), v_n_24114});
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam20(V self, V *args) {
  V v_n_24119 = args[0];
  V v_a_24118 = heff_env(self)[0];
  V v_b_24117 = heff_env(self)[1];
  V v_xs_24115 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_24120 = heff_tr(heff_call(v_a_24118, 1, (V[]){v_n_24119}));
  switch (heff_tag_of(v_a_24120)) {
  case TAG_MkPair: {
    V v_x_24121 = heff_field(v_a_24120, 0);
    V v_n_24122 = heff_field(v_a_24120, 1);
    V v_ru_24a_24120_24MkPair = heff_take_reuse_n(v_a_24120, 3ULL, 2);
    V v_t_24123 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(v_b_24117));
    V v_a_24124 = heff_tr(heff_call(v_t_24123, 1, (V[]){v_n_24122}));
    V v_x2_24127;
    switch (heff_tag_of(v_a_24124)) {
    case TAG_MkPair: {
      V v_a_24125 = heff_field(v_a_24124, 0);
      V v_a_24126 = heff_field(v_a_24124, 1);
      heff_take_n(v_a_24124, 3ULL, 2);
      v_x2_24127 = (g_heff_2ecompile_2efields_2ereadsAt(v_xs_24115, v_a_24125, v_a_24126));
      break;
    }
    default: heff_nomatch(v_a_24124);
    }
    switch (heff_tag_of(v_x2_24127)) {
    case TAG_MkPair: {
      V v_x_24128 = heff_field(v_x2_24127, 0);
      V v_n_24129 = heff_field(v_x2_24127, 1);
      heff_take_n(v_x2_24127, 3ULL, 2);
      return heff_tag_at_n(v_ru_24a_24120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24115, v_x_24121, v_x_24128}), v_n_24129});
    }
    default: return heff_nomatch(v_x2_24127);
    }
  }
  default: return heff_nomatch(v_a_24120);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam21(V self, V *args) {
  V v_n_24132 = args[0];
  V v_m_24131 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24133 = heff_tr(heff_call(v_m_24131, 1, (V[]){v_n_24132}));
  switch (heff_tag_of(v_x2_24133)) {
  case TAG_MkPair: {
    V v_x_24134 = heff_field(v_x2_24133, 0);
    V v_n_24135 = heff_field(v_x2_24133, 1);
    V v_ru_24x2_24133_24MkPair = heff_take_reuse_n(v_x2_24133, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24133_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24134}), v_n_24135});
  }
  default: return heff_nomatch(v_x2_24133);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_lam22(V self, V *args) {
  V v_n_24139 = args[0];
  V v_a_24138 = heff_env(self)[0];
  V v_x_24136 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_24140 = heff_tr(heff_call(v_a_24138, 1, (V[]){v_n_24139}));
  V v_x2_24145;
  switch (heff_tag_of(v_a_24140)) {
  case TAG_MkPair: {
    V v_a_24141 = heff_field(v_a_24140, 0);
    V v_a_24142 = heff_field(v_a_24140, 1);
    heff_take_n(v_a_24140, 3ULL, 2);
    V v_t_24143 = (g_heff_2ecompile_2efields_2ereadAt(v_a_24141, heff_dup(v_x_24136)));
    V v_x2_24144 = heff_tr(heff_call(v_t_24143, 1, (V[]){v_a_24142}));
    v_x2_24145 = v_x2_24144;
    break;
  }
  default: heff_nomatch(v_a_24140);
  }
  switch (heff_tag_of(v_x2_24145)) {
  case TAG_MkPair: {
    V v_x_24146 = heff_field(v_x2_24145, 0);
    V v_n_24147 = heff_field(v_x2_24145, 1);
    V v_ru_24x2_24145_24MkPair = heff_take_reuse_n(v_x2_24145, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_24145_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24136, v_x_24146}), v_n_24147});
  }
  default: return heff_nomatch(v_x2_24145);
  }
}
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str10, 0, "");
Clo g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_entry, 4, 0};

V g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle(V v_tag_240, V v_x2_241, V v_acc_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530: {
    top_TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530: ;
    switch (heff_tag_of(v_x2_241)) {
    case TAG_EVar: {
      return heff_dup(v_acc_242);
    }
    case TAG_EGlobal: {
      return heff_dup(v_acc_242);
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x2_241, 1);
      if ((heff_dup(v_acc_242) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erunes_2ereads);
        V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str0);
        V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str1);
        V t_3 = v_b_247;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_e_243 = t_3;
        goto top_TAG_Enter_24heff_2ecompile_2erunes_2ereads;
      }
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_x2_241, 0);
      V v_args_249 = heff_field(v_x2_241, 1);
      V v_t_2410;
      if ((heff_dup(v_acc_242) == NTAG(TAG_True))) {
        v_t_2410 = NTAG(TAG_True);
      } else {
        v_t_2410 = (g_heff_2ecompile_2erunes_2ereads(v_g_248));
      }
      return (g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(v_args_249, v_t_2410));
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x2_241, 1);
      V v_b_2413 = heff_field(v_x2_241, 2);
      if ((heff_dup(v_acc_242) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V v_a_2414 = (g_heff_2ecompile_2erunes_2ereads(v_a_2412));
        if ((heff_dup(v_a_2414) == NTAG(TAG_True))) {
          heff_drop(v_a_2414);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_a_2414);
          V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erunes_2ereads);
          V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str2);
          V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str3);
          V t_3 = v_b_2413;
          v_tag_240 = t_0;
          v_x2_241 = t_1;
          v_acc_242 = t_2;
          v_e_243 = t_3;
          goto top_TAG_Enter_24heff_2ecompile_2erunes_2ereads;
        }
      }
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x2_241, 0);
      return (g_heff_2ecompile_2eir_2efoldFields_24s2077149100x1509340393(v_fs_2415, heff_dup(v_acc_242)));
    }
    case TAG_EProj: {
      V v_e_2417 = heff_field(v_x2_241, 0);
      if ((heff_dup(v_acc_242) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erunes_2ereads);
        V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str4);
        V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str5);
        V t_3 = v_e_2417;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_e_243 = t_3;
        goto top_TAG_Enter_24heff_2ecompile_2erunes_2ereads;
      }
    }
    case TAG_ETag: {
      V v_args_2422 = heff_field(v_x2_241, 1);
      return (g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(v_args_2422, heff_dup(v_acc_242)));
    }
    case TAG_EMatch: {
      V v_s_2424 = heff_field(v_x2_241, 0);
      V v_arms_2425 = heff_field(v_x2_241, 1);
      V v_t_2426;
      if ((heff_dup(v_acc_242) == NTAG(TAG_True))) {
        v_t_2426 = NTAG(TAG_True);
      } else {
        v_t_2426 = (g_heff_2ecompile_2erunes_2ereads(v_s_2424));
      }
      return (g_heff_2ecompile_2eir_2efoldArms_24s387193246x744492884(v_arms_2425, v_t_2426));
    }
    case TAG_EPrim: {
      return heff_dup(v_acc_242);
    }
    case TAG_EPrimCall: {
      V v_args_2429 = heff_field(v_x2_241, 1);
      return (g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(v_args_2429, heff_dup(v_acc_242)));
    }
    case TAG_ECall: {
      V v_args_2431 = heff_field(v_x2_241, 1);
      return (g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(v_args_2431, heff_dup(v_acc_242)));
    }
    case TAG_EInt: {
      return heff_dup(v_acc_242);
    }
    case TAG_EFloat: {
      return heff_dup(v_acc_242);
    }
    case TAG_EStr: {
      return heff_dup(v_acc_242);
    }
    case TAG_EBytes: {
      return heff_dup(v_acc_242);
    }
    case TAG_EFixed: {
      return heff_dup(v_acc_242);
    }
    case TAG_EFloat32: {
      return heff_dup(v_acc_242);
    }
    case TAG_EAbandon: {
      return heff_dup(v_acc_242);
    }
    case TAG_EBool: {
      V v_c_2439 = heff_field(v_x2_241, 0);
      V v_t_2440 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2439, NTAG(TAG_Nil)));
      return ({ V a_0 = v_t_2440; V a_1 = heff_dup(v_acc_242); V r_ = (g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(a_0, a_1)); heff_drop(v_t_2440); r_; });
    }
    case TAG_ESet: {
      V v_a_2442 = heff_field(v_x2_241, 1);
      V v_b_2443 = heff_field(v_x2_241, 2);
      if ((heff_dup(v_acc_242) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V v_a_2444 = (g_heff_2ecompile_2erunes_2ereads(v_a_2442));
        if ((heff_dup(v_a_2444) == NTAG(TAG_True))) {
          heff_drop(v_a_2444);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_a_2444);
          V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erunes_2ereads);
          V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str6);
          V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str7);
          V t_3 = v_b_2443;
          v_tag_240 = t_0;
          v_x2_241 = t_1;
          v_acc_242 = t_2;
          v_e_243 = t_3;
          goto top_TAG_Enter_24heff_2ecompile_2erunes_2ereads;
        }
      }
    }
    case TAG_EValues: {
      V v_es_2445 = heff_field(v_x2_241, 0);
      return (g_heff_2ecompile_2eir_2efoldList_24s505228539x1885775549(v_es_2445, heff_dup(v_acc_242)));
    }
    case TAG_EFix: {
      V v_b_2447 = heff_field(v_x2_241, 1);
      if ((heff_dup(v_acc_242) == NTAG(TAG_True))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2erunes_2ereads);
        V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str8);
        V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str9);
        V t_3 = v_b_2447;
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_e_243 = t_3;
        goto top_TAG_Enter_24heff_2ecompile_2erunes_2ereads;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Enter_24heff_2ecompile_2erunes_2ereads: {
    top_TAG_Enter_24heff_2ecompile_2erunes_2ereads: ;
    switch (heff_tag_of(v_e_243)) {
    case TAG_EPrimCall: {
      V v_e1_2448 = heff_field(v_e_243, 0);
      V v_argv_2449 = heff_field(v_e_243, 1);
      switch (heff_tag_of(v_e1_2448)) {
      case TAG_StrRuneAt: {
        return NTAG(TAG_True);
      }
      case TAG_StrRuneWidth: {
        return NTAG(TAG_True);
      }
      default: {
        return ({ V b_0 = ((V)&g_heff_2ecompile_2erunes_2ereads_clo); V a_1 = v_argv_2449; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); r_; });
      }
      }
    }
    default: {
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530);
      V t_1 = v_e_243;
      V t_2 = NTAG(TAG_False);
      V t_3 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_str10);
      v_tag_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      v_e_243 = t_3;
      goto top_TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530;
    }
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eir_2efoldParts_24s1397476960x2104853530_24cycle(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947_entry, 2, 0};

V g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_fs_243 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_t_246 = (g_heff_2ecompile_2eworlds_2eworldsIn(v_e_245, v_acc_241));
      V t_0 = v_fs_243;
      V t_1 = v_t_246;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947(a0, a[1]); heff_drop(a0); return r;
}