// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_IAnn 21211
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkBinding 51651
#define TAG_MkSegment 38079
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TPi 30745
#define TAG_TSig 38418
#define TAG_TSum 38796
#define LBL_decl 9574769
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_head 9693863
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_unit 10090059
#define LBL_vars 10107635
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1197713756x51535435_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1197713756x51535435_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1275826172x93256526_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s967883893x662417176_24dps_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf(V, V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2erunArgs(V, V);
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo;
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24cpr(V, V, V);
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s280627497x741826998_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithBoundOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithBoundOf_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_24tok2_clo;
V g_list_2eall_24s1414119352x995333365(V, V);
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a);
extern Clo g_list_2eall_24s1414119352x995333365_clo;
V g_list_2eany_24s2074406606x298866118(V);
V g_list_2eany_24s2074406606x298866118_entry(V self, V *a);
extern Clo g_list_2eany_24s2074406606x298866118_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1258450377x973220636(V);
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s2016093283x1174801437(V, V);
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s205414595x1692305030(V);
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s961097229x1129443801(V);
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_clo;
V g_list_2emap_24s97919758x216970748(V, V);
V g_list_2emap_24s97919758x216970748_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereversedBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereversedBytes(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_t_243 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_t_243, v_acc_242);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ereversedBytes(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str2, 12, "builtin.Unit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eleaving_str3, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2eleaving_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eleaving_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eleaving(V v_cx_240, V v_sp_241, V v_n_242, V v_call_243) {
top: ;
  if (heff_intLe_c_lent(v_n_242, MK_INT(0LL), 2)) {
    heff_drop(v_n_242);
    return heff_dup(v_call_243);
  } else {
    V v_e_244 = (g_heff_2esyntax_2epresyntax_2eleaving(v_cx_240, v_sp_241, heff_intSub(v_n_242, MK_INT(1LL)), v_call_243));
    V v_sp_247;
    switch (heff_tag_of(v_e_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_e_244, 1));
      v_sp_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str0)}), heff_dup(v_sp_247)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str1)}), v_sp_247});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_e_244)) {
    case TAG_At: {
      V v_s_2413 = heff_dup(heff_field(v_e_244, 1));
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    V v_e_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_e_244, v_t_2411}), v_t_2414});
    V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2416}), heff_dup(v_sp_241)});
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str2)}), heff_dup(v_sp_241)});
    V v_t_2419 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamAnn, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eleaving_str3), heff_dup(v_sp_241), v_t_2418}), v_e_2415});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2417, v_t_2420));
  }
}
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2esyntax_2epresyntax_2eleaving(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}

HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24cpr(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_StmtBind: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_xsp_246 = heff_field(v_x31_243, 1);
      V v_e_247 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24StmtBind = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      V v_x1_248 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_247}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x1_248, 0);
        V v_y_2410 = heff_field(v_x1_248, 1);
        heff_take_n(v_x1_248, 3ULL, 2);
        return ((HeffT3){{v_x_249, heff_tag_re_n(v_ru_24x31_243_24StmtBind, TAG_StmtBind, 3, 3ULL, (V[]){v_x_245, v_xsp_246, v_y_2410}), v_sp_244}});
      }
      default: return ((HeffT3){{heff_nomatch(v_x1_248)}});
      }
    }
    case TAG_StmtLet: {
      V v_p_2411 = heff_field(v_x31_243, 0);
      V v_e_2412 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x1_2413 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2412}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x1_2413, 0);
        V v_y_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        return ((HeffT3){{v_x_2414, heff_tag_at_n(v_ru_24x3_242_24At, TAG_StmtLet, 2, (V[]){v_p_2411, v_y_2415}), v_sp_244}});
      }
      default: return ((HeffT3){{heff_nomatch(v_x1_2413)}});
      }
    }
    case TAG_StmtExpr: {
      V v_e_2416 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24StmtExpr = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      V v_x1_2417 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2416}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x1_2417, 0);
        V v_y_2419 = heff_field(v_x1_2417, 1);
        heff_take_n(v_x1_2417, 3ULL, 2);
        return ((HeffT3){{v_x_2418, heff_tag_at_n(v_ru_24x31_243_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_y_2419}), v_sp_244}});
      }
      default: return ((HeffT3){{heff_nomatch(v_x1_2417)}});
      }
    }
    case TAG_StmtLetMut: {
      V v_x_2420 = heff_field(v_x31_243, 0);
      V v_xsp_2421 = heff_field(v_x31_243, 1);
      V v_e_2422 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24StmtLetMut = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      V v_x1_2423 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2422}));
      switch (heff_tag_of(v_x1_2423)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_field(v_x1_2423, 0);
        V v_y_2425 = heff_field(v_x1_2423, 1);
        heff_take_n(v_x1_2423, 3ULL, 2);
        return ((HeffT3){{v_x_2424, heff_tag_re_n(v_ru_24x31_243_24StmtLetMut, TAG_StmtLetMut, 3, 3ULL, (V[]){v_x_2420, v_xsp_2421, v_y_2425}), v_sp_244}});
      }
      default: return ((HeffT3){{heff_nomatch(v_x1_2423)}});
      }
    }
    case TAG_StmtLetElse: {
      V v_p_2426 = heff_field(v_x31_243, 0);
      V v_e_2427 = heff_field(v_x31_243, 1);
      V v_ss_2428 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24StmtLetElse = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24At, 2);
      V v_x1_2429 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_e_2427}));
      switch (heff_tag_of(v_x1_2429)) {
      case TAG_MkPair: {
        V v_x_2430 = heff_field(v_x1_2429, 0);
        V v_y_2431 = heff_field(v_x1_2429, 1);
        heff_take_n(v_x1_2429, 3ULL, 2);
        V v_t_2432 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_2433 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_2432, v_x_2430, v_ss_2428));
        {
          V v_field_2434 = v_t_2433.f[0];
          V v_field_2435 = v_t_2433.f[1];
          V v_x_2436 = v_field_2434;
          V v_y_2437 = v_field_2435;
          return ((HeffT3){{v_x_2436, heff_tag_re_n(v_ru_24x31_243_24StmtLetElse, TAG_StmtLetElse, 3, 1ULL, (V[]){v_p_2426, v_y_2431, v_y_2437}), v_sp_244}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x1_2429)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_242)}});
  }
}

HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s280627497x741826998_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_e_246 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtBind = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2436;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2436 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_246)) {
        case TAG_At: {
          V v_a_247 = heff_dup(heff_field(v_e_246, 0));
          switch (heff_tag_of(v_a_247)) {
          case TAG_ELam: {
            heff_take_n(v_a_247, 0ULL, 2);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_247, 0ULL, 1);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_247, 0ULL, 4);
            switch (heff_tag_of(v_e_246)) {
            case TAG_At: {
              v_x_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_246);
            }
            break;
          }
          default: {
            heff_drop(v_a_247);
            HeffT2 v_t_2431 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_246)));
            {
              V v_field_2432 = v_t_2431.f[0];
              V v_field_2433 = v_t_2431.f[1];
              V v_a_2434 = v_field_2432;
              V v_a_2435 = v_field_2433;
              heff_drop(v_a_2435);
              v_x_2436 = v_a_2434;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_246);
        }
      }
      return ((HeffT3){{v_x_2436, heff_tag_re_n(v_ru_24x31_242_24StmtBind, TAG_StmtBind, 3, 7ULL, (V[]){v_x_244, v_xsp_245, v_e_246}), v_sp_243}});
    }
    case TAG_StmtLet: {
      V v_p_2437 = heff_field(v_x31_242, 0);
      V v_e_2438 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_x_2468;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2468 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_2438)) {
        case TAG_At: {
          V v_a_2439 = heff_dup(heff_field(v_e_2438, 0));
          switch (heff_tag_of(v_a_2439)) {
          case TAG_ELam: {
            heff_take_n(v_a_2439, 0ULL, 2);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_2439, 0ULL, 1);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_2439, 0ULL, 1);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_2439, 0ULL, 1);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_2439, 0ULL, 1);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_2439, 0ULL, 4);
            switch (heff_tag_of(v_e_2438)) {
            case TAG_At: {
              v_x_2468 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2438);
            }
            break;
          }
          default: {
            heff_drop(v_a_2439);
            HeffT2 v_t_2463 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_2438)));
            {
              V v_field_2464 = v_t_2463.f[0];
              V v_field_2465 = v_t_2463.f[1];
              V v_a_2466 = v_field_2464;
              V v_a_2467 = v_field_2465;
              heff_drop(v_a_2467);
              v_x_2468 = v_a_2466;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2438);
        }
      }
      return ((HeffT3){{v_x_2468, heff_tag_at_n(v_ru_24x3_241_24At, TAG_StmtLet, 2, (V[]){v_p_2437, v_e_2438}), v_sp_243}});
    }
    case TAG_StmtExpr: {
      V v_e_2469 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2499;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2499 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_2469)) {
        case TAG_At: {
          V v_a_2470 = heff_dup(heff_field(v_e_2469, 0));
          switch (heff_tag_of(v_a_2470)) {
          case TAG_ELam: {
            heff_take_n(v_a_2470, 0ULL, 2);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_2470, 0ULL, 1);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_2470, 0ULL, 1);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_2470, 0ULL, 1);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_2470, 0ULL, 1);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_2470, 0ULL, 4);
            switch (heff_tag_of(v_e_2469)) {
            case TAG_At: {
              v_x_2499 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_2469);
            }
            break;
          }
          default: {
            heff_drop(v_a_2470);
            HeffT2 v_t_2494 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_2469)));
            {
              V v_field_2495 = v_t_2494.f[0];
              V v_field_2496 = v_t_2494.f[1];
              V v_a_2497 = v_field_2495;
              V v_a_2498 = v_field_2496;
              heff_drop(v_a_2498);
              v_x_2499 = v_a_2497;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_2469);
        }
      }
      return ((HeffT3){{v_x_2499, heff_tag_re_n(v_ru_24x31_242_24StmtExpr, TAG_StmtExpr, 1, 1ULL, (V[]){v_e_2469}), v_sp_243}});
    }
    case TAG_StmtLetMut: {
      V v_x_24100 = heff_field(v_x31_242, 0);
      V v_xsp_24101 = heff_field(v_x31_242, 1);
      V v_e_24102 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetMut = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_24132;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_24132 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_24102)) {
        case TAG_At: {
          V v_a_24103 = heff_dup(heff_field(v_e_24102, 0));
          switch (heff_tag_of(v_a_24103)) {
          case TAG_ELam: {
            heff_take_n(v_a_24103, 0ULL, 2);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_24103, 0ULL, 1);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_24103, 0ULL, 1);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_24103, 0ULL, 1);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_24103, 0ULL, 1);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_24103, 0ULL, 4);
            switch (heff_tag_of(v_e_24102)) {
            case TAG_At: {
              v_x_24132 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24102);
            }
            break;
          }
          default: {
            heff_drop(v_a_24103);
            HeffT2 v_t_24127 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24102)));
            {
              V v_field_24128 = v_t_24127.f[0];
              V v_field_24129 = v_t_24127.f[1];
              V v_a_24130 = v_field_24128;
              V v_a_24131 = v_field_24129;
              heff_drop(v_a_24131);
              v_x_24132 = v_a_24130;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_24102);
        }
      }
      return ((HeffT3){{v_x_24132, heff_tag_re_n(v_ru_24x31_242_24StmtLetMut, TAG_StmtLetMut, 3, 7ULL, (V[]){v_x_24100, v_xsp_24101, v_e_24102}), v_sp_243}});
    }
    case TAG_StmtLetElse: {
      V v_p_24133 = heff_field(v_x31_242, 0);
      V v_e_24134 = heff_field(v_x31_242, 1);
      V v_ss_24135 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetElse = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_24165;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_24165 = NTAG(TAG_True);
      } else {
        switch (heff_tag_of(v_e_24134)) {
        case TAG_At: {
          V v_a_24136 = heff_dup(heff_field(v_e_24134, 0));
          switch (heff_tag_of(v_a_24136)) {
          case TAG_ELam: {
            heff_take_n(v_a_24136, 0ULL, 2);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_EDo: {
            heff_take_n(v_a_24136, 0ULL, 1);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_a_24136, 0ULL, 1);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_ELazy: {
            heff_take_n(v_a_24136, 0ULL, 1);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_a_24136, 0ULL, 1);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_a_24136, 0ULL, 4);
            switch (heff_tag_of(v_e_24134)) {
            case TAG_At: {
              v_x_24165 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_e_24134);
            }
            break;
          }
          default: {
            heff_drop(v_a_24136);
            HeffT2 v_t_24160 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_e_24134)));
            {
              V v_field_24161 = v_t_24160.f[0];
              V v_field_24162 = v_t_24160.f[1];
              V v_a_24163 = v_field_24161;
              V v_a_24164 = v_field_24162;
              heff_drop(v_a_24164);
              v_x_24165 = v_a_24163;
            }
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_e_24134);
        }
      }
      HeffT2 v_t_24166 = (g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24cpr(v_x_24165, v_ss_24135));
      {
        V v_field_24167 = v_t_24166.f[0];
        V v_field_24168 = v_t_24166.f[1];
        V v_x_24169 = v_field_24167;
        V v_y_24170 = v_field_24168;
        return ((HeffT3){{v_x_24169, heff_tag_re_n(v_ru_24x31_242_24StmtLetElse, TAG_StmtLetElse, 3, 3ULL, (V[]){v_p_24133, v_e_24134, v_y_24170}), v_sp_243}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eisControl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eisControl_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eisControl(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ENotationVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_False);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      V v_alts_2436 = heff_field(v_x11_241, 1);
      HEFF_LAST return g_list_2eany_24s2074406606x298866118(heff_dup(v_alts_2436));
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      return NTAG(TAG_True);
    }
    case TAG_EWhile: {
      return NTAG(TAG_True);
    }
    case TAG_EFor: {
      return NTAG(TAG_True);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_True);
    }
    case TAG_EBreak: {
      return NTAG(TAG_True);
    }
    case TAG_EContinue: {
      return NTAG(TAG_True);
    }
    case TAG_EReturn: {
      return NTAG(TAG_True);
    }
    case TAG_ENest: {
      return NTAG(TAG_False);
    }
    case TAG_ELazy: {
      return NTAG(TAG_False);
    }
    case TAG_ETuple: {
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      return NTAG(TAG_True);
    }
    case TAG_EWith: {
      return NTAG(TAG_True);
    }
    case TAG_EWithBound: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2eisControl(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkSegment: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_a_2411 = heff_field(v_a_247, 2);
        V v_a_2412 = heff_field(v_a_247, 3);
        V v_a_2413 = heff_field(v_a_247, 4);
        V v_ru_24a_247_24MkSegment = heff_take_reuse_n(v_a_247, 31ULL, 5);
        V v_a_2414;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2414 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2414 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_249)));
        }
        V v_t_2415 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkSegment, TAG_MkSegment, 5, 31ULL, (V[]){v_a_249, v_a_2410, v_a_2411, v_a_2412, v_a_2413}), v_a_248});
        V v_cell_2416 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
        V v_u_2417 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2416);
        V t_0 = v_a_2414;
        V t_1 = v_xs_246;
        V t_2 = v_u_2417;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s967883893x662417176_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkSegment: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_a_2411 = heff_field(v_a_247, 2);
        V v_a_2412 = heff_field(v_a_247, 3);
        V v_a_2413 = heff_field(v_a_247, 4);
        V v_ru_24a_247_24MkSegment = heff_take_reuse_n(v_a_247, 31ULL, 5);
        V v_a_2414 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_249), v_st_240));
        V v_t_2415 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkSegment, TAG_MkSegment, 5, 31ULL, (V[]){v_a_249, v_a_2410, v_a_2411, v_a_2412, v_a_2413}), v_a_248});
        V v_cell_2416 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
        V v_u_2417 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2416);
        V t_0 = v_a_2414;
        V t_1 = v_xs_246;
        V t_2 = v_u_2417;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1275826172x93256526_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_x31_247 = heff_field(v_x_245, 0);
      V v_sp_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_SetField: {
        V v_x_249 = heff_field(v_x31_247, 0);
        V v_xsp_2410 = heff_field(v_x31_247, 1);
        V v_e_2411 = heff_field(v_x31_247, 2);
        V v_ru_24x31_247_24SetField = heff_take_reuse_n(v_x31_247, 7ULL, 3);
        V v_x_2412 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_2411), v_st_240));
        V v_t_2413 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_247_24SetField, TAG_SetField, 3, 7ULL, (V[]){v_x_249, v_xsp_2410, v_e_2411}), v_sp_248});
        V v_cell_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
        V v_u_2415 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2414);
        V t_0 = v_x_2412;
        V t_1 = v_xs_246;
        V t_2 = v_u_2415;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      case TAG_BadFieldSet: {
        V v_e_2416 = heff_field(v_x31_247, 0);
        V v_ru_24x31_247_24BadFieldSet = heff_take_reuse_n(v_x31_247, 1ULL, 1);
        V v_x_2417 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_e_2416), v_st_240));
        V v_t_2418 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_247_24BadFieldSet, TAG_BadFieldSet, 1, 1ULL, (V[]){v_e_2416}), v_sp_248});
        V v_cell_2419 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
        V v_u_2420 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2419);
        V t_0 = v_x_2417;
        V t_1 = v_xs_246;
        V t_2 = v_u_2420;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1197713756x51535435_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkBinding: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkBinding = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_248 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_247), v_st_240));
        V v_t_249 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkBinding, TAG_MkBinding, 2, 3ULL, (V[]){v_a_246, v_a_247}), v_a_245});
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
        HeffT2 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1197713756x51535435_24dps_24cpr(v_a_248, v_xs_243, v_cell_2410));
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          V v_x_2414 = v_field_2412;
          V v__5f_2415 = v_field_2413;
          heff_drop(v__5f_2415);
          return ((HeffT2){{v_x_2414, v_cell_2410}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xsp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_244}));
    V v_t_2415;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsInferable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_dup(heff_field(v_i_246, 1));
        v_t_249 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsInferable, TAG_TInf, 1, (V[]){v_i_246}), v_t_249});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsCheckable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
      break;
    }
    case TAG_IsType: {
      V v_t_2414 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_2415 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_re_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, 3ULL, (V[]){v_x_242, v_xsp_243, v_t_2415});
  }
  case TAG_PiImplicit: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_xsp_2417 = heff_field(v_x2_241, 1);
    V v_bsp_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = heff_field(v_x2_241, 3);
    V v_d_2420 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2419}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_IsInferable: {
      V v_i_2422 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsInferable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsInferable, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2426 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsCheckable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_c_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_c_2426);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
      break;
    }
    case TAG_IsType: {
      V v_t_2430 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      v_t_2431 = v_t_2430;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2444;
    switch (heff_tag_of(v_d_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_d_2420, 0);
      V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsInferable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsInferable, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2443 = v_c_2438;
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsType = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_t_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsType, TAG_CType, 1, (V[]){v_t_2439}), v_t_2442});
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24d_2420_24Just, TAG_Just, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_d_2420);
    }
    return heff_tag_re_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, 7ULL, (V[]){v_x_2416, v_xsp_2417, v_bsp_2418, v_t_2431, v_t_2444});
  }
  case TAG_PiInstance: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_xsp_2446 = heff_field(v_x2_241, 1);
    V v_bsp_2447 = heff_field(v_x2_241, 2);
    V v_t_2448 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_x1_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2448}));
    V v_t_2459;
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_IsInferable: {
      V v_i_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsInferable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_i_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_i_2450);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsInferable, TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2454 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsCheckable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_c_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_c_2454);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
      break;
    }
    case TAG_IsType: {
      V v_t_2458 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      v_t_2459 = v_t_2458;
      break;
    }
    default: heff_nomatch(v_x1_2449);
    }
    return heff_tag_re_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, 7ULL, (V[]){v_x_2445, v_xsp_2446, v_bsp_2447, v_t_2459});
  }
  case TAG_PiAnon: {
    V v_t_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_IsInferable: {
      V v_i_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsInferable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_i_2462)) {
      case TAG_At: {
        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_i_2462);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsInferable, TAG_TInf, 1, (V[]){v_i_2462}), v_t_2465});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2466 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsCheckable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_c_2466)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_c_2466, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_c_2466);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2466}), v_t_2469});
      break;
    }
    case TAG_IsType: {
      V v_t_2470 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      v_t_2471 = v_t_2470;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclareField = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        V v_ru_24x1_248_24IsInferable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsInferable, TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        V v_ru_24x1_248_24IsCheckable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2431;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 2);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2419}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_IsInferable: {
          V v_i_2421 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_i_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_i_2421);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2425 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          v_t_2430 = v_c_2425;
          break;
        }
        case TAG_IsType: {
          V v_t_2426 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsType = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_t_2426);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsType, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_242_24DeclareField, TAG_DeclareField, 4, 3ULL, (V[]){v_x_244, v_xsp_245, v_t_2418, v_t_2431}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2432 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldDecl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsInferable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsInferable, TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsCheckable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_c_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_c_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_c_2438);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2438}), v_t_2441});
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2443 = v_t_2442;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4, 67, " := e` sets a `let mut` variable: it is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str5, 45, "a `while` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str6, 43, "a `for` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str7, 78, "an `if` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str8, 78, "`break` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str9, 81, "`continue` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str10, 103, "`return e` ends a `do` block as one of its statements (or an arm of its `if` or `case`), not as a value");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str11, 67, "`(<- c)`, the value of an action, is in a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str12, 72, "a `try` is a statement of a `do` block (or an arm of its `if` or `case`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str13, 73, "a `with` is a statement of a `do` block (or an arm of its `if` or `case`)");
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_IVar, 1, (V[]){v_x_244}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_245});
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_247 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_IVar, 1, (V[]){v_x_246}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_247});
    }
    case TAG_ENotationVar: {
      V v_x_248 = heff_field(v_x21_242, 0);
      V v_ksp_249 = heff_field(v_x21_242, 1);
      V v_said_2410 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ENotationVar = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_2411 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24ENotationVar, TAG_INotationVar, 3, (V[]){v_x_248, v_ksp_249, v_said_2410}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_ETag: {
      V v_t_2412 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2413 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_2412, heff_dup(v_sp_243), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_2413, v_sp_243})});
    }
    case TAG_EInt: {
      V v_i_2414 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_IInt, 1, (V[]){v_i_2414}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_EFloat: {
      V v_x_2416 = heff_tget_v(v_x21_242, 0);
      V v_ru_24x21_242_24EFloat = heff_take_reuse_nf(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2417 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_IFloat, 1, (V[]){v_x_2416}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2417});
    }
    case TAG_EString: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2419 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24EString, TAG_IString, 1, (V[]){v_x_2418}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2419});
    }
    case TAG_EBinary: {
      V v_segs_2420 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      return (g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok2(v_ru_24x2_241_24At, v_r_240, NTAG(TAG_False), v_segs_2420, v_sp_243));
    }
    case TAG_ERune: {
      V v_c_2421 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2422 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_IRune, 1, (V[]){v_c_2421}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2422});
    }
    case TAG_EWord: {
      V v_w_2423 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf_24tok2(v_ru_24x2_241_24At, v_w_2423, v_sp_243));
    }
    case TAG_EApp: {
      V v_h_2424 = heff_field(v_x21_242, 0);
      V v_args_2425 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2426 = (g_heff_2esyntax_2epresyntax_2erunArgs(heff_dup(v_h_2424), v_args_2425));
      return (g_heff_2esyntax_2epresyntax_2eappOf_24tok2(v_ru_24x2_241_24At, v_r_240, v_h_2424, v_t_2426, v_sp_243));
    }
    case TAG_EProject: {
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2428 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_2428, v_sp_243})});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2431 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_2431, v_sp_243})});
    }
    case TAG_EPi: {
      V v_b_2432 = heff_field(v_x21_242, 0);
      V v_cod_2433 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2epiBinderOf(heff_dup(v_r_240), v_b_2432));
      V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2433}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        V v_ru_24x1_2435_24IsInferable = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2435_24IsInferable, TAG_TInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        V v_ru_24x1_2435_24IsCheckable = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
        V v_t_2443;
        switch (heff_tag_of(v_c_2440)) {
        case TAG_At: {
          V v_s_2442 = heff_dup(heff_field(v_c_2440, 1));
          v_t_2443 = v_s_2442;
          break;
        }
        default: heff_nomatch(v_c_2440);
        }
        v_t_2445 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2435_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2440}), v_t_2443});
        break;
      }
      case TAG_IsType: {
        V v_t_2444 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2445 = v_t_2444;
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2446 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2434, v_t_2445}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2446});
    }
    case TAG_ELam: {
      V v_x211_2447 = heff_field(v_x21_242, 0);
      V v_body_2448 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_2447)) {
      case TAG_LamName: {
        V v_x_2449 = heff_field(v_x211_2447, 0);
        V v_xsp_2450 = heff_field(v_x211_2447, 1);
        heff_take_n(v_x211_2447, 3ULL, 2);
        V v_x1_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2448}));
        V v_t_2461;
        switch (heff_tag_of(v_x1_2451)) {
        case TAG_IsInferable: {
          V v_i_2452 = heff_field(v_x1_2451, 0);
          V v_ru_24x1_2451_24IsInferable = heff_take_reuse_n(v_x1_2451, 1ULL, 1);
          V v_t_2455;
          switch (heff_tag_of(v_i_2452)) {
          case TAG_At: {
            V v_s_2454 = heff_dup(heff_field(v_i_2452, 1));
            v_t_2455 = v_s_2454;
            break;
          }
          default: heff_nomatch(v_i_2452);
          }
          v_t_2461 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2451_24IsInferable, TAG_CInf, 1, (V[]){v_i_2452}), v_t_2455});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2456 = heff_field(v_x1_2451, 0);
          heff_take_n(v_x1_2451, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2461 = v_c_2456;
          break;
        }
        case TAG_IsType: {
          V v_t_2457 = heff_field(v_x1_2451, 0);
          V v_ru_24x1_2451_24IsType = heff_take_reuse_n(v_x1_2451, 1ULL, 1);
          V v_t_2460;
          switch (heff_tag_of(v_t_2457)) {
          case TAG_At: {
            V v_s_2459 = heff_dup(heff_field(v_t_2457, 1));
            v_t_2460 = v_s_2459;
            break;
          }
          default: heff_nomatch(v_t_2457);
          }
          v_t_2461 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2451_24IsType, TAG_CType, 1, (V[]){v_t_2457}), v_t_2460});
          break;
        }
        default: heff_nomatch(v_x1_2451);
        }
        V v_t_2462 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2449, v_xsp_2450, v_t_2461}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2462});
      }
      case TAG_LamImplicit: {
        V v_x_2463 = heff_field(v_x211_2447, 0);
        V v_xsp_2464 = heff_field(v_x211_2447, 1);
        heff_take_n(v_x211_2447, 3ULL, 2);
        V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2448}));
        V v_t_2475;
        switch (heff_tag_of(v_x1_2465)) {
        case TAG_IsInferable: {
          V v_i_2466 = heff_field(v_x1_2465, 0);
          V v_ru_24x1_2465_24IsInferable = heff_take_reuse_n(v_x1_2465, 1ULL, 1);
          V v_t_2469;
          switch (heff_tag_of(v_i_2466)) {
          case TAG_At: {
            V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
            v_t_2469 = v_s_2468;
            break;
          }
          default: heff_nomatch(v_i_2466);
          }
          v_t_2475 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2465_24IsInferable, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2470 = heff_field(v_x1_2465, 0);
          heff_take_n(v_x1_2465, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2475 = v_c_2470;
          break;
        }
        case TAG_IsType: {
          V v_t_2471 = heff_field(v_x1_2465, 0);
          V v_ru_24x1_2465_24IsType = heff_take_reuse_n(v_x1_2465, 1ULL, 1);
          V v_t_2474;
          switch (heff_tag_of(v_t_2471)) {
          case TAG_At: {
            V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
            v_t_2474 = v_s_2473;
            break;
          }
          default: heff_nomatch(v_t_2471);
          }
          v_t_2475 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2465_24IsType, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
          break;
        }
        default: heff_nomatch(v_x1_2465);
        }
        V v_t_2476 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2463, v_xsp_2464, v_t_2475}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2476});
      }
      case TAG_LamAnn: {
        V v_x_2477 = heff_field(v_x211_2447, 0);
        V v_xsp_2478 = heff_field(v_x211_2447, 1);
        V v_t_2479 = heff_field(v_x211_2447, 2);
        heff_take_n(v_x211_2447, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        V v_x1_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2479}));
        V v_t_2490;
        switch (heff_tag_of(v_x1_2480)) {
        case TAG_IsInferable: {
          V v_i_2481 = heff_field(v_x1_2480, 0);
          V v_ru_24x1_2480_24IsInferable = heff_take_reuse_n(v_x1_2480, 1ULL, 1);
          V v_t_2484;
          switch (heff_tag_of(v_i_2481)) {
          case TAG_At: {
            V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
            v_t_2484 = v_s_2483;
            break;
          }
          default: heff_nomatch(v_i_2481);
          }
          v_t_2490 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2480_24IsInferable, TAG_TInf, 1, (V[]){v_i_2481}), v_t_2484});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2485 = heff_field(v_x1_2480, 0);
          V v_ru_24x1_2480_24IsCheckable = heff_take_reuse_n(v_x1_2480, 1ULL, 1);
          V v_t_2488;
          switch (heff_tag_of(v_c_2485)) {
          case TAG_At: {
            V v_s_2487 = heff_dup(heff_field(v_c_2485, 1));
            v_t_2488 = v_s_2487;
            break;
          }
          default: heff_nomatch(v_c_2485);
          }
          v_t_2490 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2480_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2485}), v_t_2488});
          break;
        }
        case TAG_IsType: {
          V v_t_2489 = heff_field(v_x1_2480, 0);
          heff_take_n(v_x1_2480, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2490 = v_t_2489;
          break;
        }
        default: heff_nomatch(v_x1_2480);
        }
        V v_t_2491 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2448}));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2477, v_xsp_2478, v_t_2490, v_t_2491, v_sp_243));
      }
      default: return heff_nomatch(v_x211_2447);
      }
    }
    case TAG_EAnn: {
      V v_a_2492 = heff_field(v_x21_242, 0);
      V v_t_2493 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_2494 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_2492}));
      V v_t_24104;
      switch (heff_tag_of(v_x1_2494)) {
      case TAG_IsInferable: {
        V v_i_2495 = heff_field(v_x1_2494, 0);
        V v_ru_24x1_2494_24IsInferable = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
        V v_t_2498;
        switch (heff_tag_of(v_i_2495)) {
        case TAG_At: {
          V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
          v_t_2498 = v_s_2497;
          break;
        }
        default: heff_nomatch(v_i_2495);
        }
        v_t_24104 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2494_24IsInferable, TAG_CInf, 1, (V[]){v_i_2495}), v_t_2498});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2499 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24104 = v_c_2499;
        break;
      }
      case TAG_IsType: {
        V v_t_24100 = heff_field(v_x1_2494, 0);
        V v_ru_24x1_2494_24IsType = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
        V v_t_24103;
        switch (heff_tag_of(v_t_24100)) {
        case TAG_At: {
          V v_s_24102 = heff_dup(heff_field(v_t_24100, 1));
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_t_24100);
        }
        v_t_24104 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2494_24IsType, TAG_CType, 1, (V[]){v_t_24100}), v_t_24103});
        break;
      }
      default: heff_nomatch(v_x1_2494);
      }
      V v_x1_24105 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2493}));
      V v_t_24115;
      switch (heff_tag_of(v_x1_24105)) {
      case TAG_IsInferable: {
        V v_i_24106 = heff_field(v_x1_24105, 0);
        V v_ru_24x1_24105_24IsInferable = heff_take_reuse_n(v_x1_24105, 1ULL, 1);
        V v_t_24109;
        switch (heff_tag_of(v_i_24106)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_i_24106, 1));
          v_t_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_i_24106);
        }
        v_t_24115 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24105_24IsInferable, TAG_TInf, 1, (V[]){v_i_24106}), v_t_24109});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24110 = heff_field(v_x1_24105, 0);
        V v_ru_24x1_24105_24IsCheckable = heff_take_reuse_n(v_x1_24105, 1ULL, 1);
        V v_t_24113;
        switch (heff_tag_of(v_c_24110)) {
        case TAG_At: {
          V v_s_24112 = heff_dup(heff_field(v_c_24110, 1));
          v_t_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_c_24110);
        }
        v_t_24115 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24105_24IsCheckable, TAG_TChk, 1, (V[]){v_c_24110}), v_t_24113});
        break;
      }
      case TAG_IsType: {
        V v_t_24114 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24115 = v_t_24114;
        break;
      }
      default: heff_nomatch(v_x1_24105);
      }
      V v_t_24116 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24104, v_t_24115}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24116});
    }
    case TAG_ESpec: {
      V v_a_24117 = heff_field(v_x21_242, 0);
      V v_x_24118 = heff_field(v_x21_242, 1);
      V v_fsp_24119 = heff_field(v_x21_242, 2);
      V v_v_24120 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24ESpec = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_24121 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24117}));
      V v_t_24122 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24121));
      V v_x1_24123 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24120}));
      V v_t_24133;
      switch (heff_tag_of(v_x1_24123)) {
      case TAG_IsInferable: {
        V v_i_24124 = heff_field(v_x1_24123, 0);
        V v_ru_24x1_24123_24IsInferable = heff_take_reuse_n(v_x1_24123, 1ULL, 1);
        V v_t_24127;
        switch (heff_tag_of(v_i_24124)) {
        case TAG_At: {
          V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
          v_t_24127 = v_s_24126;
          break;
        }
        default: heff_nomatch(v_i_24124);
        }
        v_t_24133 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24123_24IsInferable, TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24128 = heff_field(v_x1_24123, 0);
        heff_take_n(v_x1_24123, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24133 = v_c_24128;
        break;
      }
      case TAG_IsType: {
        V v_t_24129 = heff_field(v_x1_24123, 0);
        V v_ru_24x1_24123_24IsType = heff_take_reuse_n(v_x1_24123, 1ULL, 1);
        V v_t_24132;
        switch (heff_tag_of(v_t_24129)) {
        case TAG_At: {
          V v_s_24131 = heff_dup(heff_field(v_t_24129, 1));
          v_t_24132 = v_s_24131;
          break;
        }
        default: heff_nomatch(v_t_24129);
        }
        v_t_24133 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24123_24IsType, TAG_CType, 1, (V[]){v_t_24129}), v_t_24132});
        break;
      }
      default: heff_nomatch(v_x1_24123);
      }
      V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESpec, TAG_ISpec, 4, (V[]){v_t_24122, v_x_24118, v_fsp_24119, v_t_24133}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24134});
    }
    case TAG_ESig: {
      V v_fs_24135 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24136 = (g_list_2emap_24s2016093283x1174801437(v_r_240, v_fs_24135));
      V v_t_24137 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_TSig, 1, (V[]){v_t_24136}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_24137});
    }
    case TAG_ESum: {
      V v_vs_24138 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24139 = (g_list_2emap_24s97919758x216970748(v_r_240, v_vs_24138));
      V v_t_24140 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_TSum, 1, (V[]){v_t_24139}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_24140});
    }
    case TAG_EStruct: {
      V v_fs_24141 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24142 = (g_list_2emap_24s2039279853x710813703(v_r_240, v_fs_24141));
      V v_t_24143 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CStruct, 1, (V[]){v_t_24142}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24143});
    }
    case TAG_EUpdate: {
      V v_a_24144 = heff_field(v_x21_242, 0);
      V v_fs_24145 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24146 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24144}));
      V v_t_24147 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24146));
      V v_t_24148 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24149 = (g_list_2emap(v_t_24148, v_fs_24145));
      V v_t_24150 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_IUpdate, 2, (V[]){v_t_24147, v_t_24149}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24150});
    }
    case TAG_EMatch: {
      V v_s_24151 = heff_field(v_x21_242, 0);
      V v_alts_24152 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24153 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24151}));
      V v_t_24154 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24153));
      V v_t_24155 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtOf_clo), 1, (V[]){v_r_240}));
      V v_t_24156 = (g_list_2emap(v_t_24155, v_alts_24152));
      V v_t_24157 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_CMatch, 2, (V[]){v_t_24154, v_t_24156}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24157});
    }
    case TAG_ELetIn: {
      V v_rhs_24158 = heff_field(v_x21_242, 0);
      V v_a_24159 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24160 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24158}));
      V v_t_24161 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24160));
      V v_t_24177;
      switch (heff_tag_of(v_a_24159)) {
      case TAG_At: {
        V v_x21_24162 = heff_field(v_a_24159, 0);
        V v_sp_24163 = heff_field(v_a_24159, 1);
        V v_ru_24a_24159_24At = heff_take_reuse_n(v_a_24159, 3ULL, 2);
        switch (heff_tag_of(v_x21_24162)) {
        case TAG_MkAlt: {
          V v_p_24164 = heff_field(v_x21_24162, 0);
          V v_b_24165 = heff_field(v_x21_24162, 1);
          heff_take_n(v_x21_24162, 3ULL, 2);
          V v_x1_24166 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_24165}));
          V v_t_24176;
          switch (heff_tag_of(v_x1_24166)) {
          case TAG_IsInferable: {
            V v_i_24167 = heff_field(v_x1_24166, 0);
            V v_ru_24x1_24166_24IsInferable = heff_take_reuse_n(v_x1_24166, 1ULL, 1);
            V v_t_24170;
            switch (heff_tag_of(v_i_24167)) {
            case TAG_At: {
              V v_s_24169 = heff_dup(heff_field(v_i_24167, 1));
              v_t_24170 = v_s_24169;
              break;
            }
            default: heff_nomatch(v_i_24167);
            }
            v_t_24176 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24166_24IsInferable, TAG_CInf, 1, (V[]){v_i_24167}), v_t_24170});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24171 = heff_field(v_x1_24166, 0);
            heff_take_n(v_x1_24166, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_24176 = v_c_24171;
            break;
          }
          case TAG_IsType: {
            V v_t_24172 = heff_field(v_x1_24166, 0);
            V v_ru_24x1_24166_24IsType = heff_take_reuse_n(v_x1_24166, 1ULL, 1);
            V v_t_24175;
            switch (heff_tag_of(v_t_24172)) {
            case TAG_At: {
              V v_s_24174 = heff_dup(heff_field(v_t_24172, 1));
              v_t_24175 = v_s_24174;
              break;
            }
            default: heff_nomatch(v_t_24172);
            }
            v_t_24176 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24166_24IsType, TAG_CType, 1, (V[]){v_t_24172}), v_t_24175});
            break;
          }
          default: heff_nomatch(v_x1_24166);
          }
          v_t_24177 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_24159_24At, TAG_MkAlt, 2, (V[]){v_p_24164, v_t_24176}), v_sp_24163});
          break;
        }
        default: heff_nomatch(v_x21_24162);
        }
        break;
      }
      default: heff_nomatch(v_a_24159);
      }
      V v_t_24178 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24161, v_t_24177}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24178});
    }
    case TAG_EDo: {
      V v_stmts_24179 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      HeffT2 v_t_24180 = (g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(heff_dup(v_sp_243), v_stmts_24179));
      {
        V v_field_24182 = v_t_24180.f[1];
        int64_t v_tag_24181 = ((int64_t)v_t_24180.f[0]);
        if ((v_tag_24181 == ((int64_t)0ULL))) {
          heff_drop(v_sp_243);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop_cell(v_ru_24x21_242_24EDo, 1);
          V v_e_27_24183 = v_field_24182;
          return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_27_24183});
        } else {
          heff_drop_rec(v_r_240, 2);
          heff_drop(v_field_24182);
          V v_t_24184 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2), NTAG(TAG_Nothing)});
          return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24184, v_sp_243})});
        }
      }
    }
    case TAG_ELocal: {
      V v_body_24185 = heff_field(v_x21_242, 0);
      V v_ds_24186 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_24187 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24185}));
      V v_t_24197;
      switch (heff_tag_of(v_x1_24187)) {
      case TAG_IsInferable: {
        V v_i_24188 = heff_field(v_x1_24187, 0);
        V v_ru_24x1_24187_24IsInferable = heff_take_reuse_n(v_x1_24187, 1ULL, 1);
        V v_t_24191;
        switch (heff_tag_of(v_i_24188)) {
        case TAG_At: {
          V v_s_24190 = heff_dup(heff_field(v_i_24188, 1));
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_i_24188);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24187_24IsInferable, TAG_CInf, 1, (V[]){v_i_24188}), v_t_24191});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24192 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24197 = v_c_24192;
        break;
      }
      case TAG_IsType: {
        V v_t_24193 = heff_field(v_x1_24187, 0);
        V v_ru_24x1_24187_24IsType = heff_take_reuse_n(v_x1_24187, 1ULL, 1);
        V v_t_24196;
        switch (heff_tag_of(v_t_24193)) {
        case TAG_At: {
          V v_s_24195 = heff_dup(heff_field(v_t_24193, 1));
          v_t_24196 = v_s_24195;
          break;
        }
        default: heff_nomatch(v_t_24193);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24187_24IsType, TAG_CType, 1, (V[]){v_t_24193}), v_t_24196});
        break;
      }
      default: heff_nomatch(v_x1_24187);
      }
      V v_t_24198 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24186));
      V v_t_24199 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24197, v_t_24198}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24199});
    }
    case TAG_EInvalid: {
      V v_why_24200 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24201 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24200, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24201, v_sp_243})});
    }
    case TAG_EAssign: {
      V v_x_24202 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EAssign = heff_take_reuse_n(v_x21_242, 1ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_24205 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3), v_x_24202), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4));
      V v_t_24206 = heff_tag_at_n(v_ru_24x21_242_24EAssign, TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_t_24205, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24206, v_sp_243})});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_24209 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str5), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24209, v_sp_243})});
    }
    case TAG_EFor: {
      V v_ru_24x21_242_24EFor = heff_take_reuse_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_r_240, 2);
      V v_t_24213 = heff_tag_at_n(v_ru_24x21_242_24EFor, TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str6), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24213, v_sp_243})});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_24216 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str7), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24216, v_sp_243})});
    }
    case TAG_EBreak: {
      heff_drop_rec(v_r_240, 2);
      V v_t_24217 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str8), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24217, v_sp_243})});
    }
    case TAG_EContinue: {
      heff_drop_rec(v_r_240, 2);
      V v_t_24218 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str9), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24218, v_sp_243})});
    }
    case TAG_EReturn: {
      V v_ru_24x21_242_24EReturn = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24220 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str10), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EReturn, TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24220, v_sp_243})});
    }
    case TAG_ENest: {
      V v_ru_24x21_242_24ENest = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24222 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str11), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24ENest, TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24222, v_sp_243})});
    }
    case TAG_ELazy: {
      V v_e_24223 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ELazy = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_24224 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24223}));
      V v_t_24234;
      switch (heff_tag_of(v_x1_24224)) {
      case TAG_IsInferable: {
        V v_i_24225 = heff_field(v_x1_24224, 0);
        heff_take_n(v_x1_24224, 1ULL, 1);
        V v_t_24228;
        switch (heff_tag_of(v_i_24225)) {
        case TAG_At: {
          V v_s_24227 = heff_dup(heff_field(v_i_24225, 1));
          v_t_24228 = v_s_24227;
          break;
        }
        default: heff_nomatch(v_i_24225);
        }
        v_t_24234 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CInf, 1, (V[]){v_i_24225}), v_t_24228});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24229 = heff_field(v_x1_24224, 0);
        heff_take_n(v_x1_24224, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        heff_drop_cell(v_ru_24x21_242_24ELazy, 1);
        v_t_24234 = v_c_24229;
        break;
      }
      case TAG_IsType: {
        V v_t_24230 = heff_field(v_x1_24224, 0);
        heff_take_n(v_x1_24224, 1ULL, 1);
        V v_t_24233;
        switch (heff_tag_of(v_t_24230)) {
        case TAG_At: {
          V v_s_24232 = heff_dup(heff_field(v_t_24230, 1));
          v_t_24233 = v_s_24232;
          break;
        }
        default: heff_nomatch(v_t_24230);
        }
        v_t_24234 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ELazy, TAG_CType, 1, (V[]){v_t_24230}), v_t_24233});
        break;
      }
      default: heff_nomatch(v_x1_24224);
      }
      V v_t_24235 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ILazy, 1, (V[]){v_t_24234}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24235});
    }
    case TAG_ETuple: {
      V v_es_24236 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETuple = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24248 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0, 1, 1, (V[]){v_r_240}), v_es_24236));
      V v_t_24249 = heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x21_242_24ETuple, TAG_ITuple, 1, (V[]){v_t_24248}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24249});
    }
    case TAG_ETry: {
      V v_ru_24x21_242_24ETry = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24251 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str12), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24ETry, TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24251, v_sp_243})});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_r_240, 2);
      V v_t_24256 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str13), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){v_t_24256, v_sp_243})});
    }
    case TAG_EWithBound: {
      V v_bs_24257 = heff_field(v_x21_242, 0);
      V v_w_24258 = heff_field(v_x21_242, 1);
      V v_body_24259 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_24260 = ({ V a_0 = v_sp_243; V a_1 = v_bs_24257; V a_2 = v_w_24258; V a_3 = v_body_24259; V r_ = (g_heff_2esyntax_2epresyntax_2ewithBoundOf(a_0, a_1, a_2, a_3)); heff_drop(v_w_24258); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24260});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_lam0(V self, V *args) {
  V v_e_24237 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24237}));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_IsInferable: {
    V v_i_24239 = heff_field(v_x1_24238, 0);
    V v_ru_24x1_24238_24IsInferable = heff_take_reuse_n(v_x1_24238, 1ULL, 1);
    V v_t_24242;
    switch (heff_tag_of(v_i_24239)) {
    case TAG_At: {
      V v_s_24241 = heff_dup(heff_field(v_i_24239, 1));
      v_t_24242 = v_s_24241;
      break;
    }
    default: heff_nomatch(v_i_24239);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24238_24IsInferable, TAG_CInf, 1, (V[]){v_i_24239}), v_t_24242});
  }
  case TAG_IsCheckable: {
    V v_c_24243 = heff_field(v_x1_24238, 0);
    heff_take_n(v_x1_24238, 1ULL, 1);
    return v_c_24243;
  }
  case TAG_IsType: {
    V v_t_24244 = heff_field(v_x1_24238, 0);
    V v_ru_24x1_24238_24IsType = heff_take_reuse_n(v_x1_24238, 1ULL, 1);
    V v_t_24247;
    switch (heff_tag_of(v_t_24244)) {
    case TAG_At: {
      V v_s_24246 = heff_dup(heff_field(v_t_24244, 1));
      v_t_24247 = v_s_24246;
      break;
    }
    default: heff_nomatch(v_t_24244);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24238_24IsType, TAG_CType, 1, (V[]){v_t_24244}), v_t_24247});
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xsp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    HeffT3 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_243));
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_2417;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_c_248 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
        V v_t_2411;
        switch (heff_tag_of(v_c_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_c_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_c_248);
        }
        v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_248}), v_t_2411});
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          V v_i_2412 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
          V v_t_2415;
          switch (heff_tag_of(v_i_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_i_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_i_2412);
          }
          v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2412}), v_t_2415});
        } else {
          V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247});
          v_t_2417 = v_t_2416;
        }
      }
      return heff_tag_re_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, 3ULL, (V[]){v_x_241, v_xsp_242, v_t_2417});
    }
  }
  case TAG_PiImplicit: {
    V v_x_2418 = heff_field(v_x2_240, 0);
    V v_xsp_2419 = heff_field(v_x2_240, 1);
    V v_bsp_2420 = heff_field(v_x2_240, 2);
    V v_t_2421 = heff_field(v_x2_240, 3);
    V v_d_2422 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    HeffT3 v_t_2423 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2421));
    {
      V v_field_2425 = v_t_2423.f[1];
      V v_field_2426 = v_t_2423.f[2];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      V v_t_2436;
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_c_2427 = heff_tag_n(TAG_At, 2, (V[]){v_field_2425, v_field_2426});
        V v_t_2430;
        switch (heff_tag_of(v_c_2427)) {
        case TAG_At: {
          V v_s_2429 = heff_dup(heff_field(v_c_2427, 1));
          v_t_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_c_2427);
        }
        v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2427}), v_t_2430});
      } else {
        if ((v_tag_2424 == ((int64_t)1ULL))) {
          V v_i_2431 = heff_tag_n(TAG_At, 2, (V[]){v_field_2425, v_field_2426});
          V v_t_2434;
          switch (heff_tag_of(v_i_2431)) {
          case TAG_At: {
            V v_s_2433 = heff_dup(heff_field(v_i_2431, 1));
            v_t_2434 = v_s_2433;
            break;
          }
          default: heff_nomatch(v_i_2431);
          }
          v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2431}), v_t_2434});
        } else {
          V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){v_field_2425, v_field_2426});
          v_t_2436 = v_t_2435;
        }
      }
      V v_t_2452;
      switch (heff_tag_of(v_d_2422)) {
      case TAG_Nothing: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2437 = heff_field(v_d_2422, 0);
        V v_ru_24d_2422_24Just = heff_take_reuse_n(v_d_2422, 1ULL, 1);
        HeffT3 v_t_2438 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2437));
        {
          V v_field_2440 = v_t_2438.f[1];
          V v_field_2441 = v_t_2438.f[2];
          int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
          V v_t_2451;
          if ((v_tag_2439 == ((int64_t)0ULL))) {
            V v_c_2442 = heff_tag_n(TAG_At, 2, (V[]){v_field_2440, v_field_2441});
            v_t_2451 = v_c_2442;
          } else {
            if ((v_tag_2439 == ((int64_t)1ULL))) {
              V v_i_2443 = heff_tag_n(TAG_At, 2, (V[]){v_field_2440, v_field_2441});
              V v_t_2446;
              switch (heff_tag_of(v_i_2443)) {
              case TAG_At: {
                V v_s_2445 = heff_dup(heff_field(v_i_2443, 1));
                v_t_2446 = v_s_2445;
                break;
              }
              default: heff_nomatch(v_i_2443);
              }
              v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2443}), v_t_2446});
            } else {
              V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){v_field_2440, v_field_2441});
              V v_t_2450;
              switch (heff_tag_of(v_t_2447)) {
              case TAG_At: {
                V v_s_2449 = heff_dup(heff_field(v_t_2447, 1));
                v_t_2450 = v_s_2449;
                break;
              }
              default: heff_nomatch(v_t_2447);
              }
              v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2447}), v_t_2450});
            }
          }
          v_t_2452 = heff_tag_at_n(v_ru_24d_2422_24Just, TAG_Just, 1, (V[]){v_t_2451});
        }
        break;
      }
      default: heff_nomatch(v_d_2422);
      }
      return heff_tag_re_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, 7ULL, (V[]){v_x_2418, v_xsp_2419, v_bsp_2420, v_t_2436, v_t_2452});
    }
  }
  case TAG_PiInstance: {
    V v_x_2453 = heff_field(v_x2_240, 0);
    V v_xsp_2454 = heff_field(v_x2_240, 1);
    V v_bsp_2455 = heff_field(v_x2_240, 2);
    V v_t_2456 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    HeffT3 v_t_2457 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2456));
    {
      V v_field_2459 = v_t_2457.f[1];
      V v_field_2460 = v_t_2457.f[2];
      int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
      V v_t_2470;
      if ((v_tag_2458 == ((int64_t)0ULL))) {
        V v_c_2461 = heff_tag_n(TAG_At, 2, (V[]){v_field_2459, v_field_2460});
        V v_t_2464;
        switch (heff_tag_of(v_c_2461)) {
        case TAG_At: {
          V v_s_2463 = heff_dup(heff_field(v_c_2461, 1));
          v_t_2464 = v_s_2463;
          break;
        }
        default: heff_nomatch(v_c_2461);
        }
        v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2461}), v_t_2464});
      } else {
        if ((v_tag_2458 == ((int64_t)1ULL))) {
          V v_i_2465 = heff_tag_n(TAG_At, 2, (V[]){v_field_2459, v_field_2460});
          V v_t_2468;
          switch (heff_tag_of(v_i_2465)) {
          case TAG_At: {
            V v_s_2467 = heff_dup(heff_field(v_i_2465, 1));
            v_t_2468 = v_s_2467;
            break;
          }
          default: heff_nomatch(v_i_2465);
          }
          v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2465}), v_t_2468});
        } else {
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){v_field_2459, v_field_2460});
          v_t_2470 = v_t_2469;
        }
      }
      return heff_tag_re_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, 7ULL, (V[]){v_x_2453, v_xsp_2454, v_bsp_2455, v_t_2470});
    }
  }
  case TAG_PiAnon: {
    V v_t_2471 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    HeffT3 v_t_2472 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2471));
    {
      V v_field_2474 = v_t_2472.f[1];
      V v_field_2475 = v_t_2472.f[2];
      int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
      V v_t_2485;
      if ((v_tag_2473 == ((int64_t)0ULL))) {
        V v_c_2476 = heff_tag_n(TAG_At, 2, (V[]){v_field_2474, v_field_2475});
        V v_t_2479;
        switch (heff_tag_of(v_c_2476)) {
        case TAG_At: {
          V v_s_2478 = heff_dup(heff_field(v_c_2476, 1));
          v_t_2479 = v_s_2478;
          break;
        }
        default: heff_nomatch(v_c_2476);
        }
        v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2476}), v_t_2479});
      } else {
        if ((v_tag_2473 == ((int64_t)1ULL))) {
          V v_i_2480 = heff_tag_n(TAG_At, 2, (V[]){v_field_2474, v_field_2475});
          V v_t_2483;
          switch (heff_tag_of(v_i_2480)) {
          case TAG_At: {
            V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
            v_t_2483 = v_s_2482;
            break;
          }
          default: heff_nomatch(v_i_2480);
          }
          v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2480}), v_t_2483});
        } else {
          V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){v_field_2474, v_field_2475});
          v_t_2485 = v_t_2484;
        }
      }
      return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2485});
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1, 11, "bytesConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str4, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str6, 67, " := e` sets a `let mut` variable: it is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str7, 45, "a `while` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str8, 43, "a `for` loop is a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str9, 78, "an `if` without `else` is a statement of a `do` block: a value's has an `else`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str10, 78, "`break` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str11, 81, "`continue` is a statement of a loop's body: `while c do ...`, `for x in e do ...`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str12, 103, "`return e` ends a `do` block as one of its statements (or an arm of its `if` or `case`), not as a value");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str13, 67, "`(<- c)`, the value of an action, is in a statement of a `do` block");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str14, 72, "a `try` is a statement of a `do` block (or an arm of its `if` or `case`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str15, 73, "a `with` is a statement of a `do` block (or an arm of its `if` or `case`)");

HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EVar = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24EVar, TAG_IVar, 1, (V[]){v_x_243}), v_sp_242}});
    }
    case TAG_EImplicitVar: {
      V v_x_244 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EImplicitVar = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24EImplicitVar, TAG_IVar, 1, (V[]){v_x_244}), v_sp_242}});
    }
    case TAG_ENotationVar: {
      V v_x_245 = heff_field(v_x21_241, 0);
      V v_ksp_246 = heff_field(v_x21_241, 1);
      V v_said_247 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ENotationVar = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24ENotationVar, TAG_INotationVar, 3, (V[]){v_x_245, v_ksp_246, v_said_247}), v_sp_242}});
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_249 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_248, heff_dup(v_sp_242), NTAG(TAG_Nil)});
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_249, v_sp_242}});
    }
    case TAG_EInt: {
      V v_i_2410 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EInt = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24EInt, TAG_IInt, 1, (V[]){v_i_2410}), v_sp_242}});
    }
    case TAG_EFloat: {
      V v_x_2411 = heff_tget_v(v_x21_241, 0);
      V v_ru_24x21_241_24EFloat = heff_take_reuse_nf(v_x21_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24EFloat, TAG_IFloat, 1, (V[]){v_x_2411}), v_sp_242}});
    }
    case TAG_EString: {
      V v_x_2412 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EString = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24EString, TAG_IString, 1, (V[]){v_x_2412}), v_sp_242}});
    }
    case TAG_EBinary: {
      V v_segs_2413 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EBinary = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_asBits_2414 = NTAG(TAG_False);
      V v_segs_2415 = v_segs_2413;
      V v_sp_2416 = v_sp_242;
      if ((heff_dup(v_asBits_2414) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
        return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(v_segs_2415, v_sp_2416, NTAG(TAG_False)));
      } else {
        V v_t_2417 = (g_list_2eany_24s689038521x519269801(v_segs_2415));
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
          heff_drop(v_t_2417);
          return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(v_segs_2415, v_sp_2416, NTAG(TAG_False)));
        } else {
          heff_drop(v_t_2417);
          V v_t_2418 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_2415)));
          HeffT2 v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_n_2422 = v_field_2421;
              if (!heff_intEq_c_lent(v_n_2422, MK_INT(0LL), 2)) {
                heff_drop_cell(v_ru_24x2_240_24At, 2);
                heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
                heff_drop(v_n_2422);
                return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(v_segs_2415, v_sp_2416, NTAG(TAG_False)));
              } else {
                heff_drop(v_n_2422);
                V v_x1_2423 = (g_list_2eany_24s689038521x519269801(v_segs_2415));
                if (!(heff_dup(v_x1_2423) == NTAG(TAG_True))) {
                  heff_drop(v_x1_2423);
                  V v_t_2424 = (g_list_2eall_24s1414119352x995333365(MK_INT(0LL), v_segs_2415));
                  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
                    heff_drop(v_t_2424);
                    V v_segs_2425 = heff_dup(v_segs_2415);
                    V v_sp_2426 = v_sp_2416;
                    HeffT2 v_t_2427 = ({ V a_0 = v_segs_2415; V a_1 = ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(a_0, a_1)); heff_drop(v_segs_2415); r_; });
                    {
                      V v_field_2429 = v_t_2427.f[1];
                      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
                      if ((v_tag_2428 == ((int64_t)0ULL))) {
                        heff_drop_cell(v_ru_24x2_240_24At, 2);
                        heff_drop(v_segs_2425);
                        V v_s_2430 = v_field_2429;
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24EBinary, TAG_IBytes, 1, (V[]){v_s_2430}), v_sp_2426}});
                      } else {
                        heff_drop(v_field_2429);
                        V v_xs_2431 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(v_segs_2425, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
                        V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
                        V v_t_2433 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2432, v_sp_2426));
                        V v_args_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
                        V v_t_2435 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2426), v_args_2434));
                        V v_t_2436 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24EBinary, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1)}), heff_dup(v_sp_2426)});
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_IApp, 2, (V[]){v_t_2436, v_t_2435}), v_sp_2426}});
                      }
                    }
                  } else {
                    heff_drop_cell(v_ru_24x2_240_24At, 2);
                    heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
                    heff_drop(v_t_2424);
                    return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(v_segs_2415, v_sp_2416, NTAG(TAG_True)));
                  }
                } else {
                  heff_drop_cell(v_ru_24x2_240_24At, 2);
                  heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
                  heff_drop(v_x1_2423);
                  return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(v_segs_2415, v_sp_2416, NTAG(TAG_True)));
                }
              }
            } else {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              heff_drop_cell(v_ru_24x21_241_24EBinary, 1);
              heff_drop(v_field_2421);
              return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(v_segs_2415, v_sp_2416, NTAG(TAG_False)));
            }
          }
        }
      }
    }
    case TAG_ERune: {
      V v_c_2437 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ERune = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24ERune, TAG_IRune, 1, (V[]){v_c_2437}), v_sp_242}});
    }
    case TAG_EWord: {
      V v_w_2438 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_w_2438, v_sp_242));
    }
    case TAG_EApp: {
      V v_h_2439 = heff_field(v_x21_241, 0);
      V v_args_2440 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2441 = (g_heff_2esyntax_2epresyntax_2erunArgs(heff_dup(v_h_2439), v_args_2440));
      return (g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(v_h_2439, v_t_2441, v_sp_242));
    }
    case TAG_EProject: {
      heff_take_n(v_x21_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2443 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2443, v_sp_242}});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2446 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2446, v_sp_242}});
    }
    case TAG_EPi: {
      V v_b_2447 = heff_field(v_x21_241, 0);
      V v_cod_2448 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_2449 = (g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(v_b_2447));
      HeffT3 v_t_2450 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_cod_2448));
      {
        V v_field_2452 = v_t_2450.f[1];
        V v_field_2453 = v_t_2450.f[2];
        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
        V v_t_2463;
        if ((v_tag_2451 == ((int64_t)0ULL))) {
          V v_c_2454 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2452, v_field_2453});
          V v_t_2457;
          switch (heff_tag_of(v_c_2454)) {
          case TAG_At: {
            V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
            v_t_2457 = v_s_2456;
            break;
          }
          default: heff_nomatch(v_c_2454);
          }
          v_t_2463 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
        } else {
          if ((v_tag_2451 == ((int64_t)1ULL))) {
            V v_i_2458 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2452, v_field_2453});
            V v_t_2461;
            switch (heff_tag_of(v_i_2458)) {
            case TAG_At: {
              V v_s_2460 = heff_dup(heff_field(v_i_2458, 1));
              v_t_2461 = v_s_2460;
              break;
            }
            default: heff_nomatch(v_i_2458);
            }
            v_t_2463 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2458}), v_t_2461});
          } else {
            heff_drop_cell(v_ru_24x21_241_24EPi, 2);
            V v_t_2462 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2452, v_field_2453});
            v_t_2463 = v_t_2462;
          }
        }
        return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_TPi, 2, (V[]){v_t_2449, v_t_2463}), v_sp_242}});
      }
    }
    case TAG_ELam: {
      V v_x211_2464 = heff_field(v_x21_241, 0);
      V v_body_2465 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      switch (heff_tag_of(v_x211_2464)) {
      case TAG_LamName: {
        V v_x_2466 = heff_field(v_x211_2464, 0);
        V v_xsp_2467 = heff_field(v_x211_2464, 1);
        heff_take_n(v_x211_2464, 3ULL, 2);
        HeffT3 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2465));
        {
          V v_field_2470 = v_t_2468.f[1];
          V v_field_2471 = v_t_2468.f[2];
          int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
          V v_t_2481;
          if ((v_tag_2469 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x21_241_24ELam, 2);
            V v_c_2472 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2470, v_field_2471});
            v_t_2481 = v_c_2472;
          } else {
            if ((v_tag_2469 == ((int64_t)1ULL))) {
              V v_i_2473 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2470, v_field_2471});
              V v_t_2476;
              switch (heff_tag_of(v_i_2473)) {
              case TAG_At: {
                V v_s_2475 = heff_dup(heff_field(v_i_2473, 1));
                v_t_2476 = v_s_2475;
                break;
              }
              default: heff_nomatch(v_i_2473);
              }
              v_t_2481 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2473}), v_t_2476});
            } else {
              V v_t_2477 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2470, v_field_2471});
              V v_t_2480;
              switch (heff_tag_of(v_t_2477)) {
              case TAG_At: {
                V v_s_2479 = heff_dup(heff_field(v_t_2477, 1));
                v_t_2480 = v_s_2479;
                break;
              }
              default: heff_nomatch(v_t_2477);
              }
              v_t_2481 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2477}), v_t_2480});
            }
          }
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_CLam, 3, (V[]){v_x_2466, v_xsp_2467, v_t_2481}), v_sp_242}});
        }
      }
      case TAG_LamImplicit: {
        V v_x_2482 = heff_field(v_x211_2464, 0);
        V v_xsp_2483 = heff_field(v_x211_2464, 1);
        heff_take_n(v_x211_2464, 3ULL, 2);
        HeffT3 v_t_2484 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2465));
        {
          V v_field_2486 = v_t_2484.f[1];
          V v_field_2487 = v_t_2484.f[2];
          int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
          V v_t_2497;
          if ((v_tag_2485 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x21_241_24ELam, 2);
            V v_c_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2486, v_field_2487});
            v_t_2497 = v_c_2488;
          } else {
            if ((v_tag_2485 == ((int64_t)1ULL))) {
              V v_i_2489 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2486, v_field_2487});
              V v_t_2492;
              switch (heff_tag_of(v_i_2489)) {
              case TAG_At: {
                V v_s_2491 = heff_dup(heff_field(v_i_2489, 1));
                v_t_2492 = v_s_2491;
                break;
              }
              default: heff_nomatch(v_i_2489);
              }
              v_t_2497 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2489}), v_t_2492});
            } else {
              V v_t_2493 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2486, v_field_2487});
              V v_t_2496;
              switch (heff_tag_of(v_t_2493)) {
              case TAG_At: {
                V v_s_2495 = heff_dup(heff_field(v_t_2493, 1));
                v_t_2496 = v_s_2495;
                break;
              }
              default: heff_nomatch(v_t_2493);
              }
              v_t_2497 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2493}), v_t_2496});
            }
          }
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2482, v_xsp_2483, v_t_2497}), v_sp_242}});
        }
      }
      case TAG_LamAnn: {
        V v_x_2498 = heff_field(v_x211_2464, 0);
        V v_xsp_2499 = heff_field(v_x211_2464, 1);
        V v_t_24100 = heff_field(v_x211_2464, 2);
        heff_take_n(v_x211_2464, 7ULL, 3);
        HeffT3 v_t_24101 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_24100));
        {
          V v_field_24103 = v_t_24101.f[1];
          V v_field_24104 = v_t_24101.f[2];
          int64_t v_tag_24102 = ((int64_t)v_t_24101.f[0]);
          V v_t_24114;
          if ((v_tag_24102 == ((int64_t)0ULL))) {
            V v_c_24105 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24103, v_field_24104});
            V v_t_24108;
            switch (heff_tag_of(v_c_24105)) {
            case TAG_At: {
              V v_s_24107 = heff_dup(heff_field(v_c_24105, 1));
              v_t_24108 = v_s_24107;
              break;
            }
            default: heff_nomatch(v_c_24105);
            }
            v_t_24114 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24105}), v_t_24108});
          } else {
            if ((v_tag_24102 == ((int64_t)1ULL))) {
              V v_i_24109 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24103, v_field_24104});
              V v_t_24112;
              switch (heff_tag_of(v_i_24109)) {
              case TAG_At: {
                V v_s_24111 = heff_dup(heff_field(v_i_24109, 1));
                v_t_24112 = v_s_24111;
                break;
              }
              default: heff_nomatch(v_i_24109);
              }
              v_t_24114 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24109}), v_t_24112});
            } else {
              heff_drop_cell(v_ru_24x21_241_24ELam, 2);
              V v_t_24113 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24103, v_field_24104});
              v_t_24114 = v_t_24113;
            }
          }
          V v_t_24115 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2465));
          return (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_2498, v_xsp_2499, v_t_24114, v_t_24115, v_sp_242));
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x211_2464)}});
      }
    }
    case TAG_EAnn: {
      V v_a_24116 = heff_field(v_x21_241, 0);
      V v_t_24117 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT3 v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_24116));
      {
        V v_field_24120 = v_t_24118.f[1];
        V v_field_24121 = v_t_24118.f[2];
        int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
        V v_t_24131;
        if ((v_tag_24119 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
          V v_c_24122 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24120, v_field_24121});
          v_t_24131 = v_c_24122;
        } else {
          if ((v_tag_24119 == ((int64_t)1ULL))) {
            V v_i_24123 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24120, v_field_24121});
            V v_t_24126;
            switch (heff_tag_of(v_i_24123)) {
            case TAG_At: {
              V v_s_24125 = heff_dup(heff_field(v_i_24123, 1));
              v_t_24126 = v_s_24125;
              break;
            }
            default: heff_nomatch(v_i_24123);
            }
            v_t_24131 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24123}), v_t_24126});
          } else {
            V v_t_24127 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24120, v_field_24121});
            V v_t_24130;
            switch (heff_tag_of(v_t_24127)) {
            case TAG_At: {
              V v_s_24129 = heff_dup(heff_field(v_t_24127, 1));
              v_t_24130 = v_s_24129;
              break;
            }
            default: heff_nomatch(v_t_24127);
            }
            v_t_24131 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24127}), v_t_24130});
          }
        }
        HeffT3 v_t_24132 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_24117));
        {
          V v_field_24134 = v_t_24132.f[1];
          V v_field_24135 = v_t_24132.f[2];
          int64_t v_tag_24133 = ((int64_t)v_t_24132.f[0]);
          V v_t_24145;
          if ((v_tag_24133 == ((int64_t)0ULL))) {
            V v_c_24136 = heff_tag_n(TAG_At, 2, (V[]){v_field_24134, v_field_24135});
            V v_t_24139;
            switch (heff_tag_of(v_c_24136)) {
            case TAG_At: {
              V v_s_24138 = heff_dup(heff_field(v_c_24136, 1));
              v_t_24139 = v_s_24138;
              break;
            }
            default: heff_nomatch(v_c_24136);
            }
            v_t_24145 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24136}), v_t_24139});
          } else {
            if ((v_tag_24133 == ((int64_t)1ULL))) {
              V v_i_24140 = heff_tag_n(TAG_At, 2, (V[]){v_field_24134, v_field_24135});
              V v_t_24143;
              switch (heff_tag_of(v_i_24140)) {
              case TAG_At: {
                V v_s_24142 = heff_dup(heff_field(v_i_24140, 1));
                v_t_24143 = v_s_24142;
                break;
              }
              default: heff_nomatch(v_i_24140);
              }
              v_t_24145 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24140}), v_t_24143});
            } else {
              V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){v_field_24134, v_field_24135});
              v_t_24145 = v_t_24144;
            }
          }
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24131, v_t_24145}), v_sp_242}});
        }
      }
    }
    case TAG_ESpec: {
      V v_a_24146 = heff_field(v_x21_241, 0);
      V v_x_24147 = heff_field(v_x21_241, 1);
      V v_fsp_24148 = heff_field(v_x21_241, 2);
      V v_v_24149 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24ESpec = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_24150 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24146));
      V v_t_24151 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24150));
      HeffT3 v_t_24152 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_24149));
      {
        V v_field_24154 = v_t_24152.f[1];
        V v_field_24155 = v_t_24152.f[2];
        int64_t v_tag_24153 = ((int64_t)v_t_24152.f[0]);
        V v_t_24165;
        if ((v_tag_24153 == ((int64_t)0ULL))) {
          V v_c_24156 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24154, v_field_24155});
          v_t_24165 = v_c_24156;
        } else {
          if ((v_tag_24153 == ((int64_t)1ULL))) {
            V v_i_24157 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24154, v_field_24155});
            V v_t_24160;
            switch (heff_tag_of(v_i_24157)) {
            case TAG_At: {
              V v_s_24159 = heff_dup(heff_field(v_i_24157, 1));
              v_t_24160 = v_s_24159;
              break;
            }
            default: heff_nomatch(v_i_24157);
            }
            v_t_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24157}), v_t_24160});
          } else {
            V v_t_24161 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24154, v_field_24155});
            V v_t_24164;
            switch (heff_tag_of(v_t_24161)) {
            case TAG_At: {
              V v_s_24163 = heff_dup(heff_field(v_t_24161, 1));
              v_t_24164 = v_s_24163;
              break;
            }
            default: heff_nomatch(v_t_24161);
            }
            v_t_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24161}), v_t_24164});
          }
        }
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24ESpec, TAG_ISpec, 4, (V[]){v_t_24151, v_x_24147, v_fsp_24148, v_t_24165}), v_sp_242}});
      }
    }
    case TAG_ESig: {
      V v_fs_24166 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ESig = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24167 = (g_list_2emap_24s205414595x1692305030(v_fs_24166));
      return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x21_241_24ESig, TAG_TSig, 1, (V[]){v_t_24167}), v_sp_242}});
    }
    case TAG_ESum: {
      V v_vs_24168 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ESum = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24169 = (g_list_2emap_24s1258450377x973220636(v_vs_24168));
      return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x21_241_24ESum, TAG_TSum, 1, (V[]){v_t_24169}), v_sp_242}});
    }
    case TAG_EStruct: {
      V v_fs_24170 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EStruct = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24171 = (g_list_2emap_24s961097229x1129443801(v_fs_24170));
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x21_241_24EStruct, TAG_CStruct, 1, (V[]){v_t_24171}), v_sp_242}});
    }
    case TAG_EUpdate: {
      V v_a_24172 = heff_field(v_x21_241, 0);
      V v_fs_24173 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EUpdate = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24174 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24172));
      V v_t_24175 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24174));
      V v_t_24176 = (g_list_2emap_24s137457135x961689574(v_fs_24173));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24EUpdate, TAG_IUpdate, 2, (V[]){v_t_24175, v_t_24176}), v_sp_242}});
    }
    case TAG_EMatch: {
      V v_s_24177 = heff_field(v_x21_241, 0);
      V v_alts_24178 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EMatch = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24179 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_s_24177));
      V v_t_24180 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24179));
      V v_t_24181 = (g_list_2emap_24s1230969749x2018313496(v_alts_24178));
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x21_241_24EMatch, TAG_CMatch, 2, (V[]){v_t_24180, v_t_24181}), v_sp_242}});
    }
    case TAG_ELetIn: {
      V v_rhs_24182 = heff_field(v_x21_241, 0);
      V v_a_24183 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24184 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_24182));
      V v_t_24185 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24184));
      V v_t_24204;
      switch (heff_tag_of(v_a_24183)) {
      case TAG_At: {
        V v_x21_24186 = heff_field(v_a_24183, 0);
        V v_sp_24187 = heff_field(v_a_24183, 1);
        V v_ru_24a_24183_24At = heff_take_reuse_n(v_a_24183, 3ULL, 2);
        switch (heff_tag_of(v_x21_24186)) {
        case TAG_MkAlt: {
          V v_p_24188 = heff_field(v_x21_24186, 0);
          V v_b_24189 = heff_field(v_x21_24186, 1);
          V v_ru_24x21_24186_24MkAlt = heff_take_reuse_n(v_x21_24186, 3ULL, 2);
          HeffT3 v_t_24190 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_24189));
          {
            V v_field_24192 = v_t_24190.f[1];
            V v_field_24193 = v_t_24190.f[2];
            int64_t v_tag_24191 = ((int64_t)v_t_24190.f[0]);
            V v_t_24203;
            if ((v_tag_24191 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x21_241_24ELetIn, 2);
              V v_c_24194 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24192, v_field_24193});
              v_t_24203 = v_c_24194;
            } else {
              if ((v_tag_24191 == ((int64_t)1ULL))) {
                V v_i_24195 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24192, v_field_24193});
                V v_t_24198;
                switch (heff_tag_of(v_i_24195)) {
                case TAG_At: {
                  V v_s_24197 = heff_dup(heff_field(v_i_24195, 1));
                  v_t_24198 = v_s_24197;
                  break;
                }
                default: heff_nomatch(v_i_24195);
                }
                v_t_24203 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24195}), v_t_24198});
              } else {
                V v_t_24199 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24192, v_field_24193});
                V v_t_24202;
                switch (heff_tag_of(v_t_24199)) {
                case TAG_At: {
                  V v_s_24201 = heff_dup(heff_field(v_t_24199, 1));
                  v_t_24202 = v_s_24201;
                  break;
                }
                default: heff_nomatch(v_t_24199);
                }
                v_t_24203 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24199}), v_t_24202});
              }
            }
            v_t_24204 = heff_tag_re_n(v_ru_24a_24183_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_24186_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_24188, v_t_24203}), v_sp_24187});
          }
          break;
        }
        default: heff_nomatch(v_x21_24186);
        }
        break;
      }
      default: heff_nomatch(v_a_24183);
      }
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24185, v_t_24204}), v_sp_242}});
    }
    case TAG_EDo: {
      V v_stmts_24205 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      HeffT2 v_t_24206 = (g_heff_2esyntax_2epresyntax_2edoBlock_24s1455639597x676970604_24cpr(heff_dup(v_sp_242), v_stmts_24205));
      {
        V v_field_24208 = v_t_24206.f[1];
        int64_t v_tag_24207 = ((int64_t)v_t_24206.f[0]);
        if ((v_tag_24207 == ((int64_t)0ULL))) {
          heff_drop(v_sp_242);
          V v_e_27_24209 = v_field_24208;
          V t_0 = v_e_27_24209;
          v_x2_240 = t_0;
          goto top;
        } else {
          heff_drop(v_field_24208);
          V v_t_24210 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str4), NTAG(TAG_Nothing)});
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24210, v_sp_242}});
        }
      }
    }
    case TAG_ELocal: {
      V v_body_24211 = heff_field(v_x21_241, 0);
      V v_ds_24212 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT3 v_t_24213 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_24211));
      {
        V v_field_24215 = v_t_24213.f[1];
        V v_field_24216 = v_t_24213.f[2];
        int64_t v_tag_24214 = ((int64_t)v_t_24213.f[0]);
        V v_t_24226;
        if ((v_tag_24214 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELocal, 2);
          V v_c_24217 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24215, v_field_24216});
          v_t_24226 = v_c_24217;
        } else {
          if ((v_tag_24214 == ((int64_t)1ULL))) {
            V v_i_24218 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24215, v_field_24216});
            V v_t_24221;
            switch (heff_tag_of(v_i_24218)) {
            case TAG_At: {
              V v_s_24220 = heff_dup(heff_field(v_i_24218, 1));
              v_t_24221 = v_s_24220;
              break;
            }
            default: heff_nomatch(v_i_24218);
            }
            v_t_24226 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24218}), v_t_24221});
          } else {
            V v_t_24222 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24215, v_field_24216});
            V v_t_24225;
            switch (heff_tag_of(v_t_24222)) {
            case TAG_At: {
              V v_s_24224 = heff_dup(heff_field(v_t_24222, 1));
              v_t_24225 = v_s_24224;
              break;
            }
            default: heff_nomatch(v_t_24222);
            }
            v_t_24226 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24222}), v_t_24225});
          }
        }
        V v_t_24227 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2epresyntax_2eclassifier_get(), 1)), v_ds_24212));
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24226, v_t_24227}), v_sp_242}});
      }
    }
    case TAG_EInvalid: {
      V v_why_24228 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24229 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24228, NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24229, v_sp_242}});
    }
    case TAG_EAssign: {
      V v_x_24230 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EAssign = heff_take_reuse_n(v_x21_241, 1ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24233 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str5), v_x_24230), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str6));
      V v_f_24234 = heff_tag_at_n(v_ru_24x21_241_24EAssign, TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_t_24233, NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_24234, v_sp_242}});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24237 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str7), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24237, v_sp_242}});
    }
    case TAG_EFor: {
      V v_ru_24x21_241_24EFor = heff_take_reuse_n(v_x21_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24241 = heff_tag_at_n(v_ru_24x21_241_24EFor, TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str8), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24241, v_sp_242}});
    }
    case TAG_EIfThen: {
      heff_take_n(v_x21_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24244 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str9), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24244, v_sp_242}});
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24245 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str10), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24245, v_sp_242}});
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str11), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24246, v_sp_242}});
    }
    case TAG_EReturn: {
      heff_take_n(v_x21_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24248 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str12), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24248, v_sp_242}});
    }
    case TAG_ENest: {
      heff_take_n(v_x21_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24250 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str13), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24250, v_sp_242}});
    }
    case TAG_ELazy: {
      V v_e_24251 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ELazy = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      HeffT3 v_t_24252 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_24251));
      {
        V v_field_24254 = v_t_24252.f[1];
        V v_field_24255 = v_t_24252.f[2];
        int64_t v_tag_24253 = ((int64_t)v_t_24252.f[0]);
        V v_t_24265;
        if ((v_tag_24253 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x21_241_24ELazy, 1);
          V v_c_24256 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24254, v_field_24255});
          v_t_24265 = v_c_24256;
        } else {
          if ((v_tag_24253 == ((int64_t)1ULL))) {
            V v_i_24257 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24254, v_field_24255});
            V v_t_24260;
            switch (heff_tag_of(v_i_24257)) {
            case TAG_At: {
              V v_s_24259 = heff_dup(heff_field(v_i_24257, 1));
              v_t_24260 = v_s_24259;
              break;
            }
            default: heff_nomatch(v_i_24257);
            }
            v_t_24265 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ELazy, TAG_CInf, 1, (V[]){v_i_24257}), v_t_24260});
          } else {
            V v_t_24261 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_24254, v_field_24255});
            V v_t_24264;
            switch (heff_tag_of(v_t_24261)) {
            case TAG_At: {
              V v_s_24263 = heff_dup(heff_field(v_t_24261, 1));
              v_t_24264 = v_s_24263;
              break;
            }
            default: heff_nomatch(v_t_24261);
            }
            v_t_24265 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ELazy, TAG_CType, 1, (V[]){v_t_24261}), v_t_24264});
          }
        }
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_ILazy, 1, (V[]){v_t_24265}), v_sp_242}});
      }
    }
    case TAG_ETuple: {
      V v_es_24266 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ETuple = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24267 = (g_list_2emap_24s1844509821x2028168277(v_es_24266));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x21_241_24ETuple, TAG_ITuple, 1, (V[]){v_t_24267}), v_sp_242}});
    }
    case TAG_ETry: {
      heff_take_n(v_x21_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24269 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str14), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24269, v_sp_242}});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_24274 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str15), NTAG(TAG_Nothing)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_24274, v_sp_242}});
    }
    case TAG_EWithBound: {
      V v_bs_24275 = heff_field(v_x21_241, 0);
      V v_w_24276 = heff_field(v_x21_241, 1);
      V v_body_24277 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 7ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_e_24278 = ({ V a_0 = v_sp_242; V a_1 = v_bs_24275; V a_2 = v_w_24276; V a_3 = v_body_24277; V r_ = (g_heff_2esyntax_2epresyntax_2ewithBoundOf(a_0, a_1, a_2, a_3)); heff_drop(v_w_24276); r_; });
      V t_0 = v_e_24278;
      v_x2_240 = t_0;
      goto top;
    }
    default: return ((HeffT3){{heff_nomatch(v_x21_241)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V v_x2_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_243, v_field_244})});
    } else {
      if ((v_tag_242 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_243, v_field_244})});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_243, v_field_244})});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(V v_tok_240, V v_r_241, V v_asBits_242, V v_segs_243, V v_sp_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(v_r_241, v_asBits_242, v_segs_243, v_sp_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    return heff_tag_at_n(v_tok_240, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_246, v_field_247})});
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epresyntax_2ebinaryIn_24tok1(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V v_tok_240, V v_sp_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_IAnn: {
    V v_c_243 = heff_field(v_n_242, 0);
    V v_t_244 = heff_field(v_n_242, 1);
    V v_ru_24n_242_24IAnn = heff_take_reuse_n(v_n_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_c_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_c_243, 0);
      V v_sp_246 = heff_field(v_c_243, 1);
      heff_take_n(v_c_243, 3ULL, 2);
      v_t_247 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_c_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_t_244)) {
    case TAG_At: {
      V v_n_248 = heff_field(v_t_244, 0);
      V v_sp_249 = heff_field(v_t_244, 1);
      V v_ru_24t_244_24At = heff_take_reuse_n(v_t_244, 3ULL, 2);
      v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_244_24At, v_sp_249, v_n_248));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_242_24IAnn, TAG_IAnn, 2, (V[]){v_t_247, v_t_2410}), v_sp_241});
  }
  case TAG_IInvalid: {
    V v_code_2411 = heff_field(v_n_242, 0);
    V v_why_2412 = heff_field(v_n_242, 1);
    V v_note_2413 = heff_field(v_n_242, 2);
    V v_ru_24n_242_24IInvalid = heff_take_reuse_n(v_n_242, 7ULL, 3);
    return heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24n_242_24IInvalid, TAG_IInvalid, 3, 7ULL, (V[]){v_code_2411, v_why_2412, v_note_2413}), v_sp_241});
  }
  default: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
    V v_t_2415 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_241)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_241});
  }
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V v_tok_240, V v_cx_241, V v_sp_242, V v_j_243) {
top: ;
  V v_vars_244 = heff_take_field(v_j_243, 1);
  V v_unit_245 = heff_take_field(v_j_243, 2);
  V v_head_246 = heff_take_field(v_j_243, 0);
  V v_depth_247 = heff_get_n(v_j_243, 3, 4);
  V v_vars_248 = v_vars_244;
  V v_t_249 = v_unit_245;
  V v_t_2413;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    switch (heff_tag_of(v_vars_248)) {
    case TAG_Nil: {
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_str0)}), heff_dup(v_sp_242)});
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      heff_drop_cell(v_tok_240, 1);
      v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_248));
      break;
    }
    default: heff_nomatch(v_vars_248);
    }
  } else {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_t_249);
    v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_248));
  }
  V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_head_246, v_t_2413));
  V v_t_2415 = heff_intSub(heff_dup(heff_rfield(v_cx_241, 4)), v_depth_247);
  return ({ V a_0 = v_cx_241; V a_1 = v_sp_242; V a_2 = v_t_2415; V a_3 = v_t_2414; V r_ = (g_heff_2esyntax_2epresyntax_2eleaving(a_0, a_1, a_2, a_3)); heff_drop_rec(v_cx_241, 7); heff_drop(v_sp_242); heff_drop(v_t_2414); r_; });
}
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(a[0], a[1], a[2], a[3]);
}