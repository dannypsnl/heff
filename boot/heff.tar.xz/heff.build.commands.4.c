// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_Platform 55558
#define TAG_ReadDirectory 46629
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_bug 307438
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_fuel 9649789
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_key 315609
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_packages 1496006433
#define LBL_paths 307797256
#define LBL_sources 357464573
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_value 313331083
static uint32_t shape_paths__hashes__modules__fuel[] = {LBL_paths, LBL_hashes, LBL_modules, LBL_fuel};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_co_2eop_24s981909385x709882350(V, V, V, V, V);
V g_co_2eop_24s981909385x709882350_entry(V self, V *a);
extern Clo g_co_2eop_24s981909385x709882350_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(V, V, V, V);
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_clo;
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674(V, V, V);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311(V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989(V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_clo;
V g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
HeffT2 g_heff_2ecompile_2eglue_2elinksIn_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s107931167x1978109134(V);
V g_list_2emap_24s107931167x1978109134_entry(V self, V *a);
extern Clo g_list_2emap_24s107931167x1978109134_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286(V v_badLoad_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, heff_dup(v_badLoad_240), v_k_243})));
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_badLoad_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_drop(v_x_2416);
  if ((heff_dup(v_badLoad_240) == NTAG(TAG_True))) {
    heff_clo_take(self, 4);
    heff_drop(v_badLoad_240);
    heff_drop(v_cs_241);
    V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), v_hd_242, v_k_243));
  } else {
    heff_clo_take(self, 4);
    heff_drop(v_badLoad_240);
    V v_t_2423 = ({ V a_0 = v_cs_241; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_241); r_; });
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_t_2423);
      V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_hd_242, v_k_243));
    } else {
      heff_drop(v_hd_242);
      heff_drop(v_t_2423);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_badLoad_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_drop(v_x_244);
  HeffT2 v_t_245 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_241));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_c_248 = v_field_247;
      V v_str_249 = (g_heff_2ebuild_2edriver_2einterface(v_c_248));
      V v_t_2410 = heff_tag_n(TAG_Write, 2, (V[]){v_str_249, NTAG(TAG_MkUnit)});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      heff_clo_take(self, 4);
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1047435166x2120164286_lam1, 1, 4, (V[]){v_badLoad_240, v_hd_242, v_k_243, v_cs_241})));
    } else {
      heff_clo_take(self, 4);
      heff_drop(v_cs_241);
      heff_drop(v_badLoad_240);
      heff_drop(v_field_247);
      V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_242, v_k_243));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str0, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str1, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str2, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str3, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_lam0, 1, 0};
Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209(V v_lit_240, V v_z_241, V v_links_242, V v_files_243, V v_out_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Left: {
    V v_r_248 = heff_field(v_x6_245, 0);
    heff_take_n(v_x6_245, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_z_241);
    heff_drop(v_links_242);
    heff_drop(v_files_243);
    heff_drop(v_out_244);
    heff_drop(v_z_246);
    return heff_tail(v_z_247, 1, (V[]){v_r_248});
  }
  case TAG_Right: {
    V v_os_249 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Right = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str0), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_out_244, v_t_2410})});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_links_242, v_t_2411));
    V v_t_2413 = (g_prelude_2e_2b_2b(v_os_249, v_t_2412));
    V v_t_2414 = (g_prelude_2e_2b_2b(v_files_243, v_t_2413));
    V v_ys_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str2), v_t_2414});
    V v_argv_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_240, v_ys_2415})});
    V v_t_2418 = heff_tag_at_n(v_ru_24x6_245_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){v_z_241, ((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_str4), v_argv_2416, ((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_lam0_clo)})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s297957795x1045074450(v_t_2419, v_z_246, v_z_247));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_lam0(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2(v_ru_24x3_242_24MkPair, heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam1(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_x_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    heff_clo_take(self, 5);
    return ({ V a_0 = v_dir_240; V a_1 = v_p_243; V a_2 = v_parts_245; V a_3 = v_done_241; V a_4 = v_p_244; V b_5 = heff_tag_re_n(v_ru_24x_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2418}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_parts_245); heff_drop(b_5); r_; });
  }
  case TAG_Right: {
    V v_y_2419 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    switch (heff_tag_of(v_y_2419)) {
    case TAG_Left: {
      V v_err_2420 = heff_field(v_y_2419, 0);
      V v_ru_24y_2419_24Left = heff_take_reuse_n(v_y_2419, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2417_24Right, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_dir_240; V a_1 = v_p_243; V a_2 = v_parts_245; V a_3 = v_done_241; V a_4 = v_p_244; V b_5 = heff_tag_re_n(v_ru_24y_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2420}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_parts_245); heff_drop(b_5); r_; });
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_y_2419, 0);
      heff_take_n(v_y_2419, 1ULL, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_dir_240; V a_1 = v_p_243; V a_2 = v_parts_245; V a_3 = v_done_241; V a_4 = v_p_244; V b_5 = heff_tag_at_n(v_ru_24x_2417_24Right, TAG_Right, 1, (V[]){v_x_2421}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_parts_245); heff_drop(b_5); r_; });
    }
    default: return heff_nomatch(v_y_2419);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_drop(v_x_247);
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_240)));
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam1_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2416, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  case TAG_Cons: {
    V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2424 = heff_tag_at_n(v_ru_24errors_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_p_243, v_p_244));
  }
  default: return heff_nomatch(v_errors_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str4, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str7, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str9, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str12, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str13, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str14, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str15, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str17, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str18, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str19, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam8(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530(V v_lit_240, V v_bi_241, V v_sources_242, V v_file_243, V v_outPath_244, V v_failed_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_t_2414 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
      V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
      V v_xs_2417 = (g_list_2emap_24s89148281x951607804(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str2), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str3), v_t_2416));
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
      V v_c_2419 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(v_sources_242, v_t_2418));
      return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam0, 1, 9, (V[]){v_z_248, v_c_2413, v_file_243, v_failed_245, v_z_249, v_outPath_244, v_done_246, v_lit_240, v_bi_241})});
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_bi_241);
      heff_drop(v_sources_242);
      heff_drop(v_file_243);
      heff_drop(v_outPath_244);
      heff_drop(v_failed_245);
      heff_drop(v_done_246);
      heff_drop(v_field_2412);
      V v_t_2484 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str19), NTAG(TAG_MkUnit)});
      V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
      V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2489}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam8, 1, 2, (V[]){v_z_248, v_z_249})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam2(V self, V *args) {
  V v_x_2440 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2431 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_drop(v_x_2440);
  heff_clo_take(self, 5);
  V v_t_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str7), v_file_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str8));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2441, v_why_2431);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam3(V self, V *args) {
  V v_x_2457 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2448 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_drop(v_x_2457);
  heff_clo_take(self, 5);
  V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str12), v_file_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str13));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2458, v_why_2448);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam4(V self, V *args) {
  V v_s_2460 = args[0];
  return v_s_2460;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam7(V self, V *args) {
  V v_x_2478 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2469 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_drop(v_x_2478);
  heff_clo_take(self, 5);
  V v_t_2479 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str17), v_file_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str18));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2479, v_why_2469);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam6(V self, V *args) {
  V v_x_2468 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_outPath_244 = heff_env(self)[4];
  V v_done_246 = heff_env(self)[5];
  V v_glues_2443 = heff_env(self)[6];
  V v_x_2420 = heff_env(self)[7];
  V v_lit_240 = heff_env(self)[8];
  V v_bi_241 = heff_env(self)[9];
  V v_x_2421 = heff_env(self)[10];
  V v_c_2413 = heff_env(self)[11];
  switch (heff_tag_of(v_x_2468)) {
  case TAG_Left: {
    V v_why_2469 = heff_field(v_x_2468, 0);
    V v_ru_24x_2468_24Left = heff_take_reuse_n(v_x_2468, 1ULL, 1);
    heff_clo_take(self, 12);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    heff_drop(v_glues_2443);
    heff_drop(v_x_2420);
    heff_drop(v_lit_240);
    heff_drop(v_bi_241);
    heff_drop(v_x_2421);
    heff_drop_rec(v_c_2413, 14);
    V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str14), heff_dup(v_file_243)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str15));
    V v_t_2471 = heff_strAppend(heff_strAppend(v_t_2470, heff_dup(v_why_2469)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str16));
    V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2471, NTAG(TAG_MkUnit)});
    V v_t_2473 = heff_tag_at_n(v_ru_24x_2468_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2477}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam7, 1, 5, (V[]){v_file_243, v_failed_245, v_why_2469, v_z_248, v_z_249})));
  }
  case TAG_Right: {
    V v_fs_2480 = heff_field(v_x_2468, 0);
    V v_ru_24x_2468_24Right = heff_take_reuse_n(v_x_2468, 1ULL, 1);
    heff_clo_take(self, 12);
    V v_t_2481 = (g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674(heff_dup(v_outPath_244), v_fs_2480, v_done_246));
    V v_t_2482 = (g_list_2emap_24s1435185561x202019164(v_glues_2443));
    V v_t_2483 = (g_prelude_2e_2b_2b(v_x_2420, v_t_2482));
    return (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1(v_ru_24x_2468_24Right, v_lit_240, v_bi_241, v_file_243, v_outPath_244, v_x_2421, v_failed_245, v_t_2481, v_c_2413, v_t_2483, v_z_248, v_z_249));
  }
  default: return heff_nomatch(v_x_2468);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam5(V self, V *args) {
  V v_x_2467 = args[0];
  V v_links_2459 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_failed_245 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_outPath_244 = heff_env(self)[5];
  V v_done_246 = heff_env(self)[6];
  V v_glues_2443 = heff_env(self)[7];
  V v_x_2420 = heff_env(self)[8];
  V v_lit_240 = heff_env(self)[9];
  V v_bi_241 = heff_env(self)[10];
  V v_x_2421 = heff_env(self)[11];
  V v_c_2413 = heff_env(self)[12];
  heff_clo_take(self, 13);
  return ({ V a_0 = v_x_2467; V a_1 = v_links_2459; V a_2 = heff_dup(v_z_248); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam6, 1, 12, (V[]){v_file_243, v_z_248, v_failed_245, v_z_249, v_outPath_244, v_done_246, v_glues_2443, v_x_2420, v_lit_240, v_bi_241, v_x_2421, v_c_2413}); V r_ = (g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(a_0, a_1, a_2, a_3)); heff_drop(v_x_2467); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_failed_245 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_outPath_244 = heff_env(self)[6];
  V v_done_246 = heff_env(self)[7];
  V v_lit_240 = heff_env(self)[8];
  V v_bi_241 = heff_env(self)[9];
  V v_t_2422 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
  V v_t_2423 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2422); r_; });
  V v_leaves_2424 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2423));
  V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2420)}));
  V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 10);
  V v_t_2427 = (g_list_2emap_24s164225955x66209884(v_t_2426, v_t_2425, v_leaves_2424));
  HeffT2 v_t_2428 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2427));
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      heff_drop(v_x_2421);
      heff_clo_take(self, 10);
      heff_drop_rec(v_c_2413, 14);
      heff_drop(v_x_2420);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_lit_240);
      heff_drop(v_bi_241);
      V v_why_2431 = v_field_2430;
      V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str4), heff_dup(v_file_243)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str5));
      V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, heff_dup(v_why_2431)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str6));
      V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam2, 1, 5, (V[]){v_file_243, v_failed_245, v_why_2431, v_z_248, v_z_249})));
    } else {
      V v_ms_2442 = v_field_2430;
      V v_glues_2443 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2442));
      V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 10);
      HeffT2 v_t_2445 = (g_heff_2ecompile_2eglue_2elinksIn_24cpr(v_t_2444));
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          heff_drop(v_x_2421);
          heff_clo_take(self, 10);
          heff_drop_rec(v_c_2413, 14);
          heff_drop(v_x_2420);
          heff_drop(v_outPath_244);
          heff_drop(v_done_246);
          heff_drop(v_lit_240);
          heff_drop(v_bi_241);
          heff_drop(v_glues_2443);
          V v_why_2448 = v_field_2447;
          V v_t_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str9), heff_dup(v_file_243)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str10));
          V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2449, heff_dup(v_why_2448)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_str11));
          V v_t_2451 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2450, NTAG(TAG_MkUnit)});
          V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
          V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
          V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
          V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
          V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
          return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2456}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam3, 1, 5, (V[]){v_file_243, v_failed_245, v_why_2448, v_z_248, v_z_249})));
        } else {
          V v_links_2459 = v_field_2447;
          V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam4_clo)})});
          V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
          V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
          V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
          V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
          V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
          heff_clo_take(self, 10);
          return (g_co_2eop_24s535099379x685970669(v_t_2466, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam5, 1, 13, (V[]){v_links_2459, v_z_248, v_file_243, v_failed_245, v_z_249, v_outPath_244, v_done_246, v_glues_2443, v_x_2420, v_lit_240, v_bi_241, v_x_2421, v_c_2413})));
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_failed_245 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_outPath_244 = heff_env(self)[5];
  V v_done_246 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_bi_241 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311(heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam1, 1, 10, (V[]){v_c_2413, v_x_2420, v_file_243, v_z_248, v_failed_245, v_z_249, v_outPath_244, v_done_246, v_lit_240, v_bi_241})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_lam8(V self, V *args) {
  V v_x_2490 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_drop(v_x_2490);
  V v_t_2491 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2495})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2496}), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s981909385x709882350(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092(V v_lit_240, V v_failed_241, V v_who_242, V v_st_243, V v_p_244, V v_dir_245, V v_out_246, V v_next_247) {
top: ;
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_245)));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam1, 2, 10, (V[]){v_a_2411, v_st_243, v_dir_245, v_p_244, v_lit_240, v_out_246, v_next_247, v_who_242, v_failed_241, v_path_248});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam3(V self, V *args) {
  V v_n_2424 = args[0];
  V v_path_248 = heff_env(self)[0];
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2424));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_248, v_t_2425));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  V v_path_248 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 11);
    heff_drop(v_path_248);
    return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1(v_st_243, v_dir_245, v_p_244, v_hd_2412, v_lit_240, v_out_246, v_next_247, v_k_2413, v_who_242, v_failed_241, heff_tag_re_n(v_ru_24x_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2420})));
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      V v_err_2422 = heff_field(v_y_2421, 0);
      V v_ru_24y_2421_24Left = heff_take_reuse_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 11);
      heff_drop(v_path_248);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1(v_st_243, v_dir_245, v_p_244, v_hd_2412, v_lit_240, v_out_246, v_next_247, v_k_2413, v_who_242, v_failed_241, heff_tag_re_n(v_ru_24y_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2422})));
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 11);
      V v_x_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam3, 1, 1, (V[]){v_path_248}), v_x_2423));
      V v_x_2427 = (g_list_2emap_24s219049803x1458391381(v_x_2426));
      return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1(v_st_243, v_dir_245, v_p_244, v_hd_2412, v_lit_240, v_out_246, v_next_247, v_k_2413, v_who_242, v_failed_241, heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_x_2427})));
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  V v_st_243 = heff_env(self)[1];
  V v_dir_245 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_who_242 = heff_env(self)[7];
  V v_failed_241 = heff_env(self)[8];
  V v_path_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_lam2, 1, 11, (V[]){v_st_243, v_dir_245, v_p_244, v_hd_2412, v_lit_240, v_out_246, v_next_247, v_k_2413, v_who_242, v_failed_241, v_path_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205(V v_lit_240, V v_fuel_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam0, 1, 9, (V[]){v_l_242, v_hd_247, v_fuel_241, v_lit_240, v_k_248, v_file_245, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  V v_sources_2414 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = ({ V a_0 = v_c_2416; V a_1 = v_sources_2414; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2414); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2419;
      V v_t_2421 = ({ V a_0 = v_x_2415; V a_1 = v_s_2420; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2415); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2416, v_t_2421));
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_field_2419);
      return v_c_2416;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam4(V self, V *args) {
  V v_a_2442 = args[0];
  V v_z_2443 = args[1];
  V v_z_2444 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_a_2442);
  heff_clo_take(self, 1);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_z_2443, v_z_2444));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_cs_2423 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_done_2412 = heff_env(self)[5];
  V v_l_242 = heff_env(self)[6];
  V v_hashes_2413 = heff_env(self)[7];
  V v_fuel_241 = heff_env(self)[8];
  V v_file_245 = heff_env(self)[9];
  V v_name_243 = heff_env(self)[10];
  V v_outPath_244 = heff_env(self)[11];
  V v_done_246 = heff_env(self)[12];
  heff_drop(v_x_2424);
  heff_clo_take(self, 13);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop(v_done_2412);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_hashes_2413);
    heff_drop(v_fuel_241);
    heff_drop(v_file_245);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    V v_x2_2425 = ({ V a_0 = v_cs_2423; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_2423); r_; });
    heff_drop(v_x2_2425);
    V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_247, v_k_248));
  } else {
    V v_t_2432 = (g_list_2eany_24s1740858080x874135214(v_cs_2423));
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_done_2412);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_hashes_2413);
      heff_drop(v_fuel_241);
      heff_drop(v_file_245);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2432);
      V v_x2_2433 = ({ V a_0 = v_cs_2423; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_2423); r_; });
      heff_drop(v_x2_2433);
      V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
      return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_247, v_k_248));
    } else {
      heff_drop(v_t_2432);
      V v_t_2440 = (g_list_2emap_24s1698496827x1884878103(v_done_2412));
      V v_t_2441 = heff_rec_n(4, shape_paths__hashes__modules__fuel, (V[]){heff_take_field(v_l_242, 2), v_hashes_2413, v_t_2440, v_fuel_241});
      return ({ V a_0 = v_t_2441; V a_1 = heff_get_n(v_l_242, 0, 5); V a_2 = v_file_245; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam4, 3, 1, (V[]){v_lit_240}); V a_6 = v_done_246; V a_7 = v_cs_2423; V a_8 = v_hd_247; V a_9 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_cs_2423); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_fuel_241 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_file_245 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  V v_done_2412 = heff_take_field(v_x_2411, 0);
  V v_hashes_2413 = heff_get_n(v_x_2411, 1, 2);
  V v_sources_2414 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2415 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_str2), heff_dup(v_sources_2414)));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam2, 1, 2, (V[]){v_sources_2414, v_x_2415}), heff_dup(v_done_2412)));
  V v_cs_2423;
  if ((heff_dup(v_fuel_241) == NTAG(TAG_True))) {
    v_cs_2423 = v_x_2422;
  } else {
    v_cs_2423 = (g_list_2emap_24s107931167x1978109134(v_x_2422));
  }
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2423), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam3, 1, 13, (V[]){v_x_249, v_cs_2423, v_lit_240, v_hd_247, v_k_248, v_done_2412, v_l_242, v_hashes_2413, v_fuel_241, v_file_245, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_fuel_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_file_245 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  V v_t_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_l_242)));
  heff_clo_take(self, 9);
  V f_ = v_t_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_lam1, 1, 10, (V[]){v_l_242, v_fuel_241, v_hd_247, v_x_249, v_lit_240, v_k_248, v_file_245, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str1, 10, "   (local)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str2, 11, "   (global)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str3, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str4, 13, "nothing there");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str5, 13, "nothing there");
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989(V v_file_240, V v_offs_241) {
top: ;
  V v_c_242 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam0, 2, 3, (V[]){v_c_242, v_file_240, v_offs_241});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam7(V self, V *args) {
  V v_off_2419 = args[0];
  V v_c_2418 = heff_env(self)[0];
  HeffT2 v_t_2420 = ({ V a_0 = v_off_2419; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_off_2419); r_; });
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_o_2423 = v_field_2422;
      heff_clo_take(self, 1);
      HeffT2 v_t_2424 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2418, v_o_2423));
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_i_2427 = v_field_2426;
          V v_name_2428 = heff_take_field(v_i_2427, 1);
          V v_ty_2429 = heff_take_field(v_i_2427, 4);
          V v_key_2430 = heff_get_n(v_i_2427, 2, 5);
          V v_t_2431 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_2428));
          V v_t_2432 = heff_tr(heff_call(v_ty_2429, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_2433 = v_key_2430;
          V v_t_2435;
          switch (heff_tag_of(v_t_2433)) {
          case TAG_Nothing: {
            v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str1);
            break;
          }
          case TAG_Just: {
            heff_take_n(v_t_2433, 0ULL, 1);
            v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str2);
            break;
          }
          default: heff_nomatch(v_t_2433);
          }
          V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str3)), v_t_2432);
          V v_t_2437 = heff_strAppend(v_t_2436, v_t_2435);
          return v_t_2437;
        } else {
          heff_drop(v_field_2426);
          return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str4);
        }
      }
    } else {
      heff_drop(self);
      heff_drop(v_field_2422);
      return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str5);
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_cs_2413 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_drop(v_x_2414);
  heff_clo_take(self, 4);
  HeffT2 v_t_2415 = ({ V a_0 = v_cs_2413; HeffT2 r_ = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(a_0)); heff_drop(v_cs_2413); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_c_2418 = v_field_2417;
      V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam7, 1, 1, (V[]){v_c_2418}), v_offs_241));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633(v_t_2438, v_hd_243, v_k_244));
    } else {
      heff_drop(v_offs_241);
      heff_drop(v_field_2417);
      V v_t_2439 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_cs_2413 = heff_get_n(v_x_2412, 0, 2);
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2413), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam6, 1, 4, (V[]){v_cs_2413, v_offs_241, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_drop(v_x_2410);
  heff_clo_take(self, 4);
  V v_t_2411 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(v_x_249));
  V f_ = v_t_2411;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam5, 1, 3, (V[]){v_hd_243, v_offs_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_t_248 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_247, heff_dup(heff_rfield(v_x_246, 4))));
  heff_clo_take(self, 4);
  V v_x_249 = (g_list_2efoldl_24s571074576x1179600767(v_x_246, v_t_248));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_str0), heff_dup(heff_rfield(v_x_249, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam4, 1, 4, (V[]){v_x_249, v_hd_243, v_offs_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam3, 1, 4, (V[]){v_x_246, v_hd_243, v_offs_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_245, v_file_240, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam2, 1, 3, (V[]){v_hd_243, v_offs_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1808169566x71214989_lam1, 1, 4, (V[]){v_file_240, v_hd_243, v_offs_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_name_245 = heff_take_field(v_d_243, 0);
    V v_value_246 = heff_take_field(v_d_243, 1);
    V v_bug_247 = heff_get_n(v_d_243, 2, 3);
    V v_t_248 = heff_strAppend(heff_strAppend(v_name_245, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_str0)), v_value_246);
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_str1)), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_lam0, 1, 4, (V[]){v_rest_244, v_p_241, v_bug_247, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_bug_247 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_t_2417 = heff_bool(((heff_dup(v_bug_247) == NTAG(TAG_True)) || (heff_dup(v_x_2416) == NTAG(TAG_True))));
  heff_drop(v_x_2416);
  heff_clo_take(self, 2);
  heff_drop(v_bug_247);
  V f_ = v_p_242;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_bug_247 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_drop(v_x_2415);
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s321369413x1699564770_lam1, 1, 2, (V[]){v_bug_247, v_p_242})));
}