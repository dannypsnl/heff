// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SOpaque 44226
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_poisoned 1215742945
#define LBL_ren 322325
#define LBL_ret 322331
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2eelab_2econversion_2ecanon(V);
V g_heff_2eelab_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_clo;
V g_heff_2eelab_2econversion_2ecanon_24tok1(V, V);
V g_heff_2eelab_2econversion_2ecanon_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_24tok1_clo;
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eappendL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24dps_clo;
V g_heff_2eelab_2eunify_2eappendL_24tok2(V, V, V);
V g_heff_2eelab_2eunify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_24tok2_clo;
HeffT2 g_heff_2eelab_2eunify_2eappsRev_24cpr(V);
V g_heff_2eelab_2eunify_2econcatMapL(V, V);
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2econcatMapL_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2eiterateLift_24scalars(V, V, V, V);
V g_heff_2eelab_2eunify_2eiterateLift_24scalars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_24scalars_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
HeffT3 g_heff_2eelab_2eunify_2emetasK_24cpr(V);
V g_heff_2eelab_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTermF_clo;
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(V, V, V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo;
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_clo;
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_clo;
V g_heff_2eelab_2eunify_2espineArgs(V, V);
V g_heff_2eelab_2eunify_2espineArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2espineArgs_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo;
V g_heff_2eelab_2eunify_2euAlg(V, V);
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euAlg_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo;
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695_clo;
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031_clo;
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2eunify_2ezipL_24dps(V, V, V);
V g_heff_2eelab_2eunify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_24dps_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate1(V, V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate1_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF_24map2(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map2_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisError(V);
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisError_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2ezipL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezipL_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezipL_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_248;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ezipL_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eunify_2ezipL_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTermF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244) {
top: ;
  V v_msp_245 = heff_take_field(v_r_240, 2);
  V v_mty_246 = heff_take_field(v_r_240, 1);
  V v_mel_247 = heff_get_n(v_r_240, 0, 3);
  if (heff_intLe_c_lent(v_depth_242, MK_INT(0LL), 2)) {
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_v0_244);
    heff_drop(v_msp_245);
    heff_drop(v_mty_246);
    heff_drop(v_mel_247);
    return NTAG(TAG_Nil);
  } else {
    V v_it_248 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v0_244));
    switch (heff_tag_of(v_it_248)) {
    case TAG_VNeu: {
      V v_it1_249 = heff_field(v_it_248, 0);
      V v_sp_2410 = heff_field(v_it_248, 1);
      heff_take_n(v_it_248, 3ULL, 5);
      heff_drop(v_mty_246);
      heff_drop(v_mel_247);
      switch (heff_tag_of(v_it1_249)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_249, 0ULL, 1);
        return heff_tail(v_msp_245, 3, (V[]){v_depth_242, v_len_243, v_sp_2410});
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_249, 0ULL, 1);
        return heff_tail(v_msp_245, 3, (V[]){v_depth_242, v_len_243, v_sp_2410});
      }
      case TAG_HMeta: {
        V v_m_2416 = heff_field(v_it1_249, 0);
        heff_take_n(v_it1_249, 1ULL, 1);
        V v_t_2417 = heff_tr(heff_call(v_msp_245, 3, (V[]){v_depth_242, v_len_243, v_sp_2410}));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_m_2416, v_t_2417});
      }
      case TAG_HError: {
        return heff_tail(v_msp_245, 3, (V[]){v_depth_242, v_len_243, v_sp_2410});
      }
      default: return heff_nomatch(v_it1_249);
      }
    }
    case TAG_VCode: {
      V v_t_2418 = heff_field(v_it_248, 0);
      heff_take_n(v_it_248, 1ULL, 1);
      heff_drop(v_msp_245);
      heff_drop(v_mel_247);
      return heff_tail(v_mty_246, 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2418});
    }
    case TAG_VLam: {
      V v_d_2419 = heff_field(v_it_248, 0);
      V v_c_2420 = heff_field(v_it_248, 1);
      heff_take_n(v_it_248, 3ULL, 2);
      heff_drop(v_msp_245);
      heff_drop(v_mty_246);
      V v_x1_2441;
      switch (heff_tag_of(v_c_2420)) {
      case TAG_MkClo: {
        V v_vs_2422 = heff_field(v_c_2420, 1);
        V v_body_2423 = heff_field(v_c_2420, 2);
        heff_take_n(v_c_2420, 6ULL, 3);
        v_x1_2441 = heff_tr(heff_call(v_body_2423, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2422, heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam0, 1, 2, (V[]){v_d_2419, heff_dup(v_len_243)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2440 = heff_field(v_c_2420, 0);
        heff_take_n(v_c_2420, 1ULL, 1);
        heff_drop(v_d_2419);
        v_x1_2441 = v_body_2440;
        break;
      }
      default: heff_nomatch(v_c_2420);
      }
      V v_t_2445;
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_Nom: {
        V v_x_2442 = heff_field(v_x1_2441, 0);
        heff_take_n(v_x1_2441, 1ULL, 1);
        v_t_2445 = v_x_2442;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2441, 0ULL, 1);
        v_t_2445 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2444 = heff_field(v_x1_2441, 0);
        heff_take_n(v_x1_2441, 1ULL, 1);
        v_t_2445 = v_x_2444;
        break;
      }
      default: heff_nomatch(v_x1_2441);
      }
      return heff_tail(v_mel_247, 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2445});
    }
    case TAG_VCons: {
      V v_d_2446 = heff_field(v_it_248, 0);
      heff_take_n(v_it_248, 1ULL, 1);
      heff_drop(v_msp_245);
      heff_drop(v_mty_246);
      V v_t_2447 = heff_arrayToList(heff_get_n(v_d_2446, 2, 3));
      return ({ V b_0 = heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam2, 1, 3, (V[]){v_mel_247, v_depth_242, v_len_243}); V a_1 = v_t_2447; V r_ = (g_heff_2eelab_2eunify_2econcatMapL(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2447); r_; });
    }
    case TAG_VOpaque: {
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      heff_drop(v_msp_245);
      heff_drop(v_mty_246);
      heff_drop(v_mel_247);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_it_248);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2emetasTermF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args) {
  V v_u_2439 = args[0];
  V v_a_2438 = heff_env(self)[0];
  heff_drop(v_u_2439);
  heff_clo_take(self, 1);
  return v_a_2438;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args) {
  V v_u_2424 = args[0];
  V v_d_2419 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  heff_drop(v_u_2424);
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tr(heff_call(v_d_2419, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2425)));
  V v_a_2438;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2429 = heff_field(v_t_2426, 1);
    heff_take_n(v_t_2426, 2ULL, 4);
    heff_drop(v_t_2425);
    v_a_2438 = v_dom_2429;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2426, 0ULL, 3);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeInt: {
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeFloat: {
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeString: {
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeRune: {
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_a_2438 = v_t_2425;
    break;
  }
  case TAG_NoRules: {
    v_a_2438 = v_t_2425;
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam1, 1, 1, (V[]){v_a_2438}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args) {
  V v_x_2448 = args[0];
  V v_mel_247 = heff_env(self)[0];
  V v_depth_242 = heff_env(self)[1];
  V v_len_243 = heff_env(self)[2];
  V v_t_2452;
  switch (heff_tag_of(v_x_2448)) {
  case TAG_Nom: {
    V v_x_2449 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2452 = v_x_2449;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x_2448, 0ULL, 1);
    v_t_2452 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2451 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2452 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_x_2448);
  }
  heff_clo_take(self, 3);
  V f_ = v_mel_247;
  heff_room[0] = heff_intSub(v_depth_242, MK_INT(1LL));
  heff_room[1] = v_len_243;
  heff_room[2] = v_t_2452;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
Clo g_heff_2eelab_2eunify_2ezonkTypeF_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_24generate1_entry, 4, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF_24generate1(V v_r_240, V v_xs_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_241, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_xs_241, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_244}));
      V t_0 = v_r_240;
      V t_1 = v_xs_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_245);
      v_r_240 = t_0;
      v_xs_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_xs_241, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_244}));
    V t_0 = v_r_240;
    V t_1 = v_xs_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_245);
    v_r_240 = t_0;
    v_xs_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTypeF_24generate1(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2ezonkTypeF_24map2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_24map2_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF_24map2(V v_r_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_t_243}));
      V t_0 = v_r_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_t_243}));
    V t_0 = v_r_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_24map2_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2ezonkTypeF_24map2(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eunify_2eiterateLift_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eiterateLift_24scalars_entry, 4, 0};

V g_heff_2eelab_2eunify_2eiterateLift_24scalars(V v_i_240, V v_dom_241, V v_cod_242, V v_ren_243) {
top: ;
  if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
    heff_drop(v_i_240);
    return heff_rec_n(3, shape_dom__cod__ren, (V[]){v_dom_241, v_cod_242, v_ren_243});
  } else {
    V v_t_244 = (g_std_2eordmap_2einsert_24s1703101629x493626677(v_ren_243, v_dom_241, v_cod_242));
    V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
    V t_1 = heff_intAdd(v_dom_241, MK_INT(1LL));
    V t_2 = heff_intAdd(v_cod_242, MK_INT(1LL));
    V t_3 = v_t_244;
    v_i_240 = t_0;
    v_dom_241 = t_1;
    v_cod_242 = t_2;
    v_ren_243 = t_3;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2eiterateLift_24scalars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eiterateLift_24scalars(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2eiterateLift_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eiterateLift_entry, 2, 0};

V g_heff_2eelab_2eunify_2eiterateLift(V v_i_240, V v_rr_241) {
top: ;
  V v_dom_242 = heff_take_field(v_rr_241, 0);
  V v_cod_243 = heff_take_field(v_rr_241, 1);
  V v_ren_244 = heff_get_n(v_rr_241, 2, 3);
  return (g_heff_2eelab_2eunify_2eiterateLift_24scalars(v_i_240, v_dom_242, v_cod_243, v_ren_244));
}
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eiterateLift(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eunify_2elamsU_str0, 1, "x");
Clo g_heff_2eelab_2eunify_2elamsU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2elamsU_entry, 2, 0};

V g_heff_2eelab_2eunify_2elamsU(V v_k_240, V v_body_241) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return v_body_241;
  } else {
    V v_t_242 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
    V v_t_243 = heff_tag_n(TAG_SLam, 2, (V[]){v_t_242, heff_tag_n(TAG_MkAbs, 2, (V[]){((V)&g_heff_2eelab_2eunify_2elamsU_str0), v_body_241})});
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_t_243;
    v_k_240 = t_0;
    v_body_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2elamsU(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2espineArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2espineArgs_entry, 2, 0};

V g_heff_2eelab_2eunify_2espineArgs(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return v_acc_241;
  }
  case TAG_SpApp: {
    V v_sp_242 = heff_field(v_x1_240, 0);
    V v_a_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_sp_242;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_a_243, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SpProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_SpSpec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_acc_241;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2espineArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2espineArgs(a[0], a[1]);
}

HeffT2 g_heff_2eelab_2eunify_2eappsRev_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_SpApp: {
    V v_s_241 = heff_field(v_x1_240, 0);
    V v_a_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2eelab_2eunify_2eappsRev_24cpr(v_s_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_argv_246 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_a_242, v_argv_246})}});
      } else {
        heff_drop(v_a_242);
        heff_drop_cell(v_ru_24x1_240_24SpApp, 2);
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_SpProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SpSpec: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2eunify_2euAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euAlg_entry, 2, 0};

V g_heff_2eelab_2eunify_2euAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_call(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_c2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at_n(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_c2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_err_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_err_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_m_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      V v_ru_24q_247_24Catch = heff_take_reuse_n(v_q_247, 3ULL, 2);
      V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x21_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24InR, 1);
          heff_drop_cell(v_ru_24q_247_24Catch, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_e_2414, v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop(v_h_2410);
          return heff_tag_at_n(v_ru_24q_247_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2415}), v_st_2413});
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euAlg(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam0, 1, 1, (V[]){v_v0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam1, 1, 5, (V[]){v_m_241, v_hd_244, v_k_245, v_g_240, v_pr_242})});
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_sp_2411; V a_4 = v_x_2419; V r_ = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_240); heff_drop(v_m_241); heff_drop(v_pr_242); heff_drop(v_x_2419); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2426, v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_fty_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2424 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = heff_tr(heff_call(v_fty_2423, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2428 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2427)));
  V v_t_2440;
  switch (heff_tag_of(v_t_2428)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2428, 0ULL, 1);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2431 = heff_field(v_t_2428, 1);
    heff_take_n(v_t_2428, 2ULL, 4);
    heff_drop(v_t_2427);
    v_t_2440 = v_dom_2431;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2428, 0ULL, 3);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2428, 0ULL, 1);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeInt: {
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeString: {
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeRune: {
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2428, 0ULL, 1);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2428, 0ULL, 1);
    v_t_2440 = v_t_2427;
    break;
  }
  case TAG_NoRules: {
    v_t_2440 = v_t_2427;
    break;
  }
  default: heff_nomatch(v_t_2428);
  }
  return (g_heff_2eelab_2eunify_2erenameClo_24s135024874x281590421(v_g_240, v_m_241, v_pr_242, v_t_2440, v_body_2424, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam5, 1, 2, (V[]){v_k_245, v_x_2426})));
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam9(V self, V *args) {
  V v_x_2456 = args[0];
  V v_k_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2455;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2456});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam8(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2453 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_v_2453, v_hd_2454, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam9, 1, 1, (V[]){v_k_2455})));
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_k_2450 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2450;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2447, v_x_2458});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam7(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_x_2448 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_k_2447 = heff_env(self)[4];
  V v_t_2457;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2448)) {
  case TAG_Nom: {
    V v_v_2451 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2457 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2451}));
    break;
  }
  case TAG_Describe: {
    V v_v_2452 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2457 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2452}));
    break;
  }
  case TAG_Become: {
    V v_v_2453 = heff_field(v_x_2448, 0);
    heff_take_n(v_x_2448, 1ULL, 1);
    v_t_2457 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam8, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2453});
    break;
  }
  default: heff_nomatch(v_x_2448);
  }
  V f_ = v_t_2457;
  args[0] = v_hd_2449;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam10, 1, 2, (V[]){v_k_2450, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam6(V self, V *args) {
  V v_p_2446 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  switch (heff_tag_of(v_p_2446)) {
  case TAG_MkPair: {
    V v_k_2447 = heff_field(v_p_2446, 0);
    V v_x_2448 = heff_field(v_p_2446, 1);
    heff_take_n(v_p_2446, 3ULL, 2);
    heff_clo_take(self, 3);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam7, 2, 5, (V[]){v_x_2448, v_g_240, v_m_241, v_pr_242, v_k_2447});
  }
  default: return heff_nomatch(v_p_2446);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_t_2461 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2460)));
  V v_t_2462 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2460));
  V v_t_2463 = (g_list_2emap_24s1173914895x100384474(v_x_2460));
  V v_t_2464 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2461), v_t_2462, heff_arrayFromList(v_t_2463)});
  V v_x_2465 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2464});
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_249)) {
  case TAG_VNeu: {
    V v_it1_2410 = heff_field(v_x_249, 0);
    V v_sp_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HMeta: {
      V v_m_27_2415 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2415, v_m_241, 0)) {
        heff_clo_take(self, 5);
        heff_drop(v_m_241);
        heff_drop(v_g_240);
        heff_drop(v_pr_242);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2415);
        V v_t_2416 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2417 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
        V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2417}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2418;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        heff_clo_take(self, 5);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(v_g_240, v_m_241, v_pr_242, v_m_27_2415, v_sp_2411, v_hd_244, v_k_245));
      }
    }
    default: {
      heff_clo_take(self, 5);
      return (g_heff_2eelab_2eunify_2erenameHead_24s1458708101x1555050592(heff_dup(v_pr_242), v_it1_2410, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})));
    }
    }
  }
  case TAG_VCode: {
    V v_t_2421 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(v_g_240, v_m_241, v_pr_242, v_t_2421, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam3, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2423 = heff_field(v_x_249, 0);
    V v_body_2424 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2425 = heff_tr(heff_call(heff_dup(v_fty_2423), 1, (V[]){NTAG(TAG_MkUnit)}));
    heff_clo_take(self, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2425, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam4, 1, 7, (V[]){v_fty_2423, v_g_240, v_m_241, v_pr_242, v_body_2424, v_hd_244, v_k_245})));
  }
  case TAG_VCons: {
    V v_d_2442 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_keys_2443 = heff_take_field(v_d_2442, 0);
    V v_values_2444 = heff_get_n(v_d_2442, 2, 3);
    V v_t_2445 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2443), heff_arrayToList(v_values_2444)));
    heff_clo_take(self, 5);
    V v_t_2459 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam6, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2445));
    V f_ = v_t_2459;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_lam11, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VOpaque: {
    heff_clo_take(self, 5);
    heff_drop(v_m_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_pr_242);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam11(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam11, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_entry, 7, 0};

V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_248 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_249 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s868530262x539343671(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_pr_2410 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_get_n(v_cs_241, 0, 2), v_t_247, v_t_249});
  V v_k_2411 = heff_dup(heff_rfield(v_z_245, 0));
  V v_t_2413 = heff_tr(g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(heff_dup(v_g_240), heff_dup(v_m_242), v_pr_2410, v_rhs_244, heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam0, 1, 1, (V[]){v_k_2411})));
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam1, 1, 1, (V[]){heff_dup(v_z_245)})})});
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2454}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2455, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam7, 1, 5, (V[]){v_z_246, v_args_243, v_g_240, v_m_242, v_z_245})});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k2_2419 = args[1];
  V v_s_2414 = heff_env(self)[0];
  V v_malg_2420 = heff_take_field(v_hd_2418, 2);
  V v_bind_2421 = heff_get_n(v_hd_2418, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2414})});
  V v_t_2423 = heff_tr(heff_call(v_malg_2420, 1, (V[]){v_t_2422}));
  V f_ = v_bind_2421;
  args[0] = v_t_2423;
  args[1] = v_k2_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_s_2414 = heff_env(self)[0];
  V v_malg_2429 = heff_take_field(v_hd_2427, 2);
  V v_bind_2430 = heff_get_n(v_hd_2427, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2414})});
  V v_t_2432 = heff_tr(heff_call(v_malg_2429, 1, (V[]){v_t_2431}));
  V f_ = v_bind_2430;
  args[0] = v_t_2432;
  args[1] = v_k2_2428;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam4(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k2_2439 = args[1];
  V v_s_2414 = heff_env(self)[0];
  V v_malg_2440 = heff_take_field(v_hd_2438, 2);
  V v_bind_2441 = heff_get_n(v_hd_2438, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2414})});
  V v_t_2443 = heff_tr(heff_call(v_malg_2440, 1, (V[]){v_t_2442}));
  V f_ = v_bind_2441;
  args[0] = v_t_2443;
  args[1] = v_k2_2439;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_s_2414 = heff_env(self)[0];
  V v_malg_2449 = heff_take_field(v_hd_2447, 2);
  V v_bind_2450 = heff_get_n(v_hd_2447, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2414})});
  V v_t_2452 = heff_tr(heff_call(v_malg_2449, 1, (V[]){v_t_2451}));
  V f_ = v_bind_2450;
  args[0] = v_t_2452;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_t_2453;
  switch (heff_tag_of(v_s_2414)) {
  case TAG_UnequalTys: {
    v_t_2453 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam2, 2, 1, (V[]){v_s_2414});
    break;
  }
  case TAG_UnequalEls: {
    v_t_2453 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam3, 2, 1, (V[]){v_s_2414});
    break;
  }
  case TAG_UnequalNeus: {
    v_t_2453 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam4, 2, 1, (V[]){v_s_2414});
    break;
  }
  case TAG_MentionsError: {
    v_t_2453 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam5_clo);
    break;
  }
  case TAG_Escapes: {
    v_t_2453 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam6, 2, 1, (V[]){v_s_2414});
    break;
  }
  default: heff_nomatch(v_s_2414);
  }
  heff_clo_take(self, 1);
  V f_ = v_t_2453;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_get_n(v_z_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam9(V self, V *args) {
  V v_c_2466 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2467 = ({ V b_0 = heff_get_n(v_c_2466, 2, 9); V a_1 = v_m_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_m_242); r_; });
  {
    V v_field_2469 = v_t_2467.f[1];
    int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2468 == ((int64_t)0ULL)) && ({ V v_x_2470 = heff_dup(v_field_2469); int c_ = 1; heff_drop(v_x_2470); c_; })));
    heff_drop(v_field_2469);
    return v_ret_24bool;
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam11(V self, V *args) {
  V v_c_2474 = args[0];
  return heff_get_n(v_c_2474, 3, 9);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam13(V self, V *args) {
  V v_x_2483 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2459 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_drop(v_x_2483);
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_m_242, v_t_2459, v_z_245, v_z_246));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam12(V self, V *args) {
  V v_x_2477 = args[0];
  V v_v_2464 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2459 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  HeffT3 v_t_2478 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2477));
  {
    V v_field_2479 = v_t_2478.f[0];
    heff_drop(v_t_2478.f[1]);
    heff_drop(v_t_2478.f[2]);
    heff_clo_take(self, 5);
    V v_t_2482 = heff_tr(heff_call(v_field_2479, 3, (V[]){MK_INT(20LL), MK_INT(0LL), v_v_2464}));
    return ({ V a_0 = v_t_2482; V a_1 = heff_dup(v_z_245); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam13, 1, 4, (V[]){v_m_242, v_t_2459, v_z_245, v_z_246}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2482); r_; });
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam10(V self, V *args) {
  V v_x_2473 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_v_2464 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2459 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  if ((heff_dup(v_x_2473) == NTAG(TAG_True))) {
    heff_drop(v_x_2473);
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam11_clo)})});
    V v_t_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2475}));
    heff_clo_take(self, 5);
    V f_ = heff_dup(heff_rfield(v_z_245, 1));
    heff_room[0] = v_t_2476;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam12, 1, 5, (V[]){v_v_2464, v_z_245, v_m_242, v_t_2459, v_z_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2473);
    heff_clo_take(self, 5);
    heff_drop(v_v_2464);
    return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_m_242, v_t_2459, v_z_245, v_z_246));
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_v_2464 = heff_env(self)[2];
  V v_t_2459 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_drop(v_x_2465);
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam9, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2471}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2472;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam10, 1, 5, (V[]){v_z_245, v_v_2464, v_m_242, v_t_2459, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2456)) {
  case TAG_Nothing: {
    heff_clo_take(self, 5);
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop_rec(v_z_245, 3);
    V f_ = v_z_246;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2457 = heff_field(v_x_2456, 0);
    V v_ru_24x_2456_24Just = heff_take_reuse_n(v_x_2456, 1ULL, 1);
    heff_clo_take(self, 5);
    V v_t_2458 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2459 = (g_heff_2eelab_2eunify_2elamsU(v_t_2458, v_body_2457));
    V v_x1_2460 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = heff_dup(v_t_2459); V a_3 = NTAG(TAG_LNil); V r_ = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); r_; });
    V v_v_2464;
    switch (heff_tag_of(v_x1_2460)) {
    case TAG_Nom: {
      V v_x_2461 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      v_v_2464 = v_x_2461;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2460, 0ULL, 1);
      v_v_2464 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2463 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      v_v_2464 = v_x_2463;
      break;
    }
    default: heff_nomatch(v_x1_2460);
    }
    return ({ V a_0 = v_ru_24x_2456_24Just; V a_1 = v_m_242; V a_2 = heff_dup(v_v_2464); V a_3 = heff_dup(v_t_2459); V a_4 = heff_dup(v_z_245); V a_5 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s245721962x1145924075_lam8, 1, 5, (V[]){heff_dup(v_m_242), v_z_245, v_v_2464, v_t_2459, v_z_246}); V r_ = (g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_m_242); r_; });
  }
  default: return heff_nomatch(v_x_2456);
  }
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 9); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  return heff_get_n(v_c_2416, 3, 9);
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam7(V self, V *args) {
  V v_c_2426 = args[0];
  return heff_get_n(v_c_2426, 3, 9);
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  HeffT3 v_t_2430 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2429));
  {
    V v_field_2431 = v_t_2430.f[0];
    heff_drop(v_t_2430.f[1]);
    heff_drop(v_t_2430.f[2]);
    heff_clo_take(self, 4);
    V v_t_2434 = heff_tr(heff_call(v_field_2431, 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2413}));
    return ({ V a_0 = v_t_2434; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
  }
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_drop(v_x_2425);
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam7_clo)})});
  V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2427}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2428;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam8, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  HeffT3 v_t_2420 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2419));
  {
    V v_field_2421 = v_t_2420.f[0];
    heff_drop(v_t_2420.f[1]);
    heff_drop(v_t_2420.f[2]);
    heff_clo_take(self, 5);
    V v_t_2424 = heff_tr(heff_call(v_field_2421, 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_249}));
    return ({ V a_0 = v_t_2424; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2413, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
  }
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_t_2414 = (g_heff_2eelab_2evalue_2eisError(v_x_249));
  V v_t_2415;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    v_t_2415 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2414);
    v_t_2415 = (g_heff_2eelab_2evalue_2eisError(v_x_2413));
  }
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_clo_take(self, 5);
    heff_drop(v_g_240);
    heff_drop(v_t_2415);
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam4_clo)})});
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2417}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2418;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam5, 1, 5, (V[]){v_cs_241, v_x_249, v_hd_244, v_x_2413, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2415);
    heff_clo_take(self, 5);
    switch (heff_tag_of(v_x_249)) {
    case TAG_VOpaque: {
      heff_drop(v_x_2413);
      heff_drop_rec(v_hd_244, 3);
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_g_240);
      V f_ = v_k_245;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: {
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VOpaque: {
        heff_drop(v_x_249);
        heff_drop_rec(v_hd_244, 3);
        heff_drop_rec(v_cs_241, 2);
        heff_drop(v_g_240);
        V f_ = v_k_245;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: {
        V v_t_2447;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VNeu: {
          V v_v1_2435 = heff_dup(heff_field(v_x_249, 0));
          V v_sp_2436 = heff_dup(heff_field(v_x_249, 1));
          switch (heff_tag_of(v_v1_2435)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2435, 0ULL, 1);
            heff_drop(v_sp_2436);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2435, 0ULL, 1);
            heff_drop(v_sp_2436);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_2442 = heff_field(v_v1_2435, 0);
            V v_ru_24v1_2435_24HMeta = heff_take_reuse_n(v_v1_2435, 1ULL, 1);
            v_t_2447 = heff_tag_at_n(v_ru_24v1_2435_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2442, v_sp_2436})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2436);
            v_t_2447 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2435);
          }
          break;
        }
        case TAG_VCode: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_2447 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        switch (heff_tag_of(v_t_2447)) {
        case TAG_Nothing: {
          V v_t_2460;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VNeu: {
            V v_v1_2448 = heff_dup(heff_field(v_x_2413, 0));
            V v_sp_2449 = heff_dup(heff_field(v_x_2413, 1));
            switch (heff_tag_of(v_v1_2448)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_2448, 0ULL, 1);
              heff_drop(v_sp_2449);
              v_t_2460 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_2448, 0ULL, 1);
              heff_drop(v_sp_2449);
              v_t_2460 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_2455 = heff_field(v_v1_2448, 0);
              V v_ru_24v1_2448_24HMeta = heff_take_reuse_n(v_v1_2448, 1ULL, 1);
              v_t_2460 = heff_tag_at_n(v_ru_24v1_2448_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2455, v_sp_2449})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_2449);
              v_t_2460 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_2448);
            }
            break;
          }
          case TAG_VCode: {
            v_t_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_2460 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          switch (heff_tag_of(v_t_2460)) {
          case TAG_Nothing: {
            V v_t_2473;
            switch (heff_tag_of(v_x_249)) {
            case TAG_VNeu: {
              V v_v1_2461 = heff_dup(heff_field(v_x_249, 0));
              switch (heff_tag_of(v_v1_2461)) {
              case TAG_HLocal: {
                V v_ru_24v1_2461_24HLocal = heff_take_reuse_n(v_v1_2461, 0ULL, 1);
                v_t_2473 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2461_24HLocal, heff_dup(v_x_249)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_2461_24HGlobal = heff_take_reuse_n(v_v1_2461, 0ULL, 1);
                v_t_2473 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2461_24HGlobal, heff_dup(v_x_249)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2461, 0ULL, 1);
                v_t_2473 = heff_dup(v_x_249);
                break;
              }
              case TAG_HError: {
                v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
                break;
              }
              default: heff_nomatch(v_v1_2461);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
              break;
            }
            case TAG_VLam: {
              v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
              break;
            }
            case TAG_VCons: {
              v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2473 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_249)));
              break;
            }
            default: heff_nomatch(v_x_249);
            }
            V v_t_2486;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_2474 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_2474)) {
              case TAG_HLocal: {
                V v_ru_24v1_2474_24HLocal = heff_take_reuse_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2474_24HLocal, heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_2474_24HGlobal = heff_take_reuse_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2474_24HGlobal, heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_2474);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            return (g_heff_2eelab_2eunify_2euElRigid_24s1347115405x609100695(v_g_240, v_cs_241, v_t_2473, v_t_2486, v_x_249, v_x_2413, v_hd_244, v_k_245));
          }
          case TAG_Just: {
            V v_it1_2487 = heff_field(v_t_2460, 0);
            heff_take_n(v_t_2460, 1ULL, 1);
            switch (heff_tag_of(v_it1_2487)) {
            case TAG_MkPair: {
              V v_m_2488 = heff_field(v_it1_2487, 0);
              V v_sp_2489 = heff_field(v_it1_2487, 1);
              heff_take_n(v_it1_2487, 3ULL, 2);
              return (g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(v_g_240, v_cs_241, v_m_2488, v_sp_2489, v_x_249, v_x_2413, v_hd_244, v_k_245));
            }
            default: return heff_nomatch(v_it1_2487);
            }
          }
          default: return heff_nomatch(v_t_2460);
          }
        }
        case TAG_Just: {
          V v_it1_2490 = heff_field(v_t_2447, 0);
          heff_take_n(v_t_2447, 1ULL, 1);
          switch (heff_tag_of(v_it1_2490)) {
          case TAG_MkPair: {
            V v_m_2491 = heff_field(v_it1_2490, 0);
            V v_sp_2492 = heff_field(v_it1_2490, 1);
            heff_take_n(v_it1_2490, 3ULL, 2);
            return (g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(v_g_240, v_cs_241, v_m_2491, v_sp_2492, v_x_2413, v_x_249, v_hd_244, v_k_245));
          }
          default: return heff_nomatch(v_it1_2490);
          }
        }
        default: return heff_nomatch(v_t_2447);
        }
      }
      }
    }
    }
  }
}
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_lam3, 1, 5, (V[]){v_x_249, v_hd_244, v_cs_241, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 9); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4(V self, V *args) {
  V v_c_2460 = args[0];
  return heff_get_n(v_c_2460, 3, 9);
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7(V self, V *args) {
  V v_c_2470 = args[0];
  return heff_get_n(v_c_2470, 3, 9);
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam8(V self, V *args) {
  V v_x_2473 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  HeffT3 v_t_2474 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2473));
  {
    V v_field_2476 = v_t_2474.f[1];
    heff_drop(v_t_2474.f[0]);
    heff_drop(v_t_2474.f[2]);
    heff_clo_take(self, 4);
    V v_t_2478 = heff_tr(heff_call(v_field_2476, 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2413}));
    return ({ V a_0 = v_t_2478; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2478); r_; });
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam6(V self, V *args) {
  V v_x_2469 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_drop(v_x_2469);
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam7_clo)})});
  V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2471}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2472;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam8, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  HeffT3 v_t_2464 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2463));
  {
    V v_field_2466 = v_t_2464.f[1];
    heff_drop(v_t_2464.f[0]);
    heff_drop(v_t_2464.f[2]);
    heff_clo_take(self, 5);
    V v_t_2468 = heff_tr(heff_call(v_field_2466, 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_249}));
    return ({ V a_0 = v_t_2468; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2413, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2468); r_; });
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_t_2436;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2459;
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_t_2436);
    v_t_2459 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2436);
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2438 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2438)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2459 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2438);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
  }
  if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_t_2459);
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam4_clo)})});
    V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2461}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2462;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam5, 1, 5, (V[]){v_cs_241, v_x_249, v_hd_244, v_x_2413, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2459);
    V v_t_24101;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2480 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2481 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_t1_2480)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2480, 0ULL, 1);
        heff_drop(v_sp_2481);
        v_t_24101 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2480, 0ULL, 1);
        heff_drop(v_sp_2481);
        v_t_24101 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2487 = heff_field(v_t1_2480, 0);
        V v_ru_24t1_2480_24HMeta = heff_take_reuse_n(v_t1_2480, 1ULL, 1);
        v_t_24101 = heff_tag_at_n(v_ru_24t1_2480_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2487, v_sp_2481})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2481);
        v_t_24101 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t1_2480);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_t_24101)) {
    case TAG_Nothing: {
      V v_t_24124;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24103 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_24104 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_t1_24103)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24103, 0ULL, 1);
          heff_drop(v_sp_24104);
          v_t_24124 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24103, 0ULL, 1);
          heff_drop(v_sp_24104);
          v_t_24124 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_24110 = heff_field(v_t1_24103, 0);
          V v_ru_24t1_24103_24HMeta = heff_take_reuse_n(v_t1_24103, 1ULL, 1);
          v_t_24124 = heff_tag_at_n(v_ru_24t1_24103_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24110, v_sp_24104})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_24104);
          v_t_24124 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_24103);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_t_24124)) {
      case TAG_Nothing: {
        return (g_heff_2eelab_2eunify_2euTyRigid_24s520220514x1355525634(v_g_240, v_cs_241, v_x_249, v_x_2413, v_hd_244, v_k_245));
      }
      case TAG_Just: {
        V v_it1_24125 = heff_field(v_t_24124, 0);
        V v_ru_24t_24124_24Just = heff_take_reuse_n(v_t_24124, 1ULL, 1);
        switch (heff_tag_of(v_it1_24125)) {
        case TAG_MkPair: {
          V v_m_24126 = heff_field(v_it1_24125, 0);
          V v_sp_24127 = heff_field(v_it1_24125, 1);
          heff_take_n(v_it1_24125, 3ULL, 2);
          V v_rhs_24147;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24133 = heff_field(v_x_249, 4);
            heff_take_n(v_x_249, 16ULL, 5);
            heff_drop_cell(v_ru_24t_24124_24Just, 1);
            v_rhs_24147 = heff_tr(heff_call(v_el_24133, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimRune: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24167;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24153 = heff_field(v_x_2413, 4);
            heff_take_n(v_x_2413, 16ULL, 5);
            v_self_24167 = heff_tr(heff_call(v_el_24153, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimRune: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VFixed: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return (g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(v_g_240, v_cs_241, v_m_24126, v_sp_24127, v_rhs_24147, v_self_24167, v_hd_244, v_k_245));
        }
        default: return heff_nomatch(v_it1_24125);
        }
      }
      default: return heff_nomatch(v_t_24124);
      }
    }
    case TAG_Just: {
      V v_it1_24168 = heff_field(v_t_24101, 0);
      V v_ru_24t_24101_24Just = heff_take_reuse_n(v_t_24101, 1ULL, 1);
      switch (heff_tag_of(v_it1_24168)) {
      case TAG_MkPair: {
        V v_m_24169 = heff_field(v_it1_24168, 0);
        V v_sp_24170 = heff_field(v_it1_24168, 1);
        heff_take_n(v_it1_24168, 3ULL, 2);
        V v_rhs_24190;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24176 = heff_field(v_x_2413, 4);
          heff_take_n(v_x_2413, 16ULL, 5);
          heff_drop_cell(v_ru_24t_24101_24Just, 1);
          v_rhs_24190 = heff_tr(heff_call(v_el_24176, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimRune: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24210;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24196 = heff_field(v_x_249, 4);
          heff_take_n(v_x_249, 16ULL, 5);
          v_self_24210 = heff_tr(heff_call(v_el_24196, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimRune: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VFixed: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return (g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(v_g_240, v_cs_241, v_m_24169, v_sp_24170, v_rhs_24190, v_self_24210, v_hd_244, v_k_245));
      }
      default: return heff_nomatch(v_it1_24168);
      }
    }
    default: return heff_nomatch(v_t_24101);
    }
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_lam3, 1, 5, (V[]){v_x_249, v_hd_244, v_cs_241, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam21(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam20(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam19(V self, V *args);
Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry, 6, 0};

V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0_clo);
  } else {
    heff_drop(v_t_2418);
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2eelab_2econversion_2eeqHead(v_h_242, v_h_27_244));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1_clo);
        } else {
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam2, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
        }
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam3, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam4, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam5, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2455 = heff_field(v_sp_243, 0);
      V v_v_2456 = heff_field(v_sp_243, 1);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam6, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpApp: {
        V v_sq_27_2463 = heff_field(v_sp_27_245, 0);
        V v_v_27_2464 = heff_field(v_sp_27_245, 1);
        V v_c_2465 = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(v_g_240, v_cs_241, v_h_242, v_sq_2455, v_h_27_244, v_sq_27_2463));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam7, 2, 5, (V[]){v_c_2465, heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_v_2456), heff_dup(v_v_27_2464)});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam9, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam10, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2486 = heff_field(v_sp_243, 0);
      V v_x_2487 = heff_field(v_sp_243, 1);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam11, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam12, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpProj: {
        V v_sq_27_24102 = heff_field(v_sp_27_245, 0);
        V v_x_27_24103 = heff_field(v_sp_27_245, 1);
        V v_c_24104 = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(v_g_240, v_cs_241, v_h_242, v_sq_2486, v_h_27_244, v_sq_27_24102));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam13, 2, 8, (V[]){v_c_24104, heff_dup(v_x_2487), heff_dup(v_x_27_24103), heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam15, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24119 = heff_field(v_sp_243, 0);
      V v_x_24120 = heff_field(v_sp_243, 1);
      V v_v_24121 = heff_field(v_sp_243, 2);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam16, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam17, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam18, 2, 5, (V[]){heff_dup(v_cs_241), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      case TAG_SpSpec: {
        V v_sq_27_24144 = heff_field(v_sp_27_245, 0);
        V v_x_27_24145 = heff_field(v_sp_27_245, 1);
        V v_v_27_24146 = heff_field(v_sp_27_245, 2);
        V v_c_24147 = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(v_g_240, v_cs_241, v_h_242, v_sq_24119, v_h_27_244, v_sq_27_24144));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam19, 2, 11, (V[]){v_c_24147, heff_dup(v_x_24120), heff_dup(v_x_27_24145), heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_v_24121), heff_dup(v_v_27_24146), heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_h_27_244), heff_dup(v_sp_27_245)});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(a0, a1, a2, a3, a4, a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2426 = heff_take_field(v_hd_2424, 2);
  V v_bind_2427 = heff_get_n(v_hd_2424, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2428 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2429 = heff_tr(heff_call(v_malg_2426, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
  V f_ = v_bind_2427;
  args[0] = v_t_2429;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam3(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2434 = heff_take_field(v_hd_2432, 2);
  V v_bind_2435 = heff_get_n(v_hd_2432, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2436 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2437 = heff_tr(heff_call(v_malg_2434, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  V f_ = v_bind_2435;
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam4(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2442 = heff_take_field(v_hd_2440, 2);
  V v_bind_2443 = heff_get_n(v_hd_2440, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2444 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2445 = heff_tr(heff_call(v_malg_2442, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})}));
  V f_ = v_bind_2443;
  args[0] = v_t_2445;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam5(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2451 = heff_take_field(v_hd_2449, 2);
  V v_bind_2452 = heff_get_n(v_hd_2449, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2453 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2454 = heff_tr(heff_call(v_malg_2451, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})}));
  V f_ = v_bind_2452;
  args[0] = v_t_2454;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam6(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2459 = heff_take_field(v_hd_2457, 2);
  V v_bind_2460 = heff_get_n(v_hd_2457, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2461 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2462 = heff_tr(heff_call(v_malg_2459, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})}));
  V f_ = v_bind_2460;
  args[0] = v_t_2462;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam8(V self, V *args) {
  V v_x_2468 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2456 = heff_env(self)[2];
  V v_v_27_2464 = heff_env(self)[3];
  V v_hd_2466 = heff_env(self)[4];
  V v_k_2467 = heff_env(self)[5];
  heff_drop(v_x_2468);
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(v_g_240, v_cs_241, v_v_2456, v_v_27_2464, v_hd_2466, v_k_2467));
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam7(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2456 = heff_env(self)[3];
  V v_v_27_2464 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2465;
  args[0] = heff_dup(v_hd_2466);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2456, v_v_27_2464, v_hd_2466, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam9(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k2_2472 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2473 = heff_take_field(v_hd_2471, 2);
  V v_bind_2474 = heff_get_n(v_hd_2471, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2475 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2476 = heff_tr(heff_call(v_malg_2473, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})}));
  V f_ = v_bind_2474;
  args[0] = v_t_2476;
  args[1] = v_k2_2472;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam10(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k2_2481 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2482 = heff_take_field(v_hd_2480, 2);
  V v_bind_2483 = heff_get_n(v_hd_2480, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2484 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2485 = heff_tr(heff_call(v_malg_2482, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})}));
  V f_ = v_bind_2483;
  args[0] = v_t_2485;
  args[1] = v_k2_2481;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam11(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k2_2489 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2490 = heff_take_field(v_hd_2488, 2);
  V v_bind_2491 = heff_get_n(v_hd_2488, 1, 3);
  heff_clo_take(self, 5);
  V v_t_2492 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2493 = heff_tr(heff_call(v_malg_2490, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})}));
  V f_ = v_bind_2491;
  args[0] = v_t_2493;
  args[1] = v_k2_2489;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam12(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k2_2497 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_2498 = heff_take_field(v_hd_2496, 2);
  V v_bind_2499 = heff_get_n(v_hd_2496, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24100 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24101 = heff_tr(heff_call(v_malg_2498, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})}));
  V f_ = v_bind_2499;
  args[0] = v_t_24101;
  args[1] = v_k2_2497;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam14(V self, V *args) {
  V v_x_24107 = args[0];
  V v_x_2487 = heff_env(self)[0];
  V v_x_27_24103 = heff_env(self)[1];
  V v_k_24106 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_24105 = heff_env(self)[8];
  heff_drop(v_x_24107);
  heff_clo_take(self, 9);
  if (heff_strEq_c(v_x_2487, v_x_27_24103)) {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop_rec(v_hd_24105, 3);
    V f_ = v_k_24106;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_24108 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_24109 = heff_tr(heff_call(heff_take_field(v_hd_24105, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})}));
    V f_ = heff_get_n(v_hd_24105, 1, 3);
    heff_room[0] = v_t_24109;
    heff_room[1] = v_k_24106;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam13(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k_24106 = args[1];
  V v_c_24104 = heff_env(self)[0];
  V v_x_2487 = heff_env(self)[1];
  V v_x_27_24103 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_24104;
  args[0] = heff_dup(v_hd_24105);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam14, 1, 9, (V[]){v_x_2487, v_x_27_24103, v_k_24106, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24105});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam15(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k2_24114 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_24115 = heff_take_field(v_hd_24113, 2);
  V v_bind_24116 = heff_get_n(v_hd_24113, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24117 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24118 = heff_tr(heff_call(v_malg_24115, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24117})}));
  V f_ = v_bind_24116;
  args[0] = v_t_24118;
  args[1] = v_k2_24114;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam16(V self, V *args) {
  V v_hd_24122 = args[0];
  V v_k2_24123 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_24124 = heff_take_field(v_hd_24122, 2);
  V v_bind_24125 = heff_get_n(v_hd_24122, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24126 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24127 = heff_tr(heff_call(v_malg_24124, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24126})}));
  V f_ = v_bind_24125;
  args[0] = v_t_24127;
  args[1] = v_k2_24123;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam17(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k2_24131 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_24132 = heff_take_field(v_hd_24130, 2);
  V v_bind_24133 = heff_get_n(v_hd_24130, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24134 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24135 = heff_tr(heff_call(v_malg_24132, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24134})}));
  V f_ = v_bind_24133;
  args[0] = v_t_24135;
  args[1] = v_k2_24131;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam18(V self, V *args) {
  V v_hd_24138 = args[0];
  V v_k2_24139 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  V v_malg_24140 = heff_take_field(v_hd_24138, 2);
  V v_bind_24141 = heff_get_n(v_hd_24138, 1, 3);
  heff_clo_take(self, 5);
  V v_t_24142 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24143 = heff_tr(heff_call(v_malg_24140, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24142})}));
  V f_ = v_bind_24141;
  args[0] = v_t_24143;
  args[1] = v_k2_24139;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam21(V self, V *args) {
  V v_x_24153 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_24121 = heff_env(self)[2];
  V v_v_27_24146 = heff_env(self)[3];
  V v_hd_24148 = heff_env(self)[4];
  V v_k_24149 = heff_env(self)[5];
  heff_drop(v_x_24153);
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(v_g_240, v_cs_241, v_v_24121, v_v_27_24146, v_hd_24148, v_k_24149));
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam20(V self, V *args) {
  V v_x_24150 = args[0];
  V v_x_24120 = heff_env(self)[0];
  V v_x_27_24145 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_v_24121 = heff_env(self)[4];
  V v_v_27_24146 = heff_env(self)[5];
  V v_hd_24148 = heff_env(self)[6];
  V v_k_24149 = heff_env(self)[7];
  V v_h_242 = heff_env(self)[8];
  V v_sp_243 = heff_env(self)[9];
  V v_h_27_244 = heff_env(self)[10];
  V v_sp_27_245 = heff_env(self)[11];
  heff_drop(v_x_24150);
  heff_clo_take(self, 12);
  if (heff_strEq_c(v_x_24120, v_x_27_24145)) {
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    return (g_heff_2eelab_2eunify_2euTermF_24s1290192612x227043031(v_g_240, v_cs_241, v_v_24121, v_v_27_24146, v_hd_24148, v_k_24149));
  } else {
    V v_t_24151 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_24152 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24148, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24151})}));
    V f_ = heff_dup(heff_rfield(v_hd_24148, 1));
    heff_room[0] = v_t_24152;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam21, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24121, v_v_27_24146, v_hd_24148, v_k_24149});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam19(V self, V *args) {
  V v_hd_24148 = args[0];
  V v_k_24149 = args[1];
  V v_c_24147 = heff_env(self)[0];
  V v_x_24120 = heff_env(self)[1];
  V v_x_27_24145 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_v_24121 = heff_env(self)[5];
  V v_v_27_24146 = heff_env(self)[6];
  V v_h_242 = heff_env(self)[7];
  V v_sp_243 = heff_env(self)[8];
  V v_h_27_244 = heff_env(self)[9];
  V v_sp_27_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_24147;
  args[0] = heff_dup(v_hd_24148);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_lam20, 1, 12, (V[]){v_x_24120, v_x_27_24145, v_g_240, v_cs_241, v_v_24121, v_v_27_24146, v_hd_24148, v_k_24149, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam0, 1, 1, (V[]){v_a0_242})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})});
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2410, 3, 9); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4(V self, V *args) {
  V v_c_2460 = args[0];
  return heff_get_n(v_c_2460, 3, 9);
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7(V self, V *args) {
  V v_c_2470 = args[0];
  return heff_get_n(v_c_2470, 3, 9);
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam8(V self, V *args) {
  V v_x_2473 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  HeffT3 v_t_2474 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2473));
  {
    V v_field_2476 = v_t_2474.f[1];
    heff_drop(v_t_2474.f[0]);
    heff_drop(v_t_2474.f[2]);
    heff_clo_take(self, 4);
    V v_t_2478 = heff_tr(heff_call(v_field_2476, 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2413}));
    return ({ V a_0 = v_t_2478; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2478); r_; });
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam6(V self, V *args) {
  V v_x_2469 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_drop(v_x_2469);
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam7_clo)})});
  V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2471}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2472;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam8, 1, 4, (V[]){v_cs_241, v_x_2413, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  HeffT3 v_t_2464 = (g_heff_2eelab_2eunify_2emetasK_24cpr(v_x_2463));
  {
    V v_field_2466 = v_t_2464.f[1];
    heff_drop(v_t_2464.f[0]);
    heff_drop(v_t_2464.f[2]);
    heff_clo_take(self, 5);
    V v_t_2468 = heff_tr(heff_call(v_field_2466, 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_249}));
    return ({ V a_0 = v_t_2468; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2413, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s229028905x1017169112(a_0, a_1, a_2)); heff_drop(v_t_2468); r_; });
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_t_2436;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2415 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2415)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2415, 0ULL, 1);
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2415);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2436 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V v_t_2459;
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_t_2436);
    v_t_2459 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2436);
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VU: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2438 = heff_dup(heff_field(v_x_2413, 0));
      switch (heff_tag_of(v_h_2438)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2438, 0ULL, 1);
        v_t_2459 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2459 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2438);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
  }
  if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_t_2459);
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam4_clo)})});
    V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2461}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2462;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam5, 1, 5, (V[]){v_cs_241, v_x_249, v_hd_244, v_x_2413, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_2459);
    V v_t_24101;
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2480 = heff_dup(heff_field(v_x_249, 0));
      V v_sp_2481 = heff_dup(heff_field(v_x_249, 1));
      switch (heff_tag_of(v_t1_2480)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2480, 0ULL, 1);
        heff_drop(v_sp_2481);
        v_t_24101 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2480, 0ULL, 1);
        heff_drop(v_sp_2481);
        v_t_24101 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2487 = heff_field(v_t1_2480, 0);
        V v_ru_24t1_2480_24HMeta = heff_take_reuse_n(v_t1_2480, 1ULL, 1);
        v_t_24101 = heff_tag_at_n(v_ru_24t1_2480_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2487, v_sp_2481})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2481);
        v_t_24101 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t1_2480);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    switch (heff_tag_of(v_t_24101)) {
    case TAG_Nothing: {
      V v_t_24124;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24103 = heff_dup(heff_field(v_x_2413, 0));
        V v_sp_24104 = heff_dup(heff_field(v_x_2413, 1));
        switch (heff_tag_of(v_t1_24103)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24103, 0ULL, 1);
          heff_drop(v_sp_24104);
          v_t_24124 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24103, 0ULL, 1);
          heff_drop(v_sp_24104);
          v_t_24124 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_24110 = heff_field(v_t1_24103, 0);
          V v_ru_24t1_24103_24HMeta = heff_take_reuse_n(v_t1_24103, 1ULL, 1);
          v_t_24124 = heff_tag_at_n(v_ru_24t1_24103_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24110, v_sp_24104})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_24104);
          v_t_24124 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_24103);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_24124 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      switch (heff_tag_of(v_t_24124)) {
      case TAG_Nothing: {
        return (g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(v_g_240, v_cs_241, v_x_249, v_x_2413, v_hd_244, v_k_245));
      }
      case TAG_Just: {
        V v_it1_24125 = heff_field(v_t_24124, 0);
        V v_ru_24t_24124_24Just = heff_take_reuse_n(v_t_24124, 1ULL, 1);
        switch (heff_tag_of(v_it1_24125)) {
        case TAG_MkPair: {
          V v_m_24126 = heff_field(v_it1_24125, 0);
          V v_sp_24127 = heff_field(v_it1_24125, 1);
          heff_take_n(v_it1_24125, 3ULL, 2);
          V v_rhs_24147;
          switch (heff_tag_of(v_x_249)) {
          case TAG_VU: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VDecode: {
            V v_el_24133 = heff_field(v_x_249, 4);
            heff_take_n(v_x_249, 16ULL, 5);
            heff_drop_cell(v_ru_24t_24124_24Just, 1);
            v_rhs_24147 = heff_tr(heff_call(v_el_24133, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VSum: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimRune: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24147 = heff_tag_at_n(v_ru_24t_24124_24Just, TAG_VCode, 1, (V[]){v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_self_24167;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_VU: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VDecode: {
            V v_el_24153 = heff_field(v_x_2413, 4);
            heff_take_n(v_x_2413, 16ULL, 5);
            v_self_24167 = heff_tr(heff_call(v_el_24153, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VRecord: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VSum: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimString: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimRune: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          case TAG_VFixed: {
            v_self_24167 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2413});
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          return (g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(v_g_240, v_cs_241, v_m_24126, v_sp_24127, v_rhs_24147, v_self_24167, v_hd_244, v_k_245));
        }
        default: return heff_nomatch(v_it1_24125);
        }
      }
      default: return heff_nomatch(v_t_24124);
      }
    }
    case TAG_Just: {
      V v_it1_24168 = heff_field(v_t_24101, 0);
      V v_ru_24t_24101_24Just = heff_take_reuse_n(v_t_24101, 1ULL, 1);
      switch (heff_tag_of(v_it1_24168)) {
      case TAG_MkPair: {
        V v_m_24169 = heff_field(v_it1_24168, 0);
        V v_sp_24170 = heff_field(v_it1_24168, 1);
        heff_take_n(v_it1_24168, 3ULL, 2);
        V v_rhs_24190;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VU: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VDecode: {
          V v_el_24176 = heff_field(v_x_2413, 4);
          heff_take_n(v_x_2413, 16ULL, 5);
          heff_drop_cell(v_ru_24t_24101_24Just, 1);
          v_rhs_24190 = heff_tr(heff_call(v_el_24176, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VSum: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimRune: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24190 = heff_tag_at_n(v_ru_24t_24101_24Just, TAG_VCode, 1, (V[]){v_x_2413});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        V v_self_24210;
        switch (heff_tag_of(v_x_249)) {
        case TAG_VU: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VDecode: {
          V v_el_24196 = heff_field(v_x_249, 4);
          heff_take_n(v_x_249, 16ULL, 5);
          v_self_24210 = heff_tr(heff_call(v_el_24196, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VRecord: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VSum: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimString: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimRune: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        case TAG_VFixed: {
          v_self_24210 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        return (g_heff_2eelab_2eunify_2esolveF_24s676285224x1270493577(v_g_240, v_cs_241, v_m_24169, v_sp_24170, v_rhs_24190, v_self_24210, v_hd_244, v_k_245));
      }
      default: return heff_nomatch(v_it1_24168);
      }
    }
    default: return heff_nomatch(v_t_24101);
    }
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam2, 1, 1, (V[]){v_b0_243})})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_lam3, 1, 5, (V[]){v_x_249, v_hd_244, v_cs_241, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2eunify_2eappendL_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_24tok2_entry, 3, 0};

V g_heff_2eelab_2eunify_2eappendL_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = ({ V a_0 = v_xs_244; V a_1 = v_ys_242; V a_2 = v_cell_245; V r_ = (g_heff_2eelab_2eunify_2eappendL_24dps(a_0, a_1, a_2)); heff_drop(v_ys_242); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eunify_2eappendL_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL_24tok2(a[0], a[1], a[2]);
}