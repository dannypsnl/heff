// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BocGiven 26228
#define TAG_BocNew 29139
#define TAG_BocTaken 53948
#define TAG_BocWhen 59622
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_PerformAt 64592
#define LBL_body 9524841
#define LBL_directArms 1189396761
#define LBL_directCond 1189453476
#define LBL_directE 1902362554
#define LBL_directFields 683579375
#define LBL_directList 1189716000
#define LBL_key 315609
#define LBL_name 9869138
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
V g_heff_2ecompile_2edirect_2eapplied(V, V);
V g_heff_2ecompile_2edirect_2eapplied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2eapplied_clo;
V g_heff_2ecompile_2edirect_2edirectArms_23mutual(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectArms_23mutual_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectArms_23mutual_clo;
HeffT2 g_heff_2ecompile_2edirect_2edirectBoc_24cpr(V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectDefs(V, V, V);
V g_heff_2ecompile_2edirect_2edirectDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectDefs_clo;
HeffT2 g_heff_2ecompile_2edirect_2edirectDefs_24cpr(V, V, V);
V g_heff_2ecompile_2edirect_2edirectE_23mutual(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectE_23mutual_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectE_23mutual_clo;
HeffT2 g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1875922425x917980391_24cpr(V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectList_23mutual(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2edirectList_23mutual_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2edirectList_23mutual_clo;
HeffT2 g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24dps_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2edirect_2emoduleAt(V, V);
V g_heff_2ecompile_2edirect_2emoduleAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2emoduleAt_clo;
V g_heff_2ecompile_2edirect_2emutual_23directList_get(void);
HeffT3 g_heff_2ecompile_2edirect_2eopened_24cpr(V);
V g_heff_2ecompile_2edirect_2evalueOf(V, V);
V g_heff_2ecompile_2edirect_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edirect_2evalueOf_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_heff_2ecompile_2edirect_2eapplied_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2eapplied_entry, 2, 0};

V g_heff_2ecompile_2edirect_2eapplied(V v_f_240, V v_a_241) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_ELam: {
    V v_f1_242 = heff_dup(heff_field(v_f_240, 0));
    V v_b_243 = heff_dup(heff_field(v_f_240, 1));
    switch (heff_tag_of(v_f1_242)) {
    case TAG_Nil: {
      heff_drop(v_b_243);
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_241, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_t_244});
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_f1_242, 0);
      V v_f12_246 = heff_field(v_f1_242, 1);
      V v_ru_24f1_242_24Cons = heff_take_reuse_n(v_f1_242, 3ULL, 2);
      switch (heff_tag_of(v_f12_246)) {
      case TAG_Nil: {
        heff_drop_tag(v_f_240, 2);
        heff_drop_cell(v_ru_24f1_242_24Cons, 2);
        return heff_tag_n(TAG_ELet, 3, (V[]){v_x_245, v_a_241, v_b_243});
      }
      case TAG_Cons: {
        V v_ru_24f12_246_24Cons = heff_take_reuse_n(v_f12_246, 0ULL, 2);
        heff_drop(v_b_243);
        heff_drop(v_x_245);
        V v_t_249 = heff_tag_at_n(v_ru_24f1_242_24Cons, TAG_Cons, 2, (V[]){v_a_241, NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24f12_246_24Cons, TAG_EApp, 2, (V[]){v_f_240, v_t_249});
      }
      default: return heff_nomatch(v_f12_246);
      }
    }
    default: return heff_nomatch(v_f1_242);
    }
  }
  default: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_241, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_t_2410});
  }
  }
}
V g_heff_2ecompile_2edirect_2eapplied_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edirect_2eapplied(a[0], a[1]);
}

HeffT3 g_heff_2ecompile_2edirect_2eopened_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nil: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_u_245 = heff_field(v_x11_243, 0);
      V v_x112_246 = heff_field(v_x11_243, 1);
      switch (heff_tag_of(v_x112_246)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_244)) {
        case TAG_EVar: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EGlobal: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_ELam: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EApp: {
          V v_x121_2411 = heff_field(v_x12_244, 0);
          V v_x122_2412 = heff_field(v_x12_244, 1);
          switch (heff_tag_of(v_x121_2411)) {
          case TAG_EVar: {
            V v_u2_2413 = heff_field(v_x121_2411, 0);
            switch (heff_tag_of(v_x122_2412)) {
            case TAG_Nil: {
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            case TAG_Cons: {
              V v_x1221_2414 = heff_field(v_x122_2412, 0);
              V v_x1222_2415 = heff_field(v_x122_2412, 1);
              switch (heff_tag_of(v_x1221_2414)) {
              case TAG_EVar: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EGlobal: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_ELam: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EApp: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_ELet: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_ERecord: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EProj: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_ETag: {
                V v_t_2431 = heff_field(v_x1221_2414, 0);
                V v_fs_2432 = heff_field(v_x1221_2414, 1);
                switch (heff_tag_of(v_x1222_2415)) {
                case TAG_Nil: {
                  if (heff_strEq_c_lent(v_u_245, v_u2_2413, 0)) {
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_t_2431), heff_dup(v_fs_2432)}});
                  } else {
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
                case TAG_Cons: {
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
                default: return ((HeffT3){{heff_nomatch(v_x1222_2415)}});
                }
              }
              case TAG_EMatch: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EPrim: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EPrimCall: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_ECall: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EInt: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EFloat: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EStr: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EBytes: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EFixed: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EFloat32: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EAbandon: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EBool: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_ESet: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EValues: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_EFix: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              default: return ((HeffT3){{heff_nomatch(v_x1221_2414)}});
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_x122_2412)}});
            }
          }
          case TAG_EGlobal: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_ELam: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EApp: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_ELet: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_ERecord: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EProj: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_ETag: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EMatch: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EPrim: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EPrimCall: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_ECall: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EInt: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EFloat: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EStr: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EBytes: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EFixed: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EFloat32: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EAbandon: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EBool: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_ESet: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EValues: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_EFix: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          default: return ((HeffT3){{heff_nomatch(v_x121_2411)}});
          }
        }
        case TAG_ELet: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_ERecord: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EProj: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_ETag: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EMatch: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EPrim: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EPrimCall: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_ECall: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EInt: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EFloat: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EStr: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EBytes: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EFixed: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EFloat32: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EAbandon: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EBool: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_ESet: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EValues: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_EFix: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        default: return ((HeffT3){{heff_nomatch(v_x12_244)}});
        }
      }
      case TAG_Cons: {
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      default: return ((HeffT3){{heff_nomatch(v_x112_246)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x11_243)}});
    }
  }
  case TAG_EApp: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str0, 4, "When");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str1, 11, "MkBehaviour");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str2, 7, "NewCown");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str3, 9, "MkCowning");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str4, 5, "Taken");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str5, 8, "MkTaking");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str6, 5, "Given");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str7, 8, "MkGiving");

HeffT2 g_heff_2ecompile_2edirect_2edirectBoc_24cpr(V v_kn_240, V v_u_241, V v_p_242, V v_k_243) {
top: ;
  switch (heff_tag_of(v_p_242)) {
  case TAG_EVar: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_p_242, 0ULL, 2);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_p_242, 0ULL, 2);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_p_242, 0ULL, 3);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_p_242, 0ULL, 2);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_p_242, 0ULL, 4);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    V v_t_2419 = heff_field(v_p_242, 0);
    V v_fs_2420 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24ETag = heff_take_reuse_n(v_p_242, 3ULL, 3);
    if (heff_strEq_c_lent(v_t_2419, ((V)&g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str0), 2)) {
      heff_drop(v_t_2419);
      switch (heff_tag_of(v_fs_2420)) {
      case TAG_Nil: {
        heff_drop(v_u_241);
        heff_drop(v_k_243);
        heff_drop_cell(v_ru_24p_242_24ETag, 3);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_s_2422 = heff_field(v_fs_2420, 0);
        V v_it2_2423 = heff_field(v_fs_2420, 1);
        V v_ru_24fs_2420_24Cons = heff_take_reuse_n(v_fs_2420, 3ULL, 2);
        switch (heff_tag_of(v_it2_2423)) {
        case TAG_Nil: {
          heff_drop(v_u_241);
          heff_drop(v_k_243);
          heff_drop_cell(v_ru_24p_242_24ETag, 3);
          heff_drop(v_s_2422);
          heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_b_2424 = heff_field(v_it2_2423, 0);
          V v_it22_2425 = heff_field(v_it2_2423, 1);
          V v_ru_24it2_2423_24Cons = heff_take_reuse_n(v_it2_2423, 3ULL, 2);
          switch (heff_tag_of(v_it22_2425)) {
          case TAG_Nil: {
            heff_drop(v_u_241);
            heff_drop(v_k_243);
            heff_drop_cell(v_ru_24p_242_24ETag, 3);
            heff_drop(v_s_2422);
            heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
            heff_drop(v_b_2424);
            heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Cons: {
            V v_x_2426 = heff_field(v_it22_2425, 0);
            V v_it222_2427 = heff_field(v_it22_2425, 1);
            V v_ru_24it22_2425_24Cons = heff_take_reuse_n(v_it22_2425, 3ULL, 2);
            switch (heff_tag_of(v_it222_2427)) {
            case TAG_Nil: {
              V v_t_2428 = (g_heff_2ecompile_2edirect_2evalueOf(v_kn_240, v_s_2422));
              HeffT3 v_t_2429 = ({ V a_0 = v_t_2428; HeffT3 r_ = (g_heff_2ecompile_2edirect_2eopened_24cpr(a_0)); heff_drop(v_t_2428); r_; });
              {
                V v_field_2431 = v_t_2429.f[1];
                V v_field_2432 = v_t_2429.f[2];
                int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                if ((v_tag_2430 == ((int64_t)0ULL))) {
                  V v_t2_2433 = v_field_2431;
                  V v_fs_2434 = v_field_2432;
                  if (heff_strEq_c(((V)&g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str1), v_t2_2433)) {
                    switch (heff_tag_of(v_fs_2434)) {
                    case TAG_Nil: {
                      heff_drop(v_u_241);
                      heff_drop(v_k_243);
                      heff_drop_cell(v_ru_24p_242_24ETag, 3);
                      heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                      heff_drop(v_b_2424);
                      heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
                      heff_drop(v_x_2426);
                      heff_drop_cell(v_ru_24it22_2425_24Cons, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Cons: {
                      V v_cs_2435 = heff_field(v_fs_2434, 0);
                      V v_it12_2436 = heff_field(v_fs_2434, 1);
                      V v_ru_24fs_2434_24Cons = heff_take_reuse_n(v_fs_2434, 3ULL, 2);
                      switch (heff_tag_of(v_it12_2436)) {
                      case TAG_Nil: {
                        heff_drop(v_u_241);
                        heff_drop(v_k_243);
                        heff_drop_cell(v_ru_24p_242_24ETag, 3);
                        heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                        heff_drop(v_b_2424);
                        heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
                        heff_drop(v_x_2426);
                        heff_drop_cell(v_ru_24it22_2425_24Cons, 2);
                        heff_drop(v_cs_2435);
                        heff_drop_cell(v_ru_24fs_2434_24Cons, 2);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Cons: {
                        V v_ok_2437 = heff_field(v_it12_2436, 0);
                        V v_it122_2438 = heff_field(v_it12_2436, 1);
                        V v_ru_24it12_2436_24Cons = heff_take_reuse_n(v_it12_2436, 3ULL, 2);
                        switch (heff_tag_of(v_it122_2438)) {
                        case TAG_Nil: {
                          heff_drop(v_u_241);
                          heff_drop(v_k_243);
                          heff_drop_cell(v_ru_24p_242_24ETag, 3);
                          heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                          heff_drop(v_b_2424);
                          heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
                          heff_drop(v_x_2426);
                          heff_drop_cell(v_ru_24it22_2425_24Cons, 2);
                          heff_drop(v_cs_2435);
                          heff_drop_cell(v_ru_24fs_2434_24Cons, 2);
                          heff_drop(v_ok_2437);
                          heff_drop_cell(v_ru_24it12_2436_24Cons, 2);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Cons: {
                          V v_ws_2439 = heff_field(v_it122_2438, 0);
                          V v_it1222_2440 = heff_field(v_it122_2438, 1);
                          V v_ru_24it122_2438_24Cons = heff_take_reuse_n(v_it122_2438, 3ULL, 2);
                          switch (heff_tag_of(v_it1222_2440)) {
                          case TAG_Nil: {
                            heff_drop(v_u_241);
                            heff_drop(v_k_243);
                            heff_drop_cell(v_ru_24p_242_24ETag, 3);
                            heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                            heff_drop(v_b_2424);
                            heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
                            heff_drop(v_x_2426);
                            heff_drop_cell(v_ru_24it22_2425_24Cons, 2);
                            heff_drop(v_cs_2435);
                            heff_drop_cell(v_ru_24fs_2434_24Cons, 2);
                            heff_drop(v_ok_2437);
                            heff_drop_cell(v_ru_24it12_2436_24Cons, 2);
                            heff_drop(v_ws_2439);
                            heff_drop_cell(v_ru_24it122_2438_24Cons, 2);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Cons: {
                            V v_rs_2441 = heff_field(v_it1222_2440, 0);
                            V v_it12222_2442 = heff_field(v_it1222_2440, 1);
                            V v_ru_24it1222_2440_24Cons = heff_take_reuse_n(v_it1222_2440, 3ULL, 2);
                            switch (heff_tag_of(v_it12222_2442)) {
                            case TAG_Nil: {
                              V v_t_2452;
                              switch (heff_tag_of(v_k_243)) {
                              case TAG_ELam: {
                                V v_f1_2443 = heff_dup(heff_field(v_k_243, 0));
                                V v_b_2444 = heff_dup(heff_field(v_k_243, 1));
                                switch (heff_tag_of(v_f1_2443)) {
                                case TAG_Nil: {
                                  heff_drop_cell(v_ru_24p_242_24ETag, 3);
                                  heff_drop(v_b_2444);
                                  V v_t_2445 = heff_tag_at_n(v_ru_24fs_2420_24Cons, TAG_Cons, 2, (V[]){v_x_2426, NTAG(TAG_Nil)});
                                  v_t_2452 = heff_tag_at_n(v_ru_24it1222_2440_24Cons, TAG_EApp, 2, (V[]){v_k_243, v_t_2445});
                                  break;
                                }
                                case TAG_Cons: {
                                  V v_x_2446 = heff_field(v_f1_2443, 0);
                                  V v_f12_2447 = heff_field(v_f1_2443, 1);
                                  heff_take_n(v_f1_2443, 3ULL, 2);
                                  switch (heff_tag_of(v_f12_2447)) {
                                  case TAG_Nil: {
                                    heff_drop_tag(v_k_243, 2);
                                    heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                                    heff_drop_cell(v_ru_24it1222_2440_24Cons, 2);
                                    v_t_2452 = heff_tag_at_n(v_ru_24p_242_24ETag, TAG_ELet, 3, (V[]){v_x_2446, v_x_2426, v_b_2444});
                                    break;
                                  }
                                  case TAG_Cons: {
                                    heff_take_n(v_f12_2447, 0ULL, 2);
                                    heff_drop_cell(v_ru_24p_242_24ETag, 3);
                                    heff_drop(v_b_2444);
                                    heff_drop(v_x_2446);
                                    V v_t_2450 = heff_tag_at_n(v_ru_24fs_2420_24Cons, TAG_Cons, 2, (V[]){v_x_2426, NTAG(TAG_Nil)});
                                    v_t_2452 = heff_tag_at_n(v_ru_24it1222_2440_24Cons, TAG_EApp, 2, (V[]){v_k_243, v_t_2450});
                                    break;
                                  }
                                  default: heff_nomatch(v_f12_2447);
                                  }
                                  break;
                                }
                                default: heff_nomatch(v_f1_2443);
                                }
                                break;
                              }
                              default: {
                                heff_drop_cell(v_ru_24p_242_24ETag, 3);
                                V v_t_2451 = heff_tag_at_n(v_ru_24fs_2420_24Cons, TAG_Cons, 2, (V[]){v_x_2426, NTAG(TAG_Nil)});
                                v_t_2452 = heff_tag_at_n(v_ru_24it1222_2440_24Cons, TAG_EApp, 2, (V[]){v_k_243, v_t_2451});
                                break;
                              }
                              }
                              V v_t_2453 = heff_tag_at_n(v_ru_24it2_2423_24Cons, TAG_Cons, 2, (V[]){v_rs_2441, NTAG(TAG_Nil)});
                              V v_t_2454 = heff_tag_at_n(v_ru_24it22_2425_24Cons, TAG_Cons, 2, (V[]){v_ok_2437, heff_tag_at_n(v_ru_24fs_2434_24Cons, TAG_Cons, 2, (V[]){v_ws_2439, v_t_2453})});
                              V v_t_2455 = heff_tag_at_n(v_ru_24it12_2436_24Cons, TAG_Cons, 2, (V[]){v_cs_2435, heff_tag_at_n(v_ru_24it122_2438_24Cons, TAG_Cons, 2, (V[]){v_b_2424, v_t_2454})});
                              V v_t_2456 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_BocWhen), v_t_2455});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_ELet, 3, (V[]){v_u_241, v_t_2456, v_t_2452})}});
                            }
                            case TAG_Cons: {
                              heff_take_n(v_it12222_2442, 0ULL, 2);
                              heff_drop(v_u_241);
                              heff_drop(v_k_243);
                              heff_drop_cell(v_ru_24p_242_24ETag, 3);
                              heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                              heff_drop(v_b_2424);
                              heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
                              heff_drop(v_x_2426);
                              heff_drop_cell(v_ru_24it22_2425_24Cons, 2);
                              heff_drop(v_cs_2435);
                              heff_drop_cell(v_ru_24fs_2434_24Cons, 2);
                              heff_drop(v_ok_2437);
                              heff_drop_cell(v_ru_24it12_2436_24Cons, 2);
                              heff_drop(v_ws_2439);
                              heff_drop_cell(v_ru_24it122_2438_24Cons, 2);
                              heff_drop(v_rs_2441);
                              heff_drop_cell(v_ru_24it1222_2440_24Cons, 2);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_it12222_2442)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_it1222_2440)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_it122_2438)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_it12_2436)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_fs_2434)}});
                    }
                  } else {
                    heff_drop(v_u_241);
                    heff_drop(v_k_243);
                    heff_drop_cell(v_ru_24p_242_24ETag, 3);
                    heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                    heff_drop(v_b_2424);
                    heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
                    heff_drop(v_x_2426);
                    heff_drop_cell(v_ru_24it22_2425_24Cons, 2);
                    heff_drop(v_fs_2434);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                } else {
                  heff_drop(v_u_241);
                  heff_drop(v_k_243);
                  heff_drop_cell(v_ru_24p_242_24ETag, 3);
                  heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                  heff_drop(v_b_2424);
                  heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
                  heff_drop(v_x_2426);
                  heff_drop_cell(v_ru_24it22_2425_24Cons, 2);
                  heff_drop(v_field_2431);
                  heff_drop(v_field_2432);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            case TAG_Cons: {
              heff_take_n(v_it222_2427, 0ULL, 2);
              heff_drop(v_u_241);
              heff_drop(v_k_243);
              heff_drop_cell(v_ru_24p_242_24ETag, 3);
              heff_drop(v_s_2422);
              heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
              heff_drop(v_b_2424);
              heff_drop_cell(v_ru_24it2_2423_24Cons, 2);
              heff_drop(v_x_2426);
              heff_drop_cell(v_ru_24it22_2425_24Cons, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it222_2427)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it22_2425)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it2_2423)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_fs_2420)}});
      }
    } else {
      if (heff_strEq_c_lent(v_t_2419, ((V)&g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str2), 2)) {
        heff_drop(v_u_241);
        heff_drop(v_t_2419);
        heff_drop_cell(v_ru_24p_242_24ETag, 3);
        switch (heff_tag_of(v_fs_2420)) {
        case TAG_Nil: {
          heff_drop(v_k_243);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_s_2461 = heff_field(v_fs_2420, 0);
          V v_it2_2462 = heff_field(v_fs_2420, 1);
          V v_ru_24fs_2420_24Cons = heff_take_reuse_n(v_fs_2420, 3ULL, 2);
          switch (heff_tag_of(v_it2_2462)) {
          case TAG_Nil: {
            V v_t_2463 = (g_heff_2ecompile_2edirect_2evalueOf(v_kn_240, v_s_2461));
            HeffT3 v_t_2464 = ({ V a_0 = v_t_2463; HeffT3 r_ = (g_heff_2ecompile_2edirect_2eopened_24cpr(a_0)); heff_drop(v_t_2463); r_; });
            {
              V v_field_2466 = v_t_2464.f[1];
              V v_field_2467 = v_t_2464.f[2];
              int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
              if ((v_tag_2465 == ((int64_t)0ULL))) {
                V v_t2_2468 = v_field_2466;
                V v_fs_2469 = v_field_2467;
                if (heff_strEq_c(((V)&g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str3), v_t2_2468)) {
                  switch (heff_tag_of(v_fs_2469)) {
                  case TAG_Nil: {
                    heff_drop(v_k_243);
                    heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Cons: {
                    V v_v_2470 = heff_field(v_fs_2469, 0);
                    V v_it12_2471 = heff_field(v_fs_2469, 1);
                    V v_ru_24fs_2469_24Cons = heff_take_reuse_n(v_fs_2469, 3ULL, 2);
                    switch (heff_tag_of(v_it12_2471)) {
                    case TAG_Nil: {
                      heff_drop(v_k_243);
                      heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                      heff_drop(v_v_2470);
                      heff_drop_cell(v_ru_24fs_2469_24Cons, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Cons: {
                      V v_g_2472 = heff_field(v_it12_2471, 0);
                      V v_it122_2473 = heff_field(v_it12_2471, 1);
                      heff_take_n(v_it12_2471, 3ULL, 2);
                      switch (heff_tag_of(v_it122_2473)) {
                      case TAG_Nil: {
                        V v_t_2474 = heff_tag_at_n(v_ru_24fs_2420_24Cons, TAG_Cons, 2, (V[]){v_v_2470, NTAG(TAG_Nil)});
                        V v_t_2475 = heff_tag_at_n(v_ru_24fs_2469_24Cons, TAG_EPrimCall, 2, (V[]){NTAG(TAG_BocNew), v_t_2474});
                        V v_t_2476 = (g_heff_2ecompile_2edirect_2eapplied(v_g_2472, v_t_2475));
                        V v_t_2477 = (g_heff_2ecompile_2edirect_2eapplied(v_k_243, v_t_2476));
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2477}});
                      }
                      case TAG_Cons: {
                        heff_take_n(v_it122_2473, 0ULL, 2);
                        heff_drop(v_k_243);
                        heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                        heff_drop(v_v_2470);
                        heff_drop_cell(v_ru_24fs_2469_24Cons, 2);
                        heff_drop(v_g_2472);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      default: return ((HeffT2){{heff_nomatch(v_it122_2473)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_it12_2471)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_fs_2469)}});
                  }
                } else {
                  heff_drop(v_k_243);
                  heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                  heff_drop(v_fs_2469);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                heff_drop(v_k_243);
                heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                heff_drop(v_field_2466);
                heff_drop(v_field_2467);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          case TAG_Cons: {
            heff_take_n(v_it2_2462, 0ULL, 2);
            heff_drop(v_k_243);
            heff_drop(v_s_2461);
            heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it2_2462)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_fs_2420)}});
        }
      } else {
        if (heff_strEq_c_lent(v_t_2419, ((V)&g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str4), 2)) {
          heff_drop(v_u_241);
          heff_drop(v_t_2419);
          heff_drop_cell(v_ru_24p_242_24ETag, 3);
          switch (heff_tag_of(v_fs_2420)) {
          case TAG_Nil: {
            heff_drop(v_k_243);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Cons: {
            V v_s_2482 = heff_field(v_fs_2420, 0);
            V v_it2_2483 = heff_field(v_fs_2420, 1);
            V v_ru_24fs_2420_24Cons = heff_take_reuse_n(v_fs_2420, 3ULL, 2);
            switch (heff_tag_of(v_it2_2483)) {
            case TAG_Nil: {
              V v_t_2484 = (g_heff_2ecompile_2edirect_2evalueOf(v_kn_240, v_s_2482));
              HeffT3 v_t_2485 = ({ V a_0 = v_t_2484; HeffT3 r_ = (g_heff_2ecompile_2edirect_2eopened_24cpr(a_0)); heff_drop(v_t_2484); r_; });
              {
                V v_field_2487 = v_t_2485.f[1];
                V v_field_2488 = v_t_2485.f[2];
                int64_t v_tag_2486 = ((int64_t)v_t_2485.f[0]);
                if ((v_tag_2486 == ((int64_t)0ULL))) {
                  V v_t2_2489 = v_field_2487;
                  V v_fs_2490 = v_field_2488;
                  if (heff_strEq_c(((V)&g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str5), v_t2_2489)) {
                    switch (heff_tag_of(v_fs_2490)) {
                    case TAG_Nil: {
                      heff_drop(v_k_243);
                      heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Cons: {
                      V v_tn_2491 = heff_field(v_fs_2490, 0);
                      V v_it12_2492 = heff_field(v_fs_2490, 1);
                      V v_ru_24fs_2490_24Cons = heff_take_reuse_n(v_fs_2490, 3ULL, 2);
                      switch (heff_tag_of(v_it12_2492)) {
                      case TAG_Nil: {
                        heff_drop(v_k_243);
                        heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                        heff_drop(v_tn_2491);
                        heff_drop_cell(v_ru_24fs_2490_24Cons, 2);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Cons: {
                        V v_g_2493 = heff_field(v_it12_2492, 0);
                        V v_it122_2494 = heff_field(v_it12_2492, 1);
                        heff_take_n(v_it12_2492, 3ULL, 2);
                        switch (heff_tag_of(v_it122_2494)) {
                        case TAG_Nil: {
                          V v_t_2495 = heff_tag_at_n(v_ru_24fs_2420_24Cons, TAG_Cons, 2, (V[]){v_tn_2491, NTAG(TAG_Nil)});
                          V v_t_2496 = heff_tag_at_n(v_ru_24fs_2490_24Cons, TAG_EPrimCall, 2, (V[]){NTAG(TAG_BocTaken), v_t_2495});
                          V v_t_2497 = (g_heff_2ecompile_2edirect_2eapplied(v_g_2493, v_t_2496));
                          V v_t_2498 = (g_heff_2ecompile_2edirect_2eapplied(v_k_243, v_t_2497));
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2498}});
                        }
                        case TAG_Cons: {
                          heff_take_n(v_it122_2494, 0ULL, 2);
                          heff_drop(v_k_243);
                          heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                          heff_drop(v_tn_2491);
                          heff_drop_cell(v_ru_24fs_2490_24Cons, 2);
                          heff_drop(v_g_2493);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_it122_2494)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_it12_2492)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_fs_2490)}});
                    }
                  } else {
                    heff_drop(v_k_243);
                    heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                    heff_drop(v_fs_2490);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                } else {
                  heff_drop(v_k_243);
                  heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                  heff_drop(v_field_2487);
                  heff_drop(v_field_2488);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            case TAG_Cons: {
              heff_take_n(v_it2_2483, 0ULL, 2);
              heff_drop(v_k_243);
              heff_drop(v_s_2482);
              heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it2_2483)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_fs_2420)}});
          }
        } else {
          if (heff_strEq_c(v_t_2419, ((V)&g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str6))) {
            switch (heff_tag_of(v_fs_2420)) {
            case TAG_Nil: {
              heff_drop(v_u_241);
              heff_drop(v_k_243);
              heff_drop_cell(v_ru_24p_242_24ETag, 3);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Cons: {
              V v_s_24103 = heff_field(v_fs_2420, 0);
              V v_it2_24104 = heff_field(v_fs_2420, 1);
              V v_ru_24fs_2420_24Cons = heff_take_reuse_n(v_fs_2420, 3ULL, 2);
              switch (heff_tag_of(v_it2_24104)) {
              case TAG_Nil: {
                V v_t_24105 = (g_heff_2ecompile_2edirect_2evalueOf(v_kn_240, v_s_24103));
                HeffT3 v_t_24106 = ({ V a_0 = v_t_24105; HeffT3 r_ = (g_heff_2ecompile_2edirect_2eopened_24cpr(a_0)); heff_drop(v_t_24105); r_; });
                {
                  V v_field_24108 = v_t_24106.f[1];
                  V v_field_24109 = v_t_24106.f[2];
                  int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
                  if ((v_tag_24107 == ((int64_t)0ULL))) {
                    V v_t2_24110 = v_field_24108;
                    V v_fs_24111 = v_field_24109;
                    if (heff_strEq_c(((V)&g_heff_2ecompile_2edirect_2edirectBoc_24cpr_str7), v_t2_24110)) {
                      switch (heff_tag_of(v_fs_24111)) {
                      case TAG_Nil: {
                        heff_drop(v_u_241);
                        heff_drop(v_k_243);
                        heff_drop_cell(v_ru_24p_242_24ETag, 3);
                        heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Cons: {
                        V v_tn_24112 = heff_field(v_fs_24111, 0);
                        V v_it12_24113 = heff_field(v_fs_24111, 1);
                        V v_ru_24fs_24111_24Cons = heff_take_reuse_n(v_fs_24111, 3ULL, 2);
                        switch (heff_tag_of(v_it12_24113)) {
                        case TAG_Nil: {
                          heff_drop(v_u_241);
                          heff_drop(v_k_243);
                          heff_drop_cell(v_ru_24p_242_24ETag, 3);
                          heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                          heff_drop(v_tn_24112);
                          heff_drop_cell(v_ru_24fs_24111_24Cons, 2);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Cons: {
                          V v_v_24114 = heff_field(v_it12_24113, 0);
                          V v_it122_24115 = heff_field(v_it12_24113, 1);
                          V v_ru_24it12_24113_24Cons = heff_take_reuse_n(v_it12_24113, 3ULL, 2);
                          switch (heff_tag_of(v_it122_24115)) {
                          case TAG_Nil: {
                            heff_drop(v_u_241);
                            heff_drop(v_k_243);
                            heff_drop_cell(v_ru_24p_242_24ETag, 3);
                            heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                            heff_drop(v_tn_24112);
                            heff_drop_cell(v_ru_24fs_24111_24Cons, 2);
                            heff_drop(v_v_24114);
                            heff_drop_cell(v_ru_24it12_24113_24Cons, 2);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Cons: {
                            V v_x_24116 = heff_field(v_it122_24115, 0);
                            V v_it1222_24117 = heff_field(v_it122_24115, 1);
                            V v_ru_24it122_24115_24Cons = heff_take_reuse_n(v_it122_24115, 3ULL, 2);
                            switch (heff_tag_of(v_it1222_24117)) {
                            case TAG_Nil: {
                              V v_t_24127;
                              switch (heff_tag_of(v_k_243)) {
                              case TAG_ELam: {
                                V v_f1_24118 = heff_dup(heff_field(v_k_243, 0));
                                V v_b_24119 = heff_dup(heff_field(v_k_243, 1));
                                switch (heff_tag_of(v_f1_24118)) {
                                case TAG_Nil: {
                                  heff_drop_cell(v_ru_24p_242_24ETag, 3);
                                  heff_drop(v_b_24119);
                                  V v_t_24120 = heff_tag_at_n(v_ru_24fs_2420_24Cons, TAG_Cons, 2, (V[]){v_x_24116, NTAG(TAG_Nil)});
                                  v_t_24127 = heff_tag_at_n(v_ru_24it122_24115_24Cons, TAG_EApp, 2, (V[]){v_k_243, v_t_24120});
                                  break;
                                }
                                case TAG_Cons: {
                                  V v_x_24121 = heff_field(v_f1_24118, 0);
                                  V v_f12_24122 = heff_field(v_f1_24118, 1);
                                  heff_take_n(v_f1_24118, 3ULL, 2);
                                  switch (heff_tag_of(v_f12_24122)) {
                                  case TAG_Nil: {
                                    heff_drop_tag(v_k_243, 2);
                                    heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                                    heff_drop_cell(v_ru_24it122_24115_24Cons, 2);
                                    v_t_24127 = heff_tag_at_n(v_ru_24p_242_24ETag, TAG_ELet, 3, (V[]){v_x_24121, v_x_24116, v_b_24119});
                                    break;
                                  }
                                  case TAG_Cons: {
                                    heff_take_n(v_f12_24122, 0ULL, 2);
                                    heff_drop_cell(v_ru_24p_242_24ETag, 3);
                                    heff_drop(v_b_24119);
                                    heff_drop(v_x_24121);
                                    V v_t_24125 = heff_tag_at_n(v_ru_24fs_2420_24Cons, TAG_Cons, 2, (V[]){v_x_24116, NTAG(TAG_Nil)});
                                    v_t_24127 = heff_tag_at_n(v_ru_24it122_24115_24Cons, TAG_EApp, 2, (V[]){v_k_243, v_t_24125});
                                    break;
                                  }
                                  default: heff_nomatch(v_f12_24122);
                                  }
                                  break;
                                }
                                default: heff_nomatch(v_f1_24118);
                                }
                                break;
                              }
                              default: {
                                heff_drop_cell(v_ru_24p_242_24ETag, 3);
                                V v_t_24126 = heff_tag_at_n(v_ru_24fs_2420_24Cons, TAG_Cons, 2, (V[]){v_x_24116, NTAG(TAG_Nil)});
                                v_t_24127 = heff_tag_at_n(v_ru_24it122_24115_24Cons, TAG_EApp, 2, (V[]){v_k_243, v_t_24126});
                                break;
                              }
                              }
                              V v_t_24128 = heff_tag_at_n(v_ru_24fs_24111_24Cons, TAG_Cons, 2, (V[]){v_v_24114, NTAG(TAG_Nil)});
                              V v_t_24129 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_BocGiven), heff_tag_at_n(v_ru_24it12_24113_24Cons, TAG_Cons, 2, (V[]){v_tn_24112, v_t_24128})});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_ELet, 3, (V[]){v_u_241, v_t_24129, v_t_24127})}});
                            }
                            case TAG_Cons: {
                              heff_take_n(v_it1222_24117, 0ULL, 2);
                              heff_drop(v_u_241);
                              heff_drop(v_k_243);
                              heff_drop_cell(v_ru_24p_242_24ETag, 3);
                              heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                              heff_drop(v_tn_24112);
                              heff_drop_cell(v_ru_24fs_24111_24Cons, 2);
                              heff_drop(v_v_24114);
                              heff_drop_cell(v_ru_24it12_24113_24Cons, 2);
                              heff_drop(v_x_24116);
                              heff_drop_cell(v_ru_24it122_24115_24Cons, 2);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_it1222_24117)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_it122_24115)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_it12_24113)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_fs_24111)}});
                      }
                    } else {
                      heff_drop(v_u_241);
                      heff_drop(v_k_243);
                      heff_drop_cell(v_ru_24p_242_24ETag, 3);
                      heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                      heff_drop(v_fs_24111);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  } else {
                    heff_drop(v_u_241);
                    heff_drop(v_k_243);
                    heff_drop_cell(v_ru_24p_242_24ETag, 3);
                    heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                    heff_drop(v_field_24108);
                    heff_drop(v_field_24109);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              case TAG_Cons: {
                heff_take_n(v_it2_24104, 0ULL, 2);
                heff_drop(v_u_241);
                heff_drop(v_k_243);
                heff_drop_cell(v_ru_24p_242_24ETag, 3);
                heff_drop(v_s_24103);
                heff_drop_cell(v_ru_24fs_2420_24Cons, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it2_24104)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_fs_2420)}});
            }
          } else {
            heff_drop(v_u_241);
            heff_drop(v_k_243);
            heff_drop(v_fs_2420);
            heff_drop_cell(v_ru_24p_242_24ETag, 3);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_p_242, 0ULL, 2);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_p_242, 0ULL, 2);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_p_242, 0ULL, 2);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_nf(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_p_242, 0ULL, 2);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_p_242, 0ULL, 3);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_p_242, 0ULL, 1);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_p_242, 0ULL, 2);
    heff_drop(v_u_241);
    heff_drop(v_k_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_p_242)}});
  }
}
Clo g_heff_2ecompile_2edirect_2edirectList_23mutual_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2edirectList_23mutual_entry, 5, 0};

V g_heff_2ecompile_2edirect_2edirectList_23mutual(V v_mutual_23directList_240, V v_ls_241, V v_kn_242, V v_x4_243, V v_n_244) {
top: ;
  V v_directE_245 = heff_take_field(v_mutual_23directList_240, 4);
  V v_directList_246 = heff_get_n(v_mutual_23directList_240, 0, 5);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_244});
  }
  case TAG_Cons: {
    V v_e_247 = heff_field(v_x4_243, 0);
    V v_es_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(v_directE_245, 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_e_247, v_n_244}));
    switch (heff_tag_of(v_t_249)) {
    case TAG_MkPair: {
      V v_e2_2410 = heff_field(v_t_249, 0);
      V v_n2_2411 = heff_field(v_t_249, 1);
      V v_ru_24t_249_24MkPair = heff_take_reuse_n(v_t_249, 3ULL, 2);
      V v_t_2412 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_es_248, v_n2_2411}));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_MkPair: {
        V v_es2_2413 = heff_field(v_t_2412, 0);
        V v_n3_2414 = heff_field(v_t_2412, 1);
        heff_take_n(v_t_2412, 3ULL, 2);
        return heff_tag_at_n(v_ru_24t_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e2_2410, v_es2_2413}), v_n3_2414});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2edirect_2edirectList_23mutual_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edirect_2edirectList_23mutual(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2edirect_2edirectArms_23mutual_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2edirectArms_23mutual_entry, 5, 0};

V g_heff_2ecompile_2edirect_2edirectArms_23mutual(V v_mutual_23directList_240, V v_ls_241, V v_kn_242, V v_x4_243, V v_n_244) {
top: ;
  V v_directE_245 = heff_take_field(v_mutual_23directList_240, 4);
  V v_directArms_246 = heff_get_n(v_mutual_23directList_240, 3, 5);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directArms_246);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_244});
  }
  case TAG_Cons: {
    V v_x41_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_247)) {
    case TAG_MkArm: {
      V v_t_249 = heff_field(v_x41_247, 0);
      V v_vs_2410 = heff_field(v_x41_247, 1);
      V v_b_2411 = heff_field(v_x41_247, 2);
      V v_ru_24x41_247_24MkArm = heff_take_reuse_n(v_x41_247, 7ULL, 3);
      V v_t_2412 = heff_tr(heff_call(v_directE_245, 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_b_2411, v_n_244}));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_MkPair: {
        V v_b2_2413 = heff_field(v_t_2412, 0);
        V v_n2_2414 = heff_field(v_t_2412, 1);
        V v_ru_24t_2412_24MkPair = heff_take_reuse_n(v_t_2412, 3ULL, 2);
        V v_t_2415 = heff_tr(heff_call(v_directArms_246, 4, (V[]){v_ls_241, v_kn_242, v_rest_248, v_n2_2414}));
        switch (heff_tag_of(v_t_2415)) {
        case TAG_MkPair: {
          V v_rest2_2416 = heff_field(v_t_2415, 0);
          V v_n3_2417 = heff_field(v_t_2415, 1);
          heff_take_n(v_t_2415, 3ULL, 2);
          V v_t_2418 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x41_247_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_249, v_vs_2410, v_b2_2413}), v_rest2_2416});
          return heff_tag_at_n(v_ru_24t_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, v_n3_2417});
        }
        default: return heff_nomatch(v_t_2415);
        }
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_x41_247);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2edirect_2edirectArms_23mutual_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edirect_2edirectArms_23mutual(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectE_23mutual_str0, 3, "boc");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectE_23mutual_str1, 8, "direct#u");
Clo g_heff_2ecompile_2edirect_2edirectE_23mutual_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2edirectE_23mutual_entry, 5, 0};

V g_heff_2ecompile_2edirect_2edirectE_23mutual(V v_mutual_23directList_240, V v_ls_241, V v_kn_242, V v_x4_243, V v_n_244) {
top: ;
  V v_directE_245 = heff_take_field(v_mutual_23directList_240, 4);
  V v_directList_246 = heff_take_field(v_mutual_23directList_240, 0);
  V v_directFields_247 = heff_take_field(v_mutual_23directList_240, 2);
  V v_directArms_248 = heff_take_field(v_mutual_23directList_240, 3);
  V v_directCond_249 = heff_get_n(v_mutual_23directList_240, 1, 5);
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_ELam: {
    V v_xs_2412 = heff_field(v_x4_243, 0);
    V v_b_2413 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24ELam = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_2414 = heff_tr(heff_call(v_directE_245, 4, (V[]){v_ls_241, v_kn_242, v_b_2413, v_n_244}));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_MkPair: {
      V v_b2_2415 = heff_field(v_t_2414, 0);
      V v_n2_2416 = heff_field(v_t_2414, 1);
      V v_ru_24t_2414_24MkPair = heff_take_reuse_n(v_t_2414, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_2414_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_2412, v_b2_2415}), v_n2_2416});
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_EApp: {
    V v_f_2417 = heff_field(v_x4_243, 0);
    V v_args_2418 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EApp = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_2419 = heff_tr(heff_call(v_directE_245, 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_f_2417, v_n_244}));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_MkPair: {
      V v_f2_2420 = heff_field(v_t_2419, 0);
      V v_n2_2421 = heff_field(v_t_2419, 1);
      V v_ru_24t_2419_24MkPair = heff_take_reuse_n(v_t_2419, 3ULL, 2);
      V v_t_2422 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_args_2418, v_n2_2421}));
      switch (heff_tag_of(v_t_2422)) {
      case TAG_MkPair: {
        V v_args2_2423 = heff_field(v_t_2422, 0);
        V v_n3_2424 = heff_field(v_t_2422, 1);
        heff_take_n(v_t_2422, 3ULL, 2);
        return heff_tag_at_n(v_ru_24t_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24EApp, TAG_EApp, 2, (V[]){v_f2_2420, v_args2_2423}), v_n3_2424});
      }
      default: return heff_nomatch(v_t_2422);
      }
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x4_243, 0);
    V v_a_2426 = heff_field(v_x4_243, 1);
    V v_b_2427 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24ELet = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_2428 = heff_tr(heff_call(heff_dup(v_directE_245), 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_a_2426, v_n_244}));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_MkPair: {
      V v_a2_2429 = heff_field(v_t_2428, 0);
      V v_n2_2430 = heff_field(v_t_2428, 1);
      V v_ru_24t_2428_24MkPair = heff_take_reuse_n(v_t_2428, 3ULL, 2);
      V v_t_2431 = (g_heff_2ecompile_2eir_2eisValue(v_a2_2429));
      V v_kn2_2432;
      if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
        heff_drop(v_t_2431);
        v_kn2_2432 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_kn_242, v_x_2425, v_a2_2429));
      } else {
        heff_drop(v_t_2431);
        v_kn2_2432 = v_kn_242;
      }
      V v_t_2433 = heff_tr(heff_call(v_directE_245, 4, (V[]){v_ls_241, v_kn2_2432, v_b_2427, v_n2_2430}));
      switch (heff_tag_of(v_t_2433)) {
      case TAG_MkPair: {
        V v_b2_2434 = heff_field(v_t_2433, 0);
        V v_n3_2435 = heff_field(v_t_2433, 1);
        heff_take_n(v_t_2433, 3ULL, 2);
        V v_t_2436 = (g_heff_2ecompile_2eir_2eisValue(v_a2_2429));
        if (((heff_dup(v_t_2436) == NTAG(TAG_True)) && ({ V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b2_2434), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24144 = (g_heff_2ecompile_2eir_2ecountW(v_x_2425, MK_INT(0LL), heff_dup(v_t_2437))); int c_ = heff_intEq_c_lent(v_t_24144, MK_INT(0LL), 2); heff_drop(v_t_24144); c_; }); heff_drop(v_t_2437); c_; }))) {
          heff_drop(v_x_2425);
          heff_drop_cell(v_ru_24x4_243_24ELet, 3);
          heff_drop(v_a2_2429);
          heff_drop(v_t_2436);
          return heff_tag_at_n(v_ru_24t_2428_24MkPair, TAG_MkPair, 2, (V[]){v_b2_2434, v_n3_2435});
        } else {
          heff_drop(v_t_2436);
          return heff_tag_at_n(v_ru_24t_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x4_243_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2425, v_a2_2429, v_b2_2434}), v_n3_2435});
        }
      }
      default: return heff_nomatch(v_t_2433);
      }
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_ERecord: {
    V v_fs_2438 = heff_field(v_x4_243, 0);
    V v_tys_2439 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24ERecord = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_2440 = heff_tr(heff_call(v_directFields_247, 4, (V[]){v_ls_241, v_kn_242, v_fs_2438, v_n_244}));
    switch (heff_tag_of(v_t_2440)) {
    case TAG_MkPair: {
      V v_fs2_2441 = heff_field(v_t_2440, 0);
      V v_n2_2442 = heff_field(v_t_2440, 1);
      V v_ru_24t_2440_24MkPair = heff_take_reuse_n(v_t_2440, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_2440_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_fs2_2441, v_tys_2439}), v_n2_2442});
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  case TAG_EProj: {
    V v_e_2443 = heff_field(v_x4_243, 0);
    V v_l_2444 = heff_field(v_x4_243, 1);
    V v_lbls_2445 = heff_field(v_x4_243, 2);
    V v_ty_2446 = heff_field(v_x4_243, 3);
    V v_ru_24x4_243_24EProj = heff_take_reuse_n(v_x4_243, 15ULL, 4);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_2447 = heff_tr(heff_call(v_directE_245, 4, (V[]){v_ls_241, v_kn_242, v_e_2443, v_n_244}));
    switch (heff_tag_of(v_t_2447)) {
    case TAG_MkPair: {
      V v_e2_2448 = heff_field(v_t_2447, 0);
      V v_n2_2449 = heff_field(v_t_2447, 1);
      V v_ru_24t_2447_24MkPair = heff_take_reuse_n(v_t_2447, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_2447_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_e2_2448, v_l_2444, v_lbls_2445, v_ty_2446}), v_n2_2449});
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  case TAG_ETag: {
    V v_t_2450 = heff_field(v_x4_243, 0);
    V v_args_2451 = heff_field(v_x4_243, 1);
    V v_tys_2452 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24ETag = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_directE_245);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_2453 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_args_2451, v_n_244}));
    switch (heff_tag_of(v_t_2453)) {
    case TAG_MkPair: {
      V v_args2_2454 = heff_field(v_t_2453, 0);
      V v_n2_2455 = heff_field(v_t_2453, 1);
      V v_ru_24t_2453_24MkPair = heff_take_reuse_n(v_t_2453, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_2453_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2450, v_args2_2454, v_tys_2452}), v_n2_2455});
    }
    default: return heff_nomatch(v_t_2453);
    }
  }
  case TAG_EMatch: {
    V v_sc_2456 = heff_field(v_x4_243, 0);
    V v_arms_2457 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EMatch = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directCond_249);
    V v_t_2458 = heff_tr(heff_call(v_directE_245, 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_sc_2456, v_n_244}));
    switch (heff_tag_of(v_t_2458)) {
    case TAG_MkPair: {
      V v_sc2_2459 = heff_field(v_t_2458, 0);
      V v_n2_2460 = heff_field(v_t_2458, 1);
      V v_ru_24t_2458_24MkPair = heff_take_reuse_n(v_t_2458, 3ULL, 2);
      V v_t_2461 = heff_tr(heff_call(v_directArms_248, 4, (V[]){v_ls_241, v_kn_242, v_arms_2457, v_n2_2460}));
      switch (heff_tag_of(v_t_2461)) {
      case TAG_MkPair: {
        V v_arms2_2462 = heff_field(v_t_2461, 0);
        V v_n3_2463 = heff_field(v_t_2461, 1);
        heff_take_n(v_t_2461, 3ULL, 2);
        return heff_tag_at_n(v_ru_24t_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24EMatch, TAG_EMatch, 2, (V[]){v_sc2_2459, v_arms2_2462}), v_n3_2463});
      }
      default: return heff_nomatch(v_t_2461);
      }
    }
    default: return heff_nomatch(v_t_2458);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EPrimCall: {
    V v_x41_2465 = heff_field(v_x4_243, 0);
    V v_x42_2466 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EPrimCall = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_directE_245);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    switch (heff_tag_of(v_x41_2465)) {
    case TAG_PerformAt: {
      V v_i_2467 = heff_dup(heff_field(v_x41_2465, 0));
      switch (heff_tag_of(v_x42_2466)) {
      case TAG_Nil: {
        heff_drop(v_i_2467);
        V v_t_2468 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_x42_2466, v_n_244}));
        switch (heff_tag_of(v_t_2468)) {
        case TAG_MkPair: {
          V v_args2_2469 = heff_field(v_t_2468, 0);
          V v_n2_2470 = heff_field(v_t_2468, 1);
          V v_ru_24t_2468_24MkPair = heff_take_reuse_n(v_t_2468, 3ULL, 2);
          return heff_tag_re_n(v_ru_24t_2468_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2465, v_args2_2469}), v_n2_2470});
        }
        default: return heff_nomatch(v_t_2468);
        }
      }
      case TAG_Cons: {
        V v_p_2471 = heff_dup(heff_field(v_x42_2466, 0));
        V v_x422_2472 = heff_dup(heff_field(v_x42_2466, 1));
        switch (heff_tag_of(v_x422_2472)) {
        case TAG_Nil: {
          heff_drop(v_i_2467);
          heff_drop(v_p_2471);
          V v_t_2473 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_x42_2466, v_n_244}));
          switch (heff_tag_of(v_t_2473)) {
          case TAG_MkPair: {
            V v_args2_2474 = heff_field(v_t_2473, 0);
            V v_n2_2475 = heff_field(v_t_2473, 1);
            V v_ru_24t_2473_24MkPair = heff_take_reuse_n(v_t_2473, 3ULL, 2);
            return heff_tag_re_n(v_ru_24t_2473_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2465, v_args2_2474}), v_n2_2475});
          }
          default: return heff_nomatch(v_t_2473);
          }
        }
        case TAG_Cons: {
          V v_k_2476 = heff_field(v_x422_2472, 0);
          V v_x4222_2477 = heff_field(v_x422_2472, 1);
          V v_ru_24x422_2472_24Cons = heff_take_reuse_n(v_x422_2472, 3ULL, 2);
          switch (heff_tag_of(v_x4222_2477)) {
          case TAG_Nil: {
            heff_drop_tag(v_x41_2465, 1);
            heff_drop_tag(v_x42_2466, 2);
            V v_t_2478 = heff_tag_re_n(v_ru_24x422_2472_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_k_2476, NTAG(TAG_Nil)});
            V v_t_2479 = heff_tr(heff_call(v_directList_246, 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), heff_tag_n(TAG_Cons, 2, (V[]){v_p_2471, v_t_2478}), v_n_244}));
            switch (heff_tag_of(v_t_2479)) {
            case TAG_MkPair: {
              V v_args_2480 = heff_field(v_t_2479, 0);
              V v_n2_2481 = heff_field(v_t_2479, 1);
              V v_ru_24t_2479_24MkPair = heff_take_reuse_n(v_t_2479, 3ULL, 2);
              switch (heff_tag_of(v_args_2480)) {
              case TAG_Nil: {
                heff_drop(v_ls_241);
                heff_drop(v_kn_242);
                V v_t_2482 = heff_tag_at_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2467}), v_args_2480});
                return heff_tag_re_n(v_ru_24t_2479_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2482, v_n2_2481});
              }
              case TAG_Cons: {
                V v_p2_2483 = heff_dup(heff_field(v_args_2480, 0));
                V v_it2_2484 = heff_dup(heff_field(v_args_2480, 1));
                switch (heff_tag_of(v_it2_2484)) {
                case TAG_Nil: {
                  heff_drop(v_ls_241);
                  heff_drop(v_kn_242);
                  heff_drop(v_p2_2483);
                  V v_t_2485 = heff_tag_at_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2467}), v_args_2480});
                  return heff_tag_re_n(v_ru_24t_2479_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2485, v_n2_2481});
                }
                case TAG_Cons: {
                  V v_k2_2486 = heff_field(v_it2_2484, 0);
                  V v_it22_2487 = heff_field(v_it2_2484, 1);
                  V v_ru_24it2_2484_24Cons = heff_take_reuse_n(v_it2_2484, 3ULL, 2);
                  switch (heff_tag_of(v_it22_2487)) {
                  case TAG_Nil: {
                    heff_drop_tag(v_args_2480, 2);
                    V v_m_2488 = ({ V a_0 = v_ls_241; V a_1 = heff_dup(v_i_2467); V r_ = (g_heff_2ecompile_2edirect_2emoduleAt(a_0, a_1)); heff_drop(v_ls_241); r_; });
                    V v_p_2489 = (g_heff_2ecompile_2edirect_2evalueOf(v_kn_242, heff_dup(v_p2_2483)));
                    if (heff_strEq_c(v_m_2488, ((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_str0))) {
                      V v_t_2490 = heff_strAppend(((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_str1), heff_intShow(heff_dup(v_n2_2481)));
                      HeffT2 v_t_2491 = ({ V a_0 = v_kn_242; V a_1 = v_t_2490; V a_2 = v_p_2489; V a_3 = heff_dup(v_k2_2486); HeffT2 r_ = (g_heff_2ecompile_2edirect_2edirectBoc_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_kn_242); r_; });
                      {
                        V v_field_2493 = v_t_2491.f[1];
                        int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
                        if ((v_tag_2492 == ((int64_t)0ULL))) {
                          heff_drop_cell(v_ru_24x4_243_24EPrimCall, 2);
                          heff_drop(v_i_2467);
                          heff_drop(v_p2_2483);
                          heff_drop(v_k2_2486);
                          heff_drop_cell(v_ru_24it2_2484_24Cons, 2);
                          V v_e_2494 = v_field_2493;
                          return heff_tag_at_n(v_ru_24t_2479_24MkPair, TAG_MkPair, 2, (V[]){v_e_2494, heff_intAdd(v_n2_2481, MK_INT(1LL))});
                        } else {
                          heff_drop(v_field_2493);
                          V v_t_2495 = heff_tag_re_n(v_ru_24it2_2484_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_k2_2486, NTAG(TAG_Nil)});
                          V v_t_2496 = heff_tag_at_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2467}), heff_tag_n(TAG_Cons, 2, (V[]){v_p2_2483, v_t_2495})});
                          return heff_tag_re_n(v_ru_24t_2479_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2496, v_n2_2481});
                        }
                      }
                    } else {
                      heff_drop(v_kn_242);
                      heff_drop(v_p_2489);
                      V v_t_2497 = heff_tag_re_n(v_ru_24it2_2484_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_k2_2486, NTAG(TAG_Nil)});
                      V v_t_2498 = heff_tag_at_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2467}), heff_tag_n(TAG_Cons, 2, (V[]){v_p2_2483, v_t_2497})});
                      return heff_tag_re_n(v_ru_24t_2479_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2498, v_n2_2481});
                    }
                  }
                  case TAG_Cons: {
                    heff_take_n(v_it22_2487, 0ULL, 2);
                    heff_drop(v_ls_241);
                    heff_drop(v_kn_242);
                    heff_drop(v_p2_2483);
                    heff_drop(v_k2_2486);
                    heff_drop_cell(v_ru_24it2_2484_24Cons, 2);
                    V v_t_24101 = heff_tag_at_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2467}), v_args_2480});
                    return heff_tag_re_n(v_ru_24t_2479_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24101, v_n2_2481});
                  }
                  default: return heff_nomatch(v_it22_2487);
                  }
                }
                default: return heff_nomatch(v_it2_2484);
                }
              }
              default: return heff_nomatch(v_args_2480);
              }
            }
            default: return heff_nomatch(v_t_2479);
            }
          }
          case TAG_Cons: {
            V v_ru_24x4222_2477_24Cons = heff_take_reuse_n(v_x4222_2477, 0ULL, 2);
            heff_drop(v_i_2467);
            heff_drop(v_p_2471);
            heff_drop(v_k_2476);
            heff_drop_cell(v_ru_24x422_2472_24Cons, 2);
            V v_t_24104 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_x42_2466, v_n_244}));
            switch (heff_tag_of(v_t_24104)) {
            case TAG_MkPair: {
              V v_args2_24105 = heff_field(v_t_24104, 0);
              V v_n2_24106 = heff_field(v_t_24104, 1);
              heff_take_n(v_t_24104, 3ULL, 2);
              return heff_tag_at_n(v_ru_24x4222_2477_24Cons, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2465, v_args2_24105}), v_n2_24106});
            }
            default: return heff_nomatch(v_t_24104);
            }
          }
          default: return heff_nomatch(v_x4222_2477);
          }
        }
        default: return heff_nomatch(v_x422_2472);
        }
      }
      default: return heff_nomatch(v_x42_2466);
      }
    }
    default: {
      V v_t_24107 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_x42_2466, v_n_244}));
      switch (heff_tag_of(v_t_24107)) {
      case TAG_MkPair: {
        V v_args2_24108 = heff_field(v_t_24107, 0);
        V v_n2_24109 = heff_field(v_t_24107, 1);
        V v_ru_24t_24107_24MkPair = heff_take_reuse_n(v_t_24107, 3ULL, 2);
        return heff_tag_re_n(v_ru_24t_24107_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2465, v_args2_24108}), v_n2_24109});
      }
      default: return heff_nomatch(v_t_24107);
      }
    }
    }
  }
  case TAG_ECall: {
    V v_g_24110 = heff_field(v_x4_243, 0);
    V v_args_24111 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24ECall = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_directE_245);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_24112 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_args_24111, v_n_244}));
    switch (heff_tag_of(v_t_24112)) {
    case TAG_MkPair: {
      V v_args2_24113 = heff_field(v_t_24112, 0);
      V v_n2_24114 = heff_field(v_t_24112, 1);
      V v_ru_24t_24112_24MkPair = heff_take_reuse_n(v_t_24112, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_24112_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_24110, v_args2_24113}), v_n2_24114});
    }
    default: return heff_nomatch(v_t_24112);
    }
  }
  case TAG_EInt: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EFloat: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EStr: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EBytes: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EFixed: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EFloat32: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_ls_241);
    heff_drop(v_kn_242);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x4_243, v_n_244});
  }
  case TAG_EBool: {
    V v_c_24122 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24EBool = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_directE_245);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    V v_t_24123 = heff_tr(heff_call(v_directCond_249, 4, (V[]){v_ls_241, v_kn_242, v_c_24122, v_n_244}));
    switch (heff_tag_of(v_t_24123)) {
    case TAG_MkPair: {
      V v_c2_24124 = heff_field(v_t_24123, 0);
      V v_n2_24125 = heff_field(v_t_24123, 1);
      V v_ru_24t_24123_24MkPair = heff_take_reuse_n(v_t_24123, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_24123_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x4_243_24EBool, TAG_EBool, 1, (V[]){v_c2_24124}), v_n2_24125});
    }
    default: return heff_nomatch(v_t_24123);
    }
  }
  case TAG_ESet: {
    V v_xs_24126 = heff_field(v_x4_243, 0);
    V v_a_24127 = heff_field(v_x4_243, 1);
    V v_b_24128 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24ESet = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_24129 = heff_tr(heff_call(heff_dup(v_directE_245), 4, (V[]){heff_dup(v_ls_241), heff_dup(v_kn_242), v_a_24127, v_n_244}));
    switch (heff_tag_of(v_t_24129)) {
    case TAG_MkPair: {
      V v_a2_24130 = heff_field(v_t_24129, 0);
      V v_n2_24131 = heff_field(v_t_24129, 1);
      V v_ru_24t_24129_24MkPair = heff_take_reuse_n(v_t_24129, 3ULL, 2);
      V v_t_24132 = heff_tr(heff_call(v_directE_245, 4, (V[]){v_ls_241, v_kn_242, v_b_24128, v_n2_24131}));
      switch (heff_tag_of(v_t_24132)) {
      case TAG_MkPair: {
        V v_b2_24133 = heff_field(v_t_24132, 0);
        V v_n3_24134 = heff_field(v_t_24132, 1);
        heff_take_n(v_t_24132, 3ULL, 2);
        return heff_tag_at_n(v_ru_24t_24129_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x4_243_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_24126, v_a2_24130, v_b2_24133}), v_n3_24134});
      }
      default: return heff_nomatch(v_t_24132);
      }
    }
    default: return heff_nomatch(v_t_24129);
    }
  }
  case TAG_EValues: {
    V v_es_24135 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24EValues = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_directE_245);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_24136 = heff_tr(heff_call(v_directList_246, 4, (V[]){v_ls_241, v_kn_242, v_es_24135, v_n_244}));
    switch (heff_tag_of(v_t_24136)) {
    case TAG_MkPair: {
      V v_es2_24137 = heff_field(v_t_24136, 0);
      V v_n2_24138 = heff_field(v_t_24136, 1);
      V v_ru_24t_24136_24MkPair = heff_take_reuse_n(v_t_24136, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_24136_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x4_243_24EValues, TAG_EValues, 1, (V[]){v_es2_24137}), v_n2_24138});
    }
    default: return heff_nomatch(v_t_24136);
    }
  }
  case TAG_EFix: {
    V v_x_24139 = heff_field(v_x4_243, 0);
    V v_e_24140 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EFix = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_directList_246);
    heff_drop(v_directFields_247);
    heff_drop(v_directArms_248);
    heff_drop(v_directCond_249);
    V v_t_24141 = heff_tr(heff_call(v_directE_245, 4, (V[]){v_ls_241, v_kn_242, v_e_24140, v_n_244}));
    switch (heff_tag_of(v_t_24141)) {
    case TAG_MkPair: {
      V v_e2_24142 = heff_field(v_t_24141, 0);
      V v_n2_24143 = heff_field(v_t_24141, 1);
      V v_ru_24t_24141_24MkPair = heff_take_reuse_n(v_t_24141, 3ULL, 2);
      return heff_tag_re_n(v_ru_24t_24141_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x4_243_24EFix, TAG_EFix, 2, 1ULL, (V[]){v_x_24139, v_e2_24142}), v_n2_24143});
    }
    default: return heff_nomatch(v_t_24141);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2edirect_2edirectE_23mutual_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2edirect_2edirectE_23mutual(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24dps_24cpr(V v_ls_240, V v_kn_241, V v_x4_242, V v_n_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    V v_u_245 = heff_setFieldPeek(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_246 = heff_hole();
    return ((HeffT2){{v_f_246, v_n_243}});
  }
  case TAG_Cons: {
    V v_e_247 = heff_field(v_x4_242, 0);
    V v_es_248 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_249 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(v_ls_240, v_kn_241, v_e_247, v_n_243));
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_e2_2412 = v_field_2410;
      V v_n2_2413 = v_field_2411;
      switch (heff_tag_of(v_es_248)) {
      case TAG_Nil: {
        V v_t_2414 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e2_2412, NTAG(TAG_Nil)});
        V v_u_2415 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_t_2414);
        V v_f_2416 = heff_hole();
        return ((HeffT2){{v_f_2416, v_n2_2413}});
      }
      case TAG_Cons: {
        V v_e_2417 = heff_field(v_es_248, 0);
        V v_es_2418 = heff_field(v_es_248, 1);
        V v_ru_24es_248_24Cons = heff_take_reuse_n(v_es_248, 3ULL, 2);
        HeffT2 v_t_2419 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(v_ls_240, v_kn_241, v_e_2417, v_n2_2413));
        {
          V v_field_2420 = v_t_2419.f[0];
          V v_field_2421 = v_t_2419.f[1];
          V v_e2_2422 = v_field_2420;
          V v_n2_2423 = v_field_2421;
          V v_cell_2424 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e2_2412, heff_hole()});
          V v_u_2425 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2424);
          V v_cell_2426 = heff_tag_at_n(v_ru_24es_248_24Cons, TAG_Cons, 2, (V[]){v_e2_2422, heff_hole()});
          V v_u_2427 = heff_setFieldPeek(v_u_2425, MK_INT(1LL), v_cell_2426);
          V t_0 = v_ls_240;
          V t_1 = v_kn_241;
          V t_2 = v_es_2418;
          V t_3 = v_n2_2423;
          V t_4 = v_u_2427;
          v_ls_240 = t_0;
          v_kn_241 = t_1;
          v_x4_242 = t_2;
          v_n_243 = t_3;
          v_d_244 = t_4;
          goto top;
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_es_248)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1875922425x917980391_24cpr_str0, 3, "boc");
HEFF_LIT(g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1875922425x917980391_24cpr_str1, 8, "direct#u");

HeffT2 g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1875922425x917980391_24cpr(V v_ls_240, V v_kn_241, V v_x4_242, V v_n_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_EVar: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EGlobal: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x4_242, 0);
    V v_b_247 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24ELam = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_248 = ({ V a_0 = v_ls_240; V a_1 = v_kn_241; V a_2 = v_b_247; V a_3 = v_n_243; HeffT2 r_ = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_ls_240); heff_drop(v_kn_241); r_; });
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_b2_2411 = v_field_249;
      V v_n2_2412 = v_field_2410;
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_246, v_b2_2411}), v_n2_2412}});
    }
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x4_242, 0);
    V v_args_2414 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EApp = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_2415 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(v_ls_240, v_kn_241, v_f_2413, v_n_243));
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_f2_2418 = v_field_2416;
      V v_n2_2419 = v_field_2417;
      switch (heff_tag_of(v_args_2414)) {
      case TAG_Nil: {
        heff_drop(v_ls_240);
        heff_drop(v_kn_241);
        V v_t_2420 = heff_tag_at_n(v_ru_24x4_242_24EApp, TAG_EApp, 2, (V[]){v_f2_2418, NTAG(TAG_Nil)});
        return ((HeffT2){{v_t_2420, v_n2_2419}});
      }
      case TAG_Cons: {
        V v_e_2421 = heff_field(v_args_2414, 0);
        V v_es_2422 = heff_field(v_args_2414, 1);
        V v_ru_24args_2414_24Cons = heff_take_reuse_n(v_args_2414, 3ULL, 2);
        HeffT2 v_t_2423 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1271688985x1232569127_24cpr(v_ls_240, v_kn_241, v_e_2421, v_n2_2419));
        {
          V v_field_2424 = v_t_2423.f[0];
          V v_field_2425 = v_t_2423.f[1];
          V v_e2_2426 = v_field_2424;
          V v_n2_2427 = v_field_2425;
          HeffT2 v_t_2428 = ({ V a_0 = v_ls_240; V a_1 = v_kn_241; V a_2 = v_es_2422; V a_3 = v_n2_2427; HeffT2 r_ = (g_heff_2ecompile_2edirect_2edirectList_23mutual_24s2100653597x1754463521_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_ls_240); heff_drop(v_kn_241); r_; });
          {
            V v_field_2429 = v_t_2428.f[0];
            V v_field_2430 = v_t_2428.f[1];
            V v_es2_2431 = v_field_2429;
            V v_n3_2432 = v_field_2430;
            V v_t_2433 = heff_tag_at_n(v_ru_24x4_242_24EApp, TAG_EApp, 2, (V[]){v_f2_2418, heff_tag_at_n(v_ru_24args_2414_24Cons, TAG_Cons, 2, (V[]){v_e2_2426, v_es2_2431})});
            return ((HeffT2){{v_t_2433, v_n3_2432}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_args_2414)}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2434 = heff_field(v_x4_242, 0);
    V v_a_2435 = heff_field(v_x4_242, 1);
    V v_b_2436 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24ELet = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_a_2435, v_n_243}));
    switch (heff_tag_of(v_t_2437)) {
    case TAG_MkPair: {
      V v_a2_2438 = heff_field(v_t_2437, 0);
      V v_n2_2439 = heff_field(v_t_2437, 1);
      heff_take_n(v_t_2437, 3ULL, 2);
      V v_t_2440 = (g_heff_2ecompile_2eir_2eisValue(v_a2_2438));
      V v_kn2_2441;
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_t_2440);
        v_kn2_2441 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_kn_241, v_x_2434, v_a2_2438));
      } else {
        heff_drop(v_t_2440);
        v_kn2_2441 = v_kn_241;
      }
      V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn2_2441, v_b_2436, v_n2_2439}));
      switch (heff_tag_of(v_t_2442)) {
      case TAG_MkPair: {
        V v_b2_2443 = heff_field(v_t_2442, 0);
        V v_n3_2444 = heff_field(v_t_2442, 1);
        heff_take_n(v_t_2442, 3ULL, 2);
        V v_t_2445 = (g_heff_2ecompile_2eir_2eisValue(v_a2_2438));
        if (((heff_dup(v_t_2445) == NTAG(TAG_True)) && ({ V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b2_2443), NTAG(TAG_Nil)}); int c_ = ({ V v_t_24154 = (g_heff_2ecompile_2eir_2ecountW(v_x_2434, MK_INT(0LL), heff_dup(v_t_2446))); int c_ = heff_intEq_c_lent(v_t_24154, MK_INT(0LL), 2); heff_drop(v_t_24154); c_; }); heff_drop(v_t_2446); c_; }))) {
          heff_drop(v_x_2434);
          heff_drop_cell(v_ru_24x4_242_24ELet, 3);
          heff_drop(v_a2_2438);
          heff_drop(v_t_2445);
          return ((HeffT2){{v_b2_2443, v_n3_2444}});
        } else {
          heff_drop(v_t_2445);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2434, v_a2_2438, v_b2_2443}), v_n3_2444}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2442)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2437)}});
    }
  }
  case TAG_ERecord: {
    V v_fs_2447 = heff_field(v_x4_242, 0);
    V v_tys_2448 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24ERecord = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 2)), 4, (V[]){v_ls_240, v_kn_241, v_fs_2447, v_n_243}));
    switch (heff_tag_of(v_t_2449)) {
    case TAG_MkPair: {
      V v_fs2_2450 = heff_field(v_t_2449, 0);
      V v_n2_2451 = heff_field(v_t_2449, 1);
      heff_take_n(v_t_2449, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_fs2_2450, v_tys_2448}), v_n2_2451}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2449)}});
    }
  }
  case TAG_EProj: {
    V v_e_2452 = heff_field(v_x4_242, 0);
    V v_l_2453 = heff_field(v_x4_242, 1);
    V v_lbls_2454 = heff_field(v_x4_242, 2);
    V v_ty_2455 = heff_field(v_x4_242, 3);
    V v_ru_24x4_242_24EProj = heff_take_reuse_n(v_x4_242, 15ULL, 4);
    V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_e_2452, v_n_243}));
    switch (heff_tag_of(v_t_2456)) {
    case TAG_MkPair: {
      V v_e2_2457 = heff_field(v_t_2456, 0);
      V v_n2_2458 = heff_field(v_t_2456, 1);
      heff_take_n(v_t_2456, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_e2_2457, v_l_2453, v_lbls_2454, v_ty_2455}), v_n2_2458}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2456)}});
    }
  }
  case TAG_ETag: {
    V v_t_2459 = heff_field(v_x4_242, 0);
    V v_args_2460 = heff_field(v_x4_242, 1);
    V v_tys_2461 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24ETag = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_args_2460, v_n_243}));
    switch (heff_tag_of(v_t_2462)) {
    case TAG_MkPair: {
      V v_args2_2463 = heff_field(v_t_2462, 0);
      V v_n2_2464 = heff_field(v_t_2462, 1);
      heff_take_n(v_t_2462, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2459, v_args2_2463, v_tys_2461}), v_n2_2464}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2462)}});
    }
  }
  case TAG_EMatch: {
    V v_sc_2465 = heff_field(v_x4_242, 0);
    V v_arms_2466 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EMatch = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_sc_2465, v_n_243}));
    switch (heff_tag_of(v_t_2467)) {
    case TAG_MkPair: {
      V v_sc2_2468 = heff_field(v_t_2467, 0);
      V v_n2_2469 = heff_field(v_t_2467, 1);
      heff_take_n(v_t_2467, 3ULL, 2);
      V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 3)), 4, (V[]){v_ls_240, v_kn_241, v_arms_2466, v_n2_2469}));
      switch (heff_tag_of(v_t_2470)) {
      case TAG_MkPair: {
        V v_arms2_2471 = heff_field(v_t_2470, 0);
        V v_n3_2472 = heff_field(v_t_2470, 1);
        heff_take_n(v_t_2470, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24EMatch, TAG_EMatch, 2, (V[]){v_sc2_2468, v_arms2_2471}), v_n3_2472}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2470)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2467)}});
    }
  }
  case TAG_EPrim: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EPrimCall: {
    V v_x41_2474 = heff_field(v_x4_242, 0);
    V v_x42_2475 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EPrimCall = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_2474)) {
    case TAG_PerformAt: {
      V v_i_2476 = heff_dup(heff_field(v_x41_2474, 0));
      switch (heff_tag_of(v_x42_2475)) {
      case TAG_Nil: {
        heff_drop(v_i_2476);
        V v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2475, v_n_243}));
        switch (heff_tag_of(v_t_2477)) {
        case TAG_MkPair: {
          V v_args2_2478 = heff_field(v_t_2477, 0);
          V v_n2_2479 = heff_field(v_t_2477, 1);
          heff_take_n(v_t_2477, 3ULL, 2);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2474, v_args2_2478}), v_n2_2479}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t_2477)}});
        }
      }
      case TAG_Cons: {
        V v_p_2480 = heff_dup(heff_field(v_x42_2475, 0));
        V v_x422_2481 = heff_dup(heff_field(v_x42_2475, 1));
        switch (heff_tag_of(v_x422_2481)) {
        case TAG_Nil: {
          heff_drop(v_i_2476);
          heff_drop(v_p_2480);
          V v_t_2482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2475, v_n_243}));
          switch (heff_tag_of(v_t_2482)) {
          case TAG_MkPair: {
            V v_args2_2483 = heff_field(v_t_2482, 0);
            V v_n2_2484 = heff_field(v_t_2482, 1);
            heff_take_n(v_t_2482, 3ULL, 2);
            return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2474, v_args2_2483}), v_n2_2484}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2482)}});
          }
        }
        case TAG_Cons: {
          V v_k_2485 = heff_field(v_x422_2481, 0);
          V v_x4222_2486 = heff_field(v_x422_2481, 1);
          V v_ru_24x422_2481_24Cons = heff_take_reuse_n(v_x422_2481, 3ULL, 2);
          switch (heff_tag_of(v_x4222_2486)) {
          case TAG_Nil: {
            heff_drop_tag(v_x41_2474, 1);
            heff_drop_tag(v_x42_2475, 2);
            V v_t_2487 = heff_tag_re_n(v_ru_24x422_2481_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_k_2485, NTAG(TAG_Nil)});
            V v_t_2488 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), heff_tag_n(TAG_Cons, 2, (V[]){v_p_2480, v_t_2487}), v_n_243}));
            switch (heff_tag_of(v_t_2488)) {
            case TAG_MkPair: {
              V v_args_2489 = heff_field(v_t_2488, 0);
              V v_n2_2490 = heff_field(v_t_2488, 1);
              V v_ru_24t_2488_24MkPair = heff_take_reuse_n(v_t_2488, 3ULL, 2);
              switch (heff_tag_of(v_args_2489)) {
              case TAG_Nil: {
                heff_drop(v_ls_240);
                heff_drop(v_kn_241);
                heff_drop_cell(v_ru_24t_2488_24MkPair, 2);
                V v_t_2491 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2476}), v_args_2489});
                return ((HeffT2){{v_t_2491, v_n2_2490}});
              }
              case TAG_Cons: {
                V v_p2_2492 = heff_dup(heff_field(v_args_2489, 0));
                V v_it2_2493 = heff_dup(heff_field(v_args_2489, 1));
                switch (heff_tag_of(v_it2_2493)) {
                case TAG_Nil: {
                  heff_drop(v_ls_240);
                  heff_drop(v_kn_241);
                  heff_drop_cell(v_ru_24t_2488_24MkPair, 2);
                  heff_drop(v_p2_2492);
                  V v_t_2494 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2476}), v_args_2489});
                  return ((HeffT2){{v_t_2494, v_n2_2490}});
                }
                case TAG_Cons: {
                  V v_k2_2495 = heff_field(v_it2_2493, 0);
                  V v_it22_2496 = heff_field(v_it2_2493, 1);
                  V v_ru_24it2_2493_24Cons = heff_take_reuse_n(v_it2_2493, 3ULL, 2);
                  switch (heff_tag_of(v_it22_2496)) {
                  case TAG_Nil: {
                    heff_drop_tag(v_args_2489, 2);
                    V v_m_2497 = ({ V a_0 = v_ls_240; V a_1 = heff_dup(v_i_2476); V r_ = (g_heff_2ecompile_2edirect_2emoduleAt(a_0, a_1)); heff_drop(v_ls_240); r_; });
                    V v_p_2498 = (g_heff_2ecompile_2edirect_2evalueOf(v_kn_241, heff_dup(v_p2_2492)));
                    if (heff_strEq_c(v_m_2497, ((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1875922425x917980391_24cpr_str0))) {
                      V v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1875922425x917980391_24cpr_str1), heff_intShow(heff_dup(v_n2_2490)));
                      HeffT2 v_t_24100 = ({ V a_0 = v_kn_241; V a_1 = v_t_2499; V a_2 = v_p_2498; V a_3 = heff_dup(v_k2_2495); HeffT2 r_ = (g_heff_2ecompile_2edirect_2edirectBoc_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_kn_241); r_; });
                      {
                        V v_field_24102 = v_t_24100.f[1];
                        int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
                        if ((v_tag_24101 == ((int64_t)0ULL))) {
                          heff_drop_cell(v_ru_24x4_242_24EPrimCall, 2);
                          heff_drop(v_i_2476);
                          heff_drop_cell(v_ru_24t_2488_24MkPair, 2);
                          heff_drop(v_p2_2492);
                          heff_drop(v_k2_2495);
                          heff_drop_cell(v_ru_24it2_2493_24Cons, 2);
                          V v_e_24103 = v_field_24102;
                          V v_f_24104 = heff_intAdd(v_n2_2490, MK_INT(1LL));
                          return ((HeffT2){{v_e_24103, v_f_24104}});
                        } else {
                          heff_drop(v_field_24102);
                          V v_t_24105 = heff_tag_at_n(v_ru_24t_2488_24MkPair, TAG_Cons, 2, (V[]){v_k2_2495, NTAG(TAG_Nil)});
                          V v_t_24106 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2476}), heff_tag_at_n(v_ru_24it2_2493_24Cons, TAG_Cons, 2, (V[]){v_p2_2492, v_t_24105})});
                          return ((HeffT2){{v_t_24106, v_n2_2490}});
                        }
                      }
                    } else {
                      heff_drop(v_kn_241);
                      heff_drop(v_p_2498);
                      V v_t_24107 = heff_tag_at_n(v_ru_24t_2488_24MkPair, TAG_Cons, 2, (V[]){v_k2_2495, NTAG(TAG_Nil)});
                      V v_t_24108 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2476}), heff_tag_at_n(v_ru_24it2_2493_24Cons, TAG_Cons, 2, (V[]){v_p2_2492, v_t_24107})});
                      return ((HeffT2){{v_t_24108, v_n2_2490}});
                    }
                  }
                  case TAG_Cons: {
                    heff_take_n(v_it22_2496, 0ULL, 2);
                    heff_drop(v_ls_240);
                    heff_drop(v_kn_241);
                    heff_drop_cell(v_ru_24t_2488_24MkPair, 2);
                    heff_drop(v_p2_2492);
                    heff_drop(v_k2_2495);
                    heff_drop_cell(v_ru_24it2_2493_24Cons, 2);
                    V v_t_24111 = heff_tag_at_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_i_2476}), v_args_2489});
                    return ((HeffT2){{v_t_24111, v_n2_2490}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_it22_2496)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_it2_2493)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_args_2489)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_t_2488)}});
            }
          }
          case TAG_Cons: {
            heff_take_n(v_x4222_2486, 0ULL, 2);
            heff_drop(v_i_2476);
            heff_drop(v_p_2480);
            heff_drop(v_k_2485);
            heff_drop_cell(v_ru_24x422_2481_24Cons, 2);
            V v_t_24114 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2475, v_n_243}));
            switch (heff_tag_of(v_t_24114)) {
            case TAG_MkPair: {
              V v_args2_24115 = heff_field(v_t_24114, 0);
              V v_n2_24116 = heff_field(v_t_24114, 1);
              heff_take_n(v_t_24114, 3ULL, 2);
              return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2474, v_args2_24115}), v_n2_24116}});
            }
            default: return ((HeffT2){{heff_nomatch(v_t_24114)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x4222_2486)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x422_2481)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x42_2475)}});
      }
    }
    default: {
      V v_t_24117 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_x42_2475, v_n_243}));
      switch (heff_tag_of(v_t_24117)) {
      case TAG_MkPair: {
        V v_args2_24118 = heff_field(v_t_24117, 0);
        V v_n2_24119 = heff_field(v_t_24117, 1);
        heff_take_n(v_t_24117, 3ULL, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_x41_2474, v_args2_24118}), v_n2_24119}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24117)}});
      }
    }
    }
  }
  case TAG_ECall: {
    V v_g_24120 = heff_field(v_x4_242, 0);
    V v_args_24121 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24ECall = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_24122 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_args_24121, v_n_243}));
    switch (heff_tag_of(v_t_24122)) {
    case TAG_MkPair: {
      V v_args2_24123 = heff_field(v_t_24122, 0);
      V v_n2_24124 = heff_field(v_t_24122, 1);
      heff_take_n(v_t_24122, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_24120, v_args2_24123}), v_n2_24124}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24122)}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EFloat: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EStr: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EBytes: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EFixed: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EFloat32: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EAbandon: {
    heff_drop(v_ls_240);
    heff_drop(v_kn_241);
    return ((HeffT2){{v_x4_242, v_n_243}});
  }
  case TAG_EBool: {
    V v_c_24132 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24EBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_24133 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 1)), 4, (V[]){v_ls_240, v_kn_241, v_c_24132, v_n_243}));
    switch (heff_tag_of(v_t_24133)) {
    case TAG_MkPair: {
      V v_c2_24134 = heff_field(v_t_24133, 0);
      V v_n2_24135 = heff_field(v_t_24133, 1);
      heff_take_n(v_t_24133, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24EBool, TAG_EBool, 1, (V[]){v_c2_24134}), v_n2_24135}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24133)}});
    }
  }
  case TAG_ESet: {
    V v_xs_24136 = heff_field(v_x4_242, 0);
    V v_a_24137 = heff_field(v_x4_242, 1);
    V v_b_24138 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24ESet = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_24139 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){heff_dup(v_ls_240), heff_dup(v_kn_241), v_a_24137, v_n_243}));
    switch (heff_tag_of(v_t_24139)) {
    case TAG_MkPair: {
      V v_a2_24140 = heff_field(v_t_24139, 0);
      V v_n2_24141 = heff_field(v_t_24139, 1);
      heff_take_n(v_t_24139, 3ULL, 2);
      V v_t_24142 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_b_24138, v_n2_24141}));
      switch (heff_tag_of(v_t_24142)) {
      case TAG_MkPair: {
        V v_b2_24143 = heff_field(v_t_24142, 0);
        V v_n3_24144 = heff_field(v_t_24142, 1);
        heff_take_n(v_t_24142, 3ULL, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_24136, v_a2_24140, v_b2_24143}), v_n3_24144}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24142)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24139)}});
    }
  }
  case TAG_EValues: {
    V v_es_24145 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24EValues = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_24146 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 0)), 4, (V[]){v_ls_240, v_kn_241, v_es_24145, v_n_243}));
    switch (heff_tag_of(v_t_24146)) {
    case TAG_MkPair: {
      V v_es2_24147 = heff_field(v_t_24146, 0);
      V v_n2_24148 = heff_field(v_t_24146, 1);
      heff_take_n(v_t_24146, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24EValues, TAG_EValues, 1, (V[]){v_es2_24147}), v_n2_24148}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24146)}});
    }
  }
  case TAG_EFix: {
    V v_x_24149 = heff_field(v_x4_242, 0);
    V v_e_24150 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24EFix = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_24151 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2edirect_2emutual_23directList_get(), 4)), 4, (V[]){v_ls_240, v_kn_241, v_e_24150, v_n_243}));
    switch (heff_tag_of(v_t_24151)) {
    case TAG_MkPair: {
      V v_e2_24152 = heff_field(v_t_24151, 0);
      V v_n2_24153 = heff_field(v_t_24151, 1);
      heff_take_n(v_t_24151, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x4_242_24EFix, TAG_EFix, 2, 1ULL, (V[]){v_x_24149, v_e2_24152}), v_n2_24153}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_24151)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}

HeffT2 g_heff_2ecompile_2edirect_2edirectDefs_24cpr(V v_ls_240, V v_x2_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_n_242}});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x2_241, 0);
    V v_ds_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2edirect_2edirectE_23mutual_24s1875922425x917980391_24cpr(heff_dup(v_ls_240), heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_d_243, 2), v_n_242));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_b_248 = v_field_246;
      V v_n2_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2ecompile_2edirect_2edirectDefs_24cpr(v_ls_240, v_ds_244, v_n2_249));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = heff_dup(v_field_2411);
        V v_y_2414 = heff_dup(v_field_2412);
        heff_drop(v_y_2414);
        V v_t_2415 = v_x_2413;
        V v_x_2416 = v_field_2411;
        heff_drop(v_x_2416);
        V v_y_2417 = v_field_2412;
        V v_t_2418 = v_y_2417;
        V v_t_2419 = ({ V rv_2 = v_b_248; V rr_ = heff_rec_reuse_nf(v_d_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_f_2420 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, v_t_2415});
        return ((HeffT2){{v_f_2420, v_t_2418}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2edirect_2edirectDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2edirect_2edirectDefs_entry, 3, 0};

V g_heff_2ecompile_2edirect_2edirectDefs(V v_ls_240, V v_x2_241, V v_n_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2edirect_2edirectDefs_24cpr(v_ls_240, v_x2_241, v_n_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2edirect_2edirectDefs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2edirect_2edirectDefs(a0, a[1], a[2]); heff_drop(a0); return r;
}