// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Right 62770
#define LBL_cwd 308458
#define LBL_lib 316671
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_root 10001833
#define LBL_src 323678
#define LBL_style 311138763
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952(V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_clo;
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_clo;
V g_heff_2ebuild_2eload_2esameDir(V, V, V);
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameDir_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_str1, 3, "src");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_str2, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_str3, 3, "lib");
Clo g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0(V v_d_240, V v_h_241, V v_start_242, V v_hd_243, V v_k_244, V v_x_245) {
top: ;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    heff_take_n(v_x_245, 0ULL, 1);
    if (heff_strEq_c_lent(v_d_240, ((V)&g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_str0), 2)) {
      heff_drop(v_d_240);
      V v_st_247 = heff_dup(heff_rfield(v_h_241, 3));
      HeffT3 v_t_248 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_247), heff_dup(heff_rfield(v_h_241, 2))));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        V v_d_2412 = v_field_249;
        V v_a_2413 = v_field_2410;
        V v_xs_2414 = v_field_2411;
        V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
        V v_xs_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2415; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2415); r_; });
        V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
        V v_t_2418 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2412, v_a_2413, v_t_2417});
        V v_t_2419 = ({ V a_0 = v_st_247; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop_tag(v_t_2418, 3); r_; });
        V v_t_2420 = (g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952(v_h_241, v_start_242, v_t_2419));
        return heff_tail(v_t_2420, 2, (V[]){v_hd_243, v_k_244});
      }
    } else {
      V v_st_2421 = heff_dup(heff_rfield(v_h_241, 3));
      HeffT3 v_t_2422 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2421), heff_dup(v_d_240)));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_field_2425 = v_t_2422.f[2];
        V v_d_2426 = v_field_2423;
        V v_a_2427 = v_field_2424;
        V v_xs_2428 = v_field_2425;
        V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2428));
        V v_xs_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2429; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2429); r_; });
        V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
        V v_t_2432 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2426, v_a_2427, v_t_2431});
        V v_t_2433 = ({ V a_0 = v_st_2421; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2421); heff_drop_tag(v_t_2432, 3); r_; });
        if (heff_strEq_c_lent(v_t_2433, v_d_240, 1)) {
          heff_drop(v_d_240);
          heff_drop(v_hd_243);
          V v_t_2434 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){heff_dup(v_start_242), v_start_242, heff_take_field(v_h_241, 0), heff_take_field(v_h_241, 1), heff_take_field(v_h_241, 2), heff_get_n(v_h_241, 3, 5)});
          return heff_tail(v_k_244, 1, (V[]){v_t_2434});
        } else {
          V v_st_2435 = heff_dup(heff_rfield(v_h_241, 3));
          HeffT3 v_t_2436 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2435), v_d_240));
          {
            V v_field_2437 = v_t_2436.f[0];
            V v_field_2438 = v_t_2436.f[1];
            V v_field_2439 = v_t_2436.f[2];
            V v_d_2440 = v_field_2437;
            V v_a_2441 = v_field_2438;
            V v_xs_2442 = v_field_2439;
            V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2442));
            V v_xs_2444 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2443; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2443); r_; });
            V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2444));
            V v_t_2446 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2440, v_a_2441, v_t_2445});
            V v_t_2447 = ({ V a_0 = v_st_2435; V a_1 = v_t_2446; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2435); heff_drop_tag(v_t_2446, 3); r_; });
            V v_t_2448 = (g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952(v_h_241, v_start_242, v_t_2447));
            return heff_tail(v_t_2448, 2, (V[]){v_hd_243, v_k_244});
          }
        }
      }
    }
  }
  case TAG_Right: {
    V v_y_2449 = heff_field(v_x_245, 0);
    V v_ru_24x_245_24Right = heff_take_reuse_n(v_x_245, 1ULL, 1);
    heff_drop(v_start_242);
    heff_drop(v_hd_243);
    V v_st_2450 = heff_dup(heff_rfield(v_h_241, 3));
    V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2450), heff_dup(v_d_240)));
    V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2450), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_str1)));
    V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
    V v_t_2454 = ({ V a_0 = v_st_2450; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); heff_drop(v_t_2453); r_; });
    V v_h_2455 = heff_dup(v_h_241);
    V v_d_2456 = heff_dup(v_d_240);
    HeffT2 v_t_2457 = ({ V a_0 = v_y_2449; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_y_2449); r_; });
    {
      V v_field_2459 = v_t_2457.f[1];
      int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
      V v_x3_2462;
      if ((v_tag_2458 == ((int64_t)0ULL))) {
        V v_p_2460 = v_field_2459;
        v_x3_2462 = heff_tag_at_n(v_ru_24x_245_24Right, TAG_Left, 1, (V[]){v_p_2460});
      } else {
        heff_drop_cell(v_ru_24x_245_24Right, 1);
        V v_x_2461 = v_field_2459;
        v_x3_2462 = ({ V a_0 = v_x_2461; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2461); r_; });
      }
      V v_t_2476;
      switch (heff_tag_of(v_x3_2462)) {
      case TAG_Left: {
        heff_take_n(v_x3_2462, 0ULL, 1);
        heff_drop(v_d_2456);
        v_t_2476 = heff_get_n(v_h_2455, 0, 5);
        break;
      }
      case TAG_Right: {
        V v_pk_2464 = heff_field(v_x3_2462, 0);
        heff_take_n(v_x3_2462, 1ULL, 1);
        if (heff_strEq_c(heff_get_n(v_pk_2464, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          V v_t_2465 = (g_heff_2ebuild_2eload_2eheffAt(heff_dup(v_h_2455), heff_dup(v_d_2456)));
          if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
            heff_drop(v_t_2465);
            V v_st_2466 = heff_dup(heff_rfield(v_h_2455, 3));
            V v_t_2467 = (g_std_2epath_2eparse(heff_dup(v_st_2466), heff_dup(v_d_2456)));
            V v_t_2468 = (g_std_2epath_2eparse(heff_dup(v_st_2466), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_str2)));
            V v_t_2469 = (g_std_2epath_2ejoin(v_t_2467, v_t_2468));
            V v_t_2470 = ({ V a_0 = v_st_2466; V a_1 = v_t_2469; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2466); heff_drop(v_t_2469); r_; });
            V v_x1_2471 = (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_2455), heff_dup(heff_rfield(v_h_2455, 0)), v_t_2470));
            if (!(heff_dup(v_x1_2471) == NTAG(TAG_True))) {
              heff_drop(v_x1_2471);
              V v_st_2472 = heff_get_n(v_h_2455, 3, 5);
              V v_t_2473 = (g_std_2epath_2eparse(heff_dup(v_st_2472), v_d_2456));
              V v_t_2474 = (g_std_2epath_2eparse(heff_dup(v_st_2472), ((V)&g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_str3)));
              V v_t_2475 = (g_std_2epath_2ejoin(v_t_2473, v_t_2474));
              v_t_2476 = ({ V a_0 = v_st_2472; V a_1 = v_t_2475; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2472); heff_drop(v_t_2475); r_; });
            } else {
              heff_drop(v_d_2456);
              heff_drop(v_x1_2471);
              v_t_2476 = heff_get_n(v_h_2455, 0, 5);
            }
          } else {
            heff_drop(v_d_2456);
            heff_drop(v_t_2465);
            v_t_2476 = heff_get_n(v_h_2455, 0, 5);
          }
        } else {
          heff_drop(v_d_2456);
          v_t_2476 = heff_get_n(v_h_2455, 0, 5);
        }
        break;
      }
      default: heff_nomatch(v_x3_2462);
      }
      V v_x_2477 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){v_d_240, v_t_2454, v_t_2476, heff_take_field(v_h_241, 1), heff_take_field(v_h_241, 2), heff_get_n(v_h_241, 3, 5)});
      return heff_tail(v_k_244, 1, (V[]){v_x_2477});
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2erootFrom_24s411194290x739730952_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5]);
}