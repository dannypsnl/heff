// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Windows 49101
#define TAG_WriteErr 37283
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0(V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_str0, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_str3, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0(V v_hd_240, V v_k_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_x_242)) {
  case TAG_Left: {
    V v_ru_24x_242_24Left = heff_take_reuse_n(v_x_242, 0ULL, 1);
    V v_t_245 = heff_tag_at_n(v_ru_24x_242_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam0_clo)})});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    HEFF_LAST return g_co_2eop_24s535099379x685970669(v_t_2410, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam1, 1, 2, (V[]){v_hd_240, v_k_241}));
  }
  case TAG_Right: {
    V v_ru_24x_242_24Right = heff_take_reuse_n(v_x_242, 0ULL, 1);
    V v_t_2427 = heff_tag_at_n(v_ru_24x_242_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam3_clo)})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    HEFF_LAST return g_co_2eop_24s535099379x685970669(v_t_2432, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam4, 1, 2, (V[]){v_hd_240, v_k_241}));
  }
  default: return heff_nomatch(v_x_242);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2411);
  V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_str0), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam3(V self, V *args) {
  V v_s_2426 = args[0];
  return v_s_2426;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_st_2434;
  if (heff_strEq_c(v_x_2433, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_str1))) {
    v_st_2434 = NTAG(TAG_Windows);
  } else {
    v_st_2434 = NTAG(TAG_Posix);
  }
  V v_t_2435 = (g_heff_2ebuild_2ecommands_2ebuildTarget(heff_dup(v_st_2434), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_str2)));
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186(v_st_2434, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_str3), v_t_2435, v_hd_240, v_k_241));
}