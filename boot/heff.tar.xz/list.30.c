// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ATail 47533
#define TAG_At 8900
#define TAG_AtLeast0 52203
#define TAG_AtVar 7142
#define TAG_AtWord 2344
#define TAG_BadFieldDecl 11244
#define TAG_BadVariant 54613
#define TAG_Below 46697
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_CDrop 58400
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Element 14172
#define TAG_Flat 38290
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_Nest 8345
#define TAG_Often 32846
#define TAG_Pinned 8573
#define TAG_SError 24172
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetPath 11095
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_again 294104954
#define LBL_alias 294261354
#define LBL_by 9918
#define LBL_code 9554612
#define LBL_deps 9575179
#define LBL_doc 309170
#define LBL_e 319
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_library 398066429
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_note 9882809
#define LBL_path 9928940
#define LBL_refs 9991943
#define LBL_renames 1324191545
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
V g_heff_2ebuild_2edriver_2elistedName(V);
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistedName_clo;
V g_heff_2ecompile_2efields_2ekeptOf(V, V, V);
V g_heff_2ecompile_2efields_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2ekeptOf_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_clo;
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(V, V);
V g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073_clo;
V g_heff_2esyntax_2eimport_2espaces(V);
V g_heff_2esyntax_2eimport_2espaces_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2espaces_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2eany_24s1116296567x1614305171(V);
V g_list_2eany_24s1116296567x1614305171_entry(V self, V *a);
extern Clo g_list_2eany_24s1116296567x1614305171_clo;
V g_list_2eany_24s1119435717x162862967(V, V, V);
V g_list_2eany_24s1119435717x162862967_entry(V self, V *a);
extern Clo g_list_2eany_24s1119435717x162862967_clo;
V g_list_2eany_24s1137631697x622554211(V, V);
V g_list_2eany_24s1137631697x622554211_entry(V self, V *a);
extern Clo g_list_2eany_24s1137631697x622554211_clo;
V g_list_2eany_24s1520931887x1308972177(V, V, V, V, V, V, V, V);
V g_list_2eany_24s1520931887x1308972177_entry(V self, V *a);
extern Clo g_list_2eany_24s1520931887x1308972177_clo;
V g_list_2eany_24s1647905307x479485423(V);
V g_list_2eany_24s1647905307x479485423_entry(V self, V *a);
extern Clo g_list_2eany_24s1647905307x479485423_clo;
V g_list_2eany_24s1685012089x57712328(V);
V g_list_2eany_24s1685012089x57712328_entry(V self, V *a);
extern Clo g_list_2eany_24s1685012089x57712328_clo;
V g_list_2eany_24s1687778528x1571134043(V, V);
V g_list_2eany_24s1687778528x1571134043_entry(V self, V *a);
extern Clo g_list_2eany_24s1687778528x1571134043_clo;
V g_list_2eany_24s1874753421x1382718931(V, V, V);
V g_list_2eany_24s1874753421x1382718931_entry(V self, V *a);
extern Clo g_list_2eany_24s1874753421x1382718931_clo;
V g_list_2eascending_24s1053575971x1138989897(V, V, V);
V g_list_2eascending_24s1053575971x1138989897_entry(V self, V *a);
extern Clo g_list_2eascending_24s1053575971x1138989897_clo;
V g_list_2ecollapse_24s2033985552x1651472209(V, V);
V g_list_2ecollapse_24s2033985552x1651472209_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s2033985552x1651472209_clo;
V g_list_2edescending_24s136597790x1673774577(V, V, V);
V g_list_2edescending_24s136597790x1673774577_entry(V self, V *a);
extern Clo g_list_2edescending_24s136597790x1673774577_clo;
V g_list_2efind_24s1498631415x1735266116(V, V);
V g_list_2efind_24s1498631415x1735266116_entry(V self, V *a);
extern Clo g_list_2efind_24s1498631415x1735266116_clo;
HeffT2 g_list_2efind_24s1498631415x1735266116_24cpr(V, V);
HeffT2 g_list_2efind_24s1702704581x1717241719_24cpr(V);
V g_list_2efoldl_24f1805635826x1386625471(V, V, V);
V g_list_2efoldl_24f1805635826x1386625471_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1805635826x1386625471_clo;
V g_list_2efoldl_24f811568015x381874646(V, V, V, V);
V g_list_2efoldl_24f811568015x381874646_entry(V self, V *a);
extern Clo g_list_2efoldl_24f811568015x381874646_clo;
V g_list_2efoldl_24s1694506840x958926808(V, V);
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1694506840x958926808_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s198101905x967505038(V, V, V, V);
V g_list_2efoldl_24s198101905x967505038_entry(V self, V *a);
extern Clo g_list_2efoldl_24s198101905x967505038_clo;
V g_list_2efoldl_24s947555161x768980202(V, V);
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947555161x768980202_clo;
V g_list_2efoldl_24s963266017x1719814548(V, V);
V g_list_2efoldl_24s963266017x1719814548_entry(V self, V *a);
extern Clo g_list_2efoldl_24s963266017x1719814548_clo;
V g_list_2ekeepIf_24dps(V, V, V);
V g_list_2ekeepIf_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24dps_clo;
V g_list_2ekeepIf_24f1428084847x1450173891(V, V);
V g_list_2ekeepIf_24f1428084847x1450173891_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1428084847x1450173891_clo;
V g_list_2ekeepIf_24f1428084847x1450173891_24dps(V, V, V);
V g_list_2ekeepIf_24f1428084847x1450173891_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1428084847x1450173891_24dps_clo;
V g_list_2ekeepIf_24s14815453x1234467625(V, V, V, V);
V g_list_2ekeepIf_24s14815453x1234467625_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s14815453x1234467625_clo;
V g_list_2ekeepIf_24s14815453x1234467625_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s14815453x1234467625_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s14815453x1234467625_24dps_clo;
V g_list_2ekeepIf_24s1491357071x1050483543_24dps(V, V, V);
V g_list_2ekeepIf_24s1491357071x1050483543_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1491357071x1050483543_24dps_clo;
V g_list_2ekeepIf_24s1615580983x376857327(V);
V g_list_2ekeepIf_24s1615580983x376857327_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1615580983x376857327_clo;
V g_list_2ekeepIf_24s1615580983x376857327_24dps(V, V);
V g_list_2ekeepIf_24s1615580983x376857327_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1615580983x376857327_24dps_clo;
V g_list_2ekeepIf_24s1943838498x1969994910_24dps(V, V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_24dps_clo;
V g_list_2ekeepIf_24s403268044x1108109324(V, V);
V g_list_2ekeepIf_24s403268044x1108109324_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s403268044x1108109324_clo;
V g_list_2ekeepIf_24s403268044x1108109324_24dps(V, V, V);
V g_list_2ekeepIf_24s403268044x1108109324_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s403268044x1108109324_24dps_clo;
V g_list_2ekeepIf_24s44384897x1267641110(V);
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_clo;
V g_list_2ekeepIf_24s44384897x1267641110_24dps(V, V);
V g_list_2ekeepIf_24s44384897x1267641110_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_24dps_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1559388374x681683417(V, V, V, V);
V g_list_2emap_24f1559388374x681683417_entry(V self, V *a);
extern Clo g_list_2emap_24f1559388374x681683417_clo;
V g_list_2emap_24f1559388374x681683417_24dps(V, V, V, V, V);
V g_list_2emap_24f1559388374x681683417_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1559388374x681683417_24dps_clo;
V g_list_2emap_24f755592795x444686035_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f755592795x444686035_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f755592795x444686035_24dps_clo;
V g_list_2emap_24s1341404685x1564972929_24dps(V, V);
V g_list_2emap_24s1341404685x1564972929_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_24dps_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s137457135x961689574_24dps(V, V);
V g_list_2emap_24s137457135x961689574_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_24dps_clo;
V g_list_2emap_24s1611344417x463861413_24dps(V, V, V, V);
V g_list_2emap_24s1611344417x463861413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1611344417x463861413_24dps_clo;
V g_list_2emap_24s1681408447x1763680441(V, V, V);
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_clo;
V g_list_2emap_24s1681408447x1763680441_24dps(V, V, V, V);
V g_list_2emap_24s1681408447x1763680441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_24dps_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24dps(V, V);
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24dps_clo;
V g_list_2emap_24s1816200867x1876638332(V);
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_clo;
V g_list_2emap_24s1816200867x1876638332_24dps(V, V);
V g_list_2emap_24s1816200867x1876638332_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_24dps_clo;
V g_list_2emap_24s1975257801x764827799_24dps(V, V);
V g_list_2emap_24s1975257801x764827799_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_24dps_clo;
V g_list_2emap_24s1992667171x110340492_24dps(V, V);
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_24dps_clo;
V g_list_2emap_24s2139359291x1524787922(V);
V g_list_2emap_24s2139359291x1524787922_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_clo;
V g_list_2emap_24s2139359291x1524787922_24dps(V, V);
V g_list_2emap_24s2139359291x1524787922_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_24dps_clo;
V g_list_2emap_24s244350250x1728178626_24dps(V, V);
V g_list_2emap_24s244350250x1728178626_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_24dps_clo;
V g_list_2emap_24s384717234x223264907_24dps(V, V, V);
V g_list_2emap_24s384717234x223264907_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s384717234x223264907_24dps_clo;
V g_list_2emap_24s409254358x573963502_24dps(V, V);
V g_list_2emap_24s409254358x573963502_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s409254358x573963502_24dps_clo;
V g_list_2emap_24s501902900x1631592417_24dps(V, V, V, V, V);
V g_list_2emap_24s501902900x1631592417_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s501902900x1631592417_24dps_clo;
V g_list_2emap_24s704486313x1071100879(V, V, V, V);
V g_list_2emap_24s704486313x1071100879_entry(V self, V *a);
extern Clo g_list_2emap_24s704486313x1071100879_clo;
V g_list_2emap_24s704486313x1071100879_24dps(V, V, V, V, V);
V g_list_2emap_24s704486313x1071100879_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s704486313x1071100879_24dps_clo;
V g_list_2emap_24s97919758x216970748(V, V);
V g_list_2emap_24s97919758x216970748_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_clo;
V g_list_2emap_24s97919758x216970748_24dps(V, V, V);
V g_list_2emap_24s97919758x216970748_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_24dps_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s655705766x180835539(V, V);
V g_list_2emergeRuns_24s655705766x180835539_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s655705766x180835539_clo;
V g_list_2epushRun_24s2109226209x1912152293(V, V, V);
V g_list_2epushRun_24s2109226209x1912152293_entry(V self, V *a);
extern Clo g_list_2epushRun_24s2109226209x1912152293_clo;
V g_list_2esortOn_24s227026999x1111027886(V);
V g_list_2esortOn_24s227026999x1111027886_entry(V self, V *a);
extern Clo g_list_2esortOn_24s227026999x1111027886_clo;
V g_list_2ezipWith_24s1200852x585902530(V, V, V, V);
V g_list_2ezipWith_24s1200852x585902530_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1200852x585902530_clo;
V g_list_2ezipWith_24s1200852x585902530_24dps(V, V, V, V, V);
V g_list_2ezipWith_24s1200852x585902530_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1200852x585902530_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_list_2ekeepIf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24dps_entry, 3, 0};

V g_list_2ekeepIf_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_247;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s2139359291x1524787922_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2139359291x1524787922_entry, 1, 0};

V g_list_2emap_24s2139359291x1524787922(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, NTAG(TAG_Nil)});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s2139359291x1524787922_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2139359291x1524787922_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2139359291x1524787922(a[0]);
}
V g_list_2emap_24s97919758x216970748_lam0(V self, V *args);
Clo g_list_2emap_24s97919758x216970748_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s97919758x216970748_entry, 2, 0};

V g_list_2emap_24s97919758x216970748(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2435;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_sp_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_TagVariant: {
        V v_t_248 = heff_field(v_x21_246, 0);
        V v_tsp_249 = heff_field(v_x21_246, 1);
        V v_args_2410 = heff_field(v_x21_246, 2);
        V v_ru_24x21_246_24TagVariant = heff_take_reuse_n(v_x21_246, 7ULL, 3);
        V v_t_2422 = (g_list_2emap(heff_clo_n(g_list_2emap_24s97919758x216970748_lam0, 1, 1, (V[]){v_r_244}), v_args_2410));
        v_t_2435 = heff_tag_re_n(v_ru_24x2_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_246_24TagVariant, TAG_TagVariant, 3, 3ULL, (V[]){v_t_248, v_tsp_249, v_t_2422}), v_sp_247});
        break;
      }
      case TAG_BadVariant: {
        V v_e_2423 = heff_field(v_x21_246, 0);
        V v_ru_24x21_246_24BadVariant = heff_take_reuse_n(v_x21_246, 1ULL, 1);
        V v_x1_2424 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2423}));
        V v_t_2434;
        switch (heff_tag_of(v_x1_2424)) {
        case TAG_IsInferable: {
          V v_i_2425 = heff_field(v_x1_2424, 0);
          V v_ru_24x1_2424_24IsInferable = heff_take_reuse_n(v_x1_2424, 1ULL, 1);
          V v_t_2428;
          switch (heff_tag_of(v_i_2425)) {
          case TAG_At: {
            V v_s_2427 = heff_dup(heff_field(v_i_2425, 1));
            v_t_2428 = v_s_2427;
            break;
          }
          default: heff_nomatch(v_i_2425);
          }
          v_t_2434 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2424_24IsInferable, TAG_TInf, 1, (V[]){v_i_2425}), v_t_2428});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2429 = heff_field(v_x1_2424, 0);
          V v_ru_24x1_2424_24IsCheckable = heff_take_reuse_n(v_x1_2424, 1ULL, 1);
          V v_t_2432;
          switch (heff_tag_of(v_c_2429)) {
          case TAG_At: {
            V v_s_2431 = heff_dup(heff_field(v_c_2429, 1));
            v_t_2432 = v_s_2431;
            break;
          }
          default: heff_nomatch(v_c_2429);
          }
          v_t_2434 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2424_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2429}), v_t_2432});
          break;
        }
        case TAG_IsType: {
          V v_t_2433 = heff_field(v_x1_2424, 0);
          heff_take_n(v_x1_2424, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_245_24At, 2);
          v_t_2434 = v_t_2433;
          break;
        }
        default: heff_nomatch(v_x1_2424);
        }
        v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_246_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2434}), v_sp_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2436 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2435, heff_hole()});
    V v_u_2437 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_2436; V r_ = (g_list_2emap_24s97919758x216970748_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_2437);
    return v_cell_2436;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s97919758x216970748_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s97919758x216970748(a[0], a[1]);
}
V g_list_2emap_24s97919758x216970748_lam0(V self, V *args) {
  V v_e_2411 = args[0];
  V v_r_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2412 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_e_2411}));
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_IsInferable: {
    V v_i_2413 = heff_field(v_x1_2412, 0);
    V v_ru_24x1_2412_24IsInferable = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
    V v_t_2416;
    switch (heff_tag_of(v_i_2413)) {
    case TAG_At: {
      V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
      v_t_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_i_2413);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2412_24IsInferable, TAG_TInf, 1, (V[]){v_i_2413}), v_t_2416});
  }
  case TAG_IsCheckable: {
    V v_c_2417 = heff_field(v_x1_2412, 0);
    V v_ru_24x1_2412_24IsCheckable = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_c_2417)) {
    case TAG_At: {
      V v_s_2419 = heff_dup(heff_field(v_c_2417, 1));
      v_t_2420 = v_s_2419;
      break;
    }
    default: heff_nomatch(v_c_2417);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2412_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2417}), v_t_2420});
  }
  case TAG_IsType: {
    V v_t_2421 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    return v_t_2421;
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
Clo g_list_2emap_24s137457135x961689574_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s137457135x961689574_entry, 1, 0};

V g_list_2emap_24s137457135x961689574(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2422;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_SetPath: {
        V v_path_246 = heff_field(v_x21_244, 0);
        V v_e_247 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24SetPath = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        HeffT3 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_247));
        {
          V v_field_2410 = v_t_248.f[1];
          V v_field_2411 = v_t_248.f[2];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          V v_t_2421;
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_c_2412 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
            v_t_2421 = v_c_2412;
          } else {
            if ((v_tag_249 == ((int64_t)1ULL))) {
              V v_i_2413 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
              V v_t_2416;
              switch (heff_tag_of(v_i_2413)) {
              case TAG_At: {
                V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
                v_t_2416 = v_s_2415;
                break;
              }
              default: heff_nomatch(v_i_2413);
              }
              v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2413}), v_t_2416});
            } else {
              V v_t_2417 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
              V v_t_2420;
              switch (heff_tag_of(v_t_2417)) {
              case TAG_At: {
                V v_s_2419 = heff_dup(heff_field(v_t_2417, 1));
                v_t_2420 = v_s_2419;
                break;
              }
              default: heff_nomatch(v_t_2417);
              }
              v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2417}), v_t_2420});
            }
          }
          v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_244_24SetPath, TAG_SetPath, 2, 1ULL, (V[]){v_path_246, v_t_2421}), v_sp_245});
        }
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
    V v_u_2424 = (g_list_2emap_24s137457135x961689574_24dps(v_xs_242, v_cell_2423));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s137457135x961689574_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s137457135x961689574(a[0]);
}
Clo g_list_2emap_24s1992667171x110340492_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1992667171x110340492_24dps_entry, 2, 0};

V g_list_2emap_24s1992667171x110340492_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_x2_246 = v_a_244;
      V v_t_2424;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_DeclareField: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_sp_248 = heff_field(v_x2_246, 1);
        V v_t_249 = heff_field(v_x2_246, 2);
        V v_d_2410 = heff_field(v_x2_246, 3);
        V v_ru_24x2_246_24DeclareField = heff_take_reuse_n(v_x2_246, 15ULL, 4);
        V v_t_2413;
        switch (heff_tag_of(v_t_249)) {
        case TAG_At: {
          V v_n_2411 = heff_field(v_t_249, 0);
          V v_sp_2412 = heff_field(v_t_249, 1);
          V v_ru_24t_249_24At = heff_take_reuse_n(v_t_249, 3ULL, 2);
          v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_249_24At, v_sp_2412, v_n_2411));
          break;
        }
        default: heff_nomatch(v_t_249);
        }
        V v_t_2419;
        switch (heff_tag_of(v_d_2410)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x_242_24At, 2);
          v_t_2419 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x_2414 = heff_field(v_d_2410, 0);
          V v_ru_24d_2410_24Just = heff_take_reuse_n(v_d_2410, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_x_2414)) {
          case TAG_At: {
            V v_n_2415 = heff_field(v_x_2414, 0);
            V v_sp_2416 = heff_field(v_x_2414, 1);
            heff_take_n(v_x_2414, 3ULL, 2);
            V v_t_2417 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2415));
            v_t_2418 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2417, v_sp_2416});
            break;
          }
          default: heff_nomatch(v_x_2414);
          }
          v_t_2419 = heff_tag_at_n(v_ru_24d_2410_24Just, TAG_Just, 1, (V[]){v_t_2418});
          break;
        }
        default: heff_nomatch(v_d_2410);
        }
        v_t_2424 = heff_tag_re_n(v_ru_24x2_246_24DeclareField, TAG_DeclareField, 4, 3ULL, (V[]){v_x_247, v_sp_248, v_t_2413, v_t_2419});
        break;
      }
      case TAG_BadFieldDecl: {
        V v_e_2420 = heff_field(v_x2_246, 0);
        V v_ru_24x2_246_24BadFieldDecl = heff_take_reuse_n(v_x2_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        V v_t_2423;
        switch (heff_tag_of(v_e_2420)) {
        case TAG_At: {
          V v_n_2421 = heff_field(v_e_2420, 0);
          V v_sp_2422 = heff_field(v_e_2420, 1);
          V v_ru_24e_2420_24At = heff_take_reuse_n(v_e_2420, 3ULL, 2);
          v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24e_2420_24At, v_sp_2422, v_n_2421));
          break;
        }
        default: heff_nomatch(v_e_2420);
        }
        v_t_2424 = heff_tag_at_n(v_ru_24x2_246_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2423});
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2426);
    V t_0 = v_xs_243;
    V t_1 = v_u_2427;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1992667171x110340492_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1992667171x110340492_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s244350250x1728178626_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s244350250x1728178626_24dps_entry, 2, 0};

V g_list_2emap_24s244350250x1728178626_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkAlt = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2411;
        switch (heff_tag_of(v_a_247)) {
        case TAG_At: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_a_249 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 3ULL, 2);
          V v_t_2410 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_248));
          v_t_2411 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2410, v_a_249});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        v_t_2412 = heff_tag_re_n(v_ru_24a_244_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_a_246, v_t_2411});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2414);
    V t_0 = v_xs_243;
    V t_1 = v_u_2415;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s244350250x1728178626_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s244350250x1728178626_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1735038056x329845490_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1735038056x329845490_entry, 2, 0};

V g_list_2efoldl_24s1735038056x329845490(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = ({ V a_0 = v_x_242; V a_1 = v_z_240; V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_z_240); r_; });
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1735038056x329845490(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1694506840x958926808_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1694506840x958926808_entry, 2, 0};

V g_list_2efoldl_24s1694506840x958926808(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2420;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Boxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_BoxedWord: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Element: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Unboxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Literal: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Wants: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Binds: {
      V v_x_2415 = heff_field(v_x_242, 0);
      v_t_2420 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_x_2415, NTAG(TAG_MkUnit)));
      break;
    }
    case TAG_Pinned: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Kept: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Often: {
      v_t_2420 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2420;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1694506840x958926808(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1796125103x644876049_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1796125103x644876049_entry, 1, 0};

V g_list_2emap_24s1796125103x644876049(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1796125103x644876049_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1796125103x644876049(a[0]);
}
Clo g_list_2eany_24s1687778528x1571134043_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1687778528x1571134043_entry, 2, 0};

V g_list_2eany_24s1687778528x1571134043(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_intEq_c_lent(v_t_246, v_lit_240, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1687778528x1571134043_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1687778528x1571134043(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1341404685x1564972929_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1341404685x1564972929_24dps_entry, 2, 0};

V g_list_2emap_24s1341404685x1564972929_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_245}), heff_tag_n(TAG_ATail, 1, (V[]){v_a_246})});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1341404685x1564972929_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1341404685x1564972929_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s409254358x573963502_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s409254358x573963502_24dps_entry, 2, 0};

V g_list_2emap_24s409254358x573963502_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Flat: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_249 = v_a_244;
      break;
    }
    case TAG_Nest: {
      V v_a_245 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 4);
      v_t_249 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2410);
    V t_0 = v_xs_243;
    V t_1 = v_u_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s409254358x573963502_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s409254358x573963502_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1874753421x1382718931_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1874753421x1382718931_entry, 3, 0};

V g_list_2eany_24s1874753421x1382718931(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = (g_heff_2ecompile_2efields_2ekeptOf(v_lit_240, v_lit_241, v_x_243));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s1874753421x1382718931_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2eany_24s1874753421x1382718931(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2eany_24s1685012089x57712328_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1685012089x57712328_entry, 1, 0};

V g_list_2eany_24s1685012089x57712328(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2445;
    switch (heff_tag_of(v_t_245)) {
    case TAG_EVar: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_245, 0ULL, 3);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_245, 0ULL, 4);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      V v_a_2422 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 3);
      v_t_2445 = ({ V a_0 = v_a_2422; V r_ = (g_list_2eany_24s1647905307x479485423(a_0)); heff_drop(v_a_2422); r_; });
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_t_245, 0ULL, 3);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2445);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1685012089x57712328_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1685012089x57712328(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s403268044x1108109324_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s403268044x1108109324_entry, 2, 0};

V g_list_2ekeepIf_24s403268044x1108109324(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2416;
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      v_t_2416 = NTAG(TAG_True);
    } else {
      V v_t_2418;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_248 = heff_dup(heff_field(v_x_242, 1));
        v_t_2418 = v_a_248;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2416 = heff_strEq_lent(v_t_2418, v_lit_240, 1);
    }
    V v_t_2412;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      V v_cell_249 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s403268044x1108109324_24dps(v_lit_240, v_xs_243, v_cell_249));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_False: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s403268044x1108109324_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s403268044x1108109324(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efind_24s1498631415x1735266116_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1498631415x1735266116_entry, 2, 0};

V g_list_2efind_24s1498631415x1735266116(V v_lit_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_list_2efind_24s1498631415x1735266116_24cpr(v_lit_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_list_2efind_24s1498631415x1735266116_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2efind_24s1498631415x1735266116(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1491357071x1050483543_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1491357071x1050483543_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1491357071x1050483543_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = heff_bool((heff_strEq_c_lent(v_lit_240, v_a_245, 0) || heff_strEq_c_lent(v_lit_240, v_a_246, 0)));
      heff_drop(v_a_245);
      heff_drop(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (!(heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_cell_248 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1491357071x1050483543_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s1491357071x1050483543_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2eany_24s1119435717x162862967_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1119435717x162862967_entry, 3, 0};

V g_list_2eany_24s1119435717x162862967(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x_243)) {
    case TAG_AtLeast0: {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_Below: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      V v_t_2414;
      switch (heff_tag_of(v_lit_240)) {
      case TAG_AtVar: {
        V v_a_248 = heff_field(v_lit_240, 0);
        switch (heff_tag_of(v_a_246)) {
        case TAG_AtVar: {
          V v_a_249 = heff_field(v_a_246, 0);
          v_t_2414 = heff_bool(heff_strEq_c_lent(v_a_248, v_a_249, 0));
          break;
        }
        case TAG_AtWord: {
          v_t_2414 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      case TAG_AtWord: {
        V v_a_2411 = heff_field(v_lit_240, 0);
        switch (heff_tag_of(v_a_246)) {
        case TAG_AtVar: {
          v_t_2414 = NTAG(TAG_False);
          break;
        }
        case TAG_AtWord: {
          V v_a_2413 = heff_field(v_a_246, 0);
          v_t_2414 = heff_bool(heff_intEq_c_lent(v_a_2411, v_a_2413, 0));
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_lit_240);
      }
      if (((heff_dup(v_t_2414) == NTAG(TAG_True)) && heff_strEq_c_lent(v_lit_241, v_a_247, 0))) {
        heff_drop(v_t_2414);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2414);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s1119435717x162862967_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2eany_24s1119435717x162862967(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s963266017x1719814548_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s963266017x1719814548_entry, 2, 0};

V g_list_2efoldl_24s963266017x1719814548(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_t_246, 3, 5), v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s963266017x1719814548_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s963266017x1719814548(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2ekeepIf_24s1615580983x376857327_str0, 0, "");
HEFF_LIT(g_list_2ekeepIf_24s1615580983x376857327_str1, 1, "-");
HEFF_LIT(g_list_2ekeepIf_24s1615580983x376857327_str2, 1, " ");
Clo g_list_2ekeepIf_24s1615580983x376857327_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1615580983x376857327_entry, 1, 0};

V g_list_2ekeepIf_24s1615580983x376857327(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if ((heff_strEq_c_lent(v_x_241, ((V)&g_list_2ekeepIf_24s1615580983x376857327_str0), 2) || (heff_strEq_c(heff_strSlice_lent(v_x_241, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_list_2ekeepIf_24s1615580983x376857327_str1)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_list_2ekeepIf_24s1615580983x376857327_str2), v_x_241, MK_INT(0LL), 5))))) {
      V v_cell_243 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_244 = (g_list_2ekeepIf_24s1615580983x376857327_24dps(v_xs_242, v_cell_243));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1615580983x376857327_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1615580983x376857327(a[0]);
}
Clo g_list_2ezipWith_24s1200852x585902530_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1200852x585902530_entry, 4, 0};

V g_list_2ezipWith_24s1200852x585902530(V v_lit_240, V v_lit_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_x3_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      heff_take_n(v_x3_243, 3ULL, 2);
      V v_t_2410;
      switch (heff_tag_of(v_x_244)) {
      case TAG_MkPair: {
        V v_a_248 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 2);
        v_t_2410 = v_a_248;
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, heff_dup(v_lit_240)), heff_intShow(v_y_246));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, heff_dup(v_lit_241)), heff_hole()});
      V v_u_2413 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_xs_245; V a_3 = v_ys_247; V a_4 = v_cell_2412; V r_ = (g_list_2ezipWith_24s1200852x585902530_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ezipWith_24s1200852x585902530_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1200852x585902530(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eany_24s1520931887x1308972177_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1520931887x1308972177_entry, 8, 0};

V g_list_2eany_24s1520931887x1308972177(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_t_2410 = (g_prelude_2esplit_2esplitFrom_240(v_x_248, v_lit_240, heff_dup(v_lit_241), heff_strFind_lent(v_lit_242, v_x_248, v_lit_243, 0), NTAG(TAG_Nil)));
    V v_a_2411 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nil: {
      v_t_2414 = heff_dup(v_lit_244);
      break;
    }
    case TAG_Cons: {
      V v_a_2412 = heff_field(v_a_2411, 0);
      V v_a_2413 = heff_field(v_a_2411, 1);
      heff_take_n(v_a_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = v_lit_245; V a_1 = v_a_2412; V a_2 = v_a_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2413); r_; });
      break;
    }
    default: heff_nomatch(v_a_2411);
    }
    if (heff_strEq_c_lent(v_t_2414, v_lit_246, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2eany_24s1520931887x1308972177_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2eany_24s1520931887x1308972177(a0, a1, a2, a3, a4, a5, a6, a7); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24s947555161x768980202_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s947555161x768980202_entry, 2, 0};

V g_list_2efoldl_24s947555161x768980202(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_sp_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_end_245 = heff_take_field(v_sp_244, 1);
    V v_start_246 = heff_get_n(v_sp_244, 0, 2);
    V v_t_247 = (g_heff_2esyntax_2eimport_2espaces(heff_intSub_lent(v_end_245, v_start_246, 0)));
    V v_t_248 = heff_strAppend(heff_strSlice_lent(v_z_240, MK_INT(0LL), v_start_246, 6), v_t_247);
    V v_t_249 = heff_strSlice(heff_dup(v_z_240), v_end_245, heff_strLength(v_z_240));
    V t_0 = heff_strAppend(v_t_248, v_t_249);
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s947555161x768980202_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s947555161x768980202(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1116296567x1614305171_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1116296567x1614305171_entry, 1, 0};

V g_list_2eany_24s1116296567x1614305171(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SegmentInteger: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SegmentBinary: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SegmentBits: {
      return NTAG(TAG_True);
    }
    case TAG_SegmentFloat: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SegmentUtf: {
      heff_take_n(v_t_243, 0ULL, 1);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1116296567x1614305171_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1116296567x1614305171(a0); heff_drop(a0); return r;
}
V g_list_2ekeepIf_24s14815453x1234467625_lam0(V self, V *args);
Clo g_list_2ekeepIf_24s14815453x1234467625_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s14815453x1234467625_entry, 4, 0};

V g_list_2ekeepIf_24s14815453x1234467625(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_done_246 = heff_dup(v_lit_240);
    V v_imps_247 = heff_dup(v_lit_241);
    V v_c_248 = heff_dup(v_lit_242);
    V v_t_249 = heff_dup(v_x_244);
    V v_again_2410 = heff_take_field(v_t_249, 1);
    V v_first_2411 = heff_get_n(v_t_249, 0, 2);
    V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_again_2410, 1)), 0, 14);
    V v_t_2434;
    if (heff_strEq_c(v_t_2412, heff_get_n(v_c_248, 0, 14))) {
      heff_drop(v_done_246);
      heff_drop_rec(v_imps_247, 4);
      heff_drop_rec(v_again_2410, 3);
      heff_drop_rec(v_first_2411, 3);
      v_t_2434 = NTAG(TAG_True);
    } else {
      V v_x1_2433 = ({ V b_0 = heff_clo_n(g_list_2ekeepIf_24s14815453x1234467625_lam0, 1, 3, (V[]){v_done_246, v_first_2411, v_again_2410}); V b_1 = heff_get_n(v_imps_247, 0, 4); V r_ = (g_list_2eany(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      v_t_2434 = heff_bool(!(heff_dup(v_x1_2433) == NTAG(TAG_True)));
      heff_drop(v_x1_2433);
    }
    if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
      heff_drop(v_t_2434);
      V v_cell_2435 = heff_tag_re_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, heff_hole()});
      V v_u_2436 = (g_list_2ekeepIf_24s14815453x1234467625_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, v_cell_2435));
      heff_drop(v_u_2436);
      return v_cell_2435;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_2434);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s14815453x1234467625_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s14815453x1234467625(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_list_2ekeepIf_24s14815453x1234467625_lam0(V self, V *args) {
  V v_i_2413 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_first_2411 = heff_env(self)[1];
  V v_again_2410 = heff_env(self)[2];
  V v_t_2414 = heff_dup(heff_rfield(v_i_2413, 0));
  HeffT2 v_t_2415 = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(v_done_246, v_t_2414));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_ys_2419;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_c_2418 = v_field_2417;
      v_ys_2419 = heff_get_n(v_c_2418, 8, 14);
    } else {
      heff_drop(v_field_2417);
      v_ys_2419 = NTAG(TAG_Nil);
    }
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
    V v_t_2421 = (g_heff_2ebuild_2edriver_2eclosureGo(v_done_246, v_t_2420, v_ys_2419));
    heff_clo_take(self, 3);
    V v_t_2422 = heff_get_n(heff_get_n(v_first_2411, 1, 3), 0, 14);
    V v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_t_2421; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_2422); heff_drop(v_t_2421); r_; });
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_t_2423);
      V v_t_2424 = heff_get_n(v_i_2413, 0, 3);
      HeffT2 v_t_2425 = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(v_done_246, v_t_2424));
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        V v_ys_2429;
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_c_2428 = v_field_2427;
          v_ys_2429 = heff_get_n(v_c_2428, 8, 14);
        } else {
          heff_drop(v_field_2427);
          v_ys_2429 = NTAG(TAG_Nil);
        }
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        V v_t_2431 = ({ V a_0 = v_done_246; V a_1 = v_t_2430; V a_2 = v_ys_2429; V r_ = (g_heff_2ebuild_2edriver_2eclosureGo(a_0, a_1, a_2)); heff_drop(v_done_246); r_; });
        V v_t_2432 = heff_get_n(heff_get_n(v_again_2410, 1, 3), 0, 14);
        return ({ V a_0 = v_t_2432; V a_1 = v_t_2431; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_2432); heff_drop(v_t_2431); r_; });
      }
    } else {
      heff_drop_rec(v_i_2413, 3);
      heff_drop(v_done_246);
      heff_drop_rec(v_again_2410, 3);
      heff_drop(v_t_2423);
      return NTAG(TAG_False);
    }
  }
}
Clo g_list_2emap_24s704486313x1071100879_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s704486313x1071100879_entry, 4, 0};

V g_list_2emap_24s704486313x1071100879(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_module_246 = heff_take_field(v_x_244, 0);
    V v_alias_247 = heff_get_n(v_x_244, 1, 2);
    V v_t_248 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_module_246), heff_dup(v_lit_241));
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_alias_247), heff_dup(v_lit_242));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_245; V a_4 = v_cell_2410; V r_ = (g_list_2emap_24s704486313x1071100879_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s704486313x1071100879_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s704486313x1071100879(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1611344417x463861413_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1611344417x463861413_24dps_entry, 4, 0};

V g_list_2emap_24s1611344417x463861413_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_name_246 = heff_take_field(v_x_244, 0);
    V v_tags_247 = heff_get_n(v_x_244, 1, 3);
    V v_t_248 = (g_heff_2ebuild_2edriver_2elistedName(v_name_246));
    V v_t_249 = v_tags_247;
    V v_t_2410;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2410 = heff_dup(v_lit_240);
    } else {
      heff_drop(v_t_249);
      v_t_2410 = heff_dup(v_lit_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, v_t_2410), heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2411);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1611344417x463861413_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2emap_24s1611344417x463861413_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24s1943838498x1969994910_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1943838498x1969994910_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1943838498x1969994910_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1943838498x1969994910_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s1943838498x1969994910_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emergeRuns_24s655705766x180835539_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s655705766x180835539_entry, 2, 0};

V g_list_2emergeRuns_24s655705766x180835539(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkPair = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s2033985552x1651472209(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      V v_ru_24x32_243_24Cons = heff_take_reuse_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s2109226209x1912152293(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_2412;
      switch (heff_tag_of(v_xs_245)) {
      case TAG_Nil: {
        V v_t_247 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
        v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_y_248 = heff_field(v_xs_245, 0);
        V v_ys_249 = heff_field(v_xs_245, 1);
        V v_ru_24xs_245_24Cons = heff_take_reuse_n(v_xs_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
        if (heff_intLe_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(heff_rfield(v_y_248, 0)))) {
          V v_t_2410 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2412 = (g_list_2eascending_24s1053575971x1138989897(heff_dup(v_y_248), heff_tag_re_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_248, v_t_2410}), v_ys_249));
        } else {
          V v_t_2411 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2412 = (g_list_2edescending_24s136597790x1673774577(heff_dup(v_y_248), heff_tag_re_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_248, v_t_2411}), v_ys_249));
        }
        break;
      }
      default: heff_nomatch(v_xs_245);
      }
      V t_0 = v_t_246;
      V t_1 = v_t_2412;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s655705766x180835539_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s655705766x180835539(a[0], a[1]);
}
Clo g_list_2esortOn_24s227026999x1111027886_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortOn_24s227026999x1111027886_entry, 1, 0};

V g_list_2esortOn_24s227026999x1111027886(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_xs_242)) {
    case TAG_Nil: {
      V v_t_243 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, NTAG(TAG_Nil)});
      v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_xs_242, 0);
      V v_ys_245 = heff_field(v_xs_242, 1);
      V v_ru_24xs_242_24Cons = heff_take_reuse_n(v_xs_242, 3ULL, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_241, 0)), heff_dup(heff_rfield(v_y_244, 0)))) {
        V v_t_246 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, NTAG(TAG_Nil)});
        v_t_248 = (g_list_2eascending_24s1053575971x1138989897(heff_dup(v_y_244), heff_tag_re_n(v_ru_24xs_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_244, v_t_246}), v_ys_245));
      } else {
        V v_t_247 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, NTAG(TAG_Nil)});
        v_t_248 = (g_list_2edescending_24s136597790x1673774577(heff_dup(v_y_244), heff_tag_re_n(v_ru_24xs_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_244, v_t_247}), v_ys_245));
      }
      break;
    }
    default: heff_nomatch(v_xs_242);
    }
    return (g_list_2emergeRuns_24s655705766x180835539(NTAG(TAG_Nil), v_t_248));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2esortOn_24s227026999x1111027886_entry(V self, V *a) {
  (void)self;
  return g_list_2esortOn_24s227026999x1111027886(a[0]);
}
Clo g_list_2emap_24s384717234x223264907_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s384717234x223264907_24dps_entry, 3, 0};

V g_list_2emap_24s384717234x223264907_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_245 = heff_take_field(v_x_243, 0);
    V v_span_246 = heff_get_n(v_x_243, 1, 2);
    V v_a_247 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_name_245)}), NTAG(TAG_Nothing)});
    V v_a_248 = v_name_245;
    V v_a_249 = v_span_246;
    V v_a_2410 = heff_take_field(v_a_249, 0);
    V v_a_2411 = heff_intSub(heff_dup(heff_rfield(v_a_249, 1)), heff_strLength_lent(v_a_248, 0));
    V v_t_2412;
    if (heff_intLe_c_lent(v_a_2410, v_a_2411, 0)) {
      heff_drop(v_a_2410);
      v_t_2412 = v_a_2411;
    } else {
      heff_drop(v_a_2411);
      v_t_2412 = v_a_2410;
    }
    V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_a_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_a_247, v_a_248, v_t_2413}), heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2414);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2415;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s384717234x223264907_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s384717234x223264907_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}

HeffT2 g_list_2efind_24s1702704581x1717241719_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 1, 3);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_241)}});
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_t_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_list_2emap_24s1975257801x764827799_24dps_str0, 1, "(");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_24dps_str1, 1, ")");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_24dps_str2, 1, "(");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_24dps_str3, 1, ")");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_24dps_str4, 1, "(");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_24dps_str5, 1, ")");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_24dps_str6, 4, "(..)");
HEFF_LIT(g_list_2emap_24s1975257801x764827799_24dps_str7, 0, "");
Clo g_list_2emap_24s1975257801x764827799_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1975257801x764827799_24dps_entry, 2, 0};

V g_list_2emap_24s1975257801x764827799_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_e_244 = v_x_242;
    V v_name_245 = heff_take_field(v_e_244, 0);
    V v_tags_246 = heff_get_n(v_e_244, 1, 3);
    V v_x_247 = heff_dup(v_name_245);
    V v_t_249;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_247, 0)))) {
      if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_247, MK_INT(0LL), 2))) ? !(heff_unbox_word(heff_strByteAt_lent(v_x_247, MK_INT(0LL), 2)) <= ((int64_t)57ULL)) : 1)) {
        V v_t_248 = ({ V a_0 = v_x_247; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2eimport_2eallChars_24s55697496x86991073(a_0, a_1)); heff_drop(v_x_247); r_; });
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_249 = v_name_245;
        } else {
          heff_drop(v_t_248);
          v_t_249 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1975257801x764827799_24dps_str0), v_name_245), ((V)&g_list_2emap_24s1975257801x764827799_24dps_str1));
        }
      } else {
        heff_drop(v_x_247);
        v_t_249 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1975257801x764827799_24dps_str2), v_name_245), ((V)&g_list_2emap_24s1975257801x764827799_24dps_str3));
      }
    } else {
      heff_drop(v_x_247);
      v_t_249 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1975257801x764827799_24dps_str4), v_name_245), ((V)&g_list_2emap_24s1975257801x764827799_24dps_str5));
    }
    V v_t_2410 = v_tags_246;
    V v_t_2411;
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      v_t_2411 = ((V)&g_list_2emap_24s1975257801x764827799_24dps_str6);
    } else {
      heff_drop(v_t_2410);
      v_t_2411 = ((V)&g_list_2emap_24s1975257801x764827799_24dps_str7);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, v_t_2411), heff_hole()});
    V v_u_2413 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2412);
    V t_0 = v_xs_243;
    V t_1 = v_u_2413;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1975257801x764827799_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1975257801x764827799_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1092144743x1559898298_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1092144743x1559898298_entry, 1, 0};

V g_list_2eany_24s1092144743x1559898298(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 6));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1092144743x1559898298(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1816200867x1876638332_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1816200867x1876638332_entry, 1, 0};

V g_list_2emap_24s1816200867x1876638332(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1816200867x1876638332_24dps(v_xs_242, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1816200867x1876638332(a[0]);
}
Clo g_list_2emap_24s1681408447x1763680441_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1681408447x1763680441_entry, 3, 0};

V g_list_2emap_24s1681408447x1763680441(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_t_245 = heff_strAppend(heff_take_field(v_x_243, 4), heff_dup(v_lit_241));
      v_t_246 = ({ V rv_4 = v_t_245; V rr_ = heff_rec_reuse_nf(v_x_243, 239ULL, 8, shape_module__named__path__shown__source__renames__implicit__library, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      v_t_246 = v_x_243;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_xs_244; V a_3 = v_cell_247; V r_ = (g_list_2emap_24s1681408447x1763680441_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1681408447x1763680441(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s198101905x967505038_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s198101905x967505038_entry, 4, 0};

V g_list_2efoldl_24s198101905x967505038(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 2)), 0, 2);
    V v_t_247 = heff_strAppend(heff_strSlice_lent(v_z_242, v_lit_240, v_t_246, 4), heff_dup(v_lit_241));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_244, 2)), 1, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_z_242), v_t_248, heff_strLength(v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_strAppend(v_t_247, v_t_249);
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s198101905x967505038_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2efoldl_24s198101905x967505038(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24s44384897x1267641110_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s44384897x1267641110_entry, 1, 0};

V g_list_2ekeepIf_24s44384897x1267641110(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s44384897x1267641110_24dps(v_xs_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_241, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s44384897x1267641110(a[0]);
}
Clo g_list_2emap_24s501902900x1631592417_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s501902900x1631592417_24dps_entry, 5, 0};

V g_list_2emap_24s501902900x1631592417_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_245, 0));
      v_a_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_a_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2413;
    if (heff_strEq_c_lent(v_a_2412, v_lit_240, 0)) {
      heff_drop(v_a_2412);
      v_t_2413 = v_a_249;
    } else {
      v_t_2413 = heff_strAppend(heff_strAppend(v_a_249, heff_dup(v_lit_241)), v_a_2412);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2414);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_u_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s501902900x1631592417_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_list_2emap_24s501902900x1631592417_24dps(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2emap_24f1559388374x681683417_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1559388374x681683417_entry, 4, 0};

V g_list_2emap_24f1559388374x681683417(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = v_x_244; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany_24s1137631697x622554211(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_a_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 2), heff_take_field(v_x_244, 3)});
      V v_t_248 = heff_strAppend(heff_dup(v_lit_241), heff_get_n(v_x_244, 1, 7));
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(v_t_248, heff_dup(v_lit_242)), v_a_247, NTAG(TAG_Nothing)});
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = (g_list_2emap_24f1559388374x681683417_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, v_cell_2410));
      heff_drop(v_u_2411);
      return v_cell_2410;
    } else {
      heff_drop_rec(v_x_244, 7);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1559388374x681683417_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f1559388374x681683417(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f811568015x381874646_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f811568015x381874646_entry, 4, 0};

V g_list_2efoldl_24f811568015x381874646(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_2445;
    switch (heff_tag_of(v_x_244)) {
    case TAG_EVar: {
      V v_a_246 = heff_field(v_x_244, 0);
      v_t_2445 = heff_bool(heff_strEq_c_lent(v_lit_242, v_a_246, 0));
      break;
    }
    case TAG_EGlobal: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      V t_0 = v_lit_240;
      V t_1 = heff_intAdd_lent(v_z_241, v_lit_240, 1);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2445);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f811568015x381874646_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f811568015x381874646(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2ekeepIf_24f1428084847x1450173891_str0, 0, "");
HEFF_LIT(g_list_2ekeepIf_24f1428084847x1450173891_str1, 1, "-");
HEFF_LIT(g_list_2ekeepIf_24f1428084847x1450173891_str2, 1, " ");
Clo g_list_2ekeepIf_24f1428084847x1450173891_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1428084847x1450173891_entry, 2, 0};

V g_list_2ekeepIf_24f1428084847x1450173891(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return (g_list_2ekeepIf_24s1615580983x376857327(heff_dup(v_ys_241)));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if ((heff_strEq_c_lent(v_x_242, ((V)&g_list_2ekeepIf_24f1428084847x1450173891_str0), 2) || (heff_strEq_c(heff_strSlice_lent(v_x_242, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_list_2ekeepIf_24f1428084847x1450173891_str1)) || heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_list_2ekeepIf_24f1428084847x1450173891_str2), v_x_242, MK_INT(0LL), 5))))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24f1428084847x1450173891_24dps(v_xs_243, v_ys_241, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_ys_241;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2ekeepIf_24f1428084847x1450173891_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24f1428084847x1450173891(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1805635826x1386625471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1805635826x1386625471_entry, 3, 0};

V g_list_2efoldl_24f1805635826x1386625471(V v_z_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_245 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_lit_241), heff_dup(v_x_243)));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_lit_241;
    V t_2 = v_xs_244;
    v_z_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1805635826x1386625471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2efoldl_24f1805635826x1386625471(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24f755592795x444686035_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f755592795x444686035_24dps_entry, 7, 0};

V g_list_2emap_24f755592795x444686035_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_246), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_shown_249 = heff_take_field(v_x_247, 2);
    V v_name_2410 = heff_take_field(v_x_247, 0);
    V v_doc_2411 = heff_get_n(v_x_247, 1, 4);
    if (((heff_dup(v_shown_249) == NTAG(TAG_True)) && heff_strEq_c_lent(heff_strSlice_lent(v_name_2410, v_lit_243, heff_strLength_lent(v_lit_244, 0), 4), v_lit_244, 1))) {
      heff_drop(v_shown_249);
      V v_a_2412 = v_name_2410;
      V v_a_2413 = v_doc_2411;
      V v_t_2414;
      if (heff_strEq_c_lent(v_a_2413, v_lit_240, 0)) {
        heff_drop(v_a_2413);
        v_t_2414 = v_a_2412;
      } else {
        v_t_2414 = heff_strAppend(heff_strAppend(v_a_2412, heff_dup(v_lit_241)), v_a_2413);
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2414, heff_dup(v_lit_242)), heff_hole()});
      V v_u_2416 = heff_setFieldPeek(v_d_246, MK_INT(1LL), v_cell_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_u_2416;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_shown_249);
      heff_drop(v_name_2410);
      heff_drop(v_doc_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_d_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f755592795x444686035_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V r = g_list_2emap_24f755592795x444686035_24dps(a0, a1, a2, a3, a4, a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a6); return r;
}