// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT2 g_regex_2ecountAt_2enumberAt_240_24cpr(V, V);
HeffT2 g_regex_2ecountAt_2enumberAt_240_2edigits_241_24cpr(V, V, V);

HeffT2 g_regex_2ecountAt_2enumberAt_240_24cpr(V v_s_240, V v_i_241) {
top: ;
  return (g_regex_2ecountAt_2enumberAt_240_2edigits_241_24cpr(v_s_240, v_i_241, MK_INT(-1LL)));
}