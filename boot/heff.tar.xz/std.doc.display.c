// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SEmpty 4509
#define TAG_SFail 3389
#define TAG_SLine 58919
#define TAG_SText 31624
V g_std_2edoc_2edisplay_2edisplayInto_240(V, V);
V g_std_2edoc_2edisplay_2edisplayInto_240_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplay_2edisplayInto_240_clo;
V g_std_2edoc_2espacesText_2espacesInto_240(V, V);
V g_std_2edoc_2espacesText_2espacesInto_240_entry(V self, V *a);
extern Clo g_std_2edoc_2espacesText_2espacesInto_240_clo;
HEFF_LIT(g_std_2edoc_2edisplay_2edisplayInto_240_str0, 0, "");
HEFF_LIT(g_std_2edoc_2edisplay_2edisplayInto_240_str1, 1, "\012");
Clo g_std_2edoc_2edisplay_2edisplayInto_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2edisplay_2edisplayInto_240_entry, 2, 0};

V g_std_2edoc_2edisplay_2edisplayInto_240(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SEmpty: {
    return v_acc_240;
  }
  case TAG_SFail: {
    return v_acc_240;
  }
  case TAG_SText: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_c_244 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_t_245 = heff_tr(heff_call(v_c_244, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = heff_strAppend(v_acc_240, v_t_242);
    V t_1 = v_t_245;
    v_acc_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SLine: {
    V v_i_246 = heff_field(v_x2_241, 0);
    V v_c_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_248 = (g_std_2edoc_2espacesText_2espacesInto_240(v_i_246, ((V)&g_std_2edoc_2edisplay_2edisplayInto_240_str0)));
    V v_t_249 = heff_tr(heff_call(v_c_247, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_acc_240, ((V)&g_std_2edoc_2edisplay_2edisplayInto_240_str1)), v_t_248);
    V t_0 = v_t_2410;
    V t_1 = v_t_249;
    v_acc_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2edoc_2edisplay_2edisplayInto_240_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2edisplay_2edisplayInto_240(a[0], a[1]);
}