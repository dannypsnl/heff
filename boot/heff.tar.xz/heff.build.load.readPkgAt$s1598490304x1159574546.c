// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_module 878357911
#define LBL_style 311138763
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str1, 15, " cannot be read");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str3, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str4, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str5, 16, " is the package ");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str6, 6, ", not ");
Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0(V v_ps_240, V v_dir_241, V v_path_242, V v_k_243, V v_x_244) {
top: ;
  V v_x_2441;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    V v_ru_24x_244_24Left = heff_take_reuse_n(v_x_244, 0ULL, 1);
    heff_drop(v_path_242);
    V v_st_246 = heff_get_n(v_ps_240, 5, 6);
    V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_246), v_dir_241));
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_246), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str0)));
    V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
    V v_t_2410 = ({ V a_0 = v_st_246; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); heff_drop(v_t_249); r_; });
    v_x_2441 = heff_tag_at_n(v_ru_24x_244_24Left, TAG_Left, 1, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str1))});
    break;
  }
  case TAG_Right: {
    V v_y_2411 = heff_field(v_x_244, 0);
    V v_ru_24x_244_24Right = heff_take_reuse_n(v_x_244, 1ULL, 1);
    HeffT2 v_t_2412 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2411));
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop(v_path_242);
        heff_drop_cell(v_ru_24x_244_24Right, 1);
        V v_p_2415 = v_field_2414;
        V v_st_2416 = heff_get_n(v_ps_240, 5, 6);
        V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_dir_241));
        V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2416), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str2)));
        V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
        V v_t_2420 = ({ V a_0 = v_st_2416; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2419); r_; });
        V v_t_2421 = ({ V a_0 = v_t_2420; V a_1 = v_y_2411; V a_2 = v_p_2415; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2411); r_; });
        v_x_2441 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
      } else {
        V v_x_2422 = v_field_2414;
        HeffT2 v_t_2423 = ({ V a_0 = v_x_2422; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2422); r_; });
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            heff_drop(v_path_242);
            heff_drop_cell(v_ru_24x_244_24Right, 1);
            V v_p_2426 = v_field_2425;
            V v_st_2427 = heff_get_n(v_ps_240, 5, 6);
            V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2427), v_dir_241));
            V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_2427), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str3)));
            V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
            V v_t_2431 = ({ V a_0 = v_st_2427; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2427); heff_drop(v_t_2430); r_; });
            V v_t_2432 = ({ V a_0 = v_t_2431; V a_1 = v_y_2411; V a_2 = v_p_2426; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2411); r_; });
            v_x_2441 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2432});
          } else {
            heff_drop(v_y_2411);
            V v_pk_2433 = v_field_2425;
            if (heff_strEq_c(heff_dup(heff_rfield(v_pk_2433, 0)), heff_dup(v_path_242))) {
              heff_drop_rec(v_ps_240, 6);
              heff_drop(v_dir_241);
              heff_drop(v_path_242);
              v_x_2441 = heff_tag_at_n(v_ru_24x_244_24Right, TAG_Right, 1, (V[]){v_pk_2433});
            } else {
              heff_drop_cell(v_ru_24x_244_24Right, 1);
              V v_st_2434 = heff_get_n(v_ps_240, 5, 6);
              V v_t_2435 = (g_std_2epath_2eparse(heff_dup(v_st_2434), v_dir_241));
              V v_t_2436 = (g_std_2epath_2eparse(heff_dup(v_st_2434), ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str4)));
              V v_t_2437 = (g_std_2epath_2ejoin(v_t_2435, v_t_2436));
              V v_t_2438 = ({ V a_0 = v_st_2434; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2434); heff_drop(v_t_2437); r_; });
              V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str5)), heff_get_n(v_pk_2433, 0, 4));
              V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_str6)), v_path_242);
              v_x_2441 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2440});
            }
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  return heff_tail(v_k_243, 1, (V[]){v_x_2441});
}
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_2ek_24l0(a[0], a[1], a[2], a[3], a[4]);
}