// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EQ 8989
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Expl 20488
#define TAG_ExplicitParam 63083
#define TAG_FuelTick 47424
#define TAG_GT 9054
#define TAG_Impl 63555
#define TAG_ImplicitParam 51130
#define TAG_LT 9209
#define TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply1 1347
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_MkArm 55352
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSmallTyp 41275
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_OfTags 60669
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SetPath 11095
#define TAG_ShapeRecord 31660
#define TAG_ShapeTag 9776
#define TAG_Small 51389
#define TAG_Throw 56084
#define TAG_TopL 65516
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_consumers 1203455020
#define LBL_def 308863
#define LBL_equal 298115918
#define LBL_fresh 299054408
#define LBL_implicit 319715269
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_pats 9928951
#define LBL_producers 572620898
#define LBL_rhs 322423
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_slots 310891087
#define LBL_span 10032145
#define LBL_supply 1056026650
#define LBL_typ 324869
#define LBL_val 326043
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_equal[] = {LBL_equal};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_span__name__typ__implicit[] = {LBL_span, LBL_name, LBL_typ, LBL_implicit};
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2efields_2egoLate(V, V);
V g_heff_2ecompile_2efields_2egoLate_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2egoLate_clo;
V g_heff_2ecompile_2efields_2enumbersW(V, V);
V g_heff_2ecompile_2efields_2enumbersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efields_2enumbersW_clo;
V g_heff_2ecompile_2efuel_2ebatchedBy(V, V, V, V, V, V);
V g_heff_2ecompile_2efuel_2ebatchedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ebatchedBy_clo;
V g_heff_2ecompile_2efuel_2ecloses(V, V);
V g_heff_2ecompile_2efuel_2ecloses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecloses_clo;
V g_heff_2ecompile_2efuel_2ecounted(V, V, V);
V g_heff_2ecompile_2efuel_2ecounted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2ecounted_clo;
V g_heff_2ecompile_2efuel_2eroundsOf(V, V);
V g_heff_2ecompile_2efuel_2eroundsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2eroundsOf_clo;
V g_heff_2ecompile_2efuel_2etickedIn(V, V);
V g_heff_2ecompile_2efuel_2etickedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuel_2etickedIn_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905_clo;
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_heff_2ecompile_2escalars_2edefWith(V, V, V);
V g_heff_2ecompile_2escalars_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2edefWith_clo;
V g_heff_2ecompile_2escalars_2ewithVars(V);
V g_heff_2ecompile_2escalars_2ewithVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewithVars_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopyTake_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152(V);
V g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2eupdatePath(V, V, V);
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_clo;
V g_prelude_2e_2b_2b_24f132290754x1091834184(V, V, V, V);
V g_prelude_2e_2b_2b_24f132290754x1091834184_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f132290754x1091834184_clo;
V g_prelude_2e_2b_2b_24f132290754x1091834184_24dps(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f132290754x1091834184_24dps_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587(V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_clo;
V g_prelude_2e_2b_2b_24f1681798656x925918587_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1681798656x925918587_24dps_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032(V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_24dps_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo;
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_clo;
V g_prelude_2e_2b_2b_24f603353378x1069129212(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f603353378x1069129212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f603353378x1069129212_clo;
V g_prelude_2e_2b_2b_24f603353378x1069129212_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f603353378x1069129212_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f603353378x1069129212_24dps_clo;
V g_prelude_2e_2b_2b_24f658301291x587486003(V, V);
V g_prelude_2e_2b_2b_24f658301291x587486003_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f658301291x587486003_clo;
V g_prelude_2e_2b_2b_24f658301291x587486003_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f658301291x587486003_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f658301291x587486003_24dps_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo;
V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ecompareString(V, V);
V g_prelude_2ecompareString_entry(V self, V *a);
extern Clo g_prelude_2ecompareString_clo;
V g_prelude_2einstanceEqualityString_get(void);
HeffT2 g_prelude_2eparseInt_24cpr(V);
HeffT2 g_prelude_2eparseInt_2edigitsFrom_240_24cpr(V, V, V);
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2etraverse_24s1048254938x1609755296(V, V, V, V);
V g_prelude_2etraverse_24s1048254938x1609755296_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1048254938x1609755296_clo;
HeffT2 g_prelude_2etraverse_24s1048254938x1609755296_24cpr(V, V, V, V);
HeffT2 g_prelude_2etraverse_24s1111575179x1680558317_24cpr(V, V);
V g_prelude_2etraverse_24s1157078602x1175067503(V, V, V);
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1157078602x1175067503_clo;
HeffT2 g_prelude_2etraverse_24s119460564x671287541_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s119460564x671287541_24dps_24cpr(V, V, V);
V g_prelude_2etraverse_24s1211845059x266223635(V);
V g_prelude_2etraverse_24s1211845059x266223635_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1211845059x266223635_clo;
V g_prelude_2etraverse_24s1259852701x334693366(V);
V g_prelude_2etraverse_24s1259852701x334693366_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1259852701x334693366_clo;
V g_prelude_2etraverse_24s1310917876x950458632(V, V);
V g_prelude_2etraverse_24s1310917876x950458632_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1310917876x950458632_clo;
V g_prelude_2etraverse_24s1310917876x950458632_24apply1(V, V);
V g_prelude_2etraverse_24s1310917876x950458632_24apply1_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1310917876x950458632_24apply1_clo;
V g_prelude_2etraverse_24s1310917876x950458632_24apply2(V, V);
V g_prelude_2etraverse_24s1310917876x950458632_24apply2_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1310917876x950458632_24apply2_clo;
V g_prelude_2etraverse_24s1413153166x427060745(V, V, V);
V g_prelude_2etraverse_24s1413153166x427060745_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1413153166x427060745_clo;
HeffT2 g_prelude_2etraverse_24s1483742185x1081287844_24cpr(V);
HeffT2 g_prelude_2etraverse_24s1573855737x392625097_24cpr(V, V);
V g_prelude_2etraverse_24s1700321227x1313876518(V);
V g_prelude_2etraverse_24s1700321227x1313876518_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1700321227x1313876518_clo;
HeffT2 g_prelude_2etraverse_24s1760019503x148599044_24cpr(V, V);
V g_prelude_2etraverse_24s1778157750x1229378888(V);
V g_prelude_2etraverse_24s1778157750x1229378888_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1778157750x1229378888_clo;
HeffT2 g_prelude_2etraverse_24s1778157750x1229378888_24cpr(V);
HeffT2 g_prelude_2etraverse_24s1807059150x502333573_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1989123107x1062793186_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s1989123107x1062793186_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s199930607x121965669_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr(V, V, V, V);
V g_prelude_2etraverse_24s2104983077x351811635(V);
V g_prelude_2etraverse_24s2104983077x351811635_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2104983077x351811635_clo;
V g_prelude_2etraverse_24s277604616x578020818(V);
V g_prelude_2etraverse_24s277604616x578020818_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s277604616x578020818_clo;
HeffT2 g_prelude_2etraverse_24s366524614x1308602553_24cpr(V);
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
HeffT2 g_prelude_2etraverse_24s514944727x707829312_24cpr(V, V);
V g_prelude_2etraverse_24s515579549x140669784(V, V, V);
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s515579549x140669784_clo;
V g_prelude_2etraverse_24s735647865x424372205(V, V);
V g_prelude_2etraverse_24s735647865x424372205_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s735647865x424372205_clo;
HeffT2 g_prelude_2etraverse_24s763866529x146151572_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s763866529x146151572_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s801310267x475583082_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s801310267x475583082_24dps_24scalars_24cpr(V, V, V, V, V, V, V, V);
HeffT2 g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s962837131x1183228870_24cpr(V, V);
HeffT2 g_prelude_2etraverse_24s962837131x1183228870_24dps_24cpr(V, V, V);
HeffT2 g_prelude_2etraverse_24s993801089x502291790_24dps_24cpr(V, V, V);
V g_prelude_2ewithCodePoint(V, V);
V g_prelude_2ewithCodePoint_entry(V self, V *a);
extern Clo g_prelude_2ewithCodePoint_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_strEq_get(void);

static V g_prelude_2einstanceEqualityString_val;
static HEFF_ONCE g_prelude_2einstanceEqualityString_st;
static V g_prelude_2einstanceEqualityString_init(void) {
  return heff_rec_n(1, shape_equal, (V[]){heff_dup(g_strEq_get())});
}
V g_prelude_2einstanceEqualityString_get(void) {
  if (HEFF_DONE(g_prelude_2einstanceEqualityString_st)) return g_prelude_2einstanceEqualityString_val;
  return heff_global(&g_prelude_2einstanceEqualityString_val, &g_prelude_2einstanceEqualityString_st, g_prelude_2einstanceEqualityString_init);
}
Clo g_prelude_2ecompareString_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ecompareString_entry, 2, 0};

V g_prelude_2ecompareString(V v_a_240, V v_b_241) {
top: ;
  V v_a_242 = heff_strCompare_lent(v_a_240, v_b_241, 0);
  if (heff_intLt_c_lent(v_a_242, MK_INT(0LL), 2)) {
    heff_drop(v_a_242);
    return NTAG(TAG_LT);
  } else {
    if (heff_intEq_c(v_a_242, MK_INT(0LL))) {
      return NTAG(TAG_EQ);
    } else {
      return NTAG(TAG_GT);
    }
  }
}
V g_prelude_2ecompareString_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_prelude_2ecompareString(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_prelude_2eparseInt_24cpr_str0, 1, "-");

HeffT2 g_prelude_2eparseInt_24cpr(V v_s_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) == ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_prelude_2eparseInt_24cpr_str0))) {
      if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) == ((int64_t)1ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        HeffT2 v_t_241 = (g_prelude_2eparseInt_2edigitsFrom_240_24cpr(v_s_240, MK_INT(1LL), MK_INT(0LL)));
        {
          V v_field_243 = v_t_241.f[1];
          int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
          if ((v_tag_242 == ((int64_t)0ULL))) {
            V v_x_244 = v_field_243;
            V v_f_245 = heff_intSub(MK_INT(0LL), v_x_244);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_245}});
          } else {
            heff_drop(v_field_243);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    } else {
      return (g_prelude_2eparseInt_2edigitsFrom_240_24cpr(v_s_240, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
HEFF_LIT(g_prelude_2ewithCodePoint_str0, 3, "\357\277\275");
Clo g_prelude_2ewithCodePoint_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ewithCodePoint_entry, 2, 0};

V g_prelude_2ewithCodePoint(V v_acc_240, V v_r_241) {
top: ;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_r_241, 1) && heff_intLt_c_lent(v_r_241, MK_INT(128LL), 2))) {
    V v_t_242 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_r_241)));
    return heff_strAppend(v_acc_240, v_t_242);
  } else {
    if ((heff_intLe_c_lent(MK_INT(128LL), v_r_241, 1) && heff_intLt_c_lent(v_r_241, MK_INT(2048LL), 2))) {
      int64_t v_t_243 = (((int64_t)192ULL) + (heff_peek_word(v_r_241) / ((int64_t)64ULL)));
      V v_t_244 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_243))));
      int64_t v_t_245 = (((int64_t)128ULL) + (heff_unbox_word(v_r_241) % ((int64_t)64ULL)));
      V v_t_246 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_245))));
      return heff_strAppend(heff_strAppend(v_acc_240, v_t_244), v_t_246);
    } else {
      if ((heff_intLe_c_lent(MK_INT(2048LL), v_r_241, 1) && (heff_intLt_c_lent(v_r_241, MK_INT(65536LL), 2) && ((((int64_t)55296ULL) <= heff_peek_word(v_r_241)) ? !(heff_peek_word(v_r_241) < ((int64_t)57344ULL)) : 1)))) {
        int64_t v_t_247 = (((int64_t)224ULL) + (heff_peek_word(v_r_241) / ((int64_t)4096ULL)));
        V v_t_248 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_247))));
        int64_t v_t_249 = ((heff_peek_word(v_r_241) / ((int64_t)64ULL)) % ((int64_t)64ULL));
        uint8_t v_t_2410 = heff_from_int_u8(heff_box_word((((int64_t)128ULL) + v_t_249)));
        V v_t_2411 = heff_strAppend(heff_strAppend(v_acc_240, v_t_248), heff_strFromByte(heff_box_u8(v_t_2410)));
        int64_t v_t_2412 = (((int64_t)128ULL) + (heff_unbox_word(v_r_241) % ((int64_t)64ULL)));
        V v_t_2413 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_2412))));
        return heff_strAppend(v_t_2411, v_t_2413);
      } else {
        if ((heff_intLe_c_lent(MK_INT(65536LL), v_r_241, 1) && heff_intLt_c_lent(v_r_241, MK_INT(1114112LL), 2))) {
          int64_t v_t_2414 = (((int64_t)240ULL) + (heff_peek_word(v_r_241) / ((int64_t)262144ULL)));
          V v_t_2415 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_2414))));
          int64_t v_t_2416 = ((heff_peek_word(v_r_241) / ((int64_t)4096ULL)) % ((int64_t)64ULL));
          uint8_t v_t_2417 = heff_from_int_u8(heff_box_word((((int64_t)128ULL) + v_t_2416)));
          V v_t_2418 = heff_strAppend(heff_strAppend(v_acc_240, v_t_2415), heff_strFromByte(heff_box_u8(v_t_2417)));
          int64_t v_t_2419 = ((heff_peek_word(v_r_241) / ((int64_t)64ULL)) % ((int64_t)64ULL));
          uint8_t v_t_2420 = heff_from_int_u8(heff_box_word((((int64_t)128ULL) + v_t_2419)));
          V v_t_2421 = heff_strAppend(v_t_2418, heff_strFromByte(heff_box_u8(v_t_2420)));
          int64_t v_t_2422 = (((int64_t)128ULL) + (heff_unbox_word(v_r_241) % ((int64_t)64ULL)));
          V v_t_2423 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_2422))));
          return heff_strAppend(v_t_2421, v_t_2423);
        } else {
          heff_drop(v_r_241);
          return heff_strAppend(v_acc_240, ((V)&g_prelude_2ewithCodePoint_str0));
        }
      }
    }
  }
}
V g_prelude_2ewithCodePoint_entry(V self, V *a) {
  (void)self;
  return g_prelude_2ewithCodePoint(a[0], a[1]);
}
V g_prelude_2etraverse_24s499544530x2060473942_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s499544530x2060473942_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s499544530x2060473942_lam0, 1, 0};
V g_prelude_2etraverse_24s499544530x2060473942_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s499544530x2060473942_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s499544530x2060473942_entry, 2, 0};

V g_prelude_2etraverse_24s499544530x2060473942(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s499544530x2060473942_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_prelude_2etraverse_24s499544530x2060473942_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s499544530x2060473942(a[0], a[1]);
}
V g_prelude_2etraverse_24s499544530x2060473942_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_prelude_2etraverse_24s499544530x2060473942_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_245);
      return heff_tag_re_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = (g_prelude_2etraverse_24s499544530x2060473942(v_f_240, v_xs_245));
      V v_x1_2414 = heff_tr(heff_call(v_t_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          heff_drop_cell(v_ru_24x1_2414_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_Cons, 2, (V[]){v_x_2412, v_x_2418})});
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_prelude_2etraverse_24s1048254938x1609755296_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1048254938x1609755296_entry, 4, 0};

V g_prelude_2etraverse_24s1048254938x1609755296(V v_lit_240, V v_lit_241, V v_x2_242, V v_p_243) {
top: ;
  HeffT2 v_t_244 = (g_prelude_2etraverse_24s1048254938x1609755296_24cpr(v_lit_240, v_lit_241, v_x2_242, v_p_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_245, v_field_246});
  }
}
V g_prelude_2etraverse_24s1048254938x1609755296_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_prelude_2etraverse_24s1048254938x1609755296(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_prelude_2etraverse_24s119460564x671287541_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24MkPair = heff_take_reuse_n(v_x_242, 3ULL, 2);
      HeffT2 v_t_246 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_245, v_p_241));
      {
        V v_field_247 = v_t_246.f[0];
        V v_field_248 = v_t_246.f[1];
        V v_a_249 = v_field_247;
        V v_a_2410 = v_field_248;
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x_242_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_a_244, v_a_249}), heff_hole()});
        HeffT2 v_t_2412 = (g_prelude_2etraverse_24s119460564x671287541_24dps_24cpr(v_xs_243, v_a_2410, v_cell_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v__5f_2415 = v_field_2413;
          heff_drop(v__5f_2415);
          V v_st_2416 = v_field_2414;
          return ((HeffT2){{v_cell_2411, v_st_2416}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1760019503x148599044_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nothing: {
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      HeffT2 v_t_246 = (g_prelude_2etraverse_24s1760019503x148599044_24cpr(v_f_240, v_xs_243));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_x_249 = v_field_248;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_249})}});
        } else {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_x_245);
          heff_drop(v_field_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1989123107x1062793186_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      V v_cell_2444 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      HeffT2 v_t_2445 = (g_prelude_2etraverse_24s1989123107x1062793186_24dps_24cpr(v_xs_243, v_p_241, v_cell_2444));
      {
        V v_field_2446 = v_t_2445.f[0];
        V v_field_2447 = v_t_2445.f[1];
        V v__5f_2448 = v_field_2446;
        heff_drop(v__5f_2448);
        V v_s_2449 = v_field_2447;
        return ((HeffT2){{v_cell_2444, v_s_2449}});
      }
    } else {
      heff_drop(v_t_2443);
      V v_t_2450 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(heff_rfield(v_p_241, 0)), v_x_242));
      HeffT2 v_t_2451 = ({ V a_0 = v_p_241; V a_1 = v_t_2450; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2ecopyTake_24cpr(a_0, a_1)); heff_drop(v_t_2450); r_; });
      {
        V v_field_2452 = v_t_2451.f[0];
        V v_field_2453 = v_t_2451.f[1];
        V v_x_2454 = v_field_2452;
        V v_s_2455 = v_field_2453;
        V v_cell_2456 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2454, heff_hole()});
        HeffT2 v_t_2457 = (g_prelude_2etraverse_24s1989123107x1062793186_24dps_24cpr(v_xs_243, v_s_2455, v_cell_2456));
        {
          V v_field_2458 = v_t_2457.f[0];
          V v_field_2459 = v_t_2457.f[1];
          V v__5f_2460 = v_field_2458;
          heff_drop(v__5f_2460);
          V v_s_2461 = v_field_2459;
          return ((HeffT2){{v_cell_2456, v_s_2461}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s2104983077x351811635_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2104983077x351811635_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2104983077x351811635_lam0, 1, 0};
V g_prelude_2etraverse_24s2104983077x351811635_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s2104983077x351811635_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2104983077x351811635_entry, 1, 0};

V g_prelude_2etraverse_24s2104983077x351811635(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s2104983077x351811635_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s2104983077x351811635_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s2104983077x351811635_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2104983077x351811635(a[0]);
}
V g_prelude_2etraverse_24s2104983077x351811635_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_prelude_2etraverse_24s2104983077x351811635_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = (g_prelude_2etraverse_24s2104983077x351811635(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_t_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_s_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2etraverse_24s962837131x1183228870_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s962837131x1183228870_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_a_246));
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s962837131x1183228870_24cpr_lam0, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2414, heff_hole()});
      HeffT2 v_t_2417 = (g_prelude_2etraverse_24s962837131x1183228870_24dps_24cpr(v_xs_243, v_s_2415, v_cell_2416));
      {
        V v_field_2418 = v_t_2417.f[0];
        V v_field_2419 = v_t_2417.f[1];
        V v__5f_2420 = v_field_2418;
        heff_drop(v__5f_2420);
        V v_s_2421 = v_field_2419;
        return ((HeffT2){{v_cell_2416, v_s_2421}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2413)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s962837131x1183228870_24cpr_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_prelude_2etraverse_24s735647865x424372205_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s735647865x424372205_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s735647865x424372205_lam0, 1, 0};
V g_prelude_2etraverse_24s735647865x424372205_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s735647865x424372205_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s735647865x424372205_entry, 2, 0};

V g_prelude_2etraverse_24s735647865x424372205(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s735647865x424372205_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s735647865x424372205_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s735647865x424372205_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s735647865x424372205(a[0], a[1]);
}
V g_prelude_2etraverse_24s735647865x424372205_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s735647865x424372205_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_prelude_2etraverse_24s735647865x424372205(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr_lam1(V self, V *args);
V g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_d_247 = v_x_245;
    V v_m_248 = (g_heff_2ecompile_2eir_2etraversePartsM_24s284871252x1447734407(heff_dup(heff_rfield(v_d_247, 2))));
    V v_m_2423 = heff_clo_n(g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr_lam0, 1, 2, (V[]){v_m_248, v_d_247});
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_n_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      V v_cell_2427 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2425, heff_hole()});
      V v_u_2428 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2427);
      V t_0 = v_xs_246;
      V t_1 = v_n_2426;
      V t_2 = v_u_2428;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2424)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_n_2415});
}
V g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr_lam0(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2411), NTAG(TAG_Nil)});
    V v_ns_2414 = (g_heff_2ecompile_2efields_2enumbersW(NTAG(TAG_Nil), v_t_2413));
    V v_m_2418;
    switch (heff_tag_of(v_ns_2414)) {
    case TAG_Nil: {
      v_m_2418 = heff_clo_n(g_prelude_2etraverse_24s812820150x374715993_24dps_24cpr_lam1, 1, 1, (V[]){v_x_2411});
      break;
    }
    case TAG_Cons: {
      v_m_2418 = ({ V a_0 = v_ns_2414; V a_1 = v_x_2411; V r_ = (g_heff_2ecompile_2efields_2egoLate(a_0, a_1)); heff_drop_tag(v_ns_2414, 2); r_; });
      break;
    }
    default: heff_nomatch(v_ns_2414);
    }
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2412}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      V v_t_2422 = ({ V rv_2 = v_x_2420; V rr_ = heff_rec_reuse_nf(v_d_247, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2422, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s199930607x121965669_24cpr_str0, 5, "fuel$");
V g_prelude_2etraverse_24s199930607x121965669_24cpr_lam0(V self, V *args);
V g_prelude_2etraverse_24s199930607x121965669_24cpr_lam1(V self, V *args);
V g_prelude_2etraverse_24s199930607x121965669_24cpr_lam2(V self, V *args);
V g_prelude_2etraverse_24s199930607x121965669_24cpr_lam3(V self, V *args);

HeffT2 g_prelude_2etraverse_24s199930607x121965669_24cpr(V v_lit_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_z_242}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_groups_245 = heff_dup(v_lit_240);
    V v_d_246 = v_x_243;
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_groups_245, heff_rfield(v_d_246, 0)));
    {
      V v_field_249 = v_t_247.f[1];
      V v_tag_248 = heff_box_i64(((int64_t)v_t_247.f[0]));
      V v_inGroup_2416 = heff_clo_n(g_prelude_2etraverse_24s199930607x121965669_24cpr_lam0, 1, 3, (V[]){v_tag_248, v_field_249, v_groups_245});
      V v_k_2417 = heff_dup(heff_rfield(v_d_246, 0));
      V v_e_2418 = heff_dup(heff_rfield(v_d_246, 2));
      V v_m_2442;
      switch (heff_tag_of(v_e_2418)) {
      case TAG_ELam: {
        V v_xs_2419 = heff_field(v_e_2418, 0);
        V v_b_2420 = heff_field(v_e_2418, 1);
        heff_take_n(v_e_2418, 3ULL, 2);
        V v_inGroup_2421 = v_inGroup_2416;
        V v_k_2422 = v_k_2417;
        V v_xs_2423 = heff_dup(v_xs_2419);
        V v_b_2424 = v_b_2420;
        V v_m_2425 = (g_heff_2ecompile_2efuel_2etickedIn(v_inGroup_2421, v_b_2424));
        V v_m_2437 = heff_clo_n(g_prelude_2etraverse_24s199930607x121965669_24cpr_lam1, 1, 4, (V[]){v_m_2425, v_k_2422, v_xs_2423, v_inGroup_2421});
        v_m_2442 = heff_clo_n(g_prelude_2etraverse_24s199930607x121965669_24cpr_lam2, 1, 2, (V[]){v_m_2437, v_xs_2419});
        break;
      }
      default: {
        heff_drop(v_k_2417);
        v_m_2442 = ({ V a_0 = v_inGroup_2416; V a_1 = v_e_2418; V r_ = (g_heff_2ecompile_2efuel_2etickedIn(a_0, a_1)); heff_drop_clo(v_inGroup_2416, 3); r_; });
        break;
      }
      }
      V v_m_2448 = heff_clo_n(g_prelude_2etraverse_24s199930607x121965669_24cpr_lam3, 1, 2, (V[]){v_m_2442, v_d_246});
      V v_x2_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_MkPair: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_n_2451 = heff_field(v_x2_2449, 1);
        heff_take_n(v_x2_2449, 3ULL, 2);
        V v_cell_2452 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_2450, heff_hole()});
        HeffT2 v_t_2453 = ({ V a_0 = v_lit_240; V a_1 = v_xs_244; V a_2 = v_n_2451; V a_3 = v_cell_2452; HeffT2 r_ = (g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); r_; });
        {
          V v_field_2454 = v_t_2453.f[0];
          V v_field_2455 = v_t_2453.f[1];
          V v__5f_2456 = v_field_2454;
          heff_drop(v__5f_2456);
          V v_n_2457 = v_field_2455;
          return ((HeffT2){{v_cell_2452, v_n_2457}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2449)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_prelude_2etraverse_24s199930607x121965669_24cpr_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_tag_248 = heff_env(self)[0];
  V v_field_249 = heff_env(self)[1];
  V v_groups_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_248) == ((int64_t)0ULL))) {
    V v_n_2411 = v_field_249;
    HeffT2 v_t_2412 = ({ V a_0 = v_groups_245; V a_1 = v_g_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_groups_245); heff_drop(v_g_2410); r_; });
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_m_2415 = v_field_2414;
        V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_m_2415, v_n_2411, 0));
        heff_drop(v_n_2411);
        heff_drop(v_m_2415);
        return v_ret_24bool;
      } else {
        heff_drop(v_n_2411);
        heff_drop(v_field_2414);
        return NTAG(TAG_False);
      }
    }
  } else {
    heff_drop(v_g_2410);
    heff_drop(v_field_249);
    heff_drop(v_groups_245);
    return NTAG(TAG_False);
  }
}
V g_prelude_2etraverse_24s199930607x121965669_24cpr_lam1(V self, V *args) {
  V v_n_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  V v_xs_2423 = heff_env(self)[2];
  V v_inGroup_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_n_2426}));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_n_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    V v_x_2430 = (g_heff_2ecompile_2efuel_2eroundsOf(v_k_2422, heff_dup(v_x_2428)));
    if (heff_intLt_c(MK_INT(1LL), v_x_2430)) {
      heff_drop(v_inGroup_2421);
      heff_drop_cell(v_ru_24x2_2427_24MkPair, 2);
      V v_t_2431 = (g_heff_2ecompile_2efuel_2eroundsOf(v_k_2422, heff_dup(v_x_2428)));
      V v_t_2432 = (g_heff_2ecompile_2efuel_2ecounted(v_k_2422, heff_dup(v_xs_2423), v_x_2428));
      return ({ V a_0 = v_k_2422; V a_1 = v_xs_2423; V a_2 = v_t_2431; V a_3 = v_x_2428; V a_4 = v_t_2432; V a_5 = v_n_2429; V r_ = (g_heff_2ecompile_2efuel_2ebatchedBy(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2432); r_; });
    } else {
      heff_drop(v_k_2422);
      heff_drop(v_xs_2423);
      V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2428), NTAG(TAG_Nil)});
      V v_t_2434 = ({ V a_0 = v_inGroup_2421; V a_1 = v_t_2433; V r_ = (g_heff_2ecompile_2efuel_2ecloses(a_0, a_1)); heff_drop(v_inGroup_2421); r_; });
      if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
        heff_drop(v_t_2434);
        V v_t_2435 = heff_strAppend(((V)&g_prelude_2etraverse_24s199930607x121965669_24cpr_str0), heff_intShow(heff_dup(v_n_2429)));
        V v_t_2436 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_FuelTick), NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2435, v_t_2436, v_x_2428}), heff_intAdd(v_n_2429, MK_INT(1LL))});
      } else {
        heff_drop(v_t_2434);
        return heff_tag_re_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_x_2428, v_n_2429});
      }
    }
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_prelude_2etraverse_24s199930607x121965669_24cpr_lam2(V self, V *args) {
  V v_n_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_xs_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_n_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_n_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2419, v_x_2440}), v_n_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_prelude_2etraverse_24s199930607x121965669_24cpr_lam3(V self, V *args) {
  V v_n_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2444 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_n_2443}));
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    V v_n_2446 = heff_field(v_x2_2444, 1);
    V v_ru_24x2_2444_24MkPair = heff_take_reuse_n(v_x2_2444, 3ULL, 2);
    V v_t_2447 = ({ V rv_2 = v_x_2445; V rr_ = heff_rec_reuse_nf(v_d_246, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_re_n(v_ru_24x2_2444_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2447, v_n_2446});
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
HEFF_LIT(g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_str0, 5, "fuel$");
V g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam0(V self, V *args);
V g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam1(V self, V *args);
V g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam2(V self, V *args);
V g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam3(V self, V *args);

HeffT2 g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr(V v_lit_240, V v_x2_241, V v_z_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_u_244 = heff_setFieldPeek(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_245 = heff_hole();
    return ((HeffT2){{v_f_245, v_z_242}});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_241, 0);
    V v_xs_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_groups_248 = heff_dup(v_lit_240);
    V v_d_249 = v_x_246;
    HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_groups_248, heff_rfield(v_d_249, 0)));
    {
      V v_field_2412 = v_t_2410.f[1];
      V v_tag_2411 = heff_box_i64(((int64_t)v_t_2410.f[0]));
      V v_inGroup_2419 = heff_clo_n(g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam0, 1, 3, (V[]){v_tag_2411, v_field_2412, v_groups_248});
      V v_k_2420 = heff_dup(heff_rfield(v_d_249, 0));
      V v_e_2421 = heff_dup(heff_rfield(v_d_249, 2));
      V v_m_2445;
      switch (heff_tag_of(v_e_2421)) {
      case TAG_ELam: {
        V v_xs_2422 = heff_field(v_e_2421, 0);
        V v_b_2423 = heff_field(v_e_2421, 1);
        heff_take_n(v_e_2421, 3ULL, 2);
        V v_inGroup_2424 = v_inGroup_2419;
        V v_k_2425 = v_k_2420;
        V v_xs_2426 = heff_dup(v_xs_2422);
        V v_b_2427 = v_b_2423;
        V v_m_2428 = (g_heff_2ecompile_2efuel_2etickedIn(v_inGroup_2424, v_b_2427));
        V v_m_2440 = heff_clo_n(g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam1, 1, 4, (V[]){v_m_2428, v_k_2425, v_xs_2426, v_inGroup_2424});
        v_m_2445 = heff_clo_n(g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam2, 1, 2, (V[]){v_m_2440, v_xs_2422});
        break;
      }
      default: {
        heff_drop(v_k_2420);
        v_m_2445 = ({ V a_0 = v_inGroup_2419; V a_1 = v_e_2421; V r_ = (g_heff_2ecompile_2efuel_2etickedIn(a_0, a_1)); heff_drop_clo(v_inGroup_2419, 3); r_; });
        break;
      }
      }
      V v_m_2451 = heff_clo_n(g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam3, 1, 2, (V[]){v_m_2445, v_d_249});
      V v_x2_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x2_2452)) {
      case TAG_MkPair: {
        V v_x_2453 = heff_field(v_x2_2452, 0);
        V v_n_2454 = heff_field(v_x2_2452, 1);
        heff_take_n(v_x2_2452, 3ULL, 2);
        V v_cell_2455 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_2453, heff_hole()});
        V v_u_2456 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2455);
        V t_0 = v_lit_240;
        V t_1 = v_xs_247;
        V t_2 = v_n_2454;
        V t_3 = v_u_2456;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        v_z_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2452)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam0(V self, V *args) {
  V v_g_2413 = args[0];
  V v_tag_2411 = heff_env(self)[0];
  V v_field_2412 = heff_env(self)[1];
  V v_groups_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_2411) == ((int64_t)0ULL))) {
    V v_n_2414 = v_field_2412;
    HeffT2 v_t_2415 = ({ V a_0 = v_groups_248; V a_1 = v_g_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_groups_248); heff_drop(v_g_2413); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_m_2418 = v_field_2417;
        V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_m_2418, v_n_2414, 0));
        heff_drop(v_n_2414);
        heff_drop(v_m_2418);
        return v_ret_24bool;
      } else {
        heff_drop(v_n_2414);
        heff_drop(v_field_2417);
        return NTAG(TAG_False);
      }
    }
  } else {
    heff_drop(v_g_2413);
    heff_drop(v_field_2412);
    heff_drop(v_groups_248);
    return NTAG(TAG_False);
  }
}
V g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam1(V self, V *args) {
  V v_n_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  V v_xs_2426 = heff_env(self)[2];
  V v_inGroup_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_n_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_x_2433 = (g_heff_2ecompile_2efuel_2eroundsOf(v_k_2425, heff_dup(v_x_2431)));
    if (heff_intLt_c(MK_INT(1LL), v_x_2433)) {
      heff_drop(v_inGroup_2424);
      heff_drop_cell(v_ru_24x2_2430_24MkPair, 2);
      V v_t_2434 = (g_heff_2ecompile_2efuel_2eroundsOf(v_k_2425, heff_dup(v_x_2431)));
      V v_t_2435 = (g_heff_2ecompile_2efuel_2ecounted(v_k_2425, heff_dup(v_xs_2426), v_x_2431));
      return ({ V a_0 = v_k_2425; V a_1 = v_xs_2426; V a_2 = v_t_2434; V a_3 = v_x_2431; V a_4 = v_t_2435; V a_5 = v_n_2432; V r_ = (g_heff_2ecompile_2efuel_2ebatchedBy(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2435); r_; });
    } else {
      heff_drop(v_k_2425);
      heff_drop(v_xs_2426);
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2431), NTAG(TAG_Nil)});
      V v_t_2437 = ({ V a_0 = v_inGroup_2424; V a_1 = v_t_2436; V r_ = (g_heff_2ecompile_2efuel_2ecloses(a_0, a_1)); heff_drop(v_inGroup_2424); r_; });
      if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
        heff_drop(v_t_2437);
        V v_t_2438 = heff_strAppend(((V)&g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_str0), heff_intShow(heff_dup(v_n_2432)));
        V v_t_2439 = heff_tag_n(TAG_EPrimCall, 2, (V[]){NTAG(TAG_FuelTick), NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2438, v_t_2439, v_x_2431}), heff_intAdd(v_n_2432, MK_INT(1LL))});
      } else {
        heff_drop(v_t_2437);
        return heff_tag_re_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_x_2431, v_n_2432});
      }
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam2(V self, V *args) {
  V v_n_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_xs_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_n_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2422, v_x_2443}), v_n_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_prelude_2etraverse_24s199930607x121965669_24dps_24cpr_lam3(V self, V *args) {
  V v_n_2446 = args[0];
  V v_m_2445 = heff_env(self)[0];
  V v_d_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2447 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_n_2446}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_n_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    V v_t_2450 = ({ V rv_2 = v_x_2448; V rr_ = heff_rec_reuse_nf(v_d_249, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_re_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2450, v_n_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}

HeffT2 g_prelude_2etraverse_24s801310267x475583082_24dps_24cpr(V v_x2_240, V v_p_241, V v_d_242) {
top: ;
  V v_supply_243 = heff_take_field(v_p_241, 0);
  V v_consumers_244 = heff_take_field(v_p_241, 1);
  V v_producers_245 = heff_take_field(v_p_241, 2);
  V v_made_246 = heff_take_field(v_p_241, 3);
  V v_fresh_247 = heff_take_field(v_p_241, 4);
  V v_left_248 = heff_get_n(v_p_241, 5, 6);
  return ({ V a_0 = v_x2_240; V a_1 = v_supply_243; V a_2 = v_consumers_244; V a_3 = v_producers_245; V a_4 = v_made_246; V a_5 = v_fresh_247; V a_6 = v_left_248; V a_7 = v_d_242; HeffT2 r_ = (g_prelude_2etraverse_24s801310267x475583082_24dps_24scalars_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_consumers_244); heff_drop(v_producers_245); heff_drop(v_made_246); heff_drop(v_fresh_247); heff_drop(v_left_248); r_; });
}
V g_prelude_2etraverse_24s1259852701x334693366_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1259852701x334693366_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1259852701x334693366_lam0, 1, 0};
V g_prelude_2etraverse_24s1259852701x334693366_lam1(V self, V *args);
V g_prelude_2etraverse_24s1259852701x334693366_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1259852701x334693366_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1259852701x334693366_entry, 1, 0};

V g_prelude_2etraverse_24s1259852701x334693366(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1259852701x334693366_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_a_246 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(v_a_245));
      v_m_2411 = heff_clo_n(g_prelude_2etraverse_24s1259852701x334693366_lam1, 1, 2, (V[]){v_a_246, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1259852701x334693366_lam2, 1, 2, (V[]){v_m_2411, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1259852701x334693366_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1259852701x334693366(a[0]);
}
V g_prelude_2etraverse_24s1259852701x334693366_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1259852701x334693366_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_a_247}));
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_a_249 = heff_field(v_a_248, 0);
    V v_a_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_249}), v_a_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
V g_prelude_2etraverse_24s1259852701x334693366_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_prelude_2etraverse_24s1259852701x334693366(v_xs_243));
    V v_x2_2417 = heff_tr(heff_call(v_t_2416, 1, (V[]){v_n_2415}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_n_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_Cons, 2, (V[]){v_x_2414, v_x_2418}), v_n_2419});
    }
    default: return heff_nomatch(v_x2_2417);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}

HeffT2 g_prelude_2etraverse_24s1573855737x392625097_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s479901786x2144953905(heff_take_field(v_x_242, 2)));
    V v_a_245 = heff_tr(heff_call(v_a_244, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_a_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_a_245, 0);
      V v_a_247 = heff_field(v_a_245, 1);
      heff_take_n(v_a_245, 3ULL, 2);
      HeffT2 v_t_248 = (g_prelude_2etraverse_24s1573855737x392625097_24cpr(v_xs_243, v_a_247));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_n_2412 = v_field_2410;
        V v_t_2413 = ({ V rv_2 = v_a_246; V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_f_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_x_2411});
        return ((HeffT2){{v_f_2414, v_n_2412}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_a_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1700321227x1313876518_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1700321227x1313876518_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1700321227x1313876518_lam0, 1, 0};
V g_prelude_2etraverse_24s1700321227x1313876518_lam1(V self, V *args);
V g_prelude_2etraverse_24s1700321227x1313876518_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s1700321227x1313876518_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1700321227x1313876518_entry, 1, 0};

V g_prelude_2etraverse_24s1700321227x1313876518(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1700321227x1313876518_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_a_246));
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s1700321227x1313876518_lam1, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo_n(g_prelude_2etraverse_24s1700321227x1313876518_lam2, 1, 2, (V[]){v_m_2412, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1700321227x1313876518_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1700321227x1313876518(a[0]);
}
V g_prelude_2etraverse_24s1700321227x1313876518_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1700321227x1313876518_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_call(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_re_n(v_ru_24a_249_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_prelude_2etraverse_24s1700321227x1313876518_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = (g_prelude_2etraverse_24s1700321227x1313876518(v_xs_243));
    V v_x2_2418 = heff_tr(heff_call(v_t_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}

HeffT2 g_prelude_2etraverse_24s514944727x707829312_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(heff_take_field(v_x_242, 2)));
    V v_a_245 = heff_tr(heff_call(v_a_244, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_a_245)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_a_245, 0);
      V v_a_247 = heff_field(v_a_245, 1);
      heff_take_n(v_a_245, 3ULL, 2);
      HeffT2 v_t_248 = (g_prelude_2etraverse_24s514944727x707829312_24cpr(v_xs_243, v_a_247));
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_x_2411 = v_field_249;
        V v_n_2412 = v_field_2410;
        V v_t_2413 = ({ V rv_2 = v_a_246; V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_f_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_x_2411});
        return ((HeffT2){{v_f_2414, v_n_2412}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_a_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_prelude_2etraverse_24s277604616x578020818_str0, 1, "_");
HEFF_LIT(g_prelude_2etraverse_24s277604616x578020818_str1, 1, "_");
HEFF_LIT(g_prelude_2etraverse_24s277604616x578020818_str2, 1, "$");
V g_prelude_2etraverse_24s277604616x578020818_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s277604616x578020818_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s277604616x578020818_lam0, 1, 0};
V g_prelude_2etraverse_24s277604616x578020818_lam1(V self, V *args); static Clo g_prelude_2etraverse_24s277604616x578020818_lam1_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s277604616x578020818_lam1, 1, 0};
V g_prelude_2etraverse_24s277604616x578020818_lam2(V self, V *args);
V g_prelude_2etraverse_24s277604616x578020818_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s277604616x578020818_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s277604616x578020818_entry, 1, 0};

V g_prelude_2etraverse_24s277604616x578020818(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s277604616x578020818_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_248;
    if (heff_strEq_c_lent(v_x_242, ((V)&g_prelude_2etraverse_24s277604616x578020818_str0), 2)) {
      heff_drop(v_x_242);
      v_m_248 = ((V)&g_prelude_2etraverse_24s277604616x578020818_lam1_clo);
    } else {
      V v_base_245 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eir_2ebaseGo(a_0, a_1)); heff_drop(v_x_242); r_; });
      v_m_248 = heff_clo_n(g_prelude_2etraverse_24s277604616x578020818_lam2, 1, 1, (V[]){v_base_245});
    }
    return heff_clo_n(g_prelude_2etraverse_24s277604616x578020818_lam3, 1, 2, (V[]){v_m_248, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s277604616x578020818_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s277604616x578020818(a[0]);
}
V g_prelude_2etraverse_24s277604616x578020818_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s277604616x578020818_lam1(V self, V *args) {
  V v_n_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_prelude_2etraverse_24s277604616x578020818_str1), v_n_244});
}
V g_prelude_2etraverse_24s277604616x578020818_lam2(V self, V *args) {
  V v_n_246 = args[0];
  V v_base_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_strAppend(heff_strAppend(v_base_245, ((V)&g_prelude_2etraverse_24s277604616x578020818_str2)), heff_intShow(heff_dup(v_n_246)));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, heff_intAdd(v_n_246, MK_INT(1LL))});
}
V g_prelude_2etraverse_24s277604616x578020818_lam3(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = (g_prelude_2etraverse_24s277604616x578020818(v_xs_243));
    V v_x2_2414 = heff_tr(heff_call(v_t_2413, 1, (V[]){v_n_2412}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_n_2416 = heff_field(v_x2_2414, 1);
      V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_x_2411, v_x_2415}), v_n_2416});
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}

HeffT2 g_prelude_2etraverse_24s1111575179x1680558317_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(heff_take_field(v_x_242, 2)));
    V v_x2_245 = heff_tr(heff_call(v_m_244, 1, (V[]){v_z_241}));
    V v_x2_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_n_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      v_x2_248 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_245_24MkPair, v_x_246, v_n_247));
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_n_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      HeffT2 v_t_2411 = (g_prelude_2etraverse_24s1111575179x1680558317_24cpr(v_xs_243, v_n_2410));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_x_2414 = v_field_2412;
        V v_n_2415 = v_field_2413;
        V v_t_2416 = ({ V rv_2 = v_x_249; V rr_ = heff_rec_reuse_nf(v_x_242, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_f_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_x_2414});
        return ((HeffT2){{v_f_2417, v_n_2415}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s763866529x146151572_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s763866529x146151572_24cpr(V v_x2_240, V v_z_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_z_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_m_249;
    switch (heff_tag_of(v_t_244)) {
    case TAG_ShapeRecord: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_m_249 = heff_clo_n(g_prelude_2etraverse_24s763866529x146151572_24cpr_lam0, 1, 1, (V[]){v_x_242});
      break;
    }
    case TAG_ShapeTag: {
      heff_take_n(v_t_244, 0ULL, 2);
      v_m_249 = (g_heff_2ecompile_2escalars_2ewithVars(v_x_242));
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      HeffT2 v_t_2414 = (g_prelude_2etraverse_24s763866529x146151572_24dps_24cpr(v_xs_243, v_n_2412, v_cell_2413));
      {
        V v_field_2415 = v_t_2414.f[0];
        V v_field_2416 = v_t_2414.f[1];
        V v__5f_2417 = v_field_2415;
        heff_drop(v__5f_2417);
        V v_n_2418 = v_field_2416;
        return ((HeffT2){{v_cell_2413, v_n_2418}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2410)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s763866529x146151572_24cpr_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_a_246});
}
V g_prelude_2etraverse_24s763866529x146151572_24dps_24cpr_lam0(V self, V *args);

HeffT2 g_prelude_2etraverse_24s763866529x146151572_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_x_245, 2));
    V v_m_2412;
    switch (heff_tag_of(v_t_247)) {
    case TAG_ShapeRecord: {
      heff_take_n(v_t_247, 0ULL, 1);
      v_m_2412 = heff_clo_n(g_prelude_2etraverse_24s763866529x146151572_24dps_24cpr_lam0, 1, 1, (V[]){v_x_245});
      break;
    }
    case TAG_ShapeTag: {
      heff_take_n(v_t_247, 0ULL, 2);
      v_m_2412 = (g_heff_2ecompile_2escalars_2ewithVars(v_x_245));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2414, heff_hole()});
      V v_u_2417 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2416);
      V t_0 = v_xs_246;
      V t_1 = v_n_2415;
      V t_2 = v_u_2417;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2413)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s763866529x146151572_24dps_24cpr_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_a_249});
}

HeffT2 g_prelude_2etraverse_24s993801089x502291790_24dps_24cpr(V v_x2_240, V v_z_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_z_241}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_xs_246 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_def_247 = heff_take_field(v_x_245, 0);
    V v_slots_248 = heff_get_n(v_x_245, 1, 2);
    V v_m_249 = (g_heff_2ecompile_2escalars_2edefWith(NTAG(TAG_OfTags), v_def_247, v_slots_248));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_z_241}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
      V t_0 = v_xs_246;
      V t_1 = v_n_2412;
      V t_2 = v_u_2414;
      v_x2_240 = t_0;
      v_z_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2410)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1807059150x502333573_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_err_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_245}});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      HeffT2 v_t_247 = (g_prelude_2etraverse_24s1807059150x502333573_24cpr(v_f_240, v_xs_243));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_x_246);
          V v_err_2410 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2410}});
        } else {
          V v_x_2411 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_x_2411})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1483742185x1081287844_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24MkFieldPat = heff_take_reuse_n(v_x_241, 3ULL, 2);
      HeffT2 v_t_245 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_a_244));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop(v_xs_242);
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_a_243);
          heff_drop_cell(v_ru_24x_241_24MkFieldPat, 2);
          V v_a_248 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_248}});
        } else {
          V v_a_249 = v_field_247;
          HeffT2 v_t_2410 = (g_prelude_2etraverse_24s1483742185x1081287844_24cpr(v_xs_242));
          {
            V v_field_2412 = v_t_2410.f[1];
            int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
            if ((v_tag_2411 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24Cons, 2);
              heff_drop(v_a_243);
              heff_drop_cell(v_ru_24x_241_24MkFieldPat, 2);
              heff_drop(v_a_249);
              V v_err_2413 = v_field_2412;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2413}});
            } else {
              V v_x_2414 = v_field_2412;
              V v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x_241_24MkFieldPat, TAG_MkPair, 2, (V[]){v_a_243, v_a_249}), v_x_2414});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2415}});
            }
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1778157750x1229378888_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        heff_take_n(v_a_243, 12ULL, 4);
        HeffT2 v_t_249 = (g_prelude_2etraverse_24s366524614x1308602553_24cpr(v_a_247));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop(v_xs_242);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_a_248);
            V v_a_2412 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_2412}});
          } else {
            V v_a_2413 = v_field_2411;
            HeffT2 v_t_2414 = (g_prelude_2etraverse_24s1778157750x1229378888_24cpr(v_xs_242));
            {
              V v_field_2416 = v_t_2414.f[1];
              int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop(v_a_248);
                heff_drop(v_a_2413);
                V v_err_2417 = v_field_2416;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2417}});
              } else {
                V v_x_2418 = v_field_2416;
                V v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_a_2413, v_a_248}), v_x_2418});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2419}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_243)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_prelude_2etraverse_24s1778157750x1229378888_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1778157750x1229378888_entry, 1, 0};

V g_prelude_2etraverse_24s1778157750x1229378888(V v_x2_240) {
top: ;
  HeffT2 v_t_241 = (g_prelude_2etraverse_24s1778157750x1229378888_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_prelude_2etraverse_24s1778157750x1229378888_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1778157750x1229378888(a[0]);
}
HEFF_LIT(g_prelude_2etraverse_24s1157078602x1175067503_str0, 54, "an argument of a `case` pattern is a pattern or a name");
V g_prelude_2etraverse_24s1157078602x1175067503_lam1(V self, V *args);
V g_prelude_2etraverse_24s1157078602x1175067503_lam0(V self, V *args);
Clo g_prelude_2etraverse_24s1157078602x1175067503_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1157078602x1175067503_entry, 3, 0};

V g_prelude_2etraverse_24s1157078602x1175067503(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_p_245 = v_x_243;
    V v_p_246 = heff_dup(v_p_241);
    V v_malg_247 = heff_take_field(v_p_246, 2);
    V v_bind_248 = heff_get_n(v_p_246, 1, 3);
    V v_p_2411 = heff_clo_n(g_prelude_2etraverse_24s1157078602x1175067503_lam0, 1, 3, (V[]){v_xs_244, v_p_241, v_p_242});
    switch (heff_tag_of(v_p_245)) {
    case TAG_At: {
      V v_p1_2412 = heff_dup(heff_field(v_p_245, 0));
      switch (heff_tag_of(v_p1_2412)) {
      case TAG_PatVar: {
        V v_x_2414 = heff_field(v_p1_2412, 0);
        heff_take_n(v_p1_2412, 1ULL, 1);
        heff_drop(v_malg_247);
        heff_drop(v_bind_248);
        switch (heff_tag_of(v_p_245)) {
        case TAG_At: {
          heff_take_n(v_p_245, 0ULL, 2);
          return heff_tail(v_p_2411, 1, (V[]){v_x_2414});
        }
        default: return heff_nomatch(v_p_245);
        }
      }
      default: {
        heff_drop(v_p1_2412);
        V v_t_2419;
        switch (heff_tag_of(v_p_245)) {
        case TAG_At: {
          V v_s_2418 = heff_field(v_p_245, 1);
          heff_take_n(v_p_245, 2ULL, 2);
          v_t_2419 = v_s_2418;
          break;
        }
        default: heff_nomatch(v_p_245);
        }
        V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s1157078602x1175067503_str0), v_t_2419, NTAG(TAG_Nothing)});
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tr(heff_call(v_malg_247, 1, (V[]){v_t_2422}));
        return heff_tail(v_bind_248, 2, (V[]){v_t_2423, v_p_2411});
      }
      }
    }
    default: return heff_nomatch(v_p_245);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1157078602x1175067503(a[0], a[1], a[2]);
}
V g_prelude_2etraverse_24s1157078602x1175067503_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_249, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1157078602x1175067503_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_prelude_2etraverse_24s1157078602x1175067503(v_xs_244, v_p_241, heff_clo_n(g_prelude_2etraverse_24s1157078602x1175067503_lam1, 1, 2, (V[]){v_p_242, v_a_249})));
}
V g_prelude_2etraverse_24s515579549x140669784_lam1(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam0(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam3(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam2(V self, V *args);
Clo g_prelude_2etraverse_24s515579549x140669784_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s515579549x140669784_entry, 3, 0};

V g_prelude_2etraverse_24s515579549x140669784(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_z_241);
    return heff_tail(v_z_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_248 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_a_248));
        v_a_2414 = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam0, 2, 3, (V[]){v_a_249, v_a_246, v_a_247});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tail(v_a_2414, 2, (V[]){heff_dup(v_z_241), heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam2, 1, 3, (V[]){v_xs_244, v_z_241, v_z_242})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s515579549x140669784(a[0], a[1], a[2]);
}
V g_prelude_2etraverse_24s515579549x140669784_lam1(V self, V *args) {
  V v_a_2412 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  V v_a_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = ({ V a_0 = v_a_246; V a_1 = v_a_247; V a_2 = v_a_2412; V r_ = (g_heff_2eelab_2etoplevel_2eupdatePath(a_0, a_1, a_2)); heff_drop(v_a_246); heff_drop(v_a_2412); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_a_2410;
  heff_room[1] = v_a_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s515579549x140669784_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_2411 = args[1];
  V v_a_249 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_249;
  args[0] = heff_dup(v_a_2410);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam1, 1, 4, (V[]){v_a_246, v_a_247, v_a_2410, v_a_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s515579549x140669784_lam3(V self, V *args) {
  V v_a_2416 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_a_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2415, v_a_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s515579549x140669784_lam2(V self, V *args) {
  V v_a_2415 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_prelude_2etraverse_24s515579549x140669784(v_xs_244, v_z_241, heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam3, 1, 2, (V[]){v_z_242, v_a_2415})));
}
V g_prelude_2etraverse_24s1413153166x427060745_lam1(V self, V *args);
V g_prelude_2etraverse_24s1413153166x427060745_lam0(V self, V *args);
Clo g_prelude_2etraverse_24s1413153166x427060745_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1413153166x427060745_entry, 3, 0};

V g_prelude_2etraverse_24s1413153166x427060745(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_z_241);
    return heff_tail(v_z_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2eexplicitArgChk_24s810851637x1038481152(v_x_243));
    return heff_tail(v_a_245, 2, (V[]){heff_dup(v_z_241), heff_clo_n(g_prelude_2etraverse_24s1413153166x427060745_lam0, 1, 3, (V[]){v_xs_244, v_z_241, v_z_242})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1413153166x427060745_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1413153166x427060745(a[0], a[1], a[2]);
}
V g_prelude_2etraverse_24s1413153166x427060745_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_246, v_a_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1413153166x427060745_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_prelude_2etraverse_24s1413153166x427060745(v_xs_244, v_z_241, heff_clo_n(g_prelude_2etraverse_24s1413153166x427060745_lam1, 1, 2, (V[]){v_z_242, v_a_246})));
}
HEFF_LIT(g_prelude_2etraverse_24s1211845059x266223635_str0, 19, "expected small type");
HEFF_LIT(g_prelude_2etraverse_24s1211845059x266223635_str1, 19, "expected small type");
V g_prelude_2etraverse_24s1211845059x266223635_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1211845059x266223635_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1211845059x266223635_lam0, 2, 0};
V g_prelude_2etraverse_24s1211845059x266223635_lam6(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam5(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam4(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam3(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam2(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1211845059x266223635_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1211845059x266223635_entry, 1, 0};

V g_prelude_2etraverse_24s1211845059x266223635(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1211845059x266223635_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(heff_dup(v_x_243)));
    return heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam1, 2, 3, (V[]){v_a_245, v_xs_244, v_x_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1211845059x266223635_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1211845059x266223635(a[0]);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  V v_hd_2418 = heff_env(self)[2];
  V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2420, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2425;
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Nom: {
    V v_t_2422 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_x1_2425 = ({ V a_0 = v_t_2422; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2422); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2423 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_x1_2425 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2423); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2424 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_x1_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2424); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2421);
  }
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_Small: {
    heff_clo_take(self, 3);
    heff_drop(v_sp_2413);
    heff_drop_rec(v_hd_2418, 3);
    V f_ = v_k_2419;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Large: {
    heff_drop_rec(v_x_2420, 2);
    heff_clo_take(self, 3);
    V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s1211845059x266223635_str0), v_sp_2413, NTAG(TAG_Nothing)});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_2418, 2), 1, (V[]){v_t_2428}));
    V f_ = heff_get_n(v_hd_2418, 1, 3);
    heff_room[0] = v_t_2429;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_TopL: {
    heff_drop_rec(v_x_2420, 2);
    heff_clo_take(self, 3);
    V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_prelude_2etraverse_24s1211845059x266223635_str1), v_sp_2413, NTAG(TAG_Nothing)});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_2418, 2), 1, (V[]){v_t_2432}));
    V f_ = heff_get_n(v_hd_2418, 1, 3);
    heff_room[0] = v_t_2433;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_prelude_2etraverse_24s1211845059x266223635_lam5(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam6, 1, 3, (V[]){v_k_2419, v_sp_2413, v_hd_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam4(V self, V *args) {
  V v_e_2415 = args[0];
  V v_typ_2414 = heff_env(self)[0];
  V v_sp_2413 = heff_env(self)[1];
  V v_c_2417;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_typ_2414)) {
  case TAG_MkTyp: {
    V v_f_2416 = heff_field(v_typ_2414, 0);
    heff_take_n(v_typ_2414, 1ULL, 1);
    v_c_2417 = heff_tr(heff_call(v_f_2416, 1, (V[]){v_e_2415}));
    break;
  }
  default: heff_nomatch(v_typ_2414);
  }
  return heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam5, 2, 2, (V[]){v_c_2417, v_sp_2413});
}
V g_prelude_2etraverse_24s1211845059x266223635_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  V v_sp_2413;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_243)) {
  case TAG_At: {
    V v_a_2412 = heff_field(v_x_243, 1);
    heff_take_n(v_x_243, 2ULL, 2);
    v_sp_2413 = v_a_2412;
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  V v_typ_2414 = v_a_248;
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkSmallTyp, 1, (V[]){heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam4, 1, 2, (V[]){v_typ_2414, v_sp_2413})}), v_a_2410});
  V f_ = v_a_247;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_a_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = (g_prelude_2etraverse_24s1211845059x266223635(v_xs_244));
  V f_ = v_t_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam3, 1, 3, (V[]){v_x_243, v_a_248, v_a_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1211845059x266223635_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_245;
  args[0] = heff_dup(v_a_246);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam2, 1, 4, (V[]){v_xs_244, v_a_246, v_x_243, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s1310917876x950458632_lam0(V self, V *args);
V g_prelude_2etraverse_24s1310917876x950458632_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1310917876x950458632_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1310917876x950458632_entry, 2, 0};

V g_prelude_2etraverse_24s1310917876x950458632(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    HEFF_LAST return g_prelude_2etraverse_24s1310917876x950458632_24apply2(v_p_241, NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_244 = v_x_242;
    V v_p_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Lam0_24prelude_2etraverse_24s1310917876x950458632_24apply1, 2, (V[]){v_xs_243, v_p_241});
    switch (heff_tag_of(v_x1_244)) {
    case TAG_At: {
      V v_x11_246 = heff_field(v_x1_244, 0);
      V v_sp_247 = heff_field(v_x1_244, 1);
      V v_ru_24x1_244_24At = heff_take_reuse_n(v_x1_244, 3ULL, 2);
      switch (heff_tag_of(v_x11_246)) {
      case TAG_ExplicitParam: {
        V v_x_248 = heff_field(v_x11_246, 0);
        V v_t_2410 = heff_field(v_x11_246, 2);
        heff_take_n(v_x11_246, 5ULL, 3);
        V v_n_2413;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_At: {
          V v_n_2411 = heff_field(v_t_2410, 0);
          V v_sp_2412 = heff_field(v_t_2410, 1);
          heff_take_n(v_t_2410, 3ULL, 2);
          v_n_2413 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x1_244_24At, v_sp_2412, v_n_2411));
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        V v_t_2414 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2413));
        return heff_tail(v_t_2414, 2, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_prelude_2etraverse_24s1310917876x950458632_lam0, 1, 3, (V[]){v_sp_247, v_x_248, v_p_245})});
      }
      case TAG_ImplicitParam: {
        V v_x_2417 = heff_field(v_x11_246, 0);
        V v_t_2419 = heff_field(v_x11_246, 2);
        heff_take_n(v_x11_246, 5ULL, 3);
        V v_n_2422;
        switch (heff_tag_of(v_t_2419)) {
        case TAG_At: {
          V v_n_2420 = heff_field(v_t_2419, 0);
          V v_sp_2421 = heff_field(v_t_2419, 1);
          heff_take_n(v_t_2419, 3ULL, 2);
          v_n_2422 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x1_244_24At, v_sp_2421, v_n_2420));
          break;
        }
        default: heff_nomatch(v_t_2419);
        }
        V v_t_2423 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2422));
        return heff_tail(v_t_2423, 2, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_prelude_2etraverse_24s1310917876x950458632_lam1, 1, 3, (V[]){v_sp_247, v_x_2417, v_p_245})});
      }
      default: return heff_nomatch(v_x11_246);
      }
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1310917876x950458632_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1310917876x950458632(a[0], a[1]);
}
V g_prelude_2etraverse_24s1310917876x950458632_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sp_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_247, v_x_248, v_x_2415, NTAG(TAG_Expl)});
  return (g_prelude_2etraverse_24s1310917876x950458632_24apply1(v_p_245, v_t_2416));
}
V g_prelude_2etraverse_24s1310917876x950458632_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_sp_247 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2425 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_247, v_x_2417, v_x_2424, NTAG(TAG_Impl)});
  return (g_prelude_2etraverse_24s1310917876x950458632_24apply1(v_p_245, v_t_2425));
}
Clo g_prelude_2e_2b_2b_24f658301291x587486003_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f658301291x587486003_entry, 2, 0};

V g_prelude_2e_2b_2b_24f658301291x587486003(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_x12_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_247 = ({ V a_0 = v_ys_240; V a_1 = v_x12_243; V a_2 = v_cell_246; V r_ = (g_prelude_2e_2b_2b_24f658301291x587486003_24dps(a_0, a_1, a_2)); heff_drop(v_ys_240); r_; });
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f658301291x587486003_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f658301291x587486003(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f658301291x587486003_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f658301291x587486003_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f658301291x587486003_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_x12_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_ys_240;
      V t_1 = v_x12_244;
      V t_2 = v_u_248;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x12_244);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f658301291x587486003_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f658301291x587486003_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f368057430x559112032_entry, 2, 0};

V g_prelude_2e_2b_2b_24f368057430x559112032(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s930188071x496633547(v_x_242, v_xs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_246 = ({ V a_0 = v_ys_240; V a_1 = v_t_244; V a_2 = v_cell_245; V r_ = (g_prelude_2e_2b_2b_24f368057430x559112032_24dps(a_0, a_1, a_2)); heff_drop(v_ys_240); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f368057430x559112032(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f368057430x559112032_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f368057430x559112032_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_245 = (g_list_2ekeepIf_24s930188071x496633547(v_x_243, v_xs_244));
    V v_cell_246 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = v_ys_240;
    V t_1 = v_t_245;
    V t_2 = v_u_247;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f368057430x559112032_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f1681798656x925918587_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1681798656x925918587_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1681798656x925918587(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_EVar, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = ({ V a_0 = v_ys_240; V a_1 = v_xs_243; V a_2 = v_cell_245; V r_ = (g_prelude_2e_2b_2b_24f1681798656x925918587_24dps(a_0, a_1, a_2)); heff_drop(v_ys_240); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1681798656x925918587_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1681798656x925918587(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f489629841x1061860251_entry, 3, 0};

V g_prelude_2e_2b_2b_24f489629841x1061860251(V v_ys_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_prelude_2e_2b_2b(v_ys_242, v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = ({ V a_0 = v_ys_240; V a_1 = v_xs_244; V a_2 = v_ys_242; V a_3 = v_cell_245; V r_ = (g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_ys_240); heff_drop(v_ys_242); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f489629841x1061860251(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_x12_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_ys_240;
      V t_1 = v_x12_244;
      V t_2 = v_u_248;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x12_244);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_prelude_2e_2b_2b_24f709746438x971999636_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1306153264x1245859556_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1306153264x1245859556(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_strAppend(heff_dup(v_lit_241), v_x_243);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = ({ V a_0 = v_ys_240; V a_1 = v_lit_241; V a_2 = v_xs_244; V a_3 = v_cell_246; V r_ = (g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_ys_240); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1306153264x1245859556(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_strAppend(heff_dup(v_lit_241), v_x_244);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_248;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_entry, 10, 0};

V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_x3_248);
    return heff_setField(heff_dup(v_d_249), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_247, 0);
    V v_xs_2411 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_x_2410);
      heff_drop(v_xs_2411);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return heff_setField(heff_dup(v_d_249), MK_INT(1LL), heff_dup(v_ys_240));
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_x3_248, 0);
      V v_ys_2413 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2414 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2410); r_; });
      V v_t_2415 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2414), heff_dup(v_lit_245));
      V v_t_2416 = heff_strAppend(v_t_2415, heff_intShow(v_y_2412));
      V v_x_2417 = heff_strAppend(v_t_2416, heff_dup(v_lit_246));
      V v_cell_2418 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2419 = heff_setFieldPeek(v_d_249, MK_INT(1LL), v_cell_2418);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_2411;
      V t_8 = v_ys_2413;
      V t_9 = v_u_2419;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      v_x3_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2e_2b_2b_24f543054808x1503188303_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a9 = a[9]; V r = g_prelude_2e_2b_2b_24f543054808x1503188303_24dps(a0, a1, a2, a3, a4, a5, a6, a[7], a[8], a9); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a9); return r;
}
Clo g_prelude_2e_2b_2b_24f603353378x1069129212_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f603353378x1069129212_entry, 10, 0};

V g_prelude_2e_2b_2b_24f603353378x1069129212(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248, V v_x3_249) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    heff_drop(v_lit_247);
    heff_drop(v_x3_249);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_248, 0);
    V v_xs_2411 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_244);
      heff_drop(v_lit_247);
      heff_drop(v_x_2410);
      heff_drop(v_xs_2411);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_x3_249, 0);
      V v_ys_2413 = heff_field(v_x3_249, 1);
      heff_take_n(v_x3_249, 3ULL, 2);
      V v_t_2414 = (g_prelude_2esplit_2esplitFrom_240(v_y_2412, v_lit_243, heff_dup(v_lit_244), heff_strFind_lent(v_lit_245, v_y_2412, v_lit_246, 0), NTAG(TAG_Nil)));
      V v_t_2415 = ({ V a_0 = v_y_2412; V a_1 = v_t_2414; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_y_2412); heff_drop(v_t_2414); r_; });
      V v_t_2416 = heff_strAppend(heff_dup(v_lit_241), heff_intShow(v_x_2410));
      V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, heff_dup(v_lit_242)), v_t_2415);
      V v_x_2418 = heff_strAppend(v_t_2417, heff_dup(v_lit_247));
      V v_cell_2419 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_x_2418, heff_hole()});
      V v_u_2420 = ({ V a_0 = v_ys_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_lit_247; V a_8 = v_xs_2411; V a_9 = v_ys_2413; V a_10 = v_cell_2419; V r_ = (g_prelude_2e_2b_2b_24f603353378x1069129212_24dps(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_ys_240); heff_drop(v_lit_241); heff_drop(v_lit_242); heff_drop(v_lit_244); heff_drop(v_lit_247); r_; });
      heff_drop(v_u_2420);
      return v_cell_2419;
    }
    default: return heff_nomatch(v_x3_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_prelude_2e_2b_2b_24f603353378x1069129212_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a5 = a[5]; V a6 = a[6]; V r = g_prelude_2e_2b_2b_24f603353378x1069129212(a[0], a[1], a[2], a3, a[4], a5, a6, a[7], a[8], a[9]); heff_drop(a3); heff_drop(a5); heff_drop(a6); return r;
}
Clo g_prelude_2e_2b_2b_24f132290754x1091834184_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f132290754x1091834184_entry, 4, 0};

V g_prelude_2e_2b_2b_24f132290754x1091834184(V v_ys_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_x_246 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), heff_dup(v_lit_242)), heff_intShow(v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = ({ V a_0 = v_ys_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_245; V a_4 = v_cell_247; V r_ = (g_prelude_2e_2b_2b_24f132290754x1091834184_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ys_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2e_2b_2b_24f132290754x1091834184_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f132290754x1091834184(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1815933030x829523367_str0, 1, ":");
Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1815933030x829523367_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1815933030x829523367(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_x_245 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_prelude_2e_2b_2b_24f1815933030x829523367_str0)), v_x_242);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = ({ V a_0 = v_ys_240; V a_1 = v_xs_243; V a_2 = v_cell_246; V r_ = (g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(a_0, a_1, a_2)); heff_drop(v_ys_240); r_; });
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1815933030x829523367(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_241))) {
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_246);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_u_247;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f892794188x1384814865_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_prelude_2e_2b_2b_24f892794188x1384814865_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_dup(v_ys_240));
  }
  case TAG_Cons: {
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_241), heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_246);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_247;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}