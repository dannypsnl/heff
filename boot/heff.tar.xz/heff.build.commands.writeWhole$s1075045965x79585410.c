// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Replace 14236
#define TAG_Right 62770
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_str1, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0(V v_k_240, V v_path_241, V v_text_242, V v_hd_243, V v_x_244) {
top: ;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    heff_take_n(v_x_244, 0ULL, 1);
    heff_drop(v_path_241);
    heff_drop(v_hd_243);
    return heff_tail(v_k_240, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Right: {
    V v_ru_24x_244_24Right = heff_take_reuse_n(v_x_244, 0ULL, 1);
    V v_t_247 = heff_intShow(heff_strLength_lent(v_text_242, 0));
    V v_t_248 = heff_strAppend(heff_strAppend(heff_dup(v_path_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_str0)), v_t_247);
    V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_str1))));
    V v_to_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_241));
    V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_249); r_; });
    V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2410); r_; });
    V v_a_2414 = heff_tag_n(TAG_Replace, 3, (V[]){v_t_2411, v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_lam0_clo)});
    V v_t_2415 = heff_tag_at_n(v_ru_24x_244_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2419, v_hd_243, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_lam1, 1, 1, (V[]){v_k_240})));
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_lam0(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    heff_take_n(v_x_2420, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_240;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    switch (heff_tag_of(v_y_2422)) {
    case TAG_Left: {
      heff_take_n(v_y_2422, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_240;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2422, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_240;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2422);
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}