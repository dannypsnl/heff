// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_said 10017968
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str1, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str2, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str4, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0(V v_st_240, V v_home_241, V v_hd_242, V v_k_243, V v_t_244, V v_next_245, V v_x_246) {
top: ;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    V v_ru_24x_246_24Left = heff_take_reuse_n(v_x_246, 0ULL, 1);
    heff_drop_rec(v_t_244, 6);
    heff_drop(v_next_245);
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_home_241));
    V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str0)));
    V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
    V v_t_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2410); r_; });
    V v_why_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str1), v_t_2411);
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str2), v_why_2412), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str3));
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_at_n(v_ru_24x_246_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_lam0, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  case TAG_Right: {
    V v_ru_24x_246_24Right = heff_take_reuse_n(v_x_246, 0ULL, 1);
    V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_home_241));
    V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str4)));
    V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
    V v_path_2431 = ({ V a_0 = v_st_240; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2430); r_; });
    V v_t_2432 = heff_strAppend(heff_get_n(v_t_244, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str5));
    V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, v_path_2431), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_str6));
    V v_t_2434 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_at_n(v_ru_24x_246_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_lam1, 1, 3, (V[]){v_next_245, v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_lam1(V self, V *args) {
  V v_x_2440 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_drop(v_x_2440);
  heff_clo_take(self, 3);
  V f_ = v_next_245;
  heff_room[0] = v_hd_242;
  heff_room[1] = v_k_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}