// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_F32 16337
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_HE 9070
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_facts 298546081
#define LBL_flat 9641024
#define LBL_params 951713969
#define LBL_result 1012715336
#define LBL_sure 10037468
#define LBL_tuples 1084651734
#define LBL_workers 1757018875
V g_heff_2ecompile_2eemitc_2ecallArgs(V, V);
V g_heff_2ecompile_2eemitc_2ecallArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallArgs_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eemitVer(V, V, V);
V g_heff_2ecompile_2eemitc_2eemitVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitVer_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efixedU(V, V, V);
V g_heff_2ecompile_2eemitc_2efixedU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedU_clo;
V g_heff_2ecompile_2eemitc_2efloat32U(V, V);
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat32U_clo;
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2egivenMask(V, V, V);
V g_heff_2ecompile_2eemitc_2egivenMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egivenMask_clo;
V g_heff_2ecompile_2eemitc_2eglobalH(V, V, V);
V g_heff_2ecompile_2eemitc_2eglobalH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglobalH_clo;
V g_heff_2ecompile_2eemitc_2ehashBelow(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashBelow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashBelow_clo;
V g_heff_2ecompile_2eemitc_2eintU(V, V, V);
V g_heff_2ecompile_2eemitc_2eintU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eintU_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2eparamTypeNames(V);
V g_heff_2ecompile_2eemitc_2eparamTypeNames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamTypeNames_clo;
V g_heff_2ecompile_2eemitc_2epartCount(V, V);
V g_heff_2ecompile_2eemitc_2epartCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartCount_clo;
V g_heff_2ecompile_2eemitc_2eprojShapesW(V, V);
V g_heff_2ecompile_2eemitc_2eprojShapesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprojShapesW_clo;
V g_heff_2ecompile_2eemitc_2eshapeH(V, V, V);
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeH_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2etupleDecl(V, V, V, V);
V g_heff_2ecompile_2eemitc_2etupleDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleDecl_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
V g_heff_2ecompile_2eowned_2elentOperand(V, V);
V g_heff_2ecompile_2eowned_2elentOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2elentOperand_clo;
V g_intShow_get(void);
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1568221543x2050375626(V, V);
V g_list_2efoldl_24s1568221543x2050375626_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1568221543x2050375626_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1386329375x1773300759(V);
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2eemitc_2ehashBelow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ehashBelow_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2ehashBelow(V v_t_240, V v_box_24m_241, V v_box_24i_242, V v_box_24a_243) {
  int64_t v_m_241 = heff_peek_word(v_box_24m_241);
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  int64_t v_a_243 = heff_unbox_word(v_box_24a_243);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_t_240, 0)) <= v_i_242)) {
    return heff_box_word(v_a_243);
  } else {
    int64_t v_t_244 = ((v_a_243 * ((int64_t)31ULL)) + heff_unbox_word(heff_strByteAt_lent(v_t_240, heff_box_word(v_i_242), 2)));
    int64_t v_t_245 = ((v_t_244 + ((int64_t)1ULL)) % v_m_241);
    V t_0 = v_t_240;
    int64_t t_1 = v_m_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    int64_t t_3 = v_t_245;
    v_t_240 = t_0;
    v_m_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ehashBelow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2ehashBelow(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str0, 3, "f32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str1, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str2, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str3, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str4, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str5, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str6, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str7, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str8, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedSuffix_str9, 1, "i");
Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedSuffix_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efixedSuffix(V v_w_240) {
top: ;
  V v_t_241;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_I64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U8: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U16: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U32: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_U64: {
    v_t_241 = NTAG(TAG_False);
    break;
  }
  case TAG_F32: {
    v_t_241 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str0);
  } else {
    heff_drop(v_t_241);
    V v_t_242;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str1);
      break;
    }
    case TAG_I16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str2);
      break;
    }
    case TAG_I32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str3);
      break;
    }
    case TAG_I64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str4);
      break;
    }
    case TAG_U8: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str5);
      break;
    }
    case TAG_U16: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str6);
      break;
    }
    case TAG_U32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str7);
      break;
    }
    case TAG_U64: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str8);
      break;
    }
    case TAG_F32: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efixedSuffix_str9);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_243;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_243 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_243 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_243 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_243 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    return heff_strAppend(v_t_242, heff_intShow(v_t_243));
  }
}
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efixedSuffix(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str2, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str3, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str4, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str6, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str8, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str9, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str10, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str11, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str21, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str22, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str23, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str24, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str26, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efixedU_str27, 1, ")");
Clo g_heff_2ecompile_2eemitc_2efixedU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efixedU_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2efixedU(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_op_241)) {
  case TAG_OpAdd: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpSub: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpMul: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpDiv: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpRem: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpEq: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_OpLt: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_OpLe: {
    v_t_243 = NTAG(TAG_True);
    break;
  }
  case TAG_OpAnd: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpOr: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpXor: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpShl: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpShr: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpShow: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpFromInt: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpToInt: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpSqrt: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpFromFloat: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpToFloat: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  case TAG_OpFloor: {
    v_t_243 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_op_241);
  }
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_246;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_vs_242, 0);
      v_t_246 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    V v_t_247;
    switch (heff_tag_of(v_op_241)) {
    case TAG_OpAdd: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str1);
      break;
    }
    case TAG_OpSub: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str2);
      break;
    }
    case TAG_OpMul: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str3);
      break;
    }
    case TAG_OpDiv: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str4);
      break;
    }
    case TAG_OpRem: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str5);
      break;
    }
    case TAG_OpEq: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str6);
      break;
    }
    case TAG_OpLt: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str7);
      break;
    }
    case TAG_OpLe: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str8);
      break;
    }
    case TAG_OpAnd: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str9);
      break;
    }
    case TAG_OpOr: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str10);
      break;
    }
    case TAG_OpXor: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str11);
      break;
    }
    case TAG_OpShl: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str12);
      break;
    }
    case TAG_OpShr: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str13);
      break;
    }
    case TAG_OpShow: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str14);
      break;
    }
    case TAG_OpFromInt: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str15);
      break;
    }
    case TAG_OpToInt: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str16);
      break;
    }
    case TAG_OpSqrt: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str17);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str18);
      break;
    }
    case TAG_OpToFloat: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str19);
      break;
    }
    case TAG_OpFloor: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str20);
      break;
    }
    default: heff_nomatch(v_op_241);
    }
    HeffT3 v_t_248 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
    {
      V v_field_2410 = v_t_248.f[1];
      V v_field_2411 = v_t_248.f[2];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      V v_t_2414;
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_2410;
        V v_x12_2413 = v_field_2411;
        heff_drop(v_x12_2413);
        v_t_2414 = v_x_2412;
      } else {
        heff_drop(v_field_2410);
        heff_drop(v_field_2411);
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efixedU_str21);
      }
      V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedU_str22), v_t_246), ((V)&g_heff_2ecompile_2eemitc_2efixedU_str23));
      V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, v_t_247), ((V)&g_heff_2ecompile_2eemitc_2efixedU_str24));
      V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2efixedU_str25));
      return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efixedU_str26), v_t_2417), ((V)&g_heff_2ecompile_2eemitc_2efixedU_str27));
    }
  } else {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      HEFF_LAST return g_heff_2ecompile_2eemitc_2eintU(v_w_240, v_op_241, v_vs_242);
    }
    case TAG_I16: {
      HEFF_LAST return g_heff_2ecompile_2eemitc_2eintU(v_w_240, v_op_241, v_vs_242);
    }
    case TAG_I32: {
      HEFF_LAST return g_heff_2ecompile_2eemitc_2eintU(v_w_240, v_op_241, v_vs_242);
    }
    case TAG_I64: {
      HEFF_LAST return g_heff_2ecompile_2eemitc_2eintU(v_w_240, v_op_241, v_vs_242);
    }
    case TAG_U8: {
      HEFF_LAST return g_heff_2ecompile_2eemitc_2eintU(v_w_240, v_op_241, v_vs_242);
    }
    case TAG_U16: {
      HEFF_LAST return g_heff_2ecompile_2eemitc_2eintU(v_w_240, v_op_241, v_vs_242);
    }
    case TAG_U32: {
      HEFF_LAST return g_heff_2ecompile_2eemitc_2eintU(v_w_240, v_op_241, v_vs_242);
    }
    case TAG_U64: {
      HEFF_LAST return g_heff_2ecompile_2eemitc_2eintU(v_w_240, v_op_241, v_vs_242);
    }
    case TAG_F32: {
      return (g_heff_2ecompile_2eemitc_2efloat32U(v_op_241, v_vs_242));
    }
    default: return heff_nomatch(v_w_240);
    }
  }
}
V g_heff_2ecompile_2eemitc_2efixedU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2efixedU(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str1, 14, "heff_drop_tag(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str2, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str4, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str6, 15, "heff_drop_cell(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str7, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str8, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str9, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str11, 14, "heff_drop_rec(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str12, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str14, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str16, 14, "heff_drop_clo(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str17, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str18, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edropAs_str19, 2, ");");
Clo g_heff_2ecompile_2eemitc_2edropAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edropAs_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edropAs(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_KnownTag: {
    V v_n_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str0)));
    V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str2), v_t_243));
    V v_t_245 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2edropAs_str3)), heff_intShow(heff_dup(v_n_242)));
    return heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2edropAs_str4));
  }
  case TAG_KnownCell: {
    V v_n_246 = heff_field(v_x2_241, 0);
    V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str5)));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str6), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str7), v_t_249));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2edropAs_str8)), heff_intShow(heff_dup(v_n_246)));
    return heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2edropAs_str9));
  }
  case TAG_KnownRec: {
    V v_n_2412 = heff_field(v_x2_241, 0);
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str10)));
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str11), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str12), v_t_2413));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2edropAs_str13)), heff_intShow(heff_dup(v_n_2412)));
    return heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2edropAs_str14));
  }
  case TAG_KnownClo: {
    V v_n_2416 = heff_field(v_x2_241, 0);
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edropAs_str15)));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str16), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edropAs_str17), v_t_2417));
    V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2edropAs_str18)), heff_intShow(heff_dup(v_n_2416)));
    return heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2edropAs_str19));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2edropAs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2egivenMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2egivenMask_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2egivenMask(V v_es_240, V v_x2_241, V v_bit_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_bit_242);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2ecompile_2eowned_2elentOperand(v_es_240, v_e_243));
    V v_t_246;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(0LL);
    } else {
      heff_drop(v_t_245);
      v_t_246 = heff_dup(v_bit_242);
    }
    V v_t_247 = (g_heff_2ecompile_2eemitc_2egivenMask(v_es_240, v_rest_244, heff_intMul(v_bit_242, MK_INT(2LL))));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2egivenMask_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2egivenMask(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str2, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str4, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str5, 7, "static ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str7, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunHead_str8, 1, ")");
Clo g_heff_2ecompile_2eemitc_2efunHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunHead_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2efunHead(V v_key_240, V v_xs_241, V v_rs_242, V v_ret_243, V v_w_244) {
top: ;
  V v_t_247;
  if ((heff_dup(v_w_244) == NTAG(TAG_True))) {
    V v_t_245 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str0)));
    v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunHead_str1), v_t_245), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str2));
  } else {
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str3)));
    v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunHead_str4), v_t_246);
  }
  V v_t_248 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_242, heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL)));
  V v_t_249 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_248, v_xs_241));
  V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunHead_str5), v_ret_243), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str6));
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_t_247), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str7));
  return heff_strAppend(heff_strAppend(v_t_2411, v_t_249), ((V)&g_heff_2ecompile_2eemitc_2efunHead_str8));
}
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2efunHead(a0, a[1], a2, a[3], a4); heff_drop(a0); heff_drop(a2); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamTypeNames_str0, 8, "size_t *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamTypeNames_str1, 8, "size_t *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamTypeNames_str2, 8, "size_t *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eparamTypeNames_str3, 8, "size_t *");
Clo g_heff_2ecompile_2eemitc_2eparamTypeNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eparamTypeNames_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eparamTypeNames(V v_b_240) {
top: ;
  V v_args_241 = heff_take_field(v_b_240, 2);
  V v_result_242 = heff_get_n(v_b_240, 3, 5);
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_241));
  V v_t_244 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1568221543x2050375626(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = v_result_242;
  V v_t_2414;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Gives: {
    V v_t_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    switch (heff_tag_of(v_t_246)) {
    case TAG_CInteger: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CDouble: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CBool: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CString: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CText: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_COwnedString: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CBytes: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eparamTypeNames_str0), NTAG(TAG_Nil)});
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eparamTypeNames_str1), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CPointer: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CVoid: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  case TAG_GivesOrErrno: {
    V v_t_2410 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    switch (heff_tag_of(v_t_2410)) {
    case TAG_CInteger: {
      heff_take_n(v_t_2410, 0ULL, 1);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CDouble: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CBool: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CString: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CText: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_COwnedString: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CBytes: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eparamTypeNames_str2), NTAG(TAG_Nil)});
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eparamTypeNames_str3), NTAG(TAG_Nil)});
      break;
    }
    case TAG_CPointer: {
      heff_take_n(v_t_2410, 0ULL, 2);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_CVoid: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  case TAG_DoneOrErrno: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return (g_prelude_2e_2b_2b(v_t_244, v_t_2414));
}
V g_heff_2ecompile_2eemitc_2eparamTypeNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eparamTypeNames(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallArgs_str0, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallArgs_str1, 9, "(size_t)n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallArgs_str2, 1, "a");
Clo g_heff_2ecompile_2eemitc_2ecallArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallArgs_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ecallArgs(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_t_242)) {
    case TAG_CBytes: {
      V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallArgs_str0), heff_intShow(heff_dup(v_i_240)));
      V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallArgs_str1), heff_intShow(heff_dup(v_i_240)));
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246});
      break;
    }
    default: {
      heff_drop(v_t_242);
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallArgs_str2), heff_intShow(heff_dup(v_i_240)));
      v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      break;
    }
    }
    V v_t_249 = (g_heff_2ecompile_2eemitc_2ecallArgs(heff_intAdd(v_i_240, MK_INT(1LL)), v_rest_243));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_248, v_t_249);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2ecallArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecallArgs(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str1, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str2, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str4, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str6, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str8, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str9, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str11, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str13, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str14, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str19, 2, "V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str20, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str22, 2, "V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str23, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str24, 11, "extern Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str25, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str26, 5, "_clo;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str27, 21, "_entry(V self, V *a);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str28, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str30, 2, "V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str31, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2edeclOf_str32, 11, "_get(void);");
Clo g_heff_2ecompile_2eemitc_2edeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2edeclOf_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2edeclOf(V v_ce_240, V v_k_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 0, 11);
  HeffT2 v_t_243 = ({ V a_0 = v_t_242; V a_1 = v_k_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_242); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_n_246 = v_field_245;
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 11);
      HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_k_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_247); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_t_2412;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          v_t_2412 = v_x_2411;
        } else {
          heff_drop(v_field_2410);
          v_t_2412 = MK_INT(0LL);
        }
        if (heff_intLt_c(MK_INT(0LL), v_t_2412)) {
          V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 4, 11);
          V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_k_241; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_t_2413); r_; });
          V v_t_2415 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 8, 11);
          HeffT2 v_t_2416 = ({ V a_0 = v_t_2415; V a_1 = v_k_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2415); r_; });
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            V v_t_2420;
            if ((v_tag_2417 == ((int64_t)0ULL))) {
              V v_x_2419 = v_field_2418;
              v_t_2420 = v_x_2419;
            } else {
              heff_drop(v_field_2418);
              v_t_2420 = MK_INT(0LL);
            }
            return ({ V a_0 = v_k_241; V a_1 = v_n_246; V a_2 = v_t_2414; V a_3 = v_t_2420; V r_ = (g_heff_2ecompile_2eemitc_2etupleDecl(a_0, a_1, a_2, a_3)); heff_drop(v_k_241); heff_drop(v_t_2414); r_; });
          }
        } else {
          V v_ce_2421 = v_ce_240;
          V v_k_2422 = v_k_241;
          V v_n_2423 = v_n_246;
          V v_k_2424 = heff_dup(v_k_2422);
          V v_t_2425 = heff_get_n(heff_get_n(v_ce_2421, 2, 3), 4, 11);
          HeffT2 v_t_2426 = ({ V a_0 = v_t_2425; V a_1 = v_k_2422; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2425); r_; });
          {
            V v_field_2428 = v_t_2426.f[1];
            int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
            V v_t_2446;
            if ((v_tag_2427 == ((int64_t)0ULL))) {
              V v_sg_2429 = v_field_2428;
              V v_result_2430 = heff_take_field(v_sg_2429, 1);
              V v_params_2431 = heff_get_n(v_sg_2429, 0, 2);
              V v_t_2432 = v_result_2430;
              V v_t_2434;
              switch (heff_tag_of(v_t_2432)) {
              case TAG_RepV: {
                v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str0);
                break;
              }
              case TAG_RepFix: {
                V v_w_2433 = heff_field(v_t_2432, 0);
                heff_take_n(v_t_2432, 1ULL, 1);
                v_t_2434 = ({ V a_0 = v_w_2433; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2433); r_; });
                break;
              }
              case TAG_RepF64: {
                v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str1);
                break;
              }
              case TAG_RepInt: {
                v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str2);
                break;
              }
              default: heff_nomatch(v_t_2432);
              }
              V v_t_2435 = ({ V a_0 = v_k_2424; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str3); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_k_2424); r_; });
              V v_t_2436 = heff_dup(v_params_2431);
              V v_t_2442;
              switch (heff_tag_of(v_t_2436)) {
              case TAG_Nil: {
                heff_drop(v_params_2431);
                v_t_2442 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str4);
                break;
              }
              case TAG_Cons: {
                heff_take_n(v_t_2436, 0ULL, 2);
                V v_x2_2439 = (g_list_2emap_24s1386329375x1773300759(v_params_2431));
                switch (heff_tag_of(v_x2_2439)) {
                case TAG_Nil: {
                  v_t_2442 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str5);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2440 = heff_field(v_x2_2439, 0);
                  V v_xs_2441 = heff_field(v_x2_2439, 1);
                  heff_take_n(v_x2_2439, 3ULL, 2);
                  v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str6); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
                  break;
                }
                default: heff_nomatch(v_x2_2439);
                }
                break;
              }
              default: heff_nomatch(v_t_2436);
              }
              V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str7), v_t_2435), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str8));
              V v_t_2444 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str9)), v_t_2443);
              V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str10)), v_t_2442);
              v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str11)), NTAG(TAG_Nil)});
            } else {
              heff_drop(v_k_2424);
              heff_drop(v_field_2428);
              v_t_2446 = NTAG(TAG_Nil);
            }
            V v_t_2447 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_2422, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str12)));
            V v_t_2451;
            if (heff_intEq_c_lent(v_n_2423, MK_INT(0LL), 2)) {
              heff_drop(v_n_2423);
              v_t_2451 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str13);
            } else {
              V v_x2_2448 = (g_list_2ereplicate(v_n_2423, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str14)));
              switch (heff_tag_of(v_x2_2448)) {
              case TAG_Nil: {
                v_t_2451 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str15);
                break;
              }
              case TAG_Cons: {
                V v_x_2449 = heff_field(v_x2_2448, 0);
                V v_xs_2450 = heff_field(v_x2_2448, 1);
                heff_take_n(v_x2_2448, 3ULL, 2);
                v_t_2451 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str16); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
                break;
              }
              default: heff_nomatch(v_x2_2448);
              }
            }
            V v_t_2452 = (g_heff_2ecompile_2eemitc_2emangleW(v_k_2422, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str17)));
            V v_t_2453 = ({ V a_0 = v_k_2422; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str18); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_k_2422); r_; });
            V v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str19), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str20), v_t_2447));
            V v_t_2455 = heff_strAppend(heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str21)), v_t_2451);
            V v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str22), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str23), v_t_2452));
            V v_t_2457 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str24), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str25), v_t_2453));
            V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str26)), NTAG(TAG_Nil)});
            V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2456, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str27)), v_t_2458});
            V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str28)), v_t_2459});
            HEFF_LAST return g_prelude_2e_2b_2b(v_t_2446, v_t_2460);
          }
        }
      }
    } else {
      heff_drop_rec(v_ce_240, 3);
      heff_drop(v_field_245);
      V v_t_2461 = ({ V a_0 = v_k_241; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str29); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_k_241); r_; });
      V v_t_2462 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str30), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2edeclOf_str31), v_t_2461));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2462, ((V)&g_heff_2ecompile_2eemitc_2edeclOf_str32)), NTAG(TAG_Nil)});
    }
  }
}
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2edeclOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2epartCount_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epartCount_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2epartCount(V v_bytes_240, V v_box_24b_241) {
  int64_t v_b_241 = heff_unbox_word(v_box_24b_241);
top: ;
  if (((((int64_t)64ULL) <= v_b_241) || heff_intLe_c_lent(v_bytes_240, heff_box_word((v_b_241 * ((int64_t)160000ULL))), 2))) {
    return heff_box_word(v_b_241);
  } else {
    V t_0 = v_bytes_240;
    int64_t t_1 = (v_b_241 * ((int64_t)2ULL));
    v_bytes_240 = t_0;
    v_b_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2epartCount_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2epartCount(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitVer_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitVer_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitVer_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitVer_str3, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitVer_str4, 1, "-");
V g_heff_2ecompile_2eemitc_2eemitVer_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eemitVer_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eemitVer_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eemitVer_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eemitVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eemitVer_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eemitVer(V v_ce_240, V v_key_241, V v_b_242) {
top: ;
  V v_f_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eshapeH_clo), 1, (V[]){heff_dup(v_ce_240)}));
  V v_z_244 = NTAG(TAG_Nil);
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
  V v_xs_246 = (g_heff_2ecompile_2eemitc_2eprojShapesW(NTAG(TAG_Nil), v_t_245));
  V v_m_247 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_246; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_246); r_; });
  V v_t_248 = ({ V a_0 = v_m_247; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_247); r_; });
  V v_xs_249 = (g_list_2emap_24s1937570095x2110149801(v_t_248));
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
  V v_z_2413 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eemitVer_lam0, 2, 1, (V[]){v_f_243}); V a_1 = v_z_244; V a_2 = v_t_2410; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2410); r_; });
  V v_x1_2414 = (g_heff_2ecompile_2eemitc_2etagsLbls(heff_dup(v_b_242)));
  V v_t_2417;
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 2);
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2414);
  }
  V v_m_2418 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = ({ V a_0 = v_m_2418; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2418); r_; });
  V v_t_2420 = (g_list_2emap_24s1937570095x2110149801(v_t_2419));
  V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_clo_n(g_heff_2ecompile_2eemitc_2eemitVer_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}); V a_2 = v_t_2420; V r_ = (g_list_2efoldl_24f1428393365x1980555854(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_z_2455 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eemitVer_lam2, 2, 1, (V[]){heff_dup(v_ce_240)}); V a_1 = v_z_2413; V a_2 = v_t_2427; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2427); r_; });
  V v_t_2456 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
  V v_t_2457 = (g_heff_2ecompile_2eir_2enubI(v_t_2456));
  V v_xs_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_key_241), v_t_2457});
  V v_m_2459 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2458; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop_tag(v_xs_2458, 2); r_; });
  V v_t_2460 = ({ V a_0 = v_m_2459; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2459); r_; });
  V v_t_2461 = (g_list_2efoldl_24f675617784x1820039874(NTAG(TAG_Nil), v_t_2460));
  V v_t_2464 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eemitVer_lam3, 2, 1, (V[]){v_ce_240}); V a_1 = v_z_2455; V a_2 = v_t_2461; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2461); r_; });
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_242}), v_t_2464});
  V v_items_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_key_241}), v_t_2465});
  HeffT2 v_t_2467 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_2466));
  {
    V v_field_2468 = v_t_2467.f[0];
    V v_field_2469 = v_t_2467.f[1];
    V v_a_2470 = v_field_2468;
    V v_b_2471 = v_field_2469;
    V v_t_2472 = heff_strAppend(heff_intShow(v_a_2470), ((V)&g_heff_2ecompile_2eemitc_2eemitVer_str4));
    return heff_strAppend(v_t_2472, heff_intShow(v_b_2471));
  }
}
V g_heff_2ecompile_2eemitc_2eemitVer_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eemitVer(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eemitVer_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_f_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_f_243;
  args[0] = v_x_2412;
  args[1] = v_acc_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eemitc_2eemitVer_lam1(V self, V *args) {
  V v_t_2421 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 5, 11);
  HeffT2 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_t_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2422); heff_drop(v_t_2421); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2424 == ((int64_t)0ULL)) && ({ V v_x_2426 = heff_dup(v_field_2425); int c_ = 1; heff_drop(v_x_2426); c_; })));
    heff_drop(v_field_2425);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eemitc_2eemitVer_lam2(V self, V *args) {
  V v_acc_2428 = args[0];
  V v_x_2429 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ce_2430 = v_ce_240;
  V v_t_2431 = v_x_2429;
  V v_rest_2432 = v_acc_2428;
  V v_t_2433 = heff_get_n(heff_dup(heff_rfield(v_ce_2430, 2)), 5, 11);
  HeffT2 v_t_2434 = ({ V a_0 = v_t_2433; V a_1 = v_t_2431; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2433); r_; });
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    V v_t_2438;
    if ((v_tag_2435 == ((int64_t)0ULL))) {
      V v_x_2437 = v_field_2436;
      v_t_2438 = v_x_2437;
    } else {
      heff_drop(v_field_2436);
      v_t_2438 = NTAG(TAG_Nil);
    }
    V v_x2_2439 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2438));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ecompile_2eemitc_2eemitVer_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eemitVer_str1); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    V v_t_2443 = heff_get_n(heff_get_n(v_ce_2430, 2, 3), 6, 11);
    HeffT2 v_t_2444 = ({ V a_0 = v_t_2443; V a_1 = v_t_2431; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2443); r_; });
    {
      V v_field_2446 = v_t_2444.f[1];
      int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
      V v_t_2448;
      if ((v_tag_2445 == ((int64_t)0ULL))) {
        V v_x_2447 = v_field_2446;
        v_t_2448 = v_x_2447;
      } else {
        heff_drop(v_field_2446);
        v_t_2448 = NTAG(TAG_Nil);
      }
      V v_x2_2449 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_2448));
      V v_t_2452;
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_Nil: {
        v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2eemitVer_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_xs_2451 = heff_field(v_x2_2449, 1);
        heff_take_n(v_x2_2449, 3ULL, 2);
        v_t_2452 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eemitVer_str3); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2449);
      }
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2452}), v_rest_2432});
      V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2442}), v_t_2453});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2431}), v_t_2454});
    }
  }
}
V g_heff_2ecompile_2eemitc_2eemitVer_lam3(V self, V *args) {
  V v_acc_2462 = args[0];
  V v_x_2463 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eemitc_2eglobalH(v_ce_240, v_x_2463, v_acc_2462));
}