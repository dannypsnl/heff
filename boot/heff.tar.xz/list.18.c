// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EDo 15964
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EQ 8989
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Element 14172
#define TAG_F32 16337
#define TAG_FailBecause 16014
#define TAG_Flat 38290
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_GT 9054
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Kept 49931
#define TAG_LT 9209
#define TAG_Left 13886
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_Often 32846
#define TAG_Pinned 8573
#define TAG_Positional 16703
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtExpr 2862
#define TAG_Tip 31527
#define TAG_Typed 36072
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_discarded 1490202606
#define LBL_doc 309170
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_groups 709681407
#define LBL_input 301716452
#define LBL_item 9738202
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_long 9823043
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_olds 9909235
#define LBL_part 9928890
#define LBL_place 308106529
#define LBL_pre 320797
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_shrinks 154032591
#define LBL_size 10026184
#define LBL_skipped 231818613
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_vars 10107635
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_name__doc__shape[] = {LBL_name, LBL_doc, LBL_shape};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
V g_heff_2ebuild_2ebackcache_2eemitText(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitText_clo;
V g_heff_2ebuild_2ebackcache_2eentriesAt(V, V, V);
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo;
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ecompile_2ecpr_2ebuiltFld(V, V);
V g_heff_2ecompile_2ecpr_2ebuiltFld_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2ebuiltFld_clo;
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(V, V);
V g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070_clo;
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076(V, V, V, V);
V g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076_clo;
V g_heff_2ecompile_2eowned_2egivesNothing(V);
V g_heff_2ecompile_2eowned_2egivesNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2egivesNothing_clo;
V g_heff_2ecompile_2eowned_2ewordOnly(V);
V g_heff_2ecompile_2eowned_2ewordOnly_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2ewordOnly_clo;
V g_list_2eall_24s1373454977x2143028054(V);
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a);
extern Clo g_list_2eall_24s1373454977x2143028054_clo;
V g_list_2eall_24s2069645224x1221092236(V);
V g_list_2eall_24s2069645224x1221092236_entry(V self, V *a);
extern Clo g_list_2eall_24s2069645224x1221092236_clo;
V g_list_2eall_24s442836260x1032582242(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2eall_24s442836260x1032582242_entry(V self, V *a);
extern Clo g_list_2eall_24s442836260x1032582242_clo;
V g_list_2eany_24s245529025x1335240420(V);
V g_list_2eany_24s245529025x1335240420_entry(V self, V *a);
extern Clo g_list_2eany_24s245529025x1335240420_clo;
V g_list_2eany_24s317268364x1703376737(V);
V g_list_2eany_24s317268364x1703376737_entry(V self, V *a);
extern Clo g_list_2eany_24s317268364x1703376737_clo;
V g_list_2eany_24s59996552x836780584(V, V, V, V);
V g_list_2eany_24s59996552x836780584_entry(V self, V *a);
extern Clo g_list_2eany_24s59996552x836780584_clo;
V g_list_2edescending_24s1947111851x612550467(V, V, V);
V g_list_2edescending_24s1947111851x612550467_entry(V self, V *a);
extern Clo g_list_2edescending_24s1947111851x612550467_clo;
HeffT2 g_list_2efind_24s1327702553x1694210434_24cpr(V, V);
V g_list_2efoldl_24s1045622919x1125142156(V, V);
V g_list_2efoldl_24s1045622919x1125142156_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1045622919x1125142156_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1483820613x1826490246(V, V);
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1483820613x1826490246_clo;
V g_list_2efoldl_24s1484108573x1404267297(V, V, V, V);
V g_list_2efoldl_24s1484108573x1404267297_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1484108573x1404267297_clo;
V g_list_2efoldl_24s1920613344x620515025(V, V);
V g_list_2efoldl_24s1920613344x620515025_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1920613344x620515025_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s322049767x2109647543(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s322049767x2109647543_entry(V self, V *a);
extern Clo g_list_2efoldl_24s322049767x2109647543_clo;
V g_list_2efoldl_24s623440618x1627495623(V, V);
V g_list_2efoldl_24s623440618x1627495623_entry(V self, V *a);
extern Clo g_list_2efoldl_24s623440618x1627495623_clo;
V g_list_2efoldl_24s648184591x1070837587(V, V);
V g_list_2efoldl_24s648184591x1070837587_entry(V self, V *a);
extern Clo g_list_2efoldl_24s648184591x1070837587_clo;
V g_list_2efoldl_24s648184591x1070837587_24scalars(V, V, V);
V g_list_2efoldl_24s648184591x1070837587_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s648184591x1070837587_24scalars_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s709051544x56960613(V, V, V);
V g_list_2efoldl_24s709051544x56960613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s709051544x56960613_clo;
V g_list_2efoldl_24s788343806x1528994845(V, V, V);
V g_list_2efoldl_24s788343806x1528994845_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788343806x1528994845_clo;
V g_list_2ekeepIf_24s2034497759x755284100_24dps(V, V, V);
V g_list_2ekeepIf_24s2034497759x755284100_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2034497759x755284100_24dps_clo;
V g_list_2ekeepIf_24s2115931744x466898799_24dps(V, V, V);
V g_list_2ekeepIf_24s2115931744x466898799_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_24dps_clo;
V g_list_2ekeepIf_24s403268044x1108109324(V, V);
V g_list_2ekeepIf_24s403268044x1108109324_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s403268044x1108109324_clo;
V g_list_2ekeepIf_24s425280038x249084439(V, V, V);
V g_list_2ekeepIf_24s425280038x249084439_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s425280038x249084439_clo;
HeffT2 g_list_2elookup_24s1507486579x90027037_24cpr(V, V);
V g_list_2elookup_24s1507486579x90027037_24tok1(V, V, V);
V g_list_2elookup_24s1507486579x90027037_24tok1_entry(V self, V *a);
extern Clo g_list_2elookup_24s1507486579x90027037_24tok1_clo;
V g_list_2emap_24f1320100344x346546677(V, V);
V g_list_2emap_24f1320100344x346546677_entry(V self, V *a);
extern Clo g_list_2emap_24f1320100344x346546677_clo;
V g_list_2emap_24f1320100344x346546677_24dps(V, V, V);
V g_list_2emap_24f1320100344x346546677_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1320100344x346546677_24dps_clo;
V g_list_2emap_24f1744384903x906515519(V);
V g_list_2emap_24f1744384903x906515519_entry(V self, V *a);
extern Clo g_list_2emap_24f1744384903x906515519_clo;
V g_list_2emap_24f1744384903x906515519_24dps(V, V);
V g_list_2emap_24f1744384903x906515519_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1744384903x906515519_24dps_clo;
V g_list_2emap_24f1952774010x636070089(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1952774010x636070089_entry(V self, V *a);
extern Clo g_list_2emap_24f1952774010x636070089_clo;
V g_list_2emap_24f1952774010x636070089_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1952774010x636070089_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1952774010x636070089_24dps_clo;
V g_list_2emap_24s1173914895x100384474_24dps(V, V);
V g_list_2emap_24s1173914895x100384474_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24dps_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1181937096x2120532116_24dps(V, V);
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1181937096x2120532116_24dps_clo;
V g_list_2emap_24s1263350589x621576050(V);
V g_list_2emap_24s1263350589x621576050_entry(V self, V *a);
extern Clo g_list_2emap_24s1263350589x621576050_clo;
V g_list_2emap_24s1263350589x621576050_24dps(V, V);
V g_list_2emap_24s1263350589x621576050_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1263350589x621576050_24dps_clo;
V g_list_2emap_24s1460603830x671758883_24dps(V, V, V);
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24dps_clo;
V g_list_2emap_24s1460603830x671758883_24tok1(V, V, V);
V g_list_2emap_24s1460603830x671758883_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24tok1_clo;
V g_list_2emap_24s1531382666x123921537(V);
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_clo;
V g_list_2emap_24s1531382666x123921537_24dps(V, V);
V g_list_2emap_24s1531382666x123921537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_24dps_clo;
V g_list_2emap_24s1539380703x380520933(V);
V g_list_2emap_24s1539380703x380520933_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_clo;
V g_list_2emap_24s1539380703x380520933_24dps(V, V);
V g_list_2emap_24s1539380703x380520933_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_24dps_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1598879313x231311047_24dps(V, V);
V g_list_2emap_24s1598879313x231311047_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_24dps_clo;
V g_list_2emap_24s1737386070x1499208753(V);
V g_list_2emap_24s1737386070x1499208753_entry(V self, V *a);
extern Clo g_list_2emap_24s1737386070x1499208753_clo;
V g_list_2emap_24s1737386070x1499208753_24dps(V, V);
V g_list_2emap_24s1737386070x1499208753_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1737386070x1499208753_24dps_clo;
V g_list_2emap_24s179832492x431904054(V);
V g_list_2emap_24s179832492x431904054_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_clo;
V g_list_2emap_24s179832492x431904054_24dps(V, V);
V g_list_2emap_24s179832492x431904054_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_24dps_clo;
V g_list_2emap_24s1854779998x1713580578_24dps(V, V);
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_24dps_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_list_2emap_24s2015709068x2065046486_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_24dps_clo;
V g_list_2emap_24s272223926x273382154_24dps(V, V);
V g_list_2emap_24s272223926x273382154_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s272223926x273382154_24dps_clo;
V g_list_2emap_24s338694954x1326523169_24dps(V, V);
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_24dps_clo;
V g_list_2emap_24s357242026x384251201_24dps(V, V);
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_24dps_clo;
V g_list_2emap_24s388277778x1355328594_24dps(V, V);
V g_list_2emap_24s388277778x1355328594_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s388277778x1355328594_24dps_clo;
V g_list_2emap_24s510639937x1058700299(V);
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_clo;
V g_list_2emap_24s510639937x1058700299_24dps(V, V);
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_24dps_clo;
V g_list_2emap_24s580972671x1254803293(V, V, V, V, V, V, V, V);
V g_list_2emap_24s580972671x1254803293_entry(V self, V *a);
extern Clo g_list_2emap_24s580972671x1254803293_clo;
V g_list_2emap_24s580972671x1254803293_24dps(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s580972671x1254803293_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s580972671x1254803293_24dps_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2emap_24s759871588x920431471_24dps(V, V);
V g_list_2emap_24s759871588x920431471_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_24dps_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_list_2emap_24s939813003x1383013550_24dps(V, V);
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_24dps_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2emap_24s976303750x321235480_24dps(V, V);
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_24dps_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate_24dps(V, V, V);
V g_list_2ereplicate_24dps_entry(V self, V *a);
extern Clo g_list_2ereplicate_24dps_clo;
V g_list_2ezipWith_24dps(V, V, V, V);
V g_list_2ezipWith_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24dps_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s667382472x1709340739(V, V);
V g_list_2ezipWith_24s667382472x1709340739_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s667382472x1709340739_clo;
V g_list_2ezipWith_24s667382472x1709340739_24dps(V, V, V);
V g_list_2ezipWith_24s667382472x1709340739_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s667382472x1709340739_24dps_clo;
V g_list_2ezipWith_24s704759456x417074234_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s704759456x417074234_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s704759456x417074234_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275(V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(V, V);
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_clo;
V g_std_2ecli_2ereading_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_list_2ezipWith_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24dps_entry, 4, 0};

V g_list_2ezipWith_24dps(V v_f_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x3_242);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_242, 0);
      V v_ys_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_x_244, v_y_246}));
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_249);
      V t_0 = v_f_240;
      V t_1 = v_xs_245;
      V t_2 = v_ys_247;
      V t_3 = v_u_2410;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_list_2ezipWith_24dps(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_list_2ereplicate_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ereplicate_24dps_entry, 3, 0};

V g_list_2ereplicate_24dps(V v_n_240, V v_x_241, V v_d_242) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_u_244 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_243);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_x_241;
    V t_2 = v_u_244;
    v_n_240 = t_0;
    v_x_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_list_2ereplicate_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2ereplicate_24dps(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s2115931744x466898799_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2115931744x466898799_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s2115931744x466898799_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2115931744x466898799_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s2115931744x466898799_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s322049767x2109647543_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s322049767x2109647543_entry, 14, 0};

V g_list_2efoldl_24s322049767x2109647543(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_z_2412, V v_x3_2413) {
top: ;
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nil: {
    return v_z_2412;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x3_2413, 0);
    V v_xs_2415 = heff_field(v_x3_2413, 1);
    V v_a_2418;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_MkPair: {
      V v_a_2417 = heff_field(v_x_2414, 1);
      v_a_2418 = heff_dup(v_a_2417);
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(v_lit_243, heff_dup(v_lit_244), v_a_2418));
    V v_t_2420 = (g_list_2erange(heff_dup(v_lit_242), heff_intSub_lent(v_t_2419, v_lit_245, 1)));
    V v_t_2421 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2420, v_a_2418));
    V v_t_2422 = (g_list_2ekeepIf_24s425280038x249084439(v_lit_240, v_lit_241, v_t_2421));
    V v_a_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
    V v_t_2437;
    switch (heff_tag_of(v_a_2423)) {
    case TAG_Nil: {
      v_t_2437 = v_z_2412;
      break;
    }
    case TAG_Cons: {
      V v_ru_24a_2423_24Cons = heff_take_reuse_n(v_a_2423, 0ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_MkPair: {
        V v_a_2426 = heff_field(v_x_2414, 0);
        v_t_2428 = heff_dup(v_a_2426);
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_a_2431;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_MkPair: {
        V v_a_2430 = heff_field(v_x_2414, 1);
        v_a_2431 = heff_dup(v_a_2430);
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(v_lit_249, heff_dup(v_lit_2410), v_a_2431));
      V v_t_2433 = (g_list_2erange(heff_dup(v_lit_248), heff_intSub_lent(v_t_2432, v_lit_2411, 1)));
      V v_t_2434 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2433, v_a_2431));
      V v_t_2435 = (g_list_2ekeepIf_24s425280038x249084439(v_lit_246, v_lit_247, v_t_2434));
      V v_t_2436 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24a_2423_24Cons, v_t_2435));
      v_t_2437 = ({ V a_0 = v_z_2412; V a_1 = v_t_2428; V a_2 = v_t_2436; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2428); heff_drop(v_t_2436); r_; });
      break;
    }
    default: heff_nomatch(v_a_2423);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_lit_2410;
    V t_11 = v_lit_2411;
    V t_12 = v_t_2437;
    V t_13 = v_xs_2415;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_lit_2410 = t_10;
    v_lit_2411 = t_11;
    v_z_2412 = t_12;
    v_x3_2413 = t_13;
    goto top;
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
V g_list_2efoldl_24s322049767x2109647543_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V a10 = a[10]; V a11 = a[11]; V a13 = a[13]; V r = g_list_2efoldl_24s322049767x2109647543(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a[12], a13); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); heff_drop(a8); heff_drop(a9); heff_drop(a10); heff_drop(a11); heff_drop(a13); return r;
}
Clo g_list_2emap_24s272223926x273382154_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s272223926x273382154_24dps_entry, 2, 0};

V g_list_2emap_24s272223926x273382154_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_MkAlt: {
        V v_p_246 = heff_field(v_x11_244, 0);
        V v_b_247 = heff_field(v_x11_244, 1);
        V v_ru_24x11_244_24MkAlt = heff_take_reuse_n(v_x11_244, 3ULL, 2);
        V v_t_2417;
        switch (heff_tag_of(v_b_247)) {
        case TAG_At: {
          V v_e1_248 = heff_dup(heff_field(v_b_247, 0));
          switch (heff_tag_of(v_e1_248)) {
          case TAG_EDo: {
            V v_ss_2410 = heff_field(v_e1_248, 0);
            heff_take_n(v_e1_248, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_cell(v_ru_24x_242_24At, 2);
            switch (heff_tag_of(v_b_247)) {
            case TAG_At: {
              heff_take_n(v_b_247, 0ULL, 2);
              v_t_2417 = v_ss_2410;
              break;
            }
            default: heff_nomatch(v_b_247);
            }
            break;
          }
          default: {
            heff_drop(v_e1_248);
            V v_t_2415;
            switch (heff_tag_of(v_b_247)) {
            case TAG_At: {
              V v_s_2414 = heff_dup(heff_field(v_b_247, 1));
              v_t_2415 = v_s_2414;
              break;
            }
            default: heff_nomatch(v_b_247);
            }
            V v_t_2416 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_b_247}), v_t_2415});
            v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_b_247);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x11_244_24MkAlt, TAG_MkPair, 2, (V[]){v_p_246, v_t_2417});
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2419);
    V t_0 = v_xs_243;
    V t_1 = v_u_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s272223926x273382154_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s272223926x273382154_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s338694954x1326523169_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s338694954x1326523169_24dps_entry, 2, 0};

V g_list_2emap_24s338694954x1326523169_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_msg_244 = heff_take_field(v_x_242, 2);
    V v_start_245 = heff_take_field(v_x_242, 0);
    V v_end_246 = heff_get_n(v_x_242, 1, 3);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_244, heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246}), NTAG(TAG_Nothing)});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s338694954x1326523169_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s338694954x1326523169_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s704759456x417074234_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s704759456x417074234_24dps_entry, 6, 0};

V g_list_2ezipWith_24s704759456x417074234_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_x3_244);
    return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_243, 0);
    V v_xs_247 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_x_246);
      heff_drop(v_xs_247);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_x3_244, 0);
      V v_ys_249 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2410;
      if (heff_strEq_c_lent(v_x_246, v_lit_240, 0)) {
        heff_drop(v_x_246);
        v_t_2410 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), heff_dup(v_lit_242)), heff_intShow(v_y_248));
      } else {
        heff_drop(v_y_248);
        v_t_2410 = v_x_246;
      }
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = heff_setFieldPeek(v_d_245, MK_INT(1LL), v_cell_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_247;
      V t_4 = v_ys_249;
      V t_5 = v_u_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_x3_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s704759456x417074234_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a5 = a[5]; V r = g_list_2ezipWith_24s704759456x417074234_24dps(a0, a1, a2, a[3], a[4], a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a5); return r;
}
Clo g_list_2emap_24s1737386070x1499208753_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1737386070x1499208753_entry, 1, 0};

V g_list_2emap_24s1737386070x1499208753(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = heff_field(v_x_241, 2);
      V v_ru_24x_241_24MkArm = heff_take_reuse_n(v_x_241, 7ULL, 3);
      V v_t_246 = (g_heff_2ecompile_2eimperative_2eonceSts_24s1556939157x1399261070(v_a_245, NTAG(TAG_Nothing)));
      v_t_247 = heff_tag_re_n(v_ru_24x_241_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_a_243, v_a_244, v_t_246});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1737386070x1499208753_24dps(v_xs_242, v_cell_248));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1737386070x1499208753_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1737386070x1499208753(a[0]);
}
Clo g_list_2emap_24s1598879313x231311047_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1598879313x231311047_entry, 1, 0};

V g_list_2emap_24s1598879313x231311047(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_RepV), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1598879313x231311047_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1598879313x231311047(a[0]);
}
Clo g_list_2emap_24s1598879313x231311047_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1598879313x231311047_24dps_entry, 2, 0};

V g_list_2emap_24s1598879313x231311047_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_RepV), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1598879313x231311047_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1598879313x231311047_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1134919403x2060330530_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1134919403x2060330530_entry, 2, 0};

V g_list_2efoldl_24s1134919403x2060330530(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2420;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Merge: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Boxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_BoxedWord: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Element: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Unboxed: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Literal: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Wants: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Binds: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Pinned: {
      V v_x_2416 = heff_field(v_x_242, 0);
      v_t_2420 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, v_x_2416, NTAG(TAG_MkUnit)));
      break;
    }
    case TAG_Kept: {
      v_t_2420 = v_z_240;
      break;
    }
    case TAG_Often: {
      v_t_2420 = v_z_240;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2420;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1134919403x2060330530(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s245529025x1335240420_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s245529025x1335240420_entry, 1, 0};

V g_list_2eany_24s245529025x1335240420(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2442;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_ELet: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_t_2442);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2442);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s245529025x1335240420_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s245529025x1335240420(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s976303750x321235480_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s976303750x321235480_entry, 1, 0};

V g_list_2emap_24s976303750x321235480(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V v_e_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_e_243;
      break;
    }
    case TAG_GivenU: {
      V v_e_245 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_249 = v_e_245;
      break;
    }
    case TAG_LentVar: {
      V v_x_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_249 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_LentValue: {
      V v_e_248 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_249 = v_e_248;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s976303750x321235480_24dps(v_xs_242, v_cell_2410));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s976303750x321235480_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s976303750x321235480(a[0]);
}
Clo g_list_2eall_24s2069645224x1221092236_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s2069645224x1221092236_entry, 1, 0};

V g_list_2eall_24s2069645224x1221092236(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_x1_243 = heff_dup(v_x_241);
    V v_t_2491;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_RLocal: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_True);
      break;
    }
    case TAG_RDup: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_True);
      break;
    }
    case TAG_RClo: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RGet: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetRaw: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RInt: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_True);
      break;
    }
    case TAG_RFloat: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RStr: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_True);
      break;
    }
    case TAG_RBytes: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RFixed: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RF32: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RNTag: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_True);
      break;
    }
    case TAG_RStatic: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RTag: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RTagIn: {
      heff_take_n(v_x1_243, 0ULL, 5);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RRec: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RRecIn: {
      heff_take_n(v_x1_243, 0ULL, 8);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RField: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RDupE: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RFieldV: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetN: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RFieldU: {
      heff_take_n(v_x1_243, 0ULL, 4);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetNU: {
      heff_take_n(v_x1_243, 0ULL, 5);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RWord: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RTakeField: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RGetLabel: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimFn: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrim: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RLam: {
      heff_take_n(v_x1_243, 0ULL, 4);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RCall: {
      heff_take_n(v_x1_243, 0ULL, 4);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RApply: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RBool: {
      heff_take_n(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RAbandon: {
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RBox: {
      V v_x11_2475 = heff_field(v_x1_243, 0);
      V v_e_2476 = heff_field(v_x1_243, 1);
      heff_take_n(v_x1_243, 3ULL, 2);
      switch (heff_tag_of(v_x11_2475)) {
      case TAG_RepV: {
        heff_drop(v_e_2476);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_RepFix: {
        heff_take_n(v_x11_2475, 0ULL, 1);
        heff_drop(v_e_2476);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        heff_drop(v_e_2476);
        v_t_2491 = NTAG(TAG_False);
        break;
      }
      case TAG_RepInt: {
        v_t_2491 = ({ V a_0 = v_e_2476; V r_ = (g_heff_2ecompile_2eowned_2ewordOnly(a_0)); heff_drop(v_e_2476); r_; });
        break;
      }
      default: heff_nomatch(v_x11_2475);
      }
      break;
    }
    case TAG_RUnbox: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RPeek: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimU: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RPrimAt: {
      heff_take_n(v_x1_243, 0ULL, 3);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RFixU: {
      heff_take_n(v_x1_243, 0ULL, 2);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RF32U: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    case TAG_RF64U: {
      heff_take_na(v_x1_243, 0ULL, 1);
      v_t_2491 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
      heff_drop(v_t_2491);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_2491);
      V v_t_2492 = (g_heff_2ecompile_2eowned_2egivesNothing(v_x_241));
      if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
        heff_drop(v_t_2492);
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      } else {
        heff_drop(v_t_2492);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s2069645224x1221092236_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s2069645224x1221092236(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1263350589x621576050_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1263350589x621576050_entry, 1, 0};

V g_list_2emap_24s1263350589x621576050(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_FtFloat: {
      v_t_245 = NTAG(TAG_RepF64);
      break;
    }
    case TAG_FtFixed: {
      V v_w_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24FtFixed = heff_take_reuse_n(v_x_241, 1ULL, 1);
      int64_t v_t_244;
      switch (heff_tag_of(v_w_243)) {
      case TAG_I8: {
        v_t_244 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_244 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_244 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_244 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_244 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_244 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      if ((v_t_244 == ((int64_t)64ULL))) {
        v_t_245 = heff_tag_at_n(v_ru_24x_241_24FtFixed, TAG_RepFix, 1, (V[]){v_w_243});
      } else {
        heff_drop(v_w_243);
        heff_drop_cell(v_ru_24x_241_24FtFixed, 1);
        v_t_245 = NTAG(TAG_RepV);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_245 = NTAG(TAG_RepV);
      break;
    }
    case TAG_FtAny: {
      v_t_245 = NTAG(TAG_RepV);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1263350589x621576050_24dps(v_xs_242, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1263350589x621576050_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1263350589x621576050(a[0]);
}
Clo g_list_2emap_24s388277778x1355328594_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s388277778x1355328594_24dps_entry, 2, 0};

V g_list_2emap_24s388277778x1355328594_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Flat, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s388277778x1355328594_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s388277778x1355328594_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s667382472x1709340739_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s667382472x1709340739_entry, 2, 0};

V g_list_2ezipWith_24s667382472x1709340739(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_y_244; V r_ = (g_heff_2ecompile_2ecpr_2ebuiltFld(a_0, a_1)); heff_drop(v_x_242); r_; });
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s667382472x1709340739_24dps(v_xs_243, v_ys_245, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s667382472x1709340739_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s667382472x1709340739(a[0], a[1]);
}
Clo g_list_2efoldl_24s648184591x1070837587_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s648184591x1070837587_entry, 2, 0};

V g_list_2efoldl_24s648184591x1070837587(V v_z_240, V v_x3_241) {
top: ;
  V v_labels_242 = heff_take_field(v_z_240, 0);
  V v_vars_243 = heff_get_n(v_z_240, 1, 2);
  return (g_list_2efoldl_24s648184591x1070837587_24scalars(v_labels_242, v_vars_243, v_x3_241));
}
V g_list_2efoldl_24s648184591x1070837587_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s648184591x1070837587(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_24dps_str0, 5, "(0 - ");
HEFF_LIT(g_list_2emap_24s1181937096x2120532116_24dps_str1, 1, ")");
Clo g_list_2emap_24s1181937096x2120532116_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1181937096x2120532116_24dps_entry, 2, 0};

V g_list_2emap_24s1181937096x2120532116_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    if (heff_intLt_c_lent(v_x_242, MK_INT(0LL), 2)) {
      V v_t_244 = heff_intShow(heff_intSub(MK_INT(0LL), v_x_242));
      v_t_245 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1181937096x2120532116_24dps_str0), v_t_244), ((V)&g_list_2emap_24s1181937096x2120532116_24dps_str1));
    } else {
      v_t_245 = heff_intShow(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
    V t_0 = v_xs_243;
    V t_1 = v_u_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1181937096x2120532116_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1181937096x2120532116_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s1373454977x2143028054_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1373454977x2143028054_entry, 1, 0};

V g_list_2eall_24s1373454977x2143028054(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1373454977x2143028054(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1045622919x1125142156_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1045622919x1125142156_entry, 2, 0};

V g_list_2efoldl_24s1045622919x1125142156(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = ({ V a_0 = v_z_240; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_z_240); r_; });
    V v_ps_245 = (g_list_2ekeepIf_24s403268044x1108109324(v_x_242, v_t_244));
    V v_t_246 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_245; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_245); r_; });
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1045622919x1125142156_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1045622919x1125142156(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s623440618x1627495623_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s623440618x1627495623_entry, 2, 0};

V g_list_2efoldl_24s623440618x1627495623(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2efoldl_24s1920613344x620515025(v_z_240, v_t_2412));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s623440618x1627495623_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s623440618x1627495623(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s510639937x1058700299_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510639937x1058700299_entry, 1, 0};

V g_list_2emap_24s510639937x1058700299(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 3, 5), heff_hole()});
    V v_u_244 = (g_list_2emap_24s510639937x1058700299_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510639937x1058700299(a[0]);
}
Clo g_list_2emap_24s357242026x384251201_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s357242026x384251201_24dps_entry, 2, 0};

V g_list_2emap_24s357242026x384251201_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s357242026x384251201_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s59996552x836780584_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s59996552x836780584_entry, 4, 0};

V g_list_2eany_24s59996552x836780584(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strFind(heff_dup(v_lit_241), heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_242));
    if (heff_intLe_c_lent(v_lit_240, v_t_246, 2)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s59996552x836780584_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eany_24s59996552x836780584(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s1483820613x1826490246_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1483820613x1826490246_entry, 2, 0};

V g_list_2efoldl_24s1483820613x1826490246(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1483820613x1826490246(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1484108573x1404267297_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1484108573x1404267297_entry, 4, 0};

V g_list_2efoldl_24s1484108573x1404267297(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2elower_2epieceStep_24s258686904x2130956076(heff_dup(v_lit_240), v_lit_241, v_z_242, heff_dup(v_x_244)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_246;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1484108573x1404267297_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2efoldl_24s1484108573x1404267297(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2efoldl_24s788343806x1528994845_str0, 2, "$s");
HEFF_LIT(g_list_2efoldl_24s788343806x1528994845_str1, 2, "$s");
Clo g_list_2efoldl_24s788343806x1528994845_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s788343806x1528994845_entry, 3, 0};

V g_list_2efoldl_24s788343806x1528994845(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_fs_245 = heff_dup(v_lit_240);
    V v_mods_246 = heff_take_field(v_fs_245, 0);
    V v_olds_247 = heff_get_n(v_fs_245, 1, 2);
    V v_m_248 = v_z_241;
    V v_x3_249 = heff_dup(v_x_243);
    V v_t_2422;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_MkPair: {
      V v_k_2410 = heff_field(v_x3_249, 0);
      V v_e_2411 = heff_field(v_x3_249, 1);
      heff_take_n(v_x3_249, 3ULL, 2);
      V v_j_2412 = heff_strFind_lent(((V)&g_list_2efoldl_24s788343806x1528994845_str0), v_k_2410, MK_INT(0LL), 5);
      V v_t_2413;
      if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
        heff_drop(v_j_2412);
        v_t_2413 = heff_dup(v_k_2410);
      } else {
        v_t_2413 = heff_strSlice_lent(v_k_2410, MK_INT(0LL), v_j_2412, 6);
      }
      V v_t_2414 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_246, v_t_2413));
      V v_t_2415 = (g_heff_2ebuild_2ebackcache_2eemitText(heff_dup(v_k_2410), v_e_2411));
      V v_j_2416 = heff_strFind_lent(((V)&g_list_2efoldl_24s788343806x1528994845_str1), v_k_2410, MK_INT(0LL), 5);
      V v_t_2417;
      if (heff_intLt_c_lent(v_j_2416, MK_INT(0LL), 2)) {
        heff_drop(v_j_2416);
        v_t_2417 = heff_dup(v_k_2410);
      } else {
        v_t_2417 = heff_strSlice_lent(v_k_2410, MK_INT(0LL), v_j_2416, 6);
      }
      V v_t_2418 = ({ V a_0 = v_mods_246; V a_1 = v_t_2417; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_246); r_; });
      V v_es_2419 = ({ V a_0 = v_olds_247; V a_1 = v_m_248; V a_2 = v_t_2418; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(a_0, a_1, a_2)); heff_drop(v_olds_247); heff_drop(v_t_2418); r_; });
      V v_t_2420 = ({ V a_0 = heff_take_field(v_es_2419, 2); V a_1 = v_k_2410; V a_2 = v_t_2415; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_k_2410); heff_drop(v_t_2415); r_; });
      V v_t_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_es_2419, 11ULL, 4, shape_groups__copies__emits__jss, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      v_t_2422 = ({ V a_0 = v_m_248; V a_1 = v_t_2414; V a_2 = v_t_2421; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2414); heff_drop_rec(v_t_2421, 4); r_; });
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2422;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s788343806x1528994845_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s788343806x1528994845(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s939813003x1383013550_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s939813003x1383013550_entry, 1, 0};

V g_list_2emap_24s939813003x1383013550(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(v_x_241, 2, 5);
    V v_t_248;
    switch (heff_tag_of(v_t_243)) {
    case TAG_SizeDefault: {
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_243, 0ULL, 1);
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeName: {
      V v_x_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 3);
      v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s939813003x1383013550_24dps(v_xs_242, v_cell_249));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s939813003x1383013550(a[0]);
}
Clo g_list_2efoldl_24s709051544x56960613_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s709051544x56960613_entry, 3, 0};

V g_list_2efoldl_24s709051544x56960613(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, heff_dup(v_lit_240)), v_x_243);
    V t_0 = v_lit_240;
    V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, v_z_241});
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s709051544x56960613_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efoldl_24s709051544x56960613(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_list_2efind_24s1327702553x1694210434_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s2031248677x950202423_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2031248677x950202423_entry, 2, 0};

V g_list_2efoldl_24s2031248677x950202423(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b_24f1537904782x516751275(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2031248677x950202423(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s759871588x920431471_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s759871588x920431471_entry, 1, 0};

V g_list_2emap_24s759871588x920431471(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 9), heff_hole()});
    V v_u_244 = (g_list_2emap_24s759871588x920431471_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s759871588x920431471_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s759871588x920431471(a[0]);
}
Clo g_list_2emap_24s179832492x431904054_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s179832492x431904054_entry, 1, 0};

V g_list_2emap_24s179832492x431904054(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 2, 5), heff_hole()});
    V v_u_244 = (g_list_2emap_24s179832492x431904054_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s179832492x431904054_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s179832492x431904054(a[0]);
}
Clo g_list_2emap_24s580972671x1254803293_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580972671x1254803293_entry, 8, 0};

V g_list_2emap_24s580972671x1254803293(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 12);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_a_2410 = heff_dup(heff_rfield(v_lit_241, 4));
    V v_t_2414;
    if (heff_intEq_c_lent(v_a_2410, v_lit_242, 0)) {
      heff_drop(v_a_2410);
      v_t_2414 = heff_dup(v_lit_243);
    } else {
      V v_t_2413;
      switch (heff_tag_of(v_x_248)) {
      case TAG_MkPair: {
        V v_a_2412 = heff_dup(heff_field(v_x_248, 1));
        v_t_2413 = v_a_2412;
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      v_t_2414 = heff_intDiv(heff_intMul_lent(v_t_2413, v_lit_244, 1), v_a_2410);
    }
    V v_t_2417;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2415 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 2);
      v_t_2417 = v_a_2415;
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2418 = heff_strAppend(heff_intShow(v_t_2414), heff_dup(v_lit_245));
    V v_t_2419 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2418), heff_dup(v_lit_246));
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2419, v_t_2417), heff_hole()});
    V v_u_2421 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V a_7 = v_xs_249; V a_8 = v_cell_2420; V r_ = (g_list_2emap_24s580972671x1254803293_24dps(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_lit_240); heff_drop_rec(v_lit_241, 12); heff_drop(v_lit_242); heff_drop(v_lit_243); heff_drop(v_lit_244); heff_drop(v_lit_245); heff_drop(v_lit_246); r_; });
    heff_drop(v_u_2421);
    return v_cell_2420;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2emap_24s580972671x1254803293_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580972671x1254803293(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2eall_24s442836260x1032582242_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s442836260x1032582242_entry, 11, 0};

V g_list_2eall_24s442836260x1032582242(V v_lit_240, V v_box_24lit_241, V v_box_24lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_box_24lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_box_24lit_248, V v_box_24lit_249, V v_x2_2410) {
  int64_t v_lit_241 = heff_peek_word(v_box_24lit_241);
  int64_t v_lit_242 = heff_peek_word(v_box_24lit_242);
  int64_t v_lit_243 = heff_peek_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_peek_word(v_box_24lit_244);
  int64_t v_lit_245 = heff_peek_word(v_box_24lit_245);
  int64_t v_lit_246 = heff_peek_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_peek_word(v_box_24lit_247);
  int64_t v_lit_248 = heff_peek_word(v_box_24lit_248);
  int64_t v_lit_249 = heff_peek_word(v_box_24lit_249);
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    V v_a_2413 = heff_strByteAt_lent(v_lit_240, v_x_2411, 0);
    if ((((v_lit_241 <= heff_peek_word(v_a_2413)) && (heff_peek_word(v_a_2413) <= v_lit_242)) || (((v_lit_243 <= heff_peek_word(v_a_2413)) && (heff_peek_word(v_a_2413) <= v_lit_244)) || (((v_lit_245 <= heff_peek_word(v_a_2413)) && (heff_peek_word(v_a_2413) <= v_lit_246)) || ((heff_peek_word(v_a_2413) == v_lit_247) || ((heff_peek_word(v_a_2413) == v_lit_248) || (heff_peek_word(v_a_2413) == v_lit_249))))))) {
      heff_drop(v_a_2413);
      V t_0 = v_lit_240;
      int64_t t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      int64_t t_4 = v_lit_244;
      int64_t t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      int64_t t_8 = v_lit_248;
      int64_t t_9 = v_lit_249;
      V t_10 = v_xs_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_x2_2410 = t_10;
      goto top;
    } else {
      heff_drop(v_a_2413);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2eall_24s442836260x1032582242_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V a10 = a[10]; V r = g_list_2eall_24s442836260x1032582242(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); heff_drop(a8); heff_drop(a9); heff_drop(a10); return r;
}
Clo g_list_2emap_24s2015709068x2065046486_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2015709068x2065046486_entry, 7, 0};

V g_list_2emap_24s2015709068x2065046486(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(heff_dup(v_lit_243), heff_dup(v_lit_244))});
    V v_t_2413 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_t_2411, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_2412}), heff_dup(v_lit_245), NTAG(TAG_Nil)});
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_xs_248; V a_7 = v_cell_2414; V r_ = (g_list_2emap_24s2015709068x2065046486_24dps(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); heff_drop(v_lit_243); heff_drop(v_lit_244); heff_drop(v_lit_245); r_; });
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2015709068x2065046486(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2edescending_24s1947111851x612550467_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s1947111851x612550467_entry, 3, 0};

V g_list_2edescending_24s1947111851x612550467(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 4);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x4_242, 0);
    V v_ys_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_a_245 = ({ V b_0 = heff_get_n(v_x_240, 1, 4); V a_1 = heff_rfield(v_y_243, 1); V r_ = (g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_a_245)) {
    case TAG_LT: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_243, v_ys_244})});
    }
    case TAG_EQ: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_243, v_ys_244})});
    }
    case TAG_GT: {
      V t_0 = heff_dup(v_y_243);
      V t_1 = heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_243, v_acc_241});
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_a_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2edescending_24s1947111851x612550467_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s1947111851x612550467(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1854779998x1713580578_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1854779998x1713580578_24dps_entry, 2, 0};

V g_list_2emap_24s1854779998x1713580578_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 8), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1854779998x1713580578_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1854779998x1713580578_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1531382666x123921537_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1531382666x123921537_entry, 1, 0};

V g_list_2emap_24s1531382666x123921537(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_args_243 = heff_take_field(v_x_241, 3);
    V v_name_244 = heff_take_field(v_x_241, 0);
    V v_doc_245 = heff_get_n(v_x_241, 1, 4);
    V v_t_246 = heff_tr(heff_call(v_args_243, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_t_247 = heff_rec_n(3, shape_name__doc__shape, (V[]){v_name_244, v_doc_245, heff_get_n(v_t_246, 0, 2)});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_list_2emap_24s1531382666x123921537_24dps(v_xs_242, v_cell_248));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1531382666x123921537_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1531382666x123921537(a[0]);
}
HEFF_LIT(g_list_2emap_24s1539380703x380520933_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1539380703x380520933_str1, 0, "");
Clo g_list_2emap_24s1539380703x380520933_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1539380703x380520933_entry, 1, 0};

V g_list_2emap_24s1539380703x380520933(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_list_2emap_24s1539380703x380520933_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_244 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_list_2emap_24s1539380703x380520933_str1)), v_t_243});
    V v_t_245 = heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Positional, 1, (V[]){v_x_241}), heff_tag_n(TAG_Typed, 1, (V[]){v_t_244})});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1539380703x380520933_24dps(v_xs_242, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1539380703x380520933_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1539380703x380520933(a[0]);
}
Clo g_list_2eany_24s317268364x1703376737_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s317268364x1703376737_entry, 1, 0};

V g_list_2eany_24s317268364x1703376737(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    if (((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_x_241, MK_INT(0LL), 2)) == ((int64_t)45ULL)))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s317268364x1703376737_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s317268364x1703376737(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s2034497759x755284100_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2034497759x755284100_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s2034497759x755284100_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c(v_t_247, heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_248 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_249 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2034497759x755284100_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s2034497759x755284100_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1744384903x906515519_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1744384903x906515519_entry, 1, 0};

V g_list_2emap_24f1744384903x906515519(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_name_245 = heff_take_field(v_x_244, 0);
      V v_span_246 = heff_take_field(v_x_244, 1);
      V v_ty_247 = heff_take_field(v_x_244, 2);
      V v_whole_248 = heff_get_n(v_x_244, 4, 5);
      V v_t_249 = heff_tag_n(TAG_DeclareField, 4, (V[]){v_name_245, v_span_246, v_ty_247, NTAG(TAG_Nothing)});
      V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_whole_248}), heff_hole()});
      V v_u_2411 = (g_list_2emap_24f1744384903x906515519_24dps(v_rest_242, v_cell_2410));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2emap_24f1744384903x906515519_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1744384903x906515519(a[0]);
}
Clo g_list_2emap_24f1320100344x346546677_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1320100344x346546677_entry, 2, 0};

V g_list_2emap_24f1320100344x346546677(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, NTAG(TAG_MkUnit)});
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f1320100344x346546677_24dps(v_p_240, v_xs_243, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1320100344x346546677_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f1320100344x346546677(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f1952774010x636070089_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1952774010x636070089_entry, 9, 0};

V g_list_2emap_24f1952774010x636070089(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (!heff_strEq_c_lent(heff_strSlice_lent(v_x_249, v_lit_245, v_lit_246, 0), v_lit_247, 1)) {
      V v_t_2412;
      if (heff_strEq_c_lent(heff_strSlice_lent(v_x_249, v_lit_240, v_lit_241, 0), v_lit_242, 1)) {
        V v_t_2411 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_244), heff_strLength(v_x_249));
        v_t_2412 = heff_strAppend(heff_dup(v_lit_243), v_t_2411);
      } else {
        v_t_2412 = v_x_249;
      }
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = (g_list_2emap_24f1952774010x636070089_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_xs_2410, v_cell_2413));
      heff_drop(v_u_2414);
      return v_cell_2413;
    } else {
      heff_drop(v_x_249);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2410;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24f1952774010x636070089_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24f1952774010x636070089(a0, a1, a2, a3, a4, a5, a6, a7, a[8]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2elookup_24s1507486579x90027037_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_list_2elookup_24s1507486579x90027037_24tok1_entry, 3, 0};

V g_list_2elookup_24s1507486579x90027037_24tok1(V v_tok_240, V v_k_241, V v_x2_242) {
top: ;
  HeffT2 v_t_243 = (g_list_2elookup_24s1507486579x90027037_24cpr(v_k_241, v_x2_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_list_2elookup_24s1507486579x90027037_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2elookup_24s1507486579x90027037_24tok1(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1173914895x100384474_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1173914895x100384474_24tok2_entry, 2, 0};

V g_list_2emap_24s1173914895x100384474_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_y_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1173914895x100384474_24dps(v_xs_243, v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1173914895x100384474_24tok2(a[0], a[1]);
}
Clo g_list_2emap_24s1460603830x671758883_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1460603830x671758883_24tok1_entry, 3, 0};

V g_list_2emap_24s1460603830x671758883_24tok1(V v_tok_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_EStr, 1, (V[]){heff_dup(v_lit_241)}), heff_hole()});
    V v_u_246 = ({ V a_0 = v_lit_241; V a_1 = v_xs_244; V a_2 = v_cell_245; V r_ = (g_list_2emap_24s1460603830x671758883_24dps(a_0, a_1, a_2)); heff_drop(v_lit_241); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1460603830x671758883_24tok1_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1460603830x671758883_24tok1(a[0], a[1], a[2]);
}