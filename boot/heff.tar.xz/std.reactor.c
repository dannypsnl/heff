// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Begin 41697
#define TAG_Close 2276
#define TAG_CloseGiving 1232
#define TAG_End 17255
#define TAG_Finish 61316
#define TAG_MakeGiving 40807
#define TAG_Open 48267
#define TAG_Pending 60181
#define TAG_Wake 10253
#define TAG_Within 10658
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_std_2ereactor_2ereactor_get(void);
V g_std_2ereactor_2ereactor_lam1(V self, V *args);
V g_std_2ereactor_2ereactor_lam2(V self, V *args);
V g_std_2ereactor_2ereactor_lam5(V self, V *args);
V g_std_2ereactor_2ereactor_lam4(V self, V *args);
V g_std_2ereactor_2ereactor_lam3(V self, V *args);
V g_std_2ereactor_2ereactor_lam8(V self, V *args);
V g_std_2ereactor_2ereactor_lam7(V self, V *args);
V g_std_2ereactor_2ereactor_lam6(V self, V *args);
V g_std_2ereactor_2ereactor_lam9(V self, V *args);
V g_std_2ereactor_2ereactor_lam10(V self, V *args);
V g_std_2ereactor_2ereactor_lam11(V self, V *args);
V g_std_2ereactor_2ereactor_lam0(V self, V *args); static Clo g_std_2ereactor_2ereactor_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2ereactor_lam0, 3, 0};
V g_std_2ereactor_2ereactor_lam12(V self, V *args); static Clo g_std_2ereactor_2ereactor_lam12_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2ereactor_lam12, 4, 0};

static V g_std_2ereactor_2ereactor_val;
static HEFF_ONCE g_std_2ereactor_2ereactor_st;
static V g_std_2ereactor_2ereactor_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2ereactor_2ereactor_lam0_clo), ((V)&g_std_2ereactor_2ereactor_lam12_clo)});
}
V g_std_2ereactor_2ereactor_get(void) {
  if (HEFF_DONE(g_std_2ereactor_2ereactor_st)) return g_std_2ereactor_2ereactor_val;
  return heff_global(&g_std_2ereactor_2ereactor_val, &g_std_2ereactor_2ereactor_st, g_std_2ereactor_2ereactor_init);
}
V g_std_2ereactor_2ereactor_lam1(V self, V *args) {
  V v_i_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_i_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam2(V self, V *args) {
  V v_b_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tr(heff_call(v_k_248, 1, (V[]){v_b_249}));
  V f_ = v_g_241;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam5(V self, V *args) {
  V v_w_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_w_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam4(V self, V *args) {
  V v_v_2414 = args[0];
  V v_k_2415 = args[1];
  V v_use_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2413;
  args[0] = v_v_2414;
  args[1] = heff_clo_n(g_std_2ereactor_2ereactor_lam5, 1, 2, (V[]){v_k_2415, v_g_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ereactor_2ereactor_lam3(V self, V *args) {
  V v_use_2413 = args[0];
  V v_b_2412 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2412;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam4, 2, 2, (V[]){v_use_2413, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam8(V self, V *args) {
  V v_l_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_call(v_k_2422, 1, (V[]){v_l_2423}));
  V f_ = v_g_241;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam7(V self, V *args) {
  V v_k_2422 = args[0];
  V v_use_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2421;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam8, 1, 2, (V[]){v_k_2422, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam6(V self, V *args) {
  V v_use_2421 = args[0];
  V v_f_2420 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_f_2420;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam7, 1, 2, (V[]){v_use_2421, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam9(V self, V *args) {
  V v_j_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tr(heff_call(v_k_2429, 1, (V[]){v_j_2430}));
  V f_ = v_g_241;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam10(V self, V *args) {
  V v_n_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_tr(heff_call(v_k_2436, 1, (V[]){v_n_2437}));
  V f_ = v_g_241;
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam11(V self, V *args) {
  V v_gv_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = heff_tr(heff_call(v_k_2441, 1, (V[]){v_gv_2442}));
  V f_ = v_g_241;
  args[0] = v_t_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Open: {
    V v_failing_243 = heff_field(v_p_242, 0);
    V v_k_244 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Open = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24Open, TAG_Open, 2, 1ULL, (V[]){v_failing_243, heff_clo_n(g_std_2ereactor_2ereactor_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
  }
  case TAG_Begin: {
    V v_i_247 = heff_field(v_p_242, 0);
    V v_k_248 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Begin = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24Begin, TAG_Begin, 2, 1ULL, (V[]){v_i_247, heff_clo_n(g_std_2ereactor_2ereactor_lam2, 1, 2, (V[]){v_k_248, v_g_241})});
  }
  case TAG_End: {
    V v_i_2411 = heff_field(v_p_242, 0);
    V v_b_2412 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24End = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24End, TAG_End, 2, 1ULL, (V[]){v_i_2411, heff_clo_n(g_std_2ereactor_2ereactor_lam3, 1, 2, (V[]){v_b_2412, v_g_241})});
  }
  case TAG_Finish: {
    V v_i_2418 = heff_field(v_p_242, 0);
    V v_w_2419 = heff_field(v_p_242, 1);
    V v_f_2420 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Finish = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24Finish, TAG_Finish, 3, 3ULL, (V[]){v_i_2418, v_w_2419, heff_clo_n(g_std_2ereactor_2ereactor_lam6, 1, 2, (V[]){v_f_2420, v_g_241})});
  }
  case TAG_Close: {
    V v_i_2425 = heff_field(v_p_242, 0);
    V v_x_2426 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Close = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2427 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2426}));
    return heff_tag_re_n(v_ru_24p_242_24Close, TAG_Close, 2, 1ULL, (V[]){v_i_2425, v_t_2427});
  }
  case TAG_Within: {
    V v_i_2428 = heff_field(v_p_242, 0);
    V v_k_2429 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Within = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24Within, TAG_Within, 2, 1ULL, (V[]){v_i_2428, heff_clo_n(g_std_2ereactor_2ereactor_lam9, 1, 2, (V[]){v_k_2429, v_g_241})});
  }
  case TAG_Wake: {
    V v_i_2432 = heff_field(v_p_242, 0);
    V v_x_2433 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Wake = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2433}));
    return heff_tag_re_n(v_ru_24p_242_24Wake, TAG_Wake, 2, 1ULL, (V[]){v_i_2432, v_t_2434});
  }
  case TAG_Pending: {
    V v_i_2435 = heff_field(v_p_242, 0);
    V v_k_2436 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Pending = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_re_n(v_ru_24p_242_24Pending, TAG_Pending, 2, 1ULL, (V[]){v_i_2435, heff_clo_n(g_std_2ereactor_2ereactor_lam10, 1, 2, (V[]){v_k_2436, v_g_241})});
  }
  case TAG_MakeGiving: {
    V v_i_2439 = heff_field(v_p_242, 0);
    V v_v_2440 = heff_field(v_p_242, 1);
    V v_k_2441 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24MakeGiving = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_re_n(v_ru_24p_242_24MakeGiving, TAG_MakeGiving, 3, 3ULL, (V[]){v_i_2439, v_v_2440, heff_clo_n(g_std_2ereactor_2ereactor_lam11, 1, 2, (V[]){v_k_2441, v_g_241})});
  }
  case TAG_CloseGiving: {
    V v_gv_2444 = heff_field(v_p_242, 0);
    V v_x_2445 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24CloseGiving = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2446 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2445}));
    return heff_tag_re_n(v_ru_24p_242_24CloseGiving, TAG_CloseGiving, 2, 1ULL, (V[]){v_gv_2444, v_t_2446});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2ereactor_2ereactor_lam12(V self, V *args) {
  V v_m_2447 = args[0];
  V v_n_2448 = args[1];
  V v_nt_2449 = args[2];
  V v_p_2450 = args[3];
  heff_drop(v_m_2447);
  heff_drop(v_n_2448);
  heff_drop(v_nt_2449);
  return v_p_2450;
}