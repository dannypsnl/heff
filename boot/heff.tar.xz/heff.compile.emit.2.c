// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_FloatEq 13032
#define TAG_FloatLe 13237
#define TAG_FloatLt 13252
#define TAG_Hole 35555
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IntEq 36665
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntShow 56864
#define TAG_JFalse 28308
#define TAG_JIf 20915
#define TAG_JNot 63532
#define TAG_JRel 1532
#define TAG_JSeq 2498
#define TAG_JTrue 54122
#define TAG_Leaf 13717
#define TAG_MkArm 55352
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_OfFixed 17267
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Plus 9189
#define TAG_RuneEq 61407
#define TAG_RuneLe 61612
#define TAG_RuneLt 61627
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_StrEq 12955
#define TAG_StrLength 43075
#define TAG_StrLt 13175
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_cond 9554921
#define LBL_decls 296817955
#define LBL_env 310119
#define LBL_globals 352931696
#define LBL_gs 10067
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_names 305943394
#define LBL_op 10312
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_self 10021907
#define LBL_stmts 311127493
#define LBL_tail 10047767
#define LBL_used 10094724
#define LBL_val 326043
static uint32_t shape_code__decls[] = {LBL_code, LBL_decls};
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_js__env__pre[] = {LBL_js, LBL_env, LBL_pre};
static uint32_t shape_js__pre__env[] = {LBL_js, LBL_pre, LBL_env};
static uint32_t shape_key__params[] = {LBL_key, LBL_params};
static uint32_t shape_lines__env[] = {LBL_lines, LBL_env};
static uint32_t shape_val__op__cond__body__tail__stmts[] = {LBL_val, LBL_op, LBL_cond, LBL_body, LBL_tail, LBL_stmts};
V g_heff_2ecompile_2eemit_2eapplied(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eapplied_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eapplied_clo;
V g_heff_2ecompile_2eemit_2earmJs(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_clo;
V g_heff_2ecompile_2eemit_2earmJs_24tok3(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_24tok3_clo;
HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_clo;
V g_heff_2ecompile_2eemit_2eboolCode(V);
V g_heff_2ecompile_2eemit_2eboolCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eboolCode_clo;
V g_heff_2ecompile_2eemit_2ebundleAll(V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_clo;
V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo;
V g_heff_2ecompile_2eemit_2ebundleProvider(V, V);
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo;
V g_heff_2ecompile_2eemit_2ecallCode(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecallCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallCode_clo;
HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecellPrim(V, V);
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellPrim_clo;
HeffT2 g_heff_2ecompile_2eemit_2econdCode_24cpr(V);
V g_heff_2ecompile_2eemit_2econdGo(V, V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_clo;
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
V g_heff_2ecompile_2eemit_2edeclsOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_clo;
V g_heff_2ecompile_2eemit_2edeclsOf_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_24dps_clo;
V g_heff_2ecompile_2eemit_2efixedCode(V, V);
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efixedCode_clo;
V g_heff_2ecompile_2eemit_2efuelCtxStr_get(void);
V g_heff_2ecompile_2eemit_2efuelStr_get(void);
V g_heff_2ecompile_2eemit_2eifLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eifLines_clo;
V g_heff_2ecompile_2eemit_2eimportLinesOf(V);
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo;
V g_heff_2ecompile_2eemit_2ejk_get(void);
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2elooped(V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elooped_clo;
V g_heff_2ecompile_2eemit_2enamedAs(V, V, V);
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamedAs_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eopGo(V, V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
HeffT2 g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2eprimBin(V, V, V);
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimBin_clo;
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
V g_heff_2ecompile_2eemit_2eprimHelperU(V, V, V);
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimRel_24cpr(V);
HeffT2 g_heff_2ecompile_2eemit_2eprimUnary_24cpr(V);
V g_heff_2ecompile_2eemit_2eprovIndexGo(V, V, V);
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereserved_get(void);
V g_heff_2ecompile_2eemit_2ereturnLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_clo;
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo;
V g_heff_2ecompile_2eemit_2erunSource(V, V, V, V);
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunSource_clo;
V g_heff_2ecompile_2eemit_2erunStr_get(void);
V g_heff_2ecompile_2eemit_2erunStrBy(V);
V g_heff_2ecompile_2eemit_2erunStrBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunStrBy_clo;
V g_heff_2ecompile_2eemit_2esafe(V);
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafe_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2escrutBound(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2escrutBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutBound_clo;
V g_heff_2ecompile_2eemit_2escrutOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_clo;
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
V g_heff_2ecompile_2eemit_2eseqsOf_24dps(V, V);
V g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_24dps_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estepOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2estepOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estepOf_clo;
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V, V, V);
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo;
HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2esumOf(V, V);
V g_heff_2ecompile_2eemit_2esumOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esumOf_clo;
V g_heff_2ecompile_2eemit_2esumStr_get(void);
V g_heff_2ecompile_2eemit_2eswitchLines(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eswitchLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eswitchLines_clo;
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
HeffT2 g_heff_2ecompile_2eemit_2eunsnocGo_24dps_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo(V, V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_clo;
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s1931936847x1400497912(V);
V g_list_2eany_24s1931936847x1400497912_entry(V self, V *a);
extern Clo g_list_2eany_24s1931936847x1400497912_clo;
V g_list_2eany_24s331724893x1262243254(V);
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a);
extern Clo g_list_2eany_24s331724893x1262243254_clo;
V g_list_2eany_24s522272680x1725452739(V);
V g_list_2eany_24s522272680x1725452739_entry(V self, V *a);
extern Clo g_list_2eany_24s522272680x1725452739_clo;
V g_list_2eany_24s59996552x836780584(V, V, V, V);
V g_list_2eany_24s59996552x836780584_entry(V self, V *a);
extern Clo g_list_2eany_24s59996552x836780584_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1325317589x1506218481(V, V, V);
V g_list_2emap_24s1325317589x1506218481_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_clo;
V g_list_2emap_24s1366476796x894764441(V, V);
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_clo;
V g_list_2emap_24s319754340x1392149466(V, V, V, V);
V g_list_2emap_24s319754340x1392149466_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s2130584539x811126895(V, V, V);
V g_list_2ezipWith_24s2130584539x811126895_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2130584539x811126895_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);

HeffT2 g_heff_2ecompile_2eemit_2eunsnocGo_24dps_24cpr(V v_x1_240, V v_y_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_f_244, v_y_241}});
  }
  case TAG_Cons: {
    V v_z_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_241, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
    V t_0 = v_rest_246;
    V t_1 = v_z_245;
    V t_2 = v_u_248;
    v_x1_240 = t_0;
    v_y_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2equoteGo_str0, 2, "\\\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2equoteGo_str1, 2, "\\\\");
HEFF_LIT(g_heff_2ecompile_2eemit_2equoteGo_str2, 2, "\\n");
HEFF_LIT(g_heff_2ecompile_2eemit_2equoteGo_str3, 2, "\\r");
HEFF_LIT(g_heff_2ecompile_2eemit_2equoteGo_str4, 2, "\\t");
HEFF_LIT(g_heff_2ecompile_2eemit_2equoteGo_str5, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemit_2equoteGo_str6, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2ecompile_2eemit_2equoteGo_str7, 2, "\\x");
Clo g_heff_2ecompile_2eemit_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2equoteGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_s_243 = heff_dup(v_s_240);
    V v_i_244 = heff_dup(v_i_241);
    V v_t_249;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)) == ((int64_t)34ULL))) {
      heff_drop(v_s_243);
      heff_drop(v_i_244);
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2equoteGo_str0);
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)) == ((int64_t)92ULL))) {
        heff_drop(v_s_243);
        heff_drop(v_i_244);
        v_t_249 = ((V)&g_heff_2ecompile_2eemit_2equoteGo_str1);
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)) == ((int64_t)10ULL))) {
          heff_drop(v_s_243);
          heff_drop(v_i_244);
          v_t_249 = ((V)&g_heff_2ecompile_2eemit_2equoteGo_str2);
        } else {
          if ((heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)) == ((int64_t)13ULL))) {
            heff_drop(v_s_243);
            heff_drop(v_i_244);
            v_t_249 = ((V)&g_heff_2ecompile_2eemit_2equoteGo_str3);
          } else {
            if ((heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)) == ((int64_t)9ULL))) {
              heff_drop(v_s_243);
              heff_drop(v_i_244);
              v_t_249 = ((V)&g_heff_2ecompile_2eemit_2equoteGo_str4);
            } else {
              if ((((int64_t)128ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)))) {
                int64_t v_d_245 = heff_word_div(heff_unbox_word(heff_strByteAt_lent(v_s_243, v_i_244, 0)), ((int64_t)16ULL));
                int64_t v_d_246 = heff_word_mod(heff_unbox_word(heff_strByteAt(v_s_243, v_i_244)), ((int64_t)16ULL));
                V v_t_247 = heff_strSlice(((V)&g_heff_2ecompile_2eemit_2equoteGo_str5), heff_box_word(v_d_245), heff_box_word((v_d_245 + ((int64_t)1ULL))));
                V v_t_248 = heff_strSlice(((V)&g_heff_2ecompile_2eemit_2equoteGo_str6), heff_box_word(v_d_246), heff_box_word((v_d_246 + ((int64_t)1ULL))));
                v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2equoteGo_str7), v_t_247), v_t_248);
              } else {
                v_t_249 = heff_strSlice(v_s_243, heff_dup(v_i_244), heff_box_word((heff_unbox_word(v_i_244) + ((int64_t)1ULL))));
              }
            }
          }
        }
      }
    }
    V t_0 = v_s_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = heff_strAppend(v_acc_242, v_t_249);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2equoteGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastDotFrom_entry, 2, 0};

V g_heff_2ecompile_2eemit_2elastDotFrom(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < ((int64_t)0ULL))) {
    return NTAG(TAG_Nothing);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_box_word(v_i_241)});
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2elastDotFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str3, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str7, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str8, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str11, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str14, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str15, 3, "op_");
Clo g_heff_2ecompile_2eemit_2espellAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2espellAt_entry, 2, 0};

V g_heff_2ecompile_2eemit_2espellAt(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    if (heff_strEq_c_lent(v_k_240, ((V)&g_heff_2ecompile_2eemit_2espellAt_str0), 2)) {
      return v_k_240;
    } else {
      HeffT2 v_t_242 = (g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(v_k_240, MK_INT(0LL), NTAG(TAG_Nil)));
      {
        V v_field_244 = v_t_242.f[1];
        int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
        if ((v_tag_243 == ((int64_t)0ULL))) {
          heff_drop(v_k_240);
          V v_ws_245 = v_field_244;
          V v_t_248;
          switch (heff_tag_of(v_ws_245)) {
          case TAG_Nil: {
            v_t_248 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str1);
            break;
          }
          case TAG_Cons: {
            V v_x_246 = heff_field(v_ws_245, 0);
            V v_xs_247 = heff_field(v_ws_245, 1);
            heff_take_n(v_ws_245, 3ULL, 2);
            v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
            break;
          }
          default: heff_nomatch(v_ws_245);
          }
          V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str3), v_t_248);
          return v_t_249;
        } else {
          heff_drop(v_field_244);
          return v_k_240;
        }
      }
    }
  }
  case TAG_Just: {
    V v_i_2410 = heff_field(v_x2_241, 0);
    V v_x_2411 = heff_strSlice_lent(v_k_240, heff_intAdd_lent(v_i_2410, MK_INT(1LL), 2), heff_strLength_lent(v_k_240, 0), 6);
    if (heff_strEq_c_lent(v_x_2411, ((V)&g_heff_2ecompile_2eemit_2espellAt_str4), 2)) {
      heff_drop(v_x_2411);
      if (heff_strEq_c_lent(v_k_240, ((V)&g_heff_2ecompile_2eemit_2espellAt_str5), 2)) {
        return v_k_240;
      } else {
        HeffT2 v_t_2412 = (g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(v_k_240, MK_INT(0LL), NTAG(TAG_Nil)));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            heff_drop(v_k_240);
            V v_ws_2415 = v_field_2414;
            V v_t_2418;
            switch (heff_tag_of(v_ws_2415)) {
            case TAG_Nil: {
              v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str6);
              break;
            }
            case TAG_Cons: {
              V v_x_2416 = heff_field(v_ws_2415, 0);
              V v_xs_2417 = heff_field(v_ws_2415, 1);
              heff_take_n(v_ws_2415, 3ULL, 2);
              v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str7); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
              break;
            }
            default: heff_nomatch(v_ws_2415);
            }
            V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str8), v_t_2418);
            return v_t_2419;
          } else {
            heff_drop(v_field_2414);
            return v_k_240;
          }
        }
      }
    } else {
      HeffT2 v_t_2420 = ({ V a_0 = v_x_2411; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_ws_2423 = v_field_2422;
          V v_t_2426;
          switch (heff_tag_of(v_ws_2423)) {
          case TAG_Nil: {
            v_t_2426 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str9);
            break;
          }
          case TAG_Cons: {
            V v_x_2424 = heff_field(v_ws_2423, 0);
            V v_xs_2425 = heff_field(v_ws_2423, 1);
            heff_take_n(v_ws_2423, 3ULL, 2);
            v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str10); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
            break;
          }
          default: heff_nomatch(v_ws_2423);
          }
          V v_w_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str11), v_t_2426);
          V v_t_2428 = heff_strSlice(v_k_240, MK_INT(0LL), heff_intAdd_lent(v_i_2410, MK_INT(1LL), 2));
          return heff_strAppend(v_t_2428, v_w_2427);
        } else {
          heff_drop(v_field_2422);
          if (heff_strEq_c_lent(v_k_240, ((V)&g_heff_2ecompile_2eemit_2espellAt_str12), 2)) {
            return v_k_240;
          } else {
            HeffT2 v_t_2429 = (g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(v_k_240, MK_INT(0LL), NTAG(TAG_Nil)));
            {
              V v_field_2431 = v_t_2429.f[1];
              int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
              if ((v_tag_2430 == ((int64_t)0ULL))) {
                heff_drop(v_k_240);
                V v_ws_2432 = v_field_2431;
                V v_t_2435;
                switch (heff_tag_of(v_ws_2432)) {
                case TAG_Nil: {
                  v_t_2435 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str13);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2433 = heff_field(v_ws_2432, 0);
                  V v_xs_2434 = heff_field(v_ws_2432, 1);
                  heff_take_n(v_ws_2432, 3ULL, 2);
                  v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str14); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
                  break;
                }
                default: heff_nomatch(v_ws_2432);
                }
                V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str15), v_t_2435);
                return v_t_2436;
              } else {
                heff_drop(v_field_2431);
                return v_k_240;
              }
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2espellAt(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str0, 5, "break");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str1, 4, "case");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str2, 5, "catch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str3, 5, "class");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str4, 5, "const");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str5, 8, "continue");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str6, 8, "debugger");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str7, 7, "default");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str8, 6, "delete");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str9, 2, "do");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str10, 4, "else");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str11, 4, "enum");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str12, 6, "export");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str13, 7, "extends");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str14, 5, "false");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str15, 7, "finally");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str16, 3, "for");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str17, 8, "function");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str18, 2, "if");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str19, 6, "import");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str20, 2, "in");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str21, 10, "instanceof");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str22, 3, "new");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str23, 4, "null");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str24, 6, "return");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str25, 5, "super");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str26, 6, "switch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str27, 4, "this");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str28, 5, "throw");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str29, 4, "true");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str30, 3, "try");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str31, 6, "typeof");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str32, 3, "var");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str33, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str34, 5, "while");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str35, 4, "with");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str36, 5, "yield");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str37, 3, "let");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str38, 6, "static");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str39, 10, "implements");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str40, 9, "interface");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str41, 7, "package");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str42, 7, "private");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str43, 9, "protected");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str44, 6, "public");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str45, 5, "await");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str46, 9, "arguments");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str47, 4, "eval");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str48, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str49, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str50, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str51, 8, "document");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str52, 6, "window");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str53, 6, "BigInt");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str54, 6, "String");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str55, 6, "Number");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str56, 6, "Object");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str57, 5, "Error");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str58, 4, "Math");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str59, 4, "JSON");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str60, 10, "setTimeout");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str61, 5, "fetch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str62, 7, "process");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str63, 7, "console");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str64, 10, "globalThis");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str65, 7, "Promise");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str66, 5, "Array");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str67, 3, "Map");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str68, 3, "Set");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str69, 4, "Date");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str70, 6, "Symbol");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str71, 6, "RegExp");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str72, 6, "Buffer");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str73, 12, "setImmediate");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str74, 14, "queueMicrotask");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str75, 15, "structuredClone");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str76, 3, "URL");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str77, 11, "TextEncoder");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str78, 11, "TextDecoder");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str79, 10, "Uint8Array");
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit80, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str79), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit81, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str78), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit80));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit82, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str77), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit81));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit83, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str76), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit82));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit84, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str75), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit83));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit85, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str74), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit84));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit86, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str73), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit85));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit87, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str72), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit86));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit88, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str71), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit87));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit89, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str70), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit88));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit90, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str69), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit89));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit91, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str68), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit90));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit92, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str67), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit91));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit93, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str66), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit92));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit94, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str65), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit93));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit95, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str64), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit94));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit96, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str63), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit95));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit97, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str62), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit96));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit98, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str61), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit97));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit99, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str60), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit98));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit100, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str59), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit99));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit101, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str58), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit100));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit102, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str57), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit101));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit103, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str56), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit102));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit104, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str55), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit103));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit105, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str54), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit104));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit106, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str53), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit105));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit107, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str52), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit106));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit108, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str51), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit107));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit109, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str50), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit108));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit110, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str49), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit109));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit111, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str48), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit110));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit112, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str47), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit111));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit113, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str46), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit112));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit114, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str45), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit113));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit115, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str44), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit114));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit116, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str43), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit115));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit117, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str42), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit116));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit118, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str41), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit117));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit119, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str40), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit118));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit120, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str39), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit119));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit121, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str38), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit120));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit122, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str37), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit121));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit123, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str36), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit122));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit124, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str35), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit123));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit125, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str34), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit124));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit126, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str33), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit125));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit127, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str32), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit126));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit128, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str31), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit127));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit129, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str30), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit128));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit130, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str29), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit129));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit131, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str28), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit130));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit132, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str27), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit131));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit133, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str26), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit132));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit134, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str25), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit133));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit135, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str24), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit134));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit136, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str23), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit135));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit137, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str22), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit136));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit138, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str21), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit137));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit139, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str20), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit138));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit140, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str19), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit139));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit141, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str18), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit140));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit142, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str17), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit141));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit143, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str16), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit142));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit144, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str15), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit143));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit145, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str14), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit144));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit146, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str13), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit145));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit147, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str12), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit146));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit148, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str11), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit147));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit149, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str10), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit148));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit150, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str9), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit149));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit151, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str8), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit150));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit152, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str7), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit151));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit153, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str6), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit152));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit154, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str5), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit153));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit155, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str4), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit154));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit156, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str3), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit155));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit157, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str2), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit156));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit158, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str1), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit157));
HEFF_TAG_LIT(g_heff_2ecompile_2eemit_2ereserved_lit159, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemit_2ereserved_str0), ((V)&g_heff_2ecompile_2eemit_2ereserved_lit158));

static V g_heff_2ecompile_2eemit_2ereserved_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2ereserved_st;
static V g_heff_2ecompile_2eemit_2ereserved_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2ereserved_lit159);
}
V g_heff_2ecompile_2eemit_2ereserved_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2ereserved_st)) return g_heff_2ecompile_2eemit_2ereserved_val;
  return heff_global(&g_heff_2ecompile_2eemit_2ereserved_val, &g_heff_2ecompile_2eemit_2ereserved_st, g_heff_2ecompile_2eemit_2ereserved_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esafe_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esafe_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2esafe_str2, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eemit_2esafe_str3, 1, "_");
Clo g_heff_2ecompile_2eemit_2esafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esafe_entry, 1, 0};

V g_heff_2ecompile_2eemit_2esafe(V v_x0_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_x0_240, 0)) - ((int64_t)1ULL));
  V v_t_242 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_240, heff_box_word(v_t_241)));
  V v_t_243 = ({ V a_0 = v_x0_240; V a_1 = v_t_242; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_242); r_; });
  V v_s_244 = ({ V a_0 = v_t_243; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2esafe_str0); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_s_245;
  if (heff_strEq_c_lent(v_s_244, ((V)&g_heff_2ecompile_2eemit_2esafe_str1), 2)) {
    heff_drop(v_s_244);
    v_s_245 = ((V)&g_heff_2ecompile_2eemit_2esafe_str2);
  } else {
    v_s_245 = v_s_244;
  }
  V v_t_246 = ({ V a_0 = v_s_245; V b_1 = heff_dup(g_heff_2ecompile_2eemit_2ereserved_get()); V r_ = (g_list_2eany_24s1006624359x760861690(a_0, b_1)); heff_drop(b_1); r_; });
  if (((heff_dup(v_t_246) == NTAG(TAG_True)) || ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_245, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_s_245, MK_INT(0LL), 2)) <= ((int64_t)57ULL))))) {
    heff_drop(v_t_246);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esafe_str3), v_s_245);
  } else {
    heff_drop(v_t_246);
    return v_s_245;
  }
}
V g_heff_2ecompile_2eemit_2esafe_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esafe(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str0, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str13, 1, " ");
Clo g_heff_2ecompile_2eemit_2eprimBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimBin_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimBin(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_prec_243 = heff_take_field(v_b_242, 1);
  V v_code_244 = heff_get_n(v_b_242, 0, 2);
  V v_prec_245 = heff_take_field(v_a_241, 1);
  V v_code_246 = heff_take_field(v_a_241, 0);
  if ((heff_strEq_c_lent(v_op_240, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str0), 2) || heff_strEq_c_lent(v_op_240, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str1), 2))) {
    V v_t_247;
    if (heff_intLt_c(v_prec_245, MK_INT(2LL))) {
      v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str2), v_code_246), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str3));
    } else {
      v_t_247 = v_code_246;
    }
    V v_t_248;
    if (heff_intLt_c(v_prec_243, MK_INT(3LL))) {
      v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str4), v_code_244), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str5));
    } else {
      v_t_248 = v_code_244;
    }
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str6)), v_op_240);
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str7)), v_t_248);
    return ({ V rv_0 = v_t_2410; V rv_1 = MK_INT(2LL); V rr_ = heff_rec_reuse_nf(v_a_241, 0ULL, 2, shape_code__prec, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  } else {
    V v_t_2411;
    if (heff_intLt_c(v_prec_245, MK_INT(1LL))) {
      v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str8), v_code_246), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str9));
    } else {
      v_t_2411 = v_code_246;
    }
    V v_t_2412;
    if (heff_intLt_c(v_prec_243, MK_INT(2LL))) {
      v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str10), v_code_244), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str11));
    } else {
      v_t_2412 = v_code_244;
    }
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str12)), v_op_240);
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str13)), v_t_2412);
    return ({ V rv_0 = v_t_2414; V rv_1 = MK_INT(1LL); V rr_ = heff_rec_reuse_nf(v_a_241, 0ULL, 2, shape_code__prec, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
}
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimBin(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str2, 11, ".toString()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str5, 7, "BigInt(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str6, 8, ".length)");
V g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0, 1, 0};
V g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1, 1, 0};

HeffT2 g_heff_2ecompile_2eemit_2eprimUnary_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IntShow: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0_clo)}});
  }
  case TAG_StrLength: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1_clo)}});
  }
  default: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  }
}
V g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_prec_242 = heff_take_field(v_a_241, 1);
  V v_code_243 = heff_take_field(v_a_241, 0);
  V v_t_244;
  if (heff_intLt_c(v_prec_242, MK_INT(3LL))) {
    v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str0), v_code_243), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str1));
  } else {
    v_t_244 = v_code_243;
  }
  return ({ V rv_0 = heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str2)); V rv_1 = MK_INT(3LL); V rr_ = heff_rec_reuse_nf(v_a_241, 0ULL, 2, shape_code__prec, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1(V self, V *args) {
  V v_a_245 = args[0];
  V v_prec_246 = heff_take_field(v_a_245, 1);
  V v_code_247 = heff_take_field(v_a_245, 0);
  V v_t_248;
  if (heff_intLt_c(v_prec_246, MK_INT(3LL))) {
    v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str3), v_code_247), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str4));
  } else {
    v_t_248 = v_code_247;
  }
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str5), v_t_248), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str6));
  return ({ V rv_0 = v_t_249; V rv_1 = MK_INT(3LL); V rr_ = heff_rec_reuse_nf(v_a_245, 0ULL, 2, shape_code__prec, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
Clo g_heff_2ecompile_2eemit_2ecellPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecellPrim_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecellPrim(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Hole: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_SetField: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x22_245 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x221_246 = heff_field(v_x22_245, 0);
        V v_x222_247 = heff_field(v_x22_245, 1);
        switch (heff_tag_of(v_x221_246)) {
        case TAG_SVar: {
          return NTAG(TAG_False);
        }
        case TAG_SGlobal: {
          return NTAG(TAG_False);
        }
        case TAG_SInt: {
          switch (heff_tag_of(v_x222_247)) {
          case TAG_Nil: {
            return NTAG(TAG_False);
          }
          case TAG_Cons: {
            V v_x2222_2412 = heff_field(v_x222_247, 1);
            switch (heff_tag_of(v_x2222_2412)) {
            case TAG_Nil: {
              return NTAG(TAG_True);
            }
            case TAG_Cons: {
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_x2222_2412);
            }
          }
          default: return heff_nomatch(v_x222_247);
          }
        }
        case TAG_SFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SStr: {
          return NTAG(TAG_False);
        }
        case TAG_SBytes: {
          return NTAG(TAG_False);
        }
        case TAG_SFixed: {
          return NTAG(TAG_False);
        }
        case TAG_SFloat32: {
          return NTAG(TAG_False);
        }
        case TAG_SPrimFn: {
          return NTAG(TAG_False);
        }
        case TAG_SLam: {
          return NTAG(TAG_False);
        }
        case TAG_STag: {
          return NTAG(TAG_False);
        }
        case TAG_SRec: {
          return NTAG(TAG_False);
        }
        case TAG_SProj: {
          return NTAG(TAG_False);
        }
        case TAG_SPrim: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x221_246);
        }
      }
      default: return heff_nomatch(v_x22_245);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: {
    return NTAG(TAG_False);
  }
  }
}
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ecellPrim(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemit_2eseqsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eseqsOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eseqsOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_JTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_JFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_JRel: {
    return NTAG(TAG_Nil);
  }
  case TAG_JNot: {
    V v_q_242 = heff_field(v_p_240, 0);
    V t_0 = v_q_242;
    v_p_240 = t_0;
    goto top;
  }
  case TAG_JIf: {
    V v_c_243 = heff_field(v_p_240, 0);
    V v_t_244 = heff_field(v_p_240, 1);
    V v_e_245 = heff_field(v_p_240, 2);
    V v_t_246 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_243));
    V v_t_247 = (g_heff_2ecompile_2eemit_2eseqsOf(v_t_244));
    V v_t_248 = (g_heff_2ecompile_2eemit_2eseqsOf(v_e_245));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
    return (g_prelude_2e_2b_2b(v_t_246, v_t_249));
  }
  case TAG_JSeq: {
    V v_x_2410 = heff_field(v_p_240, 0);
    V v_q_2412 = heff_field(v_p_240, 2);
    V v_cell_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2410), heff_hole()});
    V v_u_2414 = (g_heff_2ecompile_2eemit_2eseqsOf_24dps(v_q_2412, v_cell_2413));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eseqsOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2eseqsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eseqsOf_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_JTrue: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JFalse: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JRel: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JNot: {
    V v_q_243 = heff_field(v_p_240, 0);
    V t_0 = v_q_243;
    V t_1 = v_d_241;
    v_p_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_JIf: {
    V v_c_244 = heff_field(v_p_240, 0);
    V v_t_245 = heff_field(v_p_240, 1);
    V v_e_246 = heff_field(v_p_240, 2);
    V v_t_247 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_244));
    V v_t_248 = (g_heff_2ecompile_2eemit_2eseqsOf(v_t_245));
    V v_t_249 = (g_heff_2ecompile_2eemit_2eseqsOf(v_e_246));
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_248, v_t_249));
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_247, v_t_2410));
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), v_t_2411);
  }
  case TAG_JSeq: {
    V v_x_2412 = heff_field(v_p_240, 0);
    V v_q_2414 = heff_field(v_p_240, 2);
    V v_cell_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), heff_hole()});
    V v_u_2416 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2415);
    V t_0 = v_q_2414;
    V t_1 = v_u_2416;
    v_p_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2eseqsOf_24dps(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str0, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str1, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str2, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str3, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str4, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str5, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str6, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str8, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str9, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str10, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str11, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str12, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimRel_24cpr_str13, 2, "<=");

HeffT2 g_heff_2ecompile_2eemit_2eprimRel_24cpr(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_IntEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str0)}});
  }
  case TAG_IntLt: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str1)}});
  }
  case TAG_IntLe: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str2)}});
  }
  case TAG_FloatEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str3)}});
  }
  case TAG_FloatLt: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str4)}});
  }
  case TAG_FloatLe: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str5)}});
  }
  case TAG_StrEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str6)}});
  }
  case TAG_StrLt: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str7)}});
  }
  case TAG_RuneEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str8)}});
  }
  case TAG_RuneLt: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str9)}});
  }
  case TAG_RuneLe: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str10)}});
  }
  case TAG_OfFixed: {
    V v_op_242 = heff_field(v_p_240, 1);
    switch (heff_tag_of(v_op_242)) {
    case TAG_OpAdd: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpSub: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpMul: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpDiv: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpRem: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpEq: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str11)}});
    }
    case TAG_OpLt: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str12)}});
    }
    case TAG_OpLe: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimRel_24cpr_str13)}});
    }
    case TAG_OpAnd: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpOr: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpXor: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpShl: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpShr: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpShow: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpFromInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpToInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpSqrt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpFromFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpToFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpFloor: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_op_242)}});
    }
  }
  default: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str0, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str1, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str4, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str7, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str10, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str13, 10, " \? $T : $F");
Clo g_heff_2ecompile_2eemit_2eboolCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eboolCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eboolCode(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_JTrue: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eboolCode_str0), MK_INT(3LL)});
  }
  case TAG_JFalse: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eboolCode_str1), MK_INT(3LL)});
  }
  case TAG_JRel: {
    HeffT2 v_t_242 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_240));
    {
      V v_field_243 = v_t_242.f[0];
      V v_field_244 = v_t_242.f[1];
      V v_t_245;
      if (heff_intLt_c(v_field_244, MK_INT(1LL))) {
        v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str2), v_field_243), ((V)&g_heff_2ecompile_2eemit_2eboolCode_str3));
      } else {
        v_t_245 = v_field_243;
      }
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str4)), MK_INT(0LL)});
    }
  }
  case TAG_JNot: {
    HeffT2 v_t_247 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_240));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_t_2410;
      if (heff_intLt_c(v_field_249, MK_INT(1LL))) {
        v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str5), v_field_248), ((V)&g_heff_2ecompile_2eemit_2eboolCode_str6));
      } else {
        v_t_2410 = v_field_248;
      }
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str7)), MK_INT(0LL)});
    }
  }
  case TAG_JIf: {
    HeffT2 v_t_2414 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_240));
    {
      V v_field_2415 = v_t_2414.f[0];
      V v_field_2416 = v_t_2414.f[1];
      V v_t_2417;
      if (heff_intLt_c(v_field_2416, MK_INT(1LL))) {
        v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str8), v_field_2415), ((V)&g_heff_2ecompile_2eemit_2eboolCode_str9));
      } else {
        v_t_2417 = v_field_2415;
      }
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str10)), MK_INT(0LL)});
    }
  }
  case TAG_JSeq: {
    HeffT2 v_t_2421 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_240));
    {
      V v_field_2422 = v_t_2421.f[0];
      V v_field_2423 = v_t_2421.f[1];
      V v_t_2424;
      if (heff_intLt_c(v_field_2423, MK_INT(1LL))) {
        v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str11), v_field_2422), ((V)&g_heff_2ecompile_2eemit_2eboolCode_str12));
      } else {
        v_t_2424 = v_field_2422;
      }
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str13)), MK_INT(0LL)});
    }
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ecompile_2eemit_2eboolCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eboolCode(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str1, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str2, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str3, 1, "-");
Clo g_heff_2ecompile_2eemit_2efixedCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2efixedCode_entry, 2, 0};

V g_heff_2ecompile_2eemit_2efixedCode(V v_w_240, V v_n_241) {
top: ;
  int64_t v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_242 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_242 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_242 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_242 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_242 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((v_t_242 == ((int64_t)64ULL))) {
    V v_s_243 = heff_intShow(v_n_241);
    if (heff_strEq_c(heff_strSlice_lent(v_s_243, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2efixedCode_str0))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_243, ((V)&g_heff_2ecompile_2eemit_2efixedCode_str1)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_243, ((V)&g_heff_2ecompile_2eemit_2efixedCode_str2)), MK_INT(3LL)});
    }
  } else {
    V v_s_244 = heff_intShow(v_n_241);
    if (heff_strEq_c(heff_strSlice_lent(v_s_244, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2efixedCode_str3))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_244, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_244, MK_INT(3LL)});
    }
  }
}
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2efixedCode(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str1, 7, "$force(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str3, 4, "$tr(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str5, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str6, 7, "$force(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eopGo_str8, 10, "$abandon()");
Clo g_heff_2ecompile_2eemit_2eopGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eopGo_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eopGo(V v_r_240, V v_env_241, V v_ind_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_OSimple: {
    V v_v_244 = heff_field(v_x4_243, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, heff_dup(v_v_244)});
  }
  case TAG_OCall: {
    V v_g_245 = heff_field(v_x4_243, 0);
    V v_args_246 = heff_field(v_x4_243, 1);
    V v_t_2436;
    switch (heff_tag_of(v_args_246)) {
    case TAG_Nil: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_247 = heff_field(v_args_246, 0);
      V v_x12_248 = heff_field(v_args_246, 1);
      switch (heff_tag_of(v_x11_247)) {
      case TAG_SVar: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2421 = heff_field(v_x11_247, 0);
        V v_x112_2422 = heff_field(v_x11_247, 1);
        switch (heff_tag_of(v_x112_2422)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_248)) {
          case TAG_Nil: {
            v_t_2436 = heff_bool(heff_strEq_c_lent(v_t_2421, ((V)&g_heff_2ecompile_2eemit_2eopGo_str0), 2));
            break;
          }
          case TAG_Cons: {
            v_t_2436 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_248);
          }
          break;
        }
        case TAG_Cons: {
          v_t_2436 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2422);
        }
        break;
      }
      case TAG_SRec: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_247);
      }
      break;
    }
    default: heff_nomatch(v_args_246);
    }
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop_rec(v_r_240, 6);
      heff_drop(v_ind_242);
      heff_drop(v_t_2436);
      HeffT2 v_t_2437 = ({ V b_0 = heff_get_n(v_env_241, 0, 5); V a_1 = v_g_245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2439 = v_t_2437.f[1];
        int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
        V v_t_2441;
        if ((v_tag_2438 == ((int64_t)0ULL))) {
          V v_i_2440 = v_field_2439;
          v_t_2441 = heff_get_n(v_i_2440, 0, 4);
        } else {
          heff_drop(v_field_2439);
          v_t_2441 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_g_245)));
        }
        V v_code_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_str1), v_t_2441), ((V)&g_heff_2ecompile_2eemit_2eopGo_str2));
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2442, MK_INT(3LL)});
      }
    } else {
      heff_drop(v_t_2436);
      HeffT2 v_t_2443 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_241, 0), v_g_245));
      {
        V v_field_2445 = v_t_2443.f[1];
        int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
        V v_code_2450;
        if ((v_tag_2444 == ((int64_t)0ULL))) {
          V v_i_2446 = v_field_2445;
          V v_c_2447 = (g_heff_2ecompile_2eemit_2ecallCode(v_r_240, v_env_241, v_ind_242, heff_dup(v_g_245), heff_dup(v_args_246)));
          V v_t_2448 = heff_get_n(v_i_2446, 3, 4);
          if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
            heff_drop(v_t_2448);
            v_code_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_str3), v_c_2447), ((V)&g_heff_2ecompile_2eemit_2eopGo_str4));
          } else {
            heff_drop(v_t_2448);
            v_code_2450 = v_c_2447;
          }
        } else {
          heff_drop(v_field_2445);
          V v_c_2449 = (g_heff_2ecompile_2eemit_2ecallCode(v_r_240, v_env_241, v_ind_242, heff_dup(v_g_245), heff_dup(v_args_246)));
          v_code_2450 = v_c_2449;
        }
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2450, MK_INT(3LL)});
      }
    }
  }
  case TAG_OApply: {
    V v_f_2451 = heff_field(v_x4_243, 0);
    V v_args_2452 = heff_field(v_x4_243, 1);
    V v_t_2482;
    switch (heff_tag_of(v_args_2452)) {
    case TAG_Nil: {
      v_t_2482 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_x11_2453 = heff_field(v_args_2452, 0);
      V v_x12_2454 = heff_field(v_args_2452, 1);
      switch (heff_tag_of(v_x11_2453)) {
      case TAG_SVar: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SGlobal: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        V v_t_2467 = heff_field(v_x11_2453, 0);
        V v_x112_2468 = heff_field(v_x11_2453, 1);
        switch (heff_tag_of(v_x112_2468)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x12_2454)) {
          case TAG_Nil: {
            v_t_2482 = heff_bool(heff_strEq_c_lent(v_t_2467, ((V)&g_heff_2ecompile_2eemit_2eopGo_str5), 2));
            break;
          }
          case TAG_Cons: {
            v_t_2482 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x12_2454);
          }
          break;
        }
        case TAG_Cons: {
          v_t_2482 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x112_2468);
        }
        break;
      }
      case TAG_SRec: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2482 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2453);
      }
      break;
    }
    default: heff_nomatch(v_args_2452);
    }
    if ((heff_dup(v_t_2482) == NTAG(TAG_True))) {
      heff_drop(v_t_2482);
      V v_t_2483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, heff_dup(v_f_2451)}));
      V v_t_2484 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eopGo_str6), heff_take_field(v_t_2483, 0));
      V v_code_2485 = heff_strAppend(v_t_2484, ((V)&g_heff_2ecompile_2eemit_2eopGo_str7));
      return ({ V rv_0 = v_code_2485; V rv_1 = MK_INT(3LL); V rr_ = heff_rec_reuse_nf(v_t_2483, 0ULL, 2, shape_code__prec, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    } else {
      heff_drop(v_t_2482);
      V v_t_2486 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_env_241), heff_dup(v_ind_242), heff_dup(v_f_2451)}));
      return (g_heff_2ecompile_2eemit_2eapplied(v_r_240, v_env_241, v_ind_242, v_t_2486, v_args_2452));
    }
  }
  case TAG_OPrim: {
    V v_p_2487 = heff_field(v_x4_243, 0);
    V v_args_2488 = heff_field(v_x4_243, 1);
    V v_t_2489 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 2, (V[]){v_env_241, v_ind_242}));
    V v_t_2490 = (g_list_2emap(v_t_2489, heff_dup(v_args_2488)));
    return (g_heff_2ecompile_2eemit_2eprimCall(v_p_2487, v_t_2490));
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_r_240, 6);
    heff_drop_rec(v_env_241, 5);
    heff_drop(v_ind_242);
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eopGo_str8), MK_INT(3LL)});
  }
  case TAG_OBool: {
    V v_c_2491 = heff_field(v_x4_243, 0);
    V v_t_2492 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 6), 3, (V[]){v_env_241, v_ind_242, heff_dup(v_c_2491)}));
    return (g_heff_2ecompile_2eemit_2eboolCode(v_t_2492));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemit_2eopGo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemit_2eopGo(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eemit_2estepOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estepOf_entry, 4, 0};

V g_heff_2ecompile_2eemit_2estepOf(V v_r_240, V v_env_241, V v_ind_242, V v_o_243) {
top: ;
  V v_op_244 = heff_take_field(v_r_240, 1);
  V v_cond_245 = heff_get_n(v_r_240, 2, 6);
  switch (heff_tag_of(v_o_243)) {
  case TAG_OSimple: {
    heff_drop(v_cond_245);
    V v_t_247 = heff_tr(heff_call(v_op_244, 3, (V[]){v_env_241, v_ind_242, v_o_243}));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  case TAG_OCall: {
    heff_drop(v_cond_245);
    V v_t_2410 = heff_tr(heff_call(v_op_244, 3, (V[]){v_env_241, v_ind_242, v_o_243}));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_OApply: {
    heff_drop(v_cond_245);
    V v_t_2413 = heff_tr(heff_call(v_op_244, 3, (V[]){v_env_241, v_ind_242, v_o_243}));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2413, NTAG(TAG_Nil)});
  }
  case TAG_OPrim: {
    heff_drop(v_cond_245);
    V v_t_2416 = heff_tr(heff_call(v_op_244, 3, (V[]){v_env_241, v_ind_242, v_o_243}));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2416, NTAG(TAG_Nil)});
  }
  case TAG_OAbandon: {
    heff_drop(v_cond_245);
    V v_t_2417 = heff_tr(heff_call(v_op_244, 3, (V[]){v_env_241, v_ind_242, v_o_243}));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2417, NTAG(TAG_Nil)});
  }
  case TAG_OBool: {
    V v_c_2418 = heff_field(v_o_243, 0);
    heff_take_n(v_o_243, 1ULL, 1);
    heff_drop(v_op_244);
    V v_jc_2419 = heff_tr(heff_call(v_cond_245, 3, (V[]){v_env_241, v_ind_242, v_c_2418}));
    V v_t_2420 = (g_heff_2ecompile_2eemit_2eboolCode(heff_dup(v_jc_2419)));
    V v_t_2421 = ({ V a_0 = v_jc_2419; V r_ = (g_heff_2ecompile_2eemit_2eseqsOf(a_0)); heff_drop(v_jc_2419); r_; });
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2420, v_t_2421});
  }
  default: return heff_nomatch(v_o_243);
  }
}
V g_heff_2ecompile_2eemit_2estepOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2estepOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_str3, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_str5, 1, ";");
Clo g_heff_2ecompile_2eemit_2escrutBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutBound_entry, 5, 0};

V g_heff_2ecompile_2eemit_2escrutBound(V v_r_240, V v_env_241, V v_ind_242, V v_v_243, V v_b_244) {
top: ;
  V v_js_245 = heff_take_field(v_b_244, 0);
  V v_env_246 = heff_get_n(v_b_244, 1, 2);
  V v_x2_247 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2escrutBound_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2escrutBound_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2escrutBound_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 6), 3, (V[]){v_env_241, v_ind_242, v_v_243}));
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2escrutBound_str3)), heff_dup(v_js_245));
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2escrutBound_str4)), heff_get_n(v_t_2411, 0, 2));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2escrutBound_str5)), NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__env__pre, (V[]){v_js_245, v_env_246, v_t_2414});
}
V g_heff_2ecompile_2eemit_2escrutBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2escrutBound(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str3, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str5, 3, ".a[");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str6, 2, "];");
Clo g_heff_2ecompile_2eemit_2edeclsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edeclsOf_entry, 4, 0};

V g_heff_2ecompile_2eemit_2edeclsOf(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_js_240);
    heff_drop(v_ind_241);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x2_246 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str0)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str3)), v_v_244);
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str4)), heff_dup(v_js_240));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str5)), heff_intShow(heff_dup(v_i_243)));
    V v_cell_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str6)), heff_hole()});
    V v_u_2414 = ({ V a_0 = v_js_240; V a_1 = v_ind_241; V a_2 = v_rest_245; V a_3 = heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL))); V a_4 = v_cell_2413; V r_ = (g_heff_2ecompile_2eemit_2edeclsOf_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_js_240); heff_drop(v_ind_241); r_; });
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2edeclsOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str3, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str5, 3, ".a[");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str6, 2, "];");
Clo g_heff_2ecompile_2eemit_2edeclsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry, 5, 0};

V g_heff_2ecompile_2eemit_2edeclsOf_24dps(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_243);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_v_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x2_247 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str0)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str3)), v_v_245);
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str4)), heff_dup(v_js_240));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str5)), heff_intShow(heff_dup(v_i_243)));
    V v_cell_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str6)), heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2414);
    V t_0 = v_js_240;
    V t_1 = v_ind_241;
    V t_2 = v_rest_246;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    V t_4 = v_u_2415;
    v_js_240 = t_0;
    v_ind_241 = t_1;
    v_x3_242 = t_2;
    v_i_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2eemit_2edeclsOf_24dps(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str3, 6, "break;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str7, 18, "default: $nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str8, 2, ");");
V g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eemit_2ecaseStmt_24cpr(V v_r_240, V v_ind_241, V v_arms_242, V v_sc_243) {
top: ;
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_lam0, 1, 3, (V[]){heff_dup(v_sc_243), heff_dup(v_ind_241), v_r_240}), heff_dup(v_arms_242)));
  V v_t_2419 = ({ V a_0 = v_arms_242; V r_ = (g_list_2eany_24s1931936847x1400497912(a_0)); heff_drop(v_arms_242); r_; });
  V v_t_2425;
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    v_t_2425 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_t_2419);
    V v_x2_2420 = (g_list_2ereplicate(heff_intAdd_lent(v_ind_241, MK_INT(1LL), 2), ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str4)));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str6); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str7)), heff_dup(heff_rfield(v_sc_243, 0)));
    v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str8)), NTAG(TAG_Nil)});
  }
  V v_t_2426 = (g_heff_2ecompile_2eemit_2eswitchLines(heff_dup(v_sc_243), v_ind_241, v_t_2418, v_t_2425, NTAG(TAG_Nil)));
  V v_f_2427 = heff_get_n(v_sc_243, 1, 3);
  return ((HeffT2){{v_t_2426, v_f_2427}});
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_lam1(V self, V *args) {
  V v_e_2410 = args[0];
  V v_i_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_ss_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 5, 6), 4, (V[]){v_e_2410, heff_dup(v_i_2411), v_ss_247, NTAG(TAG_Nothing)}));
  V v_x2_2413 = (g_list_2ereplicate(v_i_2411, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str0)));
  V v_t_2416;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nil: {
    v_t_2416 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_xs_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str2); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_str3)), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(heff_get_n(v_t_2412, 0, 2), v_t_2417));
}
V g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_lam0(V self, V *args) {
  V v_arm_244 = args[0];
  V v_sc_243 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  switch (heff_tag_of(v_arm_244)) {
  case TAG_MkArm: {
    V v_tag_245 = heff_field(v_arm_244, 0);
    V v_vs_246 = heff_field(v_arm_244, 1);
    V v_ss_247 = heff_field(v_arm_244, 2);
    V v_ru_24arm_244_24MkArm = heff_take_reuse_n(v_arm_244, 7ULL, 3);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_247)));
    V v_t_249 = (g_list_2efoldl_24s2003609603x1707519208(NTAG(TAG_Nil), v_t_248));
    heff_clo_take(self, 3);
    return ({ V a_0 = v_ru_24arm_244_24MkArm; V a_1 = v_sc_243; V a_2 = v_ind_241; V a_3 = v_tag_245; V a_4 = v_vs_246; V a_5 = v_t_249; V a_6 = heff_clo_n(g_heff_2ecompile_2eemit_2ecaseStmt_24cpr_lam1, 2, 2, (V[]){v_r_240, v_ss_247}); V r_ = (g_heff_2ecompile_2eemit_2earmJs_24tok3(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
  }
  default: return heff_nomatch(v_arm_244);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str3, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str5, 1, ";");
Clo g_heff_2ecompile_2eemit_2enamedAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamedAs_entry, 3, 0};

V g_heff_2ecompile_2eemit_2enamedAs(V v_ind_240, V v_c_241, V v_nb_242) {
top: ;
  V v_js_243 = heff_take_field(v_nb_242, 0);
  V v_env_244 = heff_get_n(v_nb_242, 1, 2);
  V v_x2_245 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2enamedAs_str0)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2enamedAs_str3)), heff_dup(v_js_243));
  V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2enamedAs_str4)), heff_get_n(v_c_241, 0, 2));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2enamedAs_str5)), NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__pre__env, (V[]){v_js_243, v_t_2411, v_env_244});
}
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamedAs(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str0, 1, "{");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str3, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str6, 18, "return $abandon();");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str7, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str10, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str14, 10, " continue;");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str15, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str18, 16, "return $nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejk_str19, 2, ");");
V g_heff_2ecompile_2eemit_2ejk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemit_2ejk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejk_lam0, 3, 0};
V g_heff_2ecompile_2eemit_2ejk_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemit_2ejk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejk_lam1, 3, 0};
V g_heff_2ecompile_2eemit_2ejk_lam2(V self, V *args); static Clo g_heff_2ecompile_2eemit_2ejk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejk_lam2, 3, 0};
V g_heff_2ecompile_2eemit_2ejk_lam3(V self, V *args); static Clo g_heff_2ecompile_2eemit_2ejk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejk_lam3, 3, 0};
V g_heff_2ecompile_2eemit_2ejk_lam5(V self, V *args);
V g_heff_2ecompile_2eemit_2ejk_lam6(V self, V *args);
V g_heff_2ecompile_2eemit_2ejk_lam7(V self, V *args);
V g_heff_2ecompile_2eemit_2ejk_lam9(V self, V *args);
V g_heff_2ecompile_2eemit_2ejk_lam8(V self, V *args);
V g_heff_2ecompile_2eemit_2ejk_lam4(V self, V *args); static Clo g_heff_2ecompile_2eemit_2ejk_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejk_lam4, 3, 0};
V g_heff_2ecompile_2eemit_2ejk_lam10(V self, V *args); static Clo g_heff_2ecompile_2eemit_2ejk_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejk_lam10, 4, 0};

static V g_heff_2ecompile_2eemit_2ejk_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2ejk_st;
static V g_heff_2ecompile_2eemit_2ejk_init(void) {
  return heff_rec_n(6, shape_val__op__cond__body__tail__stmts, (V[]){((V)&g_heff_2ecompile_2eemit_2ejk_lam0_clo), ((V)&g_heff_2ecompile_2eemit_2ejk_lam1_clo), ((V)&g_heff_2ecompile_2eemit_2ejk_lam2_clo), ((V)&g_heff_2ecompile_2eemit_2ejk_lam3_clo), ((V)&g_heff_2ecompile_2eemit_2ejk_lam4_clo), ((V)&g_heff_2ecompile_2eemit_2ejk_lam10_clo)});
}
V g_heff_2ecompile_2eemit_2ejk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2ejk_st)) return g_heff_2ecompile_2eemit_2ejk_val;
  return heff_global(&g_heff_2ecompile_2eemit_2ejk_val, &g_heff_2ecompile_2eemit_2ejk_st, g_heff_2ecompile_2eemit_2ejk_init);
}
V g_heff_2ecompile_2eemit_2ejk_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_ind_241 = args[1];
  V v_v_242 = args[2];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eemit_2ejk_get()); V a_1 = v_env_240; V a_2 = v_ind_241; V a_3 = v_v_242; V r_ = (g_heff_2ecompile_2eemit_2evalGo(a_0, a_1, a_2, a_3)); heff_drop(v_v_242); r_; });
}
V g_heff_2ecompile_2eemit_2ejk_lam1(V self, V *args) {
  V v_env_243 = args[0];
  V v_ind_244 = args[1];
  V v_o_245 = args[2];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eemit_2ejk_get()); V a_1 = v_env_243; V a_2 = v_ind_244; V a_3 = v_o_245; V r_ = (g_heff_2ecompile_2eemit_2eopGo(a_0, a_1, a_2, a_3)); heff_drop(v_o_245); r_; });
}
V g_heff_2ecompile_2eemit_2ejk_lam2(V self, V *args) {
  V v_env_246 = args[0];
  V v_ind_247 = args[1];
  V v_c_248 = args[2];
  return (g_heff_2ecompile_2eemit_2econdGo(heff_dup(g_heff_2ecompile_2eemit_2ejk_get()), v_env_246, v_ind_247, v_c_248));
}
V g_heff_2ecompile_2eemit_2ejk_lam3(V self, V *args) {
  V v_env_249 = args[0];
  V v_ind_2410 = args[1];
  V v_t_2411 = args[2];
  V v_r_2412 = heff_dup(g_heff_2ecompile_2eemit_2ejk_get());
  V v_env_2413 = v_env_249;
  V v_ind_2414 = v_ind_2410;
  V v_t_2415 = v_t_2411;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_TSeq: {
    return (g_heff_2ecompile_2eemit_2eblockOf(v_r_2412, v_env_2413, v_ind_2414, v_t_2415));
  }
  case TAG_TReturn: {
    V v_o_2418 = heff_dup(heff_field(v_t_2415, 0));
    V v_t_2431;
    switch (heff_tag_of(v_o_2418)) {
    case TAG_OSimple: {
      v_t_2431 = NTAG(TAG_True);
      break;
    }
    case TAG_OCall: {
      V v_g_2420 = heff_dup(heff_field(v_o_2418, 0));
      HeffT2 v_t_2422 = ({ V a_0 = heff_rfield(v_env_2413, 0); V a_1 = v_g_2420; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_2420); r_; });
      {
        V v_field_2424 = v_t_2422.f[1];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          V v_i_2425 = v_field_2424;
          v_t_2431 = heff_bool(!(heff_dup(heff_rfield(v_i_2425, 3)) == NTAG(TAG_True)));
          heff_drop_rec(v_i_2425, 4);
        } else {
          heff_drop(v_field_2424);
          v_t_2431 = NTAG(TAG_True);
        }
      }
      break;
    }
    case TAG_OApply: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    case TAG_OPrim: {
      v_t_2431 = NTAG(TAG_True);
      break;
    }
    case TAG_OAbandon: {
      v_t_2431 = NTAG(TAG_True);
      break;
    }
    case TAG_OBool: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_o_2418);
    }
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_tag(v_t_2415, 1);
      heff_drop(v_t_2431);
      V v_t_2432 = heff_tr(heff_call(heff_get_n(v_r_2412, 1, 6), 3, (V[]){v_env_2413, v_ind_2414, v_o_2418}));
      V v_c_2433 = heff_get_n(v_t_2432, 0, 2);
      if (heff_strEq_c(heff_strSlice_lent(v_c_2433, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2ejk_str0))) {
        return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ejk_str1), v_c_2433), ((V)&g_heff_2ecompile_2eemit_2ejk_str2));
      } else {
        return v_c_2433;
      }
    } else {
      heff_drop(v_o_2418);
      heff_drop(v_t_2431);
      return (g_heff_2ecompile_2eemit_2eblockOf(v_r_2412, v_env_2413, v_ind_2414, v_t_2415));
    }
  }
  case TAG_TLoop: {
    return (g_heff_2ecompile_2eemit_2eblockOf(v_r_2412, v_env_2413, v_ind_2414, v_t_2415));
  }
  case TAG_TIf: {
    return (g_heff_2ecompile_2eemit_2eblockOf(v_r_2412, v_env_2413, v_ind_2414, v_t_2415));
  }
  case TAG_TCase: {
    return (g_heff_2ecompile_2eemit_2eblockOf(v_r_2412, v_env_2413, v_ind_2414, v_t_2415));
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecompile_2eemit_2ejk_lam5(V self, V *args) {
  V v_p_2469 = args[0];
  V v_a_2470 = args[1];
  V v_r_2455 = heff_env(self)[0];
  V v_env_2456 = heff_env(self)[1];
  V v_ind_2457 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2471 = heff_tr(heff_call(heff_get_n(v_r_2455, 0, 6), 3, (V[]){v_env_2456, v_ind_2457, v_a_2470}));
  V v_t_2472 = heff_strAppend(heff_strAppend(v_p_2469, ((V)&g_heff_2ecompile_2eemit_2ejk_str10)), heff_get_n(v_t_2471, 0, 2));
  return heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2eemit_2ejk_str11));
}
V g_heff_2ecompile_2eemit_2ejk_lam6(V self, V *args) {
  V v_i_2482 = args[0];
  V v_r_2443 = heff_env(self)[0];
  V v_env_2444 = heff_env(self)[1];
  V v_t_2479 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_r_2443, 4, 6);
  heff_room[0] = v_env_2444;
  heff_room[1] = v_i_2482;
  heff_room[2] = v_t_2479;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ecompile_2eemit_2ejk_lam7(V self, V *args) {
  V v_i_2483 = args[0];
  V v_r_2443 = heff_env(self)[0];
  V v_env_2444 = heff_env(self)[1];
  V v_f_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_r_2443, 4, 6);
  heff_room[0] = v_env_2444;
  heff_room[1] = v_i_2483;
  heff_room[2] = v_f_2480;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ecompile_2eemit_2ejk_lam9(V self, V *args) {
  V v_e_2495 = args[0];
  V v_i_2496 = args[1];
  V v_r_2486 = heff_env(self)[0];
  V v_t_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_get_n(v_r_2486, 4, 6);
  heff_room[0] = v_e_2495;
  heff_room[1] = v_i_2496;
  heff_room[2] = v_t_2493;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ecompile_2eemit_2ejk_lam8(V self, V *args) {
  V v_arm_2490 = args[0];
  V v_sc_2489 = heff_env(self)[0];
  V v_ind_2487 = heff_env(self)[1];
  V v_r_2486 = heff_env(self)[2];
  switch (heff_tag_of(v_arm_2490)) {
  case TAG_MkArm: {
    V v_tag_2491 = heff_field(v_arm_2490, 0);
    V v_vs_2492 = heff_field(v_arm_2490, 1);
    V v_t_2493 = heff_field(v_arm_2490, 2);
    V v_ru_24arm_2490_24MkArm = heff_take_reuse_n(v_arm_2490, 7ULL, 3);
    V v_t_2494 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2493, NTAG(TAG_Nil)));
    heff_clo_take(self, 3);
    return ({ V a_0 = v_ru_24arm_2490_24MkArm; V a_1 = v_sc_2489; V a_2 = v_ind_2487; V a_3 = v_tag_2491; V a_4 = v_vs_2492; V a_5 = v_t_2494; V a_6 = heff_clo_n(g_heff_2ecompile_2eemit_2ejk_lam9, 2, 2, (V[]){v_r_2486, v_t_2493}); V r_ = (g_heff_2ecompile_2eemit_2earmJs_24tok3(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2494); r_; });
  }
  default: return heff_nomatch(v_arm_2490);
  }
}
V g_heff_2ecompile_2eemit_2ejk_lam4(V self, V *args) {
  V v_env_2440 = args[0];
  V v_ind_2441 = args[1];
  V v_t_2442 = args[2];
  V v_r_2443 = heff_dup(g_heff_2ecompile_2eemit_2ejk_get());
  V v_env_2444 = v_env_2440;
  V v_ind_2445 = v_ind_2441;
  V v_x4_2446 = v_t_2442;
  switch (heff_tag_of(v_x4_2446)) {
  case TAG_TSeq: {
    V v_ss_2447 = heff_field(v_x4_2446, 0);
    V v_t_2448 = heff_field(v_x4_2446, 1);
    V v_ru_24x4_2446_24TSeq = heff_take_reuse_n(v_x4_2446, 3ULL, 2);
    V v_p_2449 = heff_tr(heff_call(heff_take_field(v_r_2443, 5), 4, (V[]){v_env_2444, heff_dup(v_ind_2445), v_ss_2447, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_t_2448)})}));
    V v_env_2450 = heff_take_field(v_p_2449, 1);
    V v_lines_2451 = heff_get_n(v_p_2449, 0, 2);
    V v_t_2452 = heff_tr(heff_call(heff_get_n(v_r_2443, 4, 6), 3, (V[]){v_env_2450, v_ind_2445, v_t_2448}));
    return (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_2446_24TSeq, v_lines_2451, v_t_2452));
  }
  case TAG_TReturn: {
    V v_o_2453 = heff_field(v_x4_2446, 0);
    heff_take_n(v_x4_2446, 1ULL, 1);
    return (g_heff_2ecompile_2eemit_2ereturnLines(v_r_2443, v_env_2444, v_ind_2445, v_o_2453));
  }
  case TAG_TLoop: {
    V v_args_2454 = heff_field(v_x4_2446, 0);
    heff_take_n(v_x4_2446, 1ULL, 1);
    V v_r_2455 = v_r_2443;
    V v_env_2456 = v_env_2444;
    V v_ind_2457 = v_ind_2445;
    V v_args_2458 = v_args_2454;
    V v_t_2459 = heff_dup(heff_rfield(v_env_2456, 3));
    switch (heff_tag_of(v_t_2459)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_2455, 6);
      heff_drop_rec(v_env_2456, 5);
      heff_drop(v_args_2458);
      V v_x2_2460 = (g_list_2ereplicate(v_ind_2457, ((V)&g_heff_2ecompile_2eemit_2ejk_str3)));
      V v_t_2463;
      switch (heff_tag_of(v_x2_2460)) {
      case TAG_Nil: {
        v_t_2463 = ((V)&g_heff_2ecompile_2eemit_2ejk_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_2461 = heff_field(v_x2_2460, 0);
        V v_xs_2462 = heff_field(v_x2_2460, 1);
        heff_take_n(v_x2_2460, 3ULL, 2);
        v_t_2463 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ejk_str5); V a_1 = v_x_2461; V a_2 = v_xs_2462; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2462); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2460);
      }
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2463, ((V)&g_heff_2ecompile_2eemit_2ejk_str6)), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_s_2464 = heff_field(v_t_2459, 0);
      heff_take_n(v_t_2459, 1ULL, 1);
      V v_x2_2465 = (g_list_2ereplicate(heff_dup(v_ind_2457), ((V)&g_heff_2ecompile_2eemit_2ejk_str7)));
      V v_t_2468;
      switch (heff_tag_of(v_x2_2465)) {
      case TAG_Nil: {
        v_t_2468 = ((V)&g_heff_2ecompile_2eemit_2ejk_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2466 = heff_field(v_x2_2465, 0);
        V v_xs_2467 = heff_field(v_x2_2465, 1);
        heff_take_n(v_x2_2465, 3ULL, 2);
        v_t_2468 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ejk_str9); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2465);
      }
      V v_x2_2473 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2eemit_2ejk_lam5, 2, 3, (V[]){v_r_2455, v_env_2456, v_ind_2457}), heff_get_n(v_s_2464, 1, 2), v_args_2458));
      V v_t_2476;
      switch (heff_tag_of(v_x2_2473)) {
      case TAG_Nil: {
        v_t_2476 = ((V)&g_heff_2ecompile_2eemit_2ejk_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2474 = heff_field(v_x2_2473, 0);
        V v_xs_2475 = heff_field(v_x2_2473, 1);
        heff_take_n(v_x2_2473, 3ULL, 2);
        v_t_2476 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ejk_str13); V a_1 = v_x_2474; V a_2 = v_xs_2475; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2475); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2473);
      }
      V v_t_2477 = heff_strAppend(heff_strAppend(v_t_2468, v_t_2476), ((V)&g_heff_2ecompile_2eemit_2ejk_str14));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_2459);
    }
  }
  case TAG_TIf: {
    V v_c_2478 = heff_field(v_x4_2446, 0);
    V v_t_2479 = heff_field(v_x4_2446, 1);
    V v_f_2480 = heff_field(v_x4_2446, 2);
    heff_take_n(v_x4_2446, 7ULL, 3);
    V v_t_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_2443, 2)), 3, (V[]){heff_dup(v_env_2444), heff_dup(v_ind_2445), v_c_2478}));
    return (g_heff_2ecompile_2eemit_2eifLines(v_ind_2445, v_t_2481, heff_clo_n(g_heff_2ecompile_2eemit_2ejk_lam6, 1, 3, (V[]){heff_dup(v_r_2443), heff_dup(v_env_2444), v_t_2479}), heff_clo_n(g_heff_2ecompile_2eemit_2ejk_lam7, 1, 3, (V[]){v_r_2443, v_env_2444, v_f_2480})));
  }
  case TAG_TCase: {
    V v_v_2484 = heff_field(v_x4_2446, 0);
    V v_arms_2485 = heff_field(v_x4_2446, 1);
    V v_ru_24x4_2446_24TCase = heff_take_reuse_n(v_x4_2446, 3ULL, 2);
    V v_r_2486 = heff_dup(v_r_2443);
    V v_ind_2487 = heff_dup(v_ind_2445);
    V v_arms_2488 = v_arms_2485;
    V v_sc_2489 = (g_heff_2ecompile_2eemit_2escrutOf(v_r_2443, v_env_2444, v_ind_2445, v_v_2484));
    V v_t_2497 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ejk_lam8, 1, 3, (V[]){heff_dup(v_sc_2489), heff_dup(v_ind_2487), v_r_2486}), v_arms_2488));
    V v_x2_2498 = (g_list_2ereplicate(heff_dup(v_ind_2487), ((V)&g_heff_2ecompile_2eemit_2ejk_str15)));
    V v_t_24101;
    switch (heff_tag_of(v_x2_2498)) {
    case TAG_Nil: {
      v_t_24101 = ((V)&g_heff_2ecompile_2eemit_2ejk_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2499 = heff_field(v_x2_2498, 0);
      V v_xs_24100 = heff_field(v_x2_2498, 1);
      heff_take_n(v_x2_2498, 3ULL, 2);
      v_t_24101 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ejk_str17); V a_1 = v_x_2499; V a_2 = v_xs_24100; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24100); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2498);
    }
    V v_t_24102 = heff_strAppend(heff_strAppend(v_t_24101, ((V)&g_heff_2ecompile_2eemit_2ejk_str18)), heff_dup(heff_rfield(v_sc_2489, 0)));
    V v_t_24103 = heff_tag_at_n(v_ru_24x4_2446_24TCase, TAG_Cons, 2, (V[]){heff_strAppend(v_t_24102, ((V)&g_heff_2ecompile_2eemit_2ejk_str19)), NTAG(TAG_Nil)});
    return (g_heff_2ecompile_2eemit_2eswitchLines(v_sc_2489, v_ind_2487, v_t_2497, NTAG(TAG_Nil), v_t_24103));
  }
  default: return heff_nomatch(v_x4_2446);
  }
}
V g_heff_2ecompile_2eemit_2ejk_lam10(V self, V *args) {
  V v_env_24104 = args[0];
  V v_ind_24105 = args[1];
  V v_ss_24106 = args[2];
  V v_after_24107 = args[3];
  V v_r_24108 = heff_dup(g_heff_2ecompile_2eemit_2ejk_get());
  V v_env_24109 = v_env_24104;
  V v_ind_24110 = v_ind_24105;
  V v_x4_24111 = v_ss_24106;
  V v_after_24112 = v_after_24107;
  switch (heff_tag_of(v_x4_24111)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_24108, 6);
    heff_drop(v_ind_24110);
    heff_drop(v_after_24112);
    return heff_rec_n(2, shape_lines__env, (V[]){NTAG(TAG_Nil), v_env_24109});
  }
  case TAG_Cons: {
    V v_st_24113 = heff_field(v_x4_24111, 0);
    V v_rest_24114 = heff_field(v_x4_24111, 1);
    V v_ru_24x4_24111_24Cons = heff_take_reuse_n(v_x4_24111, 3ULL, 2);
    HeffT2 v_t_24115 = ({ V a_0 = heff_dup(v_r_24108); V a_1 = v_env_24109; V a_2 = heff_dup(v_ind_24110); V a_3 = v_st_24113; HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtGo_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_st_24113); r_; });
    {
      V v_field_24116 = v_t_24115.f[0];
      V v_field_24117 = v_t_24115.f[1];
      V v_b_24118 = heff_tr(heff_call(heff_get_n(v_r_24108, 5, 6), 4, (V[]){v_field_24117, v_ind_24110, v_rest_24114, v_after_24112}));
      V v_t_24119 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_24111_24Cons, v_field_24116, heff_take_field(v_b_24118, 0)));
      return ({ V rv_0 = v_t_24119; V rr_ = heff_rec_reuse_nf(v_b_24118, 2ULL, 2, shape_lines__env, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    }
  }
  default: return heff_nomatch(v_x4_24111);
  }
}
Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry, 3, 0};

V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V v_env_240, V v_ind_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_244, NTAG(TAG_Nil)});
  }
  case TAG_OCall: {
    V v_t_247 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  case TAG_OApply: {
    V v_t_2410 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_OPrim: {
    V v_t_2413 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2413, NTAG(TAG_Nil)});
  }
  case TAG_OAbandon: {
    V v_t_2414 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2414, NTAG(TAG_Nil)});
  }
  case TAG_OBool: {
    V v_c_2415 = heff_field(v_o_242, 0);
    V v_jc_2416 = ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = heff_dup(v_c_2415); V r_ = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(a_0, a_1, a_2)); heff_drop(v_env_240); r_; });
    V v_t_2417 = (g_heff_2ecompile_2eemit_2eboolCode(heff_dup(v_jc_2416)));
    V v_t_2418 = ({ V a_0 = v_jc_2416; V r_ = (g_heff_2ecompile_2eemit_2eseqsOf(a_0)); heff_drop(v_jc_2416); r_; });
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2417, v_t_2418});
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str0, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str1, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str2, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str5, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str6, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str7, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str8, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str9, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str10, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str13, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str14, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str15, 1, ";");
Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry, 3, 0};

V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V v_env_240, V v_ind_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_v_242, 0);
    heff_take_n(v_v_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_240, 1), v_x_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_ind_241);
        heff_drop(v_x_243);
        V v_js_247 = v_field_246;
        return heff_rec_n(3, shape_js__env__pre, (V[]){v_js_247, v_env_240, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_field_246);
        V v_lit_248 = v_x_243;
        V v_env_249 = heff_dup(v_env_240);
        V v_ind_2410 = v_ind_241;
        V v_t_2411 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str0), MK_INT(0LL)));
        V v_t_2412 = (g_heff_2ecompile_2eemit_2esafe(v_t_2411));
        HeffT2 v_t_2413 = ({ V a_0 = v_env_240; V a_1 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str1); V a_2 = v_t_2412; V a_3 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(a_0, a_1, a_2, a_3)); heff_drop_rec(v_env_240, 5); heff_drop(v_t_2412); r_; });
        {
          V v_field_2414 = v_t_2413.f[0];
          V v_field_2415 = v_t_2413.f[1];
          V v_x2_2416 = (g_list_2ereplicate(v_ind_2410, ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str2)));
          V v_t_2419;
          switch (heff_tag_of(v_x2_2416)) {
          case TAG_Nil: {
            v_t_2419 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str3);
            break;
          }
          case TAG_Cons: {
            V v_x_2417 = heff_field(v_x2_2416, 0);
            V v_xs_2418 = heff_field(v_x2_2416, 1);
            heff_take_n(v_x2_2416, 3ULL, 2);
            v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str4); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2416);
          }
          V v_lit_2420 = v_lit_248;
          V v_env_2421 = v_env_249;
          V v_inl_2422 = heff_take_field(v_env_2421, 4);
          V v_names_2423 = heff_get_n(v_env_2421, 1, 5);
          HeffT2 v_t_2424 = ({ V a_0 = v_inl_2422; V a_1 = v_lit_2420; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_inl_2422); r_; });
          {
            V v_field_2426 = v_t_2424.f[1];
            int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
            V v_t_2434;
            if ((v_tag_2425 == ((int64_t)0ULL))) {
              heff_drop(v_lit_2420);
              heff_drop(v_names_2423);
              V v_c_2427 = v_field_2426;
              v_t_2434 = v_c_2427;
            } else {
              heff_drop(v_field_2426);
              V v_d_2428 = (g_heff_2ecompile_2eemit_2esafe(heff_dup(v_lit_2420)));
              HeffT2 v_t_2429 = ({ V a_0 = v_names_2423; V a_1 = v_lit_2420; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_names_2423); heff_drop(v_lit_2420); r_; });
              {
                V v_field_2431 = v_t_2429.f[1];
                int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                V v_t_2433;
                if ((v_tag_2430 == ((int64_t)0ULL))) {
                  heff_drop(v_d_2428);
                  V v_x_2432 = v_field_2431;
                  v_t_2433 = v_x_2432;
                } else {
                  heff_drop(v_field_2431);
                  v_t_2433 = v_d_2428;
                }
                v_t_2434 = heff_rec_n(2, shape_code__prec, (V[]){v_t_2433, MK_INT(3LL)});
              }
            }
            V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str5)), heff_dup(v_field_2414));
            V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str6)), heff_get_n(v_t_2434, 0, 2));
            V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str7)), NTAG(TAG_Nil)});
            return heff_rec_n(3, shape_js__env__pre, (V[]){v_field_2414, v_field_2415, v_t_2437});
          }
        }
      }
    }
  }
  default: {
    V v_env_2438 = heff_dup(v_env_240);
    V v_ind_2439 = v_ind_241;
    V v_v_2440 = v_v_242;
    V v_t_2441 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str8), MK_INT(0LL)));
    V v_t_2442 = (g_heff_2ecompile_2eemit_2esafe(v_t_2441));
    HeffT2 v_t_2443 = ({ V a_0 = v_env_240; V a_1 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str9); V a_2 = v_t_2442; V a_3 = MK_INT(0LL); HeffT2 r_ = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(a_0, a_1, a_2, a_3)); heff_drop_rec(v_env_240, 5); heff_drop(v_t_2442); r_; });
    {
      V v_field_2444 = v_t_2443.f[0];
      V v_field_2445 = v_t_2443.f[1];
      V v_x2_2446 = (g_list_2ereplicate(heff_dup(v_ind_2439), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str10)));
      V v_t_2449;
      switch (heff_tag_of(v_x2_2446)) {
      case TAG_Nil: {
        v_t_2449 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2447 = heff_field(v_x2_2446, 0);
        V v_xs_2448 = heff_field(v_x2_2446, 1);
        heff_take_n(v_x2_2446, 3ULL, 2);
        v_t_2449 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str12); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2446);
      }
      V v_t_2450 = ({ V a_0 = v_env_2438; V a_1 = v_ind_2439; V a_2 = v_v_2440; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop(v_env_2438); heff_drop(v_ind_2439); heff_drop(v_v_2440); r_; });
      V v_t_2451 = heff_strAppend(heff_strAppend(v_t_2449, ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str13)), heff_dup(v_field_2444));
      V v_t_2452 = heff_strAppend(heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str14)), heff_get_n(v_t_2450, 0, 2));
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2452, ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str15)), NTAG(TAG_Nil)});
      return heff_rec_n(3, shape_js__env__pre, (V[]){v_field_2444, v_field_2445, v_t_2453});
    }
  }
  }
}
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str3, 18, "return $abandon();");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str4, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str7, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str8, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str10, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str11, 10, " continue;");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str12, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str15, 16, "return $nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str16, 2, ");");
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam2(V self, V *args);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam4(V self, V *args);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry, 3, 0};

V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x4_242, 0);
    V v_t_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TSeq = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_p_2414;
    switch (heff_tag_of(v_ss_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x4_242_24TSeq, 2);
      v_p_2414 = heff_rec_n(2, shape_lines__env, (V[]){NTAG(TAG_Nil), v_env_240});
      break;
    }
    case TAG_Cons: {
      V v_st_245 = heff_field(v_ss_243, 0);
      V v_rest_246 = heff_field(v_ss_243, 1);
      heff_take_n(v_ss_243, 3ULL, 2);
      HeffT2 v_t_247 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = v_st_245; HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtGo_24s1434728115x1254229577_24cpr(a_0, a_1, a_2)); heff_drop(v_st_245); r_; });
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        HeffT2 v_t_2410 = ({ V a_0 = v_field_249; V a_1 = v_ind_241; V a_2 = v_rest_246; V b_3 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_t_244)}); HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(a_0, a_1, a_2, b_3)); heff_drop(v_rest_246); heff_drop(b_3); r_; });
        {
          V v_field_2411 = v_t_2410.f[0];
          V v_field_2412 = v_t_2410.f[1];
          V v_t_2413 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_242_24TSeq, v_field_248, v_field_2411));
          v_p_2414 = heff_rec_n(2, shape_lines__env, (V[]){v_t_2413, v_field_2412});
        }
      }
      break;
    }
    default: heff_nomatch(v_ss_243);
    }
    V v_env_2415 = heff_take_field(v_p_2414, 1);
    V v_lines_2416 = heff_get_n(v_p_2414, 0, 2);
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eemit_2ejk_get(), 4)), 3, (V[]){v_env_2415, v_ind_241, v_t_244}));
    return (g_prelude_2e_2b_2b(v_lines_2416, v_t_2417));
  }
  case TAG_TReturn: {
    V v_o_2418 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_o_2418);
  }
  case TAG_TLoop: {
    V v_args_2419 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_env_2420 = v_env_240;
    V v_ind_2421 = v_ind_241;
    V v_args_2422 = v_args_2419;
    V v_t_2423 = heff_dup(heff_rfield(v_env_2420, 3));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nothing: {
      heff_drop_rec(v_env_2420, 5);
      heff_drop(v_args_2422);
      V v_x2_2424 = (g_list_2ereplicate(v_ind_2421, ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str0)));
      V v_t_2427;
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_Nil: {
        v_t_2427 = ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2425 = heff_field(v_x2_2424, 0);
        V v_xs_2426 = heff_field(v_x2_2424, 1);
        heff_take_n(v_x2_2424, 3ULL, 2);
        v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str2); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2424);
      }
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str3)), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_s_2428 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 1);
      V v_x2_2429 = (g_list_2ereplicate(heff_dup(v_ind_2421), ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str4)));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str6); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      V v_x2_2437 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0, 2, 2, (V[]){v_env_2420, v_ind_2421}), heff_get_n(v_s_2428, 1, 2), v_args_2422));
      V v_t_2440;
      switch (heff_tag_of(v_x2_2437)) {
      case TAG_Nil: {
        v_t_2440 = ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str9);
        break;
      }
      case TAG_Cons: {
        V v_x_2438 = heff_field(v_x2_2437, 0);
        V v_xs_2439 = heff_field(v_x2_2437, 1);
        heff_take_n(v_x2_2437, 3ULL, 2);
        v_t_2440 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str10); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2437);
      }
      V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2432, v_t_2440), ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str11));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_TIf: {
    V v_c_2442 = heff_field(v_x4_242, 0);
    V v_t_2443 = heff_field(v_x4_242, 1);
    V v_f_2444 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eemit_2ejk_get(), 2)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_ind_241), v_c_2442}));
    return (g_heff_2ecompile_2eemit_2eifLines(v_ind_241, v_t_2445, heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1, 1, 2, (V[]){heff_dup(v_env_240), v_t_2443}), heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam2, 1, 2, (V[]){v_env_240, v_f_2444})));
  }
  case TAG_TCase: {
    V v_v_2448 = heff_field(v_x4_242, 0);
    V v_arms_2449 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TCase = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_ind_2450 = heff_dup(v_ind_241);
    V v_arms_2451 = v_arms_2449;
    V v_sc_2452 = (g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(v_env_240, v_ind_241, v_v_2448));
    V v_t_2460 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam3, 1, 2, (V[]){heff_dup(v_sc_2452), heff_dup(v_ind_2450)}), v_arms_2451));
    V v_x2_2461 = (g_list_2ereplicate(heff_dup(v_ind_2450), ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str12)));
    V v_t_2464;
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_Nil: {
      v_t_2464 = ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_xs_2463 = heff_field(v_x2_2461, 1);
      heff_take_n(v_x2_2461, 3ULL, 2);
      v_t_2464 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str14); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2461);
    }
    V v_t_2465 = heff_strAppend(heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str15)), heff_dup(heff_rfield(v_sc_2452, 0)));
    V v_t_2466 = heff_tag_at_n(v_ru_24x4_242_24TCase, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2465, ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str16)), NTAG(TAG_Nil)});
    return (g_heff_2ecompile_2eemit_2eswitchLines(v_sc_2452, v_ind_2450, v_t_2460, NTAG(TAG_Nil), v_t_2466));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0(V self, V *args) {
  V v_p_2433 = args[0];
  V v_a_2434 = args[1];
  V v_env_2420 = heff_env(self)[0];
  V v_ind_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = ({ V a_0 = v_env_2420; V a_1 = v_ind_2421; V a_2 = v_a_2434; V r_ = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(a_0, a_1, a_2)); heff_drop_rec(v_env_2420, 5); heff_drop(v_ind_2421); heff_drop(v_a_2434); r_; });
  V v_t_2436 = heff_strAppend(heff_strAppend(v_p_2433, ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str7)), heff_get_n(v_t_2435, 0, 2));
  return heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_str8));
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1(V self, V *args) {
  V v_i_2446 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_t_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(g_heff_2ecompile_2eemit_2ejk_get(), 4));
  heff_room[0] = v_env_240;
  heff_room[1] = v_i_2446;
  heff_room[2] = v_t_2443;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam2(V self, V *args) {
  V v_i_2447 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_f_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(g_heff_2ecompile_2eemit_2ejk_get(), 4));
  heff_room[0] = v_env_240;
  heff_room[1] = v_i_2447;
  heff_room[2] = v_f_2444;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam4(V self, V *args) {
  V v_e_2458 = args[0];
  V v_i_2459 = args[1];
  V v_t_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_e_2458, v_i_2459, v_t_2456));
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam3(V self, V *args) {
  V v_arm_2453 = args[0];
  V v_sc_2452 = heff_env(self)[0];
  V v_ind_2450 = heff_env(self)[1];
  switch (heff_tag_of(v_arm_2453)) {
  case TAG_MkArm: {
    V v_tag_2454 = heff_field(v_arm_2453, 0);
    V v_vs_2455 = heff_field(v_arm_2453, 1);
    V v_t_2456 = heff_field(v_arm_2453, 2);
    V v_ru_24arm_2453_24MkArm = heff_take_reuse_n(v_arm_2453, 7ULL, 3);
    V v_t_2457 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2456, NTAG(TAG_Nil)));
    heff_clo_take(self, 2);
    return ({ V a_0 = v_ru_24arm_2453_24MkArm; V a_1 = v_sc_2452; V a_2 = v_ind_2450; V a_3 = v_tag_2454; V a_4 = v_vs_2455; V a_5 = v_t_2457; V a_6 = heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam4, 2, 1, (V[]){v_t_2456}); V r_ = (g_heff_2ecompile_2eemit_2earmJs_24tok3(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2457); r_; });
  }
  default: return heff_nomatch(v_arm_2453);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str3, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str4, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str5, 6, ") => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str6, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str7, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str10, 10, "    const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str12, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str13, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str14, 3, "  }");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str15, 12, "  for (;;) {");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str16, 0, "");
Clo g_heff_2ecompile_2eemit_2elooped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elooped_entry, 4, 0};

V g_heff_2ecompile_2eemit_2elooped(V v_key_240, V v_i_241, V v_t_242, V v_r_243) {
top: ;
  V v_js_244 = heff_take_field(v_r_243, 0);
  V v_env_245 = heff_get_n(v_r_243, 1, 2);
  V v_x2_246 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str0), heff_dup(v_js_244)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemit_2elooped_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elooped_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str3), heff_get_n(v_i_241, 0, 4));
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2elooped_str4)), v_t_249);
  V v_t_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2elooped_str5));
  V v_t_2413 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str6), heff_dup(v_js_244)));
  V v_x2_2414 = (g_list_2ezipWith_24s2130584539x811126895(((V)&g_heff_2ecompile_2eemit_2elooped_str7), heff_dup(v_js_244), v_t_2413));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_t_2417 = ((V)&g_heff_2ecompile_2eemit_2elooped_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elooped_str9); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str10), v_t_2417), ((V)&g_heff_2ecompile_2eemit_2elooped_str11));
  V v_t_2419 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str12), v_js_244));
  V v_s_2420 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__params, (V[]){v_key_240, v_t_2419})});
  V v_env_2421 = v_env_245;
  V v_t_2422 = ({ V rv_3 = v_s_2420; V rr_ = heff_rec_reuse_nf(v_env_2421, 23ULL, 5, shape_gs__names__used__self__inl, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2423 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_t_2422, MK_INT(2LL), v_t_242));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str13), NTAG(TAG_Nil)});
  V v_ys_2425 = (g_prelude_2e_2b_2b(v_t_2423, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str14), v_t_2424})));
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str15), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_ys_2425})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2426})});
}
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2elooped(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str4, 7, "const $");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str5, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str6, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str7, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str8, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str9, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str12, 7, "const $");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str13, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str14, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str15, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str16, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str17, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str19, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str23, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str24, 7, "const $");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str25, 5, "$c = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str26, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str28, 2, ");");
Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimHelperU_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimHelperU(V v_uses_240, V v_p_241, V v_u_242) {
top: ;
  V v_params_243 = heff_take_field(v_u_242, 0);
  V v_body_244 = heff_get_n(v_u_242, 1, 2);
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str0), heff_dup(v_p_241)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str1));
  HeffT2 v_t_246 = ({ V a_0 = v_uses_240; V a_1 = v_t_245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_t_2429;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      heff_drop(v_x_249);
      V v_t_2410 = heff_dup(v_params_243);
      V v_t_2413;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_t_2410, 0);
        V v_xs_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str3); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str4), heff_dup(v_p_241)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str5));
      V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, v_t_2413), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str6));
      V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, v_body_244), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str7));
      v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_field_248);
      V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str8), heff_dup(v_p_241)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str9));
      HeffT2 v_t_2418 = ({ V a_0 = v_uses_240; V a_1 = v_t_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_x_2421 = v_field_2420;
          heff_drop(v_x_2421);
          V v_t_2422 = heff_dup(v_params_243);
          V v_t_2425;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_Nil: {
            v_t_2425 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str10);
            break;
          }
          case TAG_Cons: {
            V v_x_2423 = heff_field(v_t_2422, 0);
            V v_xs_2424 = heff_field(v_t_2422, 1);
            heff_take_n(v_t_2422, 3ULL, 2);
            v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str11); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str12), heff_dup(v_p_241)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str13));
          V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, v_t_2425), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str14));
          V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, v_body_244), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str15));
          v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_body_244);
          heff_drop(v_field_2420);
          v_t_2429 = NTAG(TAG_Nil);
        }
      }
    }
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str16), heff_dup(v_p_241)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str17));
    HeffT2 v_t_2431 = ({ V a_0 = v_uses_240; V a_1 = v_t_2430; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2430); r_; });
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      V v_t_2447;
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_x_2434 = v_field_2433;
        heff_drop(v_x_2434);
        V v_x2_2435 = (g_list_2emap_24s1325317589x1506218481(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str18), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str19), heff_dup(v_params_243)));
        V v_t_2438;
        switch (heff_tag_of(v_x2_2435)) {
        case TAG_Nil: {
          v_t_2438 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str20);
          break;
        }
        case TAG_Cons: {
          V v_x_2436 = heff_field(v_x2_2435, 0);
          V v_xs_2437 = heff_field(v_x2_2435, 1);
          heff_take_n(v_x2_2435, 3ULL, 2);
          v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str21); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2435);
        }
        V v_t_2439 = v_params_243;
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_Nil: {
          v_t_2442 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str22);
          break;
        }
        case TAG_Cons: {
          V v_x_2440 = heff_field(v_t_2439, 0);
          V v_xs_2441 = heff_field(v_t_2439, 1);
          heff_take_n(v_t_2439, 3ULL, 2);
          v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str23); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str24), heff_dup(v_p_241)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str25));
        V v_t_2444 = heff_strAppend(heff_strAppend(v_t_2443, v_t_2438), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str26));
        V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2444, v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str27));
        V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, v_t_2442), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str28));
        v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_p_241);
        heff_drop(v_params_243);
        heff_drop(v_field_2433);
        v_t_2447 = NTAG(TAG_Nil);
      }
      return (g_prelude_2e_2b_2b(v_t_2429, v_t_2447));
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprimHelperU(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2ebundleAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleAll_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebundleAll(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2ebundleProvider(heff_dup(v_i_240), v_p_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2eemit_2ebundleAll_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_rest_243, v_cell_245));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleAll(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esumOf_str0, 2, "L[");
HEFF_LIT(g_heff_2ecompile_2eemit_2esumOf_str1, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemit_2esumOf_str2, 5, "$sum(");
HEFF_LIT(g_heff_2ecompile_2eemit_2esumOf_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2esumOf_str4, 1, ")");
Clo g_heff_2ecompile_2eemit_2esumOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esumOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2esumOf(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esumOf_str0), heff_intShow(v_i_241));
    return heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemit_2esumOf_str1));
  }
  case TAG_Plus: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_heff_2ecompile_2eemit_2esumOf(v_a_244, heff_dup(v_i_241)));
    V v_xs_247 = (g_heff_2eelab_2eeffect_2eleaves(v_a_244));
    V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    V v_t_249 = (g_heff_2ecompile_2eemit_2esumOf(v_b_245, heff_intAdd(v_i_241, v_t_248)));
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esumOf_str2), v_t_246), ((V)&g_heff_2ecompile_2eemit_2esumOf_str3));
    return heff_strAppend(heff_strAppend(v_t_2410, v_t_249), ((V)&g_heff_2ecompile_2eemit_2esumOf_str4));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2esumOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2esumOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str0, 5, "$fuel");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str2, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str4, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str5, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str6, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str7, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str8, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str9, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str11, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str12, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str13, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str14, 2, "$p");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str15, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str16, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str18, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str20, 11, "$run(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str21, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str22, 1, "[");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str23, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str24, 9, ", (L) => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str25, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str27, 5, "})();");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str29, 8, "(() => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str30, 13, "\"use strict\";");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str31, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str32, 42, "// Generated from Hippogriff; do not edit.");
V g_heff_2ecompile_2eemit_2erunSource_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2erunSource_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2erunSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2erunSource_entry, 4, 0};

V g_heff_2ecompile_2eemit_2erunSource(V v_provs_240, V v_eff_241, V v_key_242, V v_m_243) {
top: ;
  V v_lines_244 = heff_take_field(v_m_243, 0);
  V v_globals_245 = heff_get_n(v_m_243, 1, 2);
  V v_xs_246 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_provs_240));
  V v_t_247 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_246));
  V v_hasTr_248 = (g_list_2eany_24s331724893x1262243254(v_lines_244));
  V v_have_249 = heff_dup(v_lines_244);
  V v_provs_2410 = heff_dup(v_provs_240);
  V v_eff_2411 = heff_dup(v_eff_241);
  V v_t_2412;
  if ((heff_dup(v_hasTr_248) == NTAG(TAG_True))) {
    heff_drop(v_hasTr_248);
    v_t_2412 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_hasTr_248);
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
  }
  V v_had_2413 = (g_list_2eany_24s522272680x1725452739(v_have_249));
  V v_x2_2414 = (g_list_2eany_24s59996552x836780584(MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2erunSource_str0), MK_INT(0LL), v_provs_2410));
  V v_t_2418;
  if ((heff_dup(v_x2_2414) == NTAG(TAG_True))) {
    heff_drop(v_x2_2414);
    V v_t_2415;
    if ((heff_dup(v_had_2413) == NTAG(TAG_True))) {
      heff_drop(v_had_2413);
      v_t_2415 = NTAG(TAG_Nil);
    } else {
      heff_drop(v_had_2413);
      v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2efuelStr_get()), NTAG(TAG_Nil)});
    }
    V v_t_2416 = (g_heff_2ecompile_2eemit_2erunStrBy(NTAG(TAG_True)));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    v_t_2418 = (g_prelude_2e_2b_2b(v_t_2415, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2efuelCtxStr_get()), v_t_2417})));
  } else {
    heff_drop(v_had_2413);
    heff_drop(v_x2_2414);
    v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2erunStr_get()), NTAG(TAG_Nil)});
  }
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2418));
  V v_t_2423;
  switch (heff_tag_of(v_eff_2411)) {
  case TAG_Leaf: {
    heff_take_n(v_eff_2411, 0ULL, 1);
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Plus: {
    V v_ru_24eff_2411_24Plus = heff_take_reuse_n(v_eff_2411, 0ULL, 2);
    v_t_2423 = heff_tag_at_n(v_ru_24eff_2411_24Plus, TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2esumStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_eff_2411);
  }
  V v_have_2424 = v_have_249;
  V v_provs_2425 = heff_dup(v_provs_2410);
  V v_x2_2426 = (g_list_2emap_24s720989758x1967438448(v_provs_2425));
  V v_text_2429;
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Nil: {
    v_text_2429 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    V v_xs_2428 = heff_field(v_x2_2426, 1);
    heff_take_n(v_x2_2426, 3ULL, 2);
    v_text_2429 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str2); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2426);
  }
  V v_t_2430 = ({ V a_0 = MK_INT(0LL); V a_1 = v_text_2429; V a_2 = MK_INT(0LL); V a_3 = heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get()); V r_ = (g_list_2emap_24s319754340x1392149466(a_0, a_1, a_2, a_3)); heff_drop(v_text_2429); r_; });
  V v_t_2431 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2430));
  V v_t_2434 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemit_2erunSource_lam0, 1, 1, (V[]){v_have_2424}); V a_1 = v_t_2431; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2435 = (g_heff_2ecompile_2eemit_2ebundleAll(MK_INT(0LL), v_provs_2410));
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2434, v_t_2435));
  V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2436));
  V v_x2_2438 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2437));
  V v_t_2441;
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_Nil: {
    v_t_2441 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_xs_2440 = heff_field(v_x2_2438, 1);
    heff_take_n(v_x2_2438, 3ULL, 2);
    v_t_2441 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str4); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2438);
  }
  HeffT2 v_t_2442 = ({ V a_0 = v_globals_245; V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_globals_245); heff_drop(b_1); r_; });
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    V v_t_2450;
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_i_2445 = v_field_2444;
      V v_arity_2446 = heff_take_field(v_i_2445, 1);
      V v_js_2447 = heff_take_field(v_i_2445, 0);
      V v_lazy_2448 = heff_get_n(v_i_2445, 2, 4);
      if (heff_intLe_c(MK_INT(2LL), v_arity_2446)) {
        heff_drop(v_lazy_2448);
        v_t_2450 = heff_strAppend(v_js_2447, ((V)&g_heff_2ecompile_2eemit_2erunSource_str5));
      } else {
        V v_t_2449 = v_lazy_2448;
        if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
          heff_drop(v_t_2449);
          v_t_2450 = heff_strAppend(v_js_2447, ((V)&g_heff_2ecompile_2eemit_2erunSource_str6));
        } else {
          heff_drop(v_t_2449);
          v_t_2450 = v_js_2447;
        }
      }
    } else {
      heff_drop(v_field_2444);
      v_t_2450 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str7);
    }
    V v_provs_2451 = v_provs_240;
    V v_eff_2452 = heff_dup(v_eff_241);
    V v_t_2453 = ({ V a_0 = v_eff_2452; V r_ = (g_heff_2eelab_2eeffect_2eleaves(a_0)); heff_drop(v_eff_2452); r_; });
    V v_x2_2465 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2erunSource_lam1, 1, 1, (V[]){v_provs_2451}), v_t_2453));
    V v_t_2468;
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      v_t_2468 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str18); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2465);
    }
    V v_t_2469 = ({ V a_0 = v_eff_241; V a_1 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemit_2esumOf(a_0, a_1)); heff_drop(v_eff_241); r_; });
    V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str19), NTAG(TAG_Nil)});
    V v_t_2471 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str20), v_t_2450), ((V)&g_heff_2ecompile_2eemit_2erunSource_str21));
    V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str22), v_t_2468), ((V)&g_heff_2ecompile_2eemit_2erunSource_str23));
    V v_t_2473 = heff_strAppend(heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2eemit_2erunSource_str24)), v_t_2469);
    V v_t_2474 = heff_strAppend(heff_strAppend(v_t_2471, v_t_2473), ((V)&g_heff_2ecompile_2eemit_2erunSource_str25));
    V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
    V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str26), v_t_2475})});
    V v_t_2477 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str27), v_t_2470}), v_lines_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str28), v_t_2476})));
    V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str30), v_t_2477})});
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str31); V a_1 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str32); V a_2 = v_t_247; V a_3 = v_t_2478; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); heff_drop_tag(v_t_2478, 2); r_; });
  }
}
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2erunSource(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2erunSource_lam0(V self, V *args) {
  V v_l_2432 = args[0];
  V v_have_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2433 = ({ V a_0 = v_l_2432; V a_1 = v_have_2424; V r_ = (g_list_2eany_24s1477604419x1568736711(a_0, a_1)); heff_drop(v_l_2432); heff_drop(v_have_2424); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2433) == NTAG(TAG_True)));
  heff_drop(v_x1_2433);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eemit_2erunSource_lam1(V self, V *args) {
  V v_k_2454 = args[0];
  V v_provs_2451 = heff_env(self)[0];
  V v_t_2455 = (g_prelude_2esplit_2esplitFrom_240(v_k_2454, ((V)&g_heff_2ecompile_2eemit_2erunSource_str8), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2erunSource_str9), v_k_2454, MK_INT(0LL), 5), NTAG(TAG_Nil)));
  V v_x2_2456 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2455));
  V v_t_2459;
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_Nil: {
    v_t_2459 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str10);
    break;
  }
  case TAG_Cons: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_xs_2458 = heff_field(v_x2_2456, 1);
    heff_take_n(v_x2_2456, 3ULL, 2);
    v_t_2459 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str11); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2456);
  }
  heff_clo_take(self, 1);
  V v_t_2460 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2459; V a_2 = v_provs_2451; V r_ = (g_heff_2ecompile_2eemit_2eprovIndexGo(a_0, a_1, a_2)); heff_drop(v_t_2459); heff_drop(v_provs_2451); r_; });
  V v_t_2461 = (g_prelude_2esplit_2esplitFrom_240(v_k_2454, ((V)&g_heff_2ecompile_2eemit_2erunSource_str12), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemit_2erunSource_str13), v_k_2454, MK_INT(0LL), 5), NTAG(TAG_Nil)));
  V v_t_2462 = ({ V a_0 = v_k_2454; V a_1 = v_t_2461; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2454); heff_drop(v_t_2461); r_; });
  V v_t_2463 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str14), heff_intShow(v_t_2460));
  V v_t_2464 = heff_strAppend(heff_strAppend(v_t_2463, ((V)&g_heff_2ecompile_2eemit_2erunSource_str15)), v_t_2462);
  return heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eemit_2erunSource_str16));
}