// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_ReadDirectory 46629
#define TAG_Right 62770
#define TAG_WriteErr 37283
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0(V v_dir_240, V v_parts_241, V v_p_242, V v_done_243, V v_p_244, V v_x_245) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Right: {
    V v_y_247 = heff_field(v_x_245, 0);
    v_t_248 = heff_dup(v_y_247);
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  return (g_heff_2ebuild_2ecommands_2eremoveStale_24s1116426391x1971026376(heff_dup(v_dir_240), v_parts_241, v_t_248, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam0, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_241), v_p_242, v_done_243, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_p_242, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_done_243 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    heff_clo_take(self, 4);
    heff_drop(v_dir_240);
    V f_ = v_done_243;
    heff_room[0] = v_p_242;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2410);
    heff_clo_take(self, 4);
    heff_drop(v_done_243);
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_str1));
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam2, 1, 2, (V[]){v_p_242, v_p_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_done_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_drop(v_x_249);
  heff_clo_take(self, 5);
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_241; V a_2 = heff_dup(v_p_242); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0_lam1, 1, 4, (V[]){v_done_243, v_p_242, v_p_244, v_dir_240}); V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s373165813x1728350596(a_0, a_1, a_2, a_3)); heff_drop(v_parts_241); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1(V v_dir_240, V v_p_241, V v_parts_242, V v_done_243, V v_p_244, V v_x_245) {
top: ;
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_240)));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_249 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam0_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam1, 1, 6, (V[]){v_dir_240, heff_dup(v_parts_242), v_p_241, v_done_243, v_p_244, v_path_246})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1(a[0], a[1], a2, a[3], a[4], a5); heff_drop(a2); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_path_246 = heff_env(self)[0];
  V v_t_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2420));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_246, v_t_2421));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_242 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_done_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_path_246 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_clo_take(self, 6);
    heff_drop(v_path_246);
    return ({ V a_0 = v_dir_240; V a_1 = v_parts_242; V a_2 = v_p_241; V a_3 = v_done_243; V a_4 = v_p_244; V b_5 = heff_tag_re_n(v_ru_24x_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2416}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_parts_242); heff_drop(b_5); r_; });
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      V v_err_2418 = heff_field(v_y_2417, 0);
      V v_ru_24y_2417_24Left = heff_take_reuse_n(v_y_2417, 1ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_path_246);
      heff_drop_cell(v_ru_24x_2415_24Right, 1);
      return ({ V a_0 = v_dir_240; V a_1 = v_parts_242; V a_2 = v_p_241; V a_3 = v_done_243; V a_4 = v_p_244; V b_5 = heff_tag_re_n(v_ru_24y_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2418}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_parts_242); heff_drop(b_5); r_; });
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      heff_clo_take(self, 6);
      V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l1_lam2, 1, 1, (V[]){v_path_246}), v_x_2419));
      V v_x_2423 = (g_list_2emap_24s219049803x1458391381(v_x_2422));
      return ({ V a_0 = v_dir_240; V a_1 = v_parts_242; V a_2 = v_p_241; V a_3 = v_done_243; V a_4 = v_p_244; V b_5 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Right, 1, (V[]){v_x_2423}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_2ek_24l0(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(v_parts_242); heff_drop(b_5); r_; });
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}