// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CDropSelf 14512
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CTakeSelf 23160
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStatic 28982
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Tip 31527
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_gives 299725724
#define LBL_lets 9813631
static uint32_t shape_lets__gives[] = {LBL_lets, LBL_gives};
V g_heff_2ecompile_2estatics_2eflatConst(V);
V g_heff_2ecompile_2estatics_2eflatConst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2estatics_2eflatConst_clo;
V g_heff_2ecompile_2estatics_2elaidOut(V, V, V);
V g_heff_2ecompile_2estatics_2elaidOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2estatics_2elaidOut_clo;
V g_heff_2ecompile_2estatics_2elaidStart(V, V, V);
V g_heff_2ecompile_2estatics_2elaidStart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2estatics_2elaidStart_clo;
V g_heff_2ecompile_2estatics_2eofConstants(V, V, V);
V g_heff_2ecompile_2estatics_2eofConstants_entry(V self, V *a);
extern Clo g_heff_2ecompile_2estatics_2eofConstants_clo;
V g_heff_2ecompile_2estatics_2estartOf(V, V);
V g_heff_2ecompile_2estatics_2estartOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2estatics_2estartOf_clo;
HeffT2 g_heff_2ecompile_2estatics_2estartOf_24cpr(V, V);
V g_heff_2ecompile_2estatics_2estaticDef(V);
V g_heff_2ecompile_2estatics_2estaticDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2estatics_2estaticDef_clo;
V g_heff_2ecompile_2estatics_2eusesOf(V, V);
V g_heff_2ecompile_2estatics_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2estatics_2eusesOf_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1194865087x542407696(V, V);
V g_list_2efoldl_24s1194865087x542407696_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1194865087x542407696_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1320100344x346546677(V, V);
V g_list_2emap_24f1320100344x346546677_entry(V self, V *a);
extern Clo g_list_2emap_24f1320100344x346546677_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s2062166816x394105956(V);
V g_list_2emap_24s2062166816x394105956_entry(V self, V *a);
extern Clo g_list_2emap_24s2062166816x394105956_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2estatics_2eflatConst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2estatics_2eflatConst_entry, 1, 0};

V g_heff_2ecompile_2estatics_2eflatConst(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_RLocal: {
    return NTAG(TAG_False);
  }
  case TAG_RDup: {
    return NTAG(TAG_False);
  }
  case TAG_RClo: {
    return NTAG(TAG_False);
  }
  case TAG_RGet: {
    return NTAG(TAG_False);
  }
  case TAG_RGetRaw: {
    return NTAG(TAG_False);
  }
  case TAG_RInt: {
    return NTAG(TAG_False);
  }
  case TAG_RFloat: {
    return NTAG(TAG_False);
  }
  case TAG_RStr: {
    return NTAG(TAG_False);
  }
  case TAG_RBytes: {
    return NTAG(TAG_False);
  }
  case TAG_RFixed: {
    return NTAG(TAG_False);
  }
  case TAG_RF32: {
    return NTAG(TAG_False);
  }
  case TAG_RNTag: {
    return NTAG(TAG_False);
  }
  case TAG_RStatic: {
    return NTAG(TAG_False);
  }
  case TAG_RTag: {
    return NTAG(TAG_False);
  }
  case TAG_RTagIn: {
    return NTAG(TAG_False);
  }
  case TAG_RRec: {
    return NTAG(TAG_False);
  }
  case TAG_RRecIn: {
    return NTAG(TAG_False);
  }
  case TAG_RField: {
    return NTAG(TAG_False);
  }
  case TAG_RDupE: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldV: {
    return NTAG(TAG_False);
  }
  case TAG_RGetN: {
    return NTAG(TAG_False);
  }
  case TAG_RFieldU: {
    return NTAG(TAG_False);
  }
  case TAG_RGetNU: {
    return NTAG(TAG_False);
  }
  case TAG_RWord: {
    V v_e1_2452 = heff_field(v_e_240, 0);
    V v_e2_2453 = heff_field(v_e_240, 1);
    switch (heff_tag_of(v_e1_2452)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      V v_w_2454 = heff_field(v_e1_2452, 0);
      switch (heff_tag_of(v_e2_2453)) {
      case TAG_RLocal: {
        return NTAG(TAG_False);
      }
      case TAG_RDup: {
        return NTAG(TAG_False);
      }
      case TAG_RClo: {
        return NTAG(TAG_False);
      }
      case TAG_RGet: {
        return NTAG(TAG_False);
      }
      case TAG_RGetRaw: {
        return NTAG(TAG_False);
      }
      case TAG_RInt: {
        return NTAG(TAG_False);
      }
      case TAG_RFloat: {
        return NTAG(TAG_False);
      }
      case TAG_RStr: {
        return NTAG(TAG_False);
      }
      case TAG_RBytes: {
        return NTAG(TAG_False);
      }
      case TAG_RFixed: {
        return NTAG(TAG_False);
      }
      case TAG_RF32: {
        return NTAG(TAG_False);
      }
      case TAG_RNTag: {
        return NTAG(TAG_False);
      }
      case TAG_RStatic: {
        return NTAG(TAG_False);
      }
      case TAG_RTag: {
        return NTAG(TAG_False);
      }
      case TAG_RTagIn: {
        return NTAG(TAG_False);
      }
      case TAG_RRec: {
        return NTAG(TAG_False);
      }
      case TAG_RRecIn: {
        return NTAG(TAG_False);
      }
      case TAG_RField: {
        return NTAG(TAG_False);
      }
      case TAG_RDupE: {
        return NTAG(TAG_False);
      }
      case TAG_RFieldV: {
        return NTAG(TAG_False);
      }
      case TAG_RGetN: {
        return NTAG(TAG_False);
      }
      case TAG_RFieldU: {
        return NTAG(TAG_False);
      }
      case TAG_RGetNU: {
        return NTAG(TAG_False);
      }
      case TAG_RWord: {
        return NTAG(TAG_False);
      }
      case TAG_RTakeField: {
        return NTAG(TAG_False);
      }
      case TAG_RGetLabel: {
        return NTAG(TAG_False);
      }
      case TAG_RPrimFn: {
        return NTAG(TAG_False);
      }
      case TAG_RPrim: {
        return NTAG(TAG_False);
      }
      case TAG_RLam: {
        return NTAG(TAG_False);
      }
      case TAG_RCall: {
        return NTAG(TAG_False);
      }
      case TAG_RApply: {
        return NTAG(TAG_False);
      }
      case TAG_RBool: {
        return NTAG(TAG_False);
      }
      case TAG_RAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_RBox: {
        return NTAG(TAG_False);
      }
      case TAG_RUnbox: {
        return NTAG(TAG_False);
      }
      case TAG_RPeek: {
        return NTAG(TAG_False);
      }
      case TAG_RPrimU: {
        return NTAG(TAG_False);
      }
      case TAG_RPrimAt: {
        return NTAG(TAG_False);
      }
      case TAG_RFixU: {
        int64_t v_t_24139;
        switch (heff_tag_of(v_w_2454)) {
        case TAG_I8: {
          v_t_24139 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_24139 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_24139 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_24139 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_24139 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_24139 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_24139 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_24139 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_24139 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_2454);
        }
        if ((v_t_24139 == ((int64_t)64ULL))) {
          switch (heff_tag_of(v_w_2454)) {
          case TAG_I8: {
            return NTAG(TAG_True);
          }
          case TAG_I16: {
            return NTAG(TAG_True);
          }
          case TAG_I32: {
            return NTAG(TAG_True);
          }
          case TAG_I64: {
            return NTAG(TAG_True);
          }
          case TAG_U8: {
            return NTAG(TAG_True);
          }
          case TAG_U16: {
            return NTAG(TAG_True);
          }
          case TAG_U32: {
            return NTAG(TAG_True);
          }
          case TAG_U64: {
            return NTAG(TAG_True);
          }
          case TAG_F32: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_w_2454);
          }
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_RF32U: {
        return NTAG(TAG_False);
      }
      case TAG_RF64U: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e2_2453);
      }
    }
    case TAG_RepF64: {
      switch (heff_tag_of(v_e2_2453)) {
      case TAG_RLocal: {
        return NTAG(TAG_False);
      }
      case TAG_RDup: {
        return NTAG(TAG_False);
      }
      case TAG_RClo: {
        return NTAG(TAG_False);
      }
      case TAG_RGet: {
        return NTAG(TAG_False);
      }
      case TAG_RGetRaw: {
        return NTAG(TAG_False);
      }
      case TAG_RInt: {
        return NTAG(TAG_False);
      }
      case TAG_RFloat: {
        return NTAG(TAG_False);
      }
      case TAG_RStr: {
        return NTAG(TAG_False);
      }
      case TAG_RBytes: {
        return NTAG(TAG_False);
      }
      case TAG_RFixed: {
        return NTAG(TAG_False);
      }
      case TAG_RF32: {
        return NTAG(TAG_False);
      }
      case TAG_RNTag: {
        return NTAG(TAG_False);
      }
      case TAG_RStatic: {
        return NTAG(TAG_False);
      }
      case TAG_RTag: {
        return NTAG(TAG_False);
      }
      case TAG_RTagIn: {
        return NTAG(TAG_False);
      }
      case TAG_RRec: {
        return NTAG(TAG_False);
      }
      case TAG_RRecIn: {
        return NTAG(TAG_False);
      }
      case TAG_RField: {
        return NTAG(TAG_False);
      }
      case TAG_RDupE: {
        return NTAG(TAG_False);
      }
      case TAG_RFieldV: {
        return NTAG(TAG_False);
      }
      case TAG_RGetN: {
        return NTAG(TAG_False);
      }
      case TAG_RFieldU: {
        return NTAG(TAG_False);
      }
      case TAG_RGetNU: {
        return NTAG(TAG_False);
      }
      case TAG_RWord: {
        return NTAG(TAG_False);
      }
      case TAG_RTakeField: {
        return NTAG(TAG_False);
      }
      case TAG_RGetLabel: {
        return NTAG(TAG_False);
      }
      case TAG_RPrimFn: {
        return NTAG(TAG_False);
      }
      case TAG_RPrim: {
        return NTAG(TAG_False);
      }
      case TAG_RLam: {
        return NTAG(TAG_False);
      }
      case TAG_RCall: {
        return NTAG(TAG_False);
      }
      case TAG_RApply: {
        return NTAG(TAG_False);
      }
      case TAG_RBool: {
        return NTAG(TAG_False);
      }
      case TAG_RAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_RBox: {
        return NTAG(TAG_False);
      }
      case TAG_RUnbox: {
        return NTAG(TAG_False);
      }
      case TAG_RPeek: {
        return NTAG(TAG_False);
      }
      case TAG_RPrimU: {
        return NTAG(TAG_False);
      }
      case TAG_RPrimAt: {
        return NTAG(TAG_False);
      }
      case TAG_RFixU: {
        return NTAG(TAG_False);
      }
      case TAG_RF32U: {
        return NTAG(TAG_False);
      }
      case TAG_RF64U: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e2_2453);
      }
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_2452);
    }
  }
  case TAG_RTakeField: {
    return NTAG(TAG_False);
  }
  case TAG_RGetLabel: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimFn: {
    return NTAG(TAG_False);
  }
  case TAG_RPrim: {
    return NTAG(TAG_False);
  }
  case TAG_RLam: {
    return NTAG(TAG_False);
  }
  case TAG_RCall: {
    return NTAG(TAG_False);
  }
  case TAG_RApply: {
    return NTAG(TAG_False);
  }
  case TAG_RBool: {
    return NTAG(TAG_False);
  }
  case TAG_RAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_RBox: {
    return NTAG(TAG_False);
  }
  case TAG_RUnbox: {
    return NTAG(TAG_False);
  }
  case TAG_RPeek: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimU: {
    return NTAG(TAG_False);
  }
  case TAG_RPrimAt: {
    return NTAG(TAG_False);
  }
  case TAG_RFixU: {
    return NTAG(TAG_False);
  }
  case TAG_RF32U: {
    return NTAG(TAG_False);
  }
  case TAG_RF64U: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2estatics_2eflatConst_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2estatics_2eflatConst(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2estatics_2eofConstants_lam0(V self, V *args);
V g_heff_2ecompile_2estatics_2eofConstants_lam1(V self, V *args);
Clo g_heff_2ecompile_2estatics_2eofConstants_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2estatics_2eofConstants_entry, 3, 0};

V g_heff_2ecompile_2estatics_2eofConstants(V v_vs_240, V v_field_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_RLocal: {
    V v_x_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    if ((heff_dup(v_field_241) == NTAG(TAG_True))) {
      HeffT2 v_t_244 = ({ V a_0 = v_vs_240; V a_1 = v_x_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_243); r_; });
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_245 == ((int64_t)0ULL)) && ({ V v_x_247 = heff_dup(v_field_246); int c_ = 1; heff_drop(v_x_247); c_; })));
        heff_drop(v_field_246);
        return v_ret_24bool;
      }
    } else {
      heff_drop(v_x_243);
      return NTAG(TAG_False);
    }
  }
  case TAG_RDup: {
    V v_x_248 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    if ((heff_dup(v_field_241) == NTAG(TAG_True))) {
      HeffT2 v_t_249 = ({ V a_0 = v_vs_240; V a_1 = v_x_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_248); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_2410 == ((int64_t)0ULL)) && ({ V v_x_2412 = heff_dup(v_field_2411); int c_ = 1; heff_drop(v_x_2412); c_; })));
        heff_drop(v_field_2411);
        return v_ret_24bool;
      }
    } else {
      heff_drop(v_x_248);
      return NTAG(TAG_False);
    }
  }
  case TAG_RFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_RTag: {
    V v_t_2414 = heff_field(v_x3_242, 0);
    V v_es_2416 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 5ULL, 3);
    if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2414, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2414, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)) {
      heff_drop(v_t_2414);
      return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2estatics_2eofConstants_lam0, 1, 1, (V[]){heff_dup(v_vs_240)}); V a_1 = v_es_2416; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_2416); r_; });
    } else {
      heff_drop(v_t_2414);
      heff_drop(v_es_2416);
      return NTAG(TAG_False);
    }
  }
  case TAG_RRec: {
    V v_es_2420 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 4ULL, 3);
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2estatics_2eofConstants_lam1, 1, 1, (V[]){heff_dup(v_vs_240)}); V a_1 = v_es_2420; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_2420); r_; });
  }
  default: {
    if ((heff_dup(v_field_241) == NTAG(TAG_True))) {
      V v_e_2422 = v_x3_242;
      switch (heff_tag_of(v_e_2422)) {
      case TAG_RInt: {
        V v_n_2423 = heff_field(v_e_2422, 0);
        heff_take_n(v_e_2422, 1ULL, 1);
        V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_n_2423, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_2423, 1)));
        heff_drop(v_n_2423);
        return v_ret_24bool;
      }
      case TAG_RStr: {
        heff_take_n(v_e_2422, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_RBytes: {
        heff_take_n(v_e_2422, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_RFixed: {
        V v_w_2426 = heff_field(v_e_2422, 0);
        V v_n_2427 = heff_field(v_e_2422, 1);
        heff_take_n(v_e_2422, 3ULL, 2);
        int64_t v_t_2428;
        switch (heff_tag_of(v_w_2426)) {
        case TAG_I8: {
          v_t_2428 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_2428 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_2428 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_2428 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_2428 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_2428 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_2428 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_2428 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_2428 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_2426);
        }
        V v_ret_24bool = heff_bool(((v_t_2428 < ((int64_t)64ULL)) || (heff_intLt_c_lent(v_n_2427, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_2427, 1))));
        heff_drop(v_n_2427);
        return v_ret_24bool;
      }
      case TAG_RNTag: {
        heff_take_n(v_e_2422, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: {
        return ({ V a_0 = v_e_2422; V r_ = (g_heff_2ecompile_2estatics_2eflatConst(a_0)); heff_drop(v_e_2422); r_; });
      }
      }
    } else {
      heff_drop(v_x3_242);
      return NTAG(TAG_False);
    }
  }
  }
}
V g_heff_2ecompile_2estatics_2eofConstants_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2estatics_2eofConstants(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2estatics_2eofConstants_lam0(V self, V *args) {
  V v_e_2417 = args[0];
  V v_vs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_vs_240; V a_1 = NTAG(TAG_True); V a_2 = v_e_2417; V r_ = (g_heff_2ecompile_2estatics_2eofConstants(a_0, a_1, a_2)); heff_drop(v_vs_240); r_; });
}
V g_heff_2ecompile_2estatics_2eofConstants_lam1(V self, V *args) {
  V v_e_2421 = args[0];
  V v_vs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_vs_240; V a_1 = NTAG(TAG_True); V a_2 = v_e_2421; V r_ = (g_heff_2ecompile_2estatics_2eofConstants(a_0, a_1, a_2)); heff_drop(v_vs_240); r_; });
}

HeffT2 g_heff_2ecompile_2estatics_2estartOf_24cpr(V v_vs_240, V v_ss_241) {
top: ;
  switch (heff_tag_of(v_ss_241)) {
  case TAG_Nil: {
    heff_drop(v_vs_240);
    return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_ss1_242 = heff_field(v_ss_241, 0);
    V v_rest_243 = heff_field(v_ss_241, 1);
    V v_ru_24ss_241_24Cons = heff_take_reuse_n(v_ss_241, 3ULL, 2);
    switch (heff_tag_of(v_ss1_242)) {
    case TAG_CDrop: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CLet: {
      V v_x_245 = heff_field(v_ss1_242, 0);
      V v_e_246 = heff_field(v_ss1_242, 1);
      V v_ru_24ss1_242_24CLet = heff_take_reuse_n(v_ss1_242, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2estatics_2eofConstants(v_vs_240, NTAG(TAG_False), heff_dup(v_e_246)));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_248 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_vs_240, v_x_245, NTAG(TAG_MkUnit)));
        HeffT2 v_t_249 = (g_heff_2ecompile_2estatics_2estartOf_24cpr(v_t_248, v_rest_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_t_2412 = heff_tag_at_n(v_ru_24ss_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24ss1_242_24CLet, TAG_MkPair, 2, (V[]){v_x_245, v_e_246}), v_field_2410});
          return ((HeffT2){{v_t_2412, v_field_2411}});
        }
      } else {
        heff_drop(v_vs_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24ss_241_24Cons, 2);
        heff_drop(v_x_245);
        heff_drop(v_e_246);
        heff_drop_cell(v_ru_24ss1_242_24CLet, 2);
        heff_drop(v_t_247);
        return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
      }
    }
    case TAG_CDecl: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CSet: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CAbandon: {
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CIf: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CSwitch: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CReturn: {
      V v_e_2422 = heff_field(v_ss1_242, 0);
      V v_ru_24ss1_242_24CReturn = heff_take_reuse_n(v_ss1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      switch (heff_tag_of(v_rest_243)) {
      case TAG_Nil: {
        V v_t_2423 = ({ V a_0 = v_vs_240; V a_1 = NTAG(TAG_False); V a_2 = heff_dup(v_e_2422); V r_ = (g_heff_2ecompile_2estatics_2eofConstants(a_0, a_1, a_2)); heff_drop(v_vs_240); r_; });
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_t_2423);
          return ((HeffT2){{NTAG(TAG_Nil), heff_tag_at_n(v_ru_24ss1_242_24CReturn, TAG_Just, 1, (V[]){v_e_2422})}});
        } else {
          heff_drop(v_e_2422);
          heff_drop_cell(v_ru_24ss1_242_24CReturn, 1);
          heff_drop(v_t_2423);
          return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest_243, 0ULL, 2);
        heff_drop(v_vs_240);
        heff_drop(v_e_2422);
        heff_drop_cell(v_ru_24ss1_242_24CReturn, 1);
        return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_rest_243)}});
      }
    }
    case TAG_CInPlace: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CRoomed: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CTail: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CLoop: {
      heff_take_n(v_ss1_242, 0ULL, 2);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CLoopTo: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CLabel: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CJump: {
      heff_take_n(v_ss1_242, 0ULL, 3);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CTakeSelf: {
      heff_take_n(v_ss1_242, 0ULL, 1);
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    case TAG_CDropSelf: {
      heff_drop(v_vs_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24ss_241_24Cons, 2);
      return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nothing)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ss1_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ss_241)}});
  }
}
Clo g_heff_2ecompile_2estatics_2estartOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2estatics_2estartOf_entry, 2, 0};

V g_heff_2ecompile_2estatics_2estartOf(V v_vs_240, V v_ss_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2estatics_2estartOf_24cpr(v_vs_240, v_ss_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_rec_n(2, shape_lets__gives, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2estatics_2estartOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2estatics_2estartOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2estatics_2eusesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2estatics_2eusesOf_entry, 2, 0};

V g_heff_2ecompile_2estatics_2eusesOf(V v_u_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_u_240)) {
  case TAG_MkPair: {
    V v_gs_242 = heff_dup(heff_field(v_u_240, 0));
    V v_ds_243 = heff_dup(heff_field(v_u_240, 1));
    switch (heff_tag_of(v_e_241)) {
    case TAG_RLocal: {
      V v_x_244 = heff_field(v_e_241, 0);
      heff_drop_tag(v_u_240, 2);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), v_gs_242}), v_ds_243});
    }
    case TAG_RDup: {
      V v_x_245 = heff_field(v_e_241, 0);
      heff_drop_tag(v_u_240, 2);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_gs_242, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_ds_243})});
    }
    case TAG_RClo: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RGet: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RGetRaw: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RInt: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RFloat: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RStr: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RBytes: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RFixed: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RF32: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RNTag: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RStatic: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RTag: {
      V v_es_2421 = heff_field(v_e_241, 2);
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return ({ V b_0 = ((V)&g_heff_2ecompile_2estatics_2eusesOf_clo); V a_1 = v_u_240; V a_2 = v_es_2421; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    }
    case TAG_RTagIn: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RRec: {
      V v_es_2429 = heff_field(v_e_241, 2);
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return ({ V b_0 = ((V)&g_heff_2ecompile_2estatics_2eusesOf_clo); V a_1 = v_u_240; V a_2 = v_es_2429; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    }
    case TAG_RRecIn: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RField: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RDupE: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RFieldV: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RGetN: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RFieldU: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RGetNU: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RWord: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RTakeField: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RGetLabel: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RPrimFn: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RPrim: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RLam: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RCall: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RApply: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RBool: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RAbandon: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RBox: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RUnbox: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RPeek: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RPrimU: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RPrimAt: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RFixU: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RF32U: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    case TAG_RF64U: {
      heff_drop(v_gs_242);
      heff_drop(v_ds_243);
      return v_u_240;
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_u_240);
  }
}
V g_heff_2ecompile_2estatics_2eusesOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2estatics_2eusesOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2estatics_2elaidOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2estatics_2elaidOut_entry, 3, 0};

V g_heff_2ecompile_2estatics_2elaidOut(V v_lets_240, V v_put_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_RLocal: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24RLocal = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_put_241, v_x_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_lets_240, v_x_243));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            heff_drop(v_x_243);
            heff_drop_cell(v_ru_24x3_242_24RLocal, 1);
            V v_e_2411 = v_field_2410;
            V t_0 = v_lets_240;
            V t_1 = v_put_241;
            V t_2 = v_e_2411;
            v_lets_240 = t_0;
            v_put_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_field_2410);
            return heff_tag_re_n(v_ru_24x3_242_24RLocal, TAG_RLocal, 1, 1ULL, (V[]){v_x_243});
          }
        }
      } else {
        heff_drop(v_field_246);
        return heff_tag_re_n(v_ru_24x3_242_24RLocal, TAG_RLocal, 1, 1ULL, (V[]){v_x_243});
      }
    }
  }
  case TAG_RDup: {
    V v_x_2412 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24RDup = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24RDup, TAG_RLocal, 1, (V[]){v_x_2412});
  }
  case TAG_RClo: {
    return v_x3_242;
  }
  case TAG_RGet: {
    return v_x3_242;
  }
  case TAG_RGetRaw: {
    return v_x3_242;
  }
  case TAG_RInt: {
    return v_x3_242;
  }
  case TAG_RFloat: {
    return v_x3_242;
  }
  case TAG_RStr: {
    return v_x3_242;
  }
  case TAG_RBytes: {
    return v_x3_242;
  }
  case TAG_RFixed: {
    return v_x3_242;
  }
  case TAG_RF32: {
    return v_x3_242;
  }
  case TAG_RNTag: {
    return v_x3_242;
  }
  case TAG_RStatic: {
    return v_x3_242;
  }
  case TAG_RTag: {
    V v_t_2426 = heff_field(v_x3_242, 0);
    V v_b_2427 = heff_field(v_x3_242, 1);
    V v_es_2428 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24RTag = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2429 = heff_tr(heff_call(((V)&g_heff_2ecompile_2estatics_2elaidOut_clo), 2, (V[]){heff_dup(v_lets_240), heff_dup(v_put_241)}));
    V v_t_2430 = (g_list_2emap(v_t_2429, v_es_2428));
    return heff_tag_re_n(v_ru_24x3_242_24RTag, TAG_RTag, 3, 3ULL, (V[]){v_t_2426, v_b_2427, v_t_2430});
  }
  case TAG_RTagIn: {
    return v_x3_242;
  }
  case TAG_RRec: {
    V v_ls_2436 = heff_field(v_x3_242, 0);
    V v_b_2437 = heff_field(v_x3_242, 1);
    V v_es_2438 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24RRec = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2estatics_2elaidOut_clo), 2, (V[]){heff_dup(v_lets_240), heff_dup(v_put_241)}));
    V v_t_2440 = (g_list_2emap(v_t_2439, v_es_2438));
    return heff_tag_re_n(v_ru_24x3_242_24RRec, TAG_RRec, 3, 3ULL, (V[]){v_ls_2436, v_b_2437, v_t_2440});
  }
  case TAG_RRecIn: {
    return v_x3_242;
  }
  case TAG_RField: {
    return v_x3_242;
  }
  case TAG_RDupE: {
    return v_x3_242;
  }
  case TAG_RFieldV: {
    return v_x3_242;
  }
  case TAG_RGetN: {
    return v_x3_242;
  }
  case TAG_RFieldU: {
    return v_x3_242;
  }
  case TAG_RGetNU: {
    return v_x3_242;
  }
  case TAG_RWord: {
    return v_x3_242;
  }
  case TAG_RTakeField: {
    return v_x3_242;
  }
  case TAG_RGetLabel: {
    return v_x3_242;
  }
  case TAG_RPrimFn: {
    return v_x3_242;
  }
  case TAG_RPrim: {
    return v_x3_242;
  }
  case TAG_RLam: {
    return v_x3_242;
  }
  case TAG_RCall: {
    return v_x3_242;
  }
  case TAG_RApply: {
    return v_x3_242;
  }
  case TAG_RBool: {
    return v_x3_242;
  }
  case TAG_RAbandon: {
    return v_x3_242;
  }
  case TAG_RBox: {
    return v_x3_242;
  }
  case TAG_RUnbox: {
    return v_x3_242;
  }
  case TAG_RPeek: {
    return v_x3_242;
  }
  case TAG_RPrimU: {
    return v_x3_242;
  }
  case TAG_RPrimAt: {
    return v_x3_242;
  }
  case TAG_RFixU: {
    return v_x3_242;
  }
  case TAG_RF32U: {
    return v_x3_242;
  }
  case TAG_RF64U: {
    return v_x3_242;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2estatics_2elaidOut_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2estatics_2elaidOut(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2estatics_2elaidStart_str0, 0, "");
V g_heff_2ecompile_2estatics_2elaidStart_lam0(V self, V *args);
V g_heff_2ecompile_2estatics_2elaidStart_lam1(V self, V *args);
Clo g_heff_2ecompile_2estatics_2elaidStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2estatics_2elaidStart_entry, 3, 0};

V g_heff_2ecompile_2estatics_2elaidStart(V v_st_240, V v_x2_241, V v_rest_242) {
top: ;
  V v_lets_243 = heff_take_field(v_st_240, 0);
  V v_gives_244 = heff_get_n(v_st_240, 1, 2);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_gs_245 = heff_field(v_x2_241, 0);
    V v_ds_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_ps_247 = (g_list_2emap_24s2062166816x394105956(v_ds_246));
    V v_counted_248 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_247; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_247); r_; });
    V v_ps_2414 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2estatics_2elaidStart_lam0, 1, 1, (V[]){v_counted_248}); V a_1 = v_gs_245; V r_ = (g_list_2emap_24f1320100344x346546677(b_0, a_1)); heff_drop(b_0); r_; });
    V v_put_2415 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2414; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2414); r_; });
    V v_lets_2416 = (g_list_2efoldl_24s2127176832x914341824(NTAG(TAG_Tip), v_lets_243));
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_lets_243));
    V v_t_2429 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2estatics_2elaidStart_lam1, 2, 2, (V[]){heff_dup(v_put_2415), heff_dup(v_lets_2416)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2417; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2417); r_; });
    V v_t_2430 = v_gives_244;
    V v_t_2434;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      heff_drop(v_put_2415);
      heff_drop(v_lets_2416);
      v_t_2434 = v_rest_242;
      break;
    }
    case TAG_Just: {
      V v_e_2431 = heff_field(v_t_2430, 0);
      V v_ru_24t_2430_24Just = heff_take_reuse_n(v_t_2430, 1ULL, 1);
      heff_drop(v_rest_242);
      V v_t_2432 = ({ V a_0 = v_lets_2416; V a_1 = v_put_2415; V a_2 = v_e_2431; V r_ = (g_heff_2ecompile_2estatics_2elaidOut(a_0, a_1, a_2)); heff_drop(v_lets_2416); heff_drop(v_put_2415); r_; });
      V v_t_2433 = heff_tag_at_n(v_ru_24t_2430_24Just, TAG_CReturn, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_RStatic, 2, (V[]){((V)&g_heff_2ecompile_2estatics_2elaidStart_str0), v_t_2432})});
      v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    return (g_prelude_2e_2b_2b(v_t_2429, v_t_2434));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2estatics_2elaidStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2estatics_2elaidStart(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2estatics_2elaidStart_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_counted_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = ({ V a_0 = v_counted_248; V a_1 = v_x_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_counted_248); heff_drop(v_x_249); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2411 == ((int64_t)0ULL)) ? ({ V v_x_2413 = heff_dup(v_field_2412); int c_ = 0; heff_drop(v_x_2413); c_; }) : 1));
    heff_drop(v_field_2412);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2estatics_2elaidStart_lam1(V self, V *args) {
  V v_acc_2418 = args[0];
  V v_x_2419 = args[1];
  V v_put_2415 = heff_env(self)[0];
  V v_lets_2416 = heff_env(self)[1];
  V v_t_2428;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_e_2421 = heff_field(v_x_2419, 1);
    V v_ru_24x_2419_24MkPair = heff_take_reuse_n(v_x_2419, 3ULL, 2);
    HeffT2 v_t_2422 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_put_2415, v_x_2420));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        heff_drop(v_put_2415);
        heff_drop(v_lets_2416);
        heff_drop(v_x_2420);
        heff_drop(v_e_2421);
        heff_drop_cell(v_ru_24x_2419_24MkPair, 2);
        V v_x_2425 = v_field_2424;
        heff_drop(v_x_2425);
        v_t_2428 = NTAG(TAG_Nil);
      } else {
        heff_drop(v_field_2424);
        V v_t_2426 = ({ V a_0 = v_lets_2416; V a_1 = v_put_2415; V a_2 = v_e_2421; V r_ = (g_heff_2ecompile_2estatics_2elaidOut(a_0, a_1, a_2)); heff_drop(v_lets_2416); heff_drop(v_put_2415); r_; });
        V v_t_2427 = heff_tag_at_n(v_ru_24x_2419_24MkPair, TAG_CLet, 2, (V[]){heff_dup(v_x_2420), heff_tag_n(TAG_RStatic, 2, (V[]){v_x_2420, v_t_2426})});
        v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  return (g_prelude_2e_2b_2b(v_t_2428, v_acc_2418));
}
Clo g_heff_2ecompile_2estatics_2estaticDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2estatics_2estaticDef_entry, 1, 0};

V g_heff_2ecompile_2estatics_2estaticDef(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DFun: {
    return v_d_240;
  }
  case TAG_DVal: {
    V v_x_242 = heff_field(v_d_240, 0);
    V v_ss_243 = heff_field(v_d_240, 1);
    V v_rs_244 = heff_field(v_d_240, 2);
    V v_ru_24d_240_24DVal = heff_take_reuse_n(v_d_240, 7ULL, 3);
    V v_st_245 = (g_heff_2ecompile_2estatics_2estartOf(heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_ss_243)));
    V v_t_246 = heff_dup(heff_rfield(v_st_245, 0));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      V v_t_247 = heff_dup(heff_rfield(v_st_245, 1));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_st_245, 2);
        return heff_tag_re_n(v_ru_24d_240_24DVal, TAG_DVal, 3, 7ULL, (V[]){v_x_242, v_ss_243, v_rs_244});
      }
      case TAG_Just: {
        heff_take_n(v_t_247, 0ULL, 1);
        V v_t_249 = (g_list_2emap_24s1173914895x100384474(heff_dup(heff_rfield(v_st_245, 0))));
        V v_t_2410 = heff_dup(heff_rfield(v_st_245, 1));
        V v_t_2412;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_e_2411 = heff_field(v_t_2410, 0);
          heff_take_n(v_t_2410, 1ULL, 1);
          v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2411, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        V v_t_2413 = (g_prelude_2e_2b_2b(v_t_249, v_t_2412));
        V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
        V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s1194865087x542407696(a_0, a_1)); heff_drop(v_t_2413); r_; });
        V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_st_245, 0)));
        V v_t_2417 = ({ V a_0 = v_t_2416; V a_1 = v_ss_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_ss_243); r_; });
        V v_t_2418 = (g_heff_2ecompile_2estatics_2elaidStart(v_st_245, v_t_2415, v_t_2417));
        return heff_tag_re_n(v_ru_24d_240_24DVal, TAG_DVal, 3, 5ULL, (V[]){v_x_242, v_t_2418, v_rs_244});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_Cons: {
      V v_ru_24t_246_24Cons = heff_take_reuse_n(v_t_246, 0ULL, 2);
      V v_t_2421 = (g_list_2emap_24s1173914895x100384474(heff_dup(heff_rfield(v_st_245, 0))));
      V v_t_2422 = heff_dup(heff_rfield(v_st_245, 1));
      V v_t_2424;
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_246_24Cons, 2);
        v_t_2424 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_e_2423 = heff_field(v_t_2422, 0);
        heff_take_n(v_t_2422, 1ULL, 1);
        v_t_2424 = heff_tag_at_n(v_ru_24t_246_24Cons, TAG_Cons, 2, (V[]){v_e_2423, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      V v_t_2425 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2424));
      V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_t_2427 = ({ V a_0 = v_t_2426; V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1194865087x542407696(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_st_245, 0)));
      V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_ss_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_ss_243); r_; });
      V v_t_2430 = (g_heff_2ecompile_2estatics_2elaidStart(v_st_245, v_t_2427, v_t_2429));
      return heff_tag_re_n(v_ru_24d_240_24DVal, TAG_DVal, 3, 5ULL, (V[]){v_x_242, v_t_2430, v_rs_244});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2ecompile_2estatics_2estaticDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2estatics_2estaticDef(a[0]);
}