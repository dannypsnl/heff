// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IntoCons 46138
#define TAG_LChunkSnoc 25233
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkFolded 17353
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotApplicable 40298
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_TopL 65516
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_sol 323594
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(V, V);
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_clo;
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(V, V);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_clo;
V g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071(V);
V g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
HeffT2 g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr(V);
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2edecodeNeuOf(V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_clo;
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_clo;
V g_heff_2eelab_2evalue_2edefaultsOf(V);
V g_heff_2eelab_2evalue_2edefaultsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edefaultsOf_clo;
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_clo;
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1(V, V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eneuAppTy(V, V, V);
V g_heff_2eelab_2evalue_2eneuAppTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eneuAppTy_clo;
V g_heff_2eelab_2evalue_2eprojAt(V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_clo;
V g_heff_2eelab_2evalue_2ereflect(V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_clo;
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo;
V g_heff_2eelab_2evalue_2ereflect_24tok2(V, V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24tok2_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2eelab_2evalue_2especializations(V, V);
V g_heff_2eelab_2evalue_2especializations_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especializations_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_heff_2eelab_2evalue_2especialize_24tok3(V, V, V, V);
V g_heff_2eelab_2evalue_2especialize_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_24tok3_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eelab_2evalue_2etypeForProjection_24generate0(V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_24generate0_clo;
V g_heff_2eutil_2edict_2eempty_get(void);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2eelab_2evalue_2elocalsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2elocalsAt_entry, 2, 0};

V g_heff_2eelab_2evalue_2elocalsAt(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LNil: {
    heff_drop(v_i_241);
    return heff_abandon();
  }
  case TAG_LSnoc: {
    V v_e_242 = heff_field(v_x1_240, 0);
    V v_v_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return heff_tail(heff_dup(v_v_243), 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      V t_0 = v_e_242;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  case TAG_LChunkSnoc: {
    V v_e_244 = heff_field(v_x1_240, 0);
    V v_vs_245 = heff_field(v_x1_240, 1);
    V v_t_246 = heff_intSub_lent(heff_arrayLength_lent(v_vs_245, 0), v_i_241, 1);
    V v_i_247 = heff_intSub(v_t_246, MK_INT(1LL));
    if ((heff_intLe_c_lent(MK_INT(0LL), v_i_247, 1) && heff_intLt_c_lent(v_i_247, heff_arrayLength_lent(v_vs_245, 0), 2))) {
      heff_drop(v_i_241);
      V v_v_248 = heff_arrayIndex_lent(v_vs_245, v_i_247, 2);
      return v_v_248;
    } else {
      heff_drop(v_i_247);
      V v_t_249 = heff_intSub(v_i_241, heff_arrayLength_lent(v_vs_245, 0));
      V t_0 = v_e_244;
      V t_1 = v_t_249;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2elocalsAt(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2elevelOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2elevelOf_entry, 1, 0};

V g_heff_2eelab_2evalue_2elevelOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    V v_u_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_u_241)) {
    case TAG_SmallU: {
      return NTAG(TAG_Large);
    }
    case TAG_LargeU: {
      return NTAG(TAG_TopL);
    }
    default: return heff_nomatch(v_u_241);
    }
  }
  case TAG_VDecode: {
    V v_u_244 = heff_field(v_x1_240, 2);
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      return NTAG(TAG_Small);
    }
    case TAG_LargeU: {
      return NTAG(TAG_Large);
    }
    default: return heff_nomatch(v_u_244);
    }
  }
  case TAG_VFunction: {
    V v_level_247 = heff_field(v_x1_240, 0);
    return heff_dup(v_level_247);
  }
  case TAG_VRecord: {
    V v_level_2413 = heff_field(v_x1_240, 0);
    return heff_dup(v_level_2413);
  }
  case TAG_VSum: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_Small);
  }
  case TAG_VPrimArray: {
    V v_a_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_VFixed: {
    return NTAG(TAG_Small);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2elevelOf(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam1(V self, V *args);
Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry, 4, 0};

V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V v_h_240, V v_spine_241, V v_ty_242, V v_desc_243) {
top: ;
  return heff_tag_n(TAG_VNeu, 5, (V[]){heff_dup(v_h_240), heff_dup(v_spine_241), heff_dup(v_ty_242), heff_clo_n(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam0, 1, 4, (V[]){v_ty_242, v_h_240, v_spine_241, heff_dup(v_desc_243)}), heff_clo_n(g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam1, 1, 1, (V[]){v_desc_243})});
}
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_spine_241 = heff_env(self)[2];
  V v_desc_243 = heff_env(self)[3];
  heff_drop(v_u_244);
  heff_clo_take(self, 4);
  V v_t_245 = heff_tr(heff_call(v_ty_242, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_246 = (g_heff_2eelab_2evalue_2ebehavior(v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_LikeU: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_246, 0ULL, 4);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeRecord: {
    V v_capture_2413 = heff_field(v_t_246, 1);
    V v_fieldTypes_2414 = heff_field(v_t_246, 2);
    heff_take_n(v_t_246, 6ULL, 3);
    V v_t_2415 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2414, 0)));
    V v_t_2416 = heff_arrayToList(heff_take_field(v_fieldTypes_2414, 2));
    V v_t_2417 = (g_heff_2eutil_2edict_2ezipKV(v_t_2415, v_t_2416));
    V v_xs_2418 = ({ V a_0 = v_capture_2413; V a_1 = v_h_240; V a_2 = v_spine_241; V a_3 = v_desc_243; V a_4 = v_t_2417; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_h_240); heff_drop(v_spine_241); heff_drop(v_desc_243); r_; });
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
    V v_t_2420 = ({ V rv_2 = heff_arrayFromList(v_t_2419); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2414, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_IntoCons, 1, (V[]){v_t_2420});
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeInt: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFloat: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeString: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeRune: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_246, 0ULL, 1);
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  case TAG_NoRules: {
    heff_drop(v_h_240);
    heff_drop(v_spine_241);
    heff_drop(v_desc_243);
    return NTAG(TAG_NotApplicable);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_desc_243 = heff_env(self)[0];
  heff_drop(v_u_2424);
  heff_clo_take(self, 1);
  return v_desc_243;
}
V g_heff_2eelab_2evalue_2eprojAt_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2eprojAt_lam1(V self, V *args);
Clo g_heff_2eelab_2evalue_2eprojAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eprojAt_entry, 3, 0};

V g_heff_2eelab_2evalue_2eprojAt(V v_v_240, V v_x_241, V v_a_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr(v_v_240));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_v_240);
      heff_drop(v_a_242);
      V v_fields_246 = v_field_245;
      V v_byName_247 = heff_take_field(v_fields_246, 1);
      V v_values_248 = heff_get_n(v_fields_246, 2, 3);
      HeffT2 v_t_249 = ({ V a_0 = v_byName_247; V a_1 = v_x_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_247); heff_drop(v_x_241); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_i_2412 = v_field_2411;
          V v_xs_2413 = v_values_248;
          if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2412, 1) && heff_intLt_c_lent(v_i_2412, heff_arrayLength_lent(v_xs_2413, 0), 2))) {
            V v_v_2414 = heff_arrayIndex(v_xs_2413, v_i_2412);
            return v_v_2414;
          } else {
            heff_drop(v_i_2412);
            heff_drop(v_xs_2413);
            return heff_abandon();
          }
        } else {
          heff_drop(v_values_248);
          heff_drop(v_field_2411);
          return heff_abandon();
        }
      }
    } else {
      heff_drop(v_field_245);
      switch (heff_tag_of(v_v_240)) {
      case TAG_VNeu: {
        V v_h_2415 = heff_field(v_v_240, 0);
        V v_sp_2416 = heff_field(v_v_240, 1);
        heff_take_n(v_v_240, 3ULL, 5);
        V v_t_2422 = (g_heff_2eelab_2evalue_2ereflect(v_h_2415, heff_clo_n(g_heff_2eelab_2evalue_2eprojAt_lam0, 1, 2, (V[]){v_sp_2416, v_x_241}), heff_clo_n(g_heff_2eelab_2evalue_2eprojAt_lam1, 1, 1, (V[]){v_a_242}), NTAG(TAG_Nothing)));
        return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2422});
      }
      case TAG_VCode: {
        heff_drop(v_a_242);
        switch (heff_tag_of(v_v_240)) {
        case TAG_VNeu: {
          V v_t_2429 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 5); r_; });
          return ({ V a_0 = v_t_2429; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VCode: {
          V v_t_2431 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 1); r_; });
          return ({ V a_0 = v_t_2431; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VLam: {
          V v_t_2434 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 2); r_; });
          return ({ V a_0 = v_t_2434; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VCons: {
          V v_t_2436 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 1); r_; });
          return ({ V a_0 = v_t_2436; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VOpaque: {
          heff_drop(v_x_241);
          return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
        default: return heff_nomatch(v_v_240);
        }
      }
      case TAG_VLam: {
        heff_drop(v_a_242);
        switch (heff_tag_of(v_v_240)) {
        case TAG_VNeu: {
          V v_t_2444 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 5); r_; });
          return ({ V a_0 = v_t_2444; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VCode: {
          V v_t_2446 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 1); r_; });
          return ({ V a_0 = v_t_2446; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VLam: {
          V v_t_2449 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 2); r_; });
          return ({ V a_0 = v_t_2449; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VCons: {
          V v_t_2451 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 1); r_; });
          return ({ V a_0 = v_t_2451; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VOpaque: {
          heff_drop(v_x_241);
          return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
        default: return heff_nomatch(v_v_240);
        }
      }
      case TAG_VCons: {
        heff_drop(v_a_242);
        switch (heff_tag_of(v_v_240)) {
        case TAG_VNeu: {
          V v_t_2458 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 5); r_; });
          return ({ V a_0 = v_t_2458; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VCode: {
          V v_t_2460 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 1); r_; });
          return ({ V a_0 = v_t_2460; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VLam: {
          V v_t_2463 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 2); r_; });
          return ({ V a_0 = v_t_2463; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VCons: {
          V v_t_2465 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 1); r_; });
          return ({ V a_0 = v_t_2465; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VOpaque: {
          heff_drop(v_x_241);
          return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
        default: return heff_nomatch(v_v_240);
        }
      }
      case TAG_VOpaque: {
        heff_drop(v_a_242);
        switch (heff_tag_of(v_v_240)) {
        case TAG_VNeu: {
          V v_t_2471 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 5); r_; });
          return ({ V a_0 = v_t_2471; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VCode: {
          V v_t_2473 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 1); r_; });
          return ({ V a_0 = v_t_2473; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VLam: {
          V v_t_2476 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 2); r_; });
          return ({ V a_0 = v_t_2476; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VCons: {
          V v_t_2478 = ({ V a_0 = v_v_240; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_240, 1); r_; });
          return ({ V a_0 = v_t_2478; V a_1 = v_x_241; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_241); r_; });
        }
        case TAG_VOpaque: {
          heff_drop(v_x_241);
          return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
        default: return heff_nomatch(v_v_240);
        }
      }
      default: return heff_nomatch(v_v_240);
      }
    }
  }
}
V g_heff_2eelab_2evalue_2eprojAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eprojAt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2eprojAt_lam0(V self, V *args) {
  V v_u_2420 = args[0];
  V v_sp_2416 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_drop(v_u_2420);
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2416, v_x_241});
}
V g_heff_2eelab_2evalue_2eprojAt_lam1(V self, V *args) {
  V v_u_2421 = args[0];
  V v_a_242 = heff_env(self)[0];
  heff_drop(v_u_2421);
  heff_clo_take(self, 1);
  return v_a_242;
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_lam0, 1, 0};
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam1(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_lam1, 1, 0};
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam2(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_lam2, 1, 0};
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam3(V self, V *args);
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam4(V self, V *args);
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam5(V self, V *args);
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam6(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_lam6, 1, 0};
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam7(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_lam7, 1, 0};
Clo g_heff_2eelab_2evalue_2edecodeNeuOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_entry, 5, 0};

V g_heff_2eelab_2evalue_2edecodeNeuOf(V v_h_240, V v_sp_241, V v_ty_242, V v_expansion_243, V v_desc_244) {
top: ;
  V v_x1_245 = heff_tr(heff_call(heff_dup(v_ty_242), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2428;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_VU: {
    heff_take_n(v_x1_245, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_247 = heff_field(v_x1_245, 0);
    heff_take_n(v_x1_245, 1ULL, 5);
    switch (heff_tag_of(v_h_247)) {
    case TAG_HLocal: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_247, 0ULL, 1);
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_247);
    }
    break;
  }
  case TAG_VFunction: {
    heff_take_n(v_x1_245, 0ULL, 6);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    heff_take_n(v_x1_245, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x1_245, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    heff_take_n(v_x1_245, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_h_240);
    heff_drop(v_sp_241);
    heff_drop(v_ty_242);
    heff_drop(v_expansion_243);
    heff_drop(v_desc_244);
    heff_drop(v_t_2428);
    return heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_lam0_clo), ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_lam1_clo)});
  } else {
    heff_drop(v_t_2428);
    V v_x1_2431 = heff_tr(heff_call(heff_dup(v_ty_242), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_u_2451;
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_VU: {
      V v_u_2432 = heff_field(v_x1_2431, 0);
      heff_take_n(v_x1_2431, 1ULL, 1);
      v_u_2451 = v_u_2432;
      break;
    }
    case TAG_VDecode: {
      heff_take_n(v_x1_2431, 0ULL, 5);
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VFunction: {
      heff_take_n(v_x1_2431, 0ULL, 6);
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VRecord: {
      heff_take_n(v_x1_2431, 0ULL, 4);
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VSum: {
      heff_take_n(v_x1_2431, 0ULL, 1);
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VPrimInt: {
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VPrimFloat: {
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VPrimString: {
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VPrimRune: {
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VPrimArray: {
      heff_take_n(v_x1_2431, 0ULL, 1);
      v_u_2451 = heff_abandon();
      break;
    }
    case TAG_VFixed: {
      heff_take_n(v_x1_2431, 0ULL, 1);
      v_u_2451 = heff_abandon();
      break;
    }
    default: heff_nomatch(v_x1_2431);
    }
    V v_x2_2452 = heff_tr(heff_call(heff_dup(v_desc_244), 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_Nothing: {
      return heff_tag_n(TAG_VDecode, 5, (V[]){heff_dup(v_h_240), heff_dup(v_sp_241), v_u_2451, ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_lam2_clo), heff_clo_n(g_heff_2eelab_2evalue_2edecodeNeuOf_lam3, 1, 5, (V[]){v_h_240, v_sp_241, v_ty_242, v_expansion_243, v_desc_244})});
    }
    case TAG_Just: {
      V v_x_2455 = heff_field(v_x2_2452, 0);
      heff_take_n(v_x2_2452, 1ULL, 1);
      switch (heff_tag_of(v_x_2455)) {
      case TAG_VNeu: {
        heff_take_n(v_x_2455, 0ULL, 5);
        heff_drop(v_h_240);
        heff_drop(v_sp_241);
        heff_drop(v_ty_242);
        heff_drop(v_expansion_243);
        heff_drop(v_desc_244);
        heff_drop(v_u_2451);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2461 = heff_field(v_x_2455, 0);
        heff_take_n(v_x_2455, 1ULL, 1);
        return heff_tag_n(TAG_VDecode, 5, (V[]){heff_dup(v_h_240), heff_dup(v_sp_241), v_u_2451, heff_clo_n(g_heff_2eelab_2evalue_2edecodeNeuOf_lam4, 1, 1, (V[]){v_a_2461}), heff_clo_n(g_heff_2eelab_2evalue_2edecodeNeuOf_lam5, 1, 5, (V[]){v_h_240, v_sp_241, v_ty_242, v_expansion_243, v_desc_244})});
      }
      case TAG_VLam: {
        heff_take_n(v_x_2455, 0ULL, 2);
        heff_drop(v_h_240);
        heff_drop(v_sp_241);
        heff_drop(v_ty_242);
        heff_drop(v_expansion_243);
        heff_drop(v_desc_244);
        heff_drop(v_u_2451);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_2455, 0ULL, 1);
        heff_drop(v_h_240);
        heff_drop(v_sp_241);
        heff_drop(v_ty_242);
        heff_drop(v_expansion_243);
        heff_drop(v_desc_244);
        heff_drop(v_u_2451);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop(v_h_240);
        heff_drop(v_sp_241);
        heff_drop(v_ty_242);
        heff_drop(v_expansion_243);
        heff_drop(v_desc_244);
        heff_drop(v_u_2451);
        V v_t_2469 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_lam6_clo), ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_lam7_clo)});
        return v_t_2469;
      }
      default: return heff_nomatch(v_x_2455);
      }
    }
    default: return heff_nomatch(v_x2_2452);
    }
  }
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2edecodeNeuOf(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  heff_drop(v_x_2429);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  heff_drop(v_x_2430);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam2(V self, V *args) {
  V v_x_2453 = args[0];
  heff_drop(v_x_2453);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam3(V self, V *args) {
  V v_x_2454 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_expansion_243 = heff_env(self)[3];
  V v_desc_244 = heff_env(self)[4];
  heff_drop(v_x_2454);
  heff_clo_take(self, 5);
  return heff_tag_n(TAG_VNeu, 5, (V[]){v_h_240, v_sp_241, v_ty_242, v_expansion_243, v_desc_244});
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam4(V self, V *args) {
  V v_x_2462 = args[0];
  V v_a_2461 = heff_env(self)[0];
  heff_drop(v_x_2462);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Just, 1, (V[]){v_a_2461});
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_expansion_243 = heff_env(self)[3];
  V v_desc_244 = heff_env(self)[4];
  heff_drop(v_x_2463);
  heff_clo_take(self, 5);
  return heff_tag_n(TAG_VNeu, 5, (V[]){v_h_240, v_sp_241, v_ty_242, v_expansion_243, v_desc_244});
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam6(V self, V *args) {
  V v_x_2467 = args[0];
  heff_drop(v_x_2467);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_lam7(V self, V *args) {
  V v_x_2468 = args[0];
  heff_drop(v_x_2468);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam0, 1, 0};
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam1(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam1, 1, 0};
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam2(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam2, 1, 0};
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam3(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam3, 1, 0};
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam4(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam4, 1, 0};
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam5(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam5, 1, 0};

HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nom: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_t_2413;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VNeu: {
      V v_h_242 = heff_field(v_x_241, 0);
      V v_sp_243 = heff_field(v_x_241, 1);
      V v_ty_244 = heff_field(v_x_241, 2);
      V v_expansion_245 = heff_field(v_x_241, 3);
      V v_desc_246 = heff_field(v_x_241, 4);
      v_t_2413 = (g_heff_2eelab_2evalue_2edecodeNeuOf(heff_dup(v_h_242), heff_dup(v_sp_243), heff_dup(v_ty_244), heff_dup(v_expansion_245), heff_dup(v_desc_246)));
      break;
    }
    case TAG_VCode: {
      V v_a_247 = heff_field(v_x_241, 0);
      v_t_2413 = heff_dup(v_a_247);
      break;
    }
    case TAG_VLam: {
      v_t_2413 = heff_abandon();
      break;
    }
    case TAG_VCons: {
      v_t_2413 = heff_abandon();
      break;
    }
    case TAG_VOpaque: {
      v_t_2413 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam0_clo), ((V)&g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam1_clo)});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2413}});
  }
  case TAG_Describe: {
    V v_x_2414 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x_2414)) {
    case TAG_VNeu: {
      return ((HeffT2){{heff_abandon()}});
    }
    case TAG_VCode: {
      V v_a_2420 = heff_field(v_x_2414, 0);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_dup(v_a_2420)}});
    }
    case TAG_VLam: {
      return ((HeffT2){{heff_abandon()}});
    }
    case TAG_VCons: {
      return ((HeffT2){{heff_abandon()}});
    }
    case TAG_VOpaque: {
      V v_t_2426 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam2_clo), ((V)&g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam3_clo)});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2426}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x_2414)}});
    }
  }
  case TAG_Become: {
    V v_x_2427 = heff_field(v_x1_240, 0);
    V v_t_2439;
    switch (heff_tag_of(v_x_2427)) {
    case TAG_VNeu: {
      V v_h_2428 = heff_field(v_x_2427, 0);
      V v_sp_2429 = heff_field(v_x_2427, 1);
      V v_ty_2430 = heff_field(v_x_2427, 2);
      V v_expansion_2431 = heff_field(v_x_2427, 3);
      V v_desc_2432 = heff_field(v_x_2427, 4);
      v_t_2439 = (g_heff_2eelab_2evalue_2edecodeNeuOf(heff_dup(v_h_2428), heff_dup(v_sp_2429), heff_dup(v_ty_2430), heff_dup(v_expansion_2431), heff_dup(v_desc_2432)));
      break;
    }
    case TAG_VCode: {
      V v_a_2433 = heff_field(v_x_2427, 0);
      v_t_2439 = heff_dup(v_a_2433);
      break;
    }
    case TAG_VLam: {
      v_t_2439 = heff_abandon();
      break;
    }
    case TAG_VCons: {
      v_t_2439 = heff_abandon();
      break;
    }
    case TAG_VOpaque: {
      v_t_2439 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam4_clo), ((V)&g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam5_clo)});
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2439}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  heff_drop(v_x_2411);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  heff_drop(v_x_2412);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  heff_drop(v_x_2424);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  heff_drop(v_x_2425);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  heff_drop(v_x_2437);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeEv_24cpr_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  heff_drop(v_x_2438);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2evalue_2especialize_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2especialize_lam0(V self, V *args);
Clo g_heff_2eelab_2evalue_2especialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2especialize_entry, 3, 0};

V g_heff_2eelab_2evalue_2especialize(V v_v_240, V v_x_241, V v_f_242) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_v_240, 0);
    V v_sp_244 = heff_field(v_v_240, 1);
    V v_ty_245 = heff_field(v_v_240, 2);
    V v_expansion_246 = heff_field(v_v_240, 3);
    V v_desc_247 = heff_field(v_v_240, 4);
    V v_ru_24v_240_24VNeu = heff_take_reuse_n(v_v_240, 31ULL, 5);
    V v_it_248 = heff_tr(heff_call(v_desc_247, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_it_248)) {
    case TAG_Nothing: {
      heff_drop(v_x_241);
      heff_drop(v_f_242);
      heff_drop(v_h_243);
      heff_drop(v_sp_244);
      heff_drop(v_ty_245);
      heff_drop(v_expansion_246);
      heff_drop_cell(v_ru_24v_240_24VNeu, 5);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_it1_249 = heff_field(v_it_248, 0);
      heff_take_n(v_it_248, 1ULL, 1);
      switch (heff_tag_of(v_it1_249)) {
      case TAG_VNeu: {
        heff_take_n(v_it1_249, 0ULL, 5);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_it11_2415 = heff_field(v_it1_249, 0);
        heff_take_n(v_it1_249, 1ULL, 1);
        switch (heff_tag_of(v_it11_2415)) {
        case TAG_VU: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VDecode: {
          heff_take_n(v_it11_2415, 0ULL, 5);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VFunction: {
          heff_take_n(v_it11_2415, 0ULL, 6);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VRecord: {
          V v_level_2428 = heff_field(v_it11_2415, 0);
          V v_capture_2429 = heff_field(v_it11_2415, 1);
          V v_fieldTypes_2430 = heff_field(v_it11_2415, 2);
          V v_defaults_2431 = heff_field(v_it11_2415, 3);
          heff_take_n(v_it11_2415, 15ULL, 4);
          return heff_tag_re_n(v_ru_24v_240_24VNeu, TAG_VNeu, 5, 13ULL, (V[]){v_h_243, heff_tag_n(TAG_SpSpec, 3, (V[]){v_sp_244, heff_dup(v_x_241), heff_dup(v_f_242)}), v_ty_245, v_expansion_246, heff_clo_n(g_heff_2eelab_2evalue_2especialize_lam0, 1, 6, (V[]){v_fieldTypes_2430, v_x_241, v_f_242, v_level_2428, v_capture_2429, v_defaults_2431})});
        }
        case TAG_VSum: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimInt: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimFloat: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimString: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimRune: {
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimArray: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VFixed: {
          heff_take_n(v_it11_2415, 0ULL, 1);
          heff_drop(v_x_241);
          heff_drop(v_f_242);
          heff_drop(v_h_243);
          heff_drop(v_sp_244);
          heff_drop(v_ty_245);
          heff_drop(v_expansion_246);
          heff_drop_cell(v_ru_24v_240_24VNeu, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_it11_2415);
        }
      }
      case TAG_VLam: {
        heff_take_n(v_it1_249, 0ULL, 2);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_it1_249, 0ULL, 1);
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop(v_x_241);
        heff_drop(v_f_242);
        heff_drop(v_h_243);
        heff_drop(v_sp_244);
        heff_drop(v_ty_245);
        heff_drop(v_expansion_246);
        heff_drop_cell(v_ru_24v_240_24VNeu, 5);
        return heff_abandon();
      }
      default: return heff_nomatch(v_it1_249);
      }
    }
    default: return heff_nomatch(v_it_248);
    }
  }
  case TAG_VCode: {
    heff_take_n(v_v_240, 0ULL, 1);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VLam: {
    heff_take_n(v_v_240, 0ULL, 2);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VCons: {
    heff_take_n(v_v_240, 0ULL, 1);
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    heff_drop(v_x_241);
    heff_drop(v_f_242);
    return NTAG(TAG_VOpaque);
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2especialize(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2especialize_lam1(V self, V *args) {
  V v_field_2435 = args[0];
  V v_vs_2436 = args[1];
  V v_f_242 = heff_env(self)[0];
  V v_t_2437 = heff_tr(heff_call(v_field_2435, 1, (V[]){v_vs_2436}));
  switch (heff_tag_of(v_t_2437)) {
  case TAG_MkField: {
    V v_ty_2438 = heff_field(v_t_2437, 0);
    V v_ru_24t_2437_24MkField = heff_take_reuse_n(v_t_2437, 1ULL, 2);
    heff_clo_take(self, 1);
    return heff_tag_re_n(v_ru_24t_2437_24MkField, TAG_MkField, 2, 1ULL, (V[]){v_ty_2438, heff_tag_n(TAG_Just, 1, (V[]){v_f_242})});
  }
  default: return heff_nomatch(v_t_2437);
  }
}
V g_heff_2eelab_2evalue_2especialize_lam0(V self, V *args) {
  V v_u_2432 = args[0];
  V v_fieldTypes_2430 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_level_2428 = heff_env(self)[3];
  V v_capture_2429 = heff_env(self)[4];
  V v_defaults_2431 = heff_env(self)[5];
  heff_drop(v_u_2432);
  heff_clo_take(self, 6);
  V v_d_2433 = v_fieldTypes_2430;
  V v_x_2434 = v_x_241;
  V v_f_2440 = heff_clo_n(g_heff_2eelab_2evalue_2especialize_lam1, 2, 1, (V[]){v_f_242});
  HeffT2 v_t_2441 = ({ V a_0 = heff_rfield(v_d_2433, 1); V a_1 = v_x_2434; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_2434); r_; });
  {
    V v_field_2443 = v_t_2441.f[1];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    V v_t_2449;
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      V v_i_2444 = v_field_2443;
      V v_xs_2445 = heff_dup(heff_rfield(v_d_2433, 2));
      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2444, 1) && heff_intLt_c_lent(v_i_2444, heff_arrayLength_lent(v_xs_2445, 0), 2))) {
        V v_v_2446 = heff_arrayIndex_lent(v_xs_2445, v_i_2444, 1);
        V v_t_2447 = heff_tr(heff_call(v_f_2440, 1, (V[]){v_v_2446}));
        V v_t_2448 = heff_arraySet(heff_take_field(v_d_2433, 2), v_i_2444, v_t_2447);
        v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_d_2433, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      } else {
        heff_drop_clo(v_f_2440, 1);
        heff_drop(v_i_2444);
        heff_drop(v_xs_2445);
        v_t_2449 = v_d_2433;
      }
    } else {
      heff_drop_clo(v_f_2440, 1);
      heff_drop(v_field_2443);
      v_t_2449 = v_d_2433;
    }
    V v_t_2450 = heff_tag_n(TAG_VCode, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2428, v_capture_2429, v_t_2449, v_defaults_2431})});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2450});
  }
}
Clo g_heff_2eelab_2evalue_2especializations_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2especializations_entry, 2, 0};

V g_heff_2eelab_2evalue_2especializations(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return v_acc_241;
  }
  case TAG_SpApp: {
    return v_acc_241;
  }
  case TAG_SpProj: {
    return v_acc_241;
  }
  case TAG_SpSpec: {
    V v_sp_246 = heff_field(v_x1_240, 0);
    V v_x_247 = heff_field(v_x1_240, 1);
    V v_f_248 = heff_field(v_x1_240, 2);
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_247), heff_dup(v_f_248)}), v_acc_241});
    V t_0 = v_sp_246;
    V t_1 = v_t_249;
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2especializations_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2especializations(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2edefaultsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edefaultsOf_entry, 1, 0};

V g_heff_2eelab_2evalue_2edefaultsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VDecode: {
    V v_described_245 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 5);
    V v_t_247 = heff_tr(heff_call(v_described_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return heff_dup(g_heff_2eutil_2edict_2eempty_get());
    }
    case TAG_Just: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V t_0 = v_t_248;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VFunction: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VRecord: {
    V v_defaults_2418 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_defaults_2418;
  }
  case TAG_VSum: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimInt: {
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimFloat: {
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimString: {
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimRune: {
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  case TAG_VFixed: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return heff_dup(g_heff_2eutil_2edict_2eempty_get());
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2edefaultsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2edefaultsOf(a[0]);
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam2(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam3(V self, V *args);
Clo g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_entry, 2, 0};

V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(V v_lit_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_f_241, 0);
    V v_sp_243 = heff_field(v_f_241, 1);
    V v_ty_244 = heff_field(v_f_241, 2);
    V v_desc_246 = heff_field(v_f_241, 4);
    heff_take_n(v_f_241, 23ULL, 5);
    V v_x2_247 = heff_tr(heff_call(v_desc_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_ru_24x2_247_24Just = heff_take_reuse_n(v_x2_247, 1ULL, 1);
      V v_t_249 = heff_tr(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(v_lit_240, v_x_248));
      v_t_2410 = heff_tag_at_n(v_ru_24x2_247_24Just, TAG_Just, 1, (V[]){v_t_249});
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2415 = (g_heff_2eelab_2evalue_2ereflect(heff_dup(v_h_242), heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam0, 1, 2, (V[]){v_sp_243, heff_dup(v_lit_240)}), heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam1, 1, 3, (V[]){v_ty_244, v_h_242, heff_dup(v_lit_240)}), v_t_2410));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2415});
  }
  case TAG_VCode: {
    heff_take_n(v_f_241, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_VLam: {
    V v_clo_2418 = heff_field(v_f_241, 1);
    heff_take_n(v_f_241, 2ULL, 2);
    switch (heff_tag_of(v_clo_2418)) {
    case TAG_MkClo: {
      V v_vs_2420 = heff_field(v_clo_2418, 1);
      V v_body_2421 = heff_field(v_clo_2418, 2);
      heff_take_n(v_clo_2418, 6ULL, 3);
      return heff_tail(v_body_2421, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam3, 1, 1, (V[]){heff_dup(v_lit_240)})})});
    }
    case TAG_CloConst: {
      V v_body_2423 = heff_field(v_clo_2418, 0);
      heff_take_n(v_clo_2418, 1ULL, 1);
      return v_body_2423;
    }
    default: return heff_nomatch(v_clo_2418);
    }
  }
  case TAG_VCons: {
    heff_take_n(v_f_241, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  heff_drop(v_u_2411);
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_243, v_lit_240});
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam2(V self, V *args) {
  V v_a_2414 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_a_2414);
  heff_clo_take(self, 1);
  return v_lit_240;
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  heff_drop(v_u_2412);
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tr(heff_call(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_2413; V a_2 = heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam2, 1, 1, (V[]){v_lit_240}); V r_ = (g_heff_2eelab_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_lam3(V self, V *args) {
  V v_a_2422 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_a_2422);
  heff_clo_take(self, 1);
  return v_lit_240;
}
Clo g_heff_2eelab_2evalue_2eforceEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eforceEl_entry, 2, 0};

V g_heff_2eelab_2evalue_2eforceEl(V v_mc_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VNeu: {
    V v_v1_242 = heff_dup(heff_field(v_v_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_v_241, 1));
    switch (heff_tag_of(v_v1_242)) {
    case TAG_HLocal: {
      heff_take_n(v_v1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return v_v_241;
    }
    case TAG_HGlobal: {
      heff_take_n(v_v1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      return v_v_241;
    }
    case TAG_HMeta: {
      V v_m_249 = heff_field(v_v1_242, 0);
      heff_take_n(v_v1_242, 1ULL, 1);
      HeffT2 v_t_2410 = ({ V a_0 = v_mc_240; V a_1 = v_m_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_m_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_e_2413 = v_field_2412;
          V v_t_2414 = heff_get_n(v_e_2413, 1, 6);
          switch (heff_tag_of(v_t_2414)) {
          case TAG_Nothing: {
            heff_drop(v_sp_243);
            return v_v_241;
          }
          case TAG_Just: {
            V v_sol_2415 = heff_field(v_t_2414, 0);
            heff_take_n(v_t_2414, 1ULL, 1);
            heff_drop_tag(v_v_241, 5);
            V v_t_2416 = ({ V a_0 = v_sol_2415; V a_1 = v_sp_243; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sol_2415); heff_drop(v_sp_243); r_; });
            V t_0 = v_mc_240;
            V t_1 = v_t_2416;
            v_mc_240 = t_0;
            v_v_241 = t_1;
            goto top;
          }
          default: return heff_nomatch(v_t_2414);
          }
        } else {
          heff_drop(v_sp_243);
          heff_drop(v_field_2412);
          return v_v_241;
        }
      }
    }
    case TAG_HError: {
      heff_drop(v_sp_243);
      return v_v_241;
    }
    default: return heff_nomatch(v_v1_242);
    }
  }
  case TAG_VCode: {
    return v_v_241;
  }
  case TAG_VLam: {
    return v_v_241;
  }
  case TAG_VCons: {
    return v_v_241;
  }
  case TAG_VOpaque: {
    return v_v_241;
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eforceEl(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2eforceTy_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2eforceTy_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eforceTy_lam0, 1, 0};
V g_heff_2eelab_2evalue_2eforceTy_lam1(V self, V *args); static Clo g_heff_2eelab_2evalue_2eforceTy_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eforceTy_lam1, 1, 0};
Clo g_heff_2eelab_2evalue_2eforceTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eforceTy_entry, 2, 0};

V g_heff_2eelab_2evalue_2eforceTy(V v_mc_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_VU: {
    return v_t_241;
  }
  case TAG_VDecode: {
    V v_t1_243 = heff_dup(heff_field(v_t_241, 0));
    V v_sp_244 = heff_dup(heff_field(v_t_241, 1));
    switch (heff_tag_of(v_t1_243)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      return v_t_241;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_243, 0ULL, 1);
      heff_drop(v_sp_244);
      return v_t_241;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_t1_243, 0);
      heff_take_n(v_t1_243, 1ULL, 1);
      HeffT2 v_t_2411 = ({ V a_0 = v_mc_240; V a_1 = v_m_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_m_2410); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_e_2414 = v_field_2413;
          V v_t_2415 = heff_get_n(v_e_2414, 1, 6);
          switch (heff_tag_of(v_t_2415)) {
          case TAG_Nothing: {
            heff_drop(v_sp_244);
            return v_t_241;
          }
          case TAG_Just: {
            V v_sol_2416 = heff_field(v_t_2415, 0);
            heff_take_n(v_t_2415, 1ULL, 1);
            heff_drop_tag(v_t_241, 5);
            V v_t_2417 = ({ V a_0 = v_sol_2416; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sol_2416); heff_drop(v_sp_244); r_; });
            V v_x1_2418 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_t_2417));
            V v_t_2430;
            switch (heff_tag_of(v_x1_2418)) {
            case TAG_VNeu: {
              V v_h_2419 = heff_field(v_x1_2418, 0);
              V v_sp_2420 = heff_field(v_x1_2418, 1);
              V v_ty_2421 = heff_field(v_x1_2418, 2);
              V v_expansion_2422 = heff_field(v_x1_2418, 3);
              V v_desc_2423 = heff_field(v_x1_2418, 4);
              V v_ru_24x1_2418_24VNeu = heff_take_reuse_n(v_x1_2418, 31ULL, 5);
              v_t_2430 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24x1_2418_24VNeu, v_h_2419, v_sp_2420, v_ty_2421, v_expansion_2422, v_desc_2423));
              break;
            }
            case TAG_VCode: {
              V v_a_2424 = heff_field(v_x1_2418, 0);
              heff_take_n(v_x1_2418, 1ULL, 1);
              v_t_2430 = v_a_2424;
              break;
            }
            case TAG_VLam: {
              heff_take_n(v_x1_2418, 0ULL, 2);
              v_t_2430 = heff_abandon();
              break;
            }
            case TAG_VCons: {
              heff_take_n(v_x1_2418, 0ULL, 1);
              v_t_2430 = heff_abandon();
              break;
            }
            case TAG_VOpaque: {
              v_t_2430 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2eforceTy_lam0_clo), ((V)&g_heff_2eelab_2evalue_2eforceTy_lam1_clo)});
              break;
            }
            default: heff_nomatch(v_x1_2418);
            }
            V t_0 = v_mc_240;
            V t_1 = v_t_2430;
            v_mc_240 = t_0;
            v_t_241 = t_1;
            goto top;
          }
          default: return heff_nomatch(v_t_2415);
          }
        } else {
          heff_drop(v_sp_244);
          heff_drop(v_field_2413);
          return v_t_241;
        }
      }
    }
    case TAG_HError: {
      heff_drop(v_sp_244);
      return v_t_241;
    }
    default: return heff_nomatch(v_t1_243);
    }
  }
  case TAG_VFunction: {
    return v_t_241;
  }
  case TAG_VRecord: {
    return v_t_241;
  }
  case TAG_VSum: {
    return v_t_241;
  }
  case TAG_VPrimInt: {
    return v_t_241;
  }
  case TAG_VPrimFloat: {
    return v_t_241;
  }
  case TAG_VPrimString: {
    return v_t_241;
  }
  case TAG_VPrimRune: {
    return v_t_241;
  }
  case TAG_VPrimArray: {
    return v_t_241;
  }
  case TAG_VFixed: {
    return v_t_241;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eforceTy(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2eforceTy_lam0(V self, V *args) {
  V v_x_2428 = args[0];
  heff_drop(v_x_2428);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2eforceTy_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  heff_drop(v_x_2429);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2evalue_2etypeForProjection_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2etypeForProjection_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2etypeForProjection_lam0, 1, 0};
Clo g_heff_2eelab_2evalue_2etypeForProjection_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2etypeForProjection_entry, 4, 0};

V g_heff_2eelab_2evalue_2etypeForProjection(V v_capture_240, V v_fieldTypes_241, V v_x_242, V v_fields_243) {
top: ;
  V v_byName_244 = heff_take_field(v_fieldTypes_241, 1);
  V v_values_245 = heff_get_n(v_fieldTypes_241, 2, 3);
  HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_byName_244, v_x_242));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_i_2410;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_i_249 = v_field_248;
      v_i_2410 = v_i_249;
    } else {
      heff_drop(v_field_248);
      v_i_2410 = heff_abandon();
    }
    V v_xs_2411 = v_values_245;
    V v_t_2413;
    if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2410, 1) && heff_intLt_c_lent(v_i_2410, heff_arrayLength_lent(v_xs_2411, 0), 2))) {
      V v_v_2412 = heff_arrayIndex(v_xs_2411, v_i_2410);
      v_t_2413 = v_v_2412;
    } else {
      heff_drop(v_i_2410);
      heff_drop(v_xs_2411);
      v_t_2413 = heff_abandon();
    }
    HeffT2 v_t_2414 = ({ V a_0 = v_byName_244; V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_244); r_; });
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      V v_m_2418;
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        V v_i_2417 = v_field_2416;
        v_m_2418 = v_i_2417;
      } else {
        heff_drop(v_field_2416);
        v_m_2418 = heff_abandon();
      }
      V v_t_2423;
      if (heff_intLe_c_lent(v_m_2418, MK_INT(0LL), 2)) {
        heff_drop_rec(v_fields_243, 3);
        v_t_2423 = heff_arrayGenerate(v_m_2418, ((V)&g_heff_2eelab_2evalue_2etypeForProjection_lam0_clo));
      } else {
        V v_xs_2420 = heff_dup(heff_rfield(v_fields_243, 2));
        V v_y_2422;
        if (((((int64_t)0ULL) <= ((int64_t)0ULL)) && (((int64_t)0ULL) < heff_unbox_word(heff_arrayLength_lent(v_xs_2420, 0))))) {
          V v_v_2421 = heff_arrayIndexIn(v_xs_2420, MK_INT(0LL));
          v_y_2422 = v_v_2421;
        } else {
          heff_drop(v_xs_2420);
          v_y_2422 = heff_abandon();
        }
        v_t_2423 = ({ V a_0 = v_fields_243; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2418, v_y_2422); V r_ = (g_heff_2eelab_2evalue_2etypeForProjection_24generate0(a_0, a_1, a_2)); heff_drop_rec(v_fields_243, 3); r_; });
      }
      return heff_tail(v_t_2413, 1, (V[]){heff_tag_n(TAG_LChunkSnoc, 2, (V[]){v_capture_240, v_t_2423})});
    }
  }
}
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2evalue_2etypeForProjection(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2eelab_2evalue_2etypeForProjection_lam0(V self, V *args) {
  V v_u_2419 = args[0];
  heff_drop(v_u_2419);
  return heff_abandon();
}
Clo g_heff_2eelab_2evalue_2etypeForProjection_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2etypeForProjection_24generate0_entry, 3, 0};

V g_heff_2eelab_2evalue_2etypeForProjection_24generate0(V v_fields_240, V v_box_24j_241, V v_a_242) {
  int64_t v_j_241 = heff_unbox_word(v_box_24j_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_j_241)) {
    top_TAG_InRange: ;
    if ((v_j_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_xs_243 = heff_dup(heff_rfield(v_fields_240, 2));
      V v_t_245;
      if (((((int64_t)0ULL) <= v_j_241) && (v_j_241 < heff_unbox_word(heff_arrayLength_lent(v_xs_243, 0))))) {
        V v_v_244 = heff_arrayIndexIn(v_xs_243, heff_box_word(v_j_241));
        v_t_245 = v_v_244;
      } else {
        heff_drop(v_xs_243);
        v_t_245 = heff_abandon();
      }
      V t_0 = v_fields_240;
      int64_t t_1 = (v_j_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_j_241), v_t_245);
      v_fields_240 = t_0;
      v_j_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_j_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_xs_243 = heff_dup(heff_rfield(v_fields_240, 2));
    V v_t_245;
    if (((((int64_t)0ULL) <= v_j_241) && (v_j_241 < heff_unbox_word(heff_arrayLength_lent(v_xs_243, 0))))) {
      V v_v_244 = heff_arrayIndexIn(v_xs_243, heff_box_word(v_j_241));
      v_t_245 = v_v_244;
    } else {
      heff_drop(v_xs_243);
      v_t_245 = heff_abandon();
    }
    V t_0 = v_fields_240;
    int64_t t_1 = (v_j_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_j_241), v_t_245);
    v_fields_240 = t_0;
    v_j_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2evalue_2etypeForProjection_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2etypeForProjection_24generate0(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_entry, 1, 0};

V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nom: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24Nom = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2421;
    switch (heff_tag_of(v_x_241)) {
    case TAG_VU: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VDecode: {
      V v_a_247 = heff_field(v_x_241, 4);
      heff_take_n(v_x_241, 16ULL, 5);
      v_t_2421 = heff_tr(heff_call(v_a_247, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VRecord: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VSum: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimString: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    case TAG_VFixed: {
      v_t_2421 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_241});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Nom, TAG_Nom, 1, (V[]){v_t_2421});
  }
  case TAG_Describe: {
    V v_x_2422 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24Describe = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2442;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_VU: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VDecode: {
      V v_a_2428 = heff_field(v_x_2422, 4);
      heff_take_n(v_x_2422, 16ULL, 5);
      v_t_2442 = heff_tr(heff_call(v_a_2428, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VRecord: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VSum: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VPrimString: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_VFixed: {
      v_t_2442 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2422});
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Describe, TAG_Describe, 1, (V[]){v_t_2442});
  }
  case TAG_Become: {
    V v_x_2443 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24Become = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2463;
    switch (heff_tag_of(v_x_2443)) {
    case TAG_VU: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VDecode: {
      V v_a_2449 = heff_field(v_x_2443, 4);
      heff_take_n(v_x_2443, 16ULL, 5);
      v_t_2463 = heff_tr(heff_call(v_a_2449, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VRecord: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VSum: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VPrimString: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    case TAG_VFixed: {
      v_t_2463 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2443});
      break;
    }
    default: heff_nomatch(v_x_2443);
    }
    return heff_tag_at_n(v_ru_24x2_240_24Become, TAG_Become, 1, (V[]){v_t_2463});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(a[0]);
}
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam2(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam3(V self, V *args);
Clo g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_entry, 2, 0};

V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(V v_lit_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_f_241, 0);
    V v_sp_243 = heff_field(v_f_241, 1);
    V v_ty_244 = heff_field(v_f_241, 2);
    V v_desc_246 = heff_field(v_f_241, 4);
    heff_take_n(v_f_241, 23ULL, 5);
    V v_x2_247 = heff_tr(heff_call(v_desc_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_ru_24x2_247_24Just = heff_take_reuse_n(v_x2_247, 1ULL, 1);
      V v_t_249 = heff_tr(g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(v_lit_240, v_x_248));
      v_t_2410 = heff_tag_at_n(v_ru_24x2_247_24Just, TAG_Just, 1, (V[]){v_t_249});
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2415 = (g_heff_2eelab_2evalue_2ereflect(heff_dup(v_h_242), heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam0, 1, 2, (V[]){v_sp_243, heff_dup(v_lit_240)}), heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam1, 1, 3, (V[]){v_ty_244, v_h_242, heff_dup(v_lit_240)}), v_t_2410));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2415});
  }
  case TAG_VCode: {
    heff_take_n(v_f_241, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_VLam: {
    V v_clo_2418 = heff_field(v_f_241, 1);
    heff_take_n(v_f_241, 2ULL, 2);
    switch (heff_tag_of(v_clo_2418)) {
    case TAG_MkClo: {
      V v_vs_2420 = heff_field(v_clo_2418, 1);
      V v_body_2421 = heff_field(v_clo_2418, 2);
      heff_take_n(v_clo_2418, 6ULL, 3);
      return heff_tail(v_body_2421, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam3, 1, 1, (V[]){heff_dup(v_lit_240)})})});
    }
    case TAG_CloConst: {
      V v_body_2423 = heff_field(v_clo_2418, 0);
      heff_take_n(v_clo_2418, 1ULL, 1);
      return v_body_2423;
    }
    default: return heff_nomatch(v_clo_2418);
    }
  }
  case TAG_VCons: {
    heff_take_n(v_f_241, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eapp_24s435923339x187529784(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_sp_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  heff_drop(v_u_2411);
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_243, heff_get_n(v_lit_240, 1, 2)});
}
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam2(V self, V *args) {
  V v_a_2414 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_a_2414);
  heff_clo_take(self, 1);
  return heff_get_n(v_lit_240, 1, 2);
}
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  heff_drop(v_u_2412);
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tr(heff_call(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_2413; V a_2 = heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam2, 1, 1, (V[]){v_lit_240}); V r_ = (g_heff_2eelab_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2eelab_2evalue_2eapp_24s435923339x187529784_lam3(V self, V *args) {
  V v_a_2422 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_a_2422);
  heff_clo_take(self, 1);
  return heff_get_n(v_lit_240, 1, 2);
}
V g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_lam0, 1, 0};
Clo g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_entry, 1, 0};

V g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071(V v_t_240) {
top: ;
  V v_t_241 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_LikeU: {
    heff_take_n(v_t_241, 0ULL, 1);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_244 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_244)) {
      case TAG_HLocal: {
        heff_take_n(v_h_244, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_244, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_244, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_244);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeFunction: {
    V v_cod_2442 = heff_field(v_t_241, 2);
    heff_take_n(v_t_241, 4ULL, 4);
    heff_drop(v_t_240);
    V v_x1_2449;
    switch (heff_tag_of(v_cod_2442)) {
    case TAG_MkClo: {
      V v_vs_2445 = heff_field(v_cod_2442, 1);
      V v_body_2446 = heff_field(v_cod_2442, 2);
      heff_take_n(v_cod_2442, 6ULL, 3);
      v_x1_2449 = heff_tr(heff_call(v_body_2446, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2445, ((V)&g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_lam0_clo)})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2448 = heff_field(v_cod_2442, 0);
      heff_take_n(v_cod_2442, 1ULL, 1);
      v_x1_2449 = v_body_2448;
      break;
    }
    default: heff_nomatch(v_cod_2442);
    }
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_Nom: {
      V v_x_2450 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      return v_x_2450;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2449, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_2452 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      return v_x_2452;
    }
    default: return heff_nomatch(v_x1_2449);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_241, 0ULL, 3);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_2457 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_2457)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2457, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2457, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2457, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_2457);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_241, 0ULL, 1);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_2495 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_2495)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2495, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2495, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2495, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_2495);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeInt: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24132 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24132)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24132, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24132, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24132, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24132);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeFloat: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24169 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24169)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24169, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24169, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24169, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24169);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeString: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24206 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24206)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24206, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24206, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24206, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24206);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeRune: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24243 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24243)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24243, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24243, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24243, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24243);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_241, 0ULL, 1);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24281 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24281)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24281, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24281, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24281, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24281);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_241, 0ULL, 1);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24319 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24319)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24319, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24319, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24319, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24319);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_NoRules: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24356 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24356)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24356, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24356, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24356, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24356);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071(a[0]);
}
V g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_lam0(V self, V *args) {
  V v_a_2447 = args[0];
  heff_drop(v_a_2447);
  return NTAG(TAG_VOpaque);
}
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam0, 1, 0};
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam1(V self, V *args); static Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam1, 1, 0};
Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry, 3, 0};

V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V v_h_240, V v_ty_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_240, NTAG(TAG_SpId), v_ty_241, NTAG(TAG_Nothing)));
  }
  case TAG_Just: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24Just = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_Nom: {
      V v_v_244 = heff_field(v_x41_243, 0);
      V v_ru_24x41_243_24Nom = heff_take_reuse_n(v_x41_243, 1ULL, 1);
      heff_drop(v_ty_241);
      switch (heff_tag_of(v_v_244)) {
      case TAG_VNeu: {
        heff_drop(v_h_240);
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop_cell(v_ru_24x41_243_24Nom, 1);
        return v_v_244;
      }
      case TAG_VCode: {
        V v_v1_2410 = heff_dup(heff_field(v_v_244, 0));
        switch (heff_tag_of(v_v1_2410)) {
        case TAG_VU: {
          heff_take_n(v_v1_2410, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2410, 0ULL, 5);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VFunction: {
          V v_level_2417 = heff_field(v_v1_2410, 0);
          V v_dom_2418 = heff_field(v_v1_2410, 1);
          V v_cod_2419 = heff_field(v_v1_2410, 2);
          V v_implicit_2420 = heff_field(v_v1_2410, 3);
          V v_dflt_2421 = heff_field(v_v1_2410, 4);
          V v_ru_24v1_2410_24VFunction = heff_take_reuse_n(v_v1_2410, 31ULL, 6);
          switch (heff_tag_of(v_v_244)) {
          case TAG_VCode: {
            heff_take_n(v_v_244, 0ULL, 1);
            V v_t_2425 = heff_tag_at_n(v_ru_24x4_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkFolded, 2, (V[]){v_h_240, ((V)&g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam0_clo)})});
            return heff_tag_at_n(v_ru_24x41_243_24Nom, TAG_VCode, 1, (V[]){heff_tag_re_n(v_ru_24v1_2410_24VFunction, TAG_VFunction, 6, 31ULL, (V[]){v_level_2417, v_dom_2418, v_cod_2419, v_implicit_2420, v_dflt_2421, v_t_2425})});
          }
          default: return heff_nomatch(v_v_244);
          }
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2410, 0ULL, 4);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2410, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VPrimInt: {
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VPrimFloat: {
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VPrimString: {
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VPrimRune: {
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2410, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2410, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Nom, 1);
          return v_v_244;
        }
        default: return heff_nomatch(v_v1_2410);
        }
      }
      case TAG_VLam: {
        heff_drop(v_h_240);
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop_cell(v_ru_24x41_243_24Nom, 1);
        return v_v_244;
      }
      case TAG_VCons: {
        heff_drop(v_h_240);
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop_cell(v_ru_24x41_243_24Nom, 1);
        return v_v_244;
      }
      case TAG_VOpaque: {
        heff_drop(v_h_240);
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop_cell(v_ru_24x41_243_24Nom, 1);
        return v_v_244;
      }
      default: return heff_nomatch(v_v_244);
      }
    }
    case TAG_Describe: {
      V v_desc_2436 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_240, NTAG(TAG_SpId), v_ty_241, heff_tag_at_n(v_ru_24x4_242_24Just, TAG_Just, 1, (V[]){v_desc_2436})));
    }
    case TAG_Become: {
      V v_v_2437 = heff_field(v_x41_243, 0);
      V v_ru_24x41_243_24Become = heff_take_reuse_n(v_x41_243, 1ULL, 1);
      heff_drop(v_ty_241);
      switch (heff_tag_of(v_v_2437)) {
      case TAG_VNeu: {
        heff_drop(v_h_240);
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop_cell(v_ru_24x41_243_24Become, 1);
        return v_v_2437;
      }
      case TAG_VCode: {
        V v_v1_2443 = heff_dup(heff_field(v_v_2437, 0));
        switch (heff_tag_of(v_v1_2443)) {
        case TAG_VU: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2443, 0ULL, 5);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VFunction: {
          V v_level_2450 = heff_field(v_v1_2443, 0);
          V v_dom_2451 = heff_field(v_v1_2443, 1);
          V v_cod_2452 = heff_field(v_v1_2443, 2);
          V v_implicit_2453 = heff_field(v_v1_2443, 3);
          V v_dflt_2454 = heff_field(v_v1_2443, 4);
          V v_ru_24v1_2443_24VFunction = heff_take_reuse_n(v_v1_2443, 31ULL, 6);
          switch (heff_tag_of(v_v_2437)) {
          case TAG_VCode: {
            heff_take_n(v_v_2437, 0ULL, 1);
            V v_t_2458 = heff_tag_at_n(v_ru_24x4_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkFolded, 2, (V[]){v_h_240, ((V)&g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam1_clo)})});
            return heff_tag_at_n(v_ru_24x41_243_24Become, TAG_VCode, 1, (V[]){heff_tag_re_n(v_ru_24v1_2443_24VFunction, TAG_VFunction, 6, 31ULL, (V[]){v_level_2450, v_dom_2451, v_cod_2452, v_implicit_2453, v_dflt_2454, v_t_2458})});
          }
          default: return heff_nomatch(v_v_2437);
          }
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2443, 0ULL, 4);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VPrimInt: {
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VPrimFloat: {
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VPrimString: {
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VPrimRune: {
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2443, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop_cell(v_ru_24x4_242_24Just, 1);
          heff_drop_cell(v_ru_24x41_243_24Become, 1);
          return v_v_2437;
        }
        default: return heff_nomatch(v_v1_2443);
        }
      }
      case TAG_VLam: {
        heff_drop(v_h_240);
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop_cell(v_ru_24x41_243_24Become, 1);
        return v_v_2437;
      }
      case TAG_VCons: {
        heff_drop(v_h_240);
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop_cell(v_ru_24x41_243_24Become, 1);
        return v_v_2437;
      }
      case TAG_VOpaque: {
        heff_drop(v_h_240);
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop_cell(v_ru_24x41_243_24Become, 1);
        return v_v_2437;
      }
      default: return heff_nomatch(v_v_2437);
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam0(V self, V *args) {
  V v_a_2424 = args[0];
  heff_drop(v_a_2424);
  return NTAG(TAG_SpId);
}
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_lam1(V self, V *args) {
  V v_a_2457 = args[0];
  heff_drop(v_a_2457);
  return NTAG(TAG_SpId);
}
Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_entry, 2, 0};

V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nom: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Nom = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2422;
    switch (heff_tag_of(v_x_242)) {
    case TAG_VU: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VDecode: {
      V v_a_248 = heff_field(v_x_242, 4);
      heff_take_n(v_x_242, 16ULL, 5);
      heff_drop_cell(v_tok_240, 1);
      v_t_2422 = heff_tr(heff_call(v_a_248, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VRecord: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VSum: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VPrimString: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    case TAG_VFixed: {
      v_t_2422 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_242});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_tag_at_n(v_ru_24x2_241_24Nom, TAG_Nom, 1, (V[]){v_t_2422});
  }
  case TAG_Describe: {
    V v_x_2423 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Describe = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2443;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_VU: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VDecode: {
      V v_a_2429 = heff_field(v_x_2423, 4);
      heff_take_n(v_x_2423, 16ULL, 5);
      heff_drop_cell(v_tok_240, 1);
      v_t_2443 = heff_tr(heff_call(v_a_2429, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VRecord: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VSum: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VPrimString: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_VFixed: {
      v_t_2443 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2423});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    return heff_tag_at_n(v_ru_24x2_241_24Describe, TAG_Describe, 1, (V[]){v_t_2443});
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Become = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2464;
    switch (heff_tag_of(v_x_2444)) {
    case TAG_VU: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VDecode: {
      V v_a_2450 = heff_field(v_x_2444, 4);
      heff_take_n(v_x_2444, 16ULL, 5);
      heff_drop_cell(v_tok_240, 1);
      v_t_2464 = heff_tr(heff_call(v_a_2450, 1, (V[]){NTAG(TAG_MkUnit)}));
      break;
    }
    case TAG_VFunction: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VRecord: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VSum: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VPrimInt: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VPrimString: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VPrimRune: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VPrimArray: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    case TAG_VFixed: {
      v_t_2464 = heff_tag_at_n(v_tok_240, TAG_VCode, 1, (V[]){v_x_2444});
      break;
    }
    default: heff_nomatch(v_x_2444);
    }
    return heff_tag_at_n(v_ru_24x2_241_24Become, TAG_Become, 1, (V[]){v_t_2464});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1(a[0], a[1]);
}
V g_heff_2eelab_2evalue_2especialize_24tok3_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2especialize_24tok3_lam0(V self, V *args);
Clo g_heff_2eelab_2evalue_2especialize_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2especialize_24tok3_entry, 4, 0};

V g_heff_2eelab_2evalue_2especialize_24tok3(V v_tok_240, V v_v_241, V v_x_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VNeu: {
    V v_h_244 = heff_field(v_v_241, 0);
    V v_sp_245 = heff_field(v_v_241, 1);
    V v_ty_246 = heff_field(v_v_241, 2);
    V v_expansion_247 = heff_field(v_v_241, 3);
    V v_desc_248 = heff_field(v_v_241, 4);
    V v_ru_24v_241_24VNeu = heff_take_reuse_n(v_v_241, 31ULL, 5);
    V v_it_249 = heff_tr(heff_call(v_desc_248, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_it_249)) {
    case TAG_Nothing: {
      heff_drop_cell(v_tok_240, 3);
      heff_drop(v_x_242);
      heff_drop(v_f_243);
      heff_drop(v_h_244);
      heff_drop(v_sp_245);
      heff_drop(v_ty_246);
      heff_drop(v_expansion_247);
      heff_drop_cell(v_ru_24v_241_24VNeu, 5);
      return heff_abandon();
    }
    case TAG_Just: {
      V v_it1_2410 = heff_field(v_it_249, 0);
      heff_take_n(v_it_249, 1ULL, 1);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_VNeu: {
        heff_take_n(v_it1_2410, 0ULL, 5);
        heff_drop_cell(v_tok_240, 3);
        heff_drop(v_x_242);
        heff_drop(v_f_243);
        heff_drop(v_h_244);
        heff_drop(v_sp_245);
        heff_drop(v_ty_246);
        heff_drop(v_expansion_247);
        heff_drop_cell(v_ru_24v_241_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_it11_2416 = heff_field(v_it1_2410, 0);
        heff_take_n(v_it1_2410, 1ULL, 1);
        switch (heff_tag_of(v_it11_2416)) {
        case TAG_VU: {
          heff_take_n(v_it11_2416, 0ULL, 1);
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VDecode: {
          heff_take_n(v_it11_2416, 0ULL, 5);
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VFunction: {
          heff_take_n(v_it11_2416, 0ULL, 6);
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VRecord: {
          V v_level_2429 = heff_field(v_it11_2416, 0);
          V v_capture_2430 = heff_field(v_it11_2416, 1);
          V v_fieldTypes_2431 = heff_field(v_it11_2416, 2);
          V v_defaults_2432 = heff_field(v_it11_2416, 3);
          heff_take_n(v_it11_2416, 15ULL, 4);
          return heff_tag_re_n(v_ru_24v_241_24VNeu, TAG_VNeu, 5, 13ULL, (V[]){v_h_244, heff_tag_at_n(v_tok_240, TAG_SpSpec, 3, (V[]){v_sp_245, heff_dup(v_x_242), heff_dup(v_f_243)}), v_ty_246, v_expansion_247, heff_clo_n(g_heff_2eelab_2evalue_2especialize_24tok3_lam0, 1, 6, (V[]){v_fieldTypes_2431, v_x_242, v_f_243, v_level_2429, v_capture_2430, v_defaults_2432})});
        }
        case TAG_VSum: {
          heff_take_n(v_it11_2416, 0ULL, 1);
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimInt: {
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimFloat: {
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimString: {
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimRune: {
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VPrimArray: {
          heff_take_n(v_it11_2416, 0ULL, 1);
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        case TAG_VFixed: {
          heff_take_n(v_it11_2416, 0ULL, 1);
          heff_drop_cell(v_tok_240, 3);
          heff_drop(v_x_242);
          heff_drop(v_f_243);
          heff_drop(v_h_244);
          heff_drop(v_sp_245);
          heff_drop(v_ty_246);
          heff_drop(v_expansion_247);
          heff_drop_cell(v_ru_24v_241_24VNeu, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_it11_2416);
        }
      }
      case TAG_VLam: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_cell(v_tok_240, 3);
        heff_drop(v_x_242);
        heff_drop(v_f_243);
        heff_drop(v_h_244);
        heff_drop(v_sp_245);
        heff_drop(v_ty_246);
        heff_drop(v_expansion_247);
        heff_drop_cell(v_ru_24v_241_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_cell(v_tok_240, 3);
        heff_drop(v_x_242);
        heff_drop(v_f_243);
        heff_drop(v_h_244);
        heff_drop(v_sp_245);
        heff_drop(v_ty_246);
        heff_drop(v_expansion_247);
        heff_drop_cell(v_ru_24v_241_24VNeu, 5);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_tok_240, 3);
        heff_drop(v_x_242);
        heff_drop(v_f_243);
        heff_drop(v_h_244);
        heff_drop(v_sp_245);
        heff_drop(v_ty_246);
        heff_drop(v_expansion_247);
        heff_drop_cell(v_ru_24v_241_24VNeu, 5);
        return heff_abandon();
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_it_249);
    }
  }
  case TAG_VCode: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_cell(v_tok_240, 3);
    heff_drop(v_x_242);
    heff_drop(v_f_243);
    return heff_abandon();
  }
  case TAG_VLam: {
    heff_take_n(v_v_241, 0ULL, 2);
    heff_drop_cell(v_tok_240, 3);
    heff_drop(v_x_242);
    heff_drop(v_f_243);
    return heff_abandon();
  }
  case TAG_VCons: {
    heff_take_n(v_v_241, 0ULL, 1);
    heff_drop_cell(v_tok_240, 3);
    heff_drop(v_x_242);
    heff_drop(v_f_243);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    heff_drop_cell(v_tok_240, 3);
    heff_drop(v_x_242);
    heff_drop(v_f_243);
    return NTAG(TAG_VOpaque);
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2eelab_2evalue_2especialize_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2especialize_24tok3(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2evalue_2especialize_24tok3_lam1(V self, V *args) {
  V v_field_2436 = args[0];
  V v_vs_2437 = args[1];
  V v_f_243 = heff_env(self)[0];
  V v_t_2438 = heff_tr(heff_call(v_field_2436, 1, (V[]){v_vs_2437}));
  switch (heff_tag_of(v_t_2438)) {
  case TAG_MkField: {
    V v_ty_2439 = heff_field(v_t_2438, 0);
    V v_ru_24t_2438_24MkField = heff_take_reuse_n(v_t_2438, 1ULL, 2);
    heff_clo_take(self, 1);
    return heff_tag_re_n(v_ru_24t_2438_24MkField, TAG_MkField, 2, 1ULL, (V[]){v_ty_2439, heff_tag_n(TAG_Just, 1, (V[]){v_f_243})});
  }
  default: return heff_nomatch(v_t_2438);
  }
}
V g_heff_2eelab_2evalue_2especialize_24tok3_lam0(V self, V *args) {
  V v_u_2433 = args[0];
  V v_fieldTypes_2431 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_level_2429 = heff_env(self)[3];
  V v_capture_2430 = heff_env(self)[4];
  V v_defaults_2432 = heff_env(self)[5];
  heff_drop(v_u_2433);
  heff_clo_take(self, 6);
  V v_d_2434 = v_fieldTypes_2431;
  V v_x_2435 = v_x_242;
  V v_f_2441 = heff_clo_n(g_heff_2eelab_2evalue_2especialize_24tok3_lam1, 2, 1, (V[]){v_f_243});
  HeffT2 v_t_2442 = ({ V a_0 = heff_rfield(v_d_2434, 1); V a_1 = v_x_2435; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_2435); r_; });
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    V v_t_2450;
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_i_2445 = v_field_2444;
      V v_xs_2446 = heff_dup(heff_rfield(v_d_2434, 2));
      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2445, 1) && heff_intLt_c_lent(v_i_2445, heff_arrayLength_lent(v_xs_2446, 0), 2))) {
        V v_v_2447 = heff_arrayIndex_lent(v_xs_2446, v_i_2445, 1);
        V v_t_2448 = heff_tr(heff_call(v_f_2441, 1, (V[]){v_v_2447}));
        V v_t_2449 = heff_arraySet(heff_take_field(v_d_2434, 2), v_i_2445, v_t_2448);
        v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_d_2434, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      } else {
        heff_drop_clo(v_f_2441, 1);
        heff_drop(v_i_2445);
        heff_drop(v_xs_2446);
        v_t_2450 = v_d_2434;
      }
    } else {
      heff_drop_clo(v_f_2441, 1);
      heff_drop(v_field_2444);
      v_t_2450 = v_d_2434;
    }
    V v_t_2451 = heff_tag_n(TAG_VCode, 1, (V[]){heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2429, v_capture_2430, v_t_2450, v_defaults_2432})});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2451});
  }
}