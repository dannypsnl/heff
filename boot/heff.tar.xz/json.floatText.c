// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_json_2efloatText_2enumberTextFrom_240(V, V);
V g_json_2efloatText_2enumberTextFrom_240_entry(V self, V *a);
extern Clo g_json_2efloatText_2enumberTextFrom_240_clo;
HEFF_LIT(g_json_2efloatText_2enumberTextFrom_240_str0, 2, ".0");
HEFF_LIT(g_json_2efloatText_2enumberTextFrom_240_str1, 1, "-");
HEFF_LIT(g_json_2efloatText_2enumberTextFrom_240_str2, 1, "+");
HEFF_LIT(g_json_2efloatText_2enumberTextFrom_240_str3, 1, "e");
Clo g_json_2efloatText_2enumberTextFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_json_2efloatText_2enumberTextFrom_240_entry, 2, 0};

V g_json_2efloatText_2enumberTextFrom_240(V v_t_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_t_240, 0)) <= v_i_241)) {
    return heff_dup(v_t_240);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_t_240, heff_box_word(v_i_241), 2)) == ((int64_t)101ULL))) {
      V v_m_242 = heff_strSlice_lent(v_t_240, MK_INT(0LL), heff_box_word(v_i_241), 6);
      int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_m_242, 0)) - ((int64_t)2ULL));
      V v_t_244 = heff_strSlice_lent(v_m_242, heff_box_word(v_t_243), heff_strLength_lent(v_m_242, 0), 6);
      V v_t_246;
      if (heff_strEq_c(v_t_244, ((V)&g_json_2efloatText_2enumberTextFrom_240_str0))) {
        int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_m_242, 0)) - ((int64_t)2ULL));
        v_t_246 = heff_strSlice(v_m_242, MK_INT(0LL), heff_box_word(v_t_245));
      } else {
        v_t_246 = v_m_242;
      }
      V v_ex_247 = heff_strSlice_lent(v_t_240, heff_box_word((v_i_241 + ((int64_t)1ULL))), heff_strLength_lent(v_t_240, 0), 6);
      V v_t_248;
      if (heff_strEq_c(heff_strSlice_lent(v_ex_247, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_json_2efloatText_2enumberTextFrom_240_str1))) {
        v_t_248 = v_ex_247;
      } else {
        v_t_248 = heff_strAppend(((V)&g_json_2efloatText_2enumberTextFrom_240_str2), v_ex_247);
      }
      return heff_strAppend(heff_strAppend(v_t_246, ((V)&g_json_2efloatText_2enumberTextFrom_240_str3)), v_t_248);
    } else {
      V t_0 = v_t_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_t_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_json_2efloatText_2enumberTextFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_json_2efloatText_2enumberTextFrom_240(a0, a[1]); heff_drop(a0); return r;
}