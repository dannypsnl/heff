// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EDo 15964
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ENest 28629
#define TAG_EReturn 59059
#define TAG_ETry 51493
#define TAG_EWith 38507
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IPrim 59489
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkBinding 51651
#define TAG_MkSegment 38079
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_SetPath 11095
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_e 319
#define LBL_end 310101
#define LBL_part 9928890
#define LBL_run 322821
#define LBL_start 311115900
static uint32_t shape_part__run[] = {LBL_part, LBL_run};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24dps_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s143795099x1025702421_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s143795099x1025702421_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_list_2eall_24s1414119352x995333365(V, V);
V g_list_2eall_24s1414119352x995333365_entry(V self, V *a);
extern Clo g_list_2eall_24s1414119352x995333365_clo;
V g_list_2eany_24s689038521x519269801(V);
V g_list_2eany_24s689038521x519269801_entry(V self, V *a);
extern Clo g_list_2eany_24s689038521x519269801_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s34825065x1144190520(V);
V g_list_2emap_24s34825065x1144190520_entry(V self, V *a);
extern Clo g_list_2emap_24s34825065x1144190520_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24dps_24cpr(V v_f_240, V v_st_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_u_244 = heff_setFieldPeek(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_245 = heff_hole();
    return ((HeffT2){{v_st_241, v_f_245}});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_242, 0);
    V v_xs_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_248 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_x_246}));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_MkPair: {
      V v_st_249 = heff_field(v_x1_248, 0);
      V v_y_2410 = heff_field(v_x1_248, 1);
      heff_take_n(v_x1_248, 3ULL, 2);
      V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_2410, heff_hole()});
      V v_u_2412 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2411);
      V t_0 = v_f_240;
      V t_1 = v_st_249;
      V t_2 = v_xs_247;
      V t_3 = v_u_2412;
      v_f_240 = t_0;
      v_st_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_2433;
    if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
      heff_drop(v_st_240);
      v_st_2433 = NTAG(TAG_True);
    } else {
      heff_drop(v_st_240);
      switch (heff_tag_of(v_x_242)) {
      case TAG_At: {
        V v_a_244 = heff_dup(heff_field(v_x_242, 0));
        switch (heff_tag_of(v_a_244)) {
        case TAG_ELam: {
          heff_take_n(v_a_244, 0ULL, 2);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_EDo: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_ENest: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_ELazy: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_ETry: {
          heff_take_n(v_a_244, 0ULL, 1);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        case TAG_EWith: {
          heff_take_n(v_a_244, 0ULL, 4);
          switch (heff_tag_of(v_x_242)) {
          case TAG_At: {
            v_st_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x_242);
          }
          break;
        }
        default: {
          heff_drop(v_a_244);
          HeffT2 v_t_2428 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_x_242)));
          {
            V v_field_2429 = v_t_2428.f[0];
            V v_field_2430 = v_t_2428.f[1];
            V v_a_2431 = v_field_2429;
            V v_a_2432 = v_field_2430;
            heff_drop(v_a_2432);
            v_st_2433 = v_a_2431;
          }
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_x_242);
      }
    }
    V v_cell_2434 = heff_tag_re_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    HeffT2 v_t_2435 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1242283185x1541081116_24dps_24cpr(v_st_2433, v_xs_243, v_cell_2434));
    {
      V v_field_2436 = v_t_2435.f[0];
      V v_field_2437 = v_t_2435.f[1];
      V v_x_2438 = v_field_2436;
      V v__5f_2439 = v_field_2437;
      heff_drop(v__5f_2439);
      return ((HeffT2){{v_x_2438, v_cell_2434}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s143795099x1025702421_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkBinding: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24MkBinding = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_2437;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2437 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_248 = heff_dup(heff_field(v_a_247, 0));
            switch (heff_tag_of(v_a_248)) {
            case TAG_ELam: {
              heff_take_n(v_a_248, 0ULL, 2);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EDo: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ENest: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ELazy: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_ETry: {
              heff_take_n(v_a_248, 0ULL, 1);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            case TAG_EWith: {
              heff_take_n(v_a_248, 0ULL, 4);
              switch (heff_tag_of(v_a_247)) {
              case TAG_At: {
                v_a_2437 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_247);
              }
              break;
            }
            default: {
              heff_drop(v_a_248);
              HeffT2 v_t_2432 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s194676226x2005721605_24cpr(NTAG(TAG_False), heff_dup(v_a_247)));
              {
                V v_field_2433 = v_t_2432.f[0];
                V v_field_2434 = v_t_2432.f[1];
                V v_a_2435 = v_field_2433;
                V v_a_2436 = v_field_2434;
                heff_drop(v_a_2436);
                v_a_2437 = v_a_2435;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_247);
          }
        }
        V v_t_2438 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkBinding, TAG_MkBinding, 2, 3ULL, (V[]){v_a_246, v_a_247}), v_a_245});
        V v_cell_2439 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2438, heff_hole()});
        HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2eaccList_24s143795099x1025702421_24dps_24cpr(v_a_2437, v_xs_243, v_cell_2439));
        {
          V v_field_2441 = v_t_2440.f[0];
          V v_field_2442 = v_t_2440.f[1];
          V v_x_2443 = v_field_2441;
          V v__5f_2444 = v_field_2442;
          heff_drop(v__5f_2444);
          return ((HeffT2){{v_x_2443, v_cell_2439}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1471616151x1751490896_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkSegment: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_a_2411 = heff_field(v_a_247, 2);
        V v_a_2412 = heff_field(v_a_247, 3);
        V v_a_2413 = heff_field(v_a_247, 4);
        V v_ru_24a_247_24MkSegment = heff_take_reuse_n(v_a_247, 31ULL, 5);
        V v_a_2428;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2428 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_249)) {
          case TAG_At: {
            V v_a_2414 = heff_dup(heff_field(v_a_249, 0));
            switch (heff_tag_of(v_a_2414)) {
            case TAG_ELam: {
              heff_take_n(v_a_2414, 0ULL, 2);
              switch (heff_tag_of(v_a_249)) {
              case TAG_At: {
                v_a_2428 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_249);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_2414, 0ULL, 1);
              switch (heff_tag_of(v_a_249)) {
              case TAG_At: {
                v_a_2428 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_249);
              }
              break;
            }
            default: {
              heff_drop(v_a_2414);
              HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_249)));
              {
                V v_field_2424 = v_t_2423.f[0];
                V v_field_2425 = v_t_2423.f[1];
                V v_a_2426 = v_field_2424;
                V v_a_2427 = v_field_2425;
                heff_drop(v_a_2427);
                v_a_2428 = v_a_2426;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_249);
          }
        }
        V v_t_2429 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkSegment, TAG_MkSegment, 5, 31ULL, (V[]){v_a_249, v_a_2410, v_a_2411, v_a_2412, v_a_2413}), v_a_248});
        V v_cell_2430 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2429, heff_hole()});
        V v_u_2431 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2430);
        V t_0 = v_a_2428;
        V t_1 = v_xs_246;
        V t_2 = v_u_2431;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        V v_ru_24a_244_24MkSegment = heff_take_reuse_n(v_a_244, 31ULL, 5);
        V v_a_2411;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2411 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_246)));
        }
        V v_t_2412 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkSegment, TAG_MkSegment, 5, 31ULL, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        HeffT2 v_t_2414 = (g_heff_2esyntax_2epresyntax_2eaccList_24s320198774x1124344602_24dps_24cpr(v_a_2411, v_xs_243, v_cell_2413));
        {
          V v_field_2415 = v_t_2414.f[0];
          V v_field_2416 = v_t_2414.f[1];
          V v_x_2417 = v_field_2415;
          V v__5f_2418 = v_field_2416;
          heff_drop(v__5f_2418);
          return ((HeffT2){{v_x_2417, v_cell_2413}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT3 v_t_247 = ({ V a_0 = v_st_240; V a_1 = v_x_245; HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(a_0, a_1)); heff_drop(v_st_240); r_; });
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      V v_st_2411 = v_field_248;
      V v_y_2412 = heff_tag_n(TAG_At, 2, (V[]){v_field_249, v_field_2410});
      V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_2412, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
      V t_0 = v_st_2411;
      V t_1 = v_xs_246;
      V t_2 = v_u_2414;
      v_st_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetPath: {
      V v_path_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SetPath = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24IsInferable = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_246_24IsInferable, TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24IsType = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_246_24IsType, TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_242_24SetPath, TAG_SetPath, 2, 1ULL, (V[]){v_path_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eupdateSetOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str1, 11, "bytesConcat");
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0, 2, 0};

HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  if ((heff_dup(v_asBits_241) == NTAG(TAG_True))) {
    return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(heff_dup(v_r_240), v_r_240, v_segs_242, v_sp_243, NTAG(TAG_False)));
  } else {
    V v_t_244 = (g_list_2eany_24s689038521x519269801(v_segs_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(heff_dup(v_r_240), v_r_240, v_segs_242, v_sp_243, NTAG(TAG_False)));
    } else {
      heff_drop(v_t_244);
      V v_t_245 = (g_list_2emap_24s34825065x1144190520(heff_dup(v_segs_242)));
      HeffT2 v_t_246 = ({ V a_0 = v_t_245; V a_1 = MK_INT(0LL); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_n_249 = v_field_248;
          if (!heff_intEq_c_lent(v_n_249, MK_INT(0LL), 2)) {
            heff_drop(v_n_249);
            return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(heff_dup(v_r_240), v_r_240, v_segs_242, v_sp_243, NTAG(TAG_False)));
          } else {
            heff_drop(v_n_249);
            V v_x1_2410 = (g_list_2eany_24s689038521x519269801(v_segs_242));
            if (!(heff_dup(v_x1_2410) == NTAG(TAG_True))) {
              heff_drop(v_x1_2410);
              V v_t_2411 = (g_list_2eall_24s1414119352x995333365(MK_INT(0LL), v_segs_242));
              if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
                heff_drop(v_t_2411);
                V v_r_2412 = v_r_240;
                V v_segs_2413 = heff_dup(v_segs_242);
                V v_sp_2414 = v_sp_243;
                HeffT2 v_t_2415 = ({ V a_0 = v_segs_242; V a_1 = ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str0); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(a_0, a_1)); heff_drop(v_segs_242); r_; });
                {
                  V v_field_2417 = v_t_2415.f[1];
                  int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
                  if ((v_tag_2416 == ((int64_t)0ULL))) {
                    heff_drop(v_r_2412);
                    heff_drop(v_segs_2413);
                    V v_s_2418 = v_field_2417;
                    return ((HeffT2){{heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2418}), v_sp_2414}});
                  } else {
                    heff_drop(v_field_2417);
                    V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_clo), 1, (V[]){v_r_2412}));
                    V v_m_2423 = heff_rec_n(2, shape_part__run, (V[]){v_t_2419, ((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0_clo)});
                    V v_xs_2424 = ({ V a_0 = v_m_2423; V a_1 = v_segs_2413; V a_2 = NTAG(TAG_Nothing); V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2ebinaryParts(a_0, a_1, a_2, a_3)); heff_drop_rec(v_m_2423, 2); r_; });
                    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
                    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2425, v_sp_2414));
                    V v_args_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
                    V v_t_2428 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2414), v_args_2427));
                    V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_str1)}), heff_dup(v_sp_2414)});
                    return ((HeffT2){{heff_tag_n(TAG_IApp, 2, (V[]){v_t_2429, v_t_2428}), v_sp_2414}});
                  }
                }
              } else {
                heff_drop(v_t_2411);
                return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(heff_dup(v_r_240), v_r_240, v_segs_242, v_sp_243, NTAG(TAG_True)));
              }
            } else {
              heff_drop(v_x1_2410);
              return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(heff_dup(v_r_240), v_r_240, v_segs_242, v_sp_243, NTAG(TAG_True)));
            }
          }
        } else {
          heff_drop(v_field_248);
          return (g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(heff_dup(v_r_240), v_r_240, v_segs_242, v_sp_243, NTAG(TAG_False)));
        }
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr_lam0(V self, V *args) {
  V v_s_2420 = args[0];
  V v_sp_2421 = args[1];
  V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2420}), heff_dup(v_sp_2421)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2422}), v_sp_2421});
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V v_x2_240, V v_run_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_241)) {
    case TAG_Nothing: {
      return v_acc_242;
    }
    case TAG_Just: {
      V v_x21_243 = heff_field(v_run_241, 0);
      V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
      switch (heff_tag_of(v_x21_243)) {
      case TAG_MkPair: {
        V v_s_244 = heff_field(v_x21_243, 0);
        V v_sp_245 = heff_field(v_x21_243, 1);
        V v_ru_24x21_243_24MkPair = heff_take_reuse_n(v_x21_243, 3ULL, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24x21_243_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_244}), heff_dup(v_sp_245)});
        V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_246}), v_sp_245});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_acc_242});
      }
      default: return heff_nomatch(v_x21_243);
      }
    }
    default: return heff_nomatch(v_run_241);
    }
  }
  case TAG_Cons: {
    V v_x21_248 = heff_field(v_x2_240, 0);
    V v_rest_249 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_At: {
      V v_seg_2410 = heff_field(v_x21_248, 0);
      V v_sp_2411 = heff_field(v_x21_248, 1);
      V v_ru_24x21_248_24At = heff_take_reuse_n(v_x21_248, 3ULL, 2);
      HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2410));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_seg_2410);
          heff_drop_cell(v_ru_24x21_248_24At, 2);
          V v_s_2415 = v_field_2414;
          V v_t_2421;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2415, v_sp_2411})});
            break;
          }
          case TAG_Just: {
            V v_x11_2416 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x11_2416)) {
            case TAG_MkPair: {
              V v_s0_2417 = heff_field(v_x11_2416, 0);
              V v_sp0_2418 = heff_field(v_x11_2416, 1);
              V v_ru_24x11_2416_24MkPair = heff_take_reuse_n(v_x11_2416, 3ULL, 2);
              V v_t_2419 = ({ V rv_1 = heff_get_n(v_sp_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2420 = heff_tag_at_n(v_ru_24x11_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2417, v_s_2415), v_t_2419});
              v_t_2421 = heff_tag_at_n(v_ru_24run_241_24Just, TAG_Just, 1, (V[]){v_t_2420});
              break;
            }
            default: heff_nomatch(v_x11_2416);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = v_t_2421;
          V t_2 = v_acc_242;
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          heff_drop(v_field_2414);
          V v_t_2422 = (g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(heff_tag_re_n(v_ru_24x21_248_24At, TAG_At, 2, 3ULL, (V[]){v_seg_2410, v_sp_2411})));
          V v_t_2428;
          switch (heff_tag_of(v_run_241)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            v_t_2428 = v_acc_242;
            break;
          }
          case TAG_Just: {
            V v_x21_2423 = heff_field(v_run_241, 0);
            V v_ru_24run_241_24Just = heff_take_reuse_n(v_run_241, 1ULL, 1);
            switch (heff_tag_of(v_x21_2423)) {
            case TAG_MkPair: {
              V v_s_2424 = heff_field(v_x21_2423, 0);
              V v_sp_2425 = heff_field(v_x21_2423, 1);
              V v_ru_24x21_2423_24MkPair = heff_take_reuse_n(v_x21_2423, 3ULL, 2);
              V v_t_2426 = heff_tag_at_n(v_ru_24x21_2423_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_241_24Just, TAG_IBytes, 1, (V[]){v_s_2424}), heff_dup(v_sp_2425)});
              V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2426}), v_sp_2425});
              v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2427, v_acc_242});
              break;
            }
            default: heff_nomatch(v_x21_2423);
            }
            break;
          }
          default: heff_nomatch(v_run_241);
          }
          V t_0 = v_rest_249;
          V t_1 = NTAG(TAG_Nothing);
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2428});
          v_x2_240 = t_0;
          v_run_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_TPi: {
    V v_b_241 = heff_field(v_n_240, 0);
    V v_cod_242 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24TPi = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_x2_243 = v_b_241;
    V v_t_2435;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_PiNamed: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_t_246 = heff_field(v_x2_243, 2);
      V v_ru_24x2_243_24PiNamed = heff_take_reuse_n(v_x2_243, 7ULL, 3);
      V v_t_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_At: {
        V v_n_247 = heff_field(v_t_246, 0);
        V v_sp_248 = heff_field(v_t_246, 1);
        V v_ru_24t_246_24At = heff_take_reuse_n(v_t_246, 3ULL, 2);
        v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_246_24At, v_sp_248, v_n_247));
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      v_t_2435 = heff_tag_re_n(v_ru_24x2_243_24PiNamed, TAG_PiNamed, 3, 3ULL, (V[]){v_x_244, v_sp_245, v_t_249});
      break;
    }
    case TAG_PiImplicit: {
      V v_x_2410 = heff_field(v_x2_243, 0);
      V v_sp_2411 = heff_field(v_x2_243, 1);
      V v_sp2_2412 = heff_field(v_x2_243, 2);
      V v_t_2413 = heff_field(v_x2_243, 3);
      V v_d_2414 = heff_field(v_x2_243, 4);
      V v_ru_24x2_243_24PiImplicit = heff_take_reuse_n(v_x2_243, 31ULL, 5);
      V v_t_2417;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_n_2415 = heff_field(v_t_2413, 0);
        V v_sp_2416 = heff_field(v_t_2413, 1);
        V v_ru_24t_2413_24At = heff_take_reuse_n(v_t_2413, 3ULL, 2);
        v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2413_24At, v_sp_2416, v_n_2415));
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      V v_t_2423;
      switch (heff_tag_of(v_d_2414)) {
      case TAG_Nothing: {
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_d_2414, 0);
        V v_ru_24d_2414_24Just = heff_take_reuse_n(v_d_2414, 1ULL, 1);
        V v_t_2422;
        switch (heff_tag_of(v_x_2418)) {
        case TAG_At: {
          V v_n_2419 = heff_field(v_x_2418, 0);
          V v_sp_2420 = heff_field(v_x_2418, 1);
          V v_ru_24x_2418_24At = heff_take_reuse_n(v_x_2418, 3ULL, 2);
          V v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2419));
          v_t_2422 = heff_tag_re_n(v_ru_24x_2418_24At, TAG_At, 2, 2ULL, (V[]){v_t_2421, v_sp_2420});
          break;
        }
        default: heff_nomatch(v_x_2418);
        }
        v_t_2423 = heff_tag_at_n(v_ru_24d_2414_24Just, TAG_Just, 1, (V[]){v_t_2422});
        break;
      }
      default: heff_nomatch(v_d_2414);
      }
      v_t_2435 = heff_tag_re_n(v_ru_24x2_243_24PiImplicit, TAG_PiImplicit, 5, 7ULL, (V[]){v_x_2410, v_sp_2411, v_sp2_2412, v_t_2417, v_t_2423});
      break;
    }
    case TAG_PiInstance: {
      V v_x_2424 = heff_field(v_x2_243, 0);
      V v_sp_2425 = heff_field(v_x2_243, 1);
      V v_sp2_2426 = heff_field(v_x2_243, 2);
      V v_t_2427 = heff_field(v_x2_243, 3);
      V v_ru_24x2_243_24PiInstance = heff_take_reuse_n(v_x2_243, 15ULL, 4);
      V v_t_2430;
      switch (heff_tag_of(v_t_2427)) {
      case TAG_At: {
        V v_n_2428 = heff_field(v_t_2427, 0);
        V v_sp_2429 = heff_field(v_t_2427, 1);
        V v_ru_24t_2427_24At = heff_take_reuse_n(v_t_2427, 3ULL, 2);
        v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2427_24At, v_sp_2429, v_n_2428));
        break;
      }
      default: heff_nomatch(v_t_2427);
      }
      v_t_2435 = heff_tag_re_n(v_ru_24x2_243_24PiInstance, TAG_PiInstance, 4, 7ULL, (V[]){v_x_2424, v_sp_2425, v_sp2_2426, v_t_2430});
      break;
    }
    case TAG_PiAnon: {
      V v_t_2431 = heff_field(v_x2_243, 0);
      V v_ru_24x2_243_24PiAnon = heff_take_reuse_n(v_x2_243, 1ULL, 1);
      V v_t_2434;
      switch (heff_tag_of(v_t_2431)) {
      case TAG_At: {
        V v_n_2432 = heff_field(v_t_2431, 0);
        V v_sp_2433 = heff_field(v_t_2431, 1);
        V v_ru_24t_2431_24At = heff_take_reuse_n(v_t_2431, 3ULL, 2);
        v_t_2434 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2431_24At, v_sp_2433, v_n_2432));
        break;
      }
      default: heff_nomatch(v_t_2431);
      }
      v_t_2435 = heff_tag_at_n(v_ru_24x2_243_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2434});
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_2438;
    switch (heff_tag_of(v_cod_242)) {
    case TAG_At: {
      V v_n_2436 = heff_field(v_cod_242, 0);
      V v_sp_2437 = heff_field(v_cod_242, 1);
      V v_ru_24cod_242_24At = heff_take_reuse_n(v_cod_242, 3ULL, 2);
      v_t_2438 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24cod_242_24At, v_sp_2437, v_n_2436));
      break;
    }
    default: heff_nomatch(v_cod_242);
    }
    return heff_tag_at_n(v_ru_24n_240_24TPi, TAG_TPi, 2, (V[]){v_t_2435, v_t_2438});
  }
  case TAG_TSig: {
    V v_fs_2439 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSig = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2440 = (g_list_2emap_24s1992667171x110340492(v_fs_2439));
    return heff_tag_at_n(v_ru_24n_240_24TSig, TAG_TSig, 1, (V[]){v_t_2440});
  }
  case TAG_TSum: {
    V v_vs_2441 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSum = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2442 = (g_list_2emap_24s513391942x823299088(v_vs_2441));
    return heff_tag_at_n(v_ru_24n_240_24TSum, TAG_TSum, 1, (V[]){v_t_2442});
  }
  case TAG_TType: {
    return v_n_240;
  }
  case TAG_TInt: {
    return v_n_240;
  }
  case TAG_TFloat: {
    return v_n_240;
  }
  case TAG_TString: {
    return v_n_240;
  }
  case TAG_TRune: {
    return v_n_240;
  }
  case TAG_TArray: {
    V v_a_2443 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TArray = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2446;
    switch (heff_tag_of(v_a_2443)) {
    case TAG_At: {
      V v_n_2444 = heff_field(v_a_2443, 0);
      V v_sp_2445 = heff_field(v_a_2443, 1);
      V v_ru_24a_2443_24At = heff_take_reuse_n(v_a_2443, 3ULL, 2);
      v_t_2446 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_2443_24At, v_sp_2445, v_n_2444));
      break;
    }
    default: heff_nomatch(v_a_2443);
    }
    return heff_tag_at_n(v_ru_24n_240_24TArray, TAG_TArray, 1, (V[]){v_t_2446});
  }
  case TAG_TFixed: {
    return v_n_240;
  }
  case TAG_TInf: {
    V v_i_2448 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2452;
    switch (heff_tag_of(v_i_2448)) {
    case TAG_At: {
      V v_n_2449 = heff_field(v_i_2448, 0);
      V v_sp_2450 = heff_field(v_i_2448, 1);
      V v_ru_24i_2448_24At = heff_take_reuse_n(v_i_2448, 3ULL, 2);
      V v_t_2451 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2449));
      v_t_2452 = heff_tag_re_n(v_ru_24i_2448_24At, TAG_At, 2, 2ULL, (V[]){v_t_2451, v_sp_2450});
      break;
    }
    default: heff_nomatch(v_i_2448);
    }
    return heff_tag_at_n(v_ru_24n_240_24TInf, TAG_TInf, 1, (V[]){v_t_2452});
  }
  case TAG_TChk: {
    V v_c_2453 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TChk = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2457;
    switch (heff_tag_of(v_c_2453)) {
    case TAG_At: {
      V v_n_2454 = heff_field(v_c_2453, 0);
      V v_sp_2455 = heff_field(v_c_2453, 1);
      V v_ru_24c_2453_24At = heff_take_reuse_n(v_c_2453, 3ULL, 2);
      V v_t_2456 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2454));
      v_t_2457 = heff_tag_re_n(v_ru_24c_2453_24At, TAG_At, 2, 2ULL, (V[]){v_t_2456, v_sp_2455});
      break;
    }
    default: heff_nomatch(v_c_2453);
    }
    return heff_tag_at_n(v_ru_24n_240_24TChk, TAG_TChk, 1, (V[]){v_t_2457});
  }
  case TAG_TNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(a[0]);
}