// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SEmpty 4509
#define TAG_SFail 3389
#define TAG_SLine 58919
#define TAG_SText 31624
V g_std_2edoc_2efits_2efitsGo_240(V, V);
V g_std_2edoc_2efits_2efitsGo_240_entry(V self, V *a);
extern Clo g_std_2edoc_2efits_2efitsGo_240_clo;
Clo g_std_2edoc_2efits_2efitsGo_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2efits_2efitsGo_240_entry, 2, 0};

V g_std_2edoc_2efits_2efitsGo_240(V v_rem_240, V v_s_241) {
top: ;
  if (heff_intLt_c_lent(v_rem_240, MK_INT(0LL), 2)) {
    heff_drop(v_rem_240);
    heff_drop(v_s_241);
    return NTAG(TAG_False);
  } else {
    switch (heff_tag_of(v_s_241)) {
    case TAG_SEmpty: {
      heff_drop(v_rem_240);
      return NTAG(TAG_True);
    }
    case TAG_SFail: {
      heff_drop(v_rem_240);
      return NTAG(TAG_False);
    }
    case TAG_SText: {
      V v_n_243 = heff_field(v_s_241, 1);
      V v_c_244 = heff_field(v_s_241, 2);
      heff_take_n(v_s_241, 6ULL, 3);
      V v_t_245 = heff_tr(heff_call(v_c_244, 1, (V[]){NTAG(TAG_MkUnit)}));
      V t_0 = heff_intSub(v_rem_240, v_n_243);
      V t_1 = v_t_245;
      v_rem_240 = t_0;
      v_s_241 = t_1;
      goto top;
    }
    case TAG_SLine: {
      heff_take_n(v_s_241, 0ULL, 2);
      heff_drop(v_rem_240);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_s_241);
    }
  }
}
V g_std_2edoc_2efits_2efitsGo_240_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2efits_2efitsGo_240(a[0], a[1]);
}