// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2einstanceEqualityList_2esameElements_240_24s1737331482x1249277632(V, V);
V g_prelude_2einstanceEqualityList_2esameElements_240_24s1737331482x1249277632_entry(V self, V *a);
extern Clo g_prelude_2einstanceEqualityList_2esameElements_240_24s1737331482x1249277632_clo;
Clo g_prelude_2einstanceEqualityList_2esameElements_240_24s1737331482x1249277632_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceEqualityList_2esameElements_240_24s1737331482x1249277632_entry, 2, 0};

V g_prelude_2einstanceEqualityList_2esameElements_240_24s1737331482x1249277632(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      if (heff_intEq_c_lent(v_x_244, v_y_246, 0)) {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2einstanceEqualityList_2esameElements_240_24s1737331482x1249277632_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_prelude_2einstanceEqualityList_2esameElements_240_24s1737331482x1249277632(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}