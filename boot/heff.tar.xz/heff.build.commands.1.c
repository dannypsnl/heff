// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_aliases 1464806715
#define LBL_backend 2032133329
#define LBL_bin 307073
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_c 317
#define LBL_custody 1359790159
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_fmap 9641981
#define LBL_fuel 9649789
#define LBL_globals 352931696
#define LBL_hashes 722717031
#define LBL_hmap 9701563
#define LBL_includeDirs 161922452
#define LBL_kind 9787483
#define LBL_libDirs 396703725
#define LBL_library 398066429
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_own 320000
#define LBL_packages 1496006433
#define LBL_pages 307784670
#define LBL_paths 307797256
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_run 322821
#define LBL_said 10017968
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_style 311138763
#define LBL_syntax 1059664654
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_tySyntax 1405311289
#define LBL_zig 330130
static uint32_t shape_c__zig__fuel__custody[] = {LBL_c, LBL_zig, LBL_fuel, LBL_custody};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_paths__hashes__modules__fuel[] = {LBL_paths, LBL_hashes, LBL_modules, LBL_fuel};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void);
V g_co_2eop_24s1014403878x489449937(V, V, V, V, V);
V g_co_2eop_24s1014403878x489449937_entry(V self, V *a);
extern Clo g_co_2eop_24s1014403878x489449937_clo;
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s2022167152x294629972_24rec0_get(void);
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_get(void);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0(V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624(V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575(V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621(V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144(V);
V g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_clo;
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(V, V, V, V);
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_clo;
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674(V, V, V);
V g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311(V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
HeffT2 g_heff_2ecompile_2eglue_2elinksIn_24cpr(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24f1730403549x1479772376(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1730403549x1479772376_entry(V self, V *a);
extern Clo g_list_2emap_24f1730403549x1479772376_clo;
V g_list_2emap_24s107931167x1978109134(V);
V g_list_2emap_24s107931167x1978109134_entry(V self, V *a);
extern Clo g_list_2emap_24s107931167x1978109134_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s328934344x1728860012(V, V);
V g_list_2emap_24s328934344x1728860012_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str1, 3, "out");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str3, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  HeffT3 v_t_242 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), heff_dup(v_self_241)));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_d_246 = v_field_243;
    V v_a_247 = v_field_244;
    V v_xs_248 = v_field_245;
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
    V v_xs_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_249; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
    V v_t_2412 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_246, v_a_247, v_t_2411});
    V v_s_2413 = ({ V a_0 = v_st_240; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2412, 3); r_; });
    HeffT3 v_t_2414 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2413));
    {
      V v_field_2415 = v_t_2414.f[0];
      V v_field_2416 = v_t_2414.f[1];
      V v_field_2417 = v_t_2414.f[2];
      V v_x11_2418 = v_field_2415;
      heff_drop(v_x11_2418);
      V v_x12_2419 = v_field_2416;
      heff_drop(v_x12_2419);
      V v_xs_2420 = v_field_2417;
      V v_t_2421 = v_xs_2420;
      V v_x1_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2421));
      V v_t_2425;
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_x1_2422, 0);
        heff_take_n(v_x1_2422, 1ULL, 2);
        v_t_2425 = v_x_2423;
        break;
      }
      default: heff_nomatch(v_x1_2422);
      }
      V v_t_24120;
      if (heff_strEq_c(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str1))) {
        HeffT3 v_t_2426 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), heff_dup(v_self_241)));
        V v_t_24123;
        {
          V v_field_2427 = v_t_2426.f[0];
          V v_field_2428 = v_t_2426.f[1];
          V v_field_2429 = v_t_2426.f[2];
          V v_d_2430 = v_field_2427;
          V v_a_2431 = v_field_2428;
          V v_xs_2432 = v_field_2429;
          V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2432));
          V v_xs_2434 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2433; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2433); r_; });
          V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2434));
          V v_t_2436 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2430, v_a_2431, v_t_2435});
          V v_s_2437 = ({ V a_0 = v_st_240; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2436, 3); r_; });
          HeffT3 v_t_2438 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2437));
          {
            V v_field_2439 = v_t_2438.f[0];
            V v_field_2440 = v_t_2438.f[1];
            V v_field_2441 = v_t_2438.f[2];
            V v_d_2442 = v_field_2439;
            V v_a_2443 = v_field_2440;
            V v_xs_2444 = v_field_2441;
            V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2444));
            V v_xs_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2445; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2445); r_; });
            V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2446));
            V v_t_2448 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2442, v_a_2443, v_t_2447});
            V v_s_2449 = ({ V a_0 = v_st_240; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2448, 3); r_; });
            HeffT3 v_t_2450 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2449));
            {
              V v_field_2451 = v_t_2450.f[0];
              V v_field_2452 = v_t_2450.f[1];
              V v_field_2453 = v_t_2450.f[2];
              V v_x11_2454 = v_field_2451;
              heff_drop(v_x11_2454);
              V v_x12_2455 = v_field_2452;
              heff_drop(v_x12_2455);
              V v_xs_2456 = v_field_2453;
              V v_t_2457 = v_xs_2456;
              V v_x1_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2457));
              switch (heff_tag_of(v_x1_2458)) {
              case TAG_Nil: {
                v_t_24123 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str2);
                break;
              }
              case TAG_Cons: {
                V v_x_2459 = heff_field(v_x1_2458, 0);
                heff_take_n(v_x1_2458, 1ULL, 2);
                v_t_24123 = v_x_2459;
                break;
              }
              default: heff_nomatch(v_x1_2458);
              }
            }
          }
        }
        v_t_24120 = heff_strEq(v_t_24123, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str3));
      } else {
        v_t_24120 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_24120)) {
      case TAG_True: {
        HeffT3 v_t_2461 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_self_241));
        {
          V v_field_2462 = v_t_2461.f[0];
          V v_field_2463 = v_t_2461.f[1];
          V v_field_2464 = v_t_2461.f[2];
          V v_d_2465 = v_field_2462;
          V v_a_2466 = v_field_2463;
          V v_xs_2467 = v_field_2464;
          V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2467));
          V v_xs_2469 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2468; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2468); r_; });
          V v_t_2470 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2469));
          V v_t_2471 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2465, v_a_2466, v_t_2470});
          V v_s_2472 = ({ V a_0 = v_st_240; V a_1 = v_t_2471; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2471, 3); r_; });
          HeffT3 v_t_2473 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2472));
          {
            V v_field_2474 = v_t_2473.f[0];
            V v_field_2475 = v_t_2473.f[1];
            V v_field_2476 = v_t_2473.f[2];
            V v_d_2477 = v_field_2474;
            V v_a_2478 = v_field_2475;
            V v_xs_2479 = v_field_2476;
            V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2479));
            V v_xs_2481 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2480; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2480); r_; });
            V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2481));
            V v_t_2483 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2477, v_a_2478, v_t_2482});
            V v_s_2484 = ({ V a_0 = v_st_240; V a_1 = v_t_2483; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2483, 3); r_; });
            HeffT3 v_t_2485 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2484));
            {
              V v_field_2486 = v_t_2485.f[0];
              V v_field_2487 = v_t_2485.f[1];
              V v_field_2488 = v_t_2485.f[2];
              V v_d_2489 = v_field_2486;
              V v_a_2490 = v_field_2487;
              V v_xs_2491 = v_field_2488;
              V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2491));
              V v_xs_2493 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2492; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2492); r_; });
              V v_t_2494 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2493));
              V v_t_2495 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2489, v_a_2490, v_t_2494});
              return ({ V a_0 = v_st_240; V a_1 = v_t_2495; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop_tag(v_t_2495, 3); r_; });
            }
          }
        }
      }
      case TAG_False: {
        HeffT3 v_t_2496 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_self_241));
        {
          V v_field_2497 = v_t_2496.f[0];
          V v_field_2498 = v_t_2496.f[1];
          V v_field_2499 = v_t_2496.f[2];
          V v_d_24100 = v_field_2497;
          V v_a_24101 = v_field_2498;
          V v_xs_24102 = v_field_2499;
          V v_t_24103 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24102));
          V v_xs_24104 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24103; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24103); r_; });
          V v_t_24105 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24104));
          V v_t_24106 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_24100, v_a_24101, v_t_24105});
          V v_s_24107 = ({ V a_0 = v_st_240; V a_1 = v_t_24106; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_24106, 3); r_; });
          HeffT3 v_t_24108 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_24107));
          {
            V v_field_24109 = v_t_24108.f[0];
            V v_field_24110 = v_t_24108.f[1];
            V v_field_24111 = v_t_24108.f[2];
            V v_d_24112 = v_field_24109;
            V v_a_24113 = v_field_24110;
            V v_xs_24114 = v_field_24111;
            V v_t_24115 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24114));
            V v_xs_24116 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24115; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24115); r_; });
            V v_t_24117 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24116));
            V v_t_24118 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_24112, v_a_24113, v_t_24117});
            return ({ V a_0 = v_st_240; V a_1 = v_t_24118; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop_tag(v_t_24118, 3); r_; });
          }
        }
      }
      default: return heff_nomatch(v_t_24120);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownRoot(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str0);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str1);
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_243);
        return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str2);
      }
      case TAG_Cons: {
        V v_s_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str3), heff_dup(v_b_243)), ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str4));
        return (g_heff_2ebuild_2ecommands_2eimportsOn_24acc(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_243, v_x122_244}), v_s_247));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebackDirOf_str0, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebackDirOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ebackDirOf(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_root_242));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2ecommands_2ebackDirOf_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_d_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_st_248 = v_style_241;
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_248), v_d_247));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_248), heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  return ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebackDirOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str2, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str3, 3, "-O1");
Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str1)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_b_245 = ({ V a_0 = v_st_240; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_root_241)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_b_245));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_240; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_248); r_; });
  return heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){v_root_241, v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str3)});
}
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildTarget(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappFile_str0, 3, "app");
Clo g_heff_2ebuild_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_242));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_a_247 = ({ V a_0 = v_st_240; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_f_243));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_p_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 0, 6)));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_2411));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappFile(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240, V v_file_241) {
top: ;
  V v_style_242 = heff_take_field(v_paths_240, 5);
  V v_root_243 = heff_get_n(v_paths_240, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_root_243));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_d_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  HeffT3 v_t_249 = (g_std_2epath_2eparse_24cpr(heff_dup(v_style_242), v_file_241));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_d_2413 = v_field_2410;
    heff_drop(v_d_2413);
    V v_a_2414 = v_field_2411;
    V v_xs_2415 = v_field_2412;
    V v_xs_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str1); V a_1 = v_a_2414; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str2); V a_3 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2415; V r_ = (g_list_2efoldl_24s680990791x1764841948(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_2414); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_x2_2418 = v_t_2417;
    V v_p_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_p_2421 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_p_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_st_2422 = v_style_242;
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_d_248));
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_p_2421));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    return ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s535099379x685970669(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam2(V self, V *args) {
  V v_v_2410 = args[0];
  return v_v_2410;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam4(V self, V *args) {
  V v_v_2418 = args[0];
  return v_v_2418;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam6(V self, V *args) {
  V v_s_2426 = args[0];
  return v_s_2426;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_st_2434;
  if (heff_strEq_c(v_x_2433, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str3))) {
    v_st_2434 = NTAG(TAG_Windows);
  } else {
    v_st_2434 = NTAG(TAG_Posix);
  }
  V v_x_2442;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2437;
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2425)) {
      case TAG_Nothing: {
        v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2435 = heff_field(v_x_2425, 0);
        heff_take_n(v_x_2425, 1ULL, 1);
        v_t_2437 = v_x_2435;
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2436 = heff_field(v_x_2417, 0);
      heff_take_n(v_x_2417, 1ULL, 1);
      heff_drop(v_x_2425);
      v_t_2437 = v_x_2436;
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_2434), v_t_2437));
    V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_2434), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str5)));
    V v_t_2440 = (g_std_2epath_2ejoin(v_t_2438, v_t_2439));
    v_x_2442 = ({ V a_0 = v_st_2434; V a_1 = v_t_2440; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2434); heff_drop(v_t_2440); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2441 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_x_2425);
    heff_drop(v_st_2434);
    v_x_2442 = v_d_2441;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_241;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam6_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2432, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam7, 1, 4, (V[]){v_x_249, v_x_2417, v_x_2425, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam4_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(v_t_2424, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam5, 1, 4, (V[]){v_hd_240, v_x_249, v_x_2417, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(v_t_2416, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727_lam3, 1, 3, (V[]){v_hd_240, v_x_249, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_str1, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam3(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam7(V self, V *args) {
  V v_r_2423 = args[0];
  return v_r_2423;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_x_2414 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_x_2431 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Left = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    heff_clo_take(self, 8);
    return (g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0(v_st_2413, v_x_2415, v_hd_240, v_x_242, v_x_243, v_x_244, v_x_2414, v_k_241, heff_tag_re_n(v_ru_24x_2430_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2431})));
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Right = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    switch (heff_tag_of(v_y_2432)) {
    case TAG_Left: {
      V v_err_2433 = heff_field(v_y_2432, 0);
      V v_ru_24y_2432_24Left = heff_take_reuse_n(v_y_2432, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2430_24Right, 1);
      heff_clo_take(self, 8);
      return (g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0(v_st_2413, v_x_2415, v_hd_240, v_x_242, v_x_243, v_x_244, v_x_2414, v_k_241, heff_tag_re_n(v_ru_24y_2432_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2433})));
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_y_2432, 0);
      heff_take_n(v_y_2432, 1ULL, 1);
      heff_clo_take(self, 8);
      return (g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_2ek_24l0(v_st_2413, v_x_2415, v_hd_240, v_x_242, v_x_243, v_x_244, v_x_2414, v_k_241, heff_tag_at_n(v_ru_24x_2430_24Right, TAG_Right, 1, (V[]){v_x_2434})));
    }
    default: return heff_nomatch(v_y_2432);
    }
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam6(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  V v_home_2416 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2413), heff_dup(v_x_2414)));
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2413), v_home_2416));
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2413), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_str1)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  V v_s_2420 = ({ V a_0 = v_st_2413; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_path_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2420));
  V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2421; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2421); r_; });
  V v_a_2424 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam7_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2429, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam8, 1, 8, (V[]){v_st_2413, v_x_2415, v_hd_240, v_x_242, v_x_243, v_x_244, v_x_2414, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_st_2413 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s1531866539x720065727(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam6, 1, 7, (V[]){v_st_2413, v_x_2414, v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  V v_st_2413;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_str0))) {
    v_st_2413 = NTAG(TAG_Windows);
  } else {
    v_st_2413 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam5, 1, 6, (V[]){v_hd_240, v_st_2413, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam3_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2411, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam4, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam2, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str0, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str1, 8, "fdlibm.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str2, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str3, 6, "fuel.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str4, 9, "custody.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311(V v_hd_240, V v_k_241) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str0), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam4(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = heff_strAppend(heff_strAppend(v_x_242, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str5)), v_x_243);
  V f_ = v_k_241;
  args[0] = heff_rec_n(4, shape_c__zig__fuel__custody, (V[]){v_t_247, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str4), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam4, 1, 5, (V[]){v_x_242, v_x_243, v_k_241, v_x_244, v_x_245})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str3), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam3, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241, v_x_244})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str2), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam2, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_str0), v_e_243), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_str1));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s1014403878x489449937(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(V v_ps_240, V v_olds_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_text_248 = heff_field(v_x31_245, 1);
      HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_olds_241, v_m_247));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_t_2413;
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2411;
          v_t_2413 = v_x_2412;
        } else {
          heff_drop(v_field_2411);
          v_t_2413 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_str0);
        }
        V v_c_2422;
        if (heff_strEq_c_lent(v_text_248, v_t_2413, 2)) {
          v_c_2422 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_lam0_clo);
        } else {
          V v_d_2416 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
          V v_st_2417 = heff_dup(heff_rfield(v_ps_240, 5));
          V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_d_2416));
          V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_strAppend(heff_dup(v_m_247), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_str1))));
          V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
          V v_t_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
          v_c_2422 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(v_t_2421, heff_dup(v_text_248)));
        }
        return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_lam1, 1, 5, (V[]){v_ps_240, heff_dup(v_olds_241), heff_dup(v_rest_246), v_z_243, v_z_244})});
      }
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_olds_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_drop(v_x_2423);
  heff_clo_take(self, 5);
  return ({ V a_0 = v_ps_240; V a_1 = v_olds_241; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_olds_241); heff_drop(v_rest_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300(V v_outPath_240, V v_bad_241, V v_o_242, V v_z_243, V v_z_244) {
top: ;
  V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_outPath_240)));
  V v_t_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_245; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_245); r_; });
  V v_a_248 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_246, heff_dup(heff_rfield(v_o_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_lam0_clo)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2413, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_lam1, 1, 5, (V[]){v_o_242, v_z_243, v_outPath_240, v_z_244, heff_dup(v_bad_241)})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_outPath_240 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_bad_241 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_x_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    heff_clo_take(self, 5);
    return ({ V a_0 = v_o_242; V a_1 = v_z_243; V a_2 = v_outPath_240; V a_3 = v_z_244; V a_4 = v_bad_241; V a_5 = heff_tag_re_n(v_ru_24x_2414_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2415}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_bad_241); r_; });
  }
  case TAG_Right: {
    V v_y_2416 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Right = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    switch (heff_tag_of(v_y_2416)) {
    case TAG_Left: {
      V v_err_2417 = heff_field(v_y_2416, 0);
      V v_ru_24y_2416_24Left = heff_take_reuse_n(v_y_2416, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2414_24Right, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_o_242; V a_1 = v_z_243; V a_2 = v_outPath_240; V a_3 = v_z_244; V a_4 = v_bad_241; V a_5 = heff_tag_re_n(v_ru_24y_2416_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2417}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_bad_241); r_; });
    }
    case TAG_Right: {
      V v_x_2418 = heff_field(v_y_2416, 0);
      heff_take_n(v_y_2416, 1ULL, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_o_242; V a_1 = v_z_243; V a_2 = v_outPath_240; V a_3 = v_z_244; V a_4 = v_bad_241; V a_5 = heff_tag_at_n(v_ru_24x_2414_24Right, TAG_Right, 1, (V[]){v_x_2418}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_bad_241); r_; });
    }
    default: return heff_nomatch(v_y_2416);
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str4, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str5, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str9, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str11, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str14, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str15, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str16, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str17, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str19, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str21, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam10(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_failed_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_t_2414 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
      V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
      V v_xs_2417 = (g_list_2emap_24s89148281x951607804(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str2), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str3), v_t_2416));
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
      V v_c_2419 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(v_sources_241, v_t_2418));
      return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam0, 1, 9, (V[]){v_z_248, v_name_243, v_outPath_244, v_c_2413, v_z_249, v_file_242, v_failed_245, v_done_246, v_bi_240})});
    } else {
      heff_drop(v_bi_240);
      heff_drop(v_sources_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_failed_245);
      heff_drop(v_done_246);
      heff_drop(v_field_2412);
      V v_t_24103 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str21), NTAG(TAG_MkUnit)});
      V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
      V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
      V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
      V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
      V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24108}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam10, 1, 2, (V[]){v_z_248, v_z_249})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam2(V self, V *args) {
  V v_r_2428 = args[0];
  return v_r_2428;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_outPath_244 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_c_2413 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_x_2436 = heff_field(v_x_2435, 0);
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_2ek_24l0(v_outPath_244, v_z_248, v_c_2413, v_x_2421, v_z_249, heff_tag_re_n(v_ru_24x_2435_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2436})));
  }
  case TAG_Right: {
    V v_y_2437 = heff_field(v_x_2435, 0);
    V v_ru_24x_2435_24Right = heff_take_reuse_n(v_x_2435, 1ULL, 1);
    switch (heff_tag_of(v_y_2437)) {
    case TAG_Left: {
      V v_err_2438 = heff_field(v_y_2437, 0);
      V v_ru_24y_2437_24Left = heff_take_reuse_n(v_y_2437, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2435_24Right, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_2ek_24l0(v_outPath_244, v_z_248, v_c_2413, v_x_2421, v_z_249, heff_tag_re_n(v_ru_24y_2437_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2438})));
    }
    case TAG_Right: {
      V v_x_2439 = heff_field(v_y_2437, 0);
      heff_take_n(v_y_2437, 1ULL, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_2ek_24l0(v_outPath_244, v_z_248, v_c_2413, v_x_2421, v_z_249, heff_tag_at_n(v_ru_24x_2435_24Right, TAG_Right, 1, (V[]){v_x_2439})));
    }
    default: return heff_nomatch(v_y_2437);
    }
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam4(V self, V *args) {
  V v_x_2459 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2450 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_drop(v_x_2459);
  heff_clo_take(self, 5);
  V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str9), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str10));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2460, v_why_2450);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam5(V self, V *args) {
  V v_x_2476 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2467 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_drop(v_x_2476);
  heff_clo_take(self, 5);
  V v_t_2477 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str14), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str15));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2477, v_why_2467);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam6(V self, V *args) {
  V v_s_2479 = args[0];
  return v_s_2479;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam9(V self, V *args) {
  V v_x_2497 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2488 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_drop(v_x_2497);
  heff_clo_take(self, 5);
  V v_t_2498 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str19), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str20));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2498, v_why_2488);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam8(V self, V *args) {
  V v_x_2487 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_outPath_244 = heff_env(self)[4];
  V v_done_246 = heff_env(self)[5];
  V v_glues_2462 = heff_env(self)[6];
  V v_x_2420 = heff_env(self)[7];
  V v_bi_240 = heff_env(self)[8];
  V v_name_243 = heff_env(self)[9];
  V v_x_2421 = heff_env(self)[10];
  V v_c_2413 = heff_env(self)[11];
  switch (heff_tag_of(v_x_2487)) {
  case TAG_Left: {
    V v_why_2488 = heff_field(v_x_2487, 0);
    V v_ru_24x_2487_24Left = heff_take_reuse_n(v_x_2487, 1ULL, 1);
    heff_clo_take(self, 12);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    heff_drop(v_glues_2462);
    heff_drop(v_x_2420);
    heff_drop(v_bi_240);
    heff_drop_tag(v_name_243, 1);
    heff_drop_rec(v_x_2421, 4);
    heff_drop_rec(v_c_2413, 14);
    V v_t_2489 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str16), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str17));
    V v_t_2490 = heff_strAppend(heff_strAppend(v_t_2489, heff_dup(v_why_2488)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str18));
    V v_t_2491 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2490, NTAG(TAG_MkUnit)});
    V v_t_2492 = heff_tag_at_n(v_ru_24x_2487_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2495})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2496}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam9, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2488, v_z_248, v_z_249})));
  }
  case TAG_Right: {
    V v_fs_2499 = heff_field(v_x_2487, 0);
    V v_ru_24x_2487_24Right = heff_take_reuse_n(v_x_2487, 1ULL, 1);
    heff_clo_take(self, 12);
    V v_t_24100 = (g_heff_2ebuild_2ecommands_2elinkWritten_24s1283520823x964686674(heff_dup(v_outPath_244), v_fs_2499, v_done_246));
    V v_t_24101 = (g_list_2emap_24s1435185561x202019164(v_glues_2462));
    V v_t_24102 = (g_prelude_2e_2b_2b(v_x_2420, v_t_24101));
    return ({ V a_0 = v_ru_24x_2487_24Right; V a_1 = v_bi_240; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_x_2421; V a_6 = v_failed_245; V a_7 = v_t_24100; V a_8 = v_c_2413; V a_9 = v_t_24102; V a_10 = v_z_248; V a_11 = v_z_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1381369512x803658327_24tok1(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop_tag(v_name_243, 1); r_; });
  }
  default: return heff_nomatch(v_x_2487);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam7(V self, V *args) {
  V v_x_2486 = args[0];
  V v_links_2478 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_failed_245 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_outPath_244 = heff_env(self)[5];
  V v_done_246 = heff_env(self)[6];
  V v_glues_2462 = heff_env(self)[7];
  V v_x_2420 = heff_env(self)[8];
  V v_bi_240 = heff_env(self)[9];
  V v_name_243 = heff_env(self)[10];
  V v_x_2421 = heff_env(self)[11];
  V v_c_2413 = heff_env(self)[12];
  heff_clo_take(self, 13);
  return ({ V a_0 = v_x_2486; V a_1 = v_links_2478; V a_2 = heff_dup(v_z_248); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam8, 1, 12, (V[]){v_file_242, v_z_248, v_failed_245, v_z_249, v_outPath_244, v_done_246, v_glues_2462, v_x_2420, v_bi_240, v_name_243, v_x_2421, v_c_2413}); V r_ = (g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(a_0, a_1, a_2, a_3)); heff_drop(v_x_2486); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_outPath_244 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_x_2420 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_failed_245 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  V v_bi_240 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_name_243)) {
  case TAG_Nothing: {
    heff_drop(v_x_2420);
    heff_drop(v_file_242);
    heff_drop(v_failed_245);
    heff_drop(v_done_246);
    heff_drop(v_bi_240);
    int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
    V v_t_2423 = heff_strSlice_lent(v_outPath_244, heff_box_word(v_t_2422), heff_strLength_lent(v_outPath_244, 0), 6);
    V v_t_2425;
    if (heff_strEq_c(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str4))) {
      int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)2ULL));
      v_t_2425 = heff_strSlice_lent(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2424), 6);
    } else {
      v_t_2425 = heff_dup(v_outPath_244);
    }
    V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str5))));
    V v_t_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2426; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2426); r_; });
    V v_a_2429 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2427, heff_dup(heff_rfield(v_x_2421, 1)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam2_clo)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2434, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam3, 1, 5, (V[]){v_outPath_244, v_z_248, v_c_2413, v_x_2421, v_z_249})));
  }
  case TAG_Just: {
    V v_t_2441 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
    V v_t_2442 = ({ V a_0 = v_t_2441; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2441); r_; });
    V v_leaves_2443 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2442));
    V v_t_2444 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2420)}));
    V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 10);
    V v_t_2446 = (g_list_2emap_24s164225955x66209884(v_t_2445, v_t_2444, v_leaves_2443));
    HeffT2 v_t_2447 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2446));
    {
      V v_field_2449 = v_t_2447.f[1];
      int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
      if ((v_tag_2448 == ((int64_t)0ULL))) {
        heff_drop_rec(v_x_2421, 4);
        heff_drop_tag(v_name_243, 1);
        heff_drop(v_outPath_244);
        heff_drop_rec(v_c_2413, 14);
        heff_drop(v_x_2420);
        heff_drop(v_done_246);
        heff_drop(v_bi_240);
        V v_why_2450 = v_field_2449;
        V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str6), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str7));
        V v_t_2452 = heff_strAppend(heff_strAppend(v_t_2451, heff_dup(v_why_2450)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str8));
        V v_t_2453 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2452, NTAG(TAG_MkUnit)});
        V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
        V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
        V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
        V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
        V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam4, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2450, v_z_248, v_z_249})));
      } else {
        V v_ms_2461 = v_field_2449;
        V v_glues_2462 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2461));
        V v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 10);
        HeffT2 v_t_2464 = (g_heff_2ecompile_2eglue_2elinksIn_24cpr(v_t_2463));
        {
          V v_field_2466 = v_t_2464.f[1];
          int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
          if ((v_tag_2465 == ((int64_t)0ULL))) {
            heff_drop_rec(v_x_2421, 4);
            heff_drop_tag(v_name_243, 1);
            heff_drop(v_outPath_244);
            heff_drop_rec(v_c_2413, 14);
            heff_drop(v_x_2420);
            heff_drop(v_done_246);
            heff_drop(v_bi_240);
            heff_drop(v_glues_2462);
            V v_why_2467 = v_field_2466;
            V v_t_2468 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str11), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str12));
            V v_t_2469 = heff_strAppend(heff_strAppend(v_t_2468, heff_dup(v_why_2467)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_str13));
            V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2469, NTAG(TAG_MkUnit)});
            V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
            V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
            V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
            V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
            V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
            return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam5, 1, 5, (V[]){v_file_242, v_failed_245, v_why_2467, v_z_248, v_z_249})));
          } else {
            V v_links_2478 = v_field_2466;
            V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam6_clo)})});
            V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
            V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
            V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
            V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
            V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
            return (g_co_2eop_24s535099379x685970669(v_t_2485, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam7, 1, 13, (V[]){v_links_2478, v_z_248, v_file_242, v_failed_245, v_z_249, v_outPath_244, v_done_246, v_glues_2462, v_x_2420, v_bi_240, v_name_243, v_x_2421, v_c_2413})));
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_name_243);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_c_2413 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_failed_245 = heff_env(self)[6];
  V v_done_246 = heff_env(self)[7];
  V v_bi_240 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s1882484419x628245311(heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam1, 1, 10, (V[]){v_name_243, v_outPath_244, v_z_248, v_c_2413, v_z_249, v_x_2420, v_file_242, v_failed_245, v_done_246, v_bi_240})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s942504221x1516739707_lam10(V self, V *args) {
  V v_x_24109 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_drop(v_x_24109);
  V v_t_24110 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
  V v_t_24115 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24114})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24115}), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_str0, 4, "std.");
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007(V v_host_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam0_clo);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007(v_host_240, v_rest_245));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam1, 2, 3, (V[]){v_c_246, v_s_244, heff_dup(v_host_240)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_t_2411;
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_s_244, 0, 8), v_x_249});
  } else {
    heff_drop(v_x_2410);
    heff_drop_rec(v_s_244, 8);
    v_t_2411 = v_x_249;
  }
  V f_ = v_k_248;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  if (((heff_dup(heff_rfield(v_s_244, 7)) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice(heff_dup(heff_rfield(v_s_244, 0)), MK_INT(0LL), MK_INT(4LL)), ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_str0)))) {
    heff_clo_take(self, 4);
    return ({ V a_0 = v_host_240; V a_1 = heff_dup(v_s_244); V a_2 = v_hd_247; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam3, 1, 3, (V[]){v_s_244, v_x_249, v_k_248}); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071(a_0, a_1, a_2, a_3)); heff_drop(v_host_240); r_; });
  } else {
    heff_clo_take(self, 4);
    heff_drop_rec(v_s_244, 8);
    heff_drop(v_host_240);
    heff_drop(v_hd_247);
    V f_ = v_k_248;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1558805734x1279460007_lam2, 1, 4, (V[]){v_s_244, v_host_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str0, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str1, 70, "heff compile: an ES module runs nothing: no --name with --backend=esm\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str2, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str3, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str4, 25, "heff compile: no backend ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str5, 16, ": esm, page or c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575(V v_o_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str0))) {
    V v_t_243 = heff_dup(heff_rfield(v_o_240, 2));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624(v_o_240, v_p_241, v_p_242);
    }
    case TAG_Just: {
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 0ULL, 1);
      heff_drop_rec(v_o_240, 5);
      V v_t_245 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str1), NTAG(TAG_MkUnit)});
      V v_t_246 = heff_tag_at_n(v_ru_24t_243_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
      V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
      V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
      V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
      HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_lam0, 1, 2, (V[]){v_p_241, v_p_242}));
    }
    default: return heff_nomatch(v_t_243);
    }
  } else {
    if ((heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str3)))) {
      HEFF_LAST return g_heff_2ebuild_2ecommands_2ecompileThere_24s1848029299x1407558624(v_o_240, v_p_241, v_p_242);
    } else {
      V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str4), heff_get_n(v_o_240, 3, 5));
      V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str5)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_str6));
      V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
      HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_lam1, 1, 2, (V[]){v_p_241, v_p_242}));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_drop(v_x_2411);
  V v_t_2412 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_p_241, v_p_242));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1731486759x2024809575_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_p_241, v_p_242));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str2, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str3, 5, "error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str4, 7, "warning");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str5, 5, "debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str6, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str7, 2, "  ");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621(a[0]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam7(V self, V *args) {
  V v_ev_2422 = args[0];
  V v_source_2419 = heff_env(self)[0];
  V v_span_2423 = heff_take_field(v_ev_2422, 0);
  V v_text_2424 = heff_take_field(v_ev_2422, 2);
  V v_kind_2425 = heff_get_n(v_ev_2422, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2426 = ({ V a_0 = v_source_2419; V a_1 = v_span_2423; V r_ = (g_heff_2ebuild_2equery_2eatLine(a_0, a_1)); heff_drop(v_source_2419); r_; });
  V v_t_2427 = heff_tr(heff_call(v_text_2424, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str1)), v_kind_2425);
  return heff_strAppend(heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str2)), v_t_2427);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam8(V self, V *args) {
  V v_d_2430 = args[0];
  V v_source_2419 = heff_env(self)[0];
  V v_span_2431 = heff_take_field(v_d_2430, 3);
  V v_severity_2432 = heff_take_field(v_d_2430, 1);
  V v_msg_2433 = heff_get_n(v_d_2430, 2, 5);
  heff_clo_take(self, 1);
  V v_t_2434 = ({ V a_0 = v_source_2419; V a_1 = v_span_2431; V r_ = (g_heff_2ebuild_2equery_2eatLine(a_0, a_1)); heff_drop(v_source_2419); r_; });
  V v_t_2435 = v_severity_2432;
  V v_t_2436;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_SError: {
    v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str3);
    break;
  }
  case TAG_SWarning: {
    v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str4);
    break;
  }
  case TAG_SDebug: {
    v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str5);
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str6)), v_t_2436);
  return heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str7)), v_msg_2433);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_cs_2412 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_drop(v_x_2413);
  heff_clo_take(self, 3);
  HeffT2 v_t_2414 = ({ V a_0 = v_cs_2412; HeffT2 r_ = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(a_0)); heff_drop(v_cs_2412); r_; });
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_c_2417 = v_field_2416;
      V v_c_2418 = v_c_2417;
      V v_source_2419 = heff_take_field(v_c_2418, 3);
      V v_top_2420 = heff_take_field(v_c_2418, 5);
      V v_diags_2421 = heff_get_n(v_c_2418, 6, 14);
      V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam7, 1, 1, (V[]){heff_dup(v_source_2419)}), heff_get_n(v_top_2420, 8, 10)));
      V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam8, 1, 1, (V[]){v_source_2419}), v_diags_2421));
      V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2438));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s139640506x625915633(v_t_2439, v_hd_242, v_k_243));
    } else {
      heff_drop(v_field_2416);
      V v_t_2440 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), v_hd_242, v_k_243));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam5(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_cs_2412 = heff_get_n(v_x_2411, 0, 2);
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2412), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam6, 1, 3, (V[]){v_cs_2412, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam4(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_drop(v_x_249);
  heff_clo_take(self, 3);
  V v_t_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(v_x_248));
  V f_ = v_t_2410;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam5, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_t_247 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_246, heff_dup(heff_rfield(v_x_245, 4))));
  heff_clo_take(self, 3);
  V v_x_248 = (g_list_2efoldl_24s571074576x1179600767(v_x_245, v_t_247));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_str0), heff_dup(heff_rfield(v_x_248, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam4, 1, 3, (V[]){v_x_248, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam3, 1, 3, (V[]){v_x_245, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_244, v_file_240, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1815568572x267205621_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str1, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str4, 23, "heff fmt: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str6, 23, "heff fmt: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_243, heff_dup(v_src_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_src_242);
      V v_why_249 = v_field_248;
      V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str1));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_why_249), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str2));
      V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam0, 1, 1, (V[]){v_z_245})));
    } else {
      V v_out_2419 = v_field_248;
      if (heff_strEq_c_lent(v_out_2419, v_src_242, 2)) {
        heff_drop(v_f_241);
        heff_drop(v_z_244);
        heff_drop(v_out_2419);
        return heff_tail(v_z_245, 1, (V[]){MK_INT(0LL)});
      } else {
        if ((heff_dup(v_checkOnly_240) == NTAG(TAG_True))) {
          heff_drop(v_out_2419);
          V v_t_2420 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str3)), NTAG(TAG_MkUnit)});
          V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
          V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
          V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
          return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam1, 1, 1, (V[]){v_z_245})));
        } else {
          V v_path_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_241)));
          V v_t_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2427; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2427); r_; });
          V v_a_2430 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2428, v_out_2419, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam2_clo)});
          V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2430})});
          V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
          V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
          V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
          V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
          return (g_co_2eop_24s1896221640x2141527803(v_t_2435, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam3, 1, 3, (V[]){v_f_241, v_z_244, v_z_245})));
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_drop(v_x_2418);
  heff_clo_take(self, 1);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_drop(v_x_2426);
  heff_clo_take(self, 1);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam2(V self, V *args) {
  V v_r_2429 = args[0];
  return v_r_2429;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam4(V self, V *args) {
  V v_x_2445 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_drop(v_x_2445);
  heff_clo_take(self, 1);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam5(V self, V *args) {
  V v_x_2455 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_drop(v_x_2455);
  heff_clo_take(self, 1);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    V v_ru_24x_2436_24Left = heff_take_reuse_n(v_x_2436, 0ULL, 1);
    heff_clo_take(self, 3);
    V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str4), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str5));
    V v_t_2439 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2438, NTAG(TAG_MkUnit)});
    V v_t_2440 = heff_tag_at_n(v_ru_24x_2436_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam4, 1, 1, (V[]){v_z_245})));
  }
  case TAG_Right: {
    V v_y_2446 = heff_field(v_x_2436, 0);
    V v_ru_24x_2436_24Right = heff_take_reuse_n(v_x_2436, 1ULL, 1);
    switch (heff_tag_of(v_y_2446)) {
    case TAG_Left: {
      V v_ru_24y_2446_24Left = heff_take_reuse_n(v_y_2446, 0ULL, 1);
      heff_clo_take(self, 3);
      V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str6), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_str7));
      V v_t_2449 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2448, NTAG(TAG_MkUnit)});
      V v_t_2450 = heff_tag_at_n(v_ru_24x_2436_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2446_24Left, TAG_InL, 1, (V[]){v_t_2449})});
      V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
      V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s1762352569x1909329639_lam5, 1, 1, (V[]){v_z_245})));
    }
    case TAG_Right: {
      heff_take_n(v_y_2446, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_f_241);
      heff_drop(v_z_244);
      heff_drop_cell(v_ru_24x_2436_24Right, 1);
      V f_ = v_z_245;
      args[0] = MK_INT(0LL);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2446);
    }
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_245)));
    V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
    V v_t_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_c_2411 = (g_heff_2ebuild_2ecommands_2eisThere_24s886263672x1755170144(v_t_2410));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam1, 2, 5, (V[]){v_c_2411, v_st_240, v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  V v_t_2417;
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_drop(v_n_245);
    v_t_2417 = v_x_2416;
  } else {
    heff_drop(v_x_2414);
    v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, v_x_2416});
  }
  V f_ = v_k_2413;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811(v_st_240, v_t_241, v_rest_246));
  V f_ = v_t_2415;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam3, 1, 3, (V[]){v_x_2414, v_n_245, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s53708485x1653289811_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_2412, v_n_245, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332(V v_lit_240, V v_lit_241, V v_fuel_242, V v_l_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_str0), heff_dup(heff_rfield(v_l_243, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam0, 1, 9, (V[]){v_l_243, v_hd_247, v_fuel_242, v_lit_240, v_k_248, v_lit_241, v_file_245, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  V v_sources_2414 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = ({ V a_0 = v_c_2416; V a_1 = v_sources_2414; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2414); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2419;
      V v_t_2421 = ({ V a_0 = v_x_2415; V a_1 = v_s_2420; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2415); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2416, v_t_2421));
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_field_2419);
      return v_c_2416;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam4(V self, V *args) {
  V v_a_2442 = args[0];
  V v_z_2443 = args[1];
  V v_z_2444 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_a_2442);
  heff_clo_take(self, 1);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_z_2443, v_z_2444));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_cs_2423 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_done_2412 = heff_env(self)[5];
  V v_l_243 = heff_env(self)[6];
  V v_hashes_2413 = heff_env(self)[7];
  V v_fuel_242 = heff_env(self)[8];
  V v_lit_241 = heff_env(self)[9];
  V v_file_245 = heff_env(self)[10];
  V v_outPath_244 = heff_env(self)[11];
  V v_done_246 = heff_env(self)[12];
  heff_drop(v_x_2424);
  heff_clo_take(self, 13);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop(v_done_2412);
    heff_drop_rec(v_l_243, 5);
    heff_drop(v_hashes_2413);
    heff_drop(v_fuel_242);
    heff_drop(v_lit_241);
    heff_drop(v_file_245);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    V v_x2_2425 = ({ V a_0 = v_cs_2423; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_2423); r_; });
    heff_drop(v_x2_2425);
    V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_247, v_k_248));
  } else {
    V v_t_2432 = (g_list_2eany_24s1740858080x874135214(v_cs_2423));
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_done_2412);
      heff_drop_rec(v_l_243, 5);
      heff_drop(v_hashes_2413);
      heff_drop(v_fuel_242);
      heff_drop(v_lit_241);
      heff_drop(v_file_245);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2432);
      V v_x2_2433 = ({ V a_0 = v_cs_2423; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_2423); r_; });
      heff_drop(v_x2_2433);
      V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
      return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_247, v_k_248));
    } else {
      heff_drop(v_t_2432);
      V v_t_2440 = (g_list_2emap_24s1698496827x1884878103(v_done_2412));
      V v_t_2441 = heff_rec_n(4, shape_paths__hashes__modules__fuel, (V[]){heff_take_field(v_l_243, 2), v_hashes_2413, v_t_2440, v_fuel_242});
      return ({ V a_0 = v_lit_241; V a_1 = v_t_2441; V a_2 = heff_get_n(v_l_243, 0, 5); V a_3 = v_file_245; V a_4 = v_outPath_244; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam4, 3, 1, (V[]){v_lit_240}); V a_6 = v_done_246; V a_7 = v_cs_2423; V a_8 = v_hd_247; V a_9 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_cs_2423); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_fuel_242 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_file_245 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  V v_done_2412 = heff_take_field(v_x_2411, 0);
  V v_hashes_2413 = heff_get_n(v_x_2411, 1, 2);
  V v_sources_2414 = heff_dup(heff_rfield(v_l_243, 0));
  V v_x_2415 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_str2), heff_dup(v_sources_2414)));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam2, 1, 2, (V[]){v_sources_2414, v_x_2415}), heff_dup(v_done_2412)));
  V v_cs_2423;
  if ((heff_dup(v_fuel_242) == NTAG(TAG_True))) {
    v_cs_2423 = v_x_2422;
  } else {
    v_cs_2423 = (g_list_2emap_24s107931167x1978109134(v_x_2422));
  }
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2423), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam3, 1, 13, (V[]){v_x_249, v_cs_2423, v_lit_240, v_hd_247, v_k_248, v_done_2412, v_l_243, v_hashes_2413, v_fuel_242, v_lit_241, v_file_245, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_fuel_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_file_245 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  V v_t_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_l_243)));
  heff_clo_take(self, 9);
  V f_ = v_t_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332_lam1, 1, 10, (V[]){v_l_243, v_fuel_242, v_hd_247, v_x_249, v_lit_240, v_k_248, v_lit_241, v_file_245, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str3, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str4, 2, "-I");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str5, 2, "-L");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str6, 10, "heff build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str7, 20, "compiling for a page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str8, 12, "passed over ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str9, 32, ": a page's script, not a program");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam15, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam17(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam17, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam20(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam19(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109(V v_st_240, V v_t_241, V v_bp_242, V v_x_243, V v_a_244, V v_next_245, V v_p_246, V v_p_247) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_a_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str0))) {
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s535099379x685970669(v_t_2410, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam1, 1, 7, (V[]){v_p_246, v_a_244, v_st_240, v_t_241, v_x_243, v_next_245, v_p_247})));
  } else {
    V v_t_2469 = heff_dup(heff_rfield(v_t_241, 3));
    if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
      heff_drop(v_t_2469);
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam13_clo)})});
      V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
      return (g_co_2eop_24s535099379x685970669(v_t_2472, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam14, 1, 7, (V[]){v_p_246, v_st_240, v_t_241, v_x_243, v_a_244, v_next_245, v_p_247})));
    } else {
      heff_drop(v_st_240);
      heff_drop_rec(v_t_241, 6);
      heff_drop_rec(v_a_244, 6);
      heff_drop(v_t_2469);
      V v_t_2493 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str8), v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str9));
      V v_t_2494 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2493, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str10)), NTAG(TAG_MkUnit)});
      V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
      V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
      V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
      V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
      V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2499}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam19, 1, 4, (V[]){v_bp_242, v_p_246, v_next_245, v_p_247})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam2(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_drop(v_x_2430);
  heff_clo_take(self, 3);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2426;
  heff_room[1] = v_k_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2411 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_hd_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam5, 1, 3, (V[]){v_next_245, v_hd_2426, v_k_2427})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam6(V self, V *args) {
  V v_d_2437 = args[0];
  V v_st_2432 = heff_env(self)[0];
  V v_t_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_2432), heff_get_n(v_t_2433, 0, 6)));
  V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_2432), v_d_2437));
  V v_t_2440 = (g_std_2epath_2ejoin(v_t_2438, v_t_2439));
  V v_t_2441 = ({ V a_0 = v_st_2432; V a_1 = v_t_2440; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2432); heff_drop(v_t_2440); r_; });
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str4), v_t_2441);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam7(V self, V *args) {
  V v_d_2443 = args[0];
  V v_st_2432 = heff_env(self)[0];
  V v_t_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = (g_std_2epath_2eparse(heff_dup(v_st_2432), heff_get_n(v_t_2433, 0, 6)));
  V v_t_2445 = (g_std_2epath_2eparse(heff_dup(v_st_2432), v_d_2443));
  V v_t_2446 = (g_std_2epath_2ejoin(v_t_2444, v_t_2445));
  V v_t_2447 = ({ V a_0 = v_st_2432; V a_1 = v_t_2446; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2432); heff_drop(v_t_2446); r_; });
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str5), v_t_2447);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam12(V self, V *args) {
  V v_x_2468 = args[0];
  V v_next_2457 = heff_env(self)[0];
  V v_hd_2464 = heff_env(self)[1];
  V v_k_2465 = heff_env(self)[2];
  heff_drop(v_x_2468);
  heff_clo_take(self, 3);
  V f_ = v_next_2457;
  heff_room[0] = v_hd_2464;
  heff_room[1] = v_k_2465;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam11(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_x_2415 = heff_env(self)[0];
  V v_next_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2466 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), heff_dup(v_hd_2464), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam12, 1, 3, (V[]){v_next_2457, v_hd_2464, v_k_2465})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam10(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2460 = heff_env(self)[0];
  V v_t_2417 = heff_env(self)[1];
  V v_fuel_2416 = heff_env(self)[2];
  V v_outPath_2419 = heff_env(self)[3];
  V v_file_2420 = heff_env(self)[4];
  V v_x_2415 = heff_env(self)[5];
  V v_next_2457 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  V v_t_2462 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2461, heff_dup(heff_rfield(v_x_2460, 4))));
  heff_clo_take(self, 9);
  V v_x_2463 = (g_list_2efoldl_24s571074576x1179600767(v_x_2460, v_t_2462));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s139121944x966237332(MK_INT(1LL), v_t_2417, v_fuel_2416, v_x_2463, v_outPath_2419, v_file_2420, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam11, 2, 2, (V[]){v_x_2415, v_next_2457}), v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam9(V self, V *args) {
  V v_x_2460 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_t_2417 = heff_env(self)[1];
  V v_fuel_2416 = heff_env(self)[2];
  V v_outPath_2419 = heff_env(self)[3];
  V v_file_2420 = heff_env(self)[4];
  V v_x_2415 = heff_env(self)[5];
  V v_next_2457 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam10, 1, 9, (V[]){v_x_2460, v_t_2417, v_fuel_2416, v_outPath_2419, v_file_2420, v_x_2415, v_next_2457, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_file_2420 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_t_2417 = heff_env(self)[2];
  V v_fuel_2416 = heff_env(self)[3];
  V v_outPath_2419 = heff_env(self)[4];
  V v_x_2415 = heff_env(self)[5];
  V v_next_2457 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2459, heff_dup(v_file_2420), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam9, 1, 8, (V[]){v_p_246, v_t_2417, v_fuel_2416, v_outPath_2419, v_file_2420, v_x_2415, v_next_2457, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_fuel_2416 = heff_dup(heff_rfield(v_a_244, 3));
  V v_t_2417 = heff_dup(heff_rfield(v_a_244, 1));
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_outPath_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str2));
  V v_file_2420 = (g_heff_2ebuild_2ecommands_2eappFile(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str3)));
  heff_clo_take(self, 8);
  V v_st_2421 = v_st_240;
  V v_t_2422 = v_t_241;
  V v_p_2423 = heff_dup(v_x_2411);
  V v_x_2424 = v_x_243;
  V v_a_2425 = v_a_244;
  V v_next_2431 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam4, 2, 2, (V[]){v_x_2411, v_next_245});
  V v_st_2432 = heff_dup(v_st_2421);
  V v_t_2433 = heff_dup(v_t_2422);
  V v_a_2434 = v_a_2425;
  V v_includeDirs_2435 = heff_take_field(v_a_2434, 4);
  V v_libDirs_2436 = heff_get_n(v_a_2434, 5, 6);
  V v_t_2442 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam6, 1, 2, (V[]){heff_dup(v_st_2432), heff_dup(v_t_2433)}), v_includeDirs_2435));
  V v_t_2448 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam7, 1, 2, (V[]){v_st_2432, v_t_2433}), v_libDirs_2436));
  V v_t_2449 = (g_prelude_2e_2b_2b(v_t_2442, v_t_2448));
  V v_t_2450 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_2421), heff_dup(v_t_2422), heff_dup(v_x_2424)));
  V v_a_2451 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_2421), heff_dup(v_t_2422), heff_dup(v_x_2424)));
  V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2421), v_a_2451));
  V v_t_2453 = (g_std_2epath_2eparse(heff_dup(v_st_2421), v_x_2424));
  V v_t_2454 = (g_std_2epath_2ejoin(v_t_2452, v_t_2453));
  V v_t_2455 = ({ V a_0 = v_st_2421; V a_1 = v_t_2454; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2454); r_; });
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2422, 5, 6), v_t_2449});
  V v_next_2457 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s883396168x1315037587(MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str6), v_st_2421, v_t_2456, v_p_2423, v_t_2450, v_t_2455, v_next_2431));
  V v_c_2458 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  V f_ = v_c_2458;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam8, 1, 8, (V[]){v_file_2420, v_p_246, v_t_2417, v_fuel_2416, v_outPath_2419, v_x_2415, v_next_2457, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2411), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s535099379x685970669(v_t_2414, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam3, 1, 8, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2411, v_next_245, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam13(V self, V *args) {
  V v_t_2470 = args[0];
  return v_t_2470;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam15(V self, V *args) {
  V v_t_2474 = args[0];
  return v_t_2474;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam17(V self, V *args) {
  V v_r_2481 = args[0];
  return v_r_2481;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam18(V self, V *args) {
  V v_x_2488 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_2477 = heff_env(self)[4];
  V v_x_2473 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  switch (heff_tag_of(v_x_2488)) {
  case TAG_Left: {
    V v_x_2489 = heff_field(v_x_2488, 0);
    V v_ru_24x_2488_24Left = heff_take_reuse_n(v_x_2488, 1ULL, 1);
    heff_clo_take(self, 9);
    return ({ V a_0 = v_a_244; V a_1 = v_x_243; V a_2 = v_st_240; V a_3 = v_t_241; V a_4 = v_x_2477; V a_5 = v_x_2473; V a_6 = v_next_245; V a_7 = v_p_246; V a_8 = v_p_247; V b_9 = heff_tag_re_n(v_ru_24x_2488_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2489}); V r_ = (g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
  }
  case TAG_Right: {
    V v_y_2490 = heff_field(v_x_2488, 0);
    V v_ru_24x_2488_24Right = heff_take_reuse_n(v_x_2488, 1ULL, 1);
    switch (heff_tag_of(v_y_2490)) {
    case TAG_Left: {
      V v_err_2491 = heff_field(v_y_2490, 0);
      V v_ru_24y_2490_24Left = heff_take_reuse_n(v_y_2490, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2488_24Right, 1);
      heff_clo_take(self, 9);
      return ({ V a_0 = v_a_244; V a_1 = v_x_243; V a_2 = v_st_240; V a_3 = v_t_241; V a_4 = v_x_2477; V a_5 = v_x_2473; V a_6 = v_next_245; V a_7 = v_p_246; V a_8 = v_p_247; V b_9 = heff_tag_re_n(v_ru_24y_2490_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2491}); V r_ = (g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
    }
    case TAG_Right: {
      V v_x_2492 = heff_field(v_y_2490, 0);
      heff_take_n(v_y_2490, 1ULL, 1);
      heff_clo_take(self, 9);
      return ({ V a_0 = v_a_244; V a_1 = v_x_243; V a_2 = v_st_240; V a_3 = v_t_241; V a_4 = v_x_2477; V a_5 = v_x_2473; V a_6 = v_next_245; V a_7 = v_p_246; V a_8 = v_p_247; V b_9 = heff_tag_at_n(v_ru_24x_2488_24Right, TAG_Right, 1, (V[]){v_x_2492}); V r_ = (g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
    }
    default: return heff_nomatch(v_y_2490);
    }
  }
  default: return heff_nomatch(v_x_2488);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam16(V self, V *args) {
  V v_x_2477 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_x_2473 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_s_2478 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_path_2479 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2478));
  V v_t_2480 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2479; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2479); r_; });
  V v_a_2482 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2480, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam17_clo)});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
  heff_clo_take(self, 8);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2487, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam18, 1, 9, (V[]){v_a_244, v_x_243, v_st_240, v_t_241, v_x_2477, v_x_2473, v_next_245, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam14(V self, V *args) {
  V v_x_2473 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2473), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_str7), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam15_clo)})});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s535099379x685970669(v_t_2476, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam16, 1, 8, (V[]){v_st_240, v_t_241, v_x_243, v_p_246, v_a_244, v_x_2473, v_next_245, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam20(V self, V *args) {
  V v_x_24103 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_drop(v_x_24103);
  heff_clo_take(self, 3);
  V f_ = v_next_245;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam19(V self, V *args) {
  V v_x_24100 = args[0];
  V v_bp_242 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_drop(v_x_24100);
  heff_clo_take(self, 4);
  V v_t_24101 = heff_tag_n(TAG_Complete, 2, (V[]){v_bp_242, NTAG(TAG_MkUnit)});
  V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24102}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_lam20, 1, 3, (V[]){v_next_245, v_p_246, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_str1, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    return heff_dup(v_next_243);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_build_247 = heff_dup(heff_rfield(v_a_245, 1));
    V v_name_248 = heff_dup(heff_rfield(v_a_245, 0));
    V v_t_249 = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890(v_st_240, v_t_241, v_pl_242, v_next_243, v_rest_246));
    V v_t_2411;
    if (heff_strEq_c(heff_get_n(v_build_247, 0, 6), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_str0))) {
      v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_name_248)});
    } else {
      V v_t_2410 = heff_dup(heff_rfield(v_t_241, 3));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(heff_dup(v_name_248), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_str1))});
      } else {
        heff_drop(v_t_2410);
        v_t_2411 = NTAG(TAG_Nothing);
      }
    }
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_clo), 6, (V[]){heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_pl_242), v_t_249, v_name_248, v_t_2411});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s1897687767x1048406890(a0, a1, a2, a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str5, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str7, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str11, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str13, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str15, 3, "app");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186(V v_st_240, V v_cmd_241, V v_t_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_t_248 = ({ V a_0 = v_st_240; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(v_t_249, NTAG(TAG_Nil)));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam0, 1, 5, (V[]){v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam1(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam7(V self, V *args) {
  V v_r_2459 = args[0];
  return v_r_2459;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam9(V self, V *args) {
  V v_n_2471 = args[0];
  V v_path_2457 = heff_env(self)[0];
  V v_t_2472 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2471));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_2457, v_t_2472));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam8(V self, V *args) {
  V v_x_2466 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_path_2457 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2466)) {
  case TAG_Left: {
    V v_x_2467 = heff_field(v_x_2466, 0);
    V v_ru_24x_2466_24Left = heff_take_reuse_n(v_x_2466, 1ULL, 1);
    heff_clo_take(self, 6);
    heff_drop(v_path_2457);
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_2ek_24l0(v_z_243, v_st_240, v_t_242, v_cmd_241, v_z_244, heff_tag_re_n(v_ru_24x_2466_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2467})));
  }
  case TAG_Right: {
    V v_y_2468 = heff_field(v_x_2466, 0);
    V v_ru_24x_2466_24Right = heff_take_reuse_n(v_x_2466, 1ULL, 1);
    switch (heff_tag_of(v_y_2468)) {
    case TAG_Left: {
      V v_err_2469 = heff_field(v_y_2468, 0);
      V v_ru_24y_2468_24Left = heff_take_reuse_n(v_y_2468, 1ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_path_2457);
      heff_drop_cell(v_ru_24x_2466_24Right, 1);
      return (g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_2ek_24l0(v_z_243, v_st_240, v_t_242, v_cmd_241, v_z_244, heff_tag_re_n(v_ru_24y_2468_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2469})));
    }
    case TAG_Right: {
      V v_x_2470 = heff_field(v_y_2468, 0);
      heff_take_n(v_y_2468, 1ULL, 1);
      heff_clo_take(self, 6);
      V v_x_2473 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam9, 1, 1, (V[]){v_path_2457}), v_x_2470));
      V v_x_2474 = (g_list_2emap_24s219049803x1458391381(v_x_2473));
      return (g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_2ek_24l0(v_z_243, v_st_240, v_t_242, v_cmd_241, v_z_244, heff_tag_at_n(v_ru_24x_2466_24Right, TAG_Right, 1, (V[]){v_x_2474})));
    }
    default: return heff_nomatch(v_y_2468);
    }
  }
  default: return heff_nomatch(v_x_2466);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_drop(v_x_2452);
  V v_t_2453 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2454 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str15)));
  V v_t_2455 = (g_std_2epath_2ejoin(v_t_2453, v_t_2454));
  V v_s_2456 = ({ V a_0 = v_st_240; V a_1 = v_t_2455; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2455); r_; });
  V v_path_2457 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2456));
  V v_t_2458 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2457; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2460 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2458, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam7_clo)});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
  heff_clo_take(self, 5);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2465, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam8, 1, 6, (V[]){v_z_243, v_st_240, v_t_242, v_cmd_241, v_z_244, v_path_2457})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_errors_2419 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_seen_2420 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  heff_drop(v_x_2423);
  if (heff_intLt_c_lent(MK_INT(0LL), v_errors_2419, 1)) {
    heff_clo_take(self, 7);
    heff_drop(v_seen_2420);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    V v_n_2424 = v_errors_2419;
    V v_t_2425;
    if (heff_intEq_c_lent(v_n_2424, MK_INT(1LL), 2)) {
      heff_drop(v_n_2424);
      v_t_2425 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str2);
    } else {
      v_t_2425 = heff_strAppend(heff_intShow(v_n_2424), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str3));
    }
    V v_what_2426 = heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str4));
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str5), v_cmd_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str6));
    V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, v_what_2426), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str7));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str8)), NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam5, 1, 2, (V[]){v_z_243, v_z_244})));
  } else {
    heff_clo_take(self, 7);
    heff_drop(v_errors_2419);
    V v_n_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_seen_2420; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_seen_2420); r_; });
    V v_t_2443;
    if (heff_intEq_c_lent(v_n_2442, MK_INT(1LL), 2)) {
      heff_drop(v_n_2442);
      v_t_2443 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str9);
    } else {
      v_t_2443 = heff_strAppend(heff_intShow(v_n_2442), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str10));
    }
    V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str11), heff_dup(v_cmd_241)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str12));
    V v_str_2445 = heff_strAppend(heff_strAppend(v_t_2444, v_t_2443), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str13));
    V v_t_2446 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2445, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str14)), NTAG(TAG_MkUnit)});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam6, 1, 5, (V[]){v_st_240, v_t_242, v_z_243, v_cmd_241, v_z_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_errors_2419 = heff_take_field(v_x_2418, 1);
  V v_seen_2420 = heff_get_n(v_x_2418, 0, 2);
  heff_clo_take(self, 6);
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam4, 1, 7, (V[]){v_errors_2419, v_cmd_241, v_z_243, v_z_244, v_seen_2420, v_st_240, v_t_242})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_t_2417 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  heff_clo_take(self, 6);
  return ({ V a_0 = heff_dup(v_x_2416); V a_1 = v_t_2417; V a_2 = v_x_2411; V a_3 = heff_dup(v_z_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam3, 1, 6, (V[]){v_x_2416, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242}); V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2411); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_total_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2411));
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_str1), v_total_2412, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam1_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  heff_clo_take(self, 5);
  return (g_co_2eop_24s535099379x685970669(v_t_2415, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s2077037117x1177867186_lam2, 1, 6, (V[]){v_x_2411, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_str0, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam1(V self, V *args);

static V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_st;
static V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_init(void) {
  V v_path_240 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_str0)));
  V v_t_241 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_240); r_; });
  V v_a_243 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam1, 2, 1, (V[]){v_a_243});
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_st)) return g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_val, &g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_st, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_init);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam0(V self, V *args) {
  V v_r_242 = args[0];
  return v_r_242;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_x_2412 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    heff_clo_take(self, 2);
    return (g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0(v_hd_244, v_k_245, heff_tag_re_n(v_ru_24x_2411_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2412})));
  }
  case TAG_Right: {
    V v_y_2413 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Right = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    switch (heff_tag_of(v_y_2413)) {
    case TAG_Left: {
      V v_err_2414 = heff_field(v_y_2413, 0);
      V v_ru_24y_2413_24Left = heff_take_reuse_n(v_y_2413, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2411_24Right, 1);
      heff_clo_take(self, 2);
      return (g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0(v_hd_244, v_k_245, heff_tag_re_n(v_ru_24y_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2414})));
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_y_2413, 0);
      heff_take_n(v_y_2413, 1ULL, 1);
      heff_clo_take(self, 2);
      return (g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_2ek_24l0(v_hd_244, v_k_245, heff_tag_at_n(v_ru_24x_2411_24Right, TAG_Right, 1, (V[]){v_x_2415})));
    }
    default: return heff_nomatch(v_y_2413);
    }
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_243})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2410, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1577360515x2061470467_lam2, 1, 2, (V[]){v_hd_244, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str5, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str7, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str11, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str13, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str15, 3, "app");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599(V v_st_240, V v_cmd_241, V v_t_242, V v_none_243, V v_done_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str0)));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_t_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_c_2412 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(v_t_2411, NTAG(TAG_Nil)));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam0, 1, 7, (V[]){v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam1(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam7(V self, V *args) {
  V v_r_2461 = args[0];
  return v_r_2461;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam9(V self, V *args) {
  V v_n_2473 = args[0];
  V v_path_2459 = heff_env(self)[0];
  V v_t_2474 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2473));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_2459, v_t_2474));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam8(V self, V *args) {
  V v_x_2468 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_path_2459 = heff_env(self)[7];
  switch (heff_tag_of(v_x_2468)) {
  case TAG_Left: {
    V v_x_2469 = heff_field(v_x_2468, 0);
    V v_ru_24x_2468_24Left = heff_take_reuse_n(v_x_2468, 1ULL, 1);
    heff_clo_take(self, 8);
    heff_drop(v_path_2459);
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0(v_z_245, v_st_240, v_t_242, v_cmd_241, v_z_246, v_none_243, v_done_244, heff_tag_re_n(v_ru_24x_2468_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2469})));
  }
  case TAG_Right: {
    V v_y_2470 = heff_field(v_x_2468, 0);
    V v_ru_24x_2468_24Right = heff_take_reuse_n(v_x_2468, 1ULL, 1);
    switch (heff_tag_of(v_y_2470)) {
    case TAG_Left: {
      V v_err_2471 = heff_field(v_y_2470, 0);
      V v_ru_24y_2470_24Left = heff_take_reuse_n(v_y_2470, 1ULL, 1);
      heff_clo_take(self, 8);
      heff_drop(v_path_2459);
      heff_drop_cell(v_ru_24x_2468_24Right, 1);
      return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0(v_z_245, v_st_240, v_t_242, v_cmd_241, v_z_246, v_none_243, v_done_244, heff_tag_re_n(v_ru_24y_2470_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2471})));
    }
    case TAG_Right: {
      V v_x_2472 = heff_field(v_y_2470, 0);
      heff_take_n(v_y_2470, 1ULL, 1);
      heff_clo_take(self, 8);
      V v_x_2475 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam9, 1, 1, (V[]){v_path_2459}), v_x_2472));
      V v_x_2476 = (g_list_2emap_24s219049803x1458391381(v_x_2475));
      return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_2ek_24l0(v_z_245, v_st_240, v_t_242, v_cmd_241, v_z_246, v_none_243, v_done_244, heff_tag_at_n(v_ru_24x_2468_24Right, TAG_Right, 1, (V[]){v_x_2476})));
    }
    default: return heff_nomatch(v_y_2470);
    }
  }
  default: return heff_nomatch(v_x_2468);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam6(V self, V *args) {
  V v_x_2454 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_drop(v_x_2454);
  V v_t_2455 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2456 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str15)));
  V v_t_2457 = (g_std_2epath_2ejoin(v_t_2455, v_t_2456));
  V v_s_2458 = ({ V a_0 = v_st_240; V a_1 = v_t_2457; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2457); r_; });
  V v_path_2459 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2458));
  V v_t_2460 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2459; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2462 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2460, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam7_clo)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2467, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam8, 1, 8, (V[]){v_z_245, v_st_240, v_t_242, v_cmd_241, v_z_246, v_none_243, v_done_244, v_path_2459})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_errors_2421 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_seen_2422 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_none_243 = heff_env(self)[7];
  V v_done_244 = heff_env(self)[8];
  heff_drop(v_x_2425);
  if (heff_intLt_c_lent(MK_INT(0LL), v_errors_2421, 1)) {
    heff_clo_take(self, 9);
    heff_drop(v_seen_2422);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_none_243);
    heff_drop(v_done_244);
    V v_n_2426 = v_errors_2421;
    V v_t_2427;
    if (heff_intEq_c_lent(v_n_2426, MK_INT(1LL), 2)) {
      heff_drop(v_n_2426);
      v_t_2427 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str2);
    } else {
      v_t_2427 = heff_strAppend(heff_intShow(v_n_2426), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str3));
    }
    V v_what_2428 = heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str4));
    V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str5), v_cmd_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str6));
    V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, v_what_2428), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str7));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str8)), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam5, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    heff_clo_take(self, 9);
    heff_drop(v_errors_2421);
    V v_n_2444 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_seen_2422; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_seen_2422); r_; });
    V v_t_2445;
    if (heff_intEq_c_lent(v_n_2444, MK_INT(1LL), 2)) {
      heff_drop(v_n_2444);
      v_t_2445 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str9);
    } else {
      v_t_2445 = heff_strAppend(heff_intShow(v_n_2444), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str10));
    }
    V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str11), heff_dup(v_cmd_241)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str12));
    V v_str_2447 = heff_strAppend(heff_strAppend(v_t_2446, v_t_2445), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str13));
    V v_t_2448 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2447, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str14)), NTAG(TAG_MkUnit)});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam6, 1, 7, (V[]){v_st_240, v_t_242, v_z_245, v_cmd_241, v_z_246, v_none_243, v_done_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  V v_errors_2421 = heff_take_field(v_x_2420, 1);
  V v_seen_2422 = heff_get_n(v_x_2420, 0, 2);
  heff_clo_take(self, 8);
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam4, 1, 9, (V[]){v_errors_2421, v_cmd_241, v_z_245, v_z_246, v_seen_2422, v_st_240, v_t_242, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  V v_t_2419 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  heff_clo_take(self, 8);
  return ({ V a_0 = heff_dup(v_x_2418); V a_1 = v_t_2419; V a_2 = v_x_2413; V a_3 = heff_dup(v_z_245); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam3, 1, 8, (V[]){v_x_2418, v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244}); V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_total_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2413));
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_str1), v_total_2414, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam1_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s535099379x685970669(v_t_2417, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1469829783x1547337599_lam2, 1, 8, (V[]){v_x_2413, v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s1841671598x1987604613(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam1(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_x_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    heff_clo_take(self, 3);
    return (g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0(v_x_242, v_hd_240, v_k_241, heff_tag_re_n(v_ru_24x_2412_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2413})));
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2414)) {
    case TAG_Left: {
      V v_err_2415 = heff_field(v_y_2414, 0);
      V v_ru_24y_2414_24Left = heff_take_reuse_n(v_y_2414, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2412_24Right, 1);
      heff_clo_take(self, 3);
      return (g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0(v_x_242, v_hd_240, v_k_241, heff_tag_re_n(v_ru_24y_2414_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2415})));
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_y_2414, 0);
      heff_take_n(v_y_2414, 1ULL, 1);
      heff_clo_take(self, 3);
      return (g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_2ek_24l0(v_x_242, v_hd_240, v_k_241, heff_tag_at_n(v_ru_24x_2412_24Right, TAG_Right, 1, (V[]){v_x_2416})));
    }
    default: return heff_nomatch(v_y_2414);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_242)));
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_243); r_; });
  V v_a_246 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam1_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2411, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1740819745x232228206_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str0, 5, "=def ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str2, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str3, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str4, 4, "=ty ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str5, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str6, 20, "<no such definition>");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str7, 6, "=body ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 14);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2edefKind(heff_dup(v_c_240), v_k_244));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str0), heff_dup(v_k_244)), ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str1));
    V v_t_248 = heff_strAppend(v_t_247, v_t_246);
    V v_t_249 = heff_dup(heff_rfield(v_c_240, 5));
    V v_k_2410 = heff_dup(v_k_244);
    V v_g_2411 = heff_get_n(v_t_249, 0, 10);
    V v_entries_2412 = heff_take_field(v_g_2411, 1);
    V v_aliases_2413 = heff_get_n(v_g_2411, 2, 8);
    HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2412, v_k_2410));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      V v_t_2426;
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_k_2410);
        heff_drop(v_entries_2412);
        heff_drop(v_aliases_2413);
        V v_e_2417 = v_field_2416;
        v_t_2426 = ({ V b_0 = heff_get_n(v_e_2417, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_field_2416);
        HeffT2 v_t_2418 = ({ V a_0 = v_aliases_2413; V a_1 = v_k_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2413); heff_drop(v_k_2410); r_; });
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_k2_2421 = v_field_2420;
            HeffT2 v_t_2422 = ({ V a_0 = v_entries_2412; V a_1 = v_k2_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2412); heff_drop(v_k2_2421); r_; });
            {
              V v_field_2424 = v_t_2422.f[1];
              int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
              if ((v_tag_2423 == ((int64_t)0ULL))) {
                V v_e_2425 = v_field_2424;
                v_t_2426 = ({ V b_0 = heff_get_n(v_e_2425, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
              } else {
                heff_drop(v_field_2424);
                v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str2);
              }
            }
          } else {
            heff_drop(v_entries_2412);
            heff_drop(v_field_2420);
            v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str3);
          }
        }
      }
      V v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str4), v_t_2426);
      V v_t_2428 = heff_dup(heff_rfield(v_c_240, 5));
      V v_k_2429 = v_k_244;
      V v_g_2430 = heff_get_n(v_t_2428, 0, 10);
      V v_entries_2431 = heff_take_field(v_g_2430, 1);
      V v_aliases_2432 = heff_get_n(v_g_2430, 2, 8);
      HeffT2 v_t_2433 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2431, v_k_2429));
      {
        V v_field_2435 = v_t_2433.f[1];
        int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
        V v_t_2445;
        if ((v_tag_2434 == ((int64_t)0ULL))) {
          heff_drop(v_k_2429);
          heff_drop(v_entries_2431);
          heff_drop(v_aliases_2432);
          V v_e_2436 = v_field_2435;
          v_t_2445 = ({ V b_0 = heff_get_n(v_e_2436, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
        } else {
          heff_drop(v_field_2435);
          HeffT2 v_t_2437 = ({ V a_0 = v_aliases_2432; V a_1 = v_k_2429; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2432); heff_drop(v_k_2429); r_; });
          {
            V v_field_2439 = v_t_2437.f[1];
            int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
            if ((v_tag_2438 == ((int64_t)0ULL))) {
              V v_k2_2440 = v_field_2439;
              HeffT2 v_t_2441 = ({ V a_0 = v_entries_2431; V a_1 = v_k2_2440; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2431); heff_drop(v_k2_2440); r_; });
              {
                V v_field_2443 = v_t_2441.f[1];
                int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                if ((v_tag_2442 == ((int64_t)0ULL))) {
                  V v_e_2444 = v_field_2443;
                  v_t_2445 = ({ V b_0 = heff_get_n(v_e_2444, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
                } else {
                  heff_drop(v_field_2443);
                  v_t_2445 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str5);
                }
              }
            } else {
              heff_drop(v_entries_2431);
              heff_drop(v_field_2439);
              v_t_2445 = ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str6);
            }
          }
        }
        V v_t_2446 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str7), v_t_2445);
        return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam1, 2, 5, (V[]){v_t_2427, v_t_2446, v_c_240, v_rest_245, v_t_248});
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam2(V self, V *args) {
  V v_x_2452 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2447 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  heff_drop(v_x_2452);
  heff_clo_take(self, 4);
  V v_t_2453 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042(v_c_240, v_rest_245));
  V f_ = v_t_2453;
  heff_room[0] = v_hd_2447;
  heff_room[1] = v_k_2448;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam4(V self, V *args) {
  V v_x_2465 = args[0];
  V v_g_2463 = heff_env(self)[0];
  V v_hd_2462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2466 = heff_tr(heff_call(v_g_2463, 1, (V[]){v_x_2465}));
  V f_ = heff_get_n(v_hd_2462, 0, 3);
  args[0] = v_t_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam3(V self, V *args) {
  V v_g_2463 = args[0];
  V v_m_2464 = args[1];
  V v_hd_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2462, 1));
  args[0] = v_m_2464;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam4, 1, 2, (V[]){v_g_2463, v_hd_2462});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam5(V self, V *args) {
  V v_c_2467 = args[0];
  V v_hd_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2467;
  heff_room[0] = heff_dup(v_hd_2462);
  heff_room[1] = heff_get_n(v_hd_2462, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam8(V self, V *args) {
  V v_x_2484 = args[0];
  V v_g_2482 = heff_env(self)[0];
  V v_hd_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_tr(heff_call(v_g_2482, 1, (V[]){v_x_2484}));
  V f_ = heff_get_n(v_hd_2481, 0, 3);
  args[0] = v_t_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam7(V self, V *args) {
  V v_g_2482 = args[0];
  V v_m_2483 = args[1];
  V v_hd_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2481, 1));
  args[0] = v_m_2483;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam8, 1, 2, (V[]){v_g_2482, v_hd_2481});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam9(V self, V *args) {
  V v_c_2486 = args[0];
  V v_hd_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2486;
  heff_room[0] = heff_dup(v_hd_2481);
  heff_room[1] = heff_get_n(v_hd_2481, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam11(V self, V *args) {
  V v_x_2496 = args[0];
  V v_lit_2473 = heff_env(self)[0];
  heff_drop(v_x_2496);
  heff_clo_take(self, 1);
  V f_ = v_lit_2473;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam10(V self, V *args) {
  V v_a_2489 = args[0];
  V v_lit_2471 = heff_env(self)[0];
  V v_lit_2472 = heff_env(self)[1];
  V v_lit_2473 = heff_env(self)[2];
  heff_drop(v_a_2489);
  heff_clo_take(self, 3);
  V v_t_2490 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_lit_2471, ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str10)), NTAG(TAG_MkUnit)});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_lit_2472, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam11, 1, 1, (V[]){v_lit_2473})));
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam6(V self, V *args) {
  V v_a_2470 = args[0];
  V v_lit_2450 = heff_env(self)[0];
  V v_lit_2451 = heff_env(self)[1];
  V v_lit_2454 = heff_env(self)[2];
  V v_lit_2449 = heff_env(self)[3];
  heff_drop(v_a_2470);
  heff_clo_take(self, 4);
  V v_lit_2471 = v_lit_2450;
  V v_lit_2472 = heff_dup(v_lit_2451);
  V v_lit_2473 = v_lit_2454;
  V v_t_2474 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_lit_2449, ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str9)), NTAG(TAG_MkUnit)});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  V v_p_2480 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2479});
  V v_hd_2481 = v_lit_2451;
  V v_t_2487 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam7, 2, 1, (V[]){heff_dup(v_hd_2481)})}), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam9, 1, 1, (V[]){heff_dup(v_hd_2481)}), v_p_2480}));
  V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_2481, 2), 1, (V[]){v_t_2487}));
  V f_ = heff_get_n(v_hd_2481, 1, 3);
  heff_room[0] = v_t_2488;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam10, 1, 3, (V[]){v_lit_2471, v_lit_2472, v_lit_2473});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam1(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_t_2446 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_t_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_lit_2449 = v_t_2427;
  V v_lit_2450 = v_t_2446;
  V v_lit_2451 = heff_dup(v_hd_2447);
  V v_lit_2454 = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam2, 1, 4, (V[]){v_c_240, v_rest_245, heff_dup(v_hd_2447), v_k_2448});
  V v_t_2455 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_str8)), NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  V v_p_2461 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2460});
  V v_hd_2462 = v_hd_2447;
  V v_t_2468 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam3, 2, 1, (V[]){heff_dup(v_hd_2462)})}), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam5, 1, 1, (V[]){heff_dup(v_hd_2462)}), v_p_2461}));
  V v_t_2469 = heff_tr(heff_call(heff_take_field(v_hd_2462, 2), 1, (V[]){v_t_2468}));
  V f_ = heff_get_n(v_hd_2462, 1, 3);
  args[0] = v_t_2469;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042_lam6, 1, 4, (V[]){v_lit_2450, v_lit_2451, v_lit_2454, v_lit_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_str1, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688(V v_x1_240, V v_bad_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_list_2emap_24f1730403549x1479772376(MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_str0), MK_INT(0LL), MK_INT(97LL), MK_INT(0LL), MK_INT(0LL), MK_INT(122LL), MK_INT(65LL), MK_INT(0LL), MK_INT(0LL), MK_INT(90LL), heff_dup(heff_rfield(v_c_244, 7))));
    V v_c_247 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s357186076x574774042(heff_dup(v_c_244), v_t_246));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_lam0, 1, 5, (V[]){heff_dup(v_c_244), v_z_242, heff_dup(v_rest_245), v_bad_241, v_z_243})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2410); V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_drop(v_x_248);
  heff_clo_take(self, 5);
  V v_t_249 = (g_list_2emap_24s328934344x1728860012(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_str1), heff_take_field(v_c_244, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(heff_get_n(v_c_244, 0, 14), v_t_249, MK_INT(0LL), heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s2136117850x864231688_lam1, 1, 4, (V[]){v_rest_245, v_bad_241, v_z_242, v_z_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1(V v_tok_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_str0), v_e_244), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_str1));
    V v_t_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_WriteErr, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s1014403878x489449937(v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_p_242));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1(a[0], a[1], a[2], a[3]);
}