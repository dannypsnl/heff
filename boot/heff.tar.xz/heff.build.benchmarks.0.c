// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailedWith 25914
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Measured 52135
#define TAG_Nanos 3335
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_SkippedWith 54656
#define TAG_TimedOut 6056
#define TAG_Times 15230
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_count 296209705
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_json 9767343
#define LBL_keep 9783372
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_ran 322201
#define LBL_root 10001833
#define LBL_style 311138763
#define LBL_time 10055572
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get(void);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_clo;
V g_heff_2ebuild_2ebenchmarks_2edecimalParts(V, V);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_clo;
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_clo;
V g_heff_2ebuild_2ebenchmarks_2eperOp(V, V);
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo;
V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo;
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528_clo;
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_clo;
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_clo;
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces(V);
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V, V);
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo;
V g_heff_2ebuild_2ebenchmarks_2etenTo(V);
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo;
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_clo;
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V, V);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2eskipSpace(V, V);
V g_json_2eskipSpace_entry(V self, V *a);
extern Clo g_json_2eskipSpace_clo;
HeffT2 g_json_2esteps_24cpr(V, V);
V g_json_2esteps_2evalueAt_240(V, V, V);
V g_json_2esteps_2evalueAt_240_entry(V self, V *a);
extern Clo g_json_2esteps_2evalueAt_240_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eall_24s2093734251x1702493483(V, V, V, V);
V g_list_2eall_24s2093734251x1702493483_entry(V self, V *a);
extern Clo g_list_2eall_24s2093734251x1702493483_clo;
HeffT2 g_list_2efind_24s1136367117x833793205_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24f1221993074x1235215335(V, V, V);
V g_list_2efoldl_24f1221993074x1235215335_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1221993074x1235215335_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s141260856x1366916752(V, V, V, V, V);
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a);
extern Clo g_list_2efoldl_24s141260856x1366916752_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s849938259x51049885(V);
V g_list_2emap_24s849938259x51049885_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2etenTo_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2etenTo(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(10LL), v_t_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2etenTo(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5, 2, 0};
Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2edecimalParts(V v_unit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_2421;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_w_242, 0)))) {
        int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_w_242, 0)) - ((int64_t)1ULL));
        V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_244)));
        V v_t_246 = ({ V a_0 = MK_INT(48LL); V a_1 = v_w_242; V a_2 = MK_INT(57LL); V a_3 = v_t_245; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          HeffT2 v_t_247 = (g_prelude_2eparseInt_24cpr(v_w_242));
          {
            V v_field_249 = v_t_247.f[1];
            V v_tag_248 = heff_box_i64(((int64_t)v_t_247.f[0]));
            v_t_2421 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0, 2, 3, (V[]){v_tag_248, v_field_249, v_unit_240});
          }
        } else {
          heff_drop(v_unit_240);
          heff_drop(v_t_246);
          v_t_2421 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1_clo);
        }
      } else {
        heff_drop(v_unit_240);
        v_t_2421 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2_clo);
      }
      return heff_tail(v_t_2421, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), MK_INT(0LL)});
    }
    case TAG_Cons: {
      V v_f_2422 = heff_field(v_x22_243, 0);
      V v_x222_2423 = heff_field(v_x22_243, 1);
      switch (heff_tag_of(v_x222_2423)) {
      case TAG_Nil: {
        V v_t_2441;
        if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_w_242, 0)))) {
          int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_w_242, 0)) - ((int64_t)1ULL));
          V v_t_2425 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_2424)));
          V v_t_2426 = ({ V a_0 = MK_INT(48LL); V a_1 = v_w_242; V a_2 = MK_INT(57LL); V a_3 = v_t_2425; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
          if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
            heff_drop(v_t_2426);
            HeffT2 v_t_2427 = (g_prelude_2eparseInt_24cpr(v_w_242));
            {
              V v_field_2429 = v_t_2427.f[1];
              V v_tag_2428 = heff_box_i64(((int64_t)v_t_2427.f[0]));
              v_t_2441 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3, 2, 3, (V[]){v_tag_2428, v_field_2429, v_unit_240});
            }
          } else {
            heff_drop(v_unit_240);
            heff_drop(v_t_2426);
            v_t_2441 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4_clo);
          }
        } else {
          heff_drop(v_unit_240);
          v_t_2441 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5_clo);
        }
        V v_t_2445;
        if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_f_2422, 0)))) {
          int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_f_2422, 0)) - ((int64_t)1ULL));
          V v_t_2443 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_2442)));
          V v_t_2444 = ({ V a_0 = MK_INT(48LL); V a_1 = v_f_2422; V a_2 = MK_INT(57LL); V a_3 = v_t_2443; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_2443); r_; });
          if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
            heff_drop(v_t_2444);
            v_t_2445 = (g_prelude_2eparseInt(v_f_2422));
          } else {
            heff_drop(v_t_2444);
            v_t_2445 = NTAG(TAG_Nothing);
          }
        } else {
          v_t_2445 = NTAG(TAG_Nothing);
        }
        return heff_tail(v_t_2441, 2, (V[]){v_t_2445, heff_strLength_lent(v_f_2422, 0)});
      }
      case TAG_Cons: {
        heff_drop(v_unit_240);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x222_2423);
      }
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2edecimalParts(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0(V self, V *args) {
  V v_x3_2410 = args[0];
  V v_places_2411 = args[1];
  V v_tag_248 = heff_env(self)[0];
  V v_field_249 = heff_env(self)[1];
  V v_unit_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_248) == ((int64_t)0ULL))) {
    V v_w_2412 = v_field_249;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      heff_drop(v_places_2411);
      heff_drop(v_unit_240);
      heff_drop(v_w_2412);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_f_2413 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Just = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      V v_t_2414 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_places_2411));
      V v_t_2415 = heff_intDiv(heff_intMul_lent(v_f_2413, v_unit_240, 1), v_t_2414);
      V v_t_2416 = heff_intAdd(heff_intMul(v_w_2412, v_unit_240), v_t_2415);
      return heff_tag_at_n(v_ru_24x3_2410_24Just, TAG_Just, 1, (V[]){v_t_2416});
    }
    default: return heff_nomatch(v_x3_2410);
    }
  } else {
    heff_drop(v_x3_2410);
    heff_drop(v_places_2411);
    heff_drop(v_field_249);
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1(V self, V *args) {
  V v_x3_2417 = args[0];
  V v_places_2418 = args[1];
  heff_drop(v_x3_2417);
  heff_drop(v_places_2418);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2(V self, V *args) {
  V v_x3_2419 = args[0];
  V v_places_2420 = args[1];
  heff_drop(v_x3_2419);
  heff_drop(v_places_2420);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3(V self, V *args) {
  V v_x3_2430 = args[0];
  V v_places_2431 = args[1];
  V v_tag_2428 = heff_env(self)[0];
  V v_field_2429 = heff_env(self)[1];
  V v_unit_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_2428) == ((int64_t)0ULL))) {
    V v_w_2432 = v_field_2429;
    switch (heff_tag_of(v_x3_2430)) {
    case TAG_Nothing: {
      heff_drop(v_places_2431);
      heff_drop(v_unit_240);
      heff_drop(v_w_2432);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_f_2433 = heff_field(v_x3_2430, 0);
      V v_ru_24x3_2430_24Just = heff_take_reuse_n(v_x3_2430, 1ULL, 1);
      V v_t_2434 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_places_2431));
      V v_t_2435 = heff_intDiv(heff_intMul_lent(v_f_2433, v_unit_240, 1), v_t_2434);
      V v_t_2436 = heff_intAdd(heff_intMul(v_w_2432, v_unit_240), v_t_2435);
      return heff_tag_at_n(v_ru_24x3_2430_24Just, TAG_Just, 1, (V[]){v_t_2436});
    }
    default: return heff_nomatch(v_x3_2430);
    }
  } else {
    heff_drop(v_x3_2430);
    heff_drop(v_places_2431);
    heff_drop(v_field_2429);
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4(V self, V *args) {
  V v_x3_2437 = args[0];
  V v_places_2438 = args[1];
  heff_drop(v_x3_2437);
  heff_drop(v_places_2438);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5(V self, V *args) {
  V v_x3_2439 = args[0];
  V v_places_2440 = args[1];
  heff_drop(v_x3_2439);
  heff_drop(v_places_2440);
  return NTAG(TAG_Nothing);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str1, 1, " ");
Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str0));
  } else {
    V v_s_242 = heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str1));
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_s_242;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2espaces_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str0, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str1, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str3, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str7, 1, "_");
Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaced_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2espaced(V v_s_240) {
top: ;
  V v_x2_241 = (g_prelude_2esplit_2esplitFrom_240(v_s_240, ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str1), v_s_240, MK_INT(0LL), 5), NTAG(TAG_Nil)));
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str3); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = ({ V a_0 = v_s_244; V a_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str5), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_244); r_; });
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str6);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebenchmarks_2espaced(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eperOp_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eperOp_str1, 1, ".");
Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eperOp_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2eperOp(V v_total_240, V v_n_241) {
top: ;
  if (heff_intEq_c_lent(v_total_240, MK_INT(0LL), 2)) {
    heff_drop(v_total_240);
    heff_drop(v_n_241);
    V v_t_242 = (g_heff_2ebuild_2ebenchmarks_2espaces(MK_INT(9LL)));
    return heff_strAppend(v_t_242, ((V)&g_heff_2ebuild_2ebenchmarks_2eperOp_str0));
  } else {
    V v_t_243 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(v_total_240, v_n_241, MK_INT(0LL)));
    V v_x_244 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(v_total_240, v_n_241, MK_INT(0LL)));
    V v_t_245;
    if (heff_intLt_c(MK_INT(0LL), v_x_244)) {
      v_t_245 = MK_INT(1LL);
    } else {
      v_t_245 = MK_INT(0LL);
    }
    V v_n_246 = heff_intAdd(heff_intAdd(MK_INT(10LL), v_t_243), v_t_245);
    V v_places_247 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(v_total_240, v_n_241, MK_INT(0LL)));
    V v_t_248 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(v_total_240, v_n_241, MK_INT(0LL)));
    V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_t_248));
    V v_t_2410 = heff_intMul(heff_intMul(MK_INT(2LL), v_total_240), v_t_249);
    V v_scaled_2411 = heff_intDiv(heff_intAdd_lent(v_t_2410, v_n_241, 1), heff_intMul(MK_INT(2LL), v_n_241));
    V v_s_2417;
    if (heff_intEq_c_lent(v_places_247, MK_INT(0LL), 2)) {
      heff_drop(v_places_247);
      v_s_2417 = heff_intShow(v_scaled_2411);
    } else {
      V v_t_2412 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_dup(v_places_247)));
      V v_t_2413 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_dup(v_places_247)));
      V v_t_2414 = heff_intShow(heff_intMod_lent(v_scaled_2411, v_t_2413, 2));
      V v_t_2415 = ({ V a_0 = v_places_247; V a_1 = v_t_2414; V r_ = (g_heff_2ebuild_2ebenchmarks_2ezeroPadded(a_0, a_1)); heff_drop(v_places_247); r_; });
      V v_t_2416 = heff_intShow(heff_intDiv(v_scaled_2411, v_t_2412));
      v_s_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2ebenchmarks_2eperOp_str1)), v_t_2415);
    }
    V v_t_2418 = heff_intSub(v_n_246, heff_strLength_lent(v_s_2417, 0));
    V v_t_2419 = (g_heff_2ebuild_2ebenchmarks_2espaces(v_t_2418));
    return heff_strAppend(v_t_2419, v_s_2417);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eperOp(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_str0, 13, "heffBenchMain");

static V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st;
static V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_init(void) {
  return ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchMainName_str0);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st)) return g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val, &g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st, g_heff_2ebuild_2ebenchmarks_2ebenchMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str0, 11, ".heff/bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str6, 1, "_");
Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V v_paths_240, V v_file_241) {
top: ;
  V v_style_242 = heff_take_field(v_paths_240, 5);
  V v_root_243 = heff_get_n(v_paths_240, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_root_243));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_d_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  HeffT3 v_t_249 = (g_std_2epath_2eparse_24cpr(heff_dup(v_style_242), v_file_241));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_d_2413 = v_field_2410;
    heff_drop(v_d_2413);
    V v_a_2414 = v_field_2411;
    V v_xs_2415 = v_field_2412;
    V v_xs_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str1); V a_1 = v_a_2414; V a_2 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str2); V a_3 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2415; V r_ = (g_list_2efoldl_24s680990791x1764841948(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_2414); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_x2_2418 = v_t_2417;
    V v_p_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_p_2421 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_p_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_st_2422 = v_style_242;
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_d_248));
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_p_2421));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    return ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str0, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str2, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str3, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str4, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str5, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str6, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str7, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str8, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str9, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str10, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str11, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str12, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str13, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str14, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str15, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str16, 2, "ns");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str17, 6, "allocs");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str18, 5, "bytes");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(V v_j_240) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_j_240)) {
  case TAG_JNull: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_246 = heff_dup(heff_field(v_j_240, 0));
    HeffT2 v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str0); V a_1 = v_fs_246; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_246); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_p_2410 = v_field_249;
        V v_t_2413;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_y_2412 = heff_field(v_p_2410, 1);
          heff_take_n(v_p_2410, 2ULL, 2);
          v_t_2413 = v_y_2412;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        switch (heff_tag_of(v_t_2413)) {
        case TAG_JNull: {
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          V v_i_2415 = heff_field(v_t_2413, 0);
          V v_ru_24t_2413_24JInt = heff_take_reuse_n(v_t_2413, 1ULL, 1);
          v_t_2420 = heff_tag_at_n(v_ru_24t_2413_24JInt, TAG_Just, 1, (V[]){v_i_2415});
          break;
        }
        case TAG_JFloat: {
          double v_x_2416 = heff_tflat_f64(v_t_2413, 0);
          V v_ru_24t_2413_24JFloat = heff_take_reuse_na(v_t_2413, 0ULL, 1);
          v_t_2420 = heff_tag_at_n(v_ru_24t_2413_24JFloat, TAG_Just, 1, (V[]){heff_floor_f64(v_x_2416)});
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2420 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    V v_t_2440;
    switch (heff_tag_of(v_j_240)) {
    case TAG_JNull: {
      v_t_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      v_t_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      v_t_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      v_t_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      v_t_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      v_t_2440 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2426 = heff_dup(heff_field(v_j_240, 0));
      HeffT2 v_t_2427 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str1); V a_1 = v_fs_2426; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2426); r_; });
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_p_2430 = v_field_2429;
          V v_t_2433;
          switch (heff_tag_of(v_p_2430)) {
          case TAG_MkPair: {
            V v_y_2432 = heff_field(v_p_2430, 1);
            heff_take_n(v_p_2430, 2ULL, 2);
            v_t_2433 = v_y_2432;
            break;
          }
          default: heff_nomatch(v_p_2430);
          }
          switch (heff_tag_of(v_t_2433)) {
          case TAG_JNull: {
            v_t_2440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2433, 0ULL, 1);
            v_t_2440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2433, 0ULL, 1);
            v_t_2440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2433, 0ULL, 1);
            v_t_2440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JString: {
            V v_s_2437 = heff_field(v_t_2433, 0);
            V v_ru_24t_2433_24JString = heff_take_reuse_n(v_t_2433, 1ULL, 1);
            v_t_2440 = heff_tag_at_n(v_ru_24t_2433_24JString, TAG_Just, 1, (V[]){v_s_2437});
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2433, 0ULL, 1);
            v_t_2440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2433, 0ULL, 1);
            v_t_2440 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_t_2433);
          }
        } else {
          heff_drop(v_field_2429);
          v_t_2440 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_j_240);
    }
    switch (heff_tag_of(v_t_2440)) {
    case TAG_Nothing: {
      V v_t_2460;
      switch (heff_tag_of(v_j_240)) {
      case TAG_JNull: {
        v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str2);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_j_240, 0ULL, 1);
        v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str3);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_j_240, 0ULL, 1);
        v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str4);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_j_240, 0ULL, 1);
        v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str5);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_j_240, 0ULL, 1);
        v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str6);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_j_240, 0ULL, 1);
        v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str7);
        break;
      }
      case TAG_JObject: {
        V v_fs_2446 = heff_field(v_j_240, 0);
        heff_take_n(v_j_240, 1ULL, 1);
        HeffT2 v_t_2447 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str8); V a_1 = v_fs_2446; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2446); r_; });
        {
          V v_field_2449 = v_t_2447.f[1];
          int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
          if ((v_tag_2448 == ((int64_t)0ULL))) {
            V v_p_2450 = v_field_2449;
            V v_t_2453;
            switch (heff_tag_of(v_p_2450)) {
            case TAG_MkPair: {
              V v_y_2452 = heff_field(v_p_2450, 1);
              heff_take_n(v_p_2450, 2ULL, 2);
              v_t_2453 = v_y_2452;
              break;
            }
            default: heff_nomatch(v_p_2450);
            }
            switch (heff_tag_of(v_t_2453)) {
            case TAG_JNull: {
              v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str9);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_t_2453, 0ULL, 1);
              v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str10);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_t_2453, 0ULL, 1);
              v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str11);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_t_2453, 0ULL, 1);
              v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str12);
              break;
            }
            case TAG_JString: {
              V v_s_2457 = heff_field(v_t_2453, 0);
              heff_take_n(v_t_2453, 1ULL, 1);
              v_t_2460 = v_s_2457;
              break;
            }
            case TAG_JArray: {
              heff_take_n(v_t_2453, 0ULL, 1);
              v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str13);
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_t_2453, 0ULL, 1);
              v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str14);
              break;
            }
            default: heff_nomatch(v_t_2453);
            }
          } else {
            heff_drop(v_field_2449);
            v_t_2460 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str15);
          }
        }
        break;
      }
      default: heff_nomatch(v_j_240);
      }
      return heff_tag_n(TAG_FailedWith, 1, (V[]){v_t_2460});
    }
    case TAG_Just: {
      V v_why_2461 = heff_field(v_t_2440, 0);
      V v_ru_24t_2440_24Just = heff_take_reuse_n(v_t_2440, 1ULL, 1);
      heff_drop(v_j_240);
      return heff_tag_at_n(v_ru_24t_2440_24Just, TAG_SkippedWith, 1, (V[]){v_why_2461});
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  case TAG_Just: {
    V v_n_2462 = heff_field(v_t_2420, 0);
    heff_take_n(v_t_2420, 1ULL, 1);
    V v_t_2482;
    switch (heff_tag_of(v_j_240)) {
    case TAG_JNull: {
      v_t_2482 = MK_INT(0LL);
      break;
    }
    case TAG_JBool: {
      v_t_2482 = MK_INT(0LL);
      break;
    }
    case TAG_JInt: {
      v_t_2482 = MK_INT(0LL);
      break;
    }
    case TAG_JFloat: {
      v_t_2482 = MK_INT(0LL);
      break;
    }
    case TAG_JString: {
      v_t_2482 = MK_INT(0LL);
      break;
    }
    case TAG_JArray: {
      v_t_2482 = MK_INT(0LL);
      break;
    }
    case TAG_JObject: {
      V v_fs_2468 = heff_dup(heff_field(v_j_240, 0));
      HeffT2 v_t_2469 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str16); V a_1 = v_fs_2468; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2468); r_; });
      {
        V v_field_2471 = v_t_2469.f[1];
        int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
        if ((v_tag_2470 == ((int64_t)0ULL))) {
          V v_p_2472 = v_field_2471;
          V v_t_2475;
          switch (heff_tag_of(v_p_2472)) {
          case TAG_MkPair: {
            V v_y_2474 = heff_field(v_p_2472, 1);
            heff_take_n(v_p_2472, 2ULL, 2);
            v_t_2475 = v_y_2474;
            break;
          }
          default: heff_nomatch(v_p_2472);
          }
          switch (heff_tag_of(v_t_2475)) {
          case TAG_JNull: {
            v_t_2482 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2475, 0ULL, 1);
            v_t_2482 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2477 = heff_field(v_t_2475, 0);
            heff_take_n(v_t_2475, 1ULL, 1);
            v_t_2482 = v_i_2477;
            break;
          }
          case TAG_JFloat: {
            double v_x_2478 = heff_tflat_f64(v_t_2475, 0);
            heff_take_na(v_t_2475, 0ULL, 1);
            v_t_2482 = heff_floor_f64(v_x_2478);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_t_2475, 0ULL, 1);
            v_t_2482 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2475, 0ULL, 1);
            v_t_2482 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2475, 0ULL, 1);
            v_t_2482 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_t_2475);
          }
        } else {
          heff_drop(v_field_2471);
          v_t_2482 = MK_INT(0LL);
        }
      }
      break;
    }
    default: heff_nomatch(v_j_240);
    }
    V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str17), NTAG(TAG_Nil)});
    HeffT2 v_t_2484 = ({ V a_0 = v_t_2483; V a_1 = heff_dup(v_j_240); HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2483, 2); r_; });
    {
      V v_field_2486 = v_t_2484.f[1];
      int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
      V v_t_2494;
      if ((v_tag_2485 == ((int64_t)0ULL))) {
        V v_it1_2487 = v_field_2486;
        switch (heff_tag_of(v_it1_2487)) {
        case TAG_JNull: {
          v_t_2494 = MK_INT(0LL);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_it1_2487, 0ULL, 1);
          v_t_2494 = MK_INT(0LL);
          break;
        }
        case TAG_JInt: {
          V v_i_2489 = heff_field(v_it1_2487, 0);
          heff_take_n(v_it1_2487, 1ULL, 1);
          v_t_2494 = v_i_2489;
          break;
        }
        case TAG_JFloat: {
          double v_x_2490 = heff_tflat_f64(v_it1_2487, 0);
          heff_take_na(v_it1_2487, 0ULL, 1);
          v_t_2494 = heff_floor_f64(v_x_2490);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_it1_2487, 0ULL, 1);
          v_t_2494 = MK_INT(0LL);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_it1_2487, 0ULL, 1);
          v_t_2494 = MK_INT(0LL);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_it1_2487, 0ULL, 1);
          v_t_2494 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_it1_2487);
        }
      } else {
        heff_drop(v_field_2486);
        v_t_2494 = MK_INT(0LL);
      }
      V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str18), NTAG(TAG_Nil)});
      HeffT2 v_t_2496 = ({ V a_0 = v_t_2495; V a_1 = v_j_240; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2495, 2); r_; });
      {
        V v_field_2498 = v_t_2496.f[1];
        int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
        V v_t_24106;
        if ((v_tag_2497 == ((int64_t)0ULL))) {
          V v_it1_2499 = v_field_2498;
          switch (heff_tag_of(v_it1_2499)) {
          case TAG_JNull: {
            v_t_24106 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2499, 0ULL, 1);
            v_t_24106 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_24101 = heff_field(v_it1_2499, 0);
            heff_take_n(v_it1_2499, 1ULL, 1);
            v_t_24106 = v_i_24101;
            break;
          }
          case TAG_JFloat: {
            double v_x_24102 = heff_tflat_f64(v_it1_2499, 0);
            heff_take_na(v_it1_2499, 0ULL, 1);
            v_t_24106 = heff_floor_f64(v_x_24102);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2499, 0ULL, 1);
            v_t_24106 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2499, 0ULL, 1);
            v_t_24106 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2499, 0ULL, 1);
            v_t_24106 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2499);
          }
        } else {
          heff_drop(v_field_2498);
          v_t_24106 = MK_INT(0LL);
        }
        return heff_tag_n(TAG_Measured, 4, (V[]){v_n_2462, v_t_2482, v_t_2494, v_t_24106});
      }
    }
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str4, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str5, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str6, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str7, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str8, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str9, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str10, 32, "what it listed could not be read");

HeffT2 g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(V v_r_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_r_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Exited: {
    V v_n_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    if (!heff_intEq_c_lent(v_n_242, MK_INT(0LL), 2)) {
      heff_drop(v_n_242);
      V v_t_243 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
    } else {
      heff_drop(v_n_242);
      V v_t_244 = heff_get_n(v_r_240, 1, 3);
      V v_t_245 = ({ V a_0 = v_t_244; V a_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str1), v_t_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_244); r_; });
      V v_x1_246 = (g_list_2efoldl_24f1221993074x1235215335(NTAG(TAG_Nil), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str2), v_t_245));
      V v_s_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        v_s_249 = ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        v_s_249 = v_x_247;
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      V v_t_2410 = (g_json_2eskipSpace(v_s_249, MK_INT(0LL)));
      V v_t_2411 = (g_json_2esteps_2evalueAt_240(heff_dup(v_s_249), v_t_2410, NTAG(TAG_Nil)));
      HeffT2 v_t_2412 = ({ V a_0 = v_s_249; V a_1 = v_t_2411; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_s_249); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2415 = v_field_2414;
          heff_drop(v_x_2415);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str4)}});
        } else {
          V v_it1_2416 = v_field_2414;
          switch (heff_tag_of(v_it1_2416)) {
          case TAG_JNull: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str5)}});
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str6)}});
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str7)}});
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str8)}});
          }
          case TAG_JString: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str9)}});
          }
          case TAG_JArray: {
            V v_bs_2421 = heff_field(v_it1_2416, 0);
            heff_take_n(v_it1_2416, 1ULL, 1);
            V v_t_2422 = (g_list_2emap_24s849938259x51049885(v_bs_2421));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2422}});
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str10)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2416)}});
          }
        }
      }
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_241, 0ULL, 1);
    V v_t_2425 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2425}});
  }
  case TAG_TimedOut: {
    V v_t_2426 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2426}});
  }
  case TAG_NotRun: {
    heff_take_n(v_t_241, 0ULL, 1);
    V v_t_2428 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2428}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str0, 1, "x");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str3, 19, "heff bench: --time ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str4, 57, ": not a duration (1s, 1.5s, 500ms, 2m) nor a count (100x)");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str5, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_z_241);
    return heff_tail(v_z_242, 1, (V[]){heff_dup(g_heff_2ebuild_2ebenchmarks_2edefaultTime_get())});
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_s_244 = heff_dup(v_s_243);
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
    V v_t_246 = heff_strSlice_lent(v_s_244, heff_box_word(v_t_245), heff_strLength_lent(v_s_244, 0), 6);
    V v_t_2428;
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str0))) {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
      V v_s_248 = heff_strSlice(v_s_244, MK_INT(0LL), heff_box_word(v_t_247));
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_248, 0)))) {
        int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_s_248, 0)) - ((int64_t)1ULL));
        V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_249)));
        V v_t_2411 = ({ V a_0 = MK_INT(48LL); V a_1 = v_s_248; V a_2 = MK_INT(57LL); V a_3 = v_t_2410; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          HeffT2 v_t_2412 = ({ V a_0 = v_s_248; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_248); r_; });
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_n_2415 = v_field_2414;
              if (heff_intLt_c_lent(MK_INT(0LL), v_n_2415, 1)) {
                v_t_2428 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Times, 1, (V[]){v_n_2415})});
              } else {
                heff_drop_cell(v_ru_24x1_240_24Just, 1);
                heff_drop(v_n_2415);
                v_t_2428 = NTAG(TAG_Nothing);
              }
            } else {
              heff_drop_cell(v_ru_24x1_240_24Just, 1);
              heff_drop(v_field_2414);
              v_t_2428 = NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          heff_drop(v_s_248);
          heff_drop(v_t_2411);
          v_t_2428 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        heff_drop(v_s_248);
        v_t_2428 = NTAG(TAG_Nothing);
      }
    } else {
      V v_s_2416 = heff_dup(v_s_244);
      HeffT2 v_t_2417 = ({ V a_0 = v_s_244; V b_1 = heff_dup(g_heff_2ebuild_2ebenchmarks_2eunits_get()); HeffT2 r_ = (g_list_2efind_24s1136367117x833793205_24cpr(a_0, b_1)); heff_drop(v_s_244); heff_drop(b_1); r_; });
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_x21_2420 = v_field_2419;
          switch (heff_tag_of(v_x21_2420)) {
          case TAG_MkPair: {
            V v_u_2421 = heff_field(v_x21_2420, 0);
            V v_unit_2422 = heff_field(v_x21_2420, 1);
            heff_take_n(v_x21_2420, 3ULL, 2);
            int64_t v_t_2423 = (heff_unbox_word(heff_strLength_lent(v_s_2416, 0)) - heff_unbox_word(heff_strLength(v_u_2421)));
            V v_s_2424 = heff_strSlice(v_s_2416, MK_INT(0LL), heff_box_word(v_t_2423));
            V v_t_2425 = ({ V a_0 = v_s_2424; V a_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str2), v_s_2424, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_2424); r_; });
            V v_t_2426 = ({ V a_0 = v_unit_2422; V a_1 = v_t_2425; V r_ = heff_tr(g_heff_2ebuild_2ebenchmarks_2edecimalParts(a_0, a_1)); heff_drop(v_t_2425); r_; });
            switch (heff_tag_of(v_t_2426)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x1_240_24Just, 1);
              v_t_2428 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_n_2427 = heff_field(v_t_2426, 0);
              V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
              if (heff_intLt_c_lent(MK_INT(0LL), v_n_2427, 1)) {
                v_t_2428 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Nanos, 1, (V[]){v_n_2427})});
              } else {
                heff_drop_cell(v_ru_24x1_240_24Just, 1);
                heff_drop(v_n_2427);
                heff_drop_cell(v_ru_24t_2426_24Just, 1);
                v_t_2428 = NTAG(TAG_Nothing);
              }
              break;
            }
            default: heff_nomatch(v_t_2426);
            }
            break;
          }
          default: heff_nomatch(v_x21_2420);
          }
        } else {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          heff_drop(v_s_2416);
          heff_drop(v_field_2419);
          v_t_2428 = NTAG(TAG_Nothing);
        }
      }
    }
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str3), v_s_243), ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str4));
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_str5)), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_lam0, 1, 2, (V[]){v_z_241, v_z_242}));
    }
    case TAG_Just: {
      V v_t_2444 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      heff_drop(v_z_241);
      heff_drop(v_s_243);
      return heff_tail(v_z_242, 1, (V[]){v_t_2444});
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_lam1(V self, V *args) {
  V v_x_2443 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_drop(v_x_2443);
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = heff_dup(g_heff_2ebuild_2ebenchmarks_2edefaultTime_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_lam0(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_241, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_lam1, 1, 1, (V[]){v_z_242})));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str0, 4, "file");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str1, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str6, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str9, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str11, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(V v_opts_240, V v_f_241, V v_why_242) {
top: ;
  V v_t_243 = heff_get_n(v_opts_240, 3, 5);
  V v_c_2428;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str0), heff_tag_n(TAG_JString, 1, (V[]){v_f_241})});
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str1), heff_tag_n(TAG_JString, 1, (V[]){v_why_242})});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    V v_str_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str2); V a_1 = v_t_247; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_247, 1); r_; });
    V v_t_249 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_248, ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str3)), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    v_c_2428 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})}));
  } else {
    heff_drop(v_t_243);
    V v_t_2415 = ({ V a_0 = v_why_242; V a_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str5), v_why_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_why_242); r_; });
    V v_x2_2416 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str6), v_t_2415));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str8); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str9), v_f_241), ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str10));
    V v_str_2421 = heff_strAppend(v_t_2420, v_t_2419);
    V v_t_2422 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2421, ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_str11)), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    v_c_2428 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
  }
  return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_lam0, 2, 1, (V[]){v_c_2428});
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  heff_drop(v_x_2431);
  heff_clo_take(self, 1);
  V f_ = v_k_2430;
  args[0] = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(1LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_lam0(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_lam1, 1, 1, (V[]){v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str1, 3, "run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str2, 3, "run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str3, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str9, 45, "what it said of how it went could not be read");
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam0, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_entry, 9, 0};

V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575(V v_opts_240, V v_f_241, V v_prog_242, V v_width_243, V v_names_244, V v_left_245, V v_acc_246, V v_p_247, V v_p_248) {
top: ;
  if (heff_intLe_c_lent(v_left_245, MK_INT(0LL), 2)) {
    heff_drop_rec(v_opts_240, 5);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    heff_drop(v_p_247);
    return heff_tail(v_p_248, 1, (V[]){v_acc_246});
  } else {
    V v_t_249 = heff_dup(heff_rfield(v_opts_240, 1));
    V v_t_2414;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nanos: {
      V v_ns_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_ns_2410), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str0), heff_dup(v_names_244)})});
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str1), v_t_2411});
      break;
    }
    case TAG_Times: {
      V v_n_2412 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_n_2412), heff_dup(v_names_244)});
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str3), v_t_2413})});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2415 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){heff_dup(v_prog_242), v_t_2414, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str4), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam0_clo)})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s535099379x685970669(v_t_2422, heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam1, 1, 9, (V[]){v_opts_240, v_f_241, v_width_243, v_names_244, v_p_247, v_acc_246, v_prog_242, v_left_245, v_p_248})));
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam0(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam2(V self, V *args) {
  V v_x_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_acc_246 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_prog_242 = heff_env(self)[4];
  V v_width_243 = heff_env(self)[5];
  V v_names_244 = heff_env(self)[6];
  V v_left_245 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  V v_p_248 = heff_env(self)[9];
  heff_drop(v_x_2447);
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Measured: {
    heff_take_n(v_x_2446, 0ULL, 4);
    V v_t_2452 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2453 = ({ V rv_0 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_acc_246, 2ULL, 2, shape_ran__failed, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return (g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575(v_opts_240, v_f_241, v_prog_242, v_width_243, v_names_244, heff_intSub(v_left_245, MK_INT(1LL)), v_t_2453, v_p_247, v_p_248));
  }
  case TAG_FailedWith: {
    heff_drop_rec(v_opts_240, 5);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    heff_drop(v_p_247);
    V v_t_2461;
    switch (heff_tag_of(v_x_2446)) {
    case TAG_Measured: {
      heff_take_n(v_x_2446, 0ULL, 4);
      v_t_2461 = MK_INT(0LL);
      break;
    }
    case TAG_FailedWith: {
      heff_take_n(v_x_2446, 0ULL, 1);
      v_t_2461 = MK_INT(1LL);
      break;
    }
    case TAG_SkippedWith: {
      heff_take_n(v_x_2446, 0ULL, 1);
      v_t_2461 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_x_2446);
    }
    V v_t_2462 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2463 = heff_intAdd(heff_take_field(v_acc_246, 1), v_t_2461);
    V f_ = v_p_248;
    args[0] = ({ V rv_0 = v_t_2462; V rv_1 = v_t_2463; V rr_ = heff_rec_reuse_nf(v_acc_246, 0ULL, 2, shape_ran__failed, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_SkippedWith: {
    heff_drop_rec(v_opts_240, 5);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    heff_drop(v_p_247);
    V v_t_2471;
    switch (heff_tag_of(v_x_2446)) {
    case TAG_Measured: {
      heff_take_n(v_x_2446, 0ULL, 4);
      v_t_2471 = MK_INT(0LL);
      break;
    }
    case TAG_FailedWith: {
      heff_take_n(v_x_2446, 0ULL, 1);
      v_t_2471 = MK_INT(1LL);
      break;
    }
    case TAG_SkippedWith: {
      heff_take_n(v_x_2446, 0ULL, 1);
      v_t_2471 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_x_2446);
    }
    V v_t_2472 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2473 = heff_intAdd(heff_take_field(v_acc_246, 1), v_t_2471);
    V f_ = v_p_248;
    args[0] = ({ V rv_0 = v_t_2472; V rv_1 = v_t_2473; V rr_ = heff_rec_reuse_nf(v_acc_246, 0ULL, 2, shape_ran__failed, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2446);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_width_243 = heff_env(self)[2];
  V v_names_244 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  V v_acc_246 = heff_env(self)[5];
  V v_prog_242 = heff_env(self)[6];
  V v_left_245 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  V v_r_2424 = v_x_2423;
  V v_t_2425 = heff_dup(heff_rfield(v_r_2424, 0));
  V v_x_2446;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Exited: {
    V v_n_2426 = heff_field(v_t_2425, 0);
    V v_ru_24t_2425_24Exited = heff_take_reuse_n(v_t_2425, 1ULL, 1);
    if (!heff_intEq_c_lent(v_n_2426, MK_INT(0LL), 2)) {
      heff_drop(v_n_2426);
      V v_t_2427 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_2424));
      v_x_2446 = heff_tag_at_n(v_ru_24t_2425_24Exited, TAG_FailedWith, 1, (V[]){v_t_2427});
    } else {
      heff_drop(v_n_2426);
      V v_t_2428 = heff_get_n(v_r_2424, 1, 3);
      V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str5); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str6), v_t_2428, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2428); r_; });
      V v_x1_2430 = (g_list_2efoldl_24f1221993074x1235215335(NTAG(TAG_Nil), ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str7), v_t_2429));
      V v_s_2433;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_Nil: {
        v_s_2433 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2431 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 2);
        v_s_2433 = v_x_2431;
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      V v_t_2434 = (g_json_2eskipSpace(v_s_2433, MK_INT(0LL)));
      V v_t_2435 = (g_json_2esteps_2evalueAt_240(heff_dup(v_s_2433), v_t_2434, NTAG(TAG_Nil)));
      HeffT2 v_t_2436 = ({ V a_0 = v_s_2433; V a_1 = v_t_2435; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_s_2433); r_; });
      {
        V v_field_2438 = v_t_2436.f[1];
        int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
        if ((v_tag_2437 == ((int64_t)0ULL))) {
          V v_why_2439 = v_field_2438;
          heff_drop(v_why_2439);
          v_x_2446 = heff_tag_at_n(v_ru_24t_2425_24Exited, TAG_FailedWith, 1, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_str9)});
        } else {
          heff_drop_cell(v_ru_24t_2425_24Exited, 1);
          V v_j_2440 = v_field_2438;
          v_x_2446 = (g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(v_j_2440));
        }
      }
    }
    break;
  }
  case TAG_Signalled: {
    V v_ru_24t_2425_24Signalled = heff_take_reuse_n(v_t_2425, 0ULL, 1);
    V v_t_2442 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_2424));
    v_x_2446 = heff_tag_at_n(v_ru_24t_2425_24Signalled, TAG_FailedWith, 1, (V[]){v_t_2442});
    break;
  }
  case TAG_TimedOut: {
    V v_t_2443 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_2424));
    v_x_2446 = heff_tag_n(TAG_FailedWith, 1, (V[]){v_t_2443});
    break;
  }
  case TAG_NotRun: {
    V v_ru_24t_2425_24NotRun = heff_take_reuse_n(v_t_2425, 0ULL, 1);
    V v_t_2445 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_2424));
    v_x_2446 = heff_tag_at_n(v_ru_24t_2425_24NotRun, TAG_FailedWith, 1, (V[]){v_t_2445});
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329(heff_dup(v_opts_240), heff_dup(v_f_241), heff_dup(v_width_243), heff_dup(v_names_244), heff_dup(v_x_2446), heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575_lam2, 1, 10, (V[]){v_x_2446, v_acc_246, v_opts_240, v_f_241, v_prog_242, v_width_243, v_names_244, v_left_245, v_p_247, v_p_248})));
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528_entry, 8, 0};

V g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528(V v_opts_240, V v_f_241, V v_prog_242, V v_width_243, V v_x5_244, V v_acc_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_opts_240, 5);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_p_246);
    return heff_tail(v_p_247, 1, (V[]){v_acc_245});
  }
  case TAG_Cons: {
    V v_names_248 = heff_field(v_x5_244, 0);
    V v_rest_249 = heff_field(v_x5_244, 1);
    return (g_heff_2ebuild_2ebenchmarks_2erunTimes_24s1563173250x1353772575(heff_dup(v_opts_240), heff_dup(v_f_241), heff_dup(v_prog_242), heff_dup(v_width_243), heff_dup(v_names_248), heff_dup(heff_rfield(v_opts_240, 2)), v_acc_245, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528_lam0, 1, 7, (V[]){v_opts_240, v_f_241, v_prog_242, v_width_243, heff_dup(v_rest_249), v_p_246, v_p_247})));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_prog_242 = heff_env(self)[2];
  V v_width_243 = heff_env(self)[3];
  V v_rest_249 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_opts_240; V a_1 = v_f_241; V a_2 = v_prog_242; V a_3 = v_width_243; V a_4 = v_rest_249; V a_5 = v_x_2410; V a_6 = v_p_246; V a_7 = v_p_247; V r_ = (g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_rest_249); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str0, 5, "pkg: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str3, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str5, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str6, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str7, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam3(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam3, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_entry, 6, 0};

V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321(V v_opts_240, V v_f_241, V v_prog_242, V v_bs_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_bs_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_opts_240, 5);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  }
  case TAG_Cons: {
    V v_t_248 = heff_dup(heff_rfield(v_opts_240, 3));
    V v_t_2418;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_2418 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam0_clo);
    } else {
      heff_drop(v_t_248);
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str0), heff_dup(v_f_241)), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str1));
      V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      v_t_2418 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
    }
    return heff_tail(v_t_2418, 2, (V[]){heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam1, 1, 6, (V[]){v_bs_243, v_opts_240, v_f_241, v_prog_242, v_p_244, v_p_245})});
  }
  default: return heff_nomatch(v_bs_243);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  heff_drop(v_x_2434);
  heff_clo_take(self, 2);
  V f_ = v_p_245;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = heff_get_n(v_opts_240, 3, 5);
  V v_t_2433;
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_f_241);
    heff_drop(v_t_2422);
    v_t_2433 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam3_clo);
  } else {
    heff_drop(v_t_2422);
    V v_t_2425;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2421, 1)))) {
      v_t_2425 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str5);
    } else {
      v_t_2425 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str6);
    }
    V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, v_f_241), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str7));
    V v_t_2427 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    v_t_2433 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  }
  V f_ = v_t_2433;
  heff_room[0] = v_p_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam4, 1, 2, (V[]){v_p_245, v_x_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_bs_243 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_prog_242 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_drop(v_x_2419);
  V v_t_2420 = (g_list_2efoldl_24s141260856x1366916752(((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str2), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str3), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_str4), MK_INT(0LL), v_bs_243));
  heff_clo_take(self, 6);
  return ({ V a_0 = heff_dup(v_opts_240); V a_1 = heff_dup(v_f_241); V a_2 = v_prog_242; V a_3 = v_t_2420; V a_4 = v_bs_243; V a_5 = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)}); V a_6 = heff_dup(v_p_244); V a_7 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_lam2, 1, 4, (V[]){v_opts_240, v_f_241, v_p_244, v_p_245}); V r_ = (g_heff_2ebuild_2ebenchmarks_2erunEach_24s972468051x1660821528(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop_tag(v_bs_243, 2); r_; });
}
Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_entry, 5, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(V v_opts_240, V v_x2_241, V v_acc_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return (g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399(v_opts_240, v_acc_242, v_z_243, v_z_244));
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428(heff_dup(v_opts_240), heff_dup(v_rest_246), v_acc_242, v_opts_240, heff_dup(v_f_245), v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}