// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_UFixed 18334
#define TAG_UFn 31401
#define TAG_UOp 31682
#define TAG_URel 1603
#define TAG_UToDouble 51807
#define LBL_arg 306384
#define LBL_code 9554612
#define LBL_defs 9574869
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_lams 9809570
#define LBL_lprotos 613175609
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_post 9942375
#define LBL_pre 320797
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_result 1012715336
#define LBL_shapes 1043573789
#define LBL_source 1050636102
#define LBL_strs 10036521
static uint32_t shape_arg__pre__post[] = {LBL_arg, LBL_pre, LBL_post};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
V g_heff_2ecompile_2eemitc_2eargC(V, V, V);
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargC_clo;
V g_heff_2ecompile_2eemitc_2eargLine(V, V);
V g_heff_2ecompile_2eemitc_2eargLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLine_clo;
V g_heff_2ecompile_2eemitc_2eargLines_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eargLines_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLines_24dps_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V, V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
HeffT6 g_heff_2ecompile_2eemitc_2eckOf_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efixedU(V, V, V);
V g_heff_2ecompile_2eemitc_2efixedU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedU_clo;
V g_heff_2ecompile_2eemitc_2efunTypeName(V);
V g_heff_2ecompile_2eemitc_2efunTypeName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunTypeName_clo;
V g_heff_2ecompile_2eemitc_2egivenMask(V, V, V);
V g_heff_2ecompile_2eemitc_2egivenMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egivenMask_clo;
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
HeffT2 g_heff_2ecompile_2eemitc_2elitName_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2eparamTypeNames(V);
V g_heff_2ecompile_2eemitc_2eparamTypeNames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamTypeNames_clo;
V g_heff_2ecompile_2eemitc_2epartCount(V, V);
V g_heff_2ecompile_2eemitc_2epartCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartCount_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2epointerFnLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epointerFnLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointerFnLines_clo;
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2eprojShapesW(V, V);
V g_heff_2ecompile_2eemitc_2eprojShapesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprojShapesW_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2eroomed(V);
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eroomed_clo;
V g_heff_2ecompile_2eemitc_2estaticText(V, V, V, V);
V g_heff_2ecompile_2eemitc_2estaticText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estaticText_clo;
V g_heff_2ecompile_2eemitc_2eunboxedC(V, V);
V g_heff_2ecompile_2eemitc_2eunboxedC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxedC_clo;
HeffT2 g_heff_2ecompile_2eemitc_2evalDef_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f1512150482x179770396(V, V, V, V);
V g_list_2emap_24f1512150482x179770396_entry(V self, V *a);
extern Clo g_list_2emap_24f1512150482x179770396_clo;
V g_list_2emap_24s1275294336x693095586(V, V);
V g_list_2emap_24s1275294336x693095586_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s577269653x49010166(V);
V g_list_2emap_24s577269653x49010166_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1200852x585902530(V, V, V, V);
V g_list_2ezipWith_24s1200852x585902530_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1200852x585902530_clo;
V g_list_2ezipWith_24s952564628x174753269(V, V, V, V, V);
V g_list_2ezipWith_24s952564628x174753269_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s952564628x174753269_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f1835712132x1195429753(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f1835712132x1195429753_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f1835712132x1195429753_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
Clo g_heff_2ecompile_2eemitc_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elitName_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elitName_24cpr_str1, 5, "_lit_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elitName_24cpr_str2, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elitName_24cpr_str3, 4, "_lit");

HeffT2 g_heff_2ecompile_2eemitc_2elitName_24cpr(V v_x_240, V v_s_241) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    V v_t_242 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elitName_24cpr_str0)));
    V v_t_243 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), ((V)&g_heff_2ecompile_2eemitc_2elitName_24cpr_str1));
    V v_f_244 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elitName_24cpr_str2), v_t_242));
    return ((HeffT2){{v_f_244, v_s_241}});
  } else {
    V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), ((V)&g_heff_2ecompile_2eemitc_2elitName_24cpr_str3));
    V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_s_241, 4)));
    V v_f_247 = heff_strAppend(v_t_245, v_t_246);
    V v_t_248 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
    V v_f_249 = ({ V rv_4 = v_t_248; V rr_ = heff_rec_reuse_nf(v_s_241, 239ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{v_f_247, v_f_249}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str6, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str8, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str9, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str11, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str15, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str18, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str19, 9, "((double)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str20, 1, ")");
Clo g_heff_2ecompile_2eemitc_2eunboxedC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eunboxedC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eunboxedC(V v_x1_240, V v_vs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_UFixed: {
    V v_w_242 = heff_field(v_x1_240, 0);
    V v_op_243 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2eemitc_2efixedU(v_w_242, v_op_243, v_vs_241));
  }
  case TAG_URel: {
    V v_op_244 = heff_field(v_x1_240, 0);
    V v_t_247;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_vs_241, 0);
      v_t_247 = heff_dup(v_x_245);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    HeffT3 v_t_248 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    {
      V v_field_2410 = v_t_248.f[1];
      V v_field_2411 = v_t_248.f[2];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      V v_t_2414;
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_2410;
        V v_x12_2413 = v_field_2411;
        heff_drop(v_x12_2413);
        v_t_2414 = v_x_2412;
      } else {
        heff_drop(v_field_2410);
        heff_drop(v_field_2411);
        v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str1);
      }
      V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str2), v_t_247), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str3));
      V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, heff_dup(v_op_244)), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str4));
      V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str5));
      return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str6), v_t_2417), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str7));
    }
  }
  case TAG_UOp: {
    V v_op_2418 = heff_field(v_x1_240, 0);
    V v_t_2421;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_vs_241, 0);
      v_t_2421 = heff_dup(v_x_2419);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    HeffT3 v_t_2422 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    {
      V v_field_2424 = v_t_2422.f[1];
      V v_field_2425 = v_t_2422.f[2];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      V v_t_2428;
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        V v_x_2426 = v_field_2424;
        V v_x12_2427 = v_field_2425;
        heff_drop(v_x12_2427);
        v_t_2428 = v_x_2426;
      } else {
        heff_drop(v_field_2424);
        heff_drop(v_field_2425);
        v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str9);
      }
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str10), v_t_2421), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str11));
      V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, heff_dup(v_op_2418)), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str12));
      return heff_strAppend(heff_strAppend(v_t_2430, v_t_2428), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str13));
    }
  }
  case TAG_UFn: {
    V v_f_2431 = heff_field(v_x1_240, 0);
    V v_t_2434;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_vs_241, 0);
      V v_xs_2433 = heff_field(v_vs_241, 1);
      v_t_2434 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str15), heff_dup(v_x_2432), v_xs_2433));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2435 = heff_strAppend(heff_strAppend(heff_dup(v_f_2431), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str16)), v_t_2434);
    return heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str17));
  }
  case TAG_UToDouble: {
    V v_t_2438;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_vs_241, 0);
      v_t_2438 = heff_dup(v_x_2436);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str19), v_t_2438), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str20));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eunboxedC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eunboxedC(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str0, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str1, 4, "V a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str2, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str4, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str5, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str6, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str7, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str8, 3, " a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str9, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str10, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str12, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str13, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str14, 4, "V a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str15, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str16, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str17, 2, "b_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str18, 4, "V b_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str19, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str20, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str21, 12, "heff_drop(b_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str22, 2, ");");
V g_heff_2ecompile_2eemitc_2eargC_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eargC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargC_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eargC(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Given: {
    V v_e_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_m_244 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_243}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam0, 1, 2, (V[]){v_m_244, v_i_241});
  }
  case TAG_GivenU: {
    V v_r_2414 = heff_field(v_x3_242, 0);
    V v_e_2415 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_2416 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2415}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam1, 1, 3, (V[]){v_m_2416, v_r_2414, v_i_241});
  }
  case TAG_LentVar: {
    V v_x_2428 = heff_field(v_x3_242, 0);
    V v_drops_2429 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_t_2430 = ({ V a_0 = v_x_2428; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str11); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2428); r_; });
    V v_v_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str12), v_t_2430);
    V v_post_2432 = (g_list_2emap_24s577269653x49010166(v_drops_2429));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam2, 1, 3, (V[]){v_i_241, v_v_2431, v_post_2432});
  }
  case TAG_LentValue: {
    V v_e_2438 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_m_2439 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2438}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam3, 1, 2, (V[]){v_m_2439, v_i_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eargC(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eargC_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str0), heff_intShow(heff_dup(v_i_241)));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str1), heff_intShow(v_i_241));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eargC_str2)), v_x_247);
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eargC_str3)), NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_249, v_t_2412, NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2413, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_r_2414 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2422;
    switch (heff_tag_of(v_r_2414)) {
    case TAG_RepV: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str4);
      break;
    }
    case TAG_RepFix: {
      V v_w_2421 = heff_field(v_r_2414, 0);
      heff_take_n(v_r_2414, 1ULL, 1);
      v_t_2422 = ({ V a_0 = v_w_2421; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2421); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str5);
      break;
    }
    case TAG_RepInt: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str6);
      break;
    }
    default: heff_nomatch(v_r_2414);
    }
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str7), heff_intShow(heff_dup(v_i_241)));
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2eargC_str8)), heff_intShow(v_i_241));
    V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2eargC_str9)), v_x_2419);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2eargC_str10)), NTAG(TAG_Nil)});
    V v_x_2427 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2423, v_t_2426, NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2427, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_lam2(V self, V *args) {
  V v_s_2433 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_v_2431 = heff_env(self)[1];
  V v_post_2432 = heff_env(self)[2];
  V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str13), heff_intShow(heff_dup(v_i_241)));
  heff_clo_take(self, 3);
  V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str14), heff_intShow(v_i_241));
  V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2eargC_str15)), v_v_2431);
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2eargC_str16)), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2434, v_t_2437, v_post_2432}), v_s_2433});
}
V g_heff_2ecompile_2eemitc_2eargC_lam3(V self, V *args) {
  V v_s_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_s_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_s_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str17), heff_intShow(heff_dup(v_i_241)));
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str18), heff_intShow(heff_dup(v_i_241)));
    V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemitc_2eargC_str19)), v_x_2442);
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2eargC_str20)), NTAG(TAG_Nil)});
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str21), heff_intShow(v_i_241));
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2eargC_str22)), NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2444, v_t_2447, v_t_2449}), v_s_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str2, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str3, 6, "_lent(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str5, 1, ")");
V g_heff_2ecompile_2eemitc_2elentPrimC_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentPrimC_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2elentPrimC(V v_k_240, V v_p_241, V v_suffix_242, V v_es_243) {
top: ;
  V v_t_244 = (g_list_2emap_24s1275294336x693095586(heff_dup(v_es_243), heff_dup(v_es_243)));
  V v_m_245 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_t_244));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2elentPrimC_lam0, 1, 4, (V[]){v_m_245, heff_dup(v_p_241), v_es_243, v_suffix_242});
}
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2elentPrimC(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2elentPrimC_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_es_243 = heff_env(self)[2];
  V v_suffix_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = v_p_241; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_241); r_; });
    V v_t_2413;
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x_248, 0);
      V v_xs_2412 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2414 = ({ V a_0 = v_es_243; V a_1 = v_es_243; V a_2 = MK_INT(1LL); V r_ = (g_heff_2ecompile_2eemitc_2egivenMask(a_0, a_1, a_2)); heff_drop(v_es_243); r_; });
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str2), v_t_2410), v_suffix_242);
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str3)), v_t_2413);
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str4)), heff_intShow(v_t_2414));
    V v_x_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str5));
    return heff_tag_re_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2418, v_s_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str0, 2, " f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str1, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str5, 16, "static struct { ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str6, 2, "} ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str7, 4, " = {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticText_str8, 2, "};");
Clo g_heff_2ecompile_2eemitc_2estaticText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estaticText_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2estaticText(V v_name_240, V v_decl_241, V v_head_242, V v_fs_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_243));
  V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_244, MK_INT(1LL))));
  V v_x2_246 = (g_list_2ezipWith_24s1200852x585902530(((V)&g_heff_2ecompile_2eemitc_2estaticText_str0), ((V)&g_heff_2ecompile_2eemitc_2estaticText_str1), heff_dup(v_fs_243), v_t_245));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2estaticText_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estaticText_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estaticText_str4); V a_1 = v_head_242; V a_2 = v_fs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f1835712132x1195429753(a_0, a_1, a_2)); heff_drop(v_fs_243); r_; });
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticText_str5), v_decl_241), v_t_249);
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2estaticText_str6)), v_name_240);
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2estaticText_str7)), v_t_2410);
  return heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2estaticText_str8));
}
V g_heff_2ecompile_2eemitc_2estaticText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estaticText(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str1, 7, "V f_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str3, 10, "heff_room[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str4, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str5, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str6, 10, "heff_room[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str7, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str10, 19, "if (heff_exact(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str11, 62, ", heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str12, 21, "return heff_tail(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str13, 8, ", (V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str14, 3, "});");
Clo g_heff_2ecompile_2eemitc_2eroomed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eroomed_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eroomed(V v_vs_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_t_243 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_vs_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str1), v_t_243), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str2));
  V v_t_245 = (g_list_2edrop(MK_INT(1LL), v_vs_240));
  V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_246, MK_INT(2LL))));
  V v_t_248 = (g_list_2ezipWith_24s952564628x174753269(((V)&g_heff_2ecompile_2eemitc_2eroomed_str3), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str4), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str5), v_t_245, v_t_247));
  V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_x2_2412 = (g_list_2emap_24f1512150482x179770396(((V)&g_heff_2ecompile_2eemitc_2eroomed_str6), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str7), MK_INT(0LL), heff_intSub(v_t_2411, MK_INT(2LL))));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str9); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_intShow(heff_intSub(v_t_249, MK_INT(1LL)));
  V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str10), v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str11));
  V v_t_2418 = heff_intShow(heff_intSub(v_t_2410, MK_INT(1LL)));
  V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str12), v_t_2418), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str13));
  V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, v_t_2415), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str14));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  V v_ys_2422 = (g_prelude_2e_2b_2b(v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2421})));
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_ys_2422});
}
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eroomed(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str2, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str4, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str6, 17, "static HEFF_ONCE ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str8, 4, "_st;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str10, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str12, 13, "_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str13, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str20, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str21, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str22, 16, "  if (HEFF_DONE(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str23, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str24, 13, "_st)) return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str25, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str26, 22, "  return heff_global(&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str27, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str28, 7, "_val, &");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str29, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str30, 5, "_st, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str31, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str32, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str33, 7, "_init);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str34, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str35, 12, "_get(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str36, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str37, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str38, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str39, 11, "_get(void);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str40, 0, "");

HeffT2 g_heff_2ecompile_2eemitc_2evalDef_24cpr(V v_tu_240, V v_key_241, V v_body_242, V v_rs_243, V v_z_244) {
top: ;
  HeffT6 v_t_245 = (g_heff_2ecompile_2eemitc_2eckOf_24cpr(v_rs_243, v_tu_240, MK_INT(0LL)));
  {
    V v_field_247 = v_t_245.f[1];
    heff_drop(v_t_245.f[0]);
    heff_drop(v_t_245.f[2]);
    heff_drop(v_t_245.f[3]);
    heff_drop(v_t_245.f[4]);
    heff_drop(v_t_245.f[5]);
    V v_m_2412 = heff_tr(heff_call(v_field_247, 1, (V[]){v_body_242}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str0)));
      V v_t_2417 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str1)));
      V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str2), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str3), v_t_2417));
      V v_t_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str4));
      V v_t_2420 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str5)));
      V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str6), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str7), v_t_2420));
      V v_t_2422 = heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str8));
      V v_t_2423 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str9)));
      V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str10), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str11), v_t_2423));
      V v_t_2425 = heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str12));
      V v_t_2426 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str13), v_x_2414));
      V v_t_2427 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str14)));
      V v_t_2428 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str15)));
      V v_t_2429 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str16)));
      V v_t_2430 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str17)));
      V v_t_2431 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str18)));
      V v_t_2432 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str19)));
      V v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str20), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str21), v_t_2427));
      V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str22), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str23), v_t_2428));
      V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str24)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str25), v_t_2429));
      V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str26), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str27), v_t_2430));
      V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str28)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str29), v_t_2431));
      V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str30)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str31), v_t_2432));
      V v_t_2439 = heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str32), NTAG(TAG_Nil)});
      V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str33)), v_t_2439});
      V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str34)), v_t_2440});
      V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str35)), v_t_2441});
      V v_ys_2443 = (g_prelude_2e_2b_2b(v_t_2426, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str36), v_t_2442})));
      V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str37), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str38), v_t_2416));
      V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str39)), NTAG(TAG_Nil)});
      V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_ys_2443})});
      V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2446})});
      V v_x_2448 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2445, v_t_2447});
      return ((HeffT2){{v_x_2448, v_s_2415}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2413)}});
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str3, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str4, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str5, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str6, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str7, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str8, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str9, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str10, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str11, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str12, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str13, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str14, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str15, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str16, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str17, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str18, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str19, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str21, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str22, 2, " (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str23, 1, ")");
Clo g_heff_2ecompile_2eemitc_2efunTypeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunTypeName_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efunTypeName(V v_b_240) {
top: ;
  V v_x1_241 = heff_dup(heff_rfield(v_b_240, 3));
  V v_t_2410;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Gives: {
    V v_t_242 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_CInteger: {
      V v_t_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      v_t_2410 = v_t_243;
      break;
    }
    case TAG_CDouble: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str0);
      break;
    }
    case TAG_CBool: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str1);
      break;
    }
    case TAG_CString: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str2);
      break;
    }
    case TAG_CText: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str4);
      break;
    }
    case TAG_CBytes: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str5);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str6);
      break;
    }
    case TAG_CPointer: {
      V v_t_244 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 2);
      v_t_2410 = heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str7));
      break;
    }
    case TAG_CVoid: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str8);
      break;
    }
    default: heff_nomatch(v_t_242);
    }
    break;
  }
  case TAG_GivesOrErrno: {
    V v_t_246 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    switch (heff_tag_of(v_t_246)) {
    case TAG_CInteger: {
      V v_t_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_2410 = v_t_247;
      break;
    }
    case TAG_CDouble: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str9);
      break;
    }
    case TAG_CBool: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str10);
      break;
    }
    case TAG_CString: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str11);
      break;
    }
    case TAG_CText: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str12);
      break;
    }
    case TAG_COwnedString: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str13);
      break;
    }
    case TAG_CBytes: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str14);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str15);
      break;
    }
    case TAG_CPointer: {
      V v_t_248 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_2410 = heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str16));
      break;
    }
    case TAG_CVoid: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str17);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  case TAG_DoneOrErrno: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str18);
    break;
  }
  default: heff_nomatch(v_x1_241);
  }
  V v_x1_2411 = (g_heff_2ecompile_2eemitc_2eparamTypeNames(heff_dup(v_b_240)));
  V v_t_2417;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nil: {
    heff_drop_rec(v_b_240, 5);
    v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str19);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2411, 0ULL, 2);
    V v_x2_2414 = (g_heff_2ecompile_2eemitc_2eparamTypeNames(v_b_240));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str20);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str21); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str22)), v_t_2417);
  return heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str23));
}
V g_heff_2ecompile_2eemitc_2efunTypeName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efunTypeName(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eargLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargLines_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eargLines_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = ({ V a_0 = heff_dup(v_i_240); V a_1 = v_t_243; V r_ = (g_heff_2ecompile_2eemitc_2eargLine(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_u_247;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eargLines_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eargLines_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str0, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str2, 12, "static void ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str3, 12, "(void *q) { ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str4, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str5, 8, " *)q); }");
Clo g_heff_2ecompile_2eemitc_2epointerFnLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epointerFnLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2epointerFnLines(V v_leaf_240, V v_what_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_leaf_240);
    heff_drop(v_what_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_t_246 = heff_field(v_x41_244, 0);
      V v_r_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str0), heff_dup(v_leaf_240)), ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str1));
      V v_t_249 = heff_strAppend(heff_dup(v_what_241), heff_intShow(heff_dup(v_i_242)));
      V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str2), heff_strAppend(v_t_248, v_t_249));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str3)), v_r_247);
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str4)), v_t_246);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str5)), heff_hole()});
      V v_u_2414 = ({ V a_0 = v_leaf_240; V a_1 = v_what_241; V a_2 = heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))); V a_3 = v_rest_245; V a_4 = v_cell_2413; V r_ = (g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_leaf_240); heff_drop(v_what_241); r_; });
      heff_drop(v_u_2414);
      return v_cell_2413;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2epointerFnLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epointerFnLines(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemitc_2emoduleParts_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emoduleParts_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2emoduleParts(V v_size_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_m_242 = heff_field(v_x2_241, 0);
    V v_ps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emoduleParts_lam0, 2, 1, (V[]){v_size_240}); V a_1 = MK_INT(0LL); V a_2 = v_ps_243; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_b_248 = ({ V a_0 = v_t_247; V a_1 = MK_INT(1LL); V r_ = (g_heff_2ecompile_2eemitc_2epartCount(a_0, a_1)); heff_drop(v_t_247); r_; });
    if (heff_intEq_c_lent(v_b_248, MK_INT(1LL), 2)) {
      heff_drop(v_b_248);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, 3ULL, (V[]){v_m_242, v_ps_243}), NTAG(TAG_Nil)});
    } else {
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return ({ V a_0 = v_m_242; V a_1 = v_b_248; V a_2 = v_ps_243; V a_3 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemitc_2epartsFrom(a_0, a_1, a_2, a_3)); heff_drop(v_m_242); heff_drop(v_b_248); heff_drop(v_ps_243); r_; });
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emoduleParts(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2emoduleParts_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_p_245 = args[1];
  V v_size_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tr(heff_call(v_size_240, 1, (V[]){v_p_245}));
  return heff_intAdd(v_n_244, v_t_246);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprojShapesW_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprojShapesW_str1, 1, ",");
Clo g_heff_2ecompile_2eemitc_2eprojShapesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprojShapesW_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eprojShapesW(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_acc_240;
      V t_1 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_b_247, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_argv_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_argv_249, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_acc_240;
      V t_1 = v_t_2414;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2415, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2417;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      V v_sh_2420 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 4);
      V v_t_2424;
      switch (heff_tag_of(v_sh_2420)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eprojShapesW_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_sh_2420, 0);
        V v_xs_2423 = heff_field(v_sh_2420, 1);
        heff_take_n(v_sh_2420, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprojShapesW_str1); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_sh_2420);
      }
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2424, v_acc_240});
      V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2426 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2426, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2428;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2429 = heff_field(v_x21_242, 0);
      V v_arms_2430 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2431 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2430, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2429, v_t_2431});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2434, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2435;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2437 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2437, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2438;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2446 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2447 = ({ V a_0 = v_c_2446; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2446); r_; });
      V t_0 = v_acc_240;
      V t_1 = v_t_2447;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2449 = heff_field(v_x21_242, 1);
      V v_b_2450 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2451 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2450, v_rest_243})});
      V t_0 = v_acc_240;
      V t_1 = v_t_2451;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2452 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2453 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2452, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2453;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eprojShapesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprojShapesW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2emergeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emergeKept_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2emergeKept(V v_o_240, V v_k_241, V v_s_242) {
top: ;
  V v_lams_243 = heff_take_field(v_k_241, 5);
  V v_lprotos_244 = heff_take_field(v_k_241, 4);
  V v_strs_245 = heff_take_field(v_k_241, 3);
  V v_shapes_246 = heff_take_field(v_k_241, 6);
  V v_prims_247 = heff_get_n(v_k_241, 7, 8);
  V v_t_248 = (g_heff_2ecompile_2eemitc_2epushOwn(v_o_240, v_lams_243, heff_take_field(v_s_242, 2)));
  V v_t_249 = (g_heff_2ecompile_2eemitc_2epushOwn(v_o_240, v_lprotos_244, heff_take_field(v_s_242, 3)));
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2epushOwn(v_o_240, v_strs_245, heff_take_field(v_s_242, 5)));
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2epushOwn(v_o_240, v_shapes_246, heff_take_field(v_s_242, 6)));
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2epushOwn(v_o_240, v_prims_247, heff_take_field(v_s_242, 7)));
  return ({ V rv_2 = v_t_248; V rv_3 = v_t_249; V rv_5 = v_t_2410; V rv_6 = v_t_2411; V rv_7 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_242, 19ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 783u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2emergeKept(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckOut_str0, 18, "#define HEFF_CHECK");
Clo g_heff_2ecompile_2eemitc_2echeckOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckOut_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckOut(V v_runtime_240, V v_exports_241, V v_l_242) {
top: ;
  V v_defs_243 = heff_take_field(v_l_242, 0);
  V v_facts_244 = heff_take_field(v_l_242, 1);
  V v_errors_245 = heff_get_n(v_l_242, 2, 3);
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_clo), 2, (V[]){v_exports_241, heff_dup(v_defs_243)}));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckOut_str0), NTAG(TAG_Nil)});
  V v_ending_248 = heff_rec_n(2, shape_prefix__end, (V[]){v_t_247, v_t_246});
  V v_defs_249 = v_defs_243;
  V v_t_2410 = (g_list_2efoldl_24f409057300x985797598(NTAG(TAG_Nil), heff_dup(v_defs_249)));
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_names_2412 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2411, v_t_2410));
  V v_t_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_facts_244; V a_2 = v_names_2412; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_2412); r_; });
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2eprogramCE(v_runtime_240, NTAG(TAG_Nil), v_ending_248, v_defs_249, v_t_2413));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_2414, v_errors_245});
}
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2echeckOut(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecatMaybesC_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(v_rest_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecatMaybesC(a[0]);
}