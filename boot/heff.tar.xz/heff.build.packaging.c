// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_wrong 314763719
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_clo;
V g_heff_2ebuild_2epackaging_2ebuildText_get(void);
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614(V, V, V, V);
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_clo;
V g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980(V, V, V, V);
V g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_clo;
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784(V, V, V);
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_clo;
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_clo;
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267(V);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_clo;
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0_clo;
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_clo;
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306(V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_clo;
V g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_clo;
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312(V, V, V, V);
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_clo;
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631(V, V, V, V);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_clo;
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1552018029x993523539(V, V);
V g_list_2ekeepIf_24s1552018029x993523539_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1552018029x993523539_clo;
V g_list_2emap_24f1285463828x1893111862(V, V, V);
V g_list_2emap_24f1285463828x1893111862_entry(V self, V *a);
extern Clo g_list_2emap_24f1285463828x1893111862_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str0, 69, "-- page's script of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str1, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str2, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str4, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str6, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str7, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str8, 0, "");
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit9, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str8), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit10, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str7), ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit9));
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit11, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str6), ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit10));
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit12, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str5), ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit11));
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit13, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str4), ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit12));
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit14, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str3), ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit13));
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit15, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str2), ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit14));
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit16, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str1), ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit15));
HEFF_TAG_LIT(g_heff_2ebuild_2epackaging_2ebuildText_lit_v_t_244, TAG_Cons, 2, ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str0), ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit16));
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str17, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str18, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Page` makes a");

static V g_heff_2ebuild_2epackaging_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2epackaging_2ebuildText_st;
static V g_heff_2ebuild_2epackaging_2ebuildText_init(void) {
  V v_t_244 = ((V)&g_heff_2ebuild_2epackaging_2ebuildText_lit_v_t_244);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str17); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str18); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2epackaging_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2epackaging_2ebuildText_st)) return g_heff_2ebuild_2epackaging_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2epackaging_2ebuildText_val, &g_heff_2ebuild_2epackaging_2ebuildText_st, g_heff_2ebuild_2epackaging_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_str0, 5, "win32");
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam2, 1, 0};
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s535099379x685970669(v_t_2414, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam2(V self, V *args) {
  V v_r_2423 = args[0];
  return v_r_2423;
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_243;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    heff_clo_take(self, 5);
    heff_drop(v_f_246);
    return (g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    switch (heff_tag_of(v_y_2432)) {
    case TAG_Left: {
      heff_take_n(v_y_2432, 0ULL, 1);
      heff_clo_take(self, 5);
      heff_drop(v_f_246);
      return (g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614(v_dir_240, v_rest_245, v_p_242, v_p_243));
    }
    case TAG_Right: {
      heff_take_n(v_y_2432, 0ULL, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam4, 1, 2, (V[]){v_p_243, v_f_246})));
    }
    default: return heff_nomatch(v_y_2432);
    }
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_st_2416;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_str0))) {
    v_st_2416 = NTAG(TAG_Windows);
  } else {
    v_st_2416 = NTAG(TAG_Posix);
  }
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2416), heff_dup(v_dir_240)));
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2416), heff_dup(v_f_246)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  V v_s_2420 = ({ V a_0 = v_st_2416; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2419); r_; });
  V v_path_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2420));
  V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2421; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2421); r_; });
  V v_a_2424 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam2_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  heff_clo_take(self, 5);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2429, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})));
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_str0, 5, "win32");
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam2, 1, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s535099379x685970669(v_t_2414, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam2(V self, V *args) {
  V v_r_2435 = args[0];
  return v_r_2435;
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam3(V self, V *args) {
  V v_x_2442 = args[0];
  V v_st_2416 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    V v_x_2443 = heff_field(v_x_2442, 0);
    V v_ru_24x_2442_24Left = heff_take_reuse_n(v_x_2442, 1ULL, 1);
    heff_clo_take(self, 7);
    return ({ V a_0 = v_st_2416; V a_1 = v_dir_240; V a_2 = v_f_246; V a_3 = v_text_247; V a_4 = v_p_242; V a_5 = v_rest_245; V a_6 = v_p_243; V b_7 = heff_tag_re_n(v_ru_24x_2442_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2443}); V r_ = (g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, b_7)); heff_drop(b_7); r_; });
  }
  case TAG_Right: {
    V v_y_2444 = heff_field(v_x_2442, 0);
    V v_ru_24x_2442_24Right = heff_take_reuse_n(v_x_2442, 1ULL, 1);
    switch (heff_tag_of(v_y_2444)) {
    case TAG_Left: {
      V v_err_2445 = heff_field(v_y_2444, 0);
      V v_ru_24y_2444_24Left = heff_take_reuse_n(v_y_2444, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2442_24Right, 1);
      heff_clo_take(self, 7);
      return ({ V a_0 = v_st_2416; V a_1 = v_dir_240; V a_2 = v_f_246; V a_3 = v_text_247; V a_4 = v_p_242; V a_5 = v_rest_245; V a_6 = v_p_243; V b_7 = heff_tag_re_n(v_ru_24y_2444_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2445}); V r_ = (g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, b_7)); heff_drop(b_7); r_; });
    }
    case TAG_Right: {
      V v_x_2446 = heff_field(v_y_2444, 0);
      heff_take_n(v_y_2444, 1ULL, 1);
      heff_clo_take(self, 7);
      return ({ V a_0 = v_st_2416; V a_1 = v_dir_240; V a_2 = v_f_246; V a_3 = v_text_247; V a_4 = v_p_242; V a_5 = v_rest_245; V a_6 = v_p_243; V b_7 = heff_tag_at_n(v_ru_24x_2442_24Right, TAG_Right, 1, (V[]){v_x_2446}); V r_ = (g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, b_7)); heff_drop(b_7); r_; });
    }
    default: return heff_nomatch(v_y_2444);
    }
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_st_2416;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_str0))) {
    v_st_2416 = NTAG(TAG_Windows);
  } else {
    v_st_2416 = NTAG(TAG_Posix);
  }
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2416), heff_dup(v_dir_240)));
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2416), heff_dup(v_f_246)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  V v_s_2420 = ({ V a_0 = v_st_2416; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
  HeffT3 v_t_2421 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2416), v_s_2420));
  {
    V v_field_2422 = v_t_2421.f[0];
    V v_field_2423 = v_t_2421.f[1];
    V v_field_2424 = v_t_2421.f[2];
    V v_d_2425 = v_field_2422;
    V v_a_2426 = v_field_2423;
    V v_xs_2427 = v_field_2424;
    V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
    V v_xs_2429 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2428; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2428); r_; });
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
    V v_t_2431 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2425, v_a_2426, v_t_2430});
    V v_s_2432 = ({ V a_0 = v_st_2416; V a_1 = v_t_2431; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2431, 3); r_; });
    V v_path_2433 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2432));
    V v_t_2434 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2433; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2433); r_; });
    V v_a_2436 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2434, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam2_clo)});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    heff_clo_take(self, 6);
    return (g_co_2eop_24s1896221640x2141527803(v_t_2441, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631_lam3, 1, 7, (V[]){v_st_2416, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
  }
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str4, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str5, 7, "module ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str6, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str8, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str9, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str10, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str11, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str13, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str16, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str17, 52, "-- checks them all, and `heff test` their doc tests.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str18, 15, "-- The program ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str19, 42, ": `heff build` builds it to .heff/bin/, as");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str20, 29, "-- a build, by `heff run app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str21, 10, "/main.hf`.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str22, 11, "module app.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str23, 5, ".main");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str24, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str25, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str27, 9, "main = do");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str28, 26, "  print (greeting \"world\")");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str30, 20, "main : Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str31, 13, "import std.io");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str32, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str33, 9, "import co");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str35, 68, "-- build.hf says, and `heff install` into ~/.heff/bin/; run, without");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str36, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str37, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str38, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str39, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str40, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str41, 64, "  unit \"greeting\" (assertEqual (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str42, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str43, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str44, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str45, 20, "module test.greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str46, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str47, 9, "-- tests.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str48, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str49, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str50, 68, "-- `heff test` runs the tests of every file of test/ (and src/): the");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str51, 71, "-- definitions of type `Test` (lib/check.hf), after the watches and doc");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str52, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str53, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str54, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str55, 35, "import manifest\012\012package : Package\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str56, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str57, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str58, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str59, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str60, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str61, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str62, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str63, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str64, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str65, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str66, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str67, 7, ".heff/\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str68, 1, ".");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str69, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str70, 20, "heff: the directory ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str71, 82, " has no name to name a package by: say the project's directory, as `heff init DIR`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str72, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str73, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str74, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str75, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str76, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str77, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str78, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str79, 3, "app");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str80, 4, "pkg_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str81, 4, "_app");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str82, 21, "heff: the directory `");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str83, 25, "` cannot name a package (");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str84, 36, "): name it otherwise, as `heff init ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str85, 1, "`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str86, 62, "heff: `heff` is heff's own package: name the project otherwise");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str87, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str88, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str89, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str90, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str91, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str92, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str93, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str94, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str95, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str96, 1, "\012");
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam2, 1, 0};
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_entry, 3, 0};

V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam0, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam2(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam5(V self, V *args) {
  V v_x_24114 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  if ((heff_dup(v_x_24114) == NTAG(TAG_True))) {
    heff_drop(v_x_24114);
    heff_clo_take(self, 3);
    V v_t_24115 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str87), v_dir_240), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str88));
    V v_t_24116 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_24115, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str89)), NTAG(TAG_MkUnit)});
    V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
    V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24120})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24121}), v_hd_241, v_k_242));
  } else {
    heff_drop(v_x_24114);
    heff_clo_take(self, 3);
    heff_drop(v_dir_240);
    V v_t_24122 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
    V v_t_24127 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24126})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24127}), v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam6(V self, V *args) {
  V v_x_24141 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_drop(v_x_24141);
  V v_t_24142 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24142})});
  V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
  V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
  V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
  V v_t_24147 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24146})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24147}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam7(V self, V *args) {
  V v_x_24155 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_drop(v_x_24155);
  V v_t_24156 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24156})});
  V v_t_24158 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24157})});
  V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
  V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
  V v_t_24161 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24160})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24161}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam4(V self, V *args) {
  V v_x_2485 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_x_2484 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  V v_shown_2486;
  heff_clo_take(self, 6);
  if (heff_strEq_c_lent(v_dir_240, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str68), 2)) {
    v_shown_2486 = v_x_243;
  } else {
    heff_drop(v_x_243);
    v_shown_2486 = heff_dup(v_dir_240);
  }
  V v_name_2487 = v_x_2438;
  V v_t_24113;
  if (heff_strEq_c_lent(v_name_2487, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str69), 2)) {
    heff_drop(v_name_2487);
    V v_t_2488 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str70), v_shown_2486), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str71));
    v_t_24113 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2488});
  } else {
    heff_drop(v_shown_2486);
    HeffT2 v_t_2489 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_name_2487));
    {
      V v_field_2491 = v_t_2489.f[1];
      int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
      if ((v_tag_2490 == ((int64_t)0ULL))) {
        V v_why_2492 = v_field_2491;
        V v_x_2493 = heff_dup(v_name_2487);
        V v_x2_2494 = (g_list_2emap_24f1285463828x1893111862(heff_dup(v_x_2493), MK_INT(0LL), heff_strLength(v_x_2493)));
        V v_s_2497;
        switch (heff_tag_of(v_x2_2494)) {
        case TAG_Nil: {
          v_s_2497 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str72);
          break;
        }
        case TAG_Cons: {
          V v_x_2495 = heff_field(v_x2_2494, 0);
          V v_xs_2496 = heff_field(v_x2_2494, 1);
          heff_take_n(v_x2_2494, 3ULL, 2);
          v_s_2497 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str73); V a_1 = v_x_2495; V a_2 = v_xs_2496; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2496); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2494);
        }
        V v_t_2498 = ({ V a_0 = v_s_2497; V a_1 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str74); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str75), v_s_2497, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_2497); r_; });
        V v_x2_2499 = (g_list_2ekeepIf_24s1552018029x993523539(MK_INT(0LL), v_t_2498));
        V v_x_24102;
        switch (heff_tag_of(v_x2_2499)) {
        case TAG_Nil: {
          v_x_24102 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str76);
          break;
        }
        case TAG_Cons: {
          V v_x_24100 = heff_field(v_x2_2499, 0);
          V v_xs_24101 = heff_field(v_x2_2499, 1);
          heff_take_n(v_x2_2499, 3ULL, 2);
          v_x_24102 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str77); V a_1 = v_x_24100; V a_2 = v_xs_24101; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24101); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2499);
        }
        V v_x_24103;
        if (heff_strEq_c_lent(v_x_24102, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str78), 2)) {
          heff_drop(v_x_24102);
          v_x_24103 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str79);
        } else {
          if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_24102, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_24102, MK_INT(0LL), 2)) <= ((int64_t)57ULL)))) {
            v_x_24103 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str80), v_x_24102);
          } else {
            v_x_24103 = v_x_24102;
          }
        }
        HeffT2 v_t_24104 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_24103));
        {
          V v_field_24106 = v_t_24104.f[1];
          int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
          V v_t_24108 = heff_bool(((v_tag_24105 == ((int64_t)0ULL)) ? ({ V v_x_24107 = heff_dup(v_field_24106); int c_ = 0; heff_drop(v_x_24107); c_; }) : 1));
          heff_drop(v_field_24106);
          V v_t_24109;
          if (((heff_dup(v_t_24108) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(v_x_24103), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get())))) {
            heff_drop(v_t_24108);
            v_t_24109 = v_x_24103;
          } else {
            heff_drop(v_t_24108);
            v_t_24109 = heff_strAppend(v_x_24103, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str81));
          }
          V v_t_24110 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str82), v_name_2487), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str83));
          V v_t_24111 = heff_strAppend(heff_strAppend(v_t_24110, v_why_2492), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str84));
          V v_t_24112 = heff_strAppend(heff_strAppend(v_t_24111, v_t_24109), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str85));
          v_t_24113 = heff_tag_n(TAG_Just, 1, (V[]){v_t_24112});
        }
      } else {
        heff_drop(v_field_2491);
        if (heff_strEq_c(v_name_2487, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          v_t_24113 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str86)});
        } else {
          v_t_24113 = NTAG(TAG_Nothing);
        }
      }
    }
  }
  switch (heff_tag_of(v_t_24113)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_x_2485)) {
    case TAG_Nil: {
      return (g_heff_2ebuild_2epackaging_2ewriteAll_24s2077819923x556970631(heff_dup(v_dir_240), v_x_2484, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam5, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
    }
    case TAG_Cons: {
      heff_drop_tag(v_x_2484, 2);
      V v_t_24132;
      switch (heff_tag_of(v_x_2485)) {
      case TAG_Nil: {
        v_t_24132 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str90);
        break;
      }
      case TAG_Cons: {
        V v_x_24130 = heff_field(v_x_2485, 0);
        V v_xs_24131 = heff_field(v_x_2485, 1);
        heff_take_n(v_x_2485, 3ULL, 2);
        v_t_24132 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str91); V a_1 = v_x_24130; V a_2 = v_xs_24131; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24131); r_; });
        break;
      }
      default: heff_nomatch(v_x_2485);
      }
      V v_t_24133 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str92), v_dir_240), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str93));
      V v_str_24134 = heff_strAppend(heff_strAppend(v_t_24133, v_t_24132), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str94));
      V v_t_24135 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_24134, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str95)), NTAG(TAG_MkUnit)});
      V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
      V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
      V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
      V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
      V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24140}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
    }
    default: return heff_nomatch(v_x_2485);
    }
  }
  case TAG_Just: {
    V v_why_24148 = heff_field(v_t_24113, 0);
    V v_ru_24t_24113_24Just = heff_take_reuse_n(v_t_24113, 1ULL, 1);
    heff_drop(v_x_2485);
    heff_drop(v_dir_240);
    heff_drop_tag(v_x_2484, 2);
    V v_t_24149 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_why_24148, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str96)), NTAG(TAG_MkUnit)});
    V v_t_24150 = heff_tag_at_n(v_ru_24t_24113_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
    V v_t_24151 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
    V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
    V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
    V v_t_24154 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24153})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24154}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam7, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  default: return heff_nomatch(v_t_24113);
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_st_2413;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str0))) {
    v_st_2413 = NTAG(TAG_Windows);
  } else {
    v_st_2413 = NTAG(TAG_Posix);
  }
  V v_dir_2414 = heff_dup(v_dir_240);
  V v_x3_2415 = heff_dup(v_x_243);
  V v_x_2438;
  if (heff_strEq_c_lent(v_dir_2414, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str1), 2)) {
    heff_drop(v_dir_2414);
    HeffT3 v_t_2416 = (g_std_2epath_2eparse_24cpr(v_st_2413, v_x3_2415));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_field_2419 = v_t_2416.f[2];
      V v_x11_2420 = v_field_2417;
      heff_drop(v_x11_2420);
      V v_x12_2421 = v_field_2418;
      heff_drop(v_x12_2421);
      V v_xs_2422 = v_field_2419;
      V v_t_2423 = v_xs_2422;
      V v_x1_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2423));
      switch (heff_tag_of(v_x1_2424)) {
      case TAG_Nil: {
        v_x_2438 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2425 = heff_field(v_x1_2424, 0);
        heff_take_n(v_x1_2424, 1ULL, 2);
        v_x_2438 = v_x_2425;
        break;
      }
      default: heff_nomatch(v_x1_2424);
      }
    }
  } else {
    heff_drop(v_x3_2415);
    HeffT3 v_t_2427 = (g_std_2epath_2eparse_24cpr(v_st_2413, v_dir_2414));
    {
      V v_field_2428 = v_t_2427.f[0];
      V v_field_2429 = v_t_2427.f[1];
      V v_field_2430 = v_t_2427.f[2];
      V v_x11_2431 = v_field_2428;
      heff_drop(v_x11_2431);
      V v_x12_2432 = v_field_2429;
      heff_drop(v_x12_2432);
      V v_xs_2433 = v_field_2430;
      V v_t_2434 = v_xs_2433;
      V v_x1_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2434));
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Nil: {
        v_x_2438 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 2);
        v_x_2438 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
    }
  }
  V v_name_2439 = heff_dup(v_x_2438);
  V v_v_2441;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_244)) {
  case TAG_Nothing: {
    v_v_2441 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str4);
    break;
  }
  case TAG_Just: {
    V v_x_2440 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 1);
    v_v_2441 = v_x_2440;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_name_2442 = heff_dup(v_name_2439);
  V v_t_2443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str5), v_name_2442), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str6));
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str7), NTAG(TAG_Nil)});
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str9), v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str11), v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str13), v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2447})});
  V v_t_2449 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str15); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str16); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str17), v_t_2448}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_name_2450 = heff_dup(v_name_2439);
  V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str18), heff_dup(v_name_2450)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str19));
  V v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str20), heff_dup(v_name_2450)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str21));
  V v_t_2453 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str22), heff_dup(v_name_2450)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str23));
  V v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str24), v_name_2450), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str25));
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str26), NTAG(TAG_Nil)});
  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str28), v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str30), v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str31), v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str32), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str33), v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str35), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, v_t_2460})});
  V v_t_2462 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str36); V a_1 = v_t_2451; V a_2 = v_t_2461; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2461, 2); r_; });
  V v_name_2463 = heff_dup(v_name_2439);
  V v_t_2464 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str37), v_name_2463), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str38));
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str39), NTAG(TAG_Nil)});
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str40), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str41), v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str42), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str43), v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str44), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str45), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str46), v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str47), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str48), v_t_2469})});
  V v_t_2471 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str49); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str50); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str51), v_t_2470}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str52), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str53));
  V v_t_2473 = heff_strAppend(heff_strAppend(v_t_2472, v_v_2441), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str54));
  V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str55), v_t_2473), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str56));
  V v_t_2475 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str57), heff_strAppend(v_t_2474, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str58))});
  V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str59), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str60));
  V v_t_2477 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str61), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str62));
  V v_t_2478 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str63), v_name_2439), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str64));
  V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str65), v_t_2471}), NTAG(TAG_Nil)});
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, heff_dup(g_heff_2ebuild_2epackaging_2ebuildText_get())}), v_t_2479});
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2477, v_t_2462}), v_t_2480});
  V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2476, v_t_2449}), v_t_2481});
  V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str66), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_str67)}), v_t_2482});
  V v_x_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_t_2483});
  return (g_heff_2ebuild_2epackaging_2eexisting_24s1160636487x784645614(heff_dup(v_dir_240), heff_dup(v_x_2484), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam4, 1, 6, (V[]){v_dir_240, v_x_243, v_x_2438, v_x_2484, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam2_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam3, 1, 5, (V[]){v_dir_240, v_x_243, v_x_244, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s353455707x1122081784_lam1, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_str0, 0, "");
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam3(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312(V v_x1_240, V v_acc_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_lit_246 = MK_INT(2026LL);
    V v_lit_247 = ((V)&g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_str0);
    V v_lit_248 = MK_INT(1LL);
    V v_f_249 = v_f_244;
    V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_249)));
    V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
    V v_a_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_ReadFile, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam0_clo)});
    V v_c_2426 = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam1, 2, 5, (V[]){v_a_2413, v_f_249, v_lit_246, v_lit_247, v_lit_248});
    return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam3, 1, 4, (V[]){v_z_242, v_acc_241, v_rest_245, v_z_243})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_f_249 = heff_env(self)[1];
  V v_lit_246 = heff_env(self)[2];
  V v_lit_247 = heff_env(self)[3];
  V v_lit_248 = heff_env(self)[4];
  V v_k_2415 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    V v_x_2422 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Left = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_hd_2414; V a_1 = v_f_249; V a_2 = v_lit_246; V a_3 = v_lit_247; V a_4 = v_lit_248; V a_5 = v_k_2415; V b_6 = heff_tag_re_n(v_ru_24x_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2422}); V r_ = (g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    switch (heff_tag_of(v_y_2423)) {
    case TAG_Left: {
      V v_err_2424 = heff_field(v_y_2423, 0);
      V v_ru_24y_2423_24Left = heff_take_reuse_n(v_y_2423, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2421_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_hd_2414; V a_1 = v_f_249; V a_2 = v_lit_246; V a_3 = v_lit_247; V a_4 = v_lit_248; V a_5 = v_k_2415; V b_6 = heff_tag_re_n(v_ru_24y_2423_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2424}); V r_ = (g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_y_2423, 0);
      heff_take_n(v_y_2423, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_hd_2414; V a_1 = v_f_249; V a_2 = v_lit_246; V a_3 = v_lit_247; V a_4 = v_lit_248; V a_5 = v_k_2415; V b_6 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_Right, 1, (V[]){v_x_2425}); V r_ = (g_heff_2ebuild_2etesting_2etestOneF_24s785434813x1869301249_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2423);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_a_2413 = heff_env(self)[0];
  V v_f_249 = heff_env(self)[1];
  V v_lit_246 = heff_env(self)[2];
  V v_lit_247 = heff_env(self)[3];
  V v_lit_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2420, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam2, 1, 6, (V[]){v_hd_2414, v_f_249, v_lit_246, v_lit_247, v_lit_248, v_k_2415})));
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_r_2428 = heff_env(self)[0];
  heff_drop(v_hd_2429);
  heff_clo_take(self, 1);
  V f_ = v_k_2430;
  args[0] = v_r_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_file_2432 = heff_env(self)[0];
  V v_wrong_2434 = heff_env(self)[1];
  V v_reports_2435 = heff_env(self)[2];
  V v_hd_2437 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2etesting_2etestReport_24s1557837877x1303916353(v_file_2432, v_wrong_2434, v_reports_2435, v_x_2439, v_hd_2437, v_k_2438));
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_file_2432 = heff_env(self)[1];
  V v_wrong_2434 = heff_env(self)[2];
  V v_reports_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2436;
  args[0] = heff_dup(v_hd_2437);
  args[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam6, 1, 5, (V[]){v_file_2432, v_wrong_2434, v_reports_2435, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam7(V self, V *args) {
  V v_x_2441 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2442 = (g_heff_2ebuild_2etesting_2eaddRes(v_acc_241, v_x_2441));
  return (g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312(v_rest_245, v_t_2442, v_z_242, v_z_243));
}
V g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_t_2440;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Settled: {
    V v_r_2428 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    v_t_2440 = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam4, 2, 1, (V[]){v_r_2428});
    break;
  }
  case TAG_Pend: {
    V v_p_2431 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    V v_file_2432 = heff_take_field(v_p_2431, 0);
    V v_outcomes_2433 = heff_take_field(v_p_2431, 3);
    V v_wrong_2434 = heff_take_field(v_p_2431, 1);
    V v_reports_2435 = heff_get_n(v_p_2431, 2, 7);
    V v_c_2436 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s295231510x1597151585(NTAG(TAG_False), heff_dup(v_file_2432), v_outcomes_2433));
    v_t_2440 = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam5, 2, 4, (V[]){v_c_2436, v_file_2432, v_wrong_2434, v_reports_2435});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  heff_clo_take(self, 4);
  V f_ = v_t_2440;
  heff_room[0] = heff_dup(v_z_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312_lam7, 1, 4, (V[]){v_acc_241, v_rest_245, v_z_242, v_z_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str10, 6, ": git ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str11, 2, ": ");
V g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980(V v_what_240, V v_argv_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str0), heff_dup(v_argv_241), ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str1), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s535099379x685970669(v_t_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_lam1, 1, 3, (V[]){v_argv_241, v_what_240, v_k_243})));
}
V g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_ended_2413 = heff_take_field(v_x_2412, 0);
  V v_err_2414 = heff_get_n(v_x_2412, 2, 3);
  V v_t_2415 = heff_dup(v_ended_2413);
  V v_t_2419;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Exited: {
    V v_n_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    v_t_2419 = heff_bool(heff_intEq_c_lent(v_n_2416, MK_INT(0LL), 2));
    heff_drop(v_n_2416);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2415, 0ULL, 1);
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_x_2440;
  heff_clo_take(self, 3);
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_argv_241);
    heff_drop(v_what_240);
    heff_drop(v_ended_2413);
    heff_drop(v_err_2414);
    heff_drop(v_t_2419);
    v_x_2440 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2419);
    V v_t_2422;
    switch (heff_tag_of(v_argv_241)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_argv_241, 0);
      V v_xs_2421 = heff_field(v_argv_241, 1);
      heff_take_n(v_argv_241, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str3); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_argv_241);
    }
    V v_t_2423 = v_ended_2413;
    V v_t_2432;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Exited: {
      heff_take_n(v_t_2423, 0ULL, 1);
      v_t_2432 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str4);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2423, 0ULL, 1);
      v_t_2432 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str5);
      break;
    }
    case TAG_TimedOut: {
      v_t_2432 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str6);
      break;
    }
    case TAG_NotRun: {
      V v_err_2426 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 1);
      V v_path_2427 = heff_take_field(v_err_2426, 3);
      V v_name_2428 = heff_take_field(v_err_2426, 1);
      V v_message_2429 = heff_get_n(v_err_2426, 2, 4);
      V v_t_2430 = heff_strAppend(heff_strAppend(v_path_2427, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str7)), v_name_2428);
      V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str8)), v_message_2429);
      v_t_2432 = heff_strAppend(v_t_2431, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str9));
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    V v_s_2433 = heff_strAppend(v_t_2432, v_err_2414);
    V v_t_2434 = (g_prelude_2eskipSpaces(v_s_2433, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_s_2433, 0)) - ((int64_t)1ULL));
    V v_t_2436 = (g_prelude_2eskipSpaces(v_s_2433, heff_box_word(v_t_2435), MK_INT(-1LL)));
    V v_t_2437 = heff_strAppend(heff_strAppend(v_what_240, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str10)), v_t_2422);
    V v_t_2438 = heff_strSlice(v_s_2433, v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
    V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980_str11)), v_t_2438);
    v_x_2440 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2439});
  }
  V f_ = v_k_243;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str10, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str12, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str17, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str1), heff_dup(v_v_240)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str2), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str4), v_t_245})});
  HEFF_LAST return g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str5), v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_pk_241 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_clo_take(self, 4);
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str10), heff_get_n(v_pk_241, 0, 4));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str11)), heff_dup(v_v_240));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str12)), v_v_240);
    V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str13)), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_why_2420 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_clo_take(self, 4);
    heff_drop_rec(v_pk_241, 4);
    heff_drop(v_v_240);
    V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str14), v_why_2420), ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str15));
    V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2421, NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_drop(v_x_2443);
  V v_t_2444 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str8), v_t_248})});
    heff_clo_take(self, 4);
    return (g_heff_2ebuild_2epackaging_2egitOk_24s2146508555x146267980(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str9), v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam1, 1, 4, (V[]){v_pk_241, v_v_240, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2435 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_clo_take(self, 4);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str16), v_why_2435), ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_str17));
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2436, NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306_lam3, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str0, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str1, 27, " expectations do not hold, ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str2, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str3, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str4, 37, " tests fail, or a file does not check");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str5, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672(V v_v_240, V v_pk_241, V v_r_242, V v_p_243, V v_p_244) {
top: ;
  V v_failed_245 = heff_take_field(v_r_242, 3);
  V v_testsFailed_246 = heff_take_field(v_r_242, 6);
  V v_unchecked_247 = heff_take_field(v_r_242, 4);
  V v_total_248 = heff_take_field(v_r_242, 2);
  V v_tests_249 = heff_get_n(v_r_242, 5, 8);
  V v_t_2413;
  if (heff_intLt_c_lent(MK_INT(0LL), v_failed_245, 1)) {
    heff_drop(v_unchecked_247);
    v_t_2413 = NTAG(TAG_True);
  } else {
    if (heff_intLt_c_lent(MK_INT(0LL), v_testsFailed_246, 1)) {
      heff_drop(v_unchecked_247);
      v_t_2413 = NTAG(TAG_True);
    } else {
      V v_t_2410 = v_unchecked_247;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nil: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2410, 0ULL, 2);
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
    }
  }
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    heff_drop(v_t_2413);
    V v_t_2414 = heff_strAppend(heff_intShow(v_failed_245), ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str0));
    V v_t_2415 = heff_strAppend(v_t_2414, heff_intShow(v_total_248));
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str1)), heff_intShow(v_testsFailed_246));
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str2)), heff_intShow(v_tests_249));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str3), heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str4)));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_str5)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_lam0, 1, 2, (V[]){v_p_243, v_p_244})));
  } else {
    heff_drop(v_failed_245);
    heff_drop(v_testsFailed_246);
    heff_drop(v_total_248);
    heff_drop(v_tests_249);
    heff_drop(v_t_2413);
    return (g_heff_2ebuild_2epackaging_2epublishTag_24s138555117x143496306(v_v_240, v_pk_241, v_p_243, v_p_244));
  }
}
V g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_p_243, v_p_244));
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str1, 6, "status");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str2, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str3, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str4, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str5, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str13, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str15, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str17, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str19, 67, "heff publish: what is published is what is committed: commit first\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str20, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str21, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str22, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str23, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str24, 0, "");
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam1(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam1, 1, 0};
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam8(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam8, 1, 0};
Clo g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244) {
top: ;
  V v_lit_245 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str0);
  V v_lit_246 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str1);
  V v_lit_247 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str2);
  V v_lit_248 = MK_INT(0LL);
  V v_lit_249 = MK_INT(0LL);
  V v_p_2410 = heff_dup(v_hd_243);
  V v_p_24104 = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam0, 1, 5, (V[]){v_v_240, v_hd_243, v_k_244, v_src_242, v_pk_241});
  V v_t_24105 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_247, NTAG(TAG_Nil)});
  V v_t_24106 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_lit_245, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_246, v_t_24105}), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str24), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), v_lit_248, v_lit_249, NTAG(TAG_False)});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_24106, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam8_clo)})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})});
  return (g_co_2eop_24s535099379x685970669(v_t_24113, v_p_2410, v_p_24104));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam1(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam3(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2454);
  V v_t_2455 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam4(V self, V *args) {
  V v_x_2473 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2473);
  V v_t_2474 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2479}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam5(V self, V *args) {
  V v_x_2493 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2493);
  V v_t_2494 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2499}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam7(V self, V *args) {
  V v_x_24103 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2epackaging_2epublishTested_24s1820532243x1518297672(v_v_240, v_pk_241, v_x_24103, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam6(V self, V *args) {
  V v_x_24102 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2epackaging_2etestAll_24s647496944x249873312(v_x_24102, heff_dup(g_heff_2ebuild_2etesting_2enoRes_get()), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam7, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ended_2412 = heff_env(self)[0];
  V v_err_2413 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_out_2414 = heff_env(self)[4];
  V v_v_240 = heff_env(self)[5];
  V v_src_242 = heff_env(self)[6];
  V v_pk_241 = heff_env(self)[7];
  V v_t_2426 = heff_dup(v_ended_2412);
  V v_t_2430;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Exited: {
    V v_n_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_t_2430 = heff_bool(!heff_intEq_c_lent(v_n_2427, MK_INT(0LL), 2));
    heff_drop(v_n_2427);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2425, 3);
    heff_clo_take(self, 8);
    heff_drop(v_out_2414);
    heff_drop(v_v_240);
    heff_drop(v_src_242);
    heff_drop(v_pk_241);
    heff_drop(v_t_2430);
    V v_t_2431 = v_ended_2412;
    V v_t_2440;
    switch (heff_tag_of(v_t_2431)) {
    case TAG_Exited: {
      heff_take_n(v_t_2431, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str9);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2431, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str10);
      break;
    }
    case TAG_TimedOut: {
      v_t_2440 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str11);
      break;
    }
    case TAG_NotRun: {
      V v_err_2434 = heff_field(v_t_2431, 0);
      heff_take_n(v_t_2431, 1ULL, 1);
      V v_path_2435 = heff_take_field(v_err_2434, 3);
      V v_name_2436 = heff_take_field(v_err_2434, 1);
      V v_message_2437 = heff_get_n(v_err_2434, 2, 4);
      V v_t_2438 = heff_strAppend(heff_strAppend(v_path_2435, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str12)), v_name_2436);
      V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str13)), v_message_2437);
      v_t_2440 = heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str14));
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    V v_s_2441 = heff_strAppend(v_t_2440, v_err_2413);
    V v_t_2442 = (g_prelude_2eskipSpaces(v_s_2441, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2443 = (heff_unbox_word(heff_strLength_lent(v_s_2441, 0)) - ((int64_t)1ULL));
    V v_t_2444 = (g_prelude_2eskipSpaces(v_s_2441, heff_box_word(v_t_2443), MK_INT(-1LL)));
    V v_t_2445 = heff_strSlice(v_s_2441, v_t_2442, heff_intAdd(v_t_2444, MK_INT(1LL)));
    V v_why_2446 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str15), v_t_2445);
    V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str16), v_why_2446), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str17));
    V v_t_2448 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2447, NTAG(TAG_MkUnit)});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2453}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam3, 1, 2, (V[]){v_hd_243, v_k_244})));
  } else {
    heff_clo_take(self, 8);
    heff_drop(v_ended_2412);
    heff_drop(v_err_2413);
    heff_drop(v_t_2430);
    V v_s_2461 = v_out_2414;
    V v_t_2462 = (g_prelude_2eskipSpaces(v_s_2461, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2463 = (heff_unbox_word(heff_strLength_lent(v_s_2461, 0)) - ((int64_t)1ULL));
    V v_t_2464 = (g_prelude_2eskipSpaces(v_s_2461, heff_box_word(v_t_2463), MK_INT(-1LL)));
    V v_t_2465 = heff_strSlice(v_s_2461, v_t_2462, heff_intAdd(v_t_2464, MK_INT(1LL)));
    V v_x1_2466 = heff_bool(heff_strEq_c_lent(v_t_2465, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str18), 2));
    heff_drop(v_t_2465);
    if (!(heff_dup(v_x1_2466) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2425, 3);
      heff_drop(v_v_240);
      heff_drop(v_src_242);
      heff_drop(v_pk_241);
      heff_drop(v_x1_2466);
      V v_t_2467 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str19), NTAG(TAG_MkUnit)});
      V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
      V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
      V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2472}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam4, 1, 2, (V[]){v_hd_243, v_k_244})));
    } else {
      heff_drop(v_x1_2466);
      V v_t_2480 = heff_get_n(v_x_2425, 0, 3);
      V v_t_2484;
      switch (heff_tag_of(v_t_2480)) {
      case TAG_Exited: {
        V v_n_2481 = heff_field(v_t_2480, 0);
        heff_take_n(v_t_2480, 1ULL, 1);
        v_t_2484 = heff_bool(heff_intEq_c_lent(v_n_2481, MK_INT(0LL), 2));
        heff_drop(v_n_2481);
        break;
      }
      case TAG_Signalled: {
        heff_take_n(v_t_2480, 0ULL, 1);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_TimedOut: {
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      case TAG_NotRun: {
        heff_take_n(v_t_2480, 0ULL, 1);
        v_t_2484 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2480);
      }
      if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
        heff_drop(v_src_242);
        heff_drop(v_pk_241);
        heff_drop(v_t_2484);
        V v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str20), v_v_240), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str21));
        V v_t_2486 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str22), v_t_2485), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str23));
        V v_t_2487 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2486, NTAG(TAG_MkUnit)});
        V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
        V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
        V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
        V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
        V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2492}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam5, 1, 2, (V[]){v_hd_243, v_k_244})));
      } else {
        heff_drop(v_t_2484);
        V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_242, NTAG(TAG_Nil)});
        V v_t_24101 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(v_t_24100, NTAG(TAG_Nil)));
        V f_ = v_t_24101;
        heff_room[0] = heff_dup(v_hd_243);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam6, 1, 4, (V[]){v_hd_243, v_v_240, v_pk_241, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_src_242 = heff_env(self)[3];
  V v_pk_241 = heff_env(self)[4];
  V v_ended_2412 = heff_take_field(v_x_2411, 0);
  V v_err_2413 = heff_take_field(v_x_2411, 2);
  V v_out_2414 = heff_get_n(v_x_2411, 1, 3);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str3), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str5), v_t_2415})});
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str7), v_t_2416}), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_str8), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam1_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  heff_clo_take(self, 5);
  return (g_co_2eop_24s535099379x685970669(v_t_2424, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam2, 1, 8, (V[]){v_ended_2412, v_err_2413, v_hd_243, v_k_244, v_out_2414, v_v_240, v_src_242, v_pk_241})));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357_lam8(V self, V *args) {
  V v_r_24107 = args[0];
  return v_r_24107;
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str6, 3, "src");
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659(V v_v_240, V v_l_241, V v_pk_242, V v_z_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(heff_rfield(v_pk_242, 0)), heff_dup(v_v_240)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_v_240);
      heff_drop_rec(v_l_241, 5);
      V v_why_248 = v_field_247;
      V v_t_249 = heff_strAppend(heff_get_n(v_pk_242, 0, 4), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str0));
      V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str1), heff_strAppend(v_t_249, v_why_248));
      V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str2)), NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam0, 1, 2, (V[]){v_z_243, v_z_244})));
    } else {
      heff_drop(v_field_247);
      V v_st_2424 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
      V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 0, 6);
      V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_2424), v_t_2425));
      V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2424), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str3)));
      V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
      V v_t_2429 = ({ V a_0 = v_st_2424; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2424); heff_drop(v_t_2428); r_; });
      V v_c_2430 = (g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(heff_dup(heff_rfield(v_l_241, 2)), v_t_2429));
      return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam1, 1, 5, (V[]){v_z_243, v_z_244, v_l_241, v_v_240, v_pk_242})});
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_z_243, v_z_244));
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam2(V self, V *args) {
  V v_x_2440 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_drop(v_x_2440);
  V v_t_2441 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), v_z_243, v_z_244));
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_why_2432 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    heff_clo_take(self, 5);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_242, 4);
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str4), v_why_2432), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str5));
    V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2431_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_lam2, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2431, 0ULL, 1);
    V v_st_2448 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
    heff_clo_take(self, 5);
    V v_t_2449 = heff_get_n(heff_get_n(v_l_241, 2, 5), 0, 6);
    V v_t_2450 = (g_std_2epath_2eparse(heff_dup(v_st_2448), v_t_2449));
    V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2448), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s1480286268x174334659_str6)));
    V v_t_2452 = (g_std_2epath_2ejoin(v_t_2450, v_t_2451));
    V v_t_2453 = ({ V a_0 = v_st_2448; V a_1 = v_t_2452; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2448); heff_drop(v_t_2452); r_; });
    return (g_heff_2ebuild_2epackaging_2epublishGit_24s1719526246x304957357(v_v_240, v_pk_242, v_t_2453, v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_x_2431);
  }
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str2, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str3, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str4, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam3(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_entry, 1, 0};

V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267(V v_v_240) {
top: ;
  HeffT5 v_t_241 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
  {
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    V v_field_245 = v_t_241.f[3];
    V v_field_246 = v_t_241.f[4];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_244, heff_tag_n(TAG_Cons, 2, (V[]){v_field_245, v_field_246})});
      V v_x_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_243, v_t_247});
      heff_drop_tag(v_x_248, 2);
      V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str0)));
      V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_249); r_; });
      V v_a_2412 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam0_clo)});
      return heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam1, 2, 2, (V[]){v_a_2412, v_v_240});
    } else {
      heff_drop(v_field_243);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam3, 2, 1, (V[]){v_v_240});
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267(a[0]);
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    heff_clo_take(self, 3);
    return (g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0(v_hd_2413, v_k_2414, v_v_240, heff_tag_re_n(v_ru_24x_2420_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2421})));
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Right = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    switch (heff_tag_of(v_y_2422)) {
    case TAG_Left: {
      V v_err_2423 = heff_field(v_y_2422, 0);
      V v_ru_24y_2422_24Left = heff_take_reuse_n(v_y_2422, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2420_24Right, 1);
      heff_clo_take(self, 3);
      return (g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0(v_hd_2413, v_k_2414, v_v_240, heff_tag_re_n(v_ru_24y_2422_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2423})));
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_y_2422, 0);
      heff_take_n(v_y_2422, 1ULL, 1);
      heff_clo_take(self, 3);
      return (g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_2ek_24l0(v_hd_2413, v_k_2414, v_v_240, heff_tag_at_n(v_ru_24x_2420_24Right, TAG_Right, 1, (V[]){v_x_2424})));
    }
    default: return heff_nomatch(v_y_2422);
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_a_2412 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2419, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam2, 1, 3, (V[]){v_hd_2413, v_k_2414, v_v_240})));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2425 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_2425, v_k_2426));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str1), v_v_240), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str2));
  V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str3), v_t_2427), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_str4));
  V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_2425), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s1290214234x996411267_lam4, 1, 2, (V[]){v_hd_2425, v_k_2426})));
}