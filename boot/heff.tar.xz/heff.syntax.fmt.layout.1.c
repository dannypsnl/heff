// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinding 25795
#define TAG_EBindingP 13114
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Union 35751
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_blank 295177582
#define LBL_col 308218
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_groups 709681407
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_ops 319788
#define LBL_raw 322210
#define LBL_rhsOf 309851086
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblockLast(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eblockLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLine_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_clo;
V g_heff_2esyntax_2efmt_2elayout_2egapEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2egapEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2egapEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enamesDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enamesDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2esig(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2esig_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esig_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
HeffT5 g_heff_2esyntax_2efmt_2elex_2eblockScan_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2eeolEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2eeolEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2eeolEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2emap_24s2139359291x1524787922(V);
V g_list_2emap_24s2139359291x1524787922_entry(V self, V *a);
extern Clo g_list_2emap_24s2139359291x1524787922_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2eflatten(V);
V g_std_2edoc_2eflatten_entry(V self, V *a);
extern Clo g_std_2edoc_2eflatten_clo;
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2egroup_24tok2(V, V);
V g_std_2edoc_2egroup_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_24tok2_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2ecomment_str3, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ecomment_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ecomment(V v_s_240) {
top: ;
  V v_x2_241 = (g_prelude_2esplit_2esplitFrom_240(v_s_240, ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str1), v_s_240, MK_INT(0LL), 5), NTAG(TAG_Nil)));
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V b_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  if (heff_strEq_c_lent(v_s_244, ((V)&g_heff_2esyntax_2efmt_2elayout_2ecomment_str3), 2)) {
    heff_drop(v_s_244);
    return NTAG(TAG_None);
  } else {
    return heff_tag_n(TAG_Text, 1, (V[]){v_s_244});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ecomment(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V v_s_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intLe_c_lent(v_b_242, v_a_241, 0)) {
    heff_drop(v_a_241);
    return NTAG(TAG_False);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_a_241, 0)) == ((int64_t)10ULL))) {
      heff_drop(v_a_241);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_a_241, MK_INT(1LL));
      V t_2 = v_b_242;
      v_s_240 = t_0;
      v_a_241 = t_1;
      v_b_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2enewlineIn(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2461 = heff_field(v_x1_240, 0);
    V v_e_2462 = heff_field(v_x1_240, 1);
    V v_t_2463 = heff_dup(heff_rfield(v_op_2461, 6));
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop(v_t_2463);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2463);
      V v_t_2464 = (g_heff_2esyntax_2ecst_2efirstE(v_e_2462));
      return heff_get_n(v_t_2464, 6, 9);
    }
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  case TAG_EWithBound: {
    return NTAG(TAG_False);
  }
  case TAG_EBinding: {
    return NTAG(TAG_False);
  }
  case TAG_EBindingP: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Atom: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EParen: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Named: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Tup: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Seg: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Braces: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Update: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EUSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_InstB: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFDefault: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Sum: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECon: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EField: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENeg: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETilde: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_App: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Op: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Ops: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_OpRhs: {
      V v_op_2464 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      HeffT2 v_t_2467 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_op_2464)}); V a_1 = heff_rfield(v_f_240, 0); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2469 = v_t_2467.f[1];
        int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
        if ((v_tag_2468 == ((int64_t)0ULL))) {
          V v_x_2470 = v_field_2469;
          heff_drop(v_x_2470);
          HeffT2 v_t_2471 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(v_f_240, v_rs_243));
          {
            V v_field_2473 = v_t_2471.f[1];
            int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
            if ((v_tag_2472 == ((int64_t)0ULL))) {
              V v_ops_2474 = v_field_2473;
              V v_f_2475 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_op_2464, 1, 9), v_ops_2474});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2475}});
            } else {
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              heff_drop_rec(v_op_2464, 9);
              heff_drop(v_field_2473);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_rs_243);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop_rec(v_op_2464, 9);
          heff_drop(v_field_2469);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_Ann: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BImp: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BAnn: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_BPat: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Lam: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Case: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAlt: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_If: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Do: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESBind: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetElse: {
      heff_take_n(v_x21_242, 0ULL, 7);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELetMut: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAssign: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWhile: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFor: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EJump: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EReturn: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ENest: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EArrow: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_IfThen: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETry: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECatch: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWith: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EWithBound: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBinding: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBindingP: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr_lam0(V self, V *args) {
  V v_g_2466 = args[0];
  V v_op_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_op_2464, 1, 9); V b_1 = heff_get_n(v_g_2466, 2, 5); V r_ = (g_list_2eany_24s1006624359x760861690(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V v_f_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_m_241)});
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_os_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_f_240), heff_dup(v_m_241), heff_dup(v_o_243)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Tighter: {
      V t_0 = v_f_240;
      V t_1 = v_o_243;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Looser: {
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Same: {
      heff_take_n(v_t_245, 0ULL, 1);
      V t_0 = v_f_240;
      V t_1 = v_m_241;
      V t_2 = v_os_244;
      v_f_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Unrelated: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_245, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblockLast_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblockLast_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblockLast_str2, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2eblockLast_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2eblockLast_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eblockLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eblockLast_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2eblockLast(V v_hang_240, V v_h_241, V v_one_242, V v_init2_243, V v_block_244) {
top: ;
  switch (heff_tag_of(v_init2_243)) {
  case TAG_Nil: {
    heff_drop(v_one_242);
    V v_a_245 = (g_std_2edoc_2egroup(v_h_241));
    V v_t_246;
    if (heff_intEq_c_lent(v_hang_240, MK_INT(0LL), 2)) {
      heff_drop(v_hang_240);
      v_t_246 = v_block_244;
    } else {
      v_t_246 = heff_tag_n(TAG_Nest, 2, (V[]){v_hang_240, v_block_244});
    }
    V v_t_247 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eblockLast_str0)}), v_t_246));
    return (g_std_2edoc_2e_3c_3e(v_a_245, v_t_247));
  }
  case TAG_Cons: {
    V v_d_2415 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eblockLast_lam0, 1, 1, (V[]){heff_dup(v_one_242)}); V a_2 = v_init2_243; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_dup(v_h_241), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2415})));
    V v_a_2417 = (g_std_2edoc_2eflatten(v_t_2416));
    V v_t_2418;
    if (heff_intEq_c_lent(v_hang_240, MK_INT(0LL), 2)) {
      heff_drop(v_hang_240);
      v_t_2418 = heff_dup(v_block_244);
    } else {
      v_t_2418 = heff_tag_n(TAG_Nest, 2, (V[]){v_hang_240, heff_dup(v_block_244)});
    }
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eblockLast_str1)}), v_t_2418));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_a_2417, v_t_2419));
    V v_a_2426 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eblockLast_lam1, 1, 1, (V[]){v_one_242}); V a_2 = v_init2_243; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop_tag(v_init2_243, 2); r_; });
    V v_t_2427 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eblockLast_str2)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_block_244})));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_a_2426, v_t_2427));
    V v_t_2429 = (g_std_2edoc_2e_3c_3e(v_h_241, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_t_2428})));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_get()), heff_tag_n(TAG_Union, 2, (V[]){v_t_2420, v_t_2429})));
  }
  default: return heff_nomatch(v_init2_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eblockLast_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eblockLast(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2efmt_2elayout_2eblockLast_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_one_242 = heff_env(self)[0];
  V v_t_2411 = (g_heff_2esyntax_2ecst_2efirstE(v_a_2410));
  V v_x1_2412 = heff_get_n(v_t_2411, 6, 9);
  V v_t_2413;
  if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
    heff_drop(v_x1_2412);
    v_t_2413 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_2412);
    v_t_2413 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tr(heff_call(v_one_242, 1, (V[]){v_a_2410}));
  return (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2414));
}
V g_heff_2esyntax_2efmt_2elayout_2eblockLast_lam1(V self, V *args) {
  V v_a_2421 = args[0];
  V v_one_242 = heff_env(self)[0];
  V v_t_2422 = (g_heff_2esyntax_2ecst_2efirstE(v_a_2421));
  V v_x1_2423 = heff_get_n(v_t_2422, 6, 9);
  V v_t_2424;
  if ((heff_dup(v_x1_2423) == NTAG(TAG_True))) {
    heff_drop(v_x1_2423);
    v_t_2424 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_2423);
    v_t_2424 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tr(heff_call(v_one_242, 1, (V[]){v_a_2421}));
  return (g_std_2edoc_2e_3c_3e(v_t_2424, v_t_2425));
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_ix_246 = heff_take_field(v_t_245, 7);
      V v_blank_247 = heff_get_n(v_t_245, 8, 9);
      HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_env_240, 1); V a_1 = v_ix_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_ix_246); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_t_2414;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = v_blank_247;
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop(v_blank_247);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_2410);
          v_t_2414 = v_blank_247;
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s265299328x217876366_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str7, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2422;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_2412;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkTF: {
        V v_xs_245 = heff_field(v_x_243, 0);
        switch (heff_tag_of(v_xs_245)) {
        case TAG_Nil: {
          v_t_2412 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str0), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str1), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_xs_245, 0);
          v_t_2412 = heff_dup(v_x_2410);
          break;
        }
        default: heff_nomatch(v_xs_245);
        }
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_ix_2413 = heff_take_field(v_t_2412, 7);
      V v_blank_2414 = heff_get_n(v_t_2412, 8, 9);
      HeffT2 v_t_2415 = ({ V a_0 = heff_rfield(v_env_240, 1); V a_1 = v_ix_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_ix_2413); r_; });
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        V v_t_2421;
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2418 = v_field_2417;
          switch (heff_tag_of(v_x_2418)) {
          case TAG_Nil: {
            v_t_2421 = v_blank_2414;
            break;
          }
          case TAG_Cons: {
            V v_x_2419 = heff_field(v_x_2418, 0);
            heff_take_n(v_x_2418, 1ULL, 2);
            heff_drop(v_blank_2414);
            v_t_2421 = heff_get_n(v_x_2419, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2418);
          }
        } else {
          heff_drop(v_field_2417);
          v_t_2421 = v_blank_2414;
        }
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          v_t_2422 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2421);
          v_t_2422 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2422 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2430;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_xs_2423 = heff_field(v_x_243, 0);
      switch (heff_tag_of(v_xs_2423)) {
      case TAG_Nil: {
        v_t_2430 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str3), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str4), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_xs_2423, 0);
        v_t_2430 = heff_dup(v_x_2428);
        break;
      }
      default: heff_nomatch(v_xs_2423);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2439;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_ty_2434 = heff_field(v_x_243, 3);
      V v_x15_2435 = heff_field(v_x_243, 4);
      switch (heff_tag_of(v_x15_2435)) {
      case TAG_Nothing: {
        v_t_2439 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_ty_2434)));
        break;
      }
      case TAG_Just: {
        V v_x151_2436 = heff_field(v_x15_2435, 0);
        switch (heff_tag_of(v_x151_2436)) {
        case TAG_MkPair: {
          V v_d_2438 = heff_field(v_x151_2436, 1);
          v_t_2439 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_d_2438)));
          break;
        }
        default: heff_nomatch(v_x151_2436);
        }
        break;
      }
      default: heff_nomatch(v_x15_2435);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2430, v_t_2439, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2461 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2460, v_t_2461));
    V v_t_2463 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2462));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2463));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args) {
  V v_e_2440 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_env_2441 = v_e_2440;
  heff_clo_take(self, 1);
  V v_x2_2442 = v_x_243;
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkTF: {
    V v_xs_2443 = heff_field(v_x2_2442, 0);
    V v_commas_2444 = heff_field(v_x2_2442, 1);
    V v_cc_2445 = heff_field(v_x2_2442, 2);
    V v_ty_2446 = heff_field(v_x2_2442, 3);
    V v_d_2447 = heff_field(v_x2_2442, 4);
    heff_take_n(v_x2_2442, 31ULL, 5);
    V v_t_2448 = (g_list_2emap_24s2139359291x1524787922(v_xs_2443));
    V v_a_2449 = ({ V a_0 = heff_dup(v_env_2441); V a_1 = v_t_2448; V a_2 = v_commas_2444; V r_ = (g_heff_2esyntax_2efmt_2elayout_2enamesDoc(a_0, a_1, a_2)); heff_drop(v_t_2448); heff_drop(v_commas_2444); r_; });
    V v_b_2450 = (g_heff_2esyntax_2efmt_2elayout_2esig(heff_dup(v_env_2441), v_cc_2445, v_ty_2446));
    V v_t_2451 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str6)}), v_b_2450));
    V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_a_2449, v_t_2451));
    V v_t_2459;
    switch (heff_tag_of(v_d_2447)) {
    case TAG_Nothing: {
      heff_drop(v_env_2441);
      v_t_2459 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_x21_2453 = heff_field(v_d_2447, 0);
      V v_ru_24d_2447_24Just = heff_take_reuse_n(v_d_2447, 1ULL, 1);
      switch (heff_tag_of(v_x21_2453)) {
      case TAG_MkPair: {
        V v_eq_2454 = heff_field(v_x21_2453, 0);
        V v_d_2455 = heff_field(v_x21_2453, 1);
        V v_ru_24x21_2453_24MkPair = heff_take_reuse_n(v_x21_2453, 3ULL, 2);
        V v_t_2456 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_2441), v_eq_2454));
        V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_2441, v_d_2455}));
        V v_t_2458 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x21_2453_24MkPair, v_t_2456, v_t_2457));
        v_t_2459 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24d_2447_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str7)}), v_t_2458));
        break;
      }
      default: heff_nomatch(v_x21_2453);
      }
      break;
    }
    default: heff_nomatch(v_d_2447);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2452, v_t_2459));
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(V v_env_240, V v_i_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x4_242, 0);
    V v_ds_244 = heff_field(v_x4_242, 1);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_243));
    V v_t_246 = (g_heff_2esyntax_2ecst_2efirstD(v_d_243));
    V v_t_247 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_243)));
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_246, v_t_247, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0, 1, 1, (V[]){heff_dup(v_d_243)})));
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ds_244));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_249, v_t_2410));
    return (g_std_2edoc_2e_3c_3e(v_t_245, v_t_2411));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2edeclsGo_24s1070300797x1607645945_lam0(V self, V *args) {
  V v_e_248 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_248; V a_1 = v_d_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enearGo_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2enearGo(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_cs_243);
      heff_drop(v_t_244);
      return heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_c_242, v_acc_241});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_cs_243;
      V t_1 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_c_242, v_acc_241});
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2enearGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V v_s_240, V v_i_241) {
top: ;
  V v_s_242 = heff_dup(v_s_240);
  V v_j_243 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, heff_dup(v_i_241)));
  V v_t_249;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_242, v_j_243, 0)) == ((int64_t)45ULL))) {
    V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_s_242, heff_dup(v_j_243)));
    V v_x_245 = heff_intSub_lent(v_t_244, v_j_243, 1);
    if (heff_intLe_c(MK_INT(2LL), v_x_245)) {
      V v_t_246 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_s_242, v_j_243));
      V v_c_247 = heff_strByteAt(v_s_242, v_t_246);
      v_t_249 = heff_bool(((((int64_t)0ULL) <= heff_peek_word(v_c_247)) ? ({ V v_t_248 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_247)))); int c_ = ({ V v_t_2419 = heff_strFind(heff_dup(v_t_248), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = !heff_intLe_c_lent(MK_INT(0LL), v_t_2419, 1); heff_drop(v_t_2419); c_; }); heff_drop(v_t_248); c_; }) : 1));
      heff_drop(v_c_247);
    } else {
      heff_drop(v_s_242);
      heff_drop(v_j_243);
      v_t_249 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_s_242);
    heff_drop(v_j_243);
    v_t_249 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, v_i_241));
    HEFF_LAST return g_heff_2esyntax_2efmt_2elex_2eeolEnd(v_s_240, v_t_2410);
  } else {
    heff_drop(v_t_249);
    V v_j_2411 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, heff_dup(v_i_241)));
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2411, 0)) == ((int64_t)123ULL)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_2411, MK_INT(1LL), 2), 2)) == ((int64_t)45ULL)))) {
      heff_drop(v_j_2411);
      V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2egapEnd(v_s_240, v_i_241));
      HeffT5 v_t_2413 = (g_heff_2esyntax_2efmt_2elex_2eblockScan_24cpr(v_s_240, v_t_2412, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)));
      {
        V v_field_2414 = v_t_2413.f[0];
        heff_drop(v_t_2413.f[1]);
        heff_drop(v_t_2413.f[2]);
        heff_drop(v_t_2413.f[3]);
        heff_drop(v_t_2413.f[4]);
        V t_0 = v_s_240;
        V t_1 = v_field_2414;
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_j_2411);
      return v_i_241;
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2etrailEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str0, 2, "--");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str1, 4, "-- |");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str3, 4, "-- |");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str4, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eexpectLine(V v_doc_240, V v_c_241) {
top: ;
  V v_blank_242 = heff_take_field(v_c_241, 1);
  V v_text_243 = heff_get_n(v_c_241, 0, 2);
  if (!(heff_dup(v_blank_242) == NTAG(TAG_True))) {
    heff_drop(v_blank_242);
    if (heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str0))) {
      if ((heff_dup(v_doc_240) == NTAG(TAG_True))) {
        if (heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str1))) {
          V v_s_244 = heff_strSlice(heff_dup(v_text_243), MK_INT(4LL), heff_strLength(v_text_243));
          V v_t_245 = (g_prelude_2eskipSpaces(v_s_244, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
          V v_t_247 = (g_prelude_2eskipSpaces(v_s_244, heff_box_word(v_t_246), MK_INT(-1LL)));
          V v_t_248 = heff_strSlice(v_s_244, v_t_245, heff_intAdd(v_t_247, MK_INT(1LL)));
          V v_x1_249 = heff_bool(heff_strEq_c_lent(v_t_248, ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str2), 2));
          heff_drop(v_t_248);
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
          heff_drop(v_x1_249);
          return v_ret_24bool;
        } else {
          heff_drop(v_text_243);
          return NTAG(TAG_False);
        }
      } else {
        if (!heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str3))) {
          V v_s_2410 = heff_strSlice(heff_dup(v_text_243), MK_INT(2LL), heff_strLength(v_text_243));
          V v_t_2411 = (g_prelude_2eskipSpaces(v_s_2410, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_s_2410, 0)) - ((int64_t)1ULL));
          V v_t_2413 = (g_prelude_2eskipSpaces(v_s_2410, heff_box_word(v_t_2412), MK_INT(-1LL)));
          V v_t_2414 = heff_strSlice(v_s_2410, v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
          V v_x1_2415 = heff_bool(heff_strEq_c_lent(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str4), 2));
          heff_drop(v_t_2414);
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
          heff_drop(v_x1_2415);
          return v_ret_24bool;
        } else {
          heff_drop(v_text_243);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_text_243);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_blank_242);
    heff_drop(v_text_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eexpectLine(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(V v_doc_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x2_241, 0);
    V v_cs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2eexpectLine(v_doc_240, heff_dup(v_c_243)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_c_243, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_246);
      V t_0 = v_doc_240;
      V t_1 = v_cs_244;
      V t_2 = v_u_247;
      v_doc_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_c_243);
      heff_drop(v_cs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}