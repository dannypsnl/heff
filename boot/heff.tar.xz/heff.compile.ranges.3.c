// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_IntEq 36665
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_MkArm 55352
#define TAG_MkRes 5766
#define TAG_MkResVals 58586
#define TAG_MkSeen 11336
#define TAG_MkSeenVals 17452
#define TAG_MkTest 41567
#define TAG_Unreached 46435
#define TAG_Within 10658
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define LBL_callersOf 583887482
#define LBL_calls 295783919
#define LBL_consts 592362651
#define LBL_dirty 296951788
#define LBL_escapes 914714193
#define LBL_fix 310927
#define LBL_forwards 1228451848
#define LBL_gathered 1327153563
#define LBL_given 299725719
#define LBL_grown 299987669
#define LBL_ints 9732907
#define LBL_marks 305024864
#define LBL_numeric 378927440
#define LBL_params 951713969
#define LBL_ranges 1008858625
#define LBL_tests 311609915
static uint32_t shape_fix__dirty__gathered[] = {LBL_fix, LBL_dirty, LBL_gathered};
static uint32_t shape_numeric__given__calls__ints__escapes[] = {LBL_numeric, LBL_given, LBL_calls, LBL_ints, LBL_escapes};
static uint32_t shape_params__grown__marks[] = {LBL_params, LBL_grown, LBL_marks};
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eranges_2eabsorbOne(V, V);
V g_heff_2ecompile_2eranges_2eabsorbOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eabsorbOne_clo;
V g_heff_2ecompile_2eranges_2eandR(V, V);
V g_heff_2ecompile_2eranges_2eandR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eandR_clo;
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2econdRefine(V, V, V, V);
V g_heff_2ecompile_2eranges_2econdRefine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2econdRefine_clo;
V g_heff_2ecompile_2eranges_2econdTests(V, V);
V g_heff_2ecompile_2eranges_2econdTests_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2econdTests_clo;
V g_heff_2ecompile_2eranges_2edivPositive_24tok2(V, V, V, V);
V g_heff_2ecompile_2eranges_2edivPositive_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2edivPositive_24tok2_clo;
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24dps_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ecompile_2eranges_2eheld_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2eisIntRel(V);
V g_heff_2ecompile_2eranges_2eisIntRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eisIntRel_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2eranges_2ejoinedFor(V, V, V, V);
V g_heff_2ecompile_2eranges_2ejoinedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoinedFor_clo;
V g_heff_2ecompile_2eranges_2emattering(V, V, V);
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emattering_clo;
V g_heff_2ecompile_2eranges_2emeet(V, V);
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emeet_clo;
V g_heff_2ecompile_2eranges_2enarrowTo(V, V, V);
V g_heff_2ecompile_2eranges_2enarrowTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowTo_clo;
V g_heff_2ecompile_2eranges_2eoperandRange(V, V, V);
V g_heff_2ecompile_2eranges_2eoperandRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eoperandRange_clo;
V g_heff_2ecompile_2eranges_2eprimRange(V, V);
V g_heff_2ecompile_2eranges_2eprimRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eprimRange_clo;
V g_heff_2ecompile_2eranges_2erangesEq(V, V);
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangesEq_clo;
V g_heff_2ecompile_2eranges_2etestOf(V, V);
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etestOf_clo;
V g_heff_2ecompile_2eranges_2etrimHigh(V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_clo;
V g_heff_2ecompile_2eranges_2etrimHigh_24tok1(V, V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_24tok1_clo;
V g_heff_2ecompile_2eranges_2etrimHigh_24tok2(V, V, V);
V g_heff_2ecompile_2eranges_2etrimHigh_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimHigh_24tok2_clo;
V g_heff_2ecompile_2eranges_2etrimLow(V, V);
V g_heff_2ecompile_2eranges_2etrimLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimLow_clo;
HeffT6 g_heff_2ecompile_2eranges_2ewalkArms_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkCond(V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkCond_clo;
V g_heff_2ecompile_2eranges_2ewalkGo(V, V, V);
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkGo_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
V g_heff_2ecompile_2eranges_2ewithTest(V, V, V);
V g_heff_2ecompile_2eranges_2ewithTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithTest_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewordOf_24cpr(V, V, V);
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s37738078x926874390(V, V, V, V);
V g_list_2efoldl_24s37738078x926874390_entry(V self, V *a);
extern Clo g_list_2efoldl_24s37738078x926874390_clo;
V g_list_2efoldl_24s510070423x219220408(V, V, V);
V g_list_2efoldl_24s510070423x219220408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s510070423x219220408_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2efoldl_24s92926977x826280221(V, V, V);
V g_list_2efoldl_24s92926977x826280221_entry(V self, V *a);
extern Clo g_list_2efoldl_24s92926977x826280221_clo;
V g_list_2emap_24s1792553290x233563724(V);
V g_list_2emap_24s1792553290x233563724_entry(V self, V *a);
extern Clo g_list_2emap_24s1792553290x233563724_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1026658656x682908126(V, V);
V g_list_2ezipWith_24s1026658656x682908126_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_clo;
V g_list_2ezipWith_24s1604775524x1614188687(V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2eranges_2emeet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emeet_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emeet(V v_r_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_Unreached: {
    heff_drop(v_s_241);
    return NTAG(TAG_Unreached);
  }
  case TAG_Within: {
    V v_a_242 = heff_field(v_r_240, 0);
    V v_b_243 = heff_field(v_r_240, 1);
    V v_ru_24r_240_24Within = heff_take_reuse_n(v_r_240, 3ULL, 2);
    switch (heff_tag_of(v_s_241)) {
    case TAG_Unreached: {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      heff_drop_cell(v_ru_24r_240_24Within, 2);
      return NTAG(TAG_Unreached);
    }
    case TAG_Within: {
      V v_c_244 = heff_field(v_s_241, 0);
      V v_d_245 = heff_field(v_s_241, 1);
      heff_take_n(v_s_241, 3ULL, 2);
      V v_x1_249;
      switch (heff_tag_of(v_a_242)) {
      case TAG_Nothing: {
        v_x1_249 = v_c_244;
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_a_242, 0);
        V v_ru_24a_242_24Just = heff_take_reuse_n(v_a_242, 1ULL, 1);
        switch (heff_tag_of(v_c_244)) {
        case TAG_Nothing: {
          v_x1_249 = heff_tag_re_n(v_ru_24a_242_24Just, TAG_Just, 1, 1ULL, (V[]){v_a_246});
          break;
        }
        case TAG_Just: {
          V v_b_247 = heff_field(v_c_244, 0);
          heff_take_n(v_c_244, 1ULL, 1);
          V v_t_248;
          if (heff_intLt_c_lent(v_a_246, v_b_247, 0)) {
            heff_drop(v_a_246);
            v_t_248 = v_b_247;
          } else {
            heff_drop(v_b_247);
            v_t_248 = v_a_246;
          }
          v_x1_249 = heff_tag_at_n(v_ru_24a_242_24Just, TAG_Just, 1, (V[]){v_t_248});
          break;
        }
        default: heff_nomatch(v_c_244);
        }
        break;
      }
      default: heff_nomatch(v_a_242);
      }
      V v_x2_2413;
      switch (heff_tag_of(v_b_243)) {
      case TAG_Nothing: {
        v_x2_2413 = v_d_245;
        break;
      }
      case TAG_Just: {
        V v_a_2410 = heff_field(v_b_243, 0);
        V v_ru_24b_243_24Just = heff_take_reuse_n(v_b_243, 1ULL, 1);
        switch (heff_tag_of(v_d_245)) {
        case TAG_Nothing: {
          v_x2_2413 = heff_tag_re_n(v_ru_24b_243_24Just, TAG_Just, 1, 1ULL, (V[]){v_a_2410});
          break;
        }
        case TAG_Just: {
          V v_b_2411 = heff_field(v_d_245, 0);
          heff_take_n(v_d_245, 1ULL, 1);
          V v_t_2412;
          if (heff_intLt_c_lent(v_a_2410, v_b_2411, 0)) {
            heff_drop(v_b_2411);
            v_t_2412 = v_a_2410;
          } else {
            heff_drop(v_a_2410);
            v_t_2412 = v_b_2411;
          }
          v_x2_2413 = heff_tag_at_n(v_ru_24b_243_24Just, TAG_Just, 1, (V[]){v_t_2412});
          break;
        }
        default: heff_nomatch(v_d_245);
        }
        break;
      }
      default: heff_nomatch(v_b_243);
      }
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nothing: {
        return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_x1_249, v_x2_2413});
      }
      case TAG_Just: {
        V v_lo_2414 = heff_dup(heff_field(v_x1_249, 0));
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_Nothing: {
          heff_drop(v_lo_2414);
          return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){v_x1_249, v_x2_2413});
        }
        case TAG_Just: {
          V v_hi_2415 = heff_field(v_x2_2413, 0);
          V v_ru_24x2_2413_24Just = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
          heff_drop_tag(v_x1_249, 1);
          if (heff_intLt_c_lent(v_hi_2415, v_lo_2414, 0)) {
            heff_drop_cell(v_ru_24r_240_24Within, 2);
            heff_drop(v_lo_2414);
            heff_drop(v_hi_2415);
            heff_drop_cell(v_ru_24x2_2413_24Just, 1);
            return NTAG(TAG_Unreached);
          } else {
            return heff_tag_at_n(v_ru_24r_240_24Within, TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24x2_2413_24Just, TAG_Just, 1, (V[]){v_lo_2414}), heff_tag_n(TAG_Just, 1, (V[]){v_hi_2415})});
          }
        }
        default: return heff_nomatch(v_x2_2413);
        }
      }
      default: return heff_nomatch(v_x1_249);
      }
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2emeet(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2eandR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eandR_entry, 2, 0};

V g_heff_2ecompile_2eranges_2eandR(V v_a_240, V v_b_241) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_a_240)) {
  case TAG_Unreached: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_Within: {
    V v_lo_242 = heff_dup(heff_field(v_a_240, 0));
    switch (heff_tag_of(v_lo_242)) {
    case TAG_Nothing: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_lo_242, 0);
      heff_take_n(v_lo_242, 1ULL, 1);
      if (heff_intLe_c(MK_INT(0LL), v_a_244)) {
        switch (heff_tag_of(v_b_241)) {
        case TAG_Unreached: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_Within: {
          V v_lo_245 = heff_dup(heff_field(v_b_241, 0));
          switch (heff_tag_of(v_lo_245)) {
          case TAG_Nothing: {
            v_t_248 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_a_247 = heff_field(v_lo_245, 0);
            heff_take_n(v_lo_245, 1ULL, 1);
            v_t_248 = heff_bool(heff_intLe_c_lent(MK_INT(0LL), v_a_247, 1));
            heff_drop(v_a_247);
            break;
          }
          default: heff_nomatch(v_lo_245);
          }
          break;
        }
        default: heff_nomatch(v_b_241);
        }
      } else {
        v_t_248 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_lo_242);
    }
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    HEFF_LAST return g_heff_2ecompile_2eranges_2emeet(v_a_240, v_b_241);
  } else {
    heff_drop(v_t_248);
    switch (heff_tag_of(v_a_240)) {
    case TAG_Unreached: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Unreached: {
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Within: {
        V v_lo_249 = heff_dup(heff_field(v_b_241, 0));
        switch (heff_tag_of(v_lo_249)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_b_241)) {
          case TAG_Within: {
            heff_take_n(v_b_241, 0ULL, 2);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          default: return heff_nomatch(v_b_241);
          }
        }
        case TAG_Just: {
          V v_a_2413 = heff_field(v_lo_249, 0);
          V v_ru_24lo_249_24Just = heff_take_reuse_n(v_lo_249, 1ULL, 1);
          if (heff_intLe_c(MK_INT(0LL), v_a_2413)) {
            V v_t_2416;
            switch (heff_tag_of(v_b_241)) {
            case TAG_Unreached: {
              v_t_2416 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Within: {
              V v_hi_2415 = heff_field(v_b_241, 1);
              heff_take_n(v_b_241, 2ULL, 2);
              v_t_2416 = v_hi_2415;
              break;
            }
            default: heff_nomatch(v_b_241);
            }
            return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_249_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2416});
          } else {
            heff_drop_tag(v_b_241, 2);
            heff_drop_cell(v_ru_24lo_249_24Just, 1);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        default: return heff_nomatch(v_lo_249);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    case TAG_Within: {
      V v_lo_2417 = heff_dup(heff_field(v_a_240, 0));
      switch (heff_tag_of(v_lo_2417)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Within: {
          V v_ru_24a_240_24Within = heff_take_reuse_n(v_a_240, 0ULL, 2);
          switch (heff_tag_of(v_b_241)) {
          case TAG_Unreached: {
            heff_drop_cell(v_ru_24a_240_24Within, 2);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          case TAG_Within: {
            V v_lo_2421 = heff_dup(heff_field(v_b_241, 0));
            switch (heff_tag_of(v_lo_2421)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24a_240_24Within, 2);
              switch (heff_tag_of(v_b_241)) {
              case TAG_Within: {
                heff_take_n(v_b_241, 0ULL, 2);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              default: return heff_nomatch(v_b_241);
              }
            }
            case TAG_Just: {
              V v_a_2425 = heff_field(v_lo_2421, 0);
              V v_ru_24lo_2421_24Just = heff_take_reuse_n(v_lo_2421, 1ULL, 1);
              if (heff_intLe_c(MK_INT(0LL), v_a_2425)) {
                V v_t_2428;
                switch (heff_tag_of(v_b_241)) {
                case TAG_Unreached: {
                  v_t_2428 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Within: {
                  V v_hi_2427 = heff_field(v_b_241, 1);
                  heff_take_n(v_b_241, 2ULL, 2);
                  v_t_2428 = v_hi_2427;
                  break;
                }
                default: heff_nomatch(v_b_241);
                }
                return heff_tag_at_n(v_ru_24a_240_24Within, TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2421_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2428});
              } else {
                heff_drop_tag(v_b_241, 2);
                heff_drop_cell(v_ru_24a_240_24Within, 2);
                heff_drop_cell(v_ru_24lo_2421_24Just, 1);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_lo_2421);
            }
          }
          default: return heff_nomatch(v_b_241);
          }
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_Just: {
        V v_a_2429 = heff_field(v_lo_2417, 0);
        V v_ru_24lo_2417_24Just = heff_take_reuse_n(v_lo_2417, 1ULL, 1);
        if (heff_intLe_c(MK_INT(0LL), v_a_2429)) {
          heff_drop(v_b_241);
          V v_t_2432;
          switch (heff_tag_of(v_a_240)) {
          case TAG_Unreached: {
            v_t_2432 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Within: {
            V v_hi_2431 = heff_field(v_a_240, 1);
            heff_take_n(v_a_240, 2ULL, 2);
            v_t_2432 = v_hi_2431;
            break;
          }
          default: heff_nomatch(v_a_240);
          }
          return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2417_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2432});
        } else {
          heff_drop_tag(v_a_240, 2);
          switch (heff_tag_of(v_b_241)) {
          case TAG_Unreached: {
            heff_drop_cell(v_ru_24lo_2417_24Just, 1);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
          case TAG_Within: {
            V v_lo_2433 = heff_dup(heff_field(v_b_241, 0));
            switch (heff_tag_of(v_lo_2433)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24lo_2417_24Just, 1);
              switch (heff_tag_of(v_b_241)) {
              case TAG_Within: {
                heff_take_n(v_b_241, 0ULL, 2);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
              default: return heff_nomatch(v_b_241);
              }
            }
            case TAG_Just: {
              V v_a_2437 = heff_field(v_lo_2433, 0);
              heff_take_n(v_lo_2433, 1ULL, 1);
              if (heff_intLe_c(MK_INT(0LL), v_a_2437)) {
                V v_t_2440;
                switch (heff_tag_of(v_b_241)) {
                case TAG_Unreached: {
                  v_t_2440 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Within: {
                  V v_hi_2439 = heff_field(v_b_241, 1);
                  heff_take_n(v_b_241, 2ULL, 2);
                  v_t_2440 = v_hi_2439;
                  break;
                }
                default: heff_nomatch(v_b_241);
                }
                return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24lo_2417_24Just, TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2440});
              } else {
                heff_drop_tag(v_b_241, 2);
                heff_drop_cell(v_ru_24lo_2417_24Just, 1);
                return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
              }
            }
            default: return heff_nomatch(v_lo_2433);
            }
          }
          default: return heff_nomatch(v_b_241);
          }
        }
      }
      default: return heff_nomatch(v_lo_2417);
      }
    }
    default: return heff_nomatch(v_a_240);
    }
  }
}
V g_heff_2ecompile_2eranges_2eandR_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eandR(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eranges_2eheld_24cpr(V v_p_240, V v_yes_241, V v_ra_242, V v_rb_243) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_IntEq: {
    if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
      V v_t_244 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), heff_dup(v_rb_243)));
      V v_t_245 = (g_heff_2ecompile_2eranges_2emeet(v_ra_242, v_rb_243));
      return ((HeffT2){{v_t_244, v_t_245}});
    } else {
      V v_t_2411;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_2411 = heff_dup(v_ra_242);
        break;
      }
      case TAG_Within: {
        V v_s1_246 = heff_dup(heff_field(v_rb_243, 0));
        V v_s2_247 = heff_dup(heff_field(v_rb_243, 1));
        switch (heff_tag_of(v_s1_246)) {
        case TAG_Nothing: {
          heff_drop(v_s2_247);
          v_t_2411 = heff_dup(v_ra_242);
          break;
        }
        case TAG_Just: {
          V v_v_248 = heff_field(v_s1_246, 0);
          V v_ru_24s1_246_24Just = heff_take_reuse_n(v_s1_246, 1ULL, 1);
          switch (heff_tag_of(v_s2_247)) {
          case TAG_Nothing: {
            heff_drop(v_v_248);
            heff_drop_cell(v_ru_24s1_246_24Just, 1);
            v_t_2411 = heff_dup(v_ra_242);
            break;
          }
          case TAG_Just: {
            V v_w_249 = heff_field(v_s2_247, 0);
            heff_take_n(v_s2_247, 1ULL, 1);
            if (heff_intEq_c_lent(v_v_248, v_w_249, 2)) {
              V v_t_2410 = (g_heff_2ecompile_2eranges_2etrimLow(heff_dup(v_v_248), heff_dup(v_ra_242)));
              v_t_2411 = (g_heff_2ecompile_2eranges_2etrimHigh_24tok1(v_ru_24s1_246_24Just, v_v_248, v_t_2410));
            } else {
              heff_drop(v_v_248);
              heff_drop_cell(v_ru_24s1_246_24Just, 1);
              v_t_2411 = heff_dup(v_ra_242);
            }
            break;
          }
          default: heff_nomatch(v_s2_247);
          }
          break;
        }
        default: heff_nomatch(v_s1_246);
        }
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_2417;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2417 = v_rb_243;
        break;
      }
      case TAG_Within: {
        V v_s1_2412 = heff_field(v_ra_242, 0);
        V v_s2_2413 = heff_field(v_ra_242, 1);
        V v_ru_24ra_242_24Within = heff_take_reuse_n(v_ra_242, 3ULL, 2);
        switch (heff_tag_of(v_s1_2412)) {
        case TAG_Nothing: {
          heff_drop(v_s2_2413);
          heff_drop_cell(v_ru_24ra_242_24Within, 2);
          v_t_2417 = v_rb_243;
          break;
        }
        case TAG_Just: {
          V v_v_2414 = heff_field(v_s1_2412, 0);
          heff_take_n(v_s1_2412, 1ULL, 1);
          switch (heff_tag_of(v_s2_2413)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24ra_242_24Within, 2);
            heff_drop(v_v_2414);
            v_t_2417 = v_rb_243;
            break;
          }
          case TAG_Just: {
            V v_w_2415 = heff_field(v_s2_2413, 0);
            heff_take_n(v_s2_2413, 1ULL, 1);
            if (heff_intEq_c_lent(v_v_2414, v_w_2415, 2)) {
              V v_t_2416 = (g_heff_2ecompile_2eranges_2etrimLow(heff_dup(v_v_2414), v_rb_243));
              v_t_2417 = (g_heff_2ecompile_2eranges_2etrimHigh_24tok2(v_ru_24ra_242_24Within, v_v_2414, v_t_2416));
            } else {
              heff_drop_cell(v_ru_24ra_242_24Within, 2);
              heff_drop(v_v_2414);
              v_t_2417 = v_rb_243;
            }
            break;
          }
          default: heff_nomatch(v_s2_2413);
          }
          break;
        }
        default: heff_nomatch(v_s1_2412);
        }
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      return ((HeffT2){{v_t_2411, v_t_2417}});
    }
  }
  case TAG_IntLt: {
    if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
      V v_t_2421;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_hi_2419 = heff_dup(heff_field(v_rb_243, 1));
        switch (heff_tag_of(v_hi_2419)) {
        case TAG_Nothing: {
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2420 = heff_field(v_hi_2419, 0);
          V v_ru_24hi_2419_24Just = heff_take_reuse_n(v_hi_2419, 1ULL, 1);
          v_t_2421 = heff_tag_at_n(v_ru_24hi_2419_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2420, MK_INT(-1LL))});
          break;
        }
        default: heff_nomatch(v_hi_2419);
        }
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_2422 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2421});
      V v_t_2423 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2422));
      V v_t_2427;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_2424 = heff_field(v_ra_242, 0);
        heff_take_n(v_ra_242, 1ULL, 2);
        switch (heff_tag_of(v_lo_2424)) {
        case TAG_Nothing: {
          v_t_2427 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2426 = heff_field(v_lo_2424, 0);
          V v_ru_24lo_2424_24Just = heff_take_reuse_n(v_lo_2424, 1ULL, 1);
          v_t_2427 = heff_tag_at_n(v_ru_24lo_2424_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2426, MK_INT(1LL))});
          break;
        }
        default: heff_nomatch(v_lo_2424);
        }
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      V v_t_2428 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2427, NTAG(TAG_Nothing)});
      V v_t_2429 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2428));
      return ((HeffT2){{v_t_2423, v_t_2429}});
    } else {
      V v_t_2432;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_2430 = heff_dup(heff_field(v_rb_243, 0));
        v_t_2432 = v_lo_2430;
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_2433 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2432, NTAG(TAG_Nothing)});
      V v_t_2434 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2433));
      V v_t_2437;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_hi_2436 = heff_field(v_ra_242, 1);
        heff_take_n(v_ra_242, 2ULL, 2);
        v_t_2437 = v_hi_2436;
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      V v_t_2438 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2437});
      V v_t_2439 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2438));
      return ((HeffT2){{v_t_2434, v_t_2439}});
    }
  }
  case TAG_IntLe: {
    if ((heff_dup(v_yes_241) == NTAG(TAG_True))) {
      V v_t_2442;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_2442 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_hi_2441 = heff_dup(heff_field(v_rb_243, 1));
        v_t_2442 = v_hi_2441;
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_2443 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2442});
      V v_t_2444 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2443));
      V v_t_2447;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2447 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_2445 = heff_field(v_ra_242, 0);
        heff_take_n(v_ra_242, 1ULL, 2);
        v_t_2447 = v_lo_2445;
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      V v_t_2448 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2447, NTAG(TAG_Nothing)});
      V v_t_2449 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2448));
      return ((HeffT2){{v_t_2444, v_t_2449}});
    } else {
      V v_t_2453;
      switch (heff_tag_of(v_rb_243)) {
      case TAG_Unreached: {
        v_t_2453 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_2450 = heff_dup(heff_field(v_rb_243, 0));
        switch (heff_tag_of(v_lo_2450)) {
        case TAG_Nothing: {
          v_t_2453 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2452 = heff_field(v_lo_2450, 0);
          V v_ru_24lo_2450_24Just = heff_take_reuse_n(v_lo_2450, 1ULL, 1);
          v_t_2453 = heff_tag_at_n(v_ru_24lo_2450_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2452, MK_INT(1LL))});
          break;
        }
        default: heff_nomatch(v_lo_2450);
        }
        break;
      }
      default: heff_nomatch(v_rb_243);
      }
      V v_t_2454 = heff_tag_n(TAG_Within, 2, (V[]){v_t_2453, NTAG(TAG_Nothing)});
      V v_t_2455 = (g_heff_2ecompile_2eranges_2emeet(heff_dup(v_ra_242), v_t_2454));
      V v_t_2459;
      switch (heff_tag_of(v_ra_242)) {
      case TAG_Unreached: {
        v_t_2459 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_hi_2457 = heff_field(v_ra_242, 1);
        heff_take_n(v_ra_242, 2ULL, 2);
        switch (heff_tag_of(v_hi_2457)) {
        case TAG_Nothing: {
          v_t_2459 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2458 = heff_field(v_hi_2457, 0);
          V v_ru_24hi_2457_24Just = heff_take_reuse_n(v_hi_2457, 1ULL, 1);
          v_t_2459 = heff_tag_at_n(v_ru_24hi_2457_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2458, MK_INT(-1LL))});
          break;
        }
        default: heff_nomatch(v_hi_2457);
        }
        break;
      }
      default: heff_nomatch(v_ra_242);
      }
      V v_t_2460 = heff_tag_n(TAG_Within, 2, (V[]){NTAG(TAG_Nothing), v_t_2459});
      V v_t_2461 = (g_heff_2ecompile_2eranges_2emeet(v_rb_243, v_t_2460));
      return ((HeffT2){{v_t_2455, v_t_2461}});
    }
  }
  default: {
    return ((HeffT2){{v_ra_242, v_rb_243}});
  }
  }
}
Clo g_heff_2ecompile_2eranges_2econdTests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2econdTests_entry, 2, 0};

V g_heff_2ecompile_2eranges_2econdTests(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_CFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CRel = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_245;
    switch (heff_tag_of(v_p_242)) {
    case TAG_WordEq: {
      v_t_245 = NTAG(TAG_IntEq);
      break;
    }
    case TAG_WordLt: {
      v_t_245 = NTAG(TAG_IntLt);
      break;
    }
    case TAG_WordLe: {
      v_t_245 = NTAG(TAG_IntLe);
      break;
    }
    default: {
      v_t_245 = heff_dup(v_p_242);
      break;
    }
    }
    V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eranges_2eisIntRel(a_0)); heff_drop(v_t_245); r_; });
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24CRel, TAG_MkTest, 3, (V[]){v_p_242, v_a_243, v_b_244}), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_p_242);
      heff_drop(v_a_243);
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24x2_241_24CRel, 3);
      heff_drop(v_t_246);
      return NTAG(TAG_Nil);
    }
  }
  case TAG_CTest: {
    V v_x21_247 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_247)) {
    case TAG_EVar: {
      V v_x_248 = heff_field(v_x21_247, 0);
      heff_take_n(v_x21_247, 1ULL, 1);
      HeffT2 v_t_249 = ({ V a_0 = heff_rfield(v_env_240, 1); V a_1 = v_x_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_248); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_t_2412 = v_field_2411;
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_field_2411);
          return NTAG(TAG_Nil);
        }
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_ELam: {
      heff_take_n(v_x21_247, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x21_247, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELet: {
      heff_take_n(v_x21_247, 0ULL, 3);
      return NTAG(TAG_Nil);
    }
    case TAG_ERecord: {
      heff_take_n(v_x21_247, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProj: {
      heff_take_n(v_x21_247, 0ULL, 4);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x21_247, 0ULL, 3);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x21_247, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x21_247, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ECall: {
      heff_take_n(v_x21_247, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_nf(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_EStr: {
      heff_take_n(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_247, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBool: {
      heff_take_n(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_ESet: {
      heff_take_n(v_x21_247, 0ULL, 3);
      return NTAG(TAG_Nil);
    }
    case TAG_EValues: {
      heff_take_n(v_x21_247, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_EFix: {
      heff_take_n(v_x21_247, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x21_247);
    }
  }
  case TAG_CNot: {
    V v_k_2451 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_env_240;
    V t_1 = v_k_2451;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2452 = heff_field(v_x2_241, 0);
    V v_b_2453 = heff_field(v_x2_241, 1);
    V v_k_2454 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2455 = (g_heff_2ecompile_2eranges_2econdTests(v_env_240, v_a_2452));
    V v_t_2456 = (g_heff_2ecompile_2eranges_2econdTests(v_env_240, v_b_2453));
    V v_t_2457 = (g_heff_2ecompile_2eranges_2econdTests(v_env_240, v_k_2454));
    V v_t_2458 = (g_prelude_2e_2b_2b(v_t_2456, v_t_2457));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2455, v_t_2458);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eranges_2econdTests_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2econdTests(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eranges_2etestOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etestOf_entry, 2, 0};

V g_heff_2ecompile_2eranges_2etestOf(V v_env_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_env_240, 1, 2); V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_242); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_it1_246 = v_field_245;
        switch (heff_tag_of(v_it1_246)) {
        case TAG_MkTest: {
          V v_p_247 = heff_field(v_it1_246, 0);
          V v_a_248 = heff_field(v_it1_246, 1);
          V v_b_249 = heff_field(v_it1_246, 2);
          V v_ru_24it1_246_24MkTest = heff_take_reuse_n(v_it1_246, 7ULL, 3);
          return heff_tag_at_n(v_ru_24e_241_24EVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24it1_246_24MkTest, TAG_CRel, 3, (V[]){v_p_247, v_a_248, v_b_249})});
        }
        default: return heff_nomatch(v_it1_246);
        }
      } else {
        heff_drop_cell(v_ru_24e_241_24EVar, 1);
        heff_drop(v_field_245);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    V v_p_2430 = heff_field(v_e_241, 0);
    V v_e2_2431 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_env_240, 2);
    switch (heff_tag_of(v_e2_2431)) {
    case TAG_Nil: {
      heff_drop(v_p_2430);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_a_2432 = heff_field(v_e2_2431, 0);
      V v_e22_2433 = heff_field(v_e2_2431, 1);
      heff_take_n(v_e2_2431, 3ULL, 2);
      switch (heff_tag_of(v_e22_2433)) {
      case TAG_Nil: {
        heff_drop(v_p_2430);
        heff_drop(v_a_2432);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_b_2434 = heff_field(v_e22_2433, 0);
        V v_e222_2435 = heff_field(v_e22_2433, 1);
        heff_take_n(v_e22_2433, 3ULL, 2);
        switch (heff_tag_of(v_e222_2435)) {
        case TAG_Nil: {
          V v_t_2436;
          switch (heff_tag_of(v_p_2430)) {
          case TAG_WordEq: {
            v_t_2436 = NTAG(TAG_IntEq);
            break;
          }
          case TAG_WordLt: {
            v_t_2436 = NTAG(TAG_IntLt);
            break;
          }
          case TAG_WordLe: {
            v_t_2436 = NTAG(TAG_IntLe);
            break;
          }
          default: {
            v_t_2436 = heff_dup(v_p_2430);
            break;
          }
          }
          V v_t_2437 = ({ V a_0 = v_t_2436; V r_ = (g_heff_2ecompile_2eranges_2eisIntRel(a_0)); heff_drop(v_t_2436); r_; });
          if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
            heff_drop(v_t_2437);
            return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_2430, v_a_2432, v_b_2434})});
          } else {
            heff_drop(v_p_2430);
            heff_drop(v_a_2432);
            heff_drop(v_b_2434);
            heff_drop(v_t_2437);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2435, 0ULL, 2);
          heff_drop(v_p_2430);
          heff_drop(v_a_2432);
          heff_drop(v_b_2434);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_e222_2435);
        }
      }
      default: return heff_nomatch(v_e22_2433);
      }
    }
    default: return heff_nomatch(v_e2_2431);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBool: {
    V v_k_2449 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EBool = heff_take_reuse_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return heff_tag_at_n(v_ru_24e_241_24EBool, TAG_Just, 1, (V[]){v_k_2449});
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_env_240, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eranges_2etestOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etestOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2econdRefine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2econdRefine_entry, 4, 0};

V g_heff_2ecompile_2eranges_2econdRefine(V v_c_240, V v_env_241, V v_x3_242, V v_yes_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CTrue: {
    heff_drop(v_yes_243);
    return v_env_241;
  }
  case TAG_CFalse: {
    heff_drop(v_yes_243);
    return v_env_241;
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x3_242, 0);
    V v_a_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_t_247;
    switch (heff_tag_of(v_p_244)) {
    case TAG_WordEq: {
      v_t_247 = NTAG(TAG_IntEq);
      break;
    }
    case TAG_WordLt: {
      v_t_247 = NTAG(TAG_IntLt);
      break;
    }
    case TAG_WordLe: {
      v_t_247 = NTAG(TAG_IntLe);
      break;
    }
    default: {
      v_t_247 = heff_dup(v_p_244);
      break;
    }
    }
    V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2ecompile_2eranges_2eisIntRel(a_0)); heff_drop(v_t_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_lit_249 = heff_dup(v_p_244);
      V v_lit_2410 = heff_dup(v_a_245);
      V v_lit_2411 = heff_dup(v_b_246);
      V v_c_2412 = heff_dup(v_c_240);
      V v_env_2413 = v_env_241;
      V v_yes_2414 = v_yes_243;
      V v_t_2415;
      switch (heff_tag_of(v_lit_249)) {
      case TAG_WordEq: {
        v_t_2415 = NTAG(TAG_IntEq);
        break;
      }
      case TAG_WordLt: {
        v_t_2415 = NTAG(TAG_IntLt);
        break;
      }
      case TAG_WordLe: {
        v_t_2415 = NTAG(TAG_IntLe);
        break;
      }
      default: {
        v_t_2415 = v_lit_249;
        break;
      }
      }
      V v_t_2416 = (g_heff_2ecompile_2eranges_2eoperandRange(heff_dup(v_c_2412), heff_dup(v_env_2413), heff_dup(v_lit_2410)));
      V v_t_2417 = (g_heff_2ecompile_2eranges_2eoperandRange(v_c_2412, heff_dup(v_env_2413), heff_dup(v_lit_2411)));
      HeffT2 v_t_2418 = ({ V a_0 = v_t_2415; V a_1 = v_yes_2414; V a_2 = v_t_2416; V a_3 = v_t_2417; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eheld_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2415); heff_drop(v_yes_2414); r_; });
      {
        V v_field_2419 = v_t_2418.f[0];
        V v_field_2420 = v_t_2418.f[1];
        V v_ra_2421 = v_field_2419;
        V v_rb_2422 = v_field_2420;
        V v_t_2423 = ({ V a_0 = v_env_2413; V a_1 = v_lit_2410; V a_2 = v_ra_2421; V r_ = (g_heff_2ecompile_2eranges_2enarrowTo(a_0, a_1, a_2)); heff_drop(v_ra_2421); r_; });
        return ({ V a_0 = v_t_2423; V a_1 = v_lit_2411; V a_2 = v_rb_2422; V r_ = (g_heff_2ecompile_2eranges_2enarrowTo(a_0, a_1, a_2)); heff_drop(v_rb_2422); r_; });
      }
    } else {
      heff_drop(v_yes_243);
      heff_drop(v_t_248);
      return v_env_241;
    }
  }
  case TAG_CTest: {
    V v_x31_2424 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_2424)) {
    case TAG_EVar: {
      V v_x_2425 = heff_field(v_x31_2424, 0);
      HeffT2 v_t_2426 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_241, 1), v_x_2425));
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_t_2429 = v_field_2428;
          V v_c_2430 = heff_dup(v_c_240);
          V v_env_2431 = v_env_241;
          V v_x3_2432 = v_t_2429;
          V v_yes_2433 = v_yes_243;
          switch (heff_tag_of(v_x3_2432)) {
          case TAG_MkTest: {
            V v_p_2434 = heff_field(v_x3_2432, 0);
            V v_a_2435 = heff_field(v_x3_2432, 1);
            V v_b_2436 = heff_field(v_x3_2432, 2);
            heff_take_n(v_x3_2432, 7ULL, 3);
            V v_t_2437;
            switch (heff_tag_of(v_p_2434)) {
            case TAG_WordEq: {
              v_t_2437 = NTAG(TAG_IntEq);
              break;
            }
            case TAG_WordLt: {
              v_t_2437 = NTAG(TAG_IntLt);
              break;
            }
            case TAG_WordLe: {
              v_t_2437 = NTAG(TAG_IntLe);
              break;
            }
            default: {
              v_t_2437 = v_p_2434;
              break;
            }
            }
            V v_t_2438 = (g_heff_2ecompile_2eranges_2eoperandRange(heff_dup(v_c_2430), heff_dup(v_env_2431), heff_dup(v_a_2435)));
            V v_t_2439 = (g_heff_2ecompile_2eranges_2eoperandRange(v_c_2430, heff_dup(v_env_2431), heff_dup(v_b_2436)));
            HeffT2 v_t_2440 = ({ V a_0 = v_t_2437; V a_1 = v_yes_2433; V a_2 = v_t_2438; V a_3 = v_t_2439; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eheld_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2437); heff_drop(v_yes_2433); r_; });
            {
              V v_field_2441 = v_t_2440.f[0];
              V v_field_2442 = v_t_2440.f[1];
              V v_ra_2443 = v_field_2441;
              V v_rb_2444 = v_field_2442;
              V v_t_2445 = ({ V a_0 = v_env_2431; V a_1 = v_a_2435; V a_2 = v_ra_2443; V r_ = (g_heff_2ecompile_2eranges_2enarrowTo(a_0, a_1, a_2)); heff_drop(v_ra_2443); r_; });
              return ({ V a_0 = v_t_2445; V a_1 = v_b_2436; V a_2 = v_rb_2444; V r_ = (g_heff_2ecompile_2eranges_2enarrowTo(a_0, a_1, a_2)); heff_drop(v_rb_2444); r_; });
            }
          }
          default: return heff_nomatch(v_x3_2432);
          }
        } else {
          heff_drop(v_yes_243);
          heff_drop(v_field_2428);
          return v_env_241;
        }
      }
    }
    case TAG_EGlobal: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ELam: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EApp: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ELet: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ERecord: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EProj: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ETag: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EMatch: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EPrim: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EPrimCall: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ECall: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EInt: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EFloat: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EStr: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EBytes: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EFixed: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EFloat32: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EBool: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_ESet: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EValues: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    case TAG_EFix: {
      heff_drop(v_yes_243);
      return v_env_241;
    }
    default: return heff_nomatch(v_x31_2424);
    }
  }
  case TAG_CNot: {
    V v_k_2484 = heff_field(v_x3_242, 0);
    V v_t_2485 = heff_bool(!(heff_dup(v_yes_243) == NTAG(TAG_True)));
    heff_drop(v_yes_243);
    V t_0 = v_c_240;
    V t_1 = v_env_241;
    V t_2 = v_k_2484;
    V t_3 = v_t_2485;
    v_c_240 = t_0;
    v_env_241 = t_1;
    v_x3_242 = t_2;
    v_yes_243 = t_3;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2486 = heff_field(v_x3_242, 0);
    V v_b_2487 = heff_field(v_x3_242, 1);
    V v_x33_2488 = heff_field(v_x3_242, 2);
    switch (heff_tag_of(v_x33_2488)) {
    case TAG_CFalse: {
      if ((heff_dup(v_yes_243) == NTAG(TAG_True))) {
        heff_drop(v_yes_243);
        V v_t_2489 = (g_heff_2ecompile_2eranges_2econdRefine(v_c_240, v_env_241, v_a_2486, NTAG(TAG_True)));
        V t_0 = v_c_240;
        V t_1 = v_t_2489;
        V t_2 = v_b_2487;
        V t_3 = NTAG(TAG_True);
        v_c_240 = t_0;
        v_env_241 = t_1;
        v_x3_242 = t_2;
        v_yes_243 = t_3;
        goto top;
      } else {
        heff_drop(v_yes_243);
        switch (heff_tag_of(v_b_2487)) {
        case TAG_CTrue: {
          V v_t_2490 = (g_heff_2ecompile_2eranges_2econdRefine(v_c_240, v_env_241, v_a_2486, NTAG(TAG_False)));
          V t_0 = v_c_240;
          V t_1 = v_t_2490;
          V t_2 = v_x33_2488;
          V t_3 = NTAG(TAG_False);
          v_c_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_yes_243 = t_3;
          goto top;
        }
        case TAG_CFalse: {
          return v_env_241;
        }
        case TAG_CRel: {
          return v_env_241;
        }
        case TAG_CTest: {
          return v_env_241;
        }
        case TAG_CNot: {
          return v_env_241;
        }
        case TAG_CIf: {
          return v_env_241;
        }
        default: return heff_nomatch(v_b_2487);
        }
      }
    }
    default: {
      switch (heff_tag_of(v_b_2487)) {
      case TAG_CTrue: {
        if ((heff_dup(v_yes_243) == NTAG(TAG_True))) {
          heff_drop(v_yes_243);
          return v_env_241;
        } else {
          heff_drop(v_yes_243);
          V v_t_2499 = (g_heff_2ecompile_2eranges_2econdRefine(v_c_240, v_env_241, v_a_2486, NTAG(TAG_False)));
          V t_0 = v_c_240;
          V t_1 = v_t_2499;
          V t_2 = v_x33_2488;
          V t_3 = NTAG(TAG_False);
          v_c_240 = t_0;
          v_env_241 = t_1;
          v_x3_242 = t_2;
          v_yes_243 = t_3;
          goto top;
        }
      }
      case TAG_CFalse: {
        heff_drop(v_yes_243);
        return v_env_241;
      }
      case TAG_CRel: {
        heff_drop(v_yes_243);
        return v_env_241;
      }
      case TAG_CTest: {
        heff_drop(v_yes_243);
        return v_env_241;
      }
      case TAG_CNot: {
        heff_drop(v_yes_243);
        return v_env_241;
      }
      case TAG_CIf: {
        heff_drop(v_yes_243);
        return v_env_241;
      }
      default: return heff_nomatch(v_b_2487);
      }
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2econdRefine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2econdRefine(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V v_go_240, V v_env_241, V v_st_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_env_241);
    return ((HeffT2){{NTAG(TAG_Nil), v_st_242}});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x1_246 = heff_tr(heff_call(heff_dup(v_go_240), 3, (V[]){heff_dup(v_env_241), v_st_242, v_e_244}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_MkSeen: {
      V v_r_247 = heff_field(v_x1_246, 0);
      V v_st_248 = heff_field(v_x1_246, 1);
      heff_take_n(v_x1_246, 3ULL, 2);
      V v_cell_249 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_r_247, heff_hole()});
      HeffT2 v_t_2410 = ({ V a_0 = v_go_240; V a_1 = v_env_241; V a_2 = v_st_248; V a_3 = v_es_245; V a_4 = v_cell_249; HeffT2 r_ = (g_heff_2ecompile_2eranges_2egatherMany_24dps_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_go_240); heff_drop(v_env_241); r_; });
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v__5f_2413 = v_field_2411;
        heff_drop(v__5f_2413);
        V v_st_2414 = v_field_2412;
        return ((HeffT2){{v_cell_249, v_st_2414}});
      }
    }
    case TAG_MkSeenVals: {
      V v_st_2416 = heff_field(v_x1_246, 1);
      heff_take_n(v_x1_246, 2ULL, 2);
      V v_cell_2417 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_hole()});
      HeffT2 v_t_2418 = ({ V a_0 = v_go_240; V a_1 = v_env_241; V a_2 = v_st_2416; V a_3 = v_es_245; V a_4 = v_cell_2417; HeffT2 r_ = (g_heff_2ecompile_2eranges_2egatherMany_24dps_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_go_240); heff_drop(v_env_241); r_; });
      {
        V v_field_2419 = v_t_2418.f[0];
        V v_field_2420 = v_t_2418.f[1];
        V v__5f_2421 = v_field_2419;
        heff_drop(v__5f_2421);
        V v_st_2422 = v_field_2420;
        return ((HeffT2){{v_cell_2417, v_st_2422}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str1, 5, "False");

HeffT6 g_heff_2ecompile_2eranges_2ewalkArms_24cpr(V v_c_240, V v_go_241, V v_env_242, V v_t_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    return ((HeffT6){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Unreached), NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_MkArm: {
      V v_tag_247 = heff_field(v_x51_245, 0);
      V v_vs_248 = heff_field(v_x51_245, 1);
      V v_b_249 = heff_field(v_x51_245, 2);
      V v_ru_24x51_245_24MkArm = heff_take_reuse_n(v_x51_245, 7ULL, 3);
      V v_tag_2410 = heff_dup(v_tag_247);
      V v_vs_2411 = v_vs_248;
      V v_t_2413;
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nothing: {
        heff_drop(v_tag_247);
        v_t_2413 = heff_dup(v_env_242);
        break;
      }
      case TAG_Just: {
        V v_k_2412 = heff_field(v_t_243, 0);
        if (heff_strEq_c_lent(v_tag_247, ((V)&g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str0), 2)) {
          heff_drop(v_tag_247);
          v_t_2413 = (g_heff_2ecompile_2eranges_2econdRefine(v_c_240, heff_dup(v_env_242), v_k_2412, NTAG(TAG_True)));
        } else {
          if (heff_strEq_c(v_tag_247, ((V)&g_heff_2ecompile_2eranges_2ewalkArms_24cpr_str1))) {
            v_t_2413 = (g_heff_2ecompile_2eranges_2econdRefine(v_c_240, heff_dup(v_env_242), v_k_2412, NTAG(TAG_False)));
          } else {
            v_t_2413 = heff_dup(v_env_242);
          }
        }
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      V v_x3_2414 = heff_tr(heff_call(heff_dup(v_go_241), 2, (V[]){v_t_2413, v_b_249}));
      HeffT6 v_t_2415 = (g_heff_2ecompile_2eranges_2ewalkArms_24cpr(v_c_240, v_go_241, v_env_242, v_t_243, v_rest_246));
      {
        V v_field_2417 = v_t_2415.f[1];
        V v_field_2418 = v_t_2415.f[2];
        V v_field_2419 = v_t_2415.f[3];
        V v_field_2420 = v_t_2415.f[4];
        V v_field_2421 = v_t_2415.f[5];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        switch (heff_tag_of(v_x3_2414)) {
        case TAG_MkRes: {
          V v_r_2422 = heff_field(v_x3_2414, 0);
          V v_b_2423 = heff_field(v_x3_2414, 1);
          V v_ru_24x3_2414_24MkRes = heff_take_reuse_n(v_x3_2414, 3ULL, 2);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            heff_drop(v_field_2419);
            heff_drop(v_field_2420);
            heff_drop(v_field_2421);
            heff_drop_cell(v_ru_24x3_2414_24MkRes, 2);
            V v_rr_2424 = v_field_2417;
            V v_arms_2425 = v_field_2418;
            V v_t_2426 = (g_heff_2ecompile_2eranges_2ejoin(v_r_2422, v_rr_2424));
            V v_t_2427 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x51_245_24MkArm, TAG_MkArm, 3, (V[]){v_tag_2410, v_vs_2411, v_b_2423}), v_arms_2425});
            return ((HeffT6){{heff_word_i64(((int64_t)0ULL)), v_t_2426, v_t_2427, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
          } else {
            V v_qs_2428 = v_field_2417;
            V v_arms_2429 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x51_245_24MkArm, TAG_MkArm, 3, (V[]){v_field_2418, v_field_2419, v_field_2420}), v_field_2421});
            switch (heff_tag_of(v_r_2422)) {
            case TAG_Unreached: {
              heff_drop_cell(v_ru_24x3_2414_24MkRes, 2);
              return ((HeffT6){{heff_word_i64(((int64_t)1ULL)), v_qs_2428, v_tag_2410, v_vs_2411, v_b_2423, v_arms_2429}});
            }
            case TAG_Within: {
              heff_take_n(v_r_2422, 0ULL, 2);
              heff_drop(v_qs_2428);
              V v_t_2432 = heff_tag_at_n(v_ru_24x3_2414_24MkRes, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_2410, v_vs_2411, v_b_2423}), v_arms_2429});
              return ((HeffT6){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_t_2432, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
            }
            default: return ((HeffT6){{heff_nomatch(v_r_2422)}});
            }
          }
        }
        case TAG_MkResVals: {
          V v_rs_2433 = heff_field(v_x3_2414, 0);
          V v_b_2434 = heff_field(v_x3_2414, 1);
          heff_take_n(v_x3_2414, 3ULL, 2);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            heff_drop(v_field_2419);
            heff_drop(v_field_2420);
            heff_drop(v_field_2421);
            V v_rr_2435 = v_field_2417;
            V v_arms_2436 = v_field_2418;
            switch (heff_tag_of(v_rr_2435)) {
            case TAG_Unreached: {
              heff_drop_cell(v_ru_24x5_244_24Cons, 2);
              heff_drop_cell(v_ru_24x51_245_24MkArm, 3);
              return ((HeffT6){{heff_word_i64(((int64_t)1ULL)), v_rs_2433, v_tag_2410, v_vs_2411, v_b_2434, v_arms_2436}});
            }
            case TAG_Within: {
              heff_take_n(v_rr_2435, 0ULL, 2);
              heff_drop(v_rs_2433);
              V v_t_2439 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x51_245_24MkArm, TAG_MkArm, 3, (V[]){v_tag_2410, v_vs_2411, v_b_2434}), v_arms_2436});
              return ((HeffT6){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_t_2439, MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
            }
            default: return ((HeffT6){{heff_nomatch(v_rr_2435)}});
            }
          } else {
            V v_qs_2440 = v_field_2417;
            V v_arms_2441 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x51_245_24MkArm, TAG_MkArm, 3, (V[]){v_field_2418, v_field_2419, v_field_2420}), v_field_2421});
            V v_t_2442 = (g_list_2ezipWith_24s1026658656x682908126(v_rs_2433, v_qs_2440));
            return ((HeffT6){{heff_word_i64(((int64_t)1ULL)), v_t_2442, v_tag_2410, v_vs_2411, v_b_2434, v_arms_2441}});
          }
        }
        default: return ((HeffT6){{heff_nomatch(v_x3_2414)}});
        }
      }
    }
    default: return ((HeffT6){{heff_nomatch(v_x51_245)}});
    }
  }
  default: return ((HeffT6){{heff_nomatch(v_x5_244)}});
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2ewalkGo_lam1(V self, V *args);
V g_heff_2ecompile_2eranges_2ewalkGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2eranges_2ewalkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewalkGo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2ewalkGo(V v_c_240, V v_env_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_env_241, 0, 2); V a_1 = v_x_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_248;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        v_t_248 = v_x_247;
      } else {
        heff_drop(v_field_246);
        v_t_248 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      return heff_tag_n(TAG_MkRes, 2, (V[]){v_t_248, heff_tag_re_n(v_ru_24e_242_24EVar, TAG_EVar, 1, 1ULL, (V[]){v_x_243})});
    }
  }
  case TAG_EGlobal: {
    V v_g_249 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EGlobal = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_241, 2);
    HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_c_240, 1), v_g_249));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      V v_t_2414;
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2412;
        v_t_2414 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2413)}), heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      } else {
        heff_drop(v_field_2412);
        v_t_2414 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      return heff_tag_n(TAG_MkRes, 2, (V[]){v_t_2414, heff_tag_re_n(v_ru_24e_242_24EGlobal, TAG_EGlobal, 1, 1ULL, (V[]){v_g_249})});
    }
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_e_242, 0);
    V v_a_2416 = heff_field(v_e_242, 1);
    V v_b_2417 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_x1_2418 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, heff_dup(v_env_241), heff_dup(v_a_2416)));
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_MkRes: {
      V v_r_2419 = heff_field(v_x1_2418, 0);
      V v_e_2420 = heff_field(v_x1_2418, 1);
      V v_ru_24x1_2418_24MkRes = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
      V v_t_2421 = ({ V a_0 = v_env_241; V a_1 = v_x_2415; V a_2 = v_r_2419; V r_ = (g_heff_2ecompile_2eranges_2ewithRange(a_0, a_1, a_2)); heff_drop(v_r_2419); r_; });
      V v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = v_x_2415; V a_2 = v_a_2416; V r_ = (g_heff_2ecompile_2eranges_2ewithTest(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
      V v_x2_2423 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, v_t_2422, v_b_2417));
      switch (heff_tag_of(v_x2_2423)) {
      case TAG_MkRes: {
        V v_r_2424 = heff_field(v_x2_2423, 0);
        V v_e_2425 = heff_field(v_x2_2423, 1);
        heff_take_n(v_x2_2423, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x1_2418_24MkRes, TAG_MkRes, 2, (V[]){v_r_2424, heff_tag_re_n(v_ru_24e_242_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2415, v_e_2420, v_e_2425})});
      }
      case TAG_MkResVals: {
        V v_rs_2426 = heff_field(v_x2_2423, 0);
        V v_e_2427 = heff_field(v_x2_2423, 1);
        V v_ru_24x2_2423_24MkResVals = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
        heff_drop_cell(v_ru_24x1_2418_24MkRes, 2);
        return heff_tag_re_n(v_ru_24x2_2423_24MkResVals, TAG_MkResVals, 2, 1ULL, (V[]){v_rs_2426, heff_tag_re_n(v_ru_24e_242_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2415, v_e_2420, v_e_2427})});
      }
      default: return heff_nomatch(v_x2_2423);
      }
    }
    case TAG_MkResVals: {
      V v_e_2429 = heff_field(v_x1_2418, 1);
      V v_ru_24x1_2418_24MkResVals = heff_take_reuse_n(v_x1_2418, 2ULL, 2);
      V v_t_2430 = ({ V a_0 = v_env_241; V a_1 = v_x_2415; V a_2 = v_a_2416; V r_ = (g_heff_2ecompile_2eranges_2ewithTest(a_0, a_1, a_2)); heff_drop_rec(v_env_241, 2); r_; });
      V v_x2_2431 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, v_t_2430, v_b_2417));
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_MkRes: {
        V v_r_2432 = heff_field(v_x2_2431, 0);
        V v_e_2433 = heff_field(v_x2_2431, 1);
        V v_ru_24x2_2431_24MkRes = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
        heff_drop_cell(v_ru_24x1_2418_24MkResVals, 2);
        return heff_tag_re_n(v_ru_24x2_2431_24MkRes, TAG_MkRes, 2, 1ULL, (V[]){v_r_2432, heff_tag_re_n(v_ru_24e_242_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2415, v_e_2429, v_e_2433})});
      }
      case TAG_MkResVals: {
        V v_rs_2434 = heff_field(v_x2_2431, 0);
        V v_e_2435 = heff_field(v_x2_2431, 1);
        heff_take_n(v_x2_2431, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x1_2418_24MkResVals, TAG_MkResVals, 2, (V[]){v_rs_2434, heff_tag_re_n(v_ru_24e_242_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2415, v_e_2429, v_e_2435})});
      }
      default: return heff_nomatch(v_x2_2431);
      }
    }
    default: return heff_nomatch(v_x1_2418);
    }
  }
  case TAG_EMatch: {
    V v_s_2436 = heff_field(v_e_242, 0);
    V v_arms_2437 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_x1_2438 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, heff_dup(v_env_241), heff_dup(v_s_2436)));
    V v_k_2454 = heff_clo_n(g_heff_2ecompile_2eranges_2ewalkGo_lam0, 2, 4, (V[]){heff_dup(v_c_240), v_env_241, v_s_2436, v_arms_2437});
    switch (heff_tag_of(v_x1_2438)) {
    case TAG_MkRes: {
      V v_r_2455 = heff_field(v_x1_2438, 0);
      V v_e_2456 = heff_field(v_x1_2438, 1);
      heff_take_n(v_x1_2438, 3ULL, 2);
      return heff_tail(v_k_2454, 2, (V[]){v_r_2455, v_e_2456});
    }
    case TAG_MkResVals: {
      V v_e_2458 = heff_field(v_x1_2438, 1);
      heff_take_n(v_x1_2438, 2ULL, 2);
      return heff_tail(v_k_2454, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_e_2458});
    }
    default: return heff_nomatch(v_x1_2438);
    }
  }
  case TAG_EPrimCall: {
    V v_e1_2459 = heff_field(v_e_242, 0);
    V v_args_2460 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){heff_dup(v_c_240)}));
    HeffT2 v_t_2462 = ({ V a_0 = v_t_2461; V a_1 = v_env_241; V a_2 = v_args_2460; HeffT2 r_ = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2461); heff_drop_rec(v_env_241, 2); r_; });
    {
      V v_field_2463 = v_t_2462.f[0];
      V v_field_2464 = v_t_2462.f[1];
      V v_rs_2465 = v_field_2463;
      V v_es_2466 = v_field_2464;
      V v_t_2467 = (g_heff_2ecompile_2eranges_2eprimRange(v_e1_2459, v_rs_2465));
      V v_t_2468 = (g_heff_2ecompile_2eranges_2eprimRange(v_e1_2459, v_rs_2465));
      HeffT2 v_t_2469 = ({ V a_0 = v_e1_2459; V a_1 = v_rs_2465; V a_2 = v_t_2468; HeffT2 r_ = (g_heff_2ecompile_2eranges_2ewordOf_24cpr(a_0, a_1, a_2)); heff_drop(v_rs_2465); heff_drop(v_t_2468); r_; });
      {
        V v_field_2471 = v_t_2469.f[1];
        int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
        V v_t_2473;
        if ((v_tag_2470 == ((int64_t)0ULL))) {
          heff_drop(v_e1_2459);
          V v_x_2472 = v_field_2471;
          v_t_2473 = v_x_2472;
        } else {
          heff_drop(v_field_2471);
          v_t_2473 = v_e1_2459;
        }
        return heff_tag_n(TAG_MkRes, 2, (V[]){v_t_2467, heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_t_2473, v_es_2466})});
      }
    }
  }
  case TAG_EInt: {
    V v_n_2474 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EInt = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_241, 2);
    V v_t_2475 = heff_tag_n(TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_n_2474)}), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_n_2474)})});
    return heff_tag_n(TAG_MkRes, 2, (V[]){v_t_2475, heff_tag_re_n(v_ru_24e_242_24EInt, TAG_EInt, 1, 1ULL, (V[]){v_n_2474})});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_env_241, 2);
    return heff_tag_n(TAG_MkRes, 2, (V[]){NTAG(TAG_Unreached), NTAG(TAG_EAbandon)});
  }
  case TAG_EBool: {
    V v_k_2476 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EBool = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2477 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){heff_dup(v_c_240)}));
    V v_t_2478 = ({ V a_0 = v_c_240; V a_1 = v_t_2477; V a_2 = v_env_241; V a_3 = v_k_2476; V r_ = (g_heff_2ecompile_2eranges_2ewalkCond(a_0, a_1, a_2, a_3)); heff_drop(v_t_2477); r_; });
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), heff_tag_at_n(v_ru_24e_242_24EBool, TAG_EBool, 1, (V[]){v_t_2478})});
  }
  case TAG_ESet: {
    V v_xs_2479 = heff_field(v_e_242, 0);
    V v_a_2480 = heff_field(v_e_242, 1);
    V v_b_2481 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_x1_2482 = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(v_c_240, heff_dup(v_env_241), v_a_2480));
    V v_k_2492 = heff_clo_n(g_heff_2ecompile_2eranges_2ewalkGo_lam1, 2, 4, (V[]){v_xs_2479, v_env_241, heff_dup(v_c_240), v_b_2481});
    switch (heff_tag_of(v_x1_2482)) {
    case TAG_MkRes: {
      V v_e_2494 = heff_field(v_x1_2482, 1);
      heff_take_n(v_x1_2482, 2ULL, 2);
      return heff_tail(v_k_2492, 2, (V[]){NTAG(TAG_Nil), v_e_2494});
    }
    case TAG_MkResVals: {
      V v_rs_2495 = heff_field(v_x1_2482, 0);
      V v_e_2496 = heff_field(v_x1_2482, 1);
      heff_take_n(v_x1_2482, 3ULL, 2);
      return heff_tail(v_k_2492, 2, (V[]){v_rs_2495, v_e_2496});
    }
    default: return heff_nomatch(v_x1_2482);
    }
  }
  case TAG_EValues: {
    V v_es_2497 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EValues = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2498 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){heff_dup(v_c_240)}));
    HeffT2 v_t_2499 = ({ V a_0 = v_t_2498; V a_1 = v_env_241; V a_2 = v_es_2497; HeffT2 r_ = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2498); heff_drop_rec(v_env_241, 2); r_; });
    {
      V v_field_24100 = v_t_2499.f[0];
      V v_field_24101 = v_t_2499.f[1];
      V v_rs_24102 = v_field_24100;
      V v_es_24103 = v_field_24101;
      return heff_tag_n(TAG_MkResVals, 2, (V[]){v_rs_24102, heff_tag_at_n(v_ru_24e_242_24EValues, TAG_EValues, 1, (V[]){v_es_24103})});
    }
  }
  default: {
    V v_t_24111 = (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2eranges_2ewalkGo_lam2, 2, 2, (V[]){heff_dup(v_c_240), v_env_241}), v_e_242));
    return heff_tag_n(TAG_MkRes, 2, (V[]){heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_t_24111});
  }
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2ewalkGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eranges_2ewalkGo_lam0(V self, V *args) {
  V v_x_2439 = args[0];
  V v_s1_2440 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_s_2436 = heff_env(self)[2];
  V v_arms_2437 = heff_env(self)[3];
  heff_drop(v_x_2439);
  V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eranges_2ewalkGo_clo), 1, (V[]){heff_dup(v_c_240)}));
  heff_clo_take(self, 4);
  V v_t_2442 = (g_heff_2ecompile_2eranges_2etestOf(heff_dup(v_env_241), v_s_2436));
  HeffT6 v_t_2443 = ({ V a_0 = v_c_240; V a_1 = v_t_2441; V a_2 = v_env_241; V a_3 = v_t_2442; V a_4 = v_arms_2437; HeffT6 r_ = (g_heff_2ecompile_2eranges_2ewalkArms_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop_rec(v_c_240, 3); heff_drop(v_t_2441); heff_drop_rec(v_env_241, 2); heff_drop(v_t_2442); r_; });
  {
    V v_field_2445 = v_t_2443.f[1];
    V v_field_2446 = v_t_2443.f[2];
    V v_field_2447 = v_t_2443.f[3];
    V v_field_2448 = v_t_2443.f[4];
    V v_field_2449 = v_t_2443.f[5];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      heff_drop(v_field_2447);
      heff_drop(v_field_2448);
      heff_drop(v_field_2449);
      V v_r_2450 = v_field_2445;
      V v_arms_2451 = v_field_2446;
      return heff_tag_n(TAG_MkRes, 2, (V[]){v_r_2450, heff_tag_n(TAG_EMatch, 2, (V[]){v_s1_2440, v_arms_2451})});
    } else {
      V v_rs_2452 = v_field_2445;
      V v_arms_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_field_2446, v_field_2447, v_field_2448}), v_field_2449});
      return heff_tag_n(TAG_MkResVals, 2, (V[]){v_rs_2452, heff_tag_n(TAG_EMatch, 2, (V[]){v_s1_2440, v_arms_2453})});
    }
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_lam1(V self, V *args) {
  V v_rs_2483 = args[0];
  V v_a1_2484 = args[1];
  V v_xs_2479 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_b_2481 = heff_env(self)[3];
  V v_t_2485 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_2479), v_rs_2483));
  heff_clo_take(self, 4);
  V v_t_2486 = ({ V a_0 = v_env_241; V a_1 = v_t_2485; V r_ = (g_list_2efoldl_24s518632429x1911716206(a_0, a_1)); heff_drop(v_t_2485); r_; });
  V v_x2_2487 = ({ V a_0 = v_c_240; V a_1 = v_t_2486; V a_2 = v_b_2481; V r_ = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(a_0, a_1, a_2)); heff_drop_rec(v_c_240, 3); r_; });
  switch (heff_tag_of(v_x2_2487)) {
  case TAG_MkRes: {
    V v_r_2488 = heff_field(v_x2_2487, 0);
    V v_e_2489 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkRes = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2487_24MkRes, TAG_MkRes, 2, 1ULL, (V[]){v_r_2488, heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2479, v_a1_2484, v_e_2489})});
  }
  case TAG_MkResVals: {
    V v_rs_2490 = heff_field(v_x2_2487, 0);
    V v_e_2491 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkResVals = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2487_24MkResVals, TAG_MkResVals, 2, 1ULL, (V[]){v_rs_2490, heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2479, v_a1_2484, v_e_2491})});
  }
  default: return heff_nomatch(v_x2_2487);
  }
}
V g_heff_2ecompile_2eranges_2ewalkGo_lam2(V self, V *args) {
  V v_x_24104 = args[0];
  V v_p_24105 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_env_241 = heff_env(self)[1];
  heff_drop(v_x_24104);
  heff_clo_take(self, 2);
  V v_x1_24106 = ({ V a_0 = v_c_240; V a_1 = v_env_241; V a_2 = v_p_24105; V r_ = heff_tr(g_heff_2ecompile_2eranges_2ewalkGo(a_0, a_1, a_2)); heff_drop_rec(v_c_240, 3); r_; });
  switch (heff_tag_of(v_x1_24106)) {
  case TAG_MkRes: {
    V v_e_24108 = heff_field(v_x1_24106, 1);
    heff_take_n(v_x1_24106, 2ULL, 2);
    return v_e_24108;
  }
  case TAG_MkResVals: {
    V v_e_24110 = heff_field(v_x1_24106, 1);
    heff_take_n(v_x1_24106, 2ULL, 2);
    return v_e_24110;
  }
  default: return heff_nomatch(v_x1_24106);
  }
}
V g_heff_2ecompile_2eranges_2eabsorbOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2eabsorbOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eabsorbOne_entry, 2, 0};

V g_heff_2ecompile_2eranges_2eabsorbOne(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_g_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 0, 3);
    HeffT2 v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_g_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_old_248 = v_field_247;
        V v_t_249 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_248), heff_dup(v_rs_243)));
        V v_t_2410 = ({ V a_0 = v_old_248; V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2eranges_2erangesEq(a_0, a_1)); heff_drop(v_t_249); r_; });
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_g_242);
          heff_drop(v_rs_243);
          heff_drop(v_old_248);
          heff_drop(v_t_2410);
          return v_s_240;
        } else {
          heff_drop(v_t_2410);
          V v_fx_2411 = heff_dup(heff_rfield(v_s_240, 0));
          V v_grown_2412 = heff_take_field(v_fx_2411, 1);
          V v_marks_2413 = heff_take_field(v_fx_2411, 2);
          V v_g_2414 = heff_dup(v_g_242);
          V v_old_2415 = heff_dup(v_old_248);
          V v_new_2416 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_248), heff_dup(v_rs_243)));
          V v_d_2417 = (g_list_2emap_24s258116700x992061112(MK_INT(0LL), heff_dup(v_old_2415)));
          HeffT2 v_t_2418 = ({ V a_0 = v_grown_2412; V a_1 = v_g_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_grown_2412); r_; });
          {
            V v_field_2420 = v_t_2418.f[1];
            int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
            V v_t_2422;
            if ((v_tag_2419 == ((int64_t)0ULL))) {
              heff_drop(v_d_2417);
              V v_x_2421 = v_field_2420;
              v_t_2422 = v_x_2421;
            } else {
              heff_drop(v_field_2420);
              v_t_2422 = v_d_2417;
            }
            V v_t_2423 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2422, v_old_2415));
            V v_t_2491 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2eranges_2eabsorbOne_lam0, 2, 2, (V[]){v_marks_2413, v_g_2414}), v_t_2423, v_new_2416));
            V v_t_2492 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 0, 3);
            V v_t_2493 = ({ V a_0 = v_t_2492; V a_1 = v_g_242; V a_2 = v_t_2491; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2491); r_; });
            V v_new_2494 = (g_list_2ezipWith_24s1026658656x682908126(heff_dup(v_old_248), v_rs_243));
            V v_d_2495 = (g_list_2emap_24s258116700x992061112(MK_INT(0LL), heff_dup(v_old_248)));
            V v_t_2496 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 1, 3);
            HeffT2 v_t_2497 = ({ V a_0 = v_t_2496; V a_1 = v_g_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2496); r_; });
            {
              V v_field_2499 = v_t_2497.f[1];
              int64_t v_tag_2498 = ((int64_t)v_t_2497.f[0]);
              V v_t_24101;
              if ((v_tag_2498 == ((int64_t)0ULL))) {
                heff_drop(v_d_2495);
                V v_x_24100 = v_field_2499;
                v_t_24101 = v_x_24100;
              } else {
                heff_drop(v_field_2499);
                v_t_24101 = v_d_2495;
              }
              V v_t_24102 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_24101, v_old_248));
              V v_t_24103 = (g_list_2ezipWith_24s1604775524x1614188687(MK_INT(1LL), v_t_24102, v_new_2494));
              V v_t_24104 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 1, 3);
              V v_t_24105 = ({ V a_0 = v_t_24104; V a_1 = v_g_242; V a_2 = v_t_24103; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_24103); r_; });
              V v_t_24106 = ({ V a_0 = heff_take_field(v_s_240, 1); V a_1 = v_g_242; V a_2 = NTAG(TAG_MkUnit); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_g_242); r_; });
              V v_t_24107 = heff_get_n(heff_dup(heff_rfield(v_s_240, 0)), 2, 3);
              return ({ V rv_0 = ({ V rv_0 = v_t_2493; V rv_1 = v_t_24105; V rv_2 = v_t_24107; V rr_ = heff_rec_reuse_nf(v_fx_2411, 0ULL, 3, shape_params__grown__marks, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; }); V rv_1 = v_t_24106; V rr_ = heff_rec_reuse_nf(v_s_240, 4ULL, 3, shape_fix__dirty__gathered, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            }
          }
        }
      } else {
        heff_drop(v_g_242);
        heff_drop(v_rs_243);
        heff_drop(v_field_247);
        return v_s_240;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eranges_2eabsorbOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2eabsorbOne(a[0], a[1]);
}
V g_heff_2ecompile_2eranges_2eabsorbOne_lam0(V self, V *args) {
  V v_kr_2424 = args[0];
  V v_n_2425 = args[1];
  V v_marks_2413 = heff_env(self)[0];
  V v_g_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2426 = ({ V a_0 = v_marks_2413; V a_1 = v_g_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_marks_2413); heff_drop(v_g_2414); r_; });
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    V v_ms_2430;
    if ((v_tag_2427 == ((int64_t)0ULL))) {
      V v_x_2429 = v_field_2428;
      v_ms_2430 = v_x_2429;
    } else {
      heff_drop(v_field_2428);
      v_ms_2430 = heff_dup(g_std_2eordmap_2eempty_get());
    }
    V v_k_2433;
    switch (heff_tag_of(v_kr_2424)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_dup(heff_field(v_kr_2424, 0));
      v_k_2433 = v_x_2431;
      break;
    }
    default: heff_nomatch(v_kr_2424);
    }
    V v_old_2436;
    switch (heff_tag_of(v_kr_2424)) {
    case TAG_MkPair: {
      V v_y_2435 = heff_field(v_kr_2424, 1);
      heff_take_n(v_kr_2424, 2ULL, 2);
      v_old_2436 = v_y_2435;
      break;
    }
    default: heff_nomatch(v_kr_2424);
    }
    V v_new_2437 = v_n_2425;
    if (heff_intLt_c_lent(v_k_2433, MK_INT(1LL), 2)) {
      heff_drop(v_ms_2430);
      heff_drop(v_k_2433);
      heff_drop(v_old_2436);
      return v_new_2437;
    } else {
      if (heff_intLt_c(v_k_2433, MK_INT(3LL))) {
        switch (heff_tag_of(v_old_2436)) {
        case TAG_Unreached: {
          heff_drop(v_ms_2430);
          return v_new_2437;
        }
        case TAG_Within: {
          V v_a_2438 = heff_field(v_old_2436, 0);
          V v_b_2439 = heff_field(v_old_2436, 1);
          V v_ru_24old_2436_24Within = heff_take_reuse_n(v_old_2436, 3ULL, 2);
          switch (heff_tag_of(v_new_2437)) {
          case TAG_Unreached: {
            heff_drop(v_ms_2430);
            heff_drop(v_a_2438);
            heff_drop(v_b_2439);
            heff_drop_cell(v_ru_24old_2436_24Within, 2);
            return v_new_2437;
          }
          case TAG_Within: {
            V v_c_2440 = heff_field(v_new_2437, 0);
            V v_d_2441 = heff_field(v_new_2437, 1);
            heff_take_n(v_new_2437, 3ULL, 2);
            V v_lit_2442 = heff_dup(v_ms_2430);
            V v_a_2443 = v_a_2438;
            V v_x3_2444 = v_c_2440;
            V v_t_2450;
            switch (heff_tag_of(v_x3_2444)) {
            case TAG_Nothing: {
              heff_drop(v_lit_2442);
              switch (heff_tag_of(v_a_2443)) {
              case TAG_Nothing: {
                v_t_2450 = v_x3_2444;
                break;
              }
              case TAG_Just: {
                V v_a_2445 = heff_field(v_a_2443, 0);
                heff_take_n(v_a_2443, 1ULL, 1);
                switch (heff_tag_of(v_x3_2444)) {
                case TAG_Nothing: {
                  heff_drop(v_a_2445);
                  v_t_2450 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_c_2446 = heff_dup(heff_field(v_x3_2444, 0));
                  if (heff_intLt_c(v_c_2446, v_a_2445)) {
                    heff_drop_tag(v_x3_2444, 1);
                    v_t_2450 = NTAG(TAG_Nothing);
                  } else {
                    v_t_2450 = v_x3_2444;
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2444);
                }
                break;
              }
              default: heff_nomatch(v_a_2443);
              }
              break;
            }
            case TAG_Just: {
              V v_c_2447 = heff_field(v_x3_2444, 0);
              V v_ru_24x3_2444_24Just = heff_take_reuse_n(v_x3_2444, 1ULL, 1);
              switch (heff_tag_of(v_a_2443)) {
              case TAG_Nothing: {
                heff_drop(v_lit_2442);
                v_t_2450 = heff_tag_re_n(v_ru_24x3_2444_24Just, TAG_Just, 1, 1ULL, (V[]){v_c_2447});
                break;
              }
              case TAG_Just: {
                V v_a_2448 = heff_field(v_a_2443, 0);
                heff_take_n(v_a_2443, 1ULL, 1);
                if (heff_intLt_c_lent(v_c_2447, v_a_2448, 2)) {
                  heff_drop_cell(v_ru_24x3_2444_24Just, 1);
                  V v_t_2449 = ({ V a_0 = v_lit_2442; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_lit_2442); r_; });
                  v_t_2450 = ({ V a_0 = v_c_2447; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2449; V r_ = (g_list_2efoldl_24s510070423x219220408(a_0, a_1, a_2)); heff_drop(v_c_2447); heff_drop(v_t_2449); r_; });
                } else {
                  heff_drop(v_lit_2442);
                  v_t_2450 = heff_tag_re_n(v_ru_24x3_2444_24Just, TAG_Just, 1, 1ULL, (V[]){v_c_2447});
                }
                break;
              }
              default: heff_nomatch(v_a_2443);
              }
              break;
            }
            default: heff_nomatch(v_x3_2444);
            }
            V v_lit_2451 = v_ms_2430;
            V v_b_2452 = v_b_2439;
            V v_x3_2453 = v_d_2441;
            V v_t_2459;
            switch (heff_tag_of(v_x3_2453)) {
            case TAG_Nothing: {
              heff_drop(v_lit_2451);
              switch (heff_tag_of(v_b_2452)) {
              case TAG_Nothing: {
                v_t_2459 = v_x3_2453;
                break;
              }
              case TAG_Just: {
                V v_b_2454 = heff_field(v_b_2452, 0);
                heff_take_n(v_b_2452, 1ULL, 1);
                switch (heff_tag_of(v_x3_2453)) {
                case TAG_Nothing: {
                  heff_drop(v_b_2454);
                  v_t_2459 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_d_2455 = heff_dup(heff_field(v_x3_2453, 0));
                  if (heff_intLt_c(v_b_2454, v_d_2455)) {
                    heff_drop_tag(v_x3_2453, 1);
                    v_t_2459 = NTAG(TAG_Nothing);
                  } else {
                    v_t_2459 = v_x3_2453;
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2453);
                }
                break;
              }
              default: heff_nomatch(v_b_2452);
              }
              break;
            }
            case TAG_Just: {
              V v_d_2456 = heff_field(v_x3_2453, 0);
              V v_ru_24x3_2453_24Just = heff_take_reuse_n(v_x3_2453, 1ULL, 1);
              switch (heff_tag_of(v_b_2452)) {
              case TAG_Nothing: {
                heff_drop(v_lit_2451);
                v_t_2459 = heff_tag_re_n(v_ru_24x3_2453_24Just, TAG_Just, 1, 1ULL, (V[]){v_d_2456});
                break;
              }
              case TAG_Just: {
                V v_b_2457 = heff_field(v_b_2452, 0);
                heff_take_n(v_b_2452, 1ULL, 1);
                if (heff_intLt_c_lent(v_b_2457, v_d_2456, 1)) {
                  heff_drop_cell(v_ru_24x3_2453_24Just, 1);
                  V v_t_2458 = ({ V a_0 = v_lit_2451; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_lit_2451); r_; });
                  v_t_2459 = ({ V a_0 = v_d_2456; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2458; V r_ = (g_list_2efoldl_24s92926977x826280221(a_0, a_1, a_2)); heff_drop(v_d_2456); heff_drop(v_t_2458); r_; });
                } else {
                  heff_drop(v_lit_2451);
                  v_t_2459 = heff_tag_re_n(v_ru_24x3_2453_24Just, TAG_Just, 1, 1ULL, (V[]){v_d_2456});
                }
                break;
              }
              default: heff_nomatch(v_b_2452);
              }
              break;
            }
            default: heff_nomatch(v_x3_2453);
            }
            return heff_tag_at_n(v_ru_24old_2436_24Within, TAG_Within, 2, (V[]){v_t_2450, v_t_2459});
          }
          default: return heff_nomatch(v_new_2437);
          }
        }
        default: return heff_nomatch(v_old_2436);
        }
      } else {
        heff_drop(v_ms_2430);
        V v_ms_2460 = NTAG(TAG_Nothing);
        V v_o_2461 = v_old_2436;
        V v_n_2462 = v_new_2437;
        switch (heff_tag_of(v_o_2461)) {
        case TAG_Unreached: {
          return v_n_2462;
        }
        case TAG_Within: {
          V v_a_2463 = heff_field(v_o_2461, 0);
          V v_b_2464 = heff_field(v_o_2461, 1);
          V v_ru_24o_2461_24Within = heff_take_reuse_n(v_o_2461, 3ULL, 2);
          switch (heff_tag_of(v_n_2462)) {
          case TAG_Unreached: {
            heff_drop(v_a_2463);
            heff_drop(v_b_2464);
            heff_drop_cell(v_ru_24o_2461_24Within, 2);
            return v_n_2462;
          }
          case TAG_Within: {
            V v_c_2465 = heff_field(v_n_2462, 0);
            V v_d_2466 = heff_field(v_n_2462, 1);
            heff_take_n(v_n_2462, 3ULL, 2);
            V v_x1_2467 = heff_dup(v_ms_2460);
            V v_a_2468 = v_a_2463;
            V v_x3_2469 = v_c_2465;
            V v_t_2478;
            switch (heff_tag_of(v_x1_2467)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_a_2468)) {
              case TAG_Nothing: {
                v_t_2478 = v_x3_2469;
                break;
              }
              case TAG_Just: {
                V v_a_2470 = heff_field(v_a_2468, 0);
                heff_take_n(v_a_2468, 1ULL, 1);
                switch (heff_tag_of(v_x3_2469)) {
                case TAG_Nothing: {
                  heff_drop(v_a_2470);
                  v_t_2478 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_c_2471 = heff_dup(heff_field(v_x3_2469, 0));
                  if (heff_intLt_c(v_c_2471, v_a_2470)) {
                    heff_drop_tag(v_x3_2469, 1);
                    v_t_2478 = NTAG(TAG_Nothing);
                  } else {
                    v_t_2478 = v_x3_2469;
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2469);
                }
                break;
              }
              default: heff_nomatch(v_a_2468);
              }
              break;
            }
            case TAG_Just: {
              V v_ms_2472 = heff_field(v_x1_2467, 0);
              V v_ru_24x1_2467_24Just = heff_take_reuse_n(v_x1_2467, 1ULL, 1);
              switch (heff_tag_of(v_x3_2469)) {
              case TAG_Nothing: {
                heff_drop(v_ms_2472);
                heff_drop_cell(v_ru_24x1_2467_24Just, 1);
                switch (heff_tag_of(v_a_2468)) {
                case TAG_Nothing: {
                  v_t_2478 = v_x3_2469;
                  break;
                }
                case TAG_Just: {
                  V v_a_2473 = heff_field(v_a_2468, 0);
                  heff_take_n(v_a_2468, 1ULL, 1);
                  switch (heff_tag_of(v_x3_2469)) {
                  case TAG_Nothing: {
                    heff_drop(v_a_2473);
                    v_t_2478 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_c_2474 = heff_dup(heff_field(v_x3_2469, 0));
                    if (heff_intLt_c(v_c_2474, v_a_2473)) {
                      heff_drop_tag(v_x3_2469, 1);
                      v_t_2478 = NTAG(TAG_Nothing);
                    } else {
                      v_t_2478 = v_x3_2469;
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2469);
                  }
                  break;
                }
                default: heff_nomatch(v_a_2468);
                }
                break;
              }
              case TAG_Just: {
                V v_c_2475 = heff_field(v_x3_2469, 0);
                heff_take_n(v_x3_2469, 1ULL, 1);
                switch (heff_tag_of(v_a_2468)) {
                case TAG_Nothing: {
                  heff_drop(v_ms_2472);
                  v_t_2478 = heff_tag_at_n(v_ru_24x1_2467_24Just, TAG_Just, 1, (V[]){v_c_2475});
                  break;
                }
                case TAG_Just: {
                  V v_a_2476 = heff_field(v_a_2468, 0);
                  heff_take_n(v_a_2468, 1ULL, 1);
                  if (heff_intLt_c_lent(v_c_2475, v_a_2476, 2)) {
                    heff_drop_cell(v_ru_24x1_2467_24Just, 1);
                    V v_t_2477 = ({ V a_0 = v_ms_2472; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_ms_2472); r_; });
                    v_t_2478 = ({ V a_0 = v_c_2475; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2477; V r_ = (g_list_2efoldl_24s510070423x219220408(a_0, a_1, a_2)); heff_drop(v_c_2475); heff_drop(v_t_2477); r_; });
                  } else {
                    heff_drop(v_ms_2472);
                    v_t_2478 = heff_tag_at_n(v_ru_24x1_2467_24Just, TAG_Just, 1, (V[]){v_c_2475});
                  }
                  break;
                }
                default: heff_nomatch(v_a_2468);
                }
                break;
              }
              default: heff_nomatch(v_x3_2469);
              }
              break;
            }
            default: heff_nomatch(v_x1_2467);
            }
            V v_x1_2479 = v_ms_2460;
            V v_b_2480 = v_b_2464;
            V v_x3_2481 = v_d_2466;
            V v_t_2490;
            switch (heff_tag_of(v_x1_2479)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_b_2480)) {
              case TAG_Nothing: {
                v_t_2490 = v_x3_2481;
                break;
              }
              case TAG_Just: {
                V v_b_2482 = heff_field(v_b_2480, 0);
                heff_take_n(v_b_2480, 1ULL, 1);
                switch (heff_tag_of(v_x3_2481)) {
                case TAG_Nothing: {
                  heff_drop(v_b_2482);
                  v_t_2490 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_d_2483 = heff_dup(heff_field(v_x3_2481, 0));
                  if (heff_intLt_c(v_b_2482, v_d_2483)) {
                    heff_drop_tag(v_x3_2481, 1);
                    v_t_2490 = NTAG(TAG_Nothing);
                  } else {
                    v_t_2490 = v_x3_2481;
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2481);
                }
                break;
              }
              default: heff_nomatch(v_b_2480);
              }
              break;
            }
            case TAG_Just: {
              V v_ms_2484 = heff_field(v_x1_2479, 0);
              V v_ru_24x1_2479_24Just = heff_take_reuse_n(v_x1_2479, 1ULL, 1);
              switch (heff_tag_of(v_x3_2481)) {
              case TAG_Nothing: {
                heff_drop(v_ms_2484);
                heff_drop_cell(v_ru_24x1_2479_24Just, 1);
                switch (heff_tag_of(v_b_2480)) {
                case TAG_Nothing: {
                  v_t_2490 = v_x3_2481;
                  break;
                }
                case TAG_Just: {
                  V v_b_2485 = heff_field(v_b_2480, 0);
                  heff_take_n(v_b_2480, 1ULL, 1);
                  switch (heff_tag_of(v_x3_2481)) {
                  case TAG_Nothing: {
                    heff_drop(v_b_2485);
                    v_t_2490 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_d_2486 = heff_dup(heff_field(v_x3_2481, 0));
                    if (heff_intLt_c(v_b_2485, v_d_2486)) {
                      heff_drop_tag(v_x3_2481, 1);
                      v_t_2490 = NTAG(TAG_Nothing);
                    } else {
                      v_t_2490 = v_x3_2481;
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2481);
                  }
                  break;
                }
                default: heff_nomatch(v_b_2480);
                }
                break;
              }
              case TAG_Just: {
                V v_d_2487 = heff_field(v_x3_2481, 0);
                heff_take_n(v_x3_2481, 1ULL, 1);
                switch (heff_tag_of(v_b_2480)) {
                case TAG_Nothing: {
                  heff_drop(v_ms_2484);
                  v_t_2490 = heff_tag_at_n(v_ru_24x1_2479_24Just, TAG_Just, 1, (V[]){v_d_2487});
                  break;
                }
                case TAG_Just: {
                  V v_b_2488 = heff_field(v_b_2480, 0);
                  heff_take_n(v_b_2480, 1ULL, 1);
                  if (heff_intLt_c_lent(v_b_2488, v_d_2487, 1)) {
                    heff_drop_cell(v_ru_24x1_2479_24Just, 1);
                    V v_t_2489 = ({ V a_0 = v_ms_2484; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_ms_2484); r_; });
                    v_t_2490 = ({ V a_0 = v_d_2487; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2489; V r_ = (g_list_2efoldl_24s92926977x826280221(a_0, a_1, a_2)); heff_drop(v_d_2487); heff_drop(v_t_2489); r_; });
                  } else {
                    heff_drop(v_ms_2484);
                    v_t_2490 = heff_tag_at_n(v_ru_24x1_2479_24Just, TAG_Just, 1, (V[]){v_d_2487});
                  }
                  break;
                }
                default: heff_nomatch(v_b_2480);
                }
                break;
              }
              default: heff_nomatch(v_x3_2481);
              }
              break;
            }
            default: heff_nomatch(v_x1_2479);
            }
            return heff_tag_at_n(v_ru_24o_2461_24Within, TAG_Within, 2, (V[]){v_t_2478, v_t_2490});
          }
          default: return heff_nomatch(v_n_2462);
          }
        }
        default: return heff_nomatch(v_o_2461);
        }
      }
    }
  }
}

static V g_heff_2ecompile_2eranges_2eemptyScan_val;
static HEFF_ONCE g_heff_2ecompile_2eranges_2eemptyScan_st;
static V g_heff_2ecompile_2eranges_2eemptyScan_init(void) {
  return heff_rec_n(5, shape_numeric__given__calls__ints__escapes, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_False), heff_dup(g_std_2eordmap_2eempty_get())});
}
V g_heff_2ecompile_2eranges_2eemptyScan_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eranges_2eemptyScan_st)) return g_heff_2ecompile_2eranges_2eemptyScan_val;
  return heff_global(&g_heff_2ecompile_2eranges_2eemptyScan_val, &g_heff_2ecompile_2eranges_2eemptyScan_st, g_heff_2ecompile_2eranges_2eemptyScan_init);
}
V g_heff_2ecompile_2eranges_2emattering_lam1(V self, V *args);
V g_heff_2ecompile_2eranges_2emattering_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2emattering_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emattering_entry, 3, 0};

V g_heff_2ecompile_2eranges_2emattering(V v_fws_240, V v_box_24n_241, V v_m_242) {
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  if ((v_n_241 <= ((int64_t)0ULL))) {
    return v_m_242;
  } else {
    V v_next_2445 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eranges_2emattering_lam0, 2, 1, (V[]){heff_dup(v_m_242)}); V a_1 = heff_dup(v_m_242); V a_2 = v_fws_240; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_2446 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_next_2445, NTAG(TAG_Nil)));
    V v_t_2447 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2446; V r_ = (g_list_2efoldl_24s37738078x926874390(a_0, a_1, a_2, a_3)); heff_drop(v_t_2446); r_; });
    V v_t_2448 = ({ V a_0 = v_m_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_242); r_; });
    V v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2448; V r_ = (g_list_2efoldl_24s37738078x926874390(a_0, a_1, a_2, a_3)); heff_drop(v_t_2448); r_; });
    if (heff_intEq_c(v_t_2447, v_t_2449)) {
      return v_next_2445;
    } else {
      V t_0 = v_fws_240;
      int64_t t_1 = (v_n_241 - ((int64_t)1ULL));
      V t_2 = v_next_2445;
      v_fws_240 = t_0;
      v_n_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eranges_2emattering_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2emattering(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eranges_2emattering_lam1(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_p_2421 = args[1];
  V v_m_248 = heff_env(self)[0];
  V v_t_2424;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_dup(heff_field(v_p_2421, 0));
    v_t_2424 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2427;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_MkPair: {
    V v_y_2426 = heff_field(v_t_2424, 1);
    heff_take_n(v_t_2424, 2ULL, 2);
    v_t_2427 = v_y_2426;
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_t_2430;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_p_2421, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2433;
  switch (heff_tag_of(v_t_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_t_2430, 0);
    heff_take_n(v_t_2430, 1ULL, 2);
    v_t_2433 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_t_2430);
  }
  heff_clo_take(self, 1);
  HeffT2 v_t_2434 = ({ V a_0 = v_m_248; V a_1 = v_t_2433; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_248); heff_drop(v_t_2433); r_; });
  {
    V v_field_2436 = v_t_2434.f[1];
    int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
    V v_t_2438;
    if ((v_tag_2435 == ((int64_t)0ULL))) {
      V v_x_2437 = v_field_2436;
      v_t_2438 = v_x_2437;
    } else {
      heff_drop(v_field_2436);
      v_t_2438 = NTAG(TAG_Nil);
    }
    V v_t_2439 = ({ V a_0 = v_t_2427; V a_1 = v_t_2438; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_t_2427); heff_drop(v_t_2438); r_; });
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_t_2439);
      V v_t_2442;
      switch (heff_tag_of(v_p_2421)) {
      case TAG_MkPair: {
        V v_y_2441 = heff_field(v_p_2421, 1);
        heff_take_n(v_p_2421, 2ULL, 2);
        v_t_2442 = v_y_2441;
        break;
      }
      default: heff_nomatch(v_p_2421);
      }
      V v_t_2443 = (g_list_2eany_24s688114072x773797180(v_t_2442, v_acc_2420));
      if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
        heff_drop(v_t_2442);
        heff_drop(v_t_2443);
        return v_acc_2420;
      } else {
        heff_drop(v_t_2443);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_acc_2420});
      }
    } else {
      heff_drop(v_p_2421);
      heff_drop(v_t_2439);
      return v_acc_2420;
    }
  }
}
V g_heff_2ecompile_2eranges_2emattering_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_p_244 = args[1];
  V v_m_242 = heff_env(self)[0];
  V v_t_247;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_p_244, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_m_248 = heff_dup(v_m_242);
  V v_fn_2411;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_dup(heff_field(v_p_244, 1));
    v_fn_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_244)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_p_244, 0);
    heff_take_n(v_p_244, 1ULL, 2);
    v_t_2414 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V a_0 = v_m_242; V a_1 = v_t_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_242); heff_drop(v_t_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_is_2419;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      v_is_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2417);
      v_is_2419 = NTAG(TAG_Nil);
    }
    V v_t_2444 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eranges_2emattering_lam1, 2, 1, (V[]){v_m_248}); V a_1 = v_is_2419; V b_2 = heff_get_n(v_fn_2411, 2, 3); V r_ = (g_list_2efoldl(b_0, a_1, b_2)); heff_drop(b_0); heff_drop(b_2); r_; });
    return ({ V a_0 = v_acc_243; V a_1 = v_t_247; V a_2 = v_t_2444; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_247); heff_drop(v_t_2444); r_; });
  }
}
V g_heff_2ecompile_2eranges_2ejoinedFor_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2ejoinedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ejoinedFor_entry, 4, 0};

V g_heff_2ecompile_2eranges_2ejoinedFor(V v_sc_240, V v_gathered_241, V v_old_242, V v_g_243) {
top: ;
  V v_t_244 = (g_list_2emap_24s1792553290x233563724(v_old_242));
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_sc_240, 2, 4); V a_1 = v_g_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_t_249;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_247);
      v_t_249 = NTAG(TAG_Nil);
    }
    return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eranges_2ejoinedFor_lam0, 2, 2, (V[]){heff_dup(v_gathered_241), heff_dup(v_g_243)}); V a_1 = v_t_244; V a_2 = v_t_249; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_249); r_; });
  }
}
V g_heff_2ecompile_2eranges_2ejoinedFor_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2ejoinedFor(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2ejoinedFor_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_k_2411 = args[1];
  V v_gathered_241 = heff_env(self)[0];
  V v_g_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2412 = ({ V a_0 = v_gathered_241; V a_1 = v_k_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_gathered_241); heff_drop(v_k_2411); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_calls_2415 = v_field_2414;
      HeffT2 v_t_2416 = ({ V a_0 = v_calls_2415; V a_1 = v_g_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_calls_2415); heff_drop(v_g_243); r_; });
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_rs_2419 = v_field_2418;
          return (g_list_2ezipWith_24s1026658656x682908126(v_acc_2410, v_rs_2419));
        } else {
          heff_drop(v_field_2418);
          return v_acc_2410;
        }
      }
    } else {
      heff_drop(v_g_243);
      heff_drop(v_field_2414);
      return v_acc_2410;
    }
  }
}
Clo g_heff_2ecompile_2eranges_2edivPositive_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2edivPositive_24tok2_entry, 4, 0};

V g_heff_2ecompile_2eranges_2edivPositive_24tok2(V v_tok_240, V v_lb_241, V v_hb_242, V v_r_243) {
top: ;
  switch (heff_tag_of(v_r_243)) {
  case TAG_Unreached: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_lb_241);
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_Within: {
    V v_r1_244 = heff_field(v_r_243, 0);
    V v_r2_245 = heff_field(v_r_243, 1);
    heff_take_n(v_r_243, 3ULL, 2);
    switch (heff_tag_of(v_r1_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_lb_241);
      heff_drop(v_r2_245);
      return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_r1_244, 0);
      V v_ru_24r1_244_24Just = heff_take_reuse_n(v_r1_244, 1ULL, 1);
      switch (heff_tag_of(v_r2_245)) {
      case TAG_Nothing: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_lb_241);
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24r1_244_24Just, 1);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Just: {
        V v_y_247 = heff_field(v_r2_245, 0);
        V v_ru_24r2_245_24Just = heff_take_reuse_n(v_r2_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_hb_242)) {
        case TAG_Nothing: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_x_246, 1)) {
            heff_drop(v_x_246);
            v_t_249 = MK_INT(0LL);
          } else {
            v_t_249 = heff_intDiv_lent(v_x_246, v_lb_241, 1);
          }
          break;
        }
        case TAG_Just: {
          V v_hb_248 = heff_field(v_hb_242, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_x_246, 1)) {
            v_t_249 = heff_intDiv_lent(v_x_246, v_hb_248, 1);
          } else {
            v_t_249 = heff_intDiv_lent(v_x_246, v_lb_241, 1);
          }
          break;
        }
        default: heff_nomatch(v_hb_242);
        }
        V v_t_2411;
        switch (heff_tag_of(v_hb_242)) {
        case TAG_Nothing: {
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_247, 1)) {
            v_t_2411 = heff_intDiv(v_y_247, v_lb_241);
          } else {
            heff_drop(v_lb_241);
            heff_drop(v_y_247);
            v_t_2411 = MK_INT(-1LL);
          }
          break;
        }
        case TAG_Just: {
          V v_hb_2410 = heff_field(v_hb_242, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_y_247, 1)) {
            v_t_2411 = heff_intDiv(v_y_247, v_lb_241);
          } else {
            heff_drop(v_lb_241);
            v_t_2411 = heff_intDiv_lent(v_y_247, v_hb_2410, 1);
          }
          break;
        }
        default: heff_nomatch(v_hb_242);
        }
        return heff_tag_at_n(v_tok_240, TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r1_244_24Just, TAG_Just, 1, (V[]){v_t_249}), heff_tag_at_n(v_ru_24r2_245_24Just, TAG_Just, 1, (V[]){v_t_2411})});
      }
      default: return heff_nomatch(v_r2_245);
      }
    }
    default: return heff_nomatch(v_r1_244);
    }
  }
  default: return heff_nomatch(v_r_243);
  }
}
V g_heff_2ecompile_2eranges_2edivPositive_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2edivPositive_24tok2(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}