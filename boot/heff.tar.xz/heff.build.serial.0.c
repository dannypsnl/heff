// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT3 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo;
HeffT3 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps(V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
HeffT3 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
HeffT3 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT3 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
HeffT3 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
HeffT3 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2eelab_2eprimitive_2eprimOfName(V);
V g_heff_2eelab_2eprimitive_2eprimOfName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimOfName_clo;
double g_heff_2esyntax_2esurface_2efloatOfText_w(V);
V g_heff_2esyntax_2esurface_2efloatOfText(V);
V g_heff_2esyntax_2esurface_2efloatOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfText_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps_entry, 4, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps(V v_lit_240, V v_x2_241, V v_rest_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_dup(v_rest_242));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_x_244, 0));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, heff_dup(v_lit_240)), v_x_244);
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_245;
    V t_2 = v_rest_242;
    V t_3 = v_u_249;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_rest_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_24dps(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(v_rest_242);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(v_lit_240, v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = ({ V a_0 = v_a_247; V a_1 = v_a_245; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_a_245); r_; });
      V v_t_249 = heff_intShow(heff_strLength_lent(v_a_246, 0));
      V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, heff_dup(v_lit_240)), v_a_246);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_t_248});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_entry, 5, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_rest_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_dup(v_rest_244);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_rest_244));
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_245, 0);
      V v_a_249 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24MkPair = heff_take_reuse_n(v_x_245, 3ULL, 2);
      V v_a_2410 = heff_arrayToList(v_a_249);
      V v_a_2411 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, heff_dup(v_lit_242), v_a_2410));
      V v_t_2412 = ({ V a_0 = v_a_2410; V a_1 = v_a_247; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a_0, a_1)); heff_drop(v_a_2410); heff_drop(v_a_247); r_; });
      V v_t_2413 = heff_intShow(heff_strLength_lent(v_a_248, 0));
      V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, heff_dup(v_lit_240)), v_a_248);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2411), v_t_2412});
      return heff_tag_at_n(v_ru_24x_245_24MkPair, TAG_Cons, 2, (V[]){v_t_2414, v_t_2415});
    }
    default: return heff_nomatch(v_x_245);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SmallU: {
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str1), v_rest_241})});
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_244);
    }
    case TAG_LargeU: {
      V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str3), v_rest_241})});
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_245);
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_x2_240, 0);
    V v_t_247 = ({ V a_0 = heff_dup(v_e_246); V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str4), v_t_247}));
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_x2_240, 0);
    V v_dom_249 = heff_field(v_x2_240, 1);
    V v_cod_2410 = heff_field(v_x2_240, 2);
    V v_implicit_2411 = heff_field(v_x2_240, 3);
    V v_dflt_2412 = heff_field(v_x2_240, 4);
    V v_t_2413;
    switch (heff_tag_of(v_level_248)) {
    case TAG_Small: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str5);
      break;
    }
    case TAG_Large: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2413 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str7);
      break;
    }
    default: heff_nomatch(v_level_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_implicit_2411)) {
    case TAG_Expl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2414 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str10);
      break;
    }
    default: heff_nomatch(v_implicit_2411);
    }
    V v_t_2417;
    switch (heff_tag_of(v_dflt_2412)) {
    case TAG_Nothing: {
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_dflt_2412, 0);
      V v_t_2416 = ({ V a_0 = heff_dup(v_d_2415); V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_rest_241); r_; });
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str12), v_t_2416});
      break;
    }
    default: heff_nomatch(v_dflt_2412);
    }
    V v_rest_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417});
    V v_rest_2426;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_cod_2410, 0);
      V v_e_2420 = heff_field(v_cod_2410, 1);
      V v_t_2421 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2420, v_rest_2418));
      V v_t_2422 = heff_intShow(heff_strLength_lent(v_x_2419, 0));
      V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str13)), heff_dup(v_x_2419));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2421})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2424 = heff_field(v_cod_2410, 0);
      V v_t_2425 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2424, v_rest_2418));
      v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str15), v_t_2425});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    V v_cell_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str16), heff_hole()});
    V v_u_2428 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2427);
    V v_cell_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2430 = heff_setFieldPeek(v_u_2428, MK_INT(1LL), v_cell_2429);
    V t_0 = v_dom_249;
    V t_1 = v_rest_2426;
    V t_2 = v_u_2430;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SRecord: {
    V v_level_2431 = heff_field(v_x2_240, 0);
    V v_fs_2432 = heff_field(v_x2_240, 1);
    V v_ds_2433 = heff_field(v_x2_240, 2);
    V v_keys_2434 = heff_dup(heff_rfield(v_ds_2433, 0));
    V v_values_2435 = heff_dup(heff_rfield(v_ds_2433, 2));
    V v_keys_2436 = heff_dup(heff_rfield(v_fs_2432, 0));
    V v_values_2437 = heff_dup(heff_rfield(v_fs_2432, 2));
    V v_t_2438;
    switch (heff_tag_of(v_level_2431)) {
    case TAG_Small: {
      v_t_2438 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str17);
      break;
    }
    case TAG_Large: {
      v_t_2438 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2438 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str19);
      break;
    }
    default: heff_nomatch(v_level_2431);
    }
    V v_xs_2439 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2434), heff_arrayToList(v_values_2435)));
    V v_i_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2439));
    V v_t_2441 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str20); V a_1 = v_xs_2439; V a_2 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(a_0, a_1, a_2)); heff_drop(v_rest_241); r_; });
    V v_rest_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2440), v_t_2441});
    V v_xs_2443 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2436), heff_arrayToList(v_values_2437)));
    V v_i_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2443));
    V v_t_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str21); V a_1 = v_xs_2443; V a_2 = v_rest_2442; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(a_0, a_1, a_2)); heff_drop_tag(v_rest_2442, 2); r_; });
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2444), v_t_2445});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_t_2446})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2447);
  }
  case TAG_SSum: {
    V v_vs_2448 = heff_field(v_x2_240, 0);
    V v_keys_2449 = heff_dup(heff_rfield(v_vs_2448, 0));
    V v_values_2450 = heff_dup(heff_rfield(v_vs_2448, 2));
    V v_xs_2451 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2449), heff_arrayToList(v_values_2450)));
    V v_i_2452 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2451));
    V v_t_2453 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str23); V a_1 = MK_INT(1LL); V a_2 = MK_INT(0LL); V a_3 = v_xs_2451; V a_4 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_241); r_; });
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2452), v_t_2453});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str24), v_t_2454}));
  }
  case TAG_SIsTy: {
    V v_t2_2455 = heff_field(v_x2_240, 0);
    V v_cell_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str25), heff_hole()});
    V v_u_2457 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2456);
    V t_0 = v_t2_2455;
    V t_1 = v_rest_241;
    V t_2 = v_u_2457;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrimInt: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str26), v_rest_241}));
  }
  case TAG_SPrimFloat: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str27), v_rest_241}));
  }
  case TAG_SPrimString: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str28), v_rest_241}));
  }
  case TAG_SPrimRune: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str29), v_rest_241}));
  }
  case TAG_SPrimArray: {
    V v_t2_2458 = heff_field(v_x2_240, 0);
    V v_cell_2459 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str30), heff_hole()});
    V v_u_2460 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2459);
    V t_0 = v_t2_2458;
    V t_1 = v_rest_241;
    V t_2 = v_u_2460;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFixed: {
    V v_w_2461 = heff_field(v_x2_240, 0);
    V v_t_2462;
    switch (heff_tag_of(v_w_2461)) {
    case TAG_I8: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str31);
      break;
    }
    case TAG_I16: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str32);
      break;
    }
    case TAG_I32: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str33);
      break;
    }
    case TAG_I64: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str34);
      break;
    }
    case TAG_U8: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str35);
      break;
    }
    case TAG_U16: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str36);
      break;
    }
    case TAG_U32: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str37);
      break;
    }
    case TAG_U64: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str38);
      break;
    }
    case TAG_F32: {
      v_t_2462 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str39);
      break;
    }
    default: heff_nomatch(v_w_2461);
    }
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, v_rest_241})});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2463);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_dup(v_rest_241);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(v_xs_243, v_rest_241));
    return ({ V a_0 = heff_dup(v_x_242); V a_1 = v_t_244; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_t_244); r_; });
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_entry, 6, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_rest_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    return heff_dup(v_rest_245);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_247, v_rest_245));
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_246, 0);
      V v_a_2410 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_MkPair: {
        V v_a_2411 = heff_field(v_a_2410, 0);
        V v_a_2412 = heff_field(v_a_2410, 1);
        heff_take_n(v_a_2410, 3ULL, 2);
        V v_a_2413 = heff_arrayToList(v_a_2411);
        V v_a_2414 = ({ V a_0 = v_a_2412; V a_1 = v_a_248; V r_ = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a_0, a_1)); heff_drop(v_a_248); r_; });
        V v_a_2415 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, heff_dup(v_lit_242), v_a_2413));
        V v_t_2416 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(heff_dup(v_lit_243), v_a_2413, v_a_2414));
        v_t_2417 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2415), v_t_2416});
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      V v_t_2418 = heff_intShow(heff_strLength_lent(v_a_249, 0));
      V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, heff_dup(v_lit_240)), v_a_249);
      return heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2419, v_t_2417});
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a5 = a[5]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(a0, a1, a2, a3, a[4], a5); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8, 7, "Float32");

HeffT3 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT2 v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str0); V a_1 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str1); V a_2 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str2); V a_3 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str3); V a_4 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str4); V a_5 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str5); V a_6 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str6); V a_7 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str7); V a_8 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_24cpr_str8); V a_9 = v_x_246; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(v_x_246); heff_drop(b_10); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_2410;
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_2411, v_j_247}});
        } else {
          heff_drop(v_j_247);
          heff_drop(v_field_2410);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args);

HeffT3 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      V v_j_248 = v_field_246;
      HeffT3 v_t_2422 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0, 2, 1, (V[]){v_d_240}); V a_1 = v_x_247; V a_2 = v_s_241; V a_3 = v_j_248; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      {
        V v_field_2424 = v_t_2422.f[1];
        V v_field_2425 = v_t_2422.f[2];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          V v_x_2426 = v_field_2424;
          V v_j_2427 = v_field_2425;
          V v_t_2428 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2426)));
          V v_t_2429 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2426));
          V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_x_2426));
          V v_x_2431 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2428), v_t_2429, heff_arrayFromList(v_t_2430)});
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_2431, v_j_2427}});
        } else {
          heff_drop(v_field_2424);
          heff_drop(v_field_2425);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_d_240);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24cpr_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_i_2410 = args[1];
  V v_d_240 = heff_env(self)[0];
  HeffT3 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_249), v_i_2410));
  {
    V v_field_2413 = v_t_2411.f[1];
    V v_field_2414 = v_t_2411.f[2];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      V v_j_2416 = v_field_2414;
      heff_clo_take(self, 1);
      V v_x3_2417 = heff_tr(heff_call(v_d_240, 2, (V[]){v_s_249, v_j_2416}));
      switch (heff_tag_of(v_x3_2417)) {
      case TAG_Nothing: {
        heff_drop(v_x_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2418 = heff_field(v_x3_2417, 0);
        V v_ru_24x3_2417_24Just = heff_take_reuse_n(v_x3_2417, 1ULL, 1);
        switch (heff_tag_of(v_x31_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x31_2418, 0);
          V v_j_2420 = heff_field(v_x31_2418, 1);
          V v_ru_24x31_2418_24MkPair = heff_take_reuse_n(v_x31_2418, 3ULL, 2);
          V v_t_2421 = heff_tag_re_n(v_ru_24x31_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2415, v_x_2419}), v_j_2420});
          return heff_tag_at_n(v_ru_24x3_2417_24Just, TAG_Just, 1, (V[]){v_t_2421});
        }
        default: return heff_nomatch(v_x31_2418);
        }
      }
      default: return heff_nomatch(v_x3_2417);
      }
    } else {
      heff_drop(v_s_249);
      heff_drop(self);
      heff_drop(v_field_2413);
      heff_drop(v_field_2414);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etakeAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeAlt_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeAlt(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      V v_j_248 = v_field_246;
      HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_247, v_s_241, v_j_248));
      {
        V v_field_2411 = v_t_249.f[1];
        V v_field_2412 = v_t_249.f[2];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2411;
          V v_j_2414 = v_field_2412;
          V v_x3_2415 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_241, v_j_2414}));
          switch (heff_tag_of(v_x3_2415)) {
          case TAG_Nothing: {
            heff_drop(v_x_2413);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2416 = heff_field(v_x3_2415, 0);
            V v_ru_24x3_2415_24Just = heff_take_reuse_n(v_x3_2415, 1ULL, 1);
            switch (heff_tag_of(v_x31_2416)) {
            case TAG_MkPair: {
              V v_x_2417 = heff_field(v_x31_2416, 0);
              V v_j_2418 = heff_field(v_x31_2416, 1);
              V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
              V v_t_2419 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2413), v_x_2417});
              return heff_tag_at_n(v_ru_24x3_2415_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_j_2418})});
            }
            default: return heff_nomatch(v_x31_2416);
            }
          }
          default: return heff_nomatch(v_x3_2415);
          }
        } else {
          heff_drop_rec(v_k_240, 2);
          heff_drop(v_s_241);
          heff_drop(v_field_2411);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeAlt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str19, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str20, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str21, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str22, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24cpr_str23, 3, "f32");

HeffT3 g_heff_2ebuild_2eserial_2etermOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    HeffT3 v_t_244 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2eint_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      V v_field_247 = v_t_244.f[2];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_246;
        V v_j_249 = v_field_247;
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SLocal, 1, (V[]){v_x_248}), v_j_249}});
      } else {
        heff_drop(v_field_246);
        heff_drop(v_field_247);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 2);
      HeffT3 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
      {
        V v_field_2412 = v_t_2410.f[1];
        V v_field_2413 = v_t_2410.f[2];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2412;
          V v_j_2415 = v_field_2413;
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2414}), v_j_2415}});
        } else {
          heff_drop(v_field_2412);
          heff_drop(v_field_2413);
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str2), 2)) {
        V v_x3_2416 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
        switch (heff_tag_of(v_x3_2416)) {
        case TAG_Nothing: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2417 = heff_field(v_x3_2416, 0);
          V v_ru_24x3_2416_24Just = heff_take_reuse_n(v_x3_2416, 1ULL, 1);
          switch (heff_tag_of(v_x31_2417)) {
          case TAG_MkPair: {
            V v_x_2418 = heff_field(v_x31_2417, 0);
            V v_j_2419 = heff_field(v_x31_2417, 1);
            heff_take_n(v_x31_2417, 3ULL, 2);
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_2416_24Just, TAG_SCode, 1, (V[]){v_x_2418}), v_j_2419}});
          }
          default: return ((HeffT3){{heff_nomatch(v_x31_2417)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x3_2416)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str3), 2)) {
          V v_m_2420 = heff_dup(heff_rfield(v_k_240, 0));
          V v_x3_2421 = heff_tr(heff_call(v_m_2420, 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2421)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2422 = heff_field(v_x3_2421, 0);
            heff_take_n(v_x3_2421, 1ULL, 1);
            switch (heff_tag_of(v_x31_2422)) {
            case TAG_MkPair: {
              V v_x_2423 = heff_field(v_x31_2422, 0);
              V v_j_2424 = heff_field(v_x31_2422, 1);
              V v_ru_24x31_2422_24MkPair = heff_take_reuse_n(v_x31_2422, 3ULL, 2);
              V v_x3_2425 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_2424}));
              switch (heff_tag_of(v_x3_2425)) {
              case TAG_Nothing: {
                heff_drop(v_x_2423);
                heff_drop_cell(v_ru_24x31_2422_24MkPair, 2);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2426 = heff_field(v_x3_2425, 0);
                heff_take_n(v_x3_2425, 1ULL, 1);
                switch (heff_tag_of(v_x31_2426)) {
                case TAG_MkPair: {
                  V v_x_2427 = heff_field(v_x31_2426, 0);
                  V v_j_2428 = heff_field(v_x31_2426, 1);
                  heff_take_n(v_x31_2426, 3ULL, 2);
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2422_24MkPair, TAG_SApp, 2, (V[]){v_x_2423, v_x_2427}), v_j_2428}});
                }
                default: return ((HeffT3){{heff_nomatch(v_x31_2426)}});
                }
              }
              default: return ((HeffT3){{heff_nomatch(v_x3_2425)}});
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_x31_2422)}});
            }
          }
          default: return ((HeffT3){{heff_nomatch(v_x3_2421)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str4), 2)) {
            V v_m_2429 = heff_take_field(v_k_240, 1);
            V v_x3_2430 = heff_tr(heff_call(v_m_2429, 2, (V[]){heff_dup(v_z_242), v_z_243}));
            switch (heff_tag_of(v_x3_2430)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2431 = heff_field(v_x3_2430, 0);
              heff_take_n(v_x3_2430, 1ULL, 1);
              switch (heff_tag_of(v_x31_2431)) {
              case TAG_MkPair: {
                V v_x_2432 = heff_field(v_x31_2431, 0);
                V v_j_2433 = heff_field(v_x31_2431, 1);
                V v_ru_24x31_2431_24MkPair = heff_take_reuse_n(v_x31_2431, 3ULL, 2);
                HeffT3 v_t_2434 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_2433));
                {
                  V v_field_2436 = v_t_2434.f[1];
                  V v_field_2437 = v_t_2434.f[2];
                  int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
                  if ((v_tag_2435 == ((int64_t)0ULL))) {
                    V v_x_2438 = v_field_2436;
                    V v_j_2439 = v_field_2437;
                    HeffT3 v_t_2440 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_2438; V a_2 = v_z_242; V a_3 = v_j_2439; HeffT3 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2438); r_; });
                    {
                      V v_field_2442 = v_t_2440.f[1];
                      V v_field_2443 = v_t_2440.f[2];
                      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                      if ((v_tag_2441 == ((int64_t)0ULL))) {
                        V v_x_2444 = v_field_2442;
                        V v_j_2445 = v_field_2443;
                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2431_24MkPair, TAG_SLam, 2, (V[]){v_x_2432, v_x_2444}), v_j_2445}});
                      } else {
                        heff_drop(v_x_2432);
                        heff_drop_cell(v_ru_24x31_2431_24MkPair, 2);
                        heff_drop(v_field_2442);
                        heff_drop(v_field_2443);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2432);
                    heff_drop_cell(v_ru_24x31_2431_24MkPair, 2);
                    heff_drop(v_field_2436);
                    heff_drop(v_field_2437);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT3){{heff_nomatch(v_x31_2431)}});
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_x3_2430)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str5), 2)) {
              HeffT3 v_t_2446 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_z_242; V a_2 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(a_0, a_1, a_2)); heff_drop(v_z_242); r_; });
              {
                V v_field_2448 = v_t_2446.f[1];
                V v_field_2449 = v_t_2446.f[2];
                int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
                if ((v_tag_2447 == ((int64_t)0ULL))) {
                  V v_x_2450 = v_field_2448;
                  V v_j_2451 = v_field_2449;
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SCons, 1, (V[]){v_x_2450}), v_j_2451}});
                } else {
                  heff_drop(v_field_2448);
                  heff_drop(v_field_2449);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str6), 2)) {
                V v_x3_2452 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2452)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2453 = heff_field(v_x3_2452, 0);
                  heff_take_n(v_x3_2452, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2453)) {
                  case TAG_MkPair: {
                    V v_x_2454 = heff_field(v_x31_2453, 0);
                    V v_j_2455 = heff_field(v_x31_2453, 1);
                    V v_ru_24x31_2453_24MkPair = heff_take_reuse_n(v_x31_2453, 3ULL, 2);
                    HeffT3 v_t_2456 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_2455));
                    {
                      V v_field_2458 = v_t_2456.f[1];
                      V v_field_2459 = v_t_2456.f[2];
                      int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                      if ((v_tag_2457 == ((int64_t)0ULL))) {
                        V v_x_2460 = v_field_2458;
                        V v_j_2461 = v_field_2459;
                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2453_24MkPair, TAG_SProj, 2, (V[]){v_x_2454, v_x_2460}), v_j_2461}});
                      } else {
                        heff_drop(v_x_2454);
                        heff_drop_cell(v_ru_24x31_2453_24MkPair, 2);
                        heff_drop(v_field_2458);
                        heff_drop(v_field_2459);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT3){{heff_nomatch(v_x31_2453)}});
                  }
                }
                default: return ((HeffT3){{heff_nomatch(v_x3_2452)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str7), 2)) {
                  HeffT3 v_t_2462 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                  {
                    V v_field_2464 = v_t_2462.f[1];
                    V v_field_2465 = v_t_2462.f[2];
                    int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                    if ((v_tag_2463 == ((int64_t)0ULL))) {
                      V v_x_2466 = v_field_2464;
                      V v_j_2467 = v_field_2465;
                      HeffT3 v_t_2468 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_242, v_j_2467));
                      {
                        V v_field_2470 = v_t_2468.f[1];
                        V v_field_2471 = v_t_2468.f[2];
                        int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                        if ((v_tag_2469 == ((int64_t)0ULL))) {
                          V v_x_2472 = v_field_2470;
                          V v_j_2473 = v_field_2471;
                          HeffT3 v_t_2474 = ({ V b_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_2472; V a_2 = v_z_242; V a_3 = v_j_2473; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2etimes_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_z_242); r_; });
                          {
                            V v_field_2476 = v_t_2474.f[1];
                            V v_field_2477 = v_t_2474.f[2];
                            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
                            if ((v_tag_2475 == ((int64_t)0ULL))) {
                              V v_x_2478 = v_field_2476;
                              V v_j_2479 = v_field_2477;
                              V v_f_2480 = heff_tag_n(TAG_STag, 2, (V[]){v_x_2466, heff_arrayFromList(v_x_2478)});
                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2480, v_j_2479}});
                            } else {
                              heff_drop(v_x_2466);
                              heff_drop(v_field_2476);
                              heff_drop(v_field_2477);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop_rec(v_k_240, 2);
                          heff_drop(v_z_242);
                          heff_drop(v_x_2466);
                          heff_drop(v_field_2470);
                          heff_drop(v_field_2471);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop(v_field_2464);
                      heff_drop(v_field_2465);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str8), 2)) {
                    V v_m_2481 = heff_dup(heff_rfield(v_k_240, 0));
                    V v_x3_2482 = heff_tr(heff_call(v_m_2481, 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_2482)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2483 = heff_field(v_x3_2482, 0);
                      heff_take_n(v_x3_2482, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2483)) {
                      case TAG_MkPair: {
                        V v_x_2484 = heff_field(v_x31_2483, 0);
                        V v_j_2485 = heff_field(v_x31_2483, 1);
                        V v_ru_24x31_2483_24MkPair = heff_take_reuse_n(v_x31_2483, 3ULL, 2);
                        V v_t_2486 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeAlt_clo), 1, (V[]){v_k_240}));
                        HeffT3 v_t_2487 = ({ V a_0 = v_t_2486; V a_1 = v_z_242; V a_2 = v_j_2485; HeffT3 r_ = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(a_0, a_1, a_2)); heff_drop(v_z_242); r_; });
                        {
                          V v_field_2489 = v_t_2487.f[1];
                          V v_field_2490 = v_t_2487.f[2];
                          int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
                          if ((v_tag_2488 == ((int64_t)0ULL))) {
                            V v_x_2491 = v_field_2489;
                            V v_j_2492 = v_field_2490;
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2483_24MkPair, TAG_SMatch, 2, (V[]){v_x_2484, v_x_2491}), v_j_2492}});
                          } else {
                            heff_drop(v_x_2484);
                            heff_drop_cell(v_ru_24x31_2483_24MkPair, 2);
                            heff_drop(v_field_2489);
                            heff_drop(v_field_2490);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT3){{heff_nomatch(v_x31_2483)}});
                      }
                    }
                    default: return ((HeffT3){{heff_nomatch(v_x3_2482)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str9), 2)) {
                      V v_m_2493 = heff_dup(heff_rfield(v_k_240, 0));
                      V v_x3_2494 = heff_tr(heff_call(v_m_2493, 2, (V[]){heff_dup(v_z_242), v_z_243}));
                      switch (heff_tag_of(v_x3_2494)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 2);
                        heff_drop(v_z_242);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_2495 = heff_field(v_x3_2494, 0);
                        heff_take_n(v_x3_2494, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2495)) {
                        case TAG_MkPair: {
                          V v_x_2496 = heff_field(v_x31_2495, 0);
                          V v_j_2497 = heff_field(v_x31_2495, 1);
                          heff_take_n(v_x31_2495, 3ULL, 2);
                          HeffT3 v_t_2498 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_j_2497));
                          {
                            V v_field_24100 = v_t_2498.f[1];
                            V v_field_24101 = v_t_2498.f[2];
                            int64_t v_tag_2499 = ((int64_t)v_t_2498.f[0]);
                            if ((v_tag_2499 == ((int64_t)0ULL))) {
                              V v_x_24102 = v_field_24100;
                              V v_j_24103 = v_field_24101;
                              V v_x3_24104 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24103}));
                              switch (heff_tag_of(v_x3_24104)) {
                              case TAG_Nothing: {
                                heff_drop(v_x_2496);
                                heff_drop(v_x_24102);
                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24105 = heff_field(v_x3_24104, 0);
                                heff_take_n(v_x3_24104, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24105)) {
                                case TAG_MkPair: {
                                  V v_x_24106 = heff_field(v_x31_24105, 0);
                                  V v_j_24107 = heff_field(v_x31_24105, 1);
                                  heff_take_n(v_x31_24105, 3ULL, 2);
                                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2496, v_x_24102, v_x_24106}), v_j_24107}});
                                }
                                default: return ((HeffT3){{heff_nomatch(v_x31_24105)}});
                                }
                              }
                              default: return ((HeffT3){{heff_nomatch(v_x3_24104)}});
                              }
                            } else {
                              heff_drop_rec(v_k_240, 2);
                              heff_drop(v_z_242);
                              heff_drop(v_x_2496);
                              heff_drop(v_field_24100);
                              heff_drop(v_field_24101);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT3){{heff_nomatch(v_x31_2495)}});
                        }
                      }
                      default: return ((HeffT3){{heff_nomatch(v_x3_2494)}});
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str10), 2)) {
                        V v_x3_24108 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_24108)) {
                        case TAG_Nothing: {
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_24109 = heff_field(v_x3_24108, 0);
                          V v_ru_24x3_24108_24Just = heff_take_reuse_n(v_x3_24108, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24109)) {
                          case TAG_MkPair: {
                            V v_x_24110 = heff_field(v_x31_24109, 0);
                            V v_j_24111 = heff_field(v_x31_24109, 1);
                            heff_take_n(v_x31_24109, 3ULL, 2);
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_24108_24Just, TAG_SIs, 1, (V[]){v_x_24110}), v_j_24111}});
                          }
                          default: return ((HeffT3){{heff_nomatch(v_x31_24109)}});
                          }
                        }
                        default: return ((HeffT3){{heff_nomatch(v_x3_24108)}});
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str11), 2)) {
                          heff_drop_rec(v_k_240, 2);
                          heff_drop(v_z_242);
                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SOpaque), v_z_243}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str12), 2)) {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SAbandon), v_z_243}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str13), 2)) {
                              V v_x3_24112 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                              switch (heff_tag_of(v_x3_24112)) {
                              case TAG_Nothing: {
                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_24113 = heff_field(v_x3_24112, 0);
                                V v_ru_24x3_24112_24Just = heff_take_reuse_n(v_x3_24112, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24113)) {
                                case TAG_MkPair: {
                                  V v_x_24114 = heff_field(v_x31_24113, 0);
                                  V v_j_24115 = heff_field(v_x31_24113, 1);
                                  heff_take_n(v_x31_24113, 3ULL, 2);
                                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_24112_24Just, TAG_SRec, 1, (V[]){v_x_24114}), v_j_24115}});
                                }
                                default: return ((HeffT3){{heff_nomatch(v_x31_24113)}});
                                }
                              }
                              default: return ((HeffT3){{heff_nomatch(v_x3_24112)}});
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str14), 2)) {
                                V v_m_24116 = heff_take_field(v_k_240, 1);
                                V v_x3_24117 = heff_tr(heff_call(v_m_24116, 2, (V[]){heff_dup(v_z_242), v_z_243}));
                                switch (heff_tag_of(v_x3_24117)) {
                                case TAG_Nothing: {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24118 = heff_field(v_x3_24117, 0);
                                  heff_take_n(v_x3_24117, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24118)) {
                                  case TAG_MkPair: {
                                    V v_x_24119 = heff_field(v_x31_24118, 0);
                                    V v_j_24120 = heff_field(v_x31_24118, 1);
                                    V v_ru_24x31_24118_24MkPair = heff_take_reuse_n(v_x31_24118, 3ULL, 2);
                                    HeffT3 v_t_24121 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_24120));
                                    {
                                      V v_field_24123 = v_t_24121.f[1];
                                      V v_field_24124 = v_t_24121.f[2];
                                      int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
                                      if ((v_tag_24122 == ((int64_t)0ULL))) {
                                        V v_x_24125 = v_field_24123;
                                        V v_j_24126 = v_field_24124;
                                        HeffT3 v_t_24127 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_x_24125; V a_2 = v_z_242; V a_3 = v_j_24126; HeffT3 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_24125); r_; });
                                        {
                                          V v_field_24129 = v_t_24127.f[1];
                                          V v_field_24130 = v_t_24127.f[2];
                                          int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
                                          if ((v_tag_24128 == ((int64_t)0ULL))) {
                                            V v_x_24131 = v_field_24129;
                                            V v_j_24132 = v_field_24130;
                                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24118_24MkPair, TAG_SFix, 2, (V[]){v_x_24119, v_x_24131}), v_j_24132}});
                                          } else {
                                            heff_drop(v_x_24119);
                                            heff_drop_cell(v_ru_24x31_24118_24MkPair, 2);
                                            heff_drop(v_field_24129);
                                            heff_drop(v_field_24130);
                                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        heff_drop_rec(v_k_240, 2);
                                        heff_drop(v_z_242);
                                        heff_drop(v_x_24119);
                                        heff_drop_cell(v_ru_24x31_24118_24MkPair, 2);
                                        heff_drop(v_field_24123);
                                        heff_drop(v_field_24124);
                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT3){{heff_nomatch(v_x31_24118)}});
                                  }
                                }
                                default: return ((HeffT3){{heff_nomatch(v_x3_24117)}});
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str15), 2)) {
                                  HeffT3 v_t_24133 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
                                  {
                                    V v_field_24135 = v_t_24133.f[1];
                                    V v_field_24136 = v_t_24133.f[2];
                                    int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
                                    if ((v_tag_24134 == ((int64_t)0ULL))) {
                                      V v_x_24137 = v_field_24135;
                                      V v_j_24138 = v_field_24136;
                                      V v_x3_24139 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24138}));
                                      switch (heff_tag_of(v_x3_24139)) {
                                      case TAG_Nothing: {
                                        heff_drop(v_x_24137);
                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                      }
                                      case TAG_Just: {
                                        V v_x31_24140 = heff_field(v_x3_24139, 0);
                                        heff_take_n(v_x3_24139, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24140)) {
                                        case TAG_MkPair: {
                                          V v_x_24141 = heff_field(v_x31_24140, 0);
                                          V v_j_24142 = heff_field(v_x31_24140, 1);
                                          V v_ru_24x31_24140_24MkPair = heff_take_reuse_n(v_x31_24140, 3ULL, 2);
                                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24140_24MkPair, TAG_SImplicit, 2, (V[]){v_x_24137, v_x_24141}), v_j_24142}});
                                        }
                                        default: return ((HeffT3){{heff_nomatch(v_x31_24140)}});
                                        }
                                      }
                                      default: return ((HeffT3){{heff_nomatch(v_x3_24139)}});
                                      }
                                    } else {
                                      heff_drop_rec(v_k_240, 2);
                                      heff_drop(v_z_242);
                                      heff_drop(v_field_24135);
                                      heff_drop(v_field_24136);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str16), 2)) {
                                    HeffT3 v_t_24143 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                    {
                                      V v_field_24145 = v_t_24143.f[1];
                                      V v_field_24146 = v_t_24143.f[2];
                                      int64_t v_tag_24144 = ((int64_t)v_t_24143.f[0]);
                                      if ((v_tag_24144 == ((int64_t)0ULL))) {
                                        V v_x_24147 = v_field_24145;
                                        V v_j_24148 = v_field_24146;
                                        V v_x1_24149 = ({ V a_0 = v_x_24147; V r_ = (g_heff_2eelab_2eprimitive_2eprimOfName(a_0)); heff_drop(v_x_24147); r_; });
                                        switch (heff_tag_of(v_x1_24149)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_j_24148);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x_24150 = heff_field(v_x1_24149, 0);
                                          V v_ru_24x1_24149_24Just = heff_take_reuse_n(v_x1_24149, 1ULL, 1);
                                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_24149_24Just, TAG_SPrim, 1, (V[]){v_x_24150}), v_j_24148}});
                                        }
                                        default: return ((HeffT3){{heff_nomatch(v_x1_24149)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24145);
                                        heff_drop(v_field_24146);
                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str17), 2)) {
                                      HeffT3 v_t_24151 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                      {
                                        V v_field_24153 = v_t_24151.f[1];
                                        V v_field_24154 = v_t_24151.f[2];
                                        int64_t v_tag_24152 = ((int64_t)v_t_24151.f[0]);
                                        if ((v_tag_24152 == ((int64_t)0ULL))) {
                                          V v_x_24155 = v_field_24153;
                                          V v_j_24156 = v_field_24154;
                                          V v_t_24157 = ({ V a_0 = v_x_24155; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24155); r_; });
                                          V v_x_24158 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24157});
                                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24158, v_j_24156}});
                                        } else {
                                          heff_drop(v_field_24153);
                                          heff_drop(v_field_24154);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str18), 2)) {
                                        HeffT3 v_t_24159 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                        {
                                          V v_field_24161 = v_t_24159.f[1];
                                          V v_field_24162 = v_t_24159.f[2];
                                          int64_t v_tag_24160 = ((int64_t)v_t_24159.f[0]);
                                          if ((v_tag_24160 == ((int64_t)0ULL))) {
                                            V v_x_24163 = v_field_24161;
                                            V v_j_24164 = v_field_24162;
                                            double v_t_24165 = ({ V a_0 = v_x_24163; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24163); r_; });
                                            V v_x_24166 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24165)});
                                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24166, v_j_24164}});
                                          } else {
                                            heff_drop(v_field_24161);
                                            heff_drop(v_field_24162);
                                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str19), 2)) {
                                          HeffT3 v_t_24167 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                          {
                                            V v_field_24169 = v_t_24167.f[1];
                                            V v_field_24170 = v_t_24167.f[2];
                                            int64_t v_tag_24168 = ((int64_t)v_t_24167.f[0]);
                                            if ((v_tag_24168 == ((int64_t)0ULL))) {
                                              V v_x_24171 = v_field_24169;
                                              V v_j_24172 = v_field_24170;
                                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24171}), v_j_24172}});
                                            } else {
                                              heff_drop(v_field_24169);
                                              heff_drop(v_field_24170);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str20), 2)) {
                                            HeffT3 v_t_24173 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                            {
                                              V v_field_24175 = v_t_24173.f[1];
                                              V v_field_24176 = v_t_24173.f[2];
                                              int64_t v_tag_24174 = ((int64_t)v_t_24173.f[0]);
                                              if ((v_tag_24174 == ((int64_t)0ULL))) {
                                                V v_x_24177 = v_field_24175;
                                                V v_j_24178 = v_field_24176;
                                                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24177}), v_j_24178}});
                                              } else {
                                                heff_drop(v_field_24175);
                                                heff_drop(v_field_24176);
                                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str21), 2)) {
                                              HeffT3 v_t_24179 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                              {
                                                V v_field_24181 = v_t_24179.f[1];
                                                V v_field_24182 = v_t_24179.f[2];
                                                int64_t v_tag_24180 = ((int64_t)v_t_24179.f[0]);
                                                if ((v_tag_24180 == ((int64_t)0ULL))) {
                                                  V v_x_24183 = v_field_24181;
                                                  V v_j_24184 = v_field_24182;
                                                  V v_t_24185 = ({ V a_0 = v_x_24183; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24183); r_; });
                                                  V v_x_24186 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24185});
                                                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24186, v_j_24184}});
                                                } else {
                                                  heff_drop(v_field_24181);
                                                  heff_drop(v_field_24182);
                                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str22), 2)) {
                                                HeffT3 v_t_24187 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_242, v_z_243));
                                                {
                                                  V v_field_24189 = v_t_24187.f[1];
                                                  V v_field_24190 = v_t_24187.f[2];
                                                  int64_t v_tag_24188 = ((int64_t)v_t_24187.f[0]);
                                                  if ((v_tag_24188 == ((int64_t)0ULL))) {
                                                    V v_x_24191 = v_field_24189;
                                                    V v_j_24192 = v_field_24190;
                                                    HeffT3 v_t_24193 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_j_24192));
                                                    {
                                                      V v_field_24195 = v_t_24193.f[1];
                                                      V v_field_24196 = v_t_24193.f[2];
                                                      int64_t v_tag_24194 = ((int64_t)v_t_24193.f[0]);
                                                      if ((v_tag_24194 == ((int64_t)0ULL))) {
                                                        V v_x_24197 = v_field_24195;
                                                        V v_j_24198 = v_field_24196;
                                                        V v_t_24199 = ({ V a_0 = v_x_24197; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24197); r_; });
                                                        V v_x_24200 = heff_tag_n(TAG_SLitFixed, 2, (V[]){v_x_24191, v_t_24199});
                                                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24200, v_j_24198}});
                                                      } else {
                                                        heff_drop(v_x_24191);
                                                        heff_drop(v_field_24195);
                                                        heff_drop(v_field_24196);
                                                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                      }
                                                    }
                                                  } else {
                                                    heff_drop(v_z_242);
                                                    heff_drop(v_field_24189);
                                                    heff_drop(v_field_24190);
                                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_24cpr_str23), 2)) {
                                                  HeffT3 v_t_24201 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_242, v_z_243));
                                                  {
                                                    V v_field_24203 = v_t_24201.f[1];
                                                    V v_field_24204 = v_t_24201.f[2];
                                                    int64_t v_tag_24202 = ((int64_t)v_t_24201.f[0]);
                                                    if ((v_tag_24202 == ((int64_t)0ULL))) {
                                                      V v_x_24205 = v_field_24203;
                                                      V v_j_24206 = v_field_24204;
                                                      double v_t_24207 = ({ V a_0 = v_x_24205; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24205); r_; });
                                                      V v_x_24208 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24207)});
                                                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_x_24208, v_j_24206}});
                                                    } else {
                                                      heff_drop(v_field_24203);
                                                      heff_drop(v_field_24204);
                                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11, 2, "px");

HeffT3 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 2);
    return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str1), 2)) {
      V v_x3_244 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_244)) {
      case TAG_Nothing: {
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_245 = heff_field(v_x3_244, 0);
        V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
        switch (heff_tag_of(v_x31_245)) {
        case TAG_MkPair: {
          V v_x_246 = heff_field(v_x31_245, 0);
          V v_j_247 = heff_field(v_x31_245, 1);
          heff_take_n(v_x31_245, 3ULL, 2);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_244_24Just, TAG_SDecode, 1, (V[]){v_x_246}), v_j_247}});
        }
        default: return ((HeffT3){{heff_nomatch(v_x31_245)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x3_244)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str2), 2)) {
        HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_242, v_z_243));
        {
          V v_field_2410 = v_t_248.f[1];
          V v_field_2411 = v_t_248.f[2];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x_2412 = v_field_2410;
            V v_j_2413 = v_field_2411;
            V v_x3_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 2, (V[]){heff_dup(v_z_242), v_j_2413}));
            switch (heff_tag_of(v_x3_2414)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              heff_drop(v_x_2412);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2415 = heff_field(v_x3_2414, 0);
              heff_take_n(v_x3_2414, 1ULL, 1);
              switch (heff_tag_of(v_x31_2415)) {
              case TAG_MkPair: {
                V v_x_2416 = heff_field(v_x31_2415, 0);
                V v_j_2417 = heff_field(v_x31_2415, 1);
                heff_take_n(v_x31_2415, 3ULL, 2);
                HeffT3 v_t_2418 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_242, v_j_2417));
                {
                  V v_field_2420 = v_t_2418.f[1];
                  V v_field_2421 = v_t_2418.f[2];
                  int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                  if ((v_tag_2419 == ((int64_t)0ULL))) {
                    V v_x_2422 = v_field_2420;
                    V v_j_2423 = v_field_2421;
                    HeffT3 v_t_2424 = ({ V a_0 = heff_dup(heff_rfield(v_k_240, 1)); V a_1 = v_x_2422; V a_2 = heff_dup(v_z_242); V a_3 = v_j_2423; HeffT3 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2422); r_; });
                    {
                      V v_field_2426 = v_t_2424.f[1];
                      V v_field_2427 = v_t_2424.f[2];
                      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
                      if ((v_tag_2425 == ((int64_t)0ULL))) {
                        V v_x_2428 = v_field_2426;
                        V v_j_2429 = v_field_2427;
                        HeffT3 v_t_2430 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(v_z_242, v_j_2429));
                        {
                          V v_field_2432 = v_t_2430.f[1];
                          V v_field_2433 = v_t_2430.f[2];
                          int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
                          if ((v_tag_2431 == ((int64_t)0ULL))) {
                            V v_x_2434 = v_field_2432;
                            V v_j_2435 = v_field_2433;
                            V v_f_2436 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2edefaultOf_clo), 1, (V[]){v_k_240}));
                            V v_s_2437 = v_z_242;
                            V v_i_2438 = v_j_2435;
                            HeffT3 v_t_2439 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2437, v_i_2438));
                            {
                              V v_field_2441 = v_t_2439.f[1];
                              V v_field_2442 = v_t_2439.f[2];
                              int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
                              V v_x3_2445;
                              if ((v_tag_2440 == ((int64_t)0ULL))) {
                                V v_x_2443 = v_field_2441;
                                V v_j_2444 = v_field_2442;
                                v_x3_2445 = heff_tr(heff_call(v_f_2436, 3, (V[]){v_x_2443, v_s_2437, v_j_2444}));
                              } else {
                                heff_drop(v_f_2436);
                                heff_drop(v_s_2437);
                                heff_drop(v_field_2441);
                                heff_drop(v_field_2442);
                                v_x3_2445 = NTAG(TAG_Nothing);
                              }
                              switch (heff_tag_of(v_x3_2445)) {
                              case TAG_Nothing: {
                                heff_drop(v_x_2412);
                                heff_drop(v_x_2416);
                                heff_drop(v_x_2428);
                                heff_drop(v_x_2434);
                                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                              }
                              case TAG_Just: {
                                V v_x31_2446 = heff_field(v_x3_2445, 0);
                                heff_take_n(v_x3_2445, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2446)) {
                                case TAG_MkPair: {
                                  V v_x_2447 = heff_field(v_x31_2446, 0);
                                  V v_j_2448 = heff_field(v_x31_2446, 1);
                                  heff_take_n(v_x31_2446, 3ULL, 2);
                                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2412, v_x_2416, v_x_2428, v_x_2434, v_x_2447}), v_j_2448}});
                                }
                                default: return ((HeffT3){{heff_nomatch(v_x31_2446)}});
                                }
                              }
                              default: return ((HeffT3){{heff_nomatch(v_x3_2445)}});
                              }
                            }
                          } else {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop(v_x_2412);
                            heff_drop(v_x_2416);
                            heff_drop(v_x_2428);
                            heff_drop(v_field_2432);
                            heff_drop(v_field_2433);
                            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        heff_drop_rec(v_k_240, 2);
                        heff_drop(v_z_242);
                        heff_drop(v_x_2412);
                        heff_drop(v_x_2416);
                        heff_drop(v_field_2426);
                        heff_drop(v_field_2427);
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    heff_drop(v_x_2412);
                    heff_drop(v_x_2416);
                    heff_drop(v_field_2420);
                    heff_drop(v_field_2421);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT3){{heff_nomatch(v_x31_2415)}});
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_x3_2414)}});
            }
          } else {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            heff_drop(v_field_2410);
            heff_drop(v_field_2411);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str3), 2)) {
          HeffT3 v_t_2449 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_242, v_z_243));
          {
            V v_field_2451 = v_t_2449.f[1];
            V v_field_2452 = v_t_2449.f[2];
            int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
            if ((v_tag_2450 == ((int64_t)0ULL))) {
              V v_x_2453 = v_field_2451;
              V v_j_2454 = v_field_2452;
              HeffT3 v_t_2455 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_take_field(v_k_240, 1), v_z_242, v_j_2454));
              {
                V v_field_2457 = v_t_2455.f[1];
                V v_field_2458 = v_t_2455.f[2];
                int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
                if ((v_tag_2456 == ((int64_t)0ULL))) {
                  V v_x_2459 = v_field_2457;
                  V v_j_2460 = v_field_2458;
                  HeffT3 v_t_2461 = ({ V a_0 = heff_get_n(v_k_240, 0, 2); V a_1 = v_z_242; V a_2 = v_j_2460; HeffT3 r_ = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(a_0, a_1, a_2)); heff_drop(v_z_242); r_; });
                  {
                    V v_field_2463 = v_t_2461.f[1];
                    V v_field_2464 = v_t_2461.f[2];
                    int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                    if ((v_tag_2462 == ((int64_t)0ULL))) {
                      V v_x_2465 = v_field_2463;
                      V v_j_2466 = v_field_2464;
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2453, v_x_2459, v_x_2465}), v_j_2466}});
                    } else {
                      heff_drop(v_x_2453);
                      heff_drop(v_x_2459);
                      heff_drop(v_field_2463);
                      heff_drop(v_field_2464);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_z_242);
                  heff_drop(v_x_2453);
                  heff_drop(v_field_2457);
                  heff_drop(v_field_2458);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              heff_drop(v_field_2451);
              heff_drop(v_field_2452);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str4), 2)) {
            V v_t_2467 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeFields_clo), 1, (V[]){v_k_240}));
            HeffT3 v_t_2468 = ({ V a_0 = v_t_2467; V a_1 = v_z_242; V a_2 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(a_0, a_1, a_2)); heff_drop(v_z_242); r_; });
            {
              V v_field_2470 = v_t_2468.f[1];
              V v_field_2471 = v_t_2468.f[2];
              int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
              if ((v_tag_2469 == ((int64_t)0ULL))) {
                V v_x_2472 = v_field_2470;
                V v_j_2473 = v_field_2471;
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SSum, 1, (V[]){v_x_2472}), v_j_2473}});
              } else {
                heff_drop(v_field_2470);
                heff_drop(v_field_2471);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str5), 2)) {
              V v_x3_2474 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
              switch (heff_tag_of(v_x3_2474)) {
              case TAG_Nothing: {
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2475 = heff_field(v_x3_2474, 0);
                V v_ru_24x3_2474_24Just = heff_take_reuse_n(v_x3_2474, 1ULL, 1);
                switch (heff_tag_of(v_x31_2475)) {
                case TAG_MkPair: {
                  V v_x_2476 = heff_field(v_x31_2475, 0);
                  V v_j_2477 = heff_field(v_x31_2475, 1);
                  heff_take_n(v_x31_2475, 3ULL, 2);
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_2474_24Just, TAG_SIsTy, 1, (V[]){v_x_2476}), v_j_2477}});
                }
                default: return ((HeffT3){{heff_nomatch(v_x31_2475)}});
                }
              }
              default: return ((HeffT3){{heff_nomatch(v_x3_2474)}});
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str6), 2)) {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SPrimInt), v_z_243}});
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str7), 2)) {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_z_242);
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SPrimFloat), v_z_243}});
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str8), 2)) {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SPrimString), v_z_243}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str9), 2)) {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_SPrimRune), v_z_243}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str10), 2)) {
                        V v_x3_2478 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_2478)) {
                        case TAG_Nothing: {
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_2479 = heff_field(v_x3_2478, 0);
                          V v_ru_24x3_2478_24Just = heff_take_reuse_n(v_x3_2478, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2479)) {
                          case TAG_MkPair: {
                            V v_x_2480 = heff_field(v_x31_2479, 0);
                            V v_j_2481 = heff_field(v_x31_2479, 1);
                            heff_take_n(v_x31_2479, 3ULL, 2);
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x3_2478_24Just, TAG_SPrimArray, 1, (V[]){v_x_2480}), v_j_2481}});
                          }
                          default: return ((HeffT3){{heff_nomatch(v_x31_2479)}});
                          }
                        }
                        default: return ((HeffT3){{heff_nomatch(v_x3_2478)}});
                        }
                      } else {
                        heff_drop_rec(v_k_240, 2);
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24cpr_str11), 2)) {
                          HeffT3 v_t_2482 = ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
                          {
                            V v_field_2484 = v_t_2482.f[1];
                            V v_field_2485 = v_t_2482.f[2];
                            int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
                            if ((v_tag_2483 == ((int64_t)0ULL))) {
                              V v_x_2486 = v_field_2484;
                              V v_j_2487 = v_field_2485;
                              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_SFixed, 1, (V[]){v_x_2486}), v_j_2487}});
                            } else {
                              heff_drop(v_field_2484);
                              heff_drop(v_field_2485);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam0, 2, 0};
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edk_lam1, 2, 0};

static V g_heff_2ebuild_2eserial_2edk_val;
static HEFF_ONCE g_heff_2ebuild_2eserial_2edk_st;
static V g_heff_2ebuild_2eserial_2edk_init(void) {
  return heff_rec_n(2, shape_el__ty, (V[]){((V)&g_heff_2ebuild_2eserial_2edk_lam0_clo), ((V)&g_heff_2ebuild_2eserial_2edk_lam1_clo)});
}
V g_heff_2ebuild_2eserial_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eserial_2edk_st)) return g_heff_2ebuild_2eserial_2edk_val;
  return heff_global(&g_heff_2ebuild_2eserial_2edk_val, &g_heff_2ebuild_2eserial_2edk_st, g_heff_2ebuild_2eserial_2edk_init);
}
V g_heff_2ebuild_2eserial_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_k_242 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      V v_j_248 = v_field_246;
      return ({ V a_0 = v_k_242; V a_1 = v_x_247; V a_2 = v_s_240; V a_3 = v_j_248; V r_ = (g_heff_2ebuild_2eserial_2etermOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_247); r_; });
    } else {
      heff_drop(v_s_240);
      heff_drop(v_k_242);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2edk_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_i_2410 = args[1];
  V v_k_2411 = heff_dup(g_heff_2ebuild_2eserial_2edk_get());
  HeffT3 v_t_2412 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_249, v_i_2410));
  {
    V v_field_2414 = v_t_2412.f[1];
    V v_field_2415 = v_t_2412.f[2];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2414;
      V v_j_2417 = v_field_2415;
      return ({ V a_0 = v_k_2411; V a_1 = v_x_2416; V a_2 = v_s_249; V a_3 = v_j_2417; V r_ = (g_heff_2ebuild_2eserial_2etypeOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_2416); r_; });
    } else {
      heff_drop(v_s_249);
      heff_drop(v_k_2411);
      heff_drop(v_field_2414);
      heff_drop(v_field_2415);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1, 1, "n");

HeffT3 g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str0), 2)) {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        HeffT3 v_t_249 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_247, v_z_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            V v_j_2414 = v_field_2412;
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Just, 1, (V[]){v_x_2413}), v_j_2414}});
          } else {
            heff_drop(v_field_2411);
            heff_drop(v_field_2412);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr_str1), 2)) {
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nothing), v_z_242}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    }
  }
}
Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry, 3, 0};

V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_24cpr(v_x2_240, v_z_241, v_z_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_field_245, v_field_246})});
    } else {
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}