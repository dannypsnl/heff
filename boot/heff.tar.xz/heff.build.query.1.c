// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_c 317
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_detail 611917692
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_expecting 1746726246
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_selection 2055983820
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_type_5f 312202367
static uint32_t shape_c__name__span[] = {LBL_c, LBL_name, LBL_span};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_label__detail[] = {LBL_label, LBL_detail};
static uint32_t shape_name__kind__span__selection__children[] = {LBL_name, LBL_kind, LBL_span, LBL_selection, LBL_children};
static uint32_t shape_out__code__expecting[] = {LBL_out, LBL_code, LBL_expecting};
static uint32_t shape_path__source__span[] = {LBL_path, LBL_source, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name[] = {LBL_target, LBL_name};
static uint32_t shape_text__span[] = {LBL_text, LBL_span};
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo;
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V, V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo;
V g_heff_2ebuild_2equery_2ecompletionDetail(V, V);
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edeclSites(V, V);
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edeclSites_clo;
V g_heff_2ebuild_2equery_2edefinesGo(V, V, V, V);
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinesGo_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
V g_heff_2ebuild_2equery_2eeqTarget(V, V);
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eeqTarget_clo;
V g_heff_2ebuild_2equery_2eexpectedIn(V, V, V);
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedIn_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2ekindOf(V, V);
V g_heff_2ebuild_2equery_2ekindOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ekindOf_clo;
HeffT2 g_heff_2ebuild_2equery_2elastDot_24cpr(V, V);
V g_heff_2ebuild_2equery_2elastPart(V, V);
V g_heff_2ebuild_2equery_2elastPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elastPart_clo;
V g_heff_2ebuild_2equery_2elocalDefinition(V, V);
V g_heff_2ebuild_2equery_2elocalDefinition_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDefinition_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ebuild_2equery_2emoreIn(V, V, V);
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2emoreIn_clo;
V g_heff_2ebuild_2equery_2enameClass(V);
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameClass_clo;
V g_heff_2ebuild_2equery_2enameInGo(V, V, V, V);
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameInGo_clo;
V g_heff_2ebuild_2equery_2enubByStart(V);
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_clo;
V g_heff_2ebuild_2equery_2enubByStart_24dps(V, V);
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo;
HeffT2 g_heff_2ebuild_2equery_2eownNameOf_24cpr(V, V);
HeffT2 g_heff_2ebuild_2equery_2esiteFound_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2espacesBefore(V, V);
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesBefore_clo;
V g_heff_2ebuild_2equery_2espacesFrom(V, V);
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesFrom_clo;
V g_heff_2ebuild_2equery_2estartsStatement(V, V, V);
V g_heff_2ebuild_2equery_2estartsStatement_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2estartsStatement_clo;
V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V, V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo;
V g_heff_2ebuild_2equery_2etypedFrom(V, V);
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypedFrom_clo;
V g_heff_2ebuild_2equery_2ewordAt(V, V, V);
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordAt_clo;
V g_heff_2ebuild_2equery_2ewordsIn(V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsIn_clo;
V g_heff_2ebuild_2equery_2ewordsOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsOf_clo;
V g_heff_2eelab_2eglobals_2eplacesSaid(V);
V g_heff_2eelab_2eglobals_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eplacesSaid_clo;
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_list_2eascending_24s1147438953x64854941(V, V, V);
V g_list_2eascending_24s1147438953x64854941_entry(V self, V *a);
extern Clo g_list_2eascending_24s1147438953x64854941_clo;
V g_list_2eascending_24s1492869513x628919935(V, V, V, V, V);
V g_list_2eascending_24s1492869513x628919935_entry(V self, V *a);
extern Clo g_list_2eascending_24s1492869513x628919935_clo;
V g_list_2edescending_24s1092102222x1336838254(V, V, V);
V g_list_2edescending_24s1092102222x1336838254_entry(V self, V *a);
extern Clo g_list_2edescending_24s1092102222x1336838254_clo;
V g_list_2edescending_24s2023694772x1287719119(V, V, V, V, V);
V g_list_2edescending_24s2023694772x1287719119_entry(V self, V *a);
extern Clo g_list_2edescending_24s2023694772x1287719119_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1702704581x1717241719_24cpr(V);
HeffT2 g_list_2efind_24s845102114x2128838930_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f2080327479x1330764413(V, V, V, V, V, V, V);
V g_list_2efoldl_24f2080327479x1330764413_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2080327479x1330764413_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1113296953x161795409(V, V);
V g_list_2efoldl_24s1113296953x161795409_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1113296953x161795409_clo;
V g_list_2efoldl_24s1179255243x525343925(V, V);
V g_list_2efoldl_24s1179255243x525343925_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1179255243x525343925_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1516272141x1201056882(V, V, V);
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1516272141x1201056882_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2efoldl_24s673493459x989016999(V, V, V);
V g_list_2efoldl_24s673493459x989016999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s673493459x989016999_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1950790755x1251737354(V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_clo;
V g_list_2ekeepIf_24s2015972532x1874881274(V, V);
V g_list_2ekeepIf_24s2015972532x1874881274_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2015972532x1874881274_clo;
V g_list_2ekeepIf_24s257286374x378693326(V, V);
V g_list_2ekeepIf_24s257286374x378693326_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s257286374x378693326_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1651437062x1594169608(V, V);
V g_list_2emap_24f1651437062x1594169608_entry(V self, V *a);
extern Clo g_list_2emap_24f1651437062x1594169608_clo;
V g_list_2emap_24f530523215x314966509(V, V, V, V, V, V, V);
V g_list_2emap_24f530523215x314966509_entry(V self, V *a);
extern Clo g_list_2emap_24f530523215x314966509_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1996604328x2084368959(V);
V g_list_2emap_24s1996604328x2084368959_entry(V self, V *a);
extern Clo g_list_2emap_24s1996604328x2084368959_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s111750985x43270407(V, V);
V g_list_2emergeRuns_24s111750985x43270407_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s111750985x43270407_clo;
V g_list_2emergeRuns_24s1455886971x1742651599(V, V, V, V);
V g_list_2emergeRuns_24s1455886971x1742651599_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1455886971x1742651599_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_rest_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2enameInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameInGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2enameInGo(V v_src_240, V v_x_241, V v_sp_242, V v_from_243) {
top: ;
  V v_j_244 = heff_strFind_lent(v_x_241, v_src_240, v_from_243, 4);
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    return heff_dup(v_sp_242);
  } else {
    V v_t_245 = heff_intAdd_lent(v_j_244, heff_strLength_lent(v_x_241, 0), 2);
    if (heff_intLe_c(v_t_245, heff_dup(heff_rfield(v_sp_242, 1)))) {
      V v_t_246 = (g_heff_2ebuild_2equery_2ewordAt(v_src_240, heff_dup(v_j_244), v_x_241));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_e_247 = heff_intAdd_lent(v_j_244, heff_strLength_lent(v_x_241, 0), 2);
        return heff_rec_n(2, shape_start__end, (V[]){v_j_244, v_e_247});
      } else {
        heff_drop(v_t_246);
        V t_0 = v_src_240;
        V t_1 = v_x_241;
        V t_2 = v_sp_242;
        V t_3 = heff_intAdd(v_j_244, MK_INT(1LL));
        v_src_240 = t_0;
        v_x_241 = t_1;
        v_sp_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_j_244);
      return heff_dup(v_sp_242);
    }
  }
}
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2equery_2enameInGo(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2equery_2enubByStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_entry, 1, 0};

V g_heff_2ebuild_2equery_2enubByStart(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s2015972532x1874881274(v_x_241, v_xs_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
    V v_u_245 = (g_heff_2ebuild_2equery_2enubByStart_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart(a[0]);
}
Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2enubByStart_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s2015972532x1874881274(v_x_242, v_xs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2enubByStart_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str2, 1, ":");
Clo g_heff_2ebuild_2equery_2eatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eatLine_entry, 2, 0};

V g_heff_2ebuild_2equery_2eatLine(V v_src_240, V v_sp_241) {
top: ;
  V v_j_242 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2eatLine_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_243;
  if (heff_intLt_c_lent(v_j_242, MK_INT(0LL), 2)) {
    heff_drop(v_j_242);
    v_t_243 = NTAG(TAG_Nothing);
  } else {
    v_t_243 = heff_tag_n(TAG_Just, 1, (V[]){v_j_242});
  }
  HeffT3 v_t_244 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_240, heff_rfield(v_sp_241, 0), MK_INT(0LL), MK_INT(0LL), v_t_243));
  {
    V v_field_245 = v_t_244.f[0];
    heff_drop(v_t_244.f[1]);
    heff_drop(v_t_244.f[2]);
    V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2eatLine_str1), v_src_240, MK_INT(0LL), 5);
    V v_t_249;
    if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
      heff_drop(v_j_248);
      v_t_249 = NTAG(TAG_Nothing);
    } else {
      v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
    }
    HeffT3 v_t_2410 = ({ V a_0 = v_src_240; V b_1 = heff_get_n(v_sp_241, 0, 2); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_249; HeffT3 r_ = (g_heff_2elsp_2erender_2elineColAt_24cpr(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    {
      V v_field_2413 = v_t_2410.f[2];
      heff_drop(v_t_2410.f[0]);
      heff_drop(v_t_2410.f[1]);
      V v_t_2414 = heff_intShow(heff_intAdd(v_field_245, MK_INT(1LL)));
      V v_t_2415 = heff_intShow(heff_intAdd(v_field_2413, MK_INT(1LL)));
      return heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2equery_2eatLine_str2)), v_t_2415);
    }
  }
}
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eatLine(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2elastPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elastPart_entry, 2, 0};

V g_heff_2ebuild_2equery_2elastPart(V v_x_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 <= ((int64_t)0ULL))) {
    return heff_dup(v_x_240);
  } else {
    V v_t_242 = heff_strByteAt_lent(v_x_240, heff_box_word((v_i_241 - ((int64_t)1ULL))), 2);
    if ((heff_unbox_word(v_t_242) == ((int64_t)46ULL))) {
      return heff_strSlice_lent(v_x_240, heff_box_word(v_i_241), heff_strLength_lent(v_x_240, 0), 6);
    } else {
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2elastPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elastPart(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2equery_2einfoAt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V v_c_240, V v_off_241) {
top: ;
  V v_source_242 = heff_take_field(v_c_240, 3);
  V v_top_243 = heff_get_n(v_c_240, 5, 14);
  V v_x2_2414 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2equery_2einfoAt_24cpr_lam0, 1, 2, (V[]){v_off_241, v_source_242}); V a_1 = heff_get_n(v_top_243, 7, 10); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2427;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_x1_2427 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24Cons = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_xs_2416)) {
    case TAG_Nil: {
      V v_t_2417 = heff_tag_re_n(v_ru_24x2_2414_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2415, NTAG(TAG_Nil)});
      v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      V v_y_2418 = heff_field(v_xs_2416, 0);
      V v_ys_2419 = heff_field(v_xs_2416, 1);
      V v_ru_24xs_2416_24Cons = heff_take_reuse_n(v_xs_2416, 3ULL, 2);
      V v_t_2420 = heff_get_n(heff_dup(heff_rfield(v_x_2415, 0)), 1, 2);
      V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_x_2415, 0)), 0, 2);
      V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_y_2418, 0)), 1, 2);
      V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_y_2418, 0)), 0, 2);
      if (heff_intLe_c(heff_intSub(v_t_2420, v_t_2421), heff_intSub(v_t_2422, v_t_2423))) {
        V v_t_2424 = heff_tag_re_n(v_ru_24x2_2414_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2415, NTAG(TAG_Nil)});
        v_t_2426 = (g_list_2eascending_24s1147438953x64854941(heff_dup(v_y_2418), heff_tag_re_n(v_ru_24xs_2416_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2418, v_t_2424}), v_ys_2419));
      } else {
        V v_t_2425 = heff_tag_re_n(v_ru_24x2_2414_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_2415, NTAG(TAG_Nil)});
        v_t_2426 = (g_list_2edescending_24s1092102222x1336838254(heff_dup(v_y_2418), heff_tag_re_n(v_ru_24xs_2416_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2418, v_t_2425}), v_ys_2419));
      }
      break;
    }
    default: heff_nomatch(v_xs_2416);
    }
    v_x1_2427 = (g_list_2emergeRuns_24s111750985x43270407(NTAG(TAG_Nil), v_t_2426));
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_2428}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2427)}});
  }
}
V g_heff_2ebuild_2equery_2einfoAt_24cpr_lam0(V self, V *args) {
  V v_i_244 = args[0];
  V v_off_241 = heff_env(self)[0];
  V v_source_242 = heff_env(self)[1];
  V v_span_245 = heff_take_field(v_i_244, 0);
  V v_name_246 = heff_take_field(v_i_244, 1);
  V v_key_247 = heff_get_n(v_i_244, 2, 5);
  V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_span_245, 1)), heff_dup(heff_rfield(v_span_245, 0)));
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_name_246, 0)) + ((int64_t)1ULL));
  if (heff_intLe_c(v_t_248, heff_box_word(v_t_249))) {
    if (heff_intLe_c(heff_dup(heff_rfield(v_span_245, 0)), heff_dup(v_off_241))) {
      heff_clo_take(self, 2);
      if (heff_intLe_c(v_off_241, heff_dup(heff_rfield(v_span_245, 1)))) {
        V v_t_2410 = v_key_247;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Nothing: {
          heff_drop(v_source_242);
          heff_drop_rec(v_span_245, 2);
          heff_drop(v_name_246);
          return NTAG(TAG_True);
        }
        case TAG_Just: {
          heff_take_n(v_t_2410, 0ULL, 1);
          V v_needle_2412 = ({ V a_0 = v_name_246; V a_1 = heff_strLength_lent(v_name_246, 0); V r_ = (g_heff_2ebuild_2equery_2elastPart(a_0, a_1)); heff_drop(v_name_246); r_; });
          V v_t_2413 = heff_strSlice(v_source_242, heff_take_field(v_span_245, 0), heff_get_n(v_span_245, 1, 2));
          V v_ret_24bool = heff_bool(heff_intLe_c(MK_INT(0LL), heff_strFind_lent(v_needle_2412, v_t_2413, MK_INT(0LL), 4)));
          heff_drop(v_needle_2412);
          heff_drop(v_t_2413);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_t_2410);
        }
      } else {
        heff_drop(v_source_242);
        heff_drop_rec(v_span_245, 2);
        heff_drop(v_name_246);
        heff_drop(v_key_247);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(self);
      heff_drop_rec(v_span_245, 2);
      heff_drop(v_name_246);
      heff_drop(v_key_247);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(self);
    heff_drop_rec(v_span_245, 2);
    heff_drop(v_name_246);
    heff_drop(v_key_247);
    return NTAG(TAG_False);
  }
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str1, 13, "` is defined ");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str7, 0, "");
V g_heff_2ebuild_2equery_2ecompletionDetail_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionDetail_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionDetail(V v_c_240, V v_x_241) {
top: ;
  V v_top_242 = heff_take_field(v_c_240, 5);
  V v_module_243 = heff_get_n(v_c_240, 0, 14);
  HeffT3 v_t_244 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(heff_dup(heff_rfield(v_top_242, 0)), heff_dup(v_x_241)));
  {
    V v_field_246 = v_t_244.f[1];
    V v_field_247 = v_t_244.f[2];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_module_243);
      heff_drop(v_field_247);
      V v_ks_248 = v_field_246;
      V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2ecompletionDetail_lam0, 1, 1, (V[]){v_top_242}), v_ks_248));
      V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eelab_2eglobals_2eplacesSaid(a_0)); heff_drop(v_t_2415); r_; });
      V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str0), v_x_241), ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str1));
      return heff_strAppend(v_t_2417, v_t_2416);
    } else {
      if ((v_tag_245 == ((int64_t)1ULL))) {
        heff_drop(v_field_246);
        heff_drop(v_field_247);
        V v_g_2418 = heff_dup(heff_rfield(v_top_242, 0));
        V v_entries_2419 = heff_take_field(v_g_2418, 1);
        V v_aliases_2420 = heff_get_n(v_g_2418, 2, 8);
        V v_k_2421 = heff_strAppend(heff_strAppend(v_module_243, ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str2)), v_x_241);
        HeffT2 v_t_2422 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2419, v_k_2421));
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            heff_drop(v_entries_2419);
            heff_drop(v_aliases_2420);
            heff_drop(v_k_2421);
            V v_e_2425 = v_field_2424;
            V v_t_2426 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2425, 3, 4)));
            HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(heff_get_n(v_top_242, 0, 10), v_t_2426);
          } else {
            heff_drop(v_field_2424);
            HeffT2 v_t_2427 = ({ V a_0 = v_aliases_2420; V a_1 = v_k_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2420); heff_drop(v_k_2421); r_; });
            {
              V v_field_2429 = v_t_2427.f[1];
              int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
              if ((v_tag_2428 == ((int64_t)0ULL))) {
                V v_k2_2430 = v_field_2429;
                HeffT2 v_t_2431 = ({ V a_0 = v_entries_2419; V a_1 = v_k2_2430; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2419); heff_drop(v_k2_2430); r_; });
                {
                  V v_field_2433 = v_t_2431.f[1];
                  int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
                  if ((v_tag_2432 == ((int64_t)0ULL))) {
                    V v_e_2434 = v_field_2433;
                    V v_t_2435 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2434, 3, 4)));
                    HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(heff_get_n(v_top_242, 0, 10), v_t_2435);
                  } else {
                    heff_drop_rec(v_top_242, 10);
                    heff_drop(v_field_2433);
                    return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str3);
                  }
                }
              } else {
                heff_drop_rec(v_top_242, 10);
                heff_drop(v_entries_2419);
                heff_drop(v_field_2429);
                return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str4);
              }
            }
          }
        }
      } else {
        if ((v_tag_245 == ((int64_t)2ULL))) {
          heff_drop(v_x_241);
          heff_drop(v_module_243);
          V v_x_2436 = v_field_246;
          heff_drop(v_x_2436);
          V v_e_2437 = v_field_247;
          V v_t_2438 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2437, 3, 4)));
          HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(heff_get_n(v_top_242, 0, 10), v_t_2438);
        } else {
          heff_drop(v_field_246);
          heff_drop(v_field_247);
          V v_g_2439 = heff_dup(heff_rfield(v_top_242, 0));
          V v_entries_2440 = heff_take_field(v_g_2439, 1);
          V v_aliases_2441 = heff_get_n(v_g_2439, 2, 8);
          V v_k_2442 = heff_strAppend(heff_strAppend(v_module_243, ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str5)), v_x_241);
          HeffT2 v_t_2443 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2440, v_k_2442));
          {
            V v_field_2445 = v_t_2443.f[1];
            int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
            if ((v_tag_2444 == ((int64_t)0ULL))) {
              heff_drop(v_entries_2440);
              heff_drop(v_aliases_2441);
              heff_drop(v_k_2442);
              V v_e_2446 = v_field_2445;
              V v_t_2447 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2446, 3, 4)));
              HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(heff_get_n(v_top_242, 0, 10), v_t_2447);
            } else {
              heff_drop(v_field_2445);
              HeffT2 v_t_2448 = ({ V a_0 = v_aliases_2441; V a_1 = v_k_2442; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2441); heff_drop(v_k_2442); r_; });
              {
                V v_field_2450 = v_t_2448.f[1];
                int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
                if ((v_tag_2449 == ((int64_t)0ULL))) {
                  V v_k2_2451 = v_field_2450;
                  HeffT2 v_t_2452 = ({ V a_0 = v_entries_2440; V a_1 = v_k2_2451; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2440); heff_drop(v_k2_2451); r_; });
                  {
                    V v_field_2454 = v_t_2452.f[1];
                    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
                    if ((v_tag_2453 == ((int64_t)0ULL))) {
                      V v_e_2455 = v_field_2454;
                      V v_t_2456 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2455, 3, 4)));
                      HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(heff_get_n(v_top_242, 0, 10), v_t_2456);
                    } else {
                      heff_drop_rec(v_top_242, 10);
                      heff_drop(v_field_2454);
                      return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str6);
                    }
                  }
                } else {
                  heff_drop_rec(v_top_242, 10);
                  heff_drop(v_entries_2440);
                  heff_drop(v_field_2450);
                  return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str7);
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionDetail(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2ecompletionDetail_lam0(V self, V *args) {
  V v_k_249 = args[0];
  V v_top_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_get_n(heff_get_n(v_top_242, 0, 10), 5, 8);
  HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_k_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_k_249);
      V v_place_2414 = v_field_2413;
      return v_place_2414;
    } else {
      heff_drop(v_field_2413);
      return v_k_249;
    }
  }
}
Clo g_heff_2ebuild_2equery_2estartsStatement_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2estartsStatement_entry, 3, 0};

V g_heff_2ebuild_2equery_2estartsStatement(V v_src_240, V v_i_241, V v_n_242) {
top: ;
  if ((heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1) && (heff_unbox_word(heff_strByteAt_lent(v_src_240, heff_intSub_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)32ULL)))) {
    V t_0 = v_src_240;
    V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
    V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    goto top;
  } else {
    V v_ret_24bool = heff_bool((heff_intLt_c_lent(MK_INT(0LL), v_n_242, 1) && (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2) || (heff_unbox_word(heff_strByteAt_lent(v_src_240, heff_intSub_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)10ULL)))));
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return v_ret_24bool;
  }
}
V g_heff_2ebuild_2equery_2estartsStatement_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2estartsStatement(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str0, 7, "abandon");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str1, 7, "abandon");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str2, 50, "a hole: checks at any small type, abandons the run");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str3, 4, "with");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str4, 4, "with");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str5, 58, "a statement: `with e as x do`, the block the `with`'s body");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str8, 1, ".");
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionsAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionsAt(V v_c_240, V v_offset_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_243 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_242, heff_dup(v_offset_241));
  V v_t_244 = heff_strSlice(((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str0), MK_INT(0LL), heff_strLength_lent(v_typed_243, 0));
  V v_t_245;
  if (heff_strEq_c(v_t_244, v_typed_243)) {
    v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_label__detail, (V[]){((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str1), ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str2)}), NTAG(TAG_Nil)});
  } else {
    v_t_245 = NTAG(TAG_Nil);
  }
  V v_src_246 = heff_dup(heff_rfield(v_c_240, 3));
  V v_from_247 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_t_248 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_249 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_248, heff_dup(v_offset_241));
  V v_t_2410 = ({ V a_0 = v_src_246; V a_1 = v_from_247; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2equery_2estartsStatement(a_0, a_1, a_2)); heff_drop(v_src_246); r_; });
  V v_t_2411;
  if (((heff_dup(v_t_2410) == NTAG(TAG_True)) && heff_strEq_c_lent(heff_strSlice(((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str3), MK_INT(0LL), heff_strLength_lent(v_typed_249, 0)), v_typed_249, 1))) {
    heff_drop(v_typed_249);
    heff_drop(v_t_2410);
    v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_label__detail, (V[]){((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str4), ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str5)}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_typed_249);
    heff_drop(v_t_2410);
    v_t_2411 = NTAG(TAG_Nil);
  }
  V v_t_2412 = (g_prelude_2e_2b_2b(v_t_245, v_t_2411));
  V v_t_2413 = (g_list_2emap_24s467798769x1763085075(heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
  V v_t_2415 = ({ V b_0 = heff_get_n(v_t_2414, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2416 = (g_list_2emap_24s1415906091x1371825187(v_t_2415));
  V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
  V v_t_2418 = ({ V b_0 = heff_get_n(v_t_2417, 4, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2419 = (g_list_2emap_24s1415906091x1371825187(v_t_2418));
  V v_g_2420 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
  V v_entries_2421 = heff_take_field(v_g_2420, 1);
  V v_order_2422 = heff_get_n(v_g_2420, 0, 8);
  V v_t_2429 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam0, 2, 1, (V[]){v_entries_2421}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_2422; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_order_2422); r_; });
  V v_t_2430 = (g_list_2emap_24s1996604328x2084368959(v_t_2429));
  V v_t_2431 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2430));
  V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2431));
  V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2432));
  V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2433));
  V v_t_2435 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2434));
  V v_t_2453 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam1, 1, 2, (V[]){v_c_240, v_offset_241}), v_t_2435));
  V v_t_2454 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2453));
  V v_x2_2455 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2454));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_xs_2457 = heff_field(v_x2_2455, 1);
    V v_ru_24x2_2455_24Cons = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
    V v_lit_2458 = MK_INT(0LL);
    V v_lit_2459 = MK_INT(0LL);
    V v_x_2460 = v_x_2456;
    V v_x3_2461 = v_xs_2457;
    V v_t_2468;
    switch (heff_tag_of(v_x3_2461)) {
    case TAG_Nil: {
      heff_drop(v_lit_2458);
      heff_drop(v_lit_2459);
      V v_t_2462 = heff_tag_at_n(v_ru_24x2_2455_24Cons, TAG_Cons, 2, (V[]){v_x_2460, NTAG(TAG_Nil)});
      v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      V v_y_2463 = heff_field(v_x3_2461, 0);
      V v_ys_2464 = heff_field(v_x3_2461, 1);
      V v_ru_24x3_2461_24Cons = heff_take_reuse_n(v_x3_2461, 3ULL, 2);
      V v_a_2465 = heff_strCompare(heff_dup(heff_rfield(v_x_2460, 0)), heff_dup(heff_rfield(v_y_2463, 0)));
      if ((heff_intLt_c_lent(v_a_2465, v_lit_2458, 0) || heff_intEq_c_lent(v_a_2465, v_lit_2459, 0))) {
        heff_drop(v_a_2465);
        V v_t_2466 = heff_tag_at_n(v_ru_24x2_2455_24Cons, TAG_Cons, 2, (V[]){v_x_2460, NTAG(TAG_Nil)});
        v_t_2468 = ({ V a_0 = v_lit_2458; V a_1 = v_lit_2459; V a_2 = heff_dup(v_y_2463); V a_3 = heff_tag_re_n(v_ru_24x3_2461_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2463, v_t_2466}); V a_4 = v_ys_2464; V r_ = (g_list_2eascending_24s1492869513x628919935(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_2458); heff_drop(v_lit_2459); r_; });
      } else {
        heff_drop(v_a_2465);
        V v_t_2467 = heff_tag_at_n(v_ru_24x2_2455_24Cons, TAG_Cons, 2, (V[]){v_x_2460, NTAG(TAG_Nil)});
        v_t_2468 = ({ V a_0 = v_lit_2458; V a_1 = v_lit_2459; V a_2 = heff_dup(v_y_2463); V a_3 = heff_tag_re_n(v_ru_24x3_2461_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_2463, v_t_2467}); V a_4 = v_ys_2464; V r_ = (g_list_2edescending_24s2023694772x1287719119(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_2458); heff_drop(v_lit_2459); r_; });
      }
      break;
    }
    default: heff_nomatch(v_x3_2461);
    }
    return (g_list_2emergeRuns_24s1455886971x1742651599(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2468));
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionsAt(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args) {
  V v_acc_2423 = args[0];
  V v_k_2424 = args[1];
  V v_entries_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2425 = ({ V a_0 = v_entries_2421; V a_1 = v_k_2424; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2421); r_; });
  {
    V v_field_2427 = v_t_2425.f[1];
    int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
    if ((v_tag_2426 == ((int64_t)0ULL))) {
      V v_e_2428 = v_field_2427;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2424, v_e_2428}), v_acc_2423});
    } else {
      heff_drop(v_k_2424);
      heff_drop(v_field_2427);
      return v_acc_2423;
    }
  }
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args) {
  V v_x_2436 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_offset_241 = heff_env(self)[1];
  V v_c_2437 = heff_dup(v_c_240);
  V v_t_2438 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_2439 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2438, heff_dup(v_offset_241));
  V v_t_2440 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  heff_clo_take(self, 2);
  V v_typed_2441 = heff_strSlice(heff_get_n(v_c_240, 3, 14), v_t_2440, v_offset_241);
  int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_typed_2441, 0)) - ((int64_t)1ULL));
  HeffT2 v_t_2443 = (g_heff_2ebuild_2equery_2elastDot_24cpr(v_typed_2441, heff_box_word(v_t_2442)));
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    V v_qualifier_2447;
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      V v_i_2446 = v_field_2445;
      v_qualifier_2447 = heff_strSlice(v_typed_2441, MK_INT(0LL), heff_intAdd(v_i_2446, MK_INT(1LL)));
    } else {
      heff_drop(v_typed_2441);
      heff_drop(v_field_2445);
      v_qualifier_2447 = ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str6);
    }
    V v_x_2448 = v_x_2436;
    V v_t_2449 = heff_strSlice_lent(v_x_2448, MK_INT(0LL), heff_strLength_lent(v_typed_2439, 0), 6);
    if ((heff_strEq_c_lent(v_t_2449, v_typed_2439, 0) && (heff_strEq_c_lent(v_qualifier_2447, ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str7), 2) ? !heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str8), v_x_2448, MK_INT(0LL), 5)) : 1))) {
      heff_drop(v_typed_2439);
      heff_drop(v_t_2449);
      V v_t_2450 = heff_strSlice_lent(v_x_2448, MK_INT(0LL), heff_strLength_lent(v_qualifier_2447, 0), 6);
      V v_t_2451;
      if (heff_strEq_c_lent(v_t_2450, v_qualifier_2447, 1)) {
        v_t_2451 = heff_strSlice(heff_dup(v_x_2448), heff_strLength(v_qualifier_2447), heff_strLength_lent(v_x_2448, 0));
      } else {
        heff_drop(v_qualifier_2447);
        v_t_2451 = heff_dup(v_x_2448);
      }
      V v_t_2452 = (g_heff_2ebuild_2equery_2ecompletionDetail(v_c_2437, v_x_2448));
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_label__detail, (V[]){v_t_2451, v_t_2452})});
    } else {
      heff_drop(v_c_2437);
      heff_drop(v_typed_2439);
      heff_drop(v_qualifier_2447);
      heff_drop(v_x_2448);
      heff_drop(v_t_2449);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2equery_2edefinesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinesGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2edefinesGo(V v_k_240, V v_c_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    V v_key_246 = heff_dup(heff_rfield(v_o_244, 1));
    V v_name_247 = heff_dup(heff_rfield(v_o_244, 0));
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_key_246);
      heff_drop(v_name_247);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x41_248 = heff_field(v_x4_243, 0);
      V v_sps_249 = heff_field(v_x4_243, 1);
      switch (heff_tag_of(v_x41_248)) {
      case TAG_MkPair: {
        V v_sp_2411 = heff_field(v_x41_248, 1);
        if (heff_strEq_c_lent(v_key_246, v_k_240, 1)) {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_c__name__span, (V[]){heff_dup(v_c_241), v_name_247, heff_dup(v_sp_2411)})});
        } else {
          heff_drop(v_name_247);
          V t_0 = v_k_240;
          V t_1 = v_c_241;
          V t_2 = v_os_245;
          V t_3 = v_sps_249;
          v_k_240 = t_0;
          v_c_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x41_248);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2equery_2edefinesGo(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2equery_2edefinitionAt_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2edefinitionAt_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2edefinitionAt_lam2(V self, V *args);
Clo g_heff_2ebuild_2equery_2edefinitionAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinitionAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2edefinitionAt(V v_program_240, V v_off_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    heff_drop(v_off_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 1ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(heff_dup(v_x_243), heff_dup(v_off_241)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_i_248 = v_field_247;
        V v_t_249 = heff_dup(heff_rfield(v_i_248, 2));
        switch (heff_tag_of(v_t_249)) {
        case TAG_Nothing: {
          heff_drop(v_program_240);
          heff_drop_cell(v_ru_24x1_242_24Cons, 2);
          heff_drop_rec(v_i_248, 5);
          HEFF_LAST return g_heff_2ebuild_2equery_2elocalDefinition(v_x_243, v_off_241);
        }
        case TAG_Just: {
          V v_k_2410 = heff_field(v_t_249, 0);
          V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
          heff_drop(v_off_241);
          heff_drop(v_x_243);
          V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
          V v_t_2414 = (g_list_2emap_24tok2(v_ru_24x1_242_24Cons, heff_clo_n(g_heff_2ebuild_2equery_2edefinitionAt_lam0, 1, 1, (V[]){heff_dup(v_k_2410)}), v_t_2411));
          V v_x1_2415 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2414));
          switch (heff_tag_of(v_x1_2415)) {
          case TAG_Nil: {
            heff_drop_rec(v_i_248, 5);
            heff_drop(v_k_2410);
            heff_drop_cell(v_ru_24t_249_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Cons: {
            V v_x_2416 = heff_field(v_x1_2415, 0);
            heff_take_n(v_x1_2415, 1ULL, 2);
            V v_i_2418 = v_i_248;
            V v_member_2419 = heff_take_field(v_i_2418, 3);
            V v_name_2420 = heff_get_n(v_i_2418, 1, 5);
            V v_k_2421 = v_k_2410;
            V v_d_2422 = v_x_2416;
            V v_c_2423 = heff_take_field(v_d_2422, 0);
            V v_span_2424 = heff_get_n(v_d_2422, 2, 3);
            V v_c_2425 = heff_dup(v_c_2423);
            V v_xs_2426 = heff_dup(heff_rfield(v_c_2425, 4));
            V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2426));
            V v_t_2431 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2equery_2edefinitionAt_lam1, 2, 1, (V[]){v_c_2425}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2427; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2427); r_; });
            HeffT2 v_t_2435 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2equery_2edefinitionAt_lam2, 1, 3, (V[]){v_member_2419, v_k_2421, heff_dup(v_name_2420)}); V a_1 = v_t_2431; HeffT2 r_ = (g_list_2efind_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2431); r_; });
            {
              V v_field_2437 = v_t_2435.f[1];
              int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
              V v_t_2440;
              if ((v_tag_2436 == ((int64_t)0ULL))) {
                heff_drop(v_name_2420);
                heff_drop(v_span_2424);
                V v_s_2438 = v_field_2437;
                v_t_2440 = heff_get_n(v_s_2438, 2, 3);
              } else {
                heff_drop(v_field_2437);
                V v_sp_2439 = v_span_2424;
                v_t_2440 = ({ V a_0 = heff_rfield(v_c_2423, 3); V a_1 = v_name_2420; V a_2 = v_sp_2439; V a_3 = heff_dup(heff_rfield(v_sp_2439, 0)); V r_ = (g_heff_2ebuild_2equery_2enameInGo(a_0, a_1, a_2, a_3)); heff_drop(v_name_2420); heff_drop_rec(v_sp_2439, 2); r_; });
              }
              V v_t_2441 = heff_rec_n(3, shape_path__source__span, (V[]){heff_take_field(v_c_2423, 1), heff_get_n(v_c_2423, 3, 14), v_t_2440});
              return heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){v_t_2441});
            }
          }
          default: return heff_nomatch(v_x1_2415);
          }
        }
        default: return heff_nomatch(v_t_249);
        }
      } else {
        heff_drop(v_program_240);
        heff_drop_cell(v_ru_24x1_242_24Cons, 2);
        heff_drop(v_field_247);
        HEFF_LAST return g_heff_2ebuild_2equery_2elocalDefinition(v_x_243, v_off_241);
      }
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edefinitionAt(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2edefinitionAt_lam0(V self, V *args) {
  V v_c2_2412 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c2_2412, 5)), 6, 10);
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_2410; V a_1 = v_c2_2412; V b_2 = heff_dup(heff_rfield(v_c2_2412, 7)); V a_3 = v_t_2413; V r_ = (g_heff_2ebuild_2equery_2edefinesGo(a_0, a_1, b_2, a_3)); heff_drop(v_k_2410); heff_drop_rec(v_c2_2412, 14); heff_drop(b_2); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2equery_2edefinitionAt_lam1(V self, V *args) {
  V v_acc_2428 = args[0];
  V v_x_2429 = args[1];
  V v_c_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = (g_heff_2ebuild_2equery_2edeclSites(v_c_2425, v_x_2429));
  return (g_prelude_2e_2b_2b(v_t_2430, v_acc_2428));
}
V g_heff_2ebuild_2equery_2edefinitionAt_lam2(V self, V *args) {
  V v_s_2432 = args[0];
  V v_member_2419 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  V v_name_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = v_member_2419;
  V v_t_2434;
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_t_2433);
    v_t_2434 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2421, heff_tag_n(TAG_Just, 1, (V[]){v_name_2420}), NTAG(TAG_Nothing)});
  } else {
    heff_drop(v_name_2420);
    heff_drop(v_t_2433);
    v_t_2434 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2421, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  }
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2432, 0, 3), v_t_2434));
}
V g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2esiteFound_24cpr(V v_program_240, V v_c_241, V v_off_242) {
top: ;
  V v_xs_243 = heff_dup(heff_rfield(v_c_241, 4));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
  V v_t_248 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_244); r_; });
  HeffT2 v_t_249 = ({ V a_0 = v_off_242; V a_1 = v_t_248; HeffT2 r_ = (g_list_2efind_24s845102114x2128838930_24cpr(a_0, a_1)); heff_drop(v_t_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_s_2412 = v_field_2411;
      V v_t_2413 = heff_get_n(v_s_2412, 0, 3);
      V v_t_2414 = heff_dup(heff_rfield(v_t_2413, 1));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        HeffT2 v_t_2415 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2413, 0)));
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_x_2418 = v_field_2417;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2413, v_x_2418})}});
          } else {
            heff_drop_rec(v_t_2413, 3);
            heff_drop(v_field_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Just: {
        V v_m_2419 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2413, v_m_2419})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2414)}});
      }
    } else {
      heff_drop(v_field_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_246));
  return (g_prelude_2e_2b_2b(v_t_247, v_acc_245));
}
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str2, 1, " ");
Clo g_heff_2ebuild_2equery_2ewordsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ewordsOf(V v_base_240, V v_line_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_line_241, 0), v_i_242, 1)) {
    heff_drop(v_i_242);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_line_241, v_i_242, 0)) == ((int64_t)32ULL))) {
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL)));
      V t_3 = v_acc_243;
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      V v_d_244 = heff_strLength_lent(v_line_241, 0);
      V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str0), v_line_241, v_i_242, 1);
      V v_t_246;
      if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
        heff_drop(v_j_245);
        v_t_246 = v_d_244;
      } else {
        heff_drop(v_d_244);
        v_t_246 = v_j_245;
      }
      V v_d_247 = heff_strLength_lent(v_line_241, 0);
      V v_j_248 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str1), v_line_241, v_i_242, 1);
      V v_t_249;
      if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
        heff_drop(v_j_248);
        v_t_249 = v_d_247;
      } else {
        heff_drop(v_d_247);
        v_t_249 = v_j_248;
      }
      V v_s_2410 = heff_intAdd_lent(v_base_240, v_i_242, 0);
      V v_d_2411 = heff_strLength_lent(v_line_241, 0);
      V v_j_2412 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str2), v_line_241, v_i_242, 1);
      V v_t_2413;
      if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
        heff_drop(v_j_2412);
        v_t_2413 = v_d_2411;
      } else {
        heff_drop(v_d_2411);
        v_t_2413 = v_j_2412;
      }
      V v_e_2414 = heff_intAdd_lent(v_base_240, v_t_2413, 2);
      V v_t_2415 = heff_rec_n(2, shape_text__span, (V[]){heff_strSlice_lent(v_line_241, v_i_242, v_t_249, 6), heff_rec_n(2, shape_start__end, (V[]){v_s_2410, v_e_2414})});
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = v_t_246;
      V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_acc_243});
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2equery_2ewordsOf(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2ewordsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsIn_entry, 6, 0};

V g_heff_2ebuild_2equery_2ewordsIn(V v_fits_240, V v_name_241, V v_src_242, V v_i_243, V v_to_244, V v_acc_245) {
top: ;
  V v_j_246 = heff_strFind_lent(v_name_241, v_src_242, v_i_243, 4);
  if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
    heff_drop(v_j_246);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  } else {
    V v_t_247 = heff_intAdd_lent(v_j_246, heff_strLength_lent(v_name_241, 0), 2);
    if (heff_intLe_c_lent(v_t_247, v_to_244, 1)) {
      V v_t_248 = (g_heff_2ebuild_2equery_2ewordAt(v_src_242, heff_dup(v_j_246), v_name_241));
      V v_t_2411;
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = heff_tr(heff_call(heff_dup(v_fits_240), 1, (V[]){heff_dup(v_j_246)}));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          V v_e_2410 = heff_intAdd_lent(v_j_246, heff_strLength_lent(v_name_241, 0), 2);
          v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_j_246), v_e_2410}), v_acc_245});
        } else {
          heff_drop(v_t_249);
          v_t_2411 = v_acc_245;
        }
      } else {
        heff_drop(v_t_248);
        v_t_2411 = v_acc_245;
      }
      V t_0 = v_fits_240;
      V t_1 = v_name_241;
      V t_2 = v_src_242;
      V t_3 = heff_intAdd(v_j_246, MK_INT(1LL));
      V t_4 = v_to_244;
      V t_5 = v_t_2411;
      v_fits_240 = t_0;
      v_name_241 = t_1;
      v_src_242 = t_2;
      v_i_243 = t_3;
      v_to_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      heff_drop(v_j_246);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
    }
  }
}
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2ebuild_2equery_2ewordsIn(a0, a1, a2, a[3], a4, a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_heff_2ebuild_2equery_2espacesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesFrom(V v_src_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)32ULL))) {
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2espacesFrom(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2espacesBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesBefore_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesBefore(V v_src_240, V v_i_241) {
top: ;
  if ((heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1) && (heff_unbox_word(heff_strByteAt_lent(v_src_240, heff_intSub_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)32ULL)))) {
    V t_0 = v_src_240;
    V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2espacesBefore(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2emoreIn_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2emoreIn_str1, 6, "infixl");
HEFF_LIT(g_heff_2ebuild_2equery_2emoreIn_str2, 6, "infixr");
HEFF_LIT(g_heff_2ebuild_2equery_2emoreIn_str3, 5, "infix");
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2emoreIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2emoreIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2emoreIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_c_243 = heff_strByteAt_lent(v_name_241, MK_INT(0LL), 2);
  V v_t_2421;
  if (((heff_peek_word(v_c_243) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_243) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_243) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_243)) ? !(heff_peek_word(v_c_243) <= ((int64_t)57ULL)) : 1))))))) {
    heff_drop(v_c_243);
    V v_t_244 = heff_dup(heff_rfield(v_t_240, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_src_245 = heff_dup(heff_rfield(v_c_242, 3));
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_src_245, 0)) - ((int64_t)1ULL));
      V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = MK_INT(0LL); V a_2 = v_src_245; V a_3 = MK_INT(1LL); V a_4 = MK_INT(10LL); V a_5 = MK_INT(0LL); V b_6 = heff_box_word(v_t_246); V r_ = (g_list_2efoldl_24f2080327479x1330764413(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(v_src_245); heff_drop(b_6); r_; });
      v_t_2421 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2equery_2emoreIn_lam0, 2, 2, (V[]){heff_dup(v_name_241), heff_dup(v_c_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_247); r_; });
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2421 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
  } else {
    heff_drop(v_c_243);
    v_t_2421 = NTAG(TAG_Nil);
  }
  V v_c_2422 = heff_strByteAt_lent(v_name_241, MK_INT(0LL), 2);
  V v_t_2423;
  if (((heff_peek_word(v_c_2422) == ((int64_t)95ULL)) ? 0 : ((heff_peek_word(v_c_2422) == ((int64_t)39ULL)) ? 0 : ((heff_peek_word(v_c_2422) == ((int64_t)47ULL)) ? 0 : (((((int64_t)97ULL) <= heff_peek_word(v_c_2422)) && (heff_peek_word(v_c_2422) <= ((int64_t)122ULL))) ? 0 : (((((int64_t)65ULL) <= heff_peek_word(v_c_2422)) && (heff_peek_word(v_c_2422) <= ((int64_t)90ULL))) ? 0 : ((((int64_t)48ULL) <= heff_peek_word(v_c_2422)) ? !(heff_peek_word(v_c_2422) <= ((int64_t)57ULL)) : 1))))))) {
    heff_drop_rec(v_t_240, 3);
    heff_drop(v_name_241);
    heff_drop_rec(v_c_242, 14);
    heff_drop(v_c_2422);
    v_t_2423 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_c_2422);
    v_t_2423 = ({ V a_0 = v_t_240; V a_1 = v_name_241; V a_2 = v_c_242; V r_ = (g_heff_2ebuild_2equery_2eexpectedIn(a_0, a_1, a_2)); heff_drop(v_name_241); r_; });
  }
  return (g_prelude_2e_2b_2b(v_t_2421, v_t_2423));
}
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2emoreIn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_name_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_name_2410 = v_name_241;
  V v_src_2411 = heff_get_n(v_c_242, 3, 14);
  V v_p_2412 = v_x_249;
  V v_d_2413 = heff_strLength_lent(v_src_2411, 0);
  V v_j_2414 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2emoreIn_str0), v_src_2411, v_p_2412, 1);
  V v_t_2415;
  if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
    heff_drop(v_j_2414);
    v_t_2415 = v_d_2413;
  } else {
    heff_drop(v_d_2413);
    v_t_2415 = v_j_2414;
  }
  V v_ws_2416 = ({ V a_0 = v_p_2412; V b_1 = heff_strSlice_lent(v_src_2411, v_p_2412, v_t_2415, 5); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ewordsOf(a_0, b_1, a_2, a_3)); heff_drop(v_p_2412); heff_drop(b_1); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_ws_2416)) {
  case TAG_Nil: {
    heff_drop(v_name_2410);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_w_2417 = heff_dup(heff_field(v_ws_2416, 0));
    if ((heff_strEq_c(heff_dup(heff_rfield(v_w_2417, 0)), ((V)&g_heff_2ebuild_2equery_2emoreIn_str1)) || (heff_strEq_c(heff_dup(heff_rfield(v_w_2417, 0)), ((V)&g_heff_2ebuild_2equery_2emoreIn_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_w_2417, 0)), ((V)&g_heff_2ebuild_2equery_2emoreIn_str3))))) {
      heff_drop_rec(v_w_2417, 2);
      v_t_2419 = ({ V a_0 = v_name_2410; V a_1 = v_ws_2416; V r_ = (g_list_2emap_24f1651437062x1594169608(a_0, a_1)); heff_drop(v_name_2410); r_; });
    } else {
      heff_drop(v_name_2410);
      heff_drop_tag(v_ws_2416, 2);
      heff_drop_rec(v_w_2417, 2);
      v_t_2419 = NTAG(TAG_Nil);
    }
    break;
  }
  default: heff_nomatch(v_ws_2416);
  }
  return (g_prelude_2e_2b_2b(v_t_2419, v_acc_248));
}
Clo g_heff_2ebuild_2equery_2enameClass_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameClass_entry, 1, 0};

V g_heff_2ebuild_2equery_2enameClass(V v_x_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) == ((int64_t)0ULL))) {
    return MK_INT(0LL);
  } else {
    if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL)))) {
      V v_t_241 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
      if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
        heff_drop(v_t_241);
        return MK_INT(1LL);
      } else {
        heff_drop(v_t_241);
        return MK_INT(0LL);
      }
    } else {
      if (((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) == ((int64_t)95ULL)) || ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))))) {
        V v_t_242 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
        if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
          heff_drop(v_t_242);
          return MK_INT(2LL);
        } else {
          heff_drop(v_t_242);
          return MK_INT(0LL);
        }
      } else {
        V v_t_243 = (g_heff_2ebuild_2equery_2eallChars_24s1137197249x2131817292(MK_INT(47LL), MK_INT(95LL), MK_INT(39LL), MK_INT(47LL), MK_INT(97LL), MK_INT(122LL), MK_INT(65LL), MK_INT(90LL), MK_INT(48LL), MK_INT(57LL), MK_INT(32LL), MK_INT(10LL), MK_INT(40LL), MK_INT(41LL), MK_INT(91LL), MK_INT(93LL), MK_INT(123LL), MK_INT(125LL), MK_INT(44LL), MK_INT(34LL), MK_INT(96LL), v_x_240, MK_INT(0LL)));
        if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
          heff_drop(v_t_243);
          return MK_INT(3LL);
        } else {
          heff_drop(v_t_243);
          return MK_INT(0LL);
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2enameClass(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str0, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str2, 1, "\012");
Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocMarkdownIn_entry, 2, 0};

V g_heff_2ebuild_2equery_2edocMarkdownIn(V v_lang_240, V v_ls_241) {
top: ;
  V v_t_242 = heff_rec_n(3, shape_out__code__expecting, (V[]){NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False)});
  V v_m_243 = (g_list_2efoldl_24s673493459x989016999(v_lang_240, v_t_242, v_ls_241));
  V v_code_244 = heff_take_field(v_m_243, 1);
  V v_out_245 = heff_get_n(v_m_243, 0, 3);
  V v_t_246 = v_code_244;
  V v_t_247;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str0), v_out_245});
  } else {
    heff_drop(v_t_246);
    v_t_247 = v_out_245;
  }
  V v_x2_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_247));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str1);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2equery_2edocMarkdownIn(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry, 1, 0};

V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENotationVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      V v_h_2415 = heff_field(v_x21_241, 0);
      V v_args_2416 = heff_field(v_x21_241, 1);
      V v_t_2417 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_h_2415));
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2416)));
      V v_t_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_2418); r_; });
      return (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      V v_e_2422 = heff_field(v_x21_241, 1);
      V t_0 = v_e_2422;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EPi: {
      V v_b_2423 = heff_field(v_x21_241, 0);
      V v_cod_2424 = heff_field(v_x21_241, 1);
      V v_t_2441;
      switch (heff_tag_of(v_b_2423)) {
      case TAG_PiNamed: {
        V v_t_2427 = heff_field(v_b_2423, 2);
        v_t_2441 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2427));
        break;
      }
      case TAG_PiImplicit: {
        V v_t_2431 = heff_field(v_b_2423, 3);
        V v_d_2432 = heff_field(v_b_2423, 4);
        V v_t_2433 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2431));
        V v_t_2435;
        switch (heff_tag_of(v_d_2432)) {
        case TAG_Nothing: {
          v_t_2435 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_2434 = heff_field(v_d_2432, 0);
          v_t_2435 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_2434));
          break;
        }
        default: heff_nomatch(v_d_2432);
        }
        v_t_2441 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2435));
        break;
      }
      case TAG_PiInstance: {
        V v_t_2439 = heff_field(v_b_2423, 3);
        v_t_2441 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2439));
        break;
      }
      case TAG_PiAnon: {
        V v_t_2440 = heff_field(v_b_2423, 0);
        v_t_2441 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2440));
        break;
      }
      default: heff_nomatch(v_b_2423);
      }
      V v_t_2442 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_cod_2424));
      return (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
    }
    case TAG_ELam: {
      V v_b_2443 = heff_field(v_x21_241, 0);
      V v_body_2444 = heff_field(v_x21_241, 1);
      V v_t_2452;
      switch (heff_tag_of(v_b_2443)) {
      case TAG_LamName: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamImplicit: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamAnn: {
        V v_t_2451 = heff_field(v_b_2443, 2);
        v_t_2452 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2451));
        break;
      }
      default: heff_nomatch(v_b_2443);
      }
      V v_t_2453 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2444));
      return (g_prelude_2e_2b_2b(v_t_2452, v_t_2453));
    }
    case TAG_EAnn: {
      V v_e_2454 = heff_field(v_x21_241, 0);
      V v_t_2455 = heff_field(v_x21_241, 1);
      V v_t_2456 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2454));
      V v_t_2457 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2455));
      return (g_prelude_2e_2b_2b(v_t_2456, v_t_2457));
    }
    case TAG_ESpec: {
      V v_acc_2458 = heff_field(v_x21_241, 0);
      V v_v_2461 = heff_field(v_x21_241, 3);
      V v_t_2462 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_acc_2458));
      V v_t_2463 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_v_2461));
      return (g_prelude_2e_2b_2b(v_t_2462, v_t_2463));
    }
    case TAG_ESig: {
      V v_fs_2464 = heff_field(v_x21_241, 0);
      V v_t_2465 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2464)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2465; V r_ = (g_list_2efoldl_24s1777318809x1106245647(a_0, a_1)); heff_drop(v_t_2465); r_; });
    }
    case TAG_ESum: {
      V v_vs_2466 = heff_field(v_x21_241, 0);
      V v_t_2467 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2466)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2467; V r_ = (g_list_2efoldl_24s491084544x100802329(a_0, a_1)); heff_drop(v_t_2467); r_; });
    }
    case TAG_EStruct: {
      V v_fs_2468 = heff_field(v_x21_241, 0);
      V v_t_2469 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2468)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2469; V r_ = (g_list_2efoldl_24s189033563x26633104(a_0, a_1)); heff_drop(v_t_2469); r_; });
    }
    case TAG_EUpdate: {
      V v_a_2470 = heff_field(v_x21_241, 0);
      V v_fs_2471 = heff_field(v_x21_241, 1);
      V v_t_2472 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2470));
      V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2471)));
      V v_t_2474 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2473; V r_ = (g_list_2efoldl_24s1026998256x1634433314(a_0, a_1)); heff_drop(v_t_2473); r_; });
      return (g_prelude_2e_2b_2b(v_t_2472, v_t_2474));
    }
    case TAG_EMatch: {
      V v_s_2475 = heff_field(v_x21_241, 0);
      V v_alts_2476 = heff_field(v_x21_241, 1);
      V v_t_2477 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_s_2475));
      V v_t_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_alts_2476)));
      V v_t_2479 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2478; V r_ = (g_list_2efoldl_24s302194196x751324068(a_0, a_1)); heff_drop(v_t_2478); r_; });
      return (g_prelude_2e_2b_2b(v_t_2477, v_t_2479));
    }
    case TAG_ELetIn: {
      V v_rhs_2480 = heff_field(v_x21_241, 0);
      V v_x212_2481 = heff_field(v_x21_241, 1);
      switch (heff_tag_of(v_x212_2481)) {
      case TAG_At: {
        V v_x2121_2482 = heff_field(v_x212_2481, 0);
        switch (heff_tag_of(v_x2121_2482)) {
        case TAG_MkAlt: {
          V v_e_2485 = heff_field(v_x2121_2482, 1);
          V v_t_2486 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_rhs_2480));
          V v_t_2487 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2485));
          return (g_prelude_2e_2b_2b(v_t_2486, v_t_2487));
        }
        default: return heff_nomatch(v_x2121_2482);
        }
      }
      default: return heff_nomatch(v_x212_2481);
      }
    }
    case TAG_EDo: {
      V v_stmts_2488 = heff_field(v_x21_241, 0);
      V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_2488)));
      return (g_list_2efoldl_24s1113296953x161795409(NTAG(TAG_Nil), v_t_2489));
    }
    case TAG_ELocal: {
      V v_b_2490 = heff_field(v_x21_241, 0);
      V v_defs_2491 = heff_field(v_x21_241, 1);
      V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2491)));
      V v_t_2493 = (g_list_2efoldl_24s1516272141x1201056882(MK_INT(12LL), NTAG(TAG_Nil), v_t_2492));
      V v_t_2494 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_b_2490));
      V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2491)));
      V v_t_2496 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2495; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2495); r_; });
      V v_t_2497 = (g_prelude_2e_2b_2b(v_t_2494, v_t_2496));
      return (g_prelude_2e_2b_2b(v_t_2493, v_t_2497));
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      V v_e_24101 = heff_field(v_x21_241, 2);
      V t_0 = v_e_24101;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EWhile: {
      V v_c_24102 = heff_field(v_x21_241, 0);
      V v_body_24103 = heff_field(v_x21_241, 1);
      V v_t_24104 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_24102));
      V v_t_24105 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24103)));
      V v_t_24106 = (g_list_2efoldl_24s1113296953x161795409(NTAG(TAG_Nil), v_t_24105));
      return (g_prelude_2e_2b_2b(v_t_24104, v_t_24106));
    }
    case TAG_EFor: {
      V v_c_24108 = heff_field(v_x21_241, 1);
      V v_body_24109 = heff_field(v_x21_241, 2);
      V v_t_24110 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_24108));
      V v_t_24111 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24109)));
      V v_t_24112 = (g_list_2efoldl_24s1113296953x161795409(NTAG(TAG_Nil), v_t_24111));
      return (g_prelude_2e_2b_2b(v_t_24110, v_t_24112));
    }
    case TAG_EIfThen: {
      V v_c_24113 = heff_field(v_x21_241, 0);
      V v_a_24114 = heff_field(v_x21_241, 1);
      V v_t_24115 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_24113));
      V v_t_24116 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_24114));
      return (g_prelude_2e_2b_2b(v_t_24115, v_t_24116));
    }
    case TAG_EBreak: {
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      V v_e_24117 = heff_field(v_x21_241, 0);
      V t_0 = v_e_24117;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ENest: {
      V v_e_24118 = heff_field(v_x21_241, 0);
      V t_0 = v_e_24118;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ELazy: {
      V v_e_24119 = heff_field(v_x21_241, 0);
      V t_0 = v_e_24119;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ETuple: {
      V v_es_24120 = heff_field(v_x21_241, 0);
      V v_t_24121 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_24120)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24121; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_24121); r_; });
    }
    case TAG_ETry: {
      V v_x211_24122 = heff_field(v_x21_241, 0);
      switch (heff_tag_of(v_x211_24122)) {
      case TAG_MkTry: {
        V v_body_24124 = heff_field(v_x211_24122, 1);
        V v_c_24125 = heff_field(v_x211_24122, 2);
        V v_t_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24124)));
        V v_t_24127 = (g_list_2efoldl_24s1113296953x161795409(NTAG(TAG_Nil), v_t_24126));
        V v_t_24140;
        switch (heff_tag_of(v_c_24125)) {
        case TAG_MkCatchArm: {
          V v_b_24128 = heff_field(v_c_24125, 0);
          V v_ss_24129 = heff_field(v_c_24125, 1);
          V v_t_24137;
          switch (heff_tag_of(v_b_24128)) {
          case TAG_LamName: {
            v_t_24137 = NTAG(TAG_Nil);
            break;
          }
          case TAG_LamImplicit: {
            v_t_24137 = NTAG(TAG_Nil);
            break;
          }
          case TAG_LamAnn: {
            V v_t_24136 = heff_field(v_b_24128, 2);
            v_t_24137 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_24136));
            break;
          }
          default: heff_nomatch(v_b_24128);
          }
          V v_t_24138 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_24129)));
          V v_t_24139 = (g_list_2efoldl_24s1113296953x161795409(NTAG(TAG_Nil), v_t_24138));
          v_t_24140 = (g_prelude_2e_2b_2b(v_t_24137, v_t_24139));
          break;
        }
        default: heff_nomatch(v_c_24125);
        }
        return (g_prelude_2e_2b_2b(v_t_24127, v_t_24140));
      }
      default: return heff_nomatch(v_x211_24122);
      }
    }
    case TAG_EWith: {
      V v_w_24141 = heff_field(v_x21_241, 0);
      V v_body_24144 = heff_field(v_x21_241, 3);
      V v_t_24145 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_w_24141));
      V v_t_24146 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24144)));
      V v_t_24147 = (g_list_2efoldl_24s1113296953x161795409(NTAG(TAG_Nil), v_t_24146));
      return (g_prelude_2e_2b_2b(v_t_24145, v_t_24147));
    }
    case TAG_EWithBound: {
      V v_bs_24148 = heff_field(v_x21_241, 0);
      V v_w_24149 = heff_field(v_x21_241, 1);
      V v_body_24150 = heff_field(v_x21_241, 2);
      V v_t_24151 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_24148)));
      V v_t_24152 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24151; V r_ = (g_list_2efoldl_24s1179255243x525343925(a_0, a_1)); heff_drop(v_t_24151); r_; });
      V v_t_24154;
      switch (heff_tag_of(v_w_24149)) {
      case TAG_Nothing: {
        v_t_24154 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_c_24153 = heff_field(v_w_24149, 0);
        v_t_24154 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_24153));
        break;
      }
      default: heff_nomatch(v_w_24149);
      }
      V v_t_24155 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24150)));
      V v_t_24156 = (g_list_2efoldl_24s1113296953x161795409(NTAG(TAG_Nil), v_t_24155));
      V v_t_24157 = (g_prelude_2e_2b_2b(v_t_24154, v_t_24156));
      return (g_prelude_2e_2b_2b(v_t_24152, v_t_24157));
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolsGo_24dps_str0, 5, "data ");
Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry, 5, 0};

V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x4_243);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_os_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_o_245);
      heff_drop(v_os_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_sps_248 = heff_field(v_x4_243, 1);
      V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_MkPair: {
        V v_sp_2410 = heff_field(v_x41_247, 1);
        heff_take_n(v_x41_247, 2ULL, 2);
        V v_c_2411 = heff_dup(v_c_240);
        V v_o_2412 = v_o_245;
        V v_sp_2413 = heff_dup(v_sp_2410);
        V v_own_2414 = ({ V a_0 = v_sp_2410; V a_1 = heff_dup(v_ss_241); V r_ = (g_list_2ekeepIf_24s257286374x378693326(a_0, a_1)); heff_drop(v_sp_2410); r_; });
        V v_t_2415 = heff_strSlice(heff_dup(heff_rfield(v_c_2411, 3)), heff_dup(heff_rfield(v_sp_2413, 0)), heff_dup(heff_rfield(v_sp_2413, 1)));
        V v_t_2416 = ({ V a_0 = heff_rfield(v_o_2412, 0); V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2equery_2ekindOf(a_0, a_1)); heff_drop(v_t_2415); r_; });
        HeffT2 v_t_2417 = (g_list_2efind_24s1702704581x1717241719_24cpr(v_own_2414));
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          V v_t_2421;
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_s_2420 = v_field_2419;
            v_t_2421 = heff_get_n(v_s_2420, 2, 3);
          } else {
            heff_drop(v_field_2419);
            v_t_2421 = (g_heff_2ebuild_2equery_2enameInGo(heff_rfield(v_c_2411, 3), heff_rfield(v_o_2412, 0), v_sp_2413, heff_dup(heff_rfield(v_sp_2413, 0))));
          }
          V v_t_2422 = (g_list_2emap_24f530523215x314966509(v_c_2411, v_sp_2413, MK_INT(5LL), ((V)&g_heff_2ebuild_2equery_2esymbolsGo_24dps_str0), MK_INT(22LL), MK_INT(8LL), v_own_2414));
          V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_2411, 4, 14)));
          V v_t_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2423); r_; });
          V v_t_2425 = (g_list_2ekeepIf_24s1950790755x1251737354(v_sp_2413, v_t_2424));
          V v_t_2426 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x4_243_24Cons, v_t_2422, v_t_2425));
          V v_t_2427 = heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){heff_get_n(v_o_2412, 0, 2), v_t_2416, v_sp_2413, v_t_2421, v_t_2426});
          V v_cell_2428 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2427, heff_hole()});
          V v_u_2429 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2428);
          V t_0 = v_c_240;
          V t_1 = v_ss_241;
          V t_2 = v_os_246;
          V t_3 = v_sps_248;
          V t_4 = v_u_2429;
          v_c_240 = t_0;
          v_ss_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          v_d_244 = t_4;
          goto top;
        }
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ebuild_2equery_2esymbolsGo_24dps(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}