// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_AsDefinition 21504
#define TAG_At 8900
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_DeclEquations 25755
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_FixedWord 19198
#define TAG_FloatValue 23118
#define TAG_FloatWord 12460
#define TAG_ImplicitParam 51130
#define TAG_IntValue 62477
#define TAG_IntWord 51777
#define TAG_Left 13886
#define TAG_MkSegment 38079
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatOp 20420
#define TAG_PatTag 47430
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_RuneWord 42901
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_StringWord 15530
#define TAG_TypeWord 10401
#define TAG_Whole 6035
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_digits 615232529
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_exponent 966452320
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_negative 1666250321
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_prims 308293287
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_waiting 1348170899
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_negative__digits__exponent[] = {LBL_negative, LBL_digits, LBL_exponent};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V);
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok1_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edecimalOfDigits(V);
V g_heff_2esyntax_2esurface_2edecimalOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edecimalOfDigits_clo;
HeffT3 g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr(V);
V g_heff_2esyntax_2esurface_2edeclL(V, V, V);
V g_heff_2esyntax_2esurface_2edeclL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edigitsVal(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edigitsVal_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edigitsVal_clo;
V g_heff_2esyntax_2esurface_2edocNext(V, V, V);
V g_heff_2esyntax_2esurface_2edocNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edocNext_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
V g_heff_2esyntax_2esurface_2eemptySpec_get(void);
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_heff_2esyntax_2esurface_2eisNameE(V);
V g_heff_2esyntax_2esurface_2eisNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisNameE_clo;
V g_heff_2esyntax_2esurface_2eknotOf(V, V);
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotOf_clo;
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_24tok1_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2emutualBody(V, V, V);
V g_heff_2esyntax_2esurface_2emutualBody_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualBody_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok1_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok2_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
V g_heff_2esyntax_2esurface_2epiImplicits_24dps(V, V);
V g_heff_2esyntax_2esurface_2epiImplicits_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_24dps_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_clo;
V g_heff_2esyntax_2esurface_2equalifiedE(V, V);
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2equalifiedE_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24tok2_clo;
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2especGroups(V, V, V);
V g_heff_2esyntax_2esurface_2especGroups_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroups_clo;
V g_heff_2esyntax_2esurface_2especGroupsOf(V, V, V);
V g_heff_2esyntax_2esurface_2especGroupsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especGroupsOf_clo;
V g_heff_2esyntax_2esurface_2etuplePRev(V, V);
V g_heff_2esyntax_2esurface_2etuplePRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etuplePRev_clo;
HeffT2 g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24rec0_get(void);
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_list_2emap_24s892909862x1245535974(V, V, V, V);
V g_list_2emap_24s892909862x1245535974_entry(V self, V *a);
extern Clo g_list_2emap_24s892909862x1245535974_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_heff_2esyntax_2esurface_2edigitsVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edigitsVal_entry, 5, 0};

V g_heff_2esyntax_2esurface_2edigitsVal(V v_base_240, V v_s_241, V v_box_24i_242, V v_box_24stop_243, V v_n_244) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  int64_t v_stop_243 = heff_peek_word(v_box_24stop_243);
top: ;
  if ((v_stop_243 <= v_i_242)) {
    return v_n_244;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_241, heff_box_word(v_i_242), 2)) == ((int64_t)95ULL))) {
      V t_0 = v_base_240;
      V t_1 = v_s_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      int64_t t_3 = v_stop_243;
      V t_4 = v_n_244;
      v_base_240 = t_0;
      v_s_241 = t_1;
      v_i_242 = t_2;
      v_stop_243 = t_3;
      v_n_244 = t_4;
      goto top;
    } else {
      V v_c_245 = heff_strByteAt_lent(v_s_241, heff_box_word(v_i_242), 2);
      int64_t v_t_246;
      if ((((int64_t)97ULL) <= heff_peek_word(v_c_245))) {
        v_t_246 = (heff_unbox_word(v_c_245) - ((int64_t)87ULL));
      } else {
        if ((((int64_t)65ULL) <= heff_peek_word(v_c_245))) {
          v_t_246 = (heff_unbox_word(v_c_245) - ((int64_t)55ULL));
        } else {
          v_t_246 = (heff_unbox_word(v_c_245) - ((int64_t)48ULL));
        }
      }
      V v_t_247 = heff_intAdd(heff_intMul_lent(v_n_244, v_base_240, 1), heff_box_word(v_t_246));
      V t_0 = v_base_240;
      V t_1 = v_s_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      int64_t t_3 = v_stop_243;
      V t_4 = v_t_247;
      v_base_240 = t_0;
      v_s_241 = t_1;
      v_i_242 = t_2;
      v_stop_243 = t_3;
      v_n_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2edigitsVal_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2edigitsVal(a0, a1, a[2], a3, a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str0, 2, "0x");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str1, 2, "0X");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str2, 2, "0o");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str3, 2, "0O");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str4, 2, "0b");
HEFF_LIT(g_heff_2esyntax_2esurface_2emagnitudeOf_str5, 2, "0B");
Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emagnitudeOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emagnitudeOf(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  V v_t_242 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6);
  if ((heff_strEq_c_lent(v_t_242, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str0), 2) || heff_strEq_c(heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str1)))) {
    heff_drop(v_t_242);
    return ({ V a_0 = MK_INT(16LL); V a_1 = v_s_240; V a_2 = heff_box_word((v_i_241 + ((int64_t)2ULL))); V b_3 = heff_strLength_lent(v_s_240, 0); V a_4 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edigitsVal(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); r_; });
  } else {
    heff_drop(v_t_242);
    V v_t_243 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6);
    if ((heff_strEq_c_lent(v_t_243, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str2), 2) || heff_strEq_c(heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str3)))) {
      heff_drop(v_t_243);
      return ({ V a_0 = MK_INT(8LL); V a_1 = v_s_240; V a_2 = heff_box_word((v_i_241 + ((int64_t)2ULL))); V b_3 = heff_strLength_lent(v_s_240, 0); V a_4 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edigitsVal(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); r_; });
    } else {
      heff_drop(v_t_243);
      V v_t_244 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6);
      if ((heff_strEq_c_lent(v_t_244, ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str4), 2) || heff_strEq_c(heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)2ULL))), 6), ((V)&g_heff_2esyntax_2esurface_2emagnitudeOf_str5)))) {
        heff_drop(v_t_244);
        return ({ V a_0 = MK_INT(2LL); V a_1 = v_s_240; V a_2 = heff_box_word((v_i_241 + ((int64_t)2ULL))); V b_3 = heff_strLength_lent(v_s_240, 0); V a_4 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edigitsVal(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); r_; });
      } else {
        heff_drop(v_t_244);
        return ({ V a_0 = MK_INT(10LL); V a_1 = v_s_240; V a_2 = heff_box_word(v_i_241); V b_3 = heff_strLength_lent(v_s_240, 0); V a_4 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edigitsVal(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); r_; });
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2emagnitudeOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2edecimalOfDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edecimalOfDigits_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edecimalOfDigits(V v_s_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr(v_s_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    return heff_rec_n(3, shape_negative__digits__exponent, (V[]){v_field_242, v_field_243, v_field_244});
  }
}
V g_heff_2esyntax_2esurface_2edecimalOfDigits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edecimalOfDigits(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2epiImplicits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epiImplicits_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epiImplicits(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENotationVar: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_nf(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_x111_2420 = heff_field(v_x11_241, 0);
      V v_rest_2421 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x111_2420)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2420, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2421;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_PiImplicit: {
        V v_x_2425 = heff_field(v_x111_2420, 0);
        heff_take_n(v_x111_2420, 1ULL, 5);
        V v_cell_2430 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2425, heff_hole()});
        V v_u_2431 = (g_heff_2esyntax_2esurface_2epiImplicits_24dps(v_rest_2421, v_cell_2430));
        heff_drop(v_u_2431);
        return v_cell_2430;
      }
      case TAG_PiInstance: {
        V v_x_2432 = heff_field(v_x111_2420, 0);
        heff_take_n(v_x111_2420, 1ULL, 4);
        V v_cell_2436 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2432, heff_hole()});
        V v_u_2437 = (g_heff_2esyntax_2esurface_2epiImplicits_24dps(v_rest_2421, v_cell_2436));
        heff_drop(v_u_2437);
        return v_cell_2436;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2420, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        V t_0 = v_rest_2421;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x111_2420);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFor: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENest: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETry: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWith: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWithBound: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epiImplicits(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_str2, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eboundBy(V v_pv_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_243 = heff_field(v_x2_241, 1);
    return ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}); V a_1 = v_args_243; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(b_0, a_1)); heff_drop(b_0); r_; });
  }
  case TAG_PAtom: {
    V v_t_245 = heff_field(v_x2_241, 0);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str0)) && !heff_strEq_c(heff_dup(heff_rfield(v_t_245, 1)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str1)))) {
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_245, 0)), ((V)&g_heff_2esyntax_2esurface_2eboundBy_str2))) {
        V v_t_246 = (g_list_2eany_24s565534491x447967237(v_t_245, v_pv_240));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_245, 1)), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_246);
          return NTAG(TAG_Nil);
        }
      } else {
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_PParen: {
    V v_q_248 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_248;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2411 = heff_field(v_x2_241, 1);
    return ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}); V a_1 = v_ps_2411; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(b_0, a_1)); heff_drop(b_0); r_; });
  }
  case TAG_POp: {
    V v_l_2415 = heff_field(v_x2_241, 0);
    V v_q_2417 = heff_field(v_x2_241, 2);
    V v_t_2418 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2415));
    V v_t_2419 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2417));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2418, v_t_2419);
  }
  case TAG_PRec: {
    V v_fs_2421 = heff_field(v_x2_241, 1);
    return ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}); V a_1 = v_fs_2421; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(b_0, a_1)); heff_drop(b_0); r_; });
  }
  case TAG_PField: {
    V v_q_2427 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2427;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2428 = heff_field(v_x2_241, 0);
    V v_q_2430 = heff_field(v_x2_241, 2);
    V v_cell_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2428, 1)), heff_hole()});
    V v_u_2432 = (g_heff_2esyntax_2esurface_2eboundBy_24dps(v_pv_240, v_q_2430, v_cell_2431));
    heff_drop(v_u_2432);
    return v_cell_2431;
  }
  case TAG_PSeg: {
    V v_q_2433 = heff_field(v_x2_241, 0);
    V t_0 = v_pv_240;
    V t_1 = v_q_2433;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_lam0(V self, V *args) {
  V v_q_244 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_244; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_244); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam1(V self, V *args) {
  V v_q_2414 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2414; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2414); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_lam2(V self, V *args) {
  V v_q_2424 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2424; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2424); r_; });
}
Clo g_heff_2esyntax_2esurface_2eidentOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eidentOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eidentOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_243)});
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENotationVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      V v_x_248 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_248)});
    }
    case TAG_EInt: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESum: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAssign: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWhile: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFor: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EBreak: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EContinue: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EReturn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENest: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELazy: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETuple: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETry: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWith: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWithBound: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eidentOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2eisNameE(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eallS_24s1153767875x1945461957(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edocNext_str0, 1, "\012");
Clo g_heff_2esyntax_2esurface_2edocNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edocNext_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edocNext(V v_src_240, V v_p_241, V v_d_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_p_241, 1));
  V v_t_2418;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_p_241, 1));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_d_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      V v_d_249 = heff_strLength_lent(v_src_240, 0);
      V v_t_2412;
      switch (heff_tag_of(v_d_247)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_d_247, 1);
        heff_take_n(v_d_247, 2ULL, 2);
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      V v_j_2413 = heff_strFind(((V)&g_heff_2esyntax_2esurface_2edocNext_str0), heff_dup(v_src_240), heff_get_n(v_t_2412, 1, 2));
      V v_t_2414;
      if (heff_intLt_c_lent(v_j_2413, MK_INT(0LL), 2)) {
        heff_drop(v_j_2413);
        v_t_2414 = v_d_249;
      } else {
        heff_drop(v_d_249);
        v_t_2414 = v_j_2413;
      }
      V v_t_2417;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_d_242, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      v_t_2418 = ({ V a_0 = v_src_240; V a_1 = heff_intAdd(v_t_2414, MK_INT(1LL)); V b_2 = heff_get_n(v_t_2417, 0, 2); V r_ = (g_heff_2esyntax_2esurface_2ecommentLinesFrom(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    V v_diags_2419 = heff_take_field(v_p_241, 2);
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, heff_take_field(v_p_241, 1)});
    return ({ V rv_1 = v_t_2420; V rv_2 = v_diags_2419; V rr_ = heff_rec_reuse_nf(v_p_241, 1ULL, 3, shape_items__waiting__diags, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  } else {
    heff_drop(v_t_2418);
    V v_items_2421 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
    V v_diags_2422 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_diags_2422);
    V v_items_2423 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_items_2423);
    V v_diags_2424 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_take_field(v_p_241, 1)));
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_242, NTAG(TAG_Nil)});
    return ({ V rv_0 = v_items_2421; V rv_1 = v_t_2425; V rv_2 = v_diags_2424; V rr_ = heff_rec_reuse_nf(v_p_241, 0ULL, 3, shape_items__waiting__diags, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
}
V g_heff_2esyntax_2esurface_2edocNext_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edocNext(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str0, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str1, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str2, 6, "String");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str3, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str4, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str5, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str6, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str7, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str8, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str9, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str10, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str11, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str12, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str13, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewordKw_str14, 7, "Float32");
Clo g_heff_2esyntax_2esurface_2ewordKw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewordKw_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ewordKw(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str0), 2)) {
    return NTAG(TAG_IntWord);
  } else {
    if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str1), 2)) {
      return NTAG(TAG_FloatWord);
    } else {
      if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str2), 2)) {
        return NTAG(TAG_StringWord);
      } else {
        if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str3), 2)) {
          return NTAG(TAG_RuneWord);
        } else {
          if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str4), 2)) {
            return NTAG(TAG_ArrayWord);
          } else {
            if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2esyntax_2esurface_2ewordKw_str5), 2)) {
              return NTAG(TAG_AbandonWord);
            } else {
              HeffT2 v_t_241 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str6); V a_1 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str7); V a_2 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str8); V a_3 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str9); V a_4 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str10); V a_5 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str11); V a_6 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str12); V a_7 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str13); V a_8 = ((V)&g_heff_2esyntax_2esurface_2ewordKw_str14); V a_9 = v_x_240; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
              {
                V v_field_243 = v_t_241.f[1];
                int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
                if ((v_tag_242 == ((int64_t)0ULL))) {
                  V v_w_244 = v_field_243;
                  return heff_tag_n(TAG_FixedWord, 1, (V[]){v_w_244});
                } else {
                  heff_drop(v_field_243);
                  return NTAG(TAG_TypeWord);
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ewordKw(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etuplePRev_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2esurface_2etuplePRev_str1, 6, "MkPair");
Clo g_heff_2esyntax_2esurface_2etuplePRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etuplePRev_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etuplePRev(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2etuplePRev_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
    V v_t_243 = ({ V rr_ = heff_rec_reuse_na(v_sp_240, 3ULL, 2, shape_start__end, 15u, 0u); rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_243});
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_Nil: {
      heff_drop_rec(v_sp_240, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_p_244;
    }
    case TAG_Cons: {
      V v_a_246 = heff_field(v_x22_245, 0);
      V v_more_247 = heff_field(v_x22_245, 1);
      V v_ru_24x22_245_24Cons = heff_take_reuse_n(v_x22_245, 3ULL, 2);
      V v_t_2410;
      switch (heff_tag_of(v_a_246)) {
      case TAG_At: {
        V v_s_249 = heff_dup(heff_field(v_a_246, 1));
        v_t_2410 = v_s_249;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      V v_t_2411 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2410, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2412 = (g_heff_2esyntax_2esurface_2etuplePRev(v_t_2411, heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_246, v_more_247})));
      V v_t_2413 = heff_tag_at_n(v_ru_24x22_245_24Cons, TAG_Cons, 2, (V[]){v_p_244, NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2etuplePRev_str1), heff_dup(v_sp_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2413})});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
    }
    default: return heff_nomatch(v_x22_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etuplePRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etuplePRev(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str0, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str2, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eletL_24cpr_str3, 1, "`");

HeffT2 g_heff_2esyntax_2esurface_2eletL_24cpr(V v_r_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_ELet: {
    V v_x26_248 = heff_field(v_x2_241, 5);
    switch (heff_tag_of(v_x26_248)) {
    case TAG_Nothing: {
      heff_drop(v_r_240);
      V v_t_249 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
      V v_start_2410 = heff_take_field(v_t_249, 3);
      V v_end_2411 = heff_get_n(v_t_249, 4, 9);
      V v_t_2412 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
      V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str0), heff_get_n(v_t_2412, 1, 9));
      V v_msg_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str1));
      V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2414, heff_rec_n(2, shape_start__end, (V[]){v_start_2410, v_end_2411}), NTAG(TAG_Nothing)});
      V v_f_2416 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2415});
      return ((HeffT2){{v_f_2416, v_z_242}});
    }
    case TAG_Just: {
      V v_x261_2417 = heff_field(v_x26_248, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_ELet: {
        V v_kw_2418 = heff_field(v_x2_241, 0);
        V v_p_2419 = heff_field(v_x2_241, 1);
        V v_ann0_2420 = heff_field(v_x2_241, 2);
        V v_e_2422 = heff_field(v_x2_241, 4);
        switch (heff_tag_of(v_x261_2417)) {
        case TAG_MkPair: {
          V v_body_2425 = heff_field(v_x261_2417, 1);
          V v_m_2426 = (g_heff_2esyntax_2esurface_2eletHeadL(heff_dup(v_r_240), heff_dup(v_p_2419), heff_dup(v_ann0_2420), heff_dup(v_e_2422)));
          V v_x1_2427 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_z_242}));
          switch (heff_tag_of(v_x1_2427)) {
          case TAG_MkPair: {
            V v_x11_2428 = heff_field(v_x1_2427, 0);
            V v_st_2429 = heff_field(v_x1_2427, 1);
            heff_take_n(v_x1_2427, 3ULL, 2);
            switch (heff_tag_of(v_x11_2428)) {
            case TAG_Left: {
              V v_e_2430 = heff_field(v_x11_2428, 0);
              V v_ru_24x11_2428_24Left = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
              heff_drop(v_r_240);
              return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2428_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2430}), v_st_2429}});
            }
            case TAG_Right: {
              V v_x_2431 = heff_field(v_x11_2428, 0);
              heff_take_n(v_x11_2428, 1ULL, 1);
              V v_t_2432 = (g_heff_2esyntax_2esurface_2eboundBy(NTAG(TAG_Nil), v_p_2419));
              return (g_heff_2esyntax_2esurface_2eletBodyL_24cpr(v_r_240, heff_dup(v_kw_2418), v_x_2431, v_t_2432, heff_dup(v_body_2425), v_st_2429));
            }
            default: return ((HeffT2){{heff_nomatch(v_x11_2428)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2427)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x261_2417)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x26_248)}});
    }
  }
  default: {
    heff_drop(v_r_240);
    V v_t_2433 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2434 = heff_take_field(v_t_2433, 3);
    V v_end_2435 = heff_get_n(v_t_2433, 4, 9);
    V v_t_2436 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2437 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str2), heff_get_n(v_t_2436, 1, 9));
    V v_msg_2438 = heff_strAppend(v_t_2437, ((V)&g_heff_2esyntax_2esurface_2eletL_24cpr_str3));
    V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2438, heff_rec_n(2, shape_start__end, (V[]){v_start_2434, v_end_2435}), NTAG(TAG_Nothing)});
    V v_f_2440 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2439});
    return ((HeffT2){{v_f_2440, v_z_242}});
  }
  }
}
HEFF_REC_LIT(g_heff_2esyntax_2esurface_2eemptySpec_lit0, 5, shape_ty__size__unit__little__signed, NTAG(TAG_Nothing), NTAG(TAG_SizeDefault), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing));

static V g_heff_2esyntax_2esurface_2eemptySpec_val;
static HEFF_ONCE g_heff_2esyntax_2esurface_2eemptySpec_st;
static V g_heff_2esyntax_2esurface_2eemptySpec_init(void) {
  return ((V)&g_heff_2esyntax_2esurface_2eemptySpec_lit0);
}
V g_heff_2esyntax_2esurface_2eemptySpec_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurface_2eemptySpec_st)) return g_heff_2esyntax_2esurface_2eemptySpec_val;
  return heff_global(&g_heff_2esyntax_2esurface_2eemptySpec_val, &g_heff_2esyntax_2esurface_2eemptySpec_st, g_heff_2esyntax_2esurface_2eemptySpec_init);
}
V g_heff_2esyntax_2esurface_2esegmentL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esegmentL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esegmentL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Seg: {
    V v_v_242 = heff_field(v_e_241, 0);
    V v_cc_243 = heff_field(v_e_241, 1);
    V v_spec_244 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_v_242)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam0, 1, 4, (V[]){v_m_245, v_spec_244, v_cc_243, v_v_242});
  }
  default: {
    V v_m_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentL_lam1, 1, 2, (V[]){v_m_2427, v_e_241});
  }
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esegmentL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esegmentL_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_spec_244 = heff_env(self)[1];
  V v_cc_243 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_spec_244);
      heff_drop_rec(v_cc_243, 9);
      heff_drop(v_v_242);
      return heff_tag_re_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_248_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = (g_heff_2esyntax_2esurface_2especGroups(heff_dup(v_spec_244), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_cc_243, 3)), heff_dup(heff_rfield(v_cc_243, 4))});
      V v_t_2414 = (g_heff_2esyntax_2esurface_2especGroupsOf(v_t_2413, heff_dup(g_heff_2esyntax_2esurface_2eemptySpec_get()), v_t_2412));
      V v_x1_2415 = heff_tr(heff_call(v_t_2414, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkPair: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        heff_take_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Left: {
          V v_e_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop(v_spec_244);
          heff_drop_rec(v_cc_243, 9);
          heff_drop(v_v_242);
          heff_drop(v_x_2411);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
        }
        case TAG_Right: {
          V v_x_2419 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_248_24Right, 1);
          V v_a_2420 = ({ V a_0 = v_v_242; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_v_242); r_; });
          V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_spec_244));
          V v_t_2424;
          switch (heff_tag_of(v_x1_2421)) {
          case TAG_Nil: {
            v_t_2424 = v_cc_243;
            break;
          }
          case TAG_Cons: {
            V v_x_2422 = heff_field(v_x1_2421, 0);
            heff_take_n(v_x1_2421, 1ULL, 2);
            heff_drop_rec(v_cc_243, 9);
            v_t_2424 = v_x_2422;
            break;
          }
          default: heff_nomatch(v_x1_2421);
          }
          V v_t_2425 = (g_heff_2esyntax_2esurface_2evalueOfE(v_x_2411));
          V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2420, 3, 9), heff_get_n(v_t_2424, 4, 9)});
          return (g_heff_2esyntax_2esurface_2esegmentOf_24tok2(v_ru_24x1_247_24MkPair, NTAG(TAG_False), v_t_2426, v_x_2411, v_t_2425, v_x_2419, v_st_2417));
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2esegmentL_lam1(V self, V *args) {
  V v_st_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2428}));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      V v_ru_24x11_2430_24Left = heff_take_reuse_n(v_x11_2430, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_re_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2430_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      V v_ru_24x11_2430_24Right = heff_take_reuse_n(v_x11_2430, 1ULL, 1);
      V v_inPat_2434 = NTAG(TAG_False);
      V v_a_2435 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      V v_t_2436 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_e_2437 = heff_get_n(v_t_2436, 4, 9);
      V v_sp_2438 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2435, 3, 9), v_e_2437});
      V v_e_2439 = heff_dup(v_x_2433);
      V v_v_2440 = ({ V a_0 = v_x_2433; V r_ = (g_heff_2esyntax_2esurface_2evalueOfE(a_0)); heff_drop(v_x_2433); r_; });
      V v_st_2441 = v_st_2431;
      V v_t_2443;
      switch (heff_tag_of(v_v_2440)) {
      case TAG_StrValue: {
        v_t_2443 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2443 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2443 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2443 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2443 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_2440);
      }
      HeffT2 v_t_2444 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_2438), heff_dup(v_v_2440), v_t_2443, v_st_2441));
      {
        V v_field_2445 = v_t_2444.f[0];
        V v_field_2446 = v_t_2444.f[1];
        V v_x11_2447 = v_field_2445;
        V v_st_2448 = v_field_2446;
        switch (heff_tag_of(v_x11_2447)) {
        case TAG_Left: {
          V v_e_2449 = heff_field(v_x11_2447, 0);
          V v_ru_24x11_2447_24Left = heff_take_reuse_n(v_x11_2447, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_2430_24Right, 1);
          heff_drop_rec(v_sp_2438, 2);
          heff_drop(v_e_2439);
          heff_drop(v_v_2440);
          return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2447_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2449}), v_st_2448});
        }
        case TAG_Right: {
          V v_ru_24x11_2447_24Right = heff_take_reuse_n(v_x11_2447, 0ULL, 1);
          V v_t_2452;
          switch (heff_tag_of(v_v_2440)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2447_24Right, 1);
            v_t_2452 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_drop_cell(v_ru_24x11_2447_24Right, 1);
            v_t_2452 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2447_24Right, 1);
            v_t_2452 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2452 = heff_tag_at_n(v_ru_24x11_2447_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2447_24Right, 1);
            v_t_2452 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_2440);
          }
          HeffT2 v_t_2453 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_24cpr(v_inPat_2434, heff_dup(v_sp_2438), heff_dup(v_v_2440), v_t_2452, NTAG(TAG_SizeDefault), v_st_2448));
          {
            V v_field_2454 = v_t_2453.f[0];
            V v_field_2455 = v_t_2453.f[1];
            V v_x11_2456 = v_field_2454;
            V v_st_2457 = v_field_2455;
            switch (heff_tag_of(v_x11_2456)) {
            case TAG_Left: {
              V v_e_2458 = heff_field(v_x11_2456, 0);
              V v_ru_24x11_2456_24Left = heff_take_reuse_n(v_x11_2456, 1ULL, 1);
              heff_drop_cell(v_ru_24x11_2430_24Right, 1);
              heff_drop_rec(v_sp_2438, 2);
              heff_drop(v_e_2439);
              heff_drop(v_v_2440);
              return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2456_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2458}), v_st_2457});
            }
            case TAG_Right: {
              V v_ru_24x11_2456_24Right = heff_take_reuse_n(v_x11_2456, 0ULL, 1);
              V v_t_2461;
              switch (heff_tag_of(v_v_2440)) {
              case TAG_StrValue: {
                heff_drop_cell(v_ru_24x11_2456_24Right, 1);
                v_t_2461 = NTAG(TAG_SegmentBinary);
                break;
              }
              case TAG_IntValue: {
                heff_take_n(v_v_2440, 0ULL, 1);
                heff_drop_cell(v_ru_24x11_2456_24Right, 1);
                v_t_2461 = NTAG(TAG_SegmentInteger);
                break;
              }
              case TAG_FloatValue: {
                heff_drop_cell(v_ru_24x11_2456_24Right, 1);
                v_t_2461 = NTAG(TAG_SegmentFloat);
                break;
              }
              case TAG_RuneValue: {
                v_t_2461 = heff_tag_at_n(v_ru_24x11_2456_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                break;
              }
              case TAG_OtherValue: {
                heff_drop_cell(v_ru_24x11_2456_24Right, 1);
                v_t_2461 = NTAG(TAG_SegmentInteger);
                break;
              }
              default: heff_nomatch(v_v_2440);
              }
              V v_t_2462 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_2439, v_t_2461, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
              V v_t_2463 = heff_tag_at_n(v_ru_24x11_2430_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_2438})});
              return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){v_t_2463, v_st_2457});
            }
            default: return heff_nomatch(v_x11_2456);
            }
          }
        }
        default: return heff_nomatch(v_x11_2447);
        }
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str2, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str3, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentValue_str4, 4, "rune");
Clo g_heff_2esyntax_2esurface_2esegmentValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentValue_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esegmentValue(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    return NTAG(TAG_False);
  }
  case TAG_PAtom: {
    V v_t_243 = heff_field(v_x1_240, 0);
    V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2esegmentValue_str0)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2esegmentValue_str1)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2esegmentValue_str2)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2esegmentValue_str3)) || heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2esegmentValue_str4)))))));
    return v_ret_24bool;
  }
  case TAG_PParen: {
    V v_p_245 = heff_field(v_x1_240, 1);
    V t_0 = v_p_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PList: {
    return NTAG(TAG_False);
  }
  case TAG_POp: {
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    return NTAG(TAG_False);
  }
  case TAG_PField: {
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    return NTAG(TAG_False);
  }
  case TAG_PSeg: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentValue(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_take_field(v_st_242, 1)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){({ V rv_0 = v_t_246; V rv_1 = v_t_247; V rr_ = heff_rec_reuse_nf(v_st_242, 0ULL, 2, shape_ops__out, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; })});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Left = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_re_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2414_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2438;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2438 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          V v_ru_24t_2418_24Cons = heff_take_reuse_n(v_t_2418, 3ULL, 2);
          V v_text_2421 = heff_take_field(v_o_2419, 1);
          V v_start_2422 = heff_take_field(v_o_2419, 3);
          V v_end_2423 = heff_get_n(v_o_2419, 4, 9);
          V v_t_2424 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2424)) {
          case TAG_Nil: {
            heff_drop(v_os_2420);
            heff_drop_cell(v_ru_24t_2418_24Cons, 2);
            heff_drop(v_text_2421);
            heff_drop(v_start_2422);
            heff_drop(v_end_2423);
            v_t_2438 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2425 = heff_field(v_t_2424, 0);
            V v_it2_2426 = heff_field(v_t_2424, 1);
            V v_ru_24t_2424_24Cons = heff_take_reuse_n(v_t_2424, 3ULL, 2);
            switch (heff_tag_of(v_it2_2426)) {
            case TAG_Nil: {
              heff_drop(v_os_2420);
              heff_drop_cell(v_ru_24t_2418_24Cons, 2);
              heff_drop(v_text_2421);
              heff_drop(v_start_2422);
              heff_drop(v_end_2423);
              heff_drop(v_r_2425);
              heff_drop_cell(v_ru_24t_2424_24Cons, 2);
              v_t_2438 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2427 = heff_field(v_it2_2426, 0);
              V v_rest_2428 = heff_field(v_it2_2426, 1);
              V v_ru_24it2_2426_24Cons = heff_take_reuse_n(v_it2_2426, 3ULL, 2);
              V v_x_2429 = v_text_2421;
              V v_xsp_2430 = heff_rec_n(2, shape_start__end, (V[]){v_start_2422, v_end_2423});
              V v_t_2433;
              switch (heff_tag_of(v_r_2425)) {
              case TAG_At: {
                V v_s_2432 = heff_dup(heff_field(v_r_2425, 1));
                v_t_2433 = v_s_2432;
                break;
              }
              default: heff_nomatch(v_r_2425);
              }
              V v_t_2434 = heff_tag_at_n(v_ru_24t_2418_24Cons, TAG_Cons, 2, (V[]){v_r_2425, NTAG(TAG_Nil)});
              V v_t_2435 = heff_tag_n(TAG_PatOp, 3, (V[]){v_x_2429, heff_dup(v_xsp_2430), heff_tag_at_n(v_ru_24t_2424_24Cons, TAG_Cons, 2, (V[]){v_l_2427, v_t_2434})});
              V v_t_2436 = ({ V rv_1 = heff_get_n(v_t_2433, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2430, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2437 = heff_tag_re_n(v_ru_24it2_2426_24Cons, TAG_Cons, 2, 2ULL, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, v_t_2436}), v_rest_2428});
              v_t_2438 = ({ V rv_0 = v_os_2420; V rv_1 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_st_242, 0ULL, 2, shape_ops__out, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
              break;
            }
            default: heff_nomatch(v_it2_2426);
            }
            break;
          }
          default: heff_nomatch(v_t_2424);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2439 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2438; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2439;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_take_field(v_st_242, 1)});
        V v_t_2442 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){({ V rv_0 = v_t_2440; V rv_1 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_st_242, 0ULL, 2, shape_ops__out, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; })});
        return heff_tag_re_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2442, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}

static V g_heff_2esyntax_2esurface_2ewhereL_24rec0_val;
static HEFF_ONCE g_heff_2esyntax_2esurface_2ewhereL_24rec0_st;
static V g_heff_2esyntax_2esurface_2ewhereL_24rec0_init(void) {
  return heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
}
V g_heff_2esyntax_2esurface_2ewhereL_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurface_2ewhereL_24rec0_st)) return g_heff_2esyntax_2esurface_2ewhereL_24rec0_val;
  return heff_global(&g_heff_2esyntax_2esurface_2ewhereL_24rec0_val, &g_heff_2esyntax_2esurface_2ewhereL_24rec0_st, g_heff_2esyntax_2esurface_2ewhereL_24rec0_init);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str0, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str1, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_str2, 1, "(");
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamOf(V v_r_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_f_245 = v_field_244;
      V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_f_245}));
      return heff_tail(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam0, 1, 1, (V[]){v_m_246}), heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam1, 2, 1, (V[]){v_e_241})});
    } else {
      heff_drop(v_field_244);
      V v_m_2432 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241)}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam2, 1, 2, (V[]){v_m_2432, v_e_241});
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2412));
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2413}));
      return (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(v_ru_24x1_248_24MkPair, MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str0), v_t_2414, v_st_2410));
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam1(V self, V *args) {
  V v_d_2415 = args[0];
  V v_z_2416 = args[1];
  V v_e_241 = heff_env(self)[0];
  HeffT2 v_t_2417 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(v_d_2415));
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      heff_drop(v_d_2415);
      V v_q_2420 = v_field_2419;
      V v_name_2421 = heff_take_field(v_q_2420, 0);
      V v_span_2422 = heff_take_field(v_q_2420, 1);
      V v_ty_2423 = heff_get_n(v_q_2420, 2, 3);
      V v_a_2424 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
      heff_clo_take(self, 1);
      V v_b_2425 = (g_heff_2esyntax_2ecst_2elastE(v_e_241));
      V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2424, 3, 9), heff_get_n(v_b_2425, 4, 9)});
      V v_x_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_name_2421, v_span_2422, v_ty_2423}), v_t_2426});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2427}), v_z_2416});
    } else {
      heff_drop(self);
      heff_drop(v_field_2419);
      V v_t_2430;
      switch (heff_tag_of(v_d_2415)) {
      case TAG_At: {
        V v_s_2429 = heff_field(v_d_2415, 1);
        heff_take_n(v_d_2415, 2ULL, 2);
        v_t_2430 = v_s_2429;
        break;
      }
      default: heff_nomatch(v_d_2415);
      }
      V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str1), v_t_2430, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_z_2416});
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam3(V self, V *args) {
  V v_st_2441 = args[0];
  V v_x_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2438}), v_st_2441});
}
V g_heff_2esyntax_2esurface_2edataParamOf_lam2(V self, V *args) {
  V v_st_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_st_2433}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_MkPair: {
    V v_x11_2435 = heff_field(v_x1_2434, 0);
    V v_st_2436 = heff_field(v_x1_2434, 1);
    V v_ru_24x1_2434_24MkPair = heff_take_reuse_n(v_x1_2434, 3ULL, 2);
    switch (heff_tag_of(v_x11_2435)) {
    case TAG_Left: {
      V v_e_2437 = heff_field(v_x11_2435, 0);
      V v_ru_24x11_2435_24Left = heff_take_reuse_n(v_x11_2435, 1ULL, 1);
      heff_drop(v_e_241);
      return heff_tag_re_n(v_ru_24x1_2434_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2435_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2437}), v_st_2436});
    }
    case TAG_Right: {
      V v_x_2438 = heff_field(v_x11_2435, 0);
      V v_ru_24x11_2435_24Right = heff_take_reuse_n(v_x11_2435, 1ULL, 1);
      V v_t_2439 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_241); r_; });
      V v_m_2442;
      if (heff_strEq_c(heff_get_n(v_t_2439, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_str2))) {
        V v_t_2440 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2438));
        v_m_2442 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2440}));
      } else {
        v_m_2442 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_lam3, 1, 1, (V[]){v_x_2438});
      }
      V v_x1_2443 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_st_2436}));
      switch (heff_tag_of(v_x1_2443)) {
      case TAG_MkPair: {
        V v_x11_2444 = heff_field(v_x1_2443, 0);
        V v_st_2445 = heff_field(v_x1_2443, 1);
        heff_take_n(v_x1_2443, 3ULL, 2);
        switch (heff_tag_of(v_x11_2444)) {
        case TAG_Left: {
          V v_e_2446 = heff_field(v_x11_2444, 0);
          heff_take_n(v_x11_2444, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2435_24Right, TAG_Left, 1, (V[]){v_e_2446}), v_st_2445});
        }
        case TAG_Right: {
          V v_x_2447 = heff_field(v_x11_2444, 0);
          heff_take_n(v_x11_2444, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_2435_24Right, 1);
          return ({ V a_0 = v_ru_24x1_2434_24MkPair; V a_1 = v_x_2447; V a_2 = v_st_2445; V r_ = (g_heff_2esyntax_2esurface_2eparamOf_24tok2(a_0, a_1, a_2)); heff_drop(v_x_2447); r_; });
        }
        default: return heff_nomatch(v_x11_2444);
        }
      }
      default: return heff_nomatch(v_x1_2443);
      }
    }
    default: return heff_nomatch(v_x11_2435);
    }
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualBody_str0, 7, "#mutual");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualBody_str1, 7, "#mutual");
Clo g_heff_2esyntax_2esurface_2emutualBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualBody_entry, 3, 0};

V g_heff_2esyntax_2esurface_2emutualBody(V v_tyE_240, V v_k_241, V v_d_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_242, 2));
  V v_t_246;
  switch (heff_tag_of(v_t_243)) {
  case TAG_At: {
    V v_s_245 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 2ULL, 2);
    v_t_246 = v_s_245;
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_247 = (g_list_2emap_24s892909862x1245535974(heff_dup(v_d_242), ((V)&g_heff_2esyntax_2esurface_2emutualBody_str0), v_k_241, heff_dup(heff_rfield(v_d_242, 3))));
  V v_t_248 = heff_strAppend(heff_take_field(v_d_242, 0), ((V)&g_heff_2esyntax_2esurface_2emutualBody_str1));
  V v_t_249 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_tyE_240}), heff_take_field(v_d_242, 2)});
  V v_t_2410 = heff_tag_n(TAG_DeclEquations, 5, (V[]){v_t_248, heff_take_field(v_d_242, 1), NTAG(TAG_AsDefinition), heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_246}), v_t_247});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_get_n(v_d_242, 4, 5)});
  return heff_tag_n(TAG_Whole, 1, (V[]){v_t_2411});
}
V g_heff_2esyntax_2esurface_2emutualBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualBody(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eknotOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eknotOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eknotOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eknotOf(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DImport: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DFixity: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DSig: {
      V v_names_247 = heff_field(v_x21_242, 0);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2eknotOf(v_k_240, v_rest_243));
      return ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eknotOf_lam0, 2, 1, (V[]){heff_dup(v_k_240)}); V a_1 = v_t_2411; V a_2 = v_names_247; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    }
    case TAG_DInstance: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DEqn: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DData: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DType: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DTheory: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DMutual: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DPrimitive: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DTest: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_DWatch: {
      V t_0 = v_k_240;
      V t_1 = v_rest_243;
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eknotOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eknotOf_lam0(V self, V *args) {
  V v_m_2412 = args[0];
  V v_n_2413 = args[1];
  V v_k_240 = heff_env(self)[0];
  HeffT2 v_t_2414 = ({ V a_0 = v_n_2413; HeffT2 r_ = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(a_0)); heff_drop(v_n_2413); r_; });
  {
    V v_field_2415 = v_t_2414.f[0];
    heff_drop(v_t_2414.f[1]);
    heff_clo_take(self, 1);
    return ({ V a_0 = v_m_2412; V a_1 = v_field_2415; V a_2 = v_k_240; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_field_2415); heff_drop(v_k_240); r_; });
  }
}
Clo g_heff_2esyntax_2esurface_2edeclL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edeclL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edeclL(V v_r_240, V v_d_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2edeclL_24cpr(v_r_240, v_d_241, v_z_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2edeclL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edeclL(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2esurface_2eedgesOf(heff_dup(v_lit_240), heff_dup(v_x_242)));
    V v_t_245 = (g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(v_lit_240, v_xs_243));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2elineColFrom_str2, 1, ":");
Clo g_heff_2esyntax_2esurface_2elineColFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elineColFrom_entry, 4, 0};

V g_heff_2esyntax_2esurface_2elineColFrom(V v_src_240, V v_i_241, V v_l_242, V v_start_243) {
top: ;
  V v_j_244 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2elineColFrom_str0), v_src_240, v_start_243, 1);
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    V v_t_245 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
    V v_t_246 = heff_strAppend(heff_intShow(v_l_242), ((V)&g_heff_2esyntax_2esurface_2elineColFrom_str1));
    V v_t_247 = heff_intShow(heff_intAdd(v_t_245, MK_INT(1LL)));
    return heff_strAppend(v_t_246, v_t_247);
  } else {
    if (heff_intLt_c_lent(v_j_244, v_i_241, 0)) {
      heff_drop(v_start_243);
      V t_0 = v_src_240;
      V t_1 = v_i_241;
      V t_2 = heff_intAdd(v_l_242, MK_INT(1LL));
      V t_3 = heff_intAdd(v_j_244, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_l_242 = t_2;
      v_start_243 = t_3;
      goto top;
    } else {
      heff_drop(v_j_244);
      V v_t_248 = (g_heff_2eutil_2erune_2erunesGo(v_src_240, v_start_243, v_i_241, MK_INT(0LL)));
      V v_t_249 = heff_strAppend(heff_intShow(v_l_242), ((V)&g_heff_2esyntax_2esurface_2elineColFrom_str2));
      V v_t_2410 = heff_intShow(heff_intAdd(v_t_248, MK_INT(1LL)));
      return heff_strAppend(v_t_249, v_t_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2elineColFrom(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2enoKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enoKnown_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enoKnown(V v_x_240) {
top: ;
  return NTAG(TAG_False);
}
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enoKnown(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ekwAtom_24tok1_str0, 1, ".");
Clo g_heff_2esyntax_2esurface_2ekwAtom_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ekwAtom_24tok1_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ekwAtom_24tok1(V v_tok_240, V v_t_241, V v_fs_242, V v_st_243) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_fs_242)) {
  case TAG_Nil: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_f_244 = heff_dup(heff_field(v_fs_242, 0));
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2esurface_2ekwAtom_24tok1_str0));
    V v_t_247 = heff_strAppend(v_t_246, heff_get_n(v_f_244, 1, 9));
    v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_243, 2)), 1, (V[]){v_t_247}));
    break;
  }
  default: heff_nomatch(v_fs_242);
  }
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_243, 2)), 1, (V[]){heff_dup(heff_rfield(v_t_241, 1))}));
  V v_x_2415;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_t_248);
    heff_drop(v_t_249);
    v_x_2415 = (g_heff_2esyntax_2esurface_2equalifiedE(v_t_241, v_fs_242));
  } else {
    heff_drop(v_t_248);
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = (g_list_2emap_24s513201124x806973253(v_fs_242));
      V v_t_2411 = heff_tag_at_n(v_tok_240, TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_t_241, 1))});
      V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
      v_x_2415 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_t_2412}), v_t_2410));
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_t_249);
      V v_e_2413 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_241));
      V v_t_2414 = (g_list_2emap_24s513201124x806973253(v_fs_242));
      v_x_2415 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2413, v_t_2414));
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2415}), v_st_243});
}
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ekwAtom_24tok1(a[0], a[1], a[2], a[3]);
}