// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_module 878357911
#define LBL_packages 1496006433
#define LBL_require 1327554473
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_clo;
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_clo;
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789(V, V, V);
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24s1910320727x339655847(V, V);
V g_list_2efoldl_24s1910320727x339655847_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1910320727x339655847_clo;
V g_list_2efoldl_24s422700624x1171050237(V, V);
V g_list_2efoldl_24s422700624x1171050237_entry(V self, V *a);
extern Clo g_list_2efoldl_24s422700624x1171050237_clo;
HeffT5 g_list_2efoldl_24s571074576x1179600767_24cpr(V, V);
V g_list_2emap_24s2098427539x1767581560(V, V, V, V);
V g_list_2emap_24s2098427539x1767581560_entry(V self, V *a);
extern Clo g_list_2emap_24s2098427539x1767581560_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2esortOn_24s1704298248x384812646(V, V, V, V, V, V, V);
V g_list_2esortOn_24s1704298248x384812646_entry(V self, V *a);
extern Clo g_list_2esortOn_24s1704298248x384812646_clo;
V g_prelude_2einstanceOrderPair_24s566030815x71064266_get(void);
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str1, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str2, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str6, 11, "the project");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str7, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str8, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str10, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str16, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str17, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str18, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str20, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str21, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str22, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str25, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str26, 32, "heff get: cannot write heff.sum\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str27, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str28, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str29, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str30, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str32, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str33, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str34, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str35, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str37, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str38, 36, " packages, none fetched: no heff.sum");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str39, 27, " packages, heff.sum written");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str40, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str41, 1, "\012");
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam7(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam7, 2, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam8(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam8, 1, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam13(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam18(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam17(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam16(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam15(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam2(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_entry, 4, 0};

V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0(V v_hd_240, V v_k_241, V v_x_242, V v_x_243) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_x_243)) {
  case TAG_Left: {
    v_t_246 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str0);
    break;
  }
  case TAG_Right: {
    V v_y_245 = heff_field(v_x_243, 0);
    v_t_246 = heff_dup(v_y_245);
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  HeffT2 v_t_247 = ({ V a_0 = v_t_246; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_t_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_x_242);
      V v_p_2410 = v_field_249;
      heff_drop(v_p_2410);
      V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str1), NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
    } else {
      V v_x_2424 = v_field_249;
      HeffT2 v_t_2425 = ({ V a_0 = v_x_2424; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2424); r_; });
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          heff_drop(v_x_242);
          V v_x_2428 = v_field_2427;
          heff_drop(v_x_2428);
          V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str2), NTAG(TAG_MkUnit)});
          V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
          V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
          V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
          V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
          V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
          return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
        } else {
          V v_root_2442 = v_field_2427;
          V v_t_2443 = (g_heff_2ebuild_2eload_2ereadSumAt_24s533140460x67941891(heff_dup(v_x_242)));
          return heff_tail(v_t_2443, 2, (V[]){heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_root_2442, v_x_242})});
        }
      }
    }
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2417);
  V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam1(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam3(V self, V *args) {
  V v_x_2453 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2453);
  V v_t_2454 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam4(V self, V *args) {
  V v_by_2463 = args[0];
  V v_path_2464 = args[1];
  V v_v_2465 = args[2];
  V v_x_242 = heff_env(self)[0];
  V v_root_2442 = heff_env(self)[1];
  V v_sums_2460 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844(v_x_242, v_root_2442, v_sums_2460, v_by_2463, v_path_2464, v_v_2465));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam7(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  heff_drop(v_hd_2478);
  V f_ = v_k_2479;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam8(V self, V *args) {
  V v_r_2487 = args[0];
  return v_r_2487;
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam10(V self, V *args) {
  V v_x_2496 = args[0];
  V v_k_2490 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2496)) {
  case TAG_Left: {
    heff_take_n(v_x_2496, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2490;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2498 = heff_field(v_x_2496, 0);
    heff_take_n(v_x_2496, 1ULL, 1);
    switch (heff_tag_of(v_y_2498)) {
    case TAG_Left: {
      heff_take_n(v_y_2498, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2490;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2498, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2490;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2498);
    }
  }
  default: return heff_nomatch(v_x_2496);
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam9(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  V v_a_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2488})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2495, v_hd_2489, heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam10, 1, 1, (V[]){v_k_2490})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam13(V self, V *args) {
  V v_x_24119 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_24119);
  V v_t_24120 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
  V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24124})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24125}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam18(V self, V *args) {
  V v_x_24148 = args[0];
  V v_seen_24146 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24148; V a_1 = v_seen_24146; V r_ = (g_list_2efoldl_24s1910320727x339655847(a_0, a_1)); heff_drop(v_seen_24146); r_; });
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam17(V self, V *args) {
  V v_x_24137 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2467 = heff_env(self)[2];
  V v_x_2472 = heff_env(self)[3];
  if (heff_intLt_c(MK_INT(0LL), v_x_24137)) {
    heff_clo_take(self, 4);
    heff_drop(v_x_2467);
    heff_drop(v_x_2472);
    V v_t_24138 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
    V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
    V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
    V v_t_24143 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24142})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24143}), v_hd_240, v_k_241));
  } else {
    V v_seen_24146;
    heff_clo_take(self, 4);
    switch (heff_tag_of(v_x_2467)) {
    case TAG_MkPair: {
      V v_x_24144 = heff_field(v_x_2467, 0);
      heff_take_n(v_x_2467, 1ULL, 2);
      v_seen_24146 = v_x_24144;
      break;
    }
    default: heff_nomatch(v_x_2467);
    }
    V v_t_24147 = (g_list_2efoldl_24s422700624x1171050237(NTAG(TAG_Nil), heff_dup(v_seen_24146)));
    V v_t_24149 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam18, 1, 1, (V[]){v_seen_24146}); V a_3 = v_t_24147; V r_ = (g_list_2efoldl_24f556306710x2087456230(a_0, a_1, b_2, a_3)); heff_drop(b_2); heff_drop(v_t_24147); r_; });
    V v_t_24150 = (g_list_2esortOn_24s1704298248x384812646(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str29), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str30), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str31), heff_dup(g_prelude_2einstanceOrderPair_24s566030815x71064266_get()), v_x_2472));
    V v_x2_24151 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str32), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str33), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str34), v_t_24150));
    V v_t_24154;
    switch (heff_tag_of(v_x2_24151)) {
    case TAG_Nil: {
      v_t_24154 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_24152 = heff_field(v_x2_24151, 0);
      V v_xs_24153 = heff_field(v_x2_24151, 1);
      heff_take_n(v_x2_24151, 3ULL, 2);
      v_t_24154 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str36); V a_1 = v_x_24152; V a_2 = v_xs_24153; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24153); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24151);
    }
    V v_t_24155;
    if (heff_strEq_c(v_t_24154, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str37))) {
      v_t_24155 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str38);
    } else {
      v_t_24155 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str39);
    }
    V v_t_24156 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str40), heff_intShow(v_t_24149));
    V v_str_24157 = heff_strAppend(v_t_24156, v_t_24155);
    V v_t_24158 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24157, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str41)), NTAG(TAG_MkUnit)});
    V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
    V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
    V v_t_24161 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
    V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
    V v_t_24163 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24162})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24163}), v_hd_240, v_k_241));
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam16(V self, V *args) {
  V v_x_24129 = args[0];
  V v_x_24128 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_2467 = heff_env(self)[3];
  V v_x_2472 = heff_env(self)[4];
  V v_t_24130 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_24129, heff_dup(heff_rfield(v_x_24128, 4))));
  heff_clo_take(self, 5);
  HeffT5 v_t_24131 = (g_list_2efoldl_24s571074576x1179600767_24cpr(v_x_24128, v_t_24130));
  {
    V v_field_24133 = v_t_24131.f[1];
    heff_drop(v_t_24131.f[0]);
    heff_drop(v_t_24131.f[2]);
    heff_drop(v_t_24131.f[3]);
    heff_drop(v_t_24131.f[4]);
    return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str28), v_field_24133, MK_INT(0LL), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam17, 1, 4, (V[]){v_hd_240, v_k_241, v_x_2467, v_x_2472})));
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam15(V self, V *args) {
  V v_x_24128 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2467 = heff_env(self)[2];
  V v_x_2472 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam16, 1, 5, (V[]){v_x_24128, v_hd_240, v_k_241, v_x_2467, v_x_2472})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam14(V self, V *args) {
  V v_x_24127 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2467 = heff_env(self)[2];
  V v_x_2472 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_24127, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str27), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam15, 1, 4, (V[]){v_hd_240, v_k_241, v_x_2467, v_x_2472})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam12(V self, V *args) {
  V v_x_24106 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_24102 = heff_env(self)[2];
  V v_x_2467 = heff_env(self)[3];
  V v_x_2472 = heff_env(self)[4];
  if (heff_intLt_c(MK_INT(0LL), v_x_24106)) {
    heff_clo_take(self, 5);
    heff_drop(v_x_24102);
    heff_drop(v_x_2467);
    heff_drop(v_x_2472);
    V v_t_24107 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24111})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24112}), v_hd_240, v_k_241));
  } else {
    if (!(heff_dup(v_x_24102) == NTAG(TAG_True))) {
      heff_clo_take(self, 5);
      heff_drop(v_x_24102);
      heff_drop(v_x_2467);
      heff_drop(v_x_2472);
      V v_t_24113 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str26), NTAG(TAG_MkUnit)});
      V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
      V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
      V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
      V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
      V v_t_24118 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24117})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24118}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam13, 1, 2, (V[]){v_hd_240, v_k_241})));
    } else {
      heff_clo_take(self, 5);
      heff_drop(v_x_24102);
      V v_c_24126 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
      V f_ = v_c_24126;
      heff_room[0] = heff_dup(v_hd_240);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam14, 1, 4, (V[]){v_hd_240, v_k_241, v_x_2467, v_x_2472});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam11(V self, V *args) {
  V v_x_24102 = args[0];
  V v_x_2467 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_2472 = heff_env(self)[3];
  V v_t_24105;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2467)) {
  case TAG_MkPair: {
    V v_y_24104 = heff_dup(heff_field(v_x_2467, 1));
    v_t_24105 = v_y_24104;
    break;
  }
  default: heff_nomatch(v_x_2467);
  }
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str25), v_t_24105, MK_INT(0LL), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam12, 1, 5, (V[]){v_hd_240, v_k_241, v_x_24102, v_x_2467, v_x_2472})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam6(V self, V *args) {
  V v_x_2472 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2467 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_t_2473 = (g_list_2esortOn_24s1704298248x384812646(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str7), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str8), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str9), heff_dup(g_prelude_2einstanceOrderPair_24s566030815x71064266_get()), heff_dup(v_x_2472)));
  V v_x2_2474 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str10), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str11), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str12), v_t_2473));
  V v_t_2477;
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_Nil: {
    v_t_2477 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str13);
    break;
  }
  case TAG_Cons: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_xs_2476 = heff_field(v_x2_2474, 1);
    heff_take_n(v_x2_2474, 3ULL, 2);
    v_t_2477 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str14); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2474);
  }
  V v_c_24101;
  if (heff_strEq_c(v_t_2477, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str15))) {
    v_c_24101 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam7_clo);
  } else {
    V v_path_2480 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str16)));
    V v_t_2481 = (g_list_2esortOn_24s1704298248x384812646(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str17), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str18), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str19), heff_dup(g_prelude_2einstanceOrderPair_24s566030815x71064266_get()), heff_dup(v_x_2472)));
    V v_x2_2482 = (g_list_2emap_24s2098427539x1767581560(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str20), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str21), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str22), v_t_2481));
    V v_text_2485;
    switch (heff_tag_of(v_x2_2482)) {
    case TAG_Nil: {
      v_text_2485 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str23);
      break;
    }
    case TAG_Cons: {
      V v_x_2483 = heff_field(v_x2_2482, 0);
      V v_xs_2484 = heff_field(v_x2_2482, 1);
      heff_take_n(v_x2_2482, 3ULL, 2);
      v_text_2485 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str24); V a_1 = v_x_2483; V a_2 = v_xs_2484; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2484); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2482);
    }
    V v_t_2486 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2480; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2480); r_; });
    V v_a_2488 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2486, v_text_2485, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam8_clo)});
    v_c_24101 = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam9, 2, 1, (V[]){v_a_2488});
  }
  heff_clo_take(self, 3);
  V f_ = v_c_24101;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam11, 1, 4, (V[]){v_x_2467, v_hd_240, v_k_241, v_x_2472});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam5(V self, V *args) {
  V v_x_2467 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_root_2442 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_t_2470;
  switch (heff_tag_of(v_x_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_dup(heff_field(v_x_2467, 0));
    v_t_2470 = v_x_2468;
    break;
  }
  default: heff_nomatch(v_x_2467);
  }
  heff_clo_take(self, 4);
  V v_t_2471 = ({ V a_0 = v_x_242; V a_1 = v_root_2442; V a_2 = v_t_2470; V r_ = (g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789(a_0, a_1, a_2)); heff_drop(v_x_242); heff_drop_rec(v_root_2442, 4); r_; });
  V f_ = v_t_2471;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam6, 1, 3, (V[]){v_hd_240, v_x_2467, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam2(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_root_2442 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Left: {
    V v_why_2445 = heff_field(v_x_2444, 0);
    V v_ru_24x_2444_24Left = heff_take_reuse_n(v_x_2444, 1ULL, 1);
    heff_clo_take(self, 4);
    heff_drop_rec(v_root_2442, 4);
    heff_drop(v_x_242);
    V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str3), v_why_2445), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str4));
    V v_t_2447 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2446, NTAG(TAG_MkUnit)});
    V v_t_2448 = heff_tag_at_n(v_ru_24x_2444_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Right: {
    V v_sums_2460 = heff_field(v_x_2444, 0);
    heff_take_n(v_x_2444, 1ULL, 1);
    V v_t_2461;
    if (heff_strEq_c(heff_dup(heff_rfield(v_root_2442, 0)), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str5))) {
      v_t_2461 = ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_str6);
    } else {
      v_t_2461 = heff_dup(heff_rfield(v_root_2442, 0));
    }
    V v_t_2462 = (g_list_2emap_24s675147852x248982264(v_t_2461, heff_dup(heff_rfield(v_root_2442, 2))));
    V v_t_2466 = ({ V b_0 = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam4, 3, 3, (V[]){heff_dup(v_x_242), heff_dup(v_root_2442), v_sums_2460}); V a_1 = heff_rfield(v_root_2442, 0); V a_2 = v_t_2462; V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s817794623x291308018(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    heff_clo_take(self, 4);
    V f_ = v_t_2466;
    heff_room[0] = heff_dup(v_hd_240);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_lam5, 1, 4, (V[]){v_x_242, v_root_2442, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2444);
  }
}