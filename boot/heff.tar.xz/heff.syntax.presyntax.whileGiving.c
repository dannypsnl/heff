// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_ELam 43266
#define TAG_EReturn 59059
#define LBL_bound 295286168
#define LBL_depth 296830685
#define LBL_giving 701566649
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
static uint32_t shape_names__muts__loop__sp__depth__giving__bound[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving, LBL_bound};
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo;
HeffT7 g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_24cpr(V, V, V);
V g_list_2eany_24s2003678755x1820404042(V);
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a);
extern Clo g_list_2eany_24s2003678755x1820404042_clo;

HeffT7 g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_24cpr(V v_cx_240, V v_c_241, V v_body_242) {
top: ;
  V v_names_243 = heff_take_field(v_cx_240, 0);
  V v_muts_244 = heff_take_field(v_cx_240, 1);
  V v_loop_245 = heff_take_field(v_cx_240, 2);
  V v_sp_246 = heff_take_field(v_cx_240, 3);
  V v_depth_247 = heff_take_field(v_cx_240, 4);
  V v_bound_248 = heff_get_n(v_cx_240, 6, 7);
  V v_ret_2424;
  switch (heff_tag_of(v_c_241)) {
  case TAG_At: {
    V v_e1_249 = heff_dup(heff_field(v_c_241, 0));
    switch (heff_tag_of(v_e1_249)) {
    case TAG_ELam: {
      heff_take_n(v_e1_249, 0ULL, 2);
      switch (heff_tag_of(v_c_241)) {
      case TAG_At: {
        heff_take_n(v_c_241, 0ULL, 2);
        v_ret_2424 = (g_list_2eany_24s2003678755x1820404042(v_body_242));
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      break;
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_249, 0ULL, 1);
      heff_drop(v_body_242);
      switch (heff_tag_of(v_c_241)) {
      case TAG_At: {
        heff_take_n(v_c_241, 0ULL, 2);
        v_ret_2424 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_c_241);
      }
      break;
    }
    default: {
      heff_drop(v_e1_249);
      HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_c_241));
      {
        V v_field_2419 = v_t_2418.f[0];
        V v_field_2420 = v_t_2418.f[1];
        V v_x_2421 = v_field_2419;
        V v_y_2422 = v_field_2420;
        heff_drop(v_y_2422);
        V v_t_2423 = v_x_2421;
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_body_242);
          heff_drop(v_t_2423);
          v_ret_2424 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_2423);
          v_ret_2424 = (g_list_2eany_24s2003678755x1820404042(v_body_242));
        }
      }
      break;
    }
    }
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  V v_f_2425 = v_names_243;
  V v_f_2426 = v_muts_244;
  V v_f_2427 = v_loop_245;
  V v_f_2428 = v_sp_246;
  V v_f_2429 = v_depth_247;
  V v_f_2430 = v_bound_248;
  return ((HeffT7){{v_f_2425, v_f_2426, v_f_2427, v_f_2428, v_f_2429, heff_tag_n(TAG_Just, 1, (V[]){v_ret_2424}), v_f_2430}});
}
Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V v_cx_240, V v_c_241, V v_body_242) {
top: ;
  HeffT7 v_t_243 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_24cpr(v_cx_240, v_c_241, v_body_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    V v_field_247 = v_t_243.f[3];
    V v_field_248 = v_t_243.f[4];
    V v_field_249 = v_t_243.f[5];
    V v_field_2410 = v_t_243.f[6];
    return heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){v_field_244, v_field_245, v_field_246, v_field_247, v_field_248, v_field_249, v_field_2410});
  }
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(a[0], a[1], a[2]);
}