// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Fork 41691
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_regex_2eemit(V, V);
V g_regex_2eemit_entry(V self, V *a);
extern Clo g_regex_2eemit_clo;
V g_regex_2eemit_2eemitOptional_241(V, V, V, V, V);
V g_regex_2eemit_2eemitOptional_241_entry(V self, V *a);
extern Clo g_regex_2eemit_2eemitOptional_241_clo;
V g_regex_2esizeOf(V);
V g_regex_2esizeOf_entry(V self, V *a);
extern Clo g_regex_2esizeOf_clo;
Clo g_regex_2eemit_2eemitOptional_241_clo = {{0x80000000u, K_CLO, 0}, g_regex_2eemit_2eemitOptional_241_entry, 5, 0};

V g_regex_2eemit_2eemitOptional_241(V v_greedy_240, V v_x_241, V v_k_242, V v_from_243, V v_end_244) {
top: ;
  if (heff_intLe_c_lent(v_k_242, MK_INT(0LL), 2)) {
    heff_drop(v_k_242);
    heff_drop(v_from_243);
    return NTAG(TAG_Nil);
  } else {
    V v_more_245 = heff_intAdd_lent(v_from_243, MK_INT(1LL), 2);
    V v_t_246;
    if ((heff_dup(v_greedy_240) == NTAG(TAG_True))) {
      v_t_246 = heff_tag_n(TAG_Fork, 2, (V[]){v_more_245, heff_dup(v_end_244)});
    } else {
      v_t_246 = heff_tag_n(TAG_Fork, 2, (V[]){heff_dup(v_end_244), v_more_245});
    }
    V v_t_247 = (g_regex_2eemit(heff_dup(v_x_241), heff_intAdd_lent(v_from_243, MK_INT(1LL), 2)));
    V v_t_248 = (g_regex_2esizeOf(v_x_241));
    V v_t_249 = heff_intAdd(heff_intAdd(v_from_243, v_t_248), MK_INT(1LL));
    V v_t_2410 = (g_regex_2eemit_2eemitOptional_241(v_greedy_240, v_x_241, heff_intSub(v_k_242, MK_INT(1LL)), v_t_249, v_end_244));
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_247, v_t_2410));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2411});
  }
}
V g_regex_2eemit_2eemitOptional_241_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_regex_2eemit_2eemitOptional_241(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}