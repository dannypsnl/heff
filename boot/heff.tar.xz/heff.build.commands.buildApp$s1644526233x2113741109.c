// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define LBL_fuel 9649789
#define LBL_run 322821
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_str0, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_str1, 7, "main.hf");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0(V v_a_240, V v_x_241, V v_st_242, V v_t_243, V v_x_244, V v_x_245, V v_next_246, V v_p_247, V v_p_248, V v_x_249) {
top: ;
  V v_fuel_2410 = heff_take_field(v_a_240, 3);
  V v_run_2411 = heff_get_n(v_a_240, 1, 6);
  V v_n_2412 = heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_str0));
  V v_a_2413 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_242), heff_dup(v_t_243), heff_dup(v_x_241)));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_a_2413));
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_242), v_n_2412));
  V v_t_2416 = (g_std_2epath_2ejoin(v_t_2414, v_t_2415));
  V v_t_2417 = ({ V a_0 = v_st_242; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_242, v_t_243, v_x_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_str1)));
  return ({ V a_0 = v_fuel_2410; V b_1 = heff_tag_n(TAG_Just, 1, (V[]){v_run_2411}); V a_2 = v_t_2417; V a_3 = v_t_2418; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam0, 2, 3, (V[]){v_x_244, v_x_245, v_next_246}); V a_5 = v_p_247; V a_6 = v_p_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886(a_0, b_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(b_1); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a9 = a[9]; V r = g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a9); heff_drop(a9); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_next_246 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  heff_drop(v_x_2426);
  heff_clo_take(self, 3);
  V f_ = v_next_246;
  heff_room[0] = v_hd_2419;
  heff_room[1] = v_k_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_next_246 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_drop(v_x_2423);
  heff_clo_take(self, 4);
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){v_x_245, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_2419), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam2, 1, 3, (V[]){v_next_246, v_hd_2419, v_k_2420})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_next_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){v_x_244, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_2419), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1644526233x2113741109_2ek_24l0_lam1, 1, 4, (V[]){v_x_245, v_hd_2419, v_next_246, v_k_2420})));
}