// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_HError 21467
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2efoldl_2efoldlFrom_240(V, V, V, V);
V g_array_2efoldl_2efoldlFrom_240_entry(V self, V *a);
extern Clo g_array_2efoldl_2efoldlFrom_240_clo;
V g_heff_2eelab_2eeval_2eerrorHeaded(V);
V g_heff_2eelab_2eeval_2eerrorHeaded_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eerrorHeaded_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0(V, V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0(V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2eebind(V, V);
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_clo;
V g_heff_2eelab_2evalue_2eebind_24tok1(V, V, V);
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo;
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263(V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_clo;
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1(V, V);
V g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2ereflect(V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_clo;
V g_heff_2eelab_2evalue_2ereflect_24tok2(V, V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24tok2_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_heff_2eelab_2evalue_2especialize_24tok3(V, V, V, V);
V g_heff_2eelab_2evalue_2especialize_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_24tok3_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2eelab_2eeval_2eerrorHeaded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eerrorHeaded_entry, 1, 0};

V g_heff_2eelab_2eeval_2eerrorHeaded(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    V v_t_244 = heff_field(v_x1_240, 0);
    V t_0 = v_t_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    V v_t_249 = heff_field(v_x1_240, 0);
    V t_0 = v_t_249;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    V v_t_2415 = heff_field(v_x1_240, 0);
    V t_0 = v_t_2415;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eeval_2eerrorHeaded_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eeval_2eerrorHeaded(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7(V self, V *args);

HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SU = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_242_24SU, TAG_VU, 1, (V[]){v_u_244})}});
  }
  case TAG_SDecode: {
    V v_t_245 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_t_246 = (g_heff_2eelab_2eeval_2eerrorHeaded(v_t_245));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      heff_drop(v_t_246);
      V v_t_249 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0_clo), ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1_clo)});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_249}});
    } else {
      heff_drop(v_t_246);
      V v_t_2410 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, v_c_241, v_t_245, heff_dup(v_vs_243)));
      return ({ V a_0 = v_t_2410; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop(v_t_2410); r_; });
    }
  }
  case TAG_SFunction: {
    V v_level_2411 = heff_field(v_x4_242, 0);
    V v_dom_2412 = heff_field(v_x4_242, 1);
    V v_cod_2413 = heff_field(v_x4_242, 2);
    V v_implicit_2414 = heff_field(v_x4_242, 3);
    V v_dflt_2415 = heff_field(v_x4_242, 4);
    heff_take_n(v_x4_242, 31ULL, 5);
    HeffT2 v_t_2416 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_dom_2412, v_vs_243));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      V v_t_2422;
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_x_2419 = v_field_2418;
        v_t_2422 = v_x_2419;
      } else {
        if ((v_tag_2417 == ((int64_t)1ULL))) {
          V v_x11_2420 = v_field_2418;
          heff_drop(v_x11_2420);
          v_t_2422 = heff_abandon();
        } else {
          V v_x_2421 = v_field_2418;
          v_t_2422 = v_x_2421;
        }
      }
      V v_t_2428;
      switch (heff_tag_of(v_cod_2413)) {
      case TAG_MkAbs: {
        V v_x_2423 = heff_field(v_cod_2413, 0);
        V v_t_2424 = heff_field(v_cod_2413, 1);
        heff_take_n(v_cod_2413, 3ULL, 2);
        v_t_2428 = heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2423, heff_dup(v_vs_243), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2, 1, 2, (V[]){heff_dup(v_g_240), v_t_2424})});
        break;
      }
      case TAG_AbsConst: {
        V v_t_2426 = heff_field(v_cod_2413, 0);
        V v_ru_24cod_2413_24AbsConst = heff_take_reuse_n(v_cod_2413, 1ULL, 1);
        V v_t_2427 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_t_2426, v_vs_243));
        v_t_2428 = heff_tag_at_n(v_ru_24cod_2413_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2427});
        break;
      }
      default: heff_nomatch(v_cod_2413);
      }
      V v_t_2429 = heff_tag_n(TAG_VFunction, 6, (V[]){v_level_2411, v_t_2422, v_t_2428, v_implicit_2414, v_dflt_2415, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_t_2429}});
    }
  }
  case TAG_SRecord: {
    V v_level_2430 = heff_field(v_x4_242, 0);
    V v_fieldTypes_2431 = heff_field(v_x4_242, 1);
    V v_defaults_2432 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_xs_2433 = heff_take_field(v_fieldTypes_2431, 2);
    V v_m_2434 = heff_arrayLength_lent(v_xs_2433, 0);
    V v_t_2447;
    if ((heff_peek_word(v_m_2434) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_2433);
      v_t_2447 = heff_arrayGenerate(v_m_2434, ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3_clo));
    } else {
      V v_t_2436 = heff_arrayIndex_lent(v_xs_2433, MK_INT(0LL), 2);
      V v_y_2445 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4, 1, 2, (V[]){heff_dup(v_g_240), v_t_2436});
      V v_t_2446 = heff_arrayKeepsAs_lent(v_xs_2433, v_y_2445, 0);
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_m_2434);
        heff_drop(v_t_2446);
        v_t_2447 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0(v_g_240, MK_INT(1LL), heff_arraySet(v_xs_2433, MK_INT(0LL), v_y_2445)));
      } else {
        heff_drop(v_t_2446);
        v_t_2447 = ({ V a_0 = v_xs_2433; V a_1 = v_g_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2434, v_y_2445); V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2433); r_; });
      }
    }
    V v_t_2448 = ({ V rv_2 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_fieldTypes_2431, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2449 = heff_tag_n(TAG_VRecord, 4, (V[]){v_level_2430, heff_dup(v_vs_243), v_t_2448, v_defaults_2432});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2449}});
  }
  case TAG_SSum: {
    V v_st_2450 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SSum = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_xs_2451 = heff_take_field(v_st_2450, 2);
    V v_m_2452 = heff_arrayLength_lent(v_xs_2451, 0);
    V v_t_2469;
    if ((heff_peek_word(v_m_2452) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_2451);
      v_t_2469 = heff_arrayGenerate(v_m_2452, ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5_clo));
    } else {
      V v_xs_2454 = heff_arrayIndex_lent(v_xs_2451, MK_INT(0LL), 2);
      V v_m_2455 = heff_arrayLength_lent(v_xs_2454, 0);
      V v_y_2467;
      if ((heff_peek_word(v_m_2455) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_2454);
        v_y_2467 = heff_arrayGenerate(v_m_2455, ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6_clo));
      } else {
        V v_t_2457 = heff_arrayIndex_lent(v_xs_2454, MK_INT(0LL), 2);
        V v_y_2465 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7, 1, 3, (V[]){heff_dup(v_g_240), v_t_2457, heff_dup(v_vs_243)});
        V v_t_2466 = heff_arrayKeepsAs_lent(v_xs_2454, v_y_2465, 0);
        if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
          heff_drop(v_m_2455);
          heff_drop(v_t_2466);
          v_y_2467 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1(v_g_240, v_vs_243, MK_INT(1LL), heff_arraySet(v_xs_2454, MK_INT(0LL), v_y_2465)));
        } else {
          heff_drop(v_t_2466);
          v_y_2467 = ({ V a_0 = v_xs_2454; V a_1 = v_g_240; V a_2 = v_vs_243; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_2455, v_y_2465); V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_2454); r_; });
        }
      }
      V v_t_2468 = heff_arrayKeepsAs_lent(v_xs_2451, v_y_2467, 0);
      if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
        heff_drop(v_m_2452);
        heff_drop(v_t_2468);
        v_t_2469 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2(v_g_240, v_vs_243, MK_INT(1LL), heff_arraySet(v_xs_2451, MK_INT(0LL), v_y_2467)));
      } else {
        heff_drop(v_t_2468);
        v_t_2469 = ({ V a_0 = v_xs_2451; V a_1 = v_g_240; V a_2 = v_vs_243; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_2452, v_y_2467); V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_2451); r_; });
      }
    }
    V v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_st_2450, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_f_2471 = heff_tag_at_n(v_ru_24x4_242_24SSum, TAG_VSum, 1, (V[]){v_t_2470});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2471}});
  }
  case TAG_SIsTy: {
    V v_t_2472 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2473 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_t_2472, v_vs_243));
    {
      V v_field_2475 = v_t_2473.f[1];
      int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
      V v_t_2479;
      if ((v_tag_2474 == ((int64_t)0ULL))) {
        V v_x_2476 = v_field_2475;
        v_t_2479 = v_x_2476;
      } else {
        if ((v_tag_2474 == ((int64_t)1ULL))) {
          V v_x11_2477 = v_field_2475;
          heff_drop(v_x11_2477);
          v_t_2479 = heff_abandon();
        } else {
          V v_x_2478 = v_field_2475;
          v_t_2479 = v_x_2478;
        }
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2479}});
    }
  }
  case TAG_SPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimInt)}});
  }
  case TAG_SPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimFloat)}});
  }
  case TAG_SPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimString)}});
  }
  case TAG_SPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), NTAG(TAG_VPrimRune)}});
  }
  case TAG_SPrimArray: {
    V v_a_2480 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimArray = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2481 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), v_a_2480, v_vs_243));
    {
      V v_field_2483 = v_t_2481.f[1];
      int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
      V v_t_2487;
      if ((v_tag_2482 == ((int64_t)0ULL))) {
        V v_x_2484 = v_field_2483;
        v_t_2487 = v_x_2484;
      } else {
        if ((v_tag_2482 == ((int64_t)1ULL))) {
          V v_x11_2485 = v_field_2483;
          heff_drop(v_x11_2485);
          v_t_2487 = heff_abandon();
        } else {
          V v_x_2486 = v_field_2483;
          v_t_2487 = v_x_2486;
        }
      }
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_242_24SPrimArray, TAG_VPrimArray, 1, (V[]){v_t_2487})}});
    }
  }
  case TAG_SFixed: {
    V v_w_2488 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_VFixed, 1, (V[]){v_w_2488})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam0(V self, V *args) {
  V v_x_247 = args[0];
  heff_drop(v_x_247);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam1(V self, V *args) {
  V v_x_248 = args[0];
  heff_drop(v_x_248);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam2(V self, V *args) {
  V v_vs2_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_2424; V a_3 = v_vs2_2425; V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs2_2425); r_; });
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam3(V self, V *args) {
  V v_u_2435 = args[0];
  heff_drop(v_u_2435);
  return heff_abandon();
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam4(V self, V *args) {
  V v_vs2_2437 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2438 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_2436; V a_3 = v_vs2_2437; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs2_2437); r_; });
  {
    V v_field_2440 = v_t_2438.f[1];
    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
    V v_t_2444;
    if ((v_tag_2439 == ((int64_t)0ULL))) {
      V v_x_2441 = v_field_2440;
      v_t_2444 = v_x_2441;
    } else {
      if ((v_tag_2439 == ((int64_t)1ULL))) {
        V v_x11_2442 = v_field_2440;
        heff_drop(v_x11_2442);
        v_t_2444 = heff_abandon();
      } else {
        V v_x_2443 = v_field_2440;
        v_t_2444 = v_x_2443;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2444, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam5(V self, V *args) {
  V v_u_2453 = args[0];
  heff_drop(v_u_2453);
  return heff_abandon();
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam6(V self, V *args) {
  V v_u_2456 = args[0];
  heff_drop(v_u_2456);
  return heff_abandon();
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_2457 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_drop(v_u_2458);
  heff_clo_take(self, 3);
  HeffT2 v_t_2459 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_2457; V a_3 = v_vs_243; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs_243); r_; });
  {
    V v_field_2461 = v_t_2459.f[1];
    int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
    if ((v_tag_2460 == ((int64_t)0ULL))) {
      V v_x_2462 = v_field_2461;
      return v_x_2462;
    } else {
      if ((v_tag_2460 == ((int64_t)1ULL))) {
        V v_x11_2463 = v_field_2461;
        heff_drop(v_x11_2463);
        return heff_abandon();
      } else {
        V v_x_2464 = v_field_2461;
        return v_x_2464;
      }
    }
  }
}
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, v_c_241, v_x4_242, v_vs_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Become, 1, (V[]){v_field_246});
    } else {
      if ((v_tag_245 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_field_246});
      } else {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_field_246});
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_lam1(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0(V v_xs_240, V v_g_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_t_2413 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_lam0, 1, 2, (V[]){heff_dup(v_g_241), v_t_244}));
      V t_0 = v_xs_240;
      V t_1 = v_g_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_2413;
      v_xs_240 = t_0;
      v_g_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_t_2413 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_lam1, 1, 2, (V[]){heff_dup(v_g_241), v_t_244}));
    V t_0 = v_xs_240;
    V t_1 = v_g_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = v_t_2413;
    v_xs_240 = t_0;
    v_g_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_lam0(V self, V *args) {
  V v_vs2_245 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_246 = ({ V a_0 = v_g_241; V a_1 = NTAG(TAG_N); V a_2 = v_t_244; V a_3 = v_vs2_245; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); heff_drop(v_vs2_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_t_2412;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      v_t_2412 = v_x_249;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2410 = v_field_248;
        heff_drop(v_x11_2410);
        v_t_2412 = heff_abandon();
      } else {
        V v_x_2411 = v_field_248;
        v_t_2412 = v_x_2411;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2412, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate0_lam1(V self, V *args) {
  V v_vs2_245 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_246 = ({ V a_0 = v_g_241; V a_1 = NTAG(TAG_N); V a_2 = v_t_244; V a_3 = v_vs2_245; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); heff_drop(v_vs2_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_t_2412;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      v_t_2412 = v_x_249;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2410 = v_field_248;
        heff_drop(v_x11_2410);
        v_t_2412 = heff_abandon();
      } else {
        V v_x_2411 = v_field_248;
        v_t_2412 = v_x_2411;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2412, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_lam1(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_entry, 3, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0(V v_g_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_2412 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_lam0, 1, 2, (V[]){heff_dup(v_g_240), v_t_243}));
      V t_0 = v_g_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_t_2412;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_2412 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_lam1, 1, 2, (V[]){heff_dup(v_g_240), v_t_243}));
    V t_0 = v_g_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_2412;
    v_g_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_lam0(V self, V *args) {
  V v_vs2_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_245 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_243; V a_3 = v_vs2_244; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs2_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_t_2411;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_t_2411 = v_x_248;
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        V v_x11_249 = v_field_247;
        heff_drop(v_x11_249);
        v_t_2411 = heff_abandon();
      } else {
        V v_x_2410 = v_field_247;
        v_t_2411 = v_x_2410;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2411, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map0_lam1(V self, V *args) {
  V v_vs2_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_245 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_243; V a_3 = v_vs2_244; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs2_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_t_2411;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_t_2411 = v_x_248;
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        V v_x11_249 = v_field_247;
        heff_drop(v_x11_249);
        v_t_2411 = heff_abandon();
      } else {
        V v_x_2410 = v_field_247;
        v_t_2411 = v_x_2410;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2411, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_lam1(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1(V v_xs_240, V v_g_241, V v_vs_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if (((((int64_t)0ULL) <= v_i_243) && (heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_t_245 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_243), 2);
      V v_t_2413 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_lam0, 1, 3, (V[]){heff_dup(v_g_241), v_t_245, heff_dup(v_vs_242)}));
      V t_0 = v_xs_240;
      V t_1 = v_g_241;
      V t_2 = v_vs_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = v_t_2413;
      v_xs_240 = t_0;
      v_g_241 = t_1;
      v_vs_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_t_245 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_243), 2);
    V v_t_2413 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_lam1, 1, 3, (V[]){heff_dup(v_g_241), v_t_245, heff_dup(v_vs_242)}));
    V t_0 = v_xs_240;
    V t_1 = v_g_241;
    V t_2 = v_vs_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = v_t_2413;
    v_xs_240 = t_0;
    v_g_241 = t_1;
    v_vs_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    return v_a_244;
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_lam0(V self, V *args) {
  V v_u_246 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_drop(v_u_246);
  heff_clo_take(self, 3);
  HeffT2 v_t_247 = ({ V a_0 = v_g_241; V a_1 = NTAG(TAG_N); V a_2 = v_t_245; V a_3 = v_vs_242; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); heff_drop(v_vs_242); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      return v_x_2410;
    } else {
      if ((v_tag_248 == ((int64_t)1ULL))) {
        V v_x11_2411 = v_field_249;
        heff_drop(v_x11_2411);
        return heff_abandon();
      } else {
        V v_x_2412 = v_field_249;
        return v_x_2412;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1_lam1(V self, V *args) {
  V v_u_246 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_drop(v_u_246);
  heff_clo_take(self, 3);
  HeffT2 v_t_247 = ({ V a_0 = v_g_241; V a_1 = NTAG(TAG_N); V a_2 = v_t_245; V a_3 = v_vs_242; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); heff_drop(v_vs_242); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      return v_x_2410;
    } else {
      if ((v_tag_248 == ((int64_t)1ULL))) {
        V v_x11_2411 = v_field_249;
        heff_drop(v_x11_2411);
        return heff_abandon();
      } else {
        V v_x_2412 = v_field_249;
        return v_x_2412;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_lam1(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1(V v_g_240, V v_vs_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if ((((int64_t)0ULL) <= v_i_242)) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t_244 = heff_arrayIndexIn_lent(v_a_243, heff_box_word(v_i_242), 2);
      V v_t_2412 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_lam0, 1, 3, (V[]){heff_dup(v_g_240), v_t_244, heff_dup(v_vs_241)}));
      V t_0 = v_g_240;
      V t_1 = v_vs_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_2412;
      v_g_240 = t_0;
      v_vs_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t_244 = heff_arrayIndex_lent(v_a_243, heff_box_word(v_i_242), 2);
    V v_t_2412 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_lam1, 1, 3, (V[]){heff_dup(v_g_240), v_t_244, heff_dup(v_vs_241)}));
    V t_0 = v_g_240;
    V t_1 = v_vs_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = v_t_2412;
    v_g_240 = t_0;
    v_vs_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  V v_vs_241 = heff_env(self)[2];
  heff_drop(v_u_245);
  heff_clo_take(self, 3);
  HeffT2 v_t_246 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_244; V a_3 = v_vs_241; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs_241); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      return v_x_249;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2410 = v_field_248;
        heff_drop(v_x11_2410);
        return heff_abandon();
      } else {
        V v_x_2411 = v_field_248;
        return v_x_2411;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1_lam1(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  V v_vs_241 = heff_env(self)[2];
  heff_drop(v_u_245);
  heff_clo_take(self, 3);
  HeffT2 v_t_246 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_244; V a_3 = v_vs_241; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs_241); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      return v_x_249;
    } else {
      if ((v_tag_247 == ((int64_t)1ULL))) {
        V v_x11_2410 = v_field_248;
        heff_drop(v_x11_2410);
        return heff_abandon();
      } else {
        V v_x_2411 = v_field_248;
        return v_x_2411;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam0, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam2(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam2, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam3(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2(V v_xs_240, V v_g_241, V v_vs_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if (((((int64_t)0ULL) <= v_i_243) && (heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_xs_245 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_243), 2);
      V v_m_246 = heff_arrayLength_lent(v_xs_245, 0);
      V v_t_2418;
      if ((heff_peek_word(v_m_246) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_245);
        v_t_2418 = heff_arrayGenerate(v_m_246, ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam0_clo));
      } else {
        V v_t_248 = heff_arrayIndex_lent(v_xs_245, MK_INT(0LL), 2);
        V v_y_2416 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam1, 1, 3, (V[]){heff_dup(v_g_241), v_t_248, heff_dup(v_vs_242)});
        V v_t_2417 = heff_arrayKeepsAs_lent(v_xs_245, v_y_2416, 0);
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_m_246);
          heff_drop(v_t_2417);
          v_t_2418 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1(v_g_241, v_vs_242, MK_INT(1LL), heff_arraySet(v_xs_245, MK_INT(0LL), v_y_2416)));
        } else {
          heff_drop(v_t_2417);
          v_t_2418 = ({ V a_0 = v_xs_245; V a_1 = v_g_241; V a_2 = v_vs_242; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_246, v_y_2416); V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_245); r_; });
        }
      }
      V t_0 = v_xs_240;
      V t_1 = v_g_241;
      V t_2 = v_vs_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_2418);
      v_xs_240 = t_0;
      v_g_241 = t_1;
      v_vs_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_xs_245 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_243), 2);
    V v_m_246 = heff_arrayLength_lent(v_xs_245, 0);
    V v_t_2418;
    if ((heff_peek_word(v_m_246) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_245);
      v_t_2418 = heff_arrayGenerate(v_m_246, ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam2_clo));
    } else {
      V v_t_248 = heff_arrayIndex_lent(v_xs_245, MK_INT(0LL), 2);
      V v_y_2416 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam3, 1, 3, (V[]){heff_dup(v_g_241), v_t_248, heff_dup(v_vs_242)});
      V v_t_2417 = heff_arrayKeepsAs_lent(v_xs_245, v_y_2416, 0);
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_m_246);
        heff_drop(v_t_2417);
        v_t_2418 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1(v_g_241, v_vs_242, MK_INT(1LL), heff_arraySet(v_xs_245, MK_INT(0LL), v_y_2416)));
      } else {
        heff_drop(v_t_2417);
        v_t_2418 = ({ V a_0 = v_xs_245; V a_1 = v_g_241; V a_2 = v_vs_242; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_246, v_y_2416); V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_245); r_; });
      }
    }
    V t_0 = v_xs_240;
    V t_1 = v_g_241;
    V t_2 = v_vs_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_2418);
    v_xs_240 = t_0;
    v_g_241 = t_1;
    v_vs_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    return v_a_244;
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam0(V self, V *args) {
  V v_u_247 = args[0];
  heff_drop(v_u_247);
  return heff_abandon();
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_t_248 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_drop(v_u_249);
  heff_clo_take(self, 3);
  HeffT2 v_t_2410 = ({ V a_0 = v_g_241; V a_1 = NTAG(TAG_N); V a_2 = v_t_248; V a_3 = v_vs_242; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); heff_drop(v_vs_242); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      return v_x_2413;
    } else {
      if ((v_tag_2411 == ((int64_t)1ULL))) {
        V v_x11_2414 = v_field_2412;
        heff_drop(v_x11_2414);
        return heff_abandon();
      } else {
        V v_x_2415 = v_field_2412;
        return v_x_2415;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam2(V self, V *args) {
  V v_u_247 = args[0];
  heff_drop(v_u_247);
  return heff_abandon();
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate2_lam3(V self, V *args) {
  V v_u_249 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_t_248 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  heff_drop(v_u_249);
  heff_clo_take(self, 3);
  HeffT2 v_t_2410 = ({ V a_0 = v_g_241; V a_1 = NTAG(TAG_N); V a_2 = v_t_248; V a_3 = v_vs_242; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_241); heff_drop(v_vs_242); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      return v_x_2413;
    } else {
      if ((v_tag_2411 == ((int64_t)1ULL))) {
        V v_x11_2414 = v_field_2412;
        heff_drop(v_x11_2414);
        return heff_abandon();
      } else {
        V v_x_2415 = v_field_2412;
        return v_x_2415;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam0(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam0, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam2(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam2, 1, 0};
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam3(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2(V v_g_240, V v_vs_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if ((((int64_t)0ULL) <= v_i_242)) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_xs_244 = heff_arrayIndexIn_lent(v_a_243, heff_box_word(v_i_242), 2);
      V v_m_245 = heff_arrayLength_lent(v_xs_244, 0);
      V v_t_2417;
      if ((heff_peek_word(v_m_245) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_244);
        v_t_2417 = heff_arrayGenerate(v_m_245, ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam0_clo));
      } else {
        V v_t_247 = heff_arrayIndex_lent(v_xs_244, MK_INT(0LL), 2);
        V v_y_2415 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam1, 1, 3, (V[]){heff_dup(v_g_240), v_t_247, heff_dup(v_vs_241)});
        V v_t_2416 = heff_arrayKeepsAs_lent(v_xs_244, v_y_2415, 0);
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_m_245);
          heff_drop(v_t_2416);
          v_t_2417 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1(v_g_240, v_vs_241, MK_INT(1LL), heff_arraySet(v_xs_244, MK_INT(0LL), v_y_2415)));
        } else {
          heff_drop(v_t_2416);
          v_t_2417 = ({ V a_0 = v_xs_244; V a_1 = v_g_240; V a_2 = v_vs_241; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_245, v_y_2415); V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_244); r_; });
        }
      }
      V t_0 = v_g_240;
      V t_1 = v_vs_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_2417);
      v_g_240 = t_0;
      v_vs_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_xs_244 = heff_arrayIndex_lent(v_a_243, heff_box_word(v_i_242), 2);
    V v_m_245 = heff_arrayLength_lent(v_xs_244, 0);
    V v_t_2417;
    if ((heff_peek_word(v_m_245) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_244);
      v_t_2417 = heff_arrayGenerate(v_m_245, ((V)&g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam2_clo));
    } else {
      V v_t_247 = heff_arrayIndex_lent(v_xs_244, MK_INT(0LL), 2);
      V v_y_2415 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam3, 1, 3, (V[]){heff_dup(v_g_240), v_t_247, heff_dup(v_vs_241)});
      V v_t_2416 = heff_arrayKeepsAs_lent(v_xs_244, v_y_2415, 0);
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_m_245);
        heff_drop(v_t_2416);
        v_t_2417 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map1(v_g_240, v_vs_241, MK_INT(1LL), heff_arraySet(v_xs_244, MK_INT(0LL), v_y_2415)));
      } else {
        heff_drop(v_t_2416);
        v_t_2417 = ({ V a_0 = v_xs_244; V a_1 = v_g_240; V a_2 = v_vs_241; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_245, v_y_2415); V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24generate1(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_244); r_; });
      }
    }
    V t_0 = v_g_240;
    V t_1 = v_vs_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_2417);
    v_g_240 = t_0;
    v_vs_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam0(V self, V *args) {
  V v_u_246 = args[0];
  heff_drop(v_u_246);
  return heff_abandon();
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_vs_241 = heff_env(self)[2];
  heff_drop(v_u_248);
  heff_clo_take(self, 3);
  HeffT2 v_t_249 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_247; V a_3 = v_vs_241; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs_241); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2411;
      return v_x_2412;
    } else {
      if ((v_tag_2410 == ((int64_t)1ULL))) {
        V v_x11_2413 = v_field_2411;
        heff_drop(v_x11_2413);
        return heff_abandon();
      } else {
        V v_x_2414 = v_field_2411;
        return v_x_2414;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam2(V self, V *args) {
  V v_u_246 = args[0];
  heff_drop(v_u_246);
  return heff_abandon();
}
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24map2_lam3(V self, V *args) {
  V v_u_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_vs_241 = heff_env(self)[2];
  heff_drop(v_u_248);
  heff_clo_take(self, 3);
  HeffT2 v_t_249 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_247; V a_3 = v_vs_241; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs_241); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2411;
      return v_x_2412;
    } else {
      if ((v_tag_2410 == ((int64_t)1ULL))) {
        V v_x11_2413 = v_field_2411;
        heff_drop(v_x11_2413);
        return heff_abandon();
      } else {
        V v_x_2414 = v_field_2411;
        return v_x_2414;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam0(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam2(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam1(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam4(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam3(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam5(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam6(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam7(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam8(V self, V *args); static Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam8, 1, 0};
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam9(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam10(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam11(V self, V *args);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam12(V self, V *args);
Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry, 4, 0};

V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V v_g_240, V v_c_241, V v_x4_242, V v_vs_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SLocal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_245 = ({ V a_0 = v_vs_243; V a_1 = v_i_244; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_243); r_; });
    return heff_tag_at_n(v_ru_24x4_242_24SLocal, TAG_Nom, 1, (V[]){v_t_245});
  }
  case TAG_SGlobal: {
    V v_x_246 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SGlobal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_vs_243);
    HeffT2 v_t_247 = ({ V a_0 = heff_rfield(v_g_240, 1); V a_1 = v_x_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_246); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2411;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_e_2410 = v_field_249;
        v_t_2411 = v_e_2410;
      } else {
        heff_drop(v_field_249);
        v_t_2411 = heff_abandon();
      }
      return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_Nom, 1, (V[]){heff_get_n(v_t_2411, 2, 4)});
    }
  }
  case TAG_SCode: {
    V v_a_2412 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SCode = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_2413 = ({ V a_0 = v_g_240; V a_1 = v_c_241; V a_2 = v_a_2412; V a_3 = v_vs_243; V r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(a_0, a_1, a_2, a_3)); heff_drop(v_vs_243); r_; });
    return (g_heff_2eelab_2evalue_2eemap_24s1669819568x2005029263_24tok1(v_ru_24x4_242_24SCode, v_t_2413));
  }
  case TAG_SApp: {
    V v_x41_2414 = heff_field(v_x4_242, 0);
    V v_t1_2415 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SApp = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_2414)) {
    case TAG_SLam: {
      V v_x412_2417 = heff_dup(heff_field(v_x41_2414, 1));
      switch (heff_tag_of(v_x412_2417)) {
      case TAG_MkAbs: {
        V v_t_2419 = heff_field(v_x412_2417, 1);
        heff_take_n(v_x412_2417, 2ULL, 2);
        switch (heff_tag_of(v_x41_2414)) {
        case TAG_SLam: {
          heff_take_n(v_x41_2414, 0ULL, 2);
          V t_0 = v_g_240;
          V t_1 = v_c_241;
          V t_2 = v_t_2419;
          V t_3 = heff_tag_at_n(v_ru_24x4_242_24SApp, TAG_LSnoc, 2, (V[]){heff_dup(v_vs_243), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam0, 1, 3, (V[]){heff_dup(v_g_240), v_t1_2415, v_vs_243})});
          v_g_240 = t_0;
          v_c_241 = t_1;
          v_x4_242 = t_2;
          v_vs_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_x41_2414);
        }
      }
      case TAG_AbsConst: {
        V v_ru_24x412_2417_24AbsConst = heff_take_reuse_n(v_x412_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_242_24SApp, 2);
        V v_t_2428 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, NTAG(TAG_N), v_x41_2414, heff_dup(v_vs_243)));
        return (g_heff_2eelab_2evalue_2eebind_24tok1(v_ru_24x412_2417_24AbsConst, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam1, 1, 3, (V[]){heff_dup(v_g_240), v_t1_2415, v_vs_243}), v_t_2428));
      }
      default: return heff_nomatch(v_x412_2417);
      }
    }
    default: {
      heff_drop_cell(v_ru_24x4_242_24SApp, 2);
      V v_t_2435 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, NTAG(TAG_N), v_x41_2414, heff_dup(v_vs_243)));
      return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam3, 1, 3, (V[]){heff_dup(v_g_240), v_t1_2415, v_vs_243}), v_t_2435));
    }
    }
  }
  case TAG_SLam: {
    V v_dom_2442 = heff_field(v_x4_242, 0);
    V v_x42_2443 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SLam = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_2443)) {
    case TAG_MkAbs: {
      V v_x_2444 = heff_field(v_x42_2443, 0);
      V v_t_2445 = heff_field(v_x42_2443, 1);
      heff_take_n(v_x42_2443, 3ULL, 2);
      V v_x_2454 = heff_tag_at_n(v_ru_24x4_242_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam5, 1, 3, (V[]){heff_dup(v_g_240), v_dom_2442, heff_dup(v_vs_243)}), heff_tag_n(TAG_MkClo, 3, (V[]){v_x_2444, v_vs_243, heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam6, 1, 3, (V[]){heff_dup(v_g_240), heff_dup(v_c_241), v_t_2445})})});
      switch (heff_tag_of(v_c_241)) {
      case TAG_N: {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2454});
      }
      case TAG_De: {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2454});
      }
      default: return heff_nomatch(v_c_241);
      }
    }
    case TAG_AbsConst: {
      V v_t_2455 = heff_field(v_x42_2443, 0);
      V v_ru_24x42_2443_24AbsConst = heff_take_reuse_n(v_x42_2443, 1ULL, 1);
      V v_t_2456 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, v_c_241, v_t_2455, heff_dup(v_vs_243)));
      V v_x_2464 = heff_tag_at_n(v_ru_24x4_242_24SLam, TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam7, 1, 3, (V[]){heff_dup(v_g_240), v_dom_2442, v_vs_243}), heff_tag_at_n(v_ru_24x42_2443_24AbsConst, TAG_CloConst, 1, (V[]){v_t_2456})});
      switch (heff_tag_of(v_c_241)) {
      case TAG_N: {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2464});
      }
      case TAG_De: {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2464});
      }
      default: return heff_nomatch(v_c_241);
      }
    }
    default: return heff_nomatch(v_x42_2443);
    }
  }
  case TAG_SCons: {
    V v_fields_2465 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SCons = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_xs_2466 = heff_take_field(v_fields_2465, 2);
    V v_m_2467 = heff_arrayLength_lent(v_xs_2466, 0);
    V v_t_2472;
    if ((heff_peek_word(v_m_2467) <= ((int64_t)0ULL))) {
      heff_drop(v_vs_243);
      heff_drop(v_xs_2466);
      v_t_2472 = heff_arrayGenerate(v_m_2467, ((V)&g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam8_clo));
    } else {
      V v_t_2469 = heff_arrayIndex_lent(v_xs_2466, MK_INT(0LL), 2);
      V v_y_2470 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, v_c_241, v_t_2469, heff_dup(v_vs_243)));
      V v_t_2471 = heff_arrayKeepsAs_lent(v_xs_2466, v_y_2470, 0);
      if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
        heff_drop(v_m_2467);
        heff_drop(v_t_2471);
        v_t_2472 = ({ V a_0 = v_g_240; V a_1 = v_c_241; V a_2 = v_vs_243; V a_3 = MK_INT(1LL); V a_4 = heff_arraySet(v_xs_2466, MK_INT(0LL), v_y_2470); V r_ = (g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_vs_243); r_; });
      } else {
        heff_drop(v_t_2471);
        v_t_2472 = ({ V a_0 = v_xs_2466; V a_1 = v_g_240; V a_2 = v_c_241; V a_3 = v_vs_243; V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_2467, v_y_2470); V r_ = (g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_2466); heff_drop(v_vs_243); r_; });
      }
    }
    V v_t_2473 = ({ V rv_2 = v_t_2472; V rr_ = heff_rec_reuse_nf(v_fields_2465, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_x_2474 = heff_tag_at_n(v_ru_24x4_242_24SCons, TAG_VCons, 1, (V[]){v_t_2473});
    switch (heff_tag_of(v_c_241)) {
    case TAG_N: {
      return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2474});
    }
    case TAG_De: {
      return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2474});
    }
    default: return heff_nomatch(v_c_241);
    }
  }
  case TAG_SProj: {
    V v_t_2475 = heff_field(v_x4_242, 0);
    V v_x_2476 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_2477 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, NTAG(TAG_N), v_t_2475, v_vs_243));
    return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam9, 1, 1, (V[]){v_x_2476}), v_t_2477));
  }
  case TAG_STag: {
    heff_take_n(v_x4_242, 0ULL, 2);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMatch: {
    heff_take_n(v_x4_242, 0ULL, 2);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SSpecialize: {
    V v_t_2496 = heff_field(v_x4_242, 0);
    V v_x_2497 = heff_field(v_x4_242, 1);
    V v_t_27_2498 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24SSpecialize = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_x1_2499 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, NTAG(TAG_N), v_t_2496, heff_dup(v_vs_243)));
    V v_t_24103;
    switch (heff_tag_of(v_x1_2499)) {
    case TAG_Nom: {
      V v_x_24100 = heff_field(v_x1_2499, 0);
      heff_take_n(v_x1_2499, 1ULL, 1);
      v_t_24103 = v_x_24100;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2499, 0ULL, 1);
      v_t_24103 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24102 = heff_field(v_x1_2499, 0);
      heff_take_n(v_x1_2499, 1ULL, 1);
      v_t_24103 = v_x_24102;
      break;
    }
    default: heff_nomatch(v_x1_2499);
    }
    V v_x1_24104 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, NTAG(TAG_N), v_t_27_2498, v_vs_243));
    V v_t_24108;
    switch (heff_tag_of(v_x1_24104)) {
    case TAG_Nom: {
      V v_x_24105 = heff_field(v_x1_24104, 0);
      heff_take_n(v_x1_24104, 1ULL, 1);
      v_t_24108 = v_x_24105;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24104, 0ULL, 1);
      v_t_24108 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24107 = heff_field(v_x1_24104, 0);
      heff_take_n(v_x1_24104, 1ULL, 1);
      v_t_24108 = v_x_24107;
      break;
    }
    default: heff_nomatch(v_x1_24104);
    }
    V v_t_24109 = (g_heff_2eelab_2evalue_2especialize_24tok3(v_ru_24x4_242_24SSpecialize, v_t_24103, v_x_2497, v_t_24108));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24109});
  }
  case TAG_SIs: {
    V v_t_24110 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SIs = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_x1_24111 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, NTAG(TAG_N), v_t_24110, v_vs_243));
    V v_t_24115;
    switch (heff_tag_of(v_x1_24111)) {
    case TAG_Nom: {
      V v_x_24112 = heff_field(v_x1_24111, 0);
      heff_take_n(v_x1_24111, 1ULL, 1);
      v_t_24115 = v_x_24112;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24111, 0ULL, 1);
      v_t_24115 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24114 = heff_field(v_x1_24111, 0);
      heff_take_n(v_x1_24111, 1ULL, 1);
      v_t_24115 = v_x_24114;
      break;
    }
    default: heff_nomatch(v_x1_24111);
    }
    return heff_tag_at_n(v_ru_24x4_242_24SIs, TAG_Become, 1, (V[]){v_t_24115});
  }
  case TAG_SOpaque: {
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SAbandon: {
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SRec: {
    V v_ru_24x4_242_24SRec = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SRec, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SFix: {
    heff_take_n(v_x4_242, 0ULL, 2);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SImplicit: {
    V v_e_24120 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_c_241;
    V t_2 = v_e_24120;
    V t_3 = v_vs_243;
    v_g_240 = t_0;
    v_c_241 = t_1;
    v_x4_242 = t_2;
    v_vs_243 = t_3;
    goto top;
  }
  case TAG_SPrim: {
    V v_ru_24x4_242_24SPrim = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SPrim, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SMetaApp: {
    V v_m_24122 = heff_field(v_x4_242, 0);
    V v_idxs_24123 = heff_field(v_x4_242, 1);
    V v_ty_24124 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_sp_24128 = ({ V a_0 = v_idxs_24123; V b_1 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam10, 2, 1, (V[]){heff_dup(v_vs_243)}); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_SpId); V r_ = (g_array_2efoldl_2efoldlFrom_240(a_0, b_1, a_2, a_3)); heff_drop(v_idxs_24123); heff_drop(b_1); r_; });
    HeffT2 v_t_24129 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_ty_24124; V a_3 = v_vs_243; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_vs_243); r_; });
    {
      V v_field_24131 = v_t_24129.f[1];
      int64_t v_tag_24130 = ((int64_t)v_t_24129.f[0]);
      V v_ty_24135;
      if ((v_tag_24130 == ((int64_t)0ULL))) {
        V v_x_24132 = v_field_24131;
        v_ty_24135 = v_x_24132;
      } else {
        if ((v_tag_24130 == ((int64_t)1ULL))) {
          V v_x11_24133 = v_field_24131;
          heff_drop(v_x11_24133);
          v_ty_24135 = heff_abandon();
        } else {
          V v_x_24134 = v_field_24131;
          v_ty_24135 = v_x_24134;
        }
      }
      V v_t_24138 = (g_heff_2eelab_2evalue_2ereflect(heff_tag_n(TAG_HMeta, 1, (V[]){v_m_24122}), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam11, 1, 1, (V[]){v_sp_24128}), heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam12, 1, 1, (V[]){v_ty_24135}), NTAG(TAG_Nothing)));
      return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24138});
    }
  }
  case TAG_SLitInt: {
    V v_ru_24x4_242_24SLitInt = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SLitInt, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat: {
    V v_ru_24x4_242_24SLitFloat = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SLitFloat, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitString: {
    V v_ru_24x4_242_24SLitString = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SLitString, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitBytes: {
    V v_ru_24x4_242_24SLitBytes = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SLitBytes, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitRune: {
    V v_ru_24x4_242_24SLitRune = heff_take_reuse_n(v_x4_242, 0ULL, 1);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SLitRune, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x4_242, 0ULL, 2);
    heff_drop(v_vs_243);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_SLitFloat32: {
    V v_ru_24x4_242_24SLitFloat32 = heff_take_reuse_na(v_x4_242, 0ULL, 1);
    heff_drop(v_vs_243);
    return heff_tag_at_n(v_ru_24x4_242_24SLitFloat32, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t1_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_drop(v_u_2422);
  heff_clo_take(self, 3);
  V v_x1_2423 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t1_2415; V a_3 = v_vs_243; V r_ = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop_rec(v_g_240, 8); r_; });
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_Nom: {
    V v_x_2424 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    return v_x_2424;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2423, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2426 = heff_field(v_x1_2423, 0);
    heff_take_n(v_x1_2423, 1ULL, 1);
    return v_x_2426;
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam2(V self, V *args) {
  V v_u_2430 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t1_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_drop(v_u_2430);
  heff_clo_take(self, 3);
  V v_x1_2431 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t1_2415; V a_3 = v_vs_243; V r_ = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop_rec(v_g_240, 8); r_; });
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nom: {
    V v_x_2432 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    return v_x_2432;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2434 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    return v_x_2434;
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam1(V self, V *args) {
  V v_f_2429 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t1_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_f_2429; V b_1 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam2, 1, 3, (V[]){v_g_240, v_t1_2415, v_vs_243}); V r_ = (g_heff_2eelab_2evalue_2eapp(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam4(V self, V *args) {
  V v_u_2437 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t1_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_drop(v_u_2437);
  heff_clo_take(self, 3);
  V v_x1_2438 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t1_2415; V a_3 = v_vs_243; V r_ = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop_rec(v_g_240, 8); r_; });
  switch (heff_tag_of(v_x1_2438)) {
  case TAG_Nom: {
    V v_x_2439 = heff_field(v_x1_2438, 0);
    heff_take_n(v_x1_2438, 1ULL, 1);
    return v_x_2439;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2438, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2441 = heff_field(v_x1_2438, 0);
    heff_take_n(v_x1_2438, 1ULL, 1);
    return v_x_2441;
  }
  default: return heff_nomatch(v_x1_2438);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam3(V self, V *args) {
  V v_f_2436 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t1_2415 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_f_2436; V b_1 = heff_clo_n(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam4, 1, 3, (V[]){v_g_240, v_t1_2415, v_vs_243}); V r_ = (g_heff_2eelab_2evalue_2eapp(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam5(V self, V *args) {
  V v_u_2446 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_dom_2442 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_drop(v_u_2446);
  heff_clo_take(self, 3);
  HeffT2 v_t_2447 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_dom_2442; V a_3 = v_vs_243; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop_rec(v_g_240, 8); heff_drop(v_vs_243); r_; });
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    if ((v_tag_2448 == ((int64_t)0ULL))) {
      V v_x_2450 = v_field_2449;
      return v_x_2450;
    } else {
      if ((v_tag_2448 == ((int64_t)1ULL))) {
        V v_x11_2451 = v_field_2449;
        heff_drop(v_x11_2451);
        return heff_abandon();
      } else {
        V v_x_2452 = v_field_2449;
        return v_x_2452;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam6(V self, V *args) {
  V v_vs2_2453 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  V v_t_2445 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_g_240; V a_1 = v_c_241; V a_2 = v_t_2445; V a_3 = v_vs2_2453; V r_ = (g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(a_0, a_1, a_2, a_3)); heff_drop_rec(v_g_240, 8); heff_drop(v_c_241); r_; });
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam7(V self, V *args) {
  V v_u_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_dom_2442 = heff_env(self)[1];
  V v_vs_243 = heff_env(self)[2];
  heff_drop(v_u_2457);
  heff_clo_take(self, 3);
  HeffT2 v_t_2458 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_dom_2442; V a_3 = v_vs_243; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop_rec(v_g_240, 8); heff_drop(v_vs_243); r_; });
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    if ((v_tag_2459 == ((int64_t)0ULL))) {
      V v_x_2461 = v_field_2460;
      return v_x_2461;
    } else {
      if ((v_tag_2459 == ((int64_t)1ULL))) {
        V v_x11_2462 = v_field_2460;
        heff_drop(v_x11_2462);
        return heff_abandon();
      } else {
        V v_x_2463 = v_field_2460;
        return v_x_2463;
      }
    }
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam8(V self, V *args) {
  V v_u_2468 = args[0];
  heff_drop(v_u_2468);
  return heff_abandon();
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam9(V self, V *args) {
  V v_v_2478 = args[0];
  V v_x_2476 = heff_env(self)[0];
  switch (heff_tag_of(v_v_2478)) {
  case TAG_VNeu: {
    V v_t_2484 = ({ V a_0 = v_v_2478; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_2478, 5); r_; });
    heff_clo_take(self, 1);
    return ({ V a_0 = v_t_2484; V a_1 = v_x_2476; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_2476); r_; });
  }
  case TAG_VCode: {
    V v_t_2486 = ({ V a_0 = v_v_2478; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_2478, 1); r_; });
    heff_clo_take(self, 1);
    return ({ V a_0 = v_t_2486; V a_1 = v_x_2476; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_2476); r_; });
  }
  case TAG_VLam: {
    V v_t_2489 = ({ V a_0 = v_v_2478; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_2478, 2); r_; });
    heff_clo_take(self, 1);
    return ({ V a_0 = v_t_2489; V a_1 = v_x_2476; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_2476); r_; });
  }
  case TAG_VCons: {
    V v_t_2491 = ({ V a_0 = v_v_2478; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_2478, 1); r_; });
    heff_clo_take(self, 1);
    return ({ V a_0 = v_t_2491; V a_1 = v_x_2476; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_2476); r_; });
  }
  case TAG_VOpaque: {
    heff_drop(self);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_v_2478);
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam10(V self, V *args) {
  V v_sp_24125 = args[0];
  V v_i_24126 = args[1];
  V v_vs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24127 = ({ V a_0 = v_vs_243; V a_1 = v_i_24126; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_vs_243); r_; });
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_24125, v_t_24127});
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam11(V self, V *args) {
  V v_u_24136 = args[0];
  V v_sp_24128 = heff_env(self)[0];
  heff_drop(v_u_24136);
  heff_clo_take(self, 1);
  return v_sp_24128;
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_lam12(V self, V *args) {
  V v_u_24137 = args[0];
  V v_ty_24135 = heff_env(self)[0];
  heff_drop(v_u_24137);
  heff_clo_take(self, 1);
  return v_ty_24135;
}
Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0_entry, 6, 0};

V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0(V v_xs_240, V v_g_241, V v_c_242, V v_vs_243, V v_box_24i_244, V v_a_245) {
  int64_t v_i_244 = heff_unbox_word(v_box_24i_244);
  v_a_245 = heff_arrayOwn(v_a_245);
  if (((((int64_t)0ULL) <= v_i_244) && (heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
      V v_t_246 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_244), 2);
      V v_t_247 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_241, v_c_242, v_t_246, heff_dup(v_vs_243)));
      V t_0 = v_xs_240;
      V t_1 = v_g_241;
      V t_2 = v_c_242;
      V t_3 = v_vs_243;
      int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
      V t_5 = heff_arraySetOwnedIn(v_a_245, heff_box_word(v_i_244), v_t_247);
      v_xs_240 = t_0;
      v_g_241 = t_1;
      v_c_242 = t_2;
      v_vs_243 = t_3;
      v_i_244 = t_4;
      v_a_245 = t_5;
      goto top_TAG_InRange;
    } else {
      return v_a_245;
    }
  } else {
  }
top: ;
  if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
    V v_t_246 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_244), 2);
    V v_t_247 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_241, v_c_242, v_t_246, heff_dup(v_vs_243)));
    V t_0 = v_xs_240;
    V t_1 = v_g_241;
    V t_2 = v_c_242;
    V t_3 = v_vs_243;
    int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
    V t_5 = heff_arraySetOwned(v_a_245, heff_box_word(v_i_244), v_t_247);
    v_xs_240 = t_0;
    v_g_241 = t_1;
    v_c_242 = t_2;
    v_vs_243 = t_3;
    v_i_244 = t_4;
    v_a_245 = t_5;
    goto top;
  } else {
    return v_a_245;
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24generate0(a0, a1, a2, a3, a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0_entry, 5, 0};

V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0(V v_g_240, V v_c_241, V v_vs_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if ((((int64_t)0ULL) <= v_i_243)) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_t_245 = heff_arrayIndexIn_lent(v_a_244, heff_box_word(v_i_243), 2);
      V v_t_246 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, v_c_241, v_t_245, heff_dup(v_vs_242)));
      V t_0 = v_g_240;
      V t_1 = v_c_241;
      V t_2 = v_vs_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_246);
      v_g_240 = t_0;
      v_c_241 = t_1;
      v_vs_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_t_245 = heff_arrayIndex_lent(v_a_244, heff_box_word(v_i_243), 2);
    V v_t_246 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(v_g_240, v_c_241, v_t_245, heff_dup(v_vs_242)));
    V t_0 = v_g_240;
    V t_1 = v_c_241;
    V t_2 = v_vs_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_246);
    v_g_240 = t_0;
    v_c_241 = t_1;
    v_vs_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    return v_a_244;
  }
}
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_24map0(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}