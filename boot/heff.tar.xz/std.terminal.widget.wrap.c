// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240(V, V, V);
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_clo;
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps(V, V, V, V);
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_entry(V self, V *a);
extern Clo g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_clo;
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_str1, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_str2, 1, " ");
Clo g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_entry, 3, 0};

V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240(V v_w_240, V v_line_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    if (heff_strEq_c_lent(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_str0), 2)) {
      heff_drop(v_line_241);
      return NTAG(TAG_Nil);
    } else {
      return heff_tag_n(TAG_Cons, 2, (V[]){v_line_241, NTAG(TAG_Nil)});
    }
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_243;
      V t_2 = v_xs_244;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      V v_t_245 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(heff_dup(v_line_241)); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_246 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(heff_dup(v_x_243)); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_247 = heff_intAdd(heff_intAdd(v_t_245, MK_INT(1LL)), v_t_246);
      if (heff_intLe_c_lent(v_t_247, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V v_t_248 = heff_strAppend(heff_strAppend(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_str2)), v_x_243);
        V t_0 = v_w_240;
        V t_1 = v_t_248;
        V t_2 = v_xs_244;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_line_241, heff_hole()});
        V v_u_2410 = (g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps(v_w_240, v_x_243, v_xs_244, v_cell_249));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_str0, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_str1, 0, "");
HEFF_LIT(g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_str2, 1, " ");
Clo g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_entry, 4, 0};

V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps(V v_w_240, V v_line_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    if (heff_strEq_c_lent(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_str0), 2)) {
      heff_drop(v_line_241);
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_line_241, NTAG(TAG_Nil)});
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_244);
    }
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_242, 0);
    V v_xs_246 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_245;
      V t_2 = v_xs_246;
      V t_3 = v_d_243;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      V v_t_247 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(heff_dup(v_line_241)); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_248 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_strRunes(heff_dup(v_x_245)); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_249 = heff_intAdd(heff_intAdd(v_t_247, MK_INT(1LL)), v_t_248);
      if (heff_intLe_c_lent(v_t_249, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x2_242_24Cons, 2);
        V v_t_2410 = heff_strAppend(heff_strAppend(v_line_241, ((V)&g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_str2)), v_x_245);
        V t_0 = v_w_240;
        V t_1 = v_t_2410;
        V t_2 = v_xs_246;
        V t_3 = v_d_243;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_line_241, heff_hole()});
        V v_u_2412 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2411);
        V t_0 = v_w_240;
        V t_1 = v_x_245;
        V t_2 = v_xs_246;
        V t_3 = v_u_2412;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x2_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_std_2eterminal_2ewidget_2ewrap_2ewrapGo_240_24dps(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}