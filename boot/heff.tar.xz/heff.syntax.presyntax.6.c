// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ETag 50948
#define TAG_ETuple 21722
#define TAG_EVar 52881
#define TAG_EndGive 48080
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IInvalid 29207
#define TAG_MkBinding 51651
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_SegmentBits 43687
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_bind 9519364
#define LBL_bound 295286168
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giveBack 2038160732
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_bind__pure__giveBack[] = {LBL_bind, LBL_pure, LBL_giveBack};
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1538437128x977115133_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1823028018x15931611_24dps_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_clo;
V g_heff_2esyntax_2epresyntax_2eendOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_clo;
V g_heff_2esyntax_2epresyntax_2egiveBackLet(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egiveBackLet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egiveBackLet_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2epackE(V, V);
V g_heff_2esyntax_2epresyntax_2epackE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackE_clo;
V g_heff_2esyntax_2epresyntax_2epackTy(V, V);
V g_heff_2esyntax_2epresyntax_2epackTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epackTy_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2erightTupleP(V, V);
V g_heff_2esyntax_2epresyntax_2erightTupleP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erightTupleP_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s568190696x1372373514(V);
V g_list_2eall_24s568190696x1372373514_entry(V self, V *a);
extern Clo g_list_2eall_24s568190696x1372373514_clo;
V g_list_2eany_24s750144226x405092487(V);
V g_list_2eany_24s750144226x405092487_entry(V self, V *a);
extern Clo g_list_2eany_24s750144226x405092487_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1674319799x1081446864(V);
V g_list_2ekeepIf_24s1674319799x1081446864_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1674319799x1081446864_clo;
V g_list_2emap_24s1709068899x1960726563(V, V, V, V);
V g_list_2emap_24s1709068899x1960726563_entry(V self, V *a);
extern Clo g_list_2emap_24s1709068899x1960726563_clo;
V g_list_2emap_24s1732792088x1893487364(V, V, V);
V g_list_2emap_24s1732792088x1893487364_entry(V self, V *a);
extern Clo g_list_2emap_24s1732792088x1893487364_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_ty_240)) {
  case TAG_SegmentBits: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_242 = heff_field(v_x2_241, 0);
      V v_f_243 = heff_intMod_lent(v_n_242, MK_INT(8LL), 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
    }
    case TAG_SizeName: {
      V v_unit_246 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod_lent(v_unit_246, MK_INT(8LL), 2)) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_SizeDefault: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
    }
    case TAG_SizeNumber: {
      V v_n_247 = heff_field(v_x2_241, 0);
      V v_f_248 = heff_intMod_lent(v_n_247, MK_INT(8LL), 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
    }
    case TAG_SizeName: {
      V v_unit_2411 = heff_field(v_x2_241, 2);
      if ((heff_unbox_word(heff_intMod_lent(v_unit_2411, MK_INT(8LL), 2)) == ((int64_t)0ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), MK_INT(0LL)}});
      } else {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_f_242 = heff_intMod(v_acc_241, MK_INT(8LL));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_242}});
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nothing: {
      heff_drop(v_acc_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_n_245 = heff_field(v_x11_243, 0);
      V t_0 = v_x12_244;
      V t_1 = heff_intAdd_lent(v_acc_241, v_n_245, 1);
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eidNames_str0, 6, "idBind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eidNames_str1, 6, "idPure");
HEFF_REC_LIT(g_heff_2esyntax_2epresyntax_2eidNames_lit2, 3, shape_bind__pure__giveBack, ((V)&g_heff_2esyntax_2epresyntax_2eidNames_str0), ((V)&g_heff_2esyntax_2epresyntax_2eidNames_str1), NTAG(TAG_True));

static V g_heff_2esyntax_2epresyntax_2eidNames_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eidNames_st;
static V g_heff_2esyntax_2epresyntax_2eidNames_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2eidNames_lit2);
}
V g_heff_2esyntax_2epresyntax_2eidNames_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eidNames_st)) return g_heff_2esyntax_2epresyntax_2eidNames_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eidNames_val, &g_heff_2esyntax_2epresyntax_2eidNames_st, g_heff_2esyntax_2epresyntax_2eidNames_init);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eendOf_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eendOf_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eendOf_str2, 12, "builtin.Unit");
Clo g_heff_2esyntax_2epresyntax_2eendOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eendOf_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eendOf(V v_cx_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EndValue: {
    V v_t_243 = heff_dup(heff_rfield(v_cx_240, 6));
    V v_v_2413;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      v_v_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eendOf_str0)}), heff_dup(v_sp_241)});
      break;
    }
    case TAG_Just: {
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 0ULL, 1);
      V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24t_243_24Just, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eendOf_str1)}), heff_dup(v_sp_241)});
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eendOf_str2)}), heff_dup(v_sp_241)});
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_241, 0)), heff_dup(heff_rfield(v_sp_241, 1))});
      V v_v_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_245, v_t_246}), v_t_247});
      V v_t_249 = heff_dup(heff_rfield(v_cx_240, 6));
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_v_2413 = v_v_248;
        break;
      }
      case TAG_Just: {
        V v_names_2410 = heff_field(v_t_249, 0);
        V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_names_2410, NTAG(TAG_Nil)});
        V v_t_2412 = heff_tag_at_n(v_ru_24t_249_24Just, TAG_ETuple, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_v_248, v_t_2411})});
        v_v_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_241)});
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
    V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2414}), heff_dup(v_sp_241)});
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2413, NTAG(TAG_Nil)});
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2415, v_t_2416));
    return ({ V a_0 = v_cx_240; V a_1 = v_sp_241; V a_2 = heff_dup(heff_rfield(v_cx_240, 4)); V a_3 = v_t_2417; V r_ = (g_heff_2esyntax_2epresyntax_2eleaving(a_0, a_1, a_2, a_3)); heff_drop_rec(v_cx_240, 7); heff_drop_rec(v_sp_241, 2); heff_drop(v_t_2417); r_; });
  }
  case TAG_EndJump: {
    V v_j_2418 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24EndJump = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    return (g_heff_2esyntax_2epresyntax_2ejumpCall_24tok1(v_ru_24x3_242_24EndJump, v_cx_240, v_sp_241, v_j_2418));
  }
  case TAG_EndGive: {
    V v_vars_2419 = heff_field(v_x3_242, 0);
    V v_d_2420 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EndGive = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_v_2421 = (g_heff_2esyntax_2epresyntax_2epackE(v_sp_241, v_vars_2419));
    V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
    V v_t_2423 = heff_tag_at_n(v_ru_24x3_242_24EndGive, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2422}), heff_dup(v_sp_241)});
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2421, NTAG(TAG_Nil)});
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2423, v_t_2424));
    V v_t_2426 = heff_intSub(heff_dup(heff_rfield(v_cx_240, 4)), v_d_2420);
    return ({ V a_0 = v_cx_240; V a_1 = v_sp_241; V a_2 = v_t_2426; V a_3 = v_t_2425; V r_ = (g_heff_2esyntax_2epresyntax_2eleaving(a_0, a_1, a_2, a_3)); heff_drop_rec(v_cx_240, 7); heff_drop_rec(v_sp_241, 2); heff_drop(v_t_2425); r_; });
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2eendOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eendOf(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1823028018x15931611_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkBinding: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24MkBinding = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2411;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2411 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_2410)));
        }
        V v_t_2412 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkBinding, TAG_MkBinding, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
        V t_0 = v_a_2411;
        V t_1 = v_xs_246;
        V t_2 = v_u_2414;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_str0, 5, "join#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_str1, 5, "join#");
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0, 1, 0};
Clo g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(V v_cx_240, V v_sp_241, V v_s_242, V v_arms_243, V v_rest_244, V v_end_245) {
top: ;
  switch (heff_tag_of(v_rest_244)) {
  case TAG_Nil: {
    V v_t_246 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
    HeffT2 v_t_247 = ({ V b_0 = heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_246}); V a_1 = NTAG(TAG_Nil); V a_2 = v_s_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x_2410 = v_field_248;
      V v_y_2411 = v_field_249;
      V v_alts_2412 = (g_list_2emap_24s1732792088x1893487364(heff_dup(v_cx_240), v_end_245, v_arms_243));
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2411, v_alts_2412}), v_sp_241});
      return ({ V a_0 = v_cx_240; V a_1 = v_x_2410; V a_2 = v_t_2413; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
    }
  }
  case TAG_Cons: {
    V v_x1_2416 = (g_list_2ekeepIf_24s1674319799x1081446864(heff_dup(v_arms_243)));
    V v_t_2426;
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      V v_a_2417 = heff_field(v_x1_2416, 0);
      V v_x12_2418 = heff_field(v_x1_2416, 1);
      V v_ru_24x1_2416_24Cons = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
      switch (heff_tag_of(v_x12_2418)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_a_2417)) {
        case TAG_MkPair: {
          V v_p_2419 = heff_field(v_a_2417, 0);
          V v_ss_2420 = heff_field(v_a_2417, 1);
          heff_take_n(v_a_2417, 3ULL, 2);
          V v_x1_2421 = (g_heff_2esyntax_2epresyntax_2epatNames_24tok2(v_ru_24x1_2416_24Cons, v_p_2419));
          switch (heff_tag_of(v_x1_2421)) {
          case TAG_Nil: {
            v_t_2426 = ({ V a_0 = v_ss_2420; V r_ = (g_list_2eall_24s568190696x1372373514(a_0)); heff_drop(v_ss_2420); r_; });
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x1_2421, 0ULL, 2);
            heff_drop(v_ss_2420);
            v_t_2426 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x1_2421);
          }
          break;
        }
        default: heff_nomatch(v_a_2417);
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x12_2418, 0ULL, 2);
        heff_drop(v_a_2417);
        heff_drop_cell(v_ru_24x1_2416_24Cons, 2);
        v_t_2426 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_2418);
      }
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_t_2426);
      V v_t_2427 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
      HeffT2 v_t_2428 = ({ V b_0 = heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2427}); V a_1 = NTAG(TAG_Nil); V a_2 = v_s_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      {
        V v_field_2429 = v_t_2428.f[0];
        V v_field_2430 = v_t_2428.f[1];
        V v_x_2431 = v_field_2429;
        V v_y_2432 = v_field_2430;
        V v_alts_2433 = (g_list_2emap_24s1709068899x1960726563(heff_dup(v_cx_240), v_rest_244, v_end_245, v_arms_243));
        V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2432, v_alts_2433}), v_sp_241});
        return ({ V a_0 = v_cx_240; V a_1 = v_x_2431; V a_2 = v_t_2434; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2431); r_; });
      }
    } else {
      heff_drop(v_t_2426);
      V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 2, 3);
      V v_t_2483;
      if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
        heff_drop(v_t_2435);
        V v_arms_2436 = heff_dup(v_arms_243);
        v_t_2483 = ({ V b_0 = ((V)&g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0_clo); V a_1 = v_arms_2436; V r_ = (g_list_2eall(b_0, a_1)); heff_drop(b_0); heff_drop(v_arms_2436); r_; });
      } else {
        heff_drop(v_t_2435);
        v_t_2483 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
        heff_drop(v_t_2483);
        V v_t_2484 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_2485 = ({ V b_0 = heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2484}); V a_1 = NTAG(TAG_Nil); V a_2 = v_s_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        {
          V v_field_2486 = v_t_2485.f[0];
          V v_field_2487 = v_t_2485.f[1];
          V v_x_2488 = v_field_2486;
          V v_y_2489 = v_field_2487;
          V v_t_2490 = heff_tag_n(TAG_EndGive, 2, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), heff_dup(heff_rfield(v_cx_240, 4))});
          V v_alts_2491 = (g_list_2emap_24s1732792088x1893487364(heff_dup(v_cx_240), v_t_2490, v_arms_243));
          V v_t_2492 = (g_heff_2esyntax_2epresyntax_2epackTy(v_sp_241, heff_dup(heff_rfield(v_cx_240, 1))));
          V v_t_2495;
          switch (heff_tag_of(v_t_2492)) {
          case TAG_At: {
            V v_s_2494 = heff_dup(heff_field(v_t_2492, 1));
            v_t_2495 = v_s_2494;
            break;
          }
          default: heff_nomatch(v_t_2492);
          }
          V v_t_2496 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_244; V a_2 = v_end_245; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop_tag(v_rest_244, 2); r_; });
          V v_t_2497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_2489, v_alts_2491}), heff_dup(v_sp_241)});
          V v_t_2498 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2495, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2499 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_2497, v_t_2492}), v_t_2498});
          V v_t_24100 = (g_heff_2esyntax_2epresyntax_2egiveBackLet(v_sp_241, heff_dup(heff_rfield(v_cx_240, 1)), v_t_2499, v_t_2496));
          return ({ V a_0 = v_cx_240; V a_1 = v_x_2488; V a_2 = v_t_24100; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2488); r_; });
        }
      } else {
        heff_drop(v_t_2483);
        V v_t_24101 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
        HeffT2 v_t_24102 = ({ V b_0 = heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_24101}); V a_1 = NTAG(TAG_Nil); V a_2 = v_s_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        {
          V v_field_24103 = v_t_24102.f[0];
          V v_field_24104 = v_t_24102.f[1];
          V v_x_24105 = v_field_24103;
          V v_y_24106 = v_field_24104;
          V v_t_24107 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
          V v_t_24108 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_str0), v_t_24107)});
          V v_t_24109 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24108, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
          V v_alts_24110 = (g_list_2emap_24s1732792088x1893487364(heff_dup(v_cx_240), heff_tag_n(TAG_EndJump, 1, (V[]){v_t_24109}), v_arms_243));
          V v_t_24111 = (g_heff_2esyntax_2epresyntax_2evarParams(heff_dup(v_sp_241), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 1))));
          V v_t_24112 = ({ V a_0 = heff_dup(v_cx_240); V a_1 = v_rest_244; V a_2 = v_end_245; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop_tag(v_rest_244, 2); r_; });
          V v_t_24113 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
          V v_t_24114 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_str1), v_t_24113), heff_dup(v_sp_241), v_t_24111, v_t_24112));
          V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_y_24106, v_alts_24110}), heff_dup(v_sp_241)});
          V v_t_24116 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24114, NTAG(TAG_Nil)});
          V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_t_24115, v_t_24116}), v_sp_241});
          return ({ V a_0 = v_cx_240; V a_1 = v_x_24105; V a_2 = v_t_24117; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_24105); r_; });
        }
      }
    }
  }
  default: return heff_nomatch(v_rest_244);
  }
}
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2epresyntax_2econdT_24s88971820x625124028_lam0(V self, V *args) {
  V v_a_2437 = args[0];
  V v_t_2440;
  switch (heff_tag_of(v_a_2437)) {
  case TAG_MkPair: {
    V v_y_2439 = heff_dup(heff_field(v_a_2437, 1));
    v_t_2440 = v_y_2439;
    break;
  }
  default: heff_nomatch(v_a_2437);
  }
  V v_x1_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2440));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nil: {
    V v_t_2444;
    switch (heff_tag_of(v_a_2437)) {
    case TAG_MkPair: {
      V v_y_2443 = heff_field(v_a_2437, 1);
      heff_take_n(v_a_2437, 2ULL, 2);
      v_t_2444 = v_y_2443;
      break;
    }
    default: heff_nomatch(v_a_2437);
    }
    V v_x1_2445 = (g_list_2eany_24s750144226x405092487(v_t_2444));
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2445) == NTAG(TAG_True)));
    heff_drop(v_x1_2445);
    return v_ret_24bool;
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 2);
    switch (heff_tag_of(v_x_2446)) {
    case TAG_At: {
      V v_it11_2448 = heff_field(v_x_2446, 0);
      heff_take_n(v_x_2446, 1ULL, 2);
      switch (heff_tag_of(v_it11_2448)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2448, 0ULL, 3);
        V v_t_2455;
        switch (heff_tag_of(v_a_2437)) {
        case TAG_MkPair: {
          V v_y_2454 = heff_field(v_a_2437, 1);
          heff_take_n(v_a_2437, 2ULL, 2);
          v_t_2455 = v_y_2454;
          break;
        }
        default: heff_nomatch(v_a_2437);
        }
        V v_x1_2456 = (g_list_2eany_24s750144226x405092487(v_t_2455));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2456) == NTAG(TAG_True)));
        heff_drop(v_x1_2456);
        return v_ret_24bool;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_2448, 0ULL, 2);
        V v_t_2461;
        switch (heff_tag_of(v_a_2437)) {
        case TAG_MkPair: {
          V v_y_2460 = heff_field(v_a_2437, 1);
          heff_take_n(v_a_2437, 2ULL, 2);
          v_t_2461 = v_y_2460;
          break;
        }
        default: heff_nomatch(v_a_2437);
        }
        V v_x1_2462 = (g_list_2eany_24s750144226x405092487(v_t_2461));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2462) == NTAG(TAG_True)));
        heff_drop(v_x1_2462);
        return v_ret_24bool;
      }
      case TAG_StmtExpr: {
        V v_e_2463 = heff_field(v_it11_2448, 0);
        heff_take_n(v_it11_2448, 1ULL, 1);
        V v_t_2464 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2463));
        if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
          heff_drop(v_t_2464);
          V v_t_2467;
          switch (heff_tag_of(v_a_2437)) {
          case TAG_MkPair: {
            V v_y_2466 = heff_field(v_a_2437, 1);
            heff_take_n(v_a_2437, 2ULL, 2);
            v_t_2467 = v_y_2466;
            break;
          }
          default: heff_nomatch(v_a_2437);
          }
          V v_x1_2468 = (g_list_2eany_24s750144226x405092487(v_t_2467));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2468) == NTAG(TAG_True)));
          heff_drop(v_x1_2468);
          return v_ret_24bool;
        } else {
          heff_drop(v_a_2437);
          heff_drop(v_t_2464);
          return NTAG(TAG_False);
        }
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2448, 0ULL, 3);
        V v_t_2474;
        switch (heff_tag_of(v_a_2437)) {
        case TAG_MkPair: {
          V v_y_2473 = heff_field(v_a_2437, 1);
          heff_take_n(v_a_2437, 2ULL, 2);
          v_t_2474 = v_y_2473;
          break;
        }
        default: heff_nomatch(v_a_2437);
        }
        V v_x1_2475 = (g_list_2eany_24s750144226x405092487(v_t_2474));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2475) == NTAG(TAG_True)));
        heff_drop(v_x1_2475);
        return v_ret_24bool;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2448, 0ULL, 3);
        V v_t_2481;
        switch (heff_tag_of(v_a_2437)) {
        case TAG_MkPair: {
          V v_y_2480 = heff_field(v_a_2437, 1);
          heff_take_n(v_a_2437, 2ULL, 2);
          v_t_2481 = v_y_2480;
          break;
        }
        default: heff_nomatch(v_a_2437);
        }
        V v_x1_2482 = (g_list_2eany_24s750144226x405092487(v_t_2481));
        V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2482) == NTAG(TAG_True)));
        heff_drop(v_x1_2482);
        return v_ret_24bool;
      }
      default: return heff_nomatch(v_it11_2448);
      }
    }
    default: return heff_nomatch(v_x_2446);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erightTupleP_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erightTupleP_str1, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erightTupleP_str2, 6, "MkPair");
Clo g_heff_2esyntax_2epresyntax_2erightTupleP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2erightTupleP_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2erightTupleP(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erightTupleP_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_240, 0)), heff_dup(heff_rfield(v_sp_240, 1))});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_243});
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_p_244;
    }
    case TAG_Cons: {
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2erightTupleP(v_sp_240, v_x22_245));
      V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      V v_ps_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_244, v_t_249});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erightTupleP_str1)}), heff_dup(v_sp_240)});
      V v_x1_2412 = ({ V a_0 = v_t_2411; V a_1 = v_ps_2410; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_t_2411, 2); r_; });
      V v_t_2415;
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_x1_2412, 1);
        heff_take_n(v_x1_2412, 2ULL, 2);
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_x1_2412);
      }
      V v_t_2416 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2415, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erightTupleP_str2), heff_dup(v_sp_240), v_ps_2410}), v_t_2416});
    }
    default: return heff_nomatch(v_x22_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2erightTupleP_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2erightTupleP(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1538437128x977115133_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_SetPath: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24SetPath = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2411 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_2410), v_st_240));
        V v_t_2412 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24SetPath, TAG_SetPath, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
        V t_0 = v_a_2411;
        V t_1 = v_xs_246;
        V t_2 = v_u_2414;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_TSig: {
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_249 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TInf: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_sp_240});
  }
  case TAG_TChk: {
    V v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(a[0], a[1]);
}