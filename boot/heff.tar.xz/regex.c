// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Alternate 49476
#define TAG_Assert 34429
#define TAG_AtEnd 56720
#define TAG_AtStart 49853
#define TAG_AtWordBoundary 26444
#define TAG_Concat 43553
#define TAG_Done 47505
#define TAG_EmptyMatch 15555
#define TAG_Fork 41691
#define TAG_Group 9145
#define TAG_Hold 35554
#define TAG_Jump 35419
#define TAG_Keep 49586
#define TAG_Left 13886
#define TAG_NotAtWordBoundary 12928
#define TAG_Repeat 23348
#define TAG_Right 62770
#define TAG_Runes 33739
#define TAG_Take 51932
#define LBL_branches 719731544
#define LBL_current 1358797751
#define LBL_found 298980252
#define LBL_group 299987609
#define LBL_next 9873338
#define LBL_seen 10021698
#define LBL_slots 310891087
#define LBL_step 10036115
#define LBL_threads 1041404398
static uint32_t shape_group__branches__current[] = {LBL_group, LBL_branches, LBL_current};
static uint32_t shape_next__found[] = {LBL_next, LBL_found};
static uint32_t shape_seen__threads[] = {LBL_seen, LBL_threads};
static uint32_t shape_step__slots[] = {LBL_step, LBL_slots};
V g_list_2efoldl_24f2005293661x823011722(V, V, V);
V g_list_2efoldl_24f2005293661x823011722_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2005293661x823011722_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1799718634x73643635(V, V);
V g_list_2efoldl_24s1799718634x73643635_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1799718634x73643635_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1041642916x1626051668(V);
V g_list_2emap_24s1041642916x1626051668_entry(V self, V *a);
extern Clo g_list_2emap_24s1041642916x1626051668_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
HeffT3 g_regex_2eclassFrom_24cpr(V, V, V, V);
HeffT3 g_regex_2eclassFrom_2eclassRune_240_24cpr(V, V);
V g_regex_2eclosed(V);
V g_regex_2eclosed_entry(V self, V *a);
extern Clo g_regex_2eclosed_clo;
V g_regex_2econtrolEscape(V);
V g_regex_2econtrolEscape_entry(V self, V *a);
extern Clo g_regex_2econtrolEscape_clo;
HeffT4 g_regex_2ecountAt_24cpr(V, V);
HeffT2 g_regex_2ecountAt_2enumberAt_240_24cpr(V, V);
V g_regex_2eemit(V, V);
V g_regex_2eemit_entry(V self, V *a);
extern Clo g_regex_2eemit_clo;
V g_regex_2eemit_2eemitOptional_241(V, V, V, V, V);
V g_regex_2eemit_2eemitOptional_241_entry(V self, V *a);
extern Clo g_regex_2eemit_2eemitOptional_241_clo;
HeffT3 g_regex_2eescapeAt_24cpr(V, V);
V g_regex_2egather(V, V, V, V, V, V);
V g_regex_2egather_entry(V self, V *a);
extern Clo g_regex_2egather_clo;
V g_regex_2eholds(V, V, V);
V g_regex_2eholds_entry(V self, V *a);
extern Clo g_regex_2eholds_clo;
HeffT3 g_regex_2eperlClass_24cpr(V);
V g_regex_2eperlClass_2edigitRanges_240_get(void);
V g_regex_2eperlClass_2espaceRanges_242_get(void);
V g_regex_2eperlClass_2ewordRanges_241_get(void);
HeffT3 g_regex_2ereadFrom_24cpr(V, V, V, V, V);
HeffT3 g_regex_2erepeatedIn_24cpr(V, V, V, V, V, V);
V g_regex_2erunFrom(V, V, V, V, V, V);
V g_regex_2erunFrom_entry(V self, V *a);
extern Clo g_regex_2erunFrom_clo;
V g_regex_2esizeOf(V);
V g_regex_2esizeOf_entry(V self, V *a);
extern Clo g_regex_2esizeOf_clo;
HeffT2 g_regex_2estepThreads_24cpr(V, V, V, V, V, V);
HeffT2 g_regex_2estepThreads_24scalars_24cpr(V, V, V, V, V, V, V);
V g_regex_2estepThreads_2einRanges_240_get(void);
V g_regex_2ewordBefore(V, V);
V g_regex_2ewordBefore_entry(V self, V *a);
extern Clo g_regex_2ewordBefore_clo;

HeffT3 g_regex_2eperlClass_24cpr(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((v_c_240 == ((int64_t)100ULL))) {
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_False), heff_dup(g_regex_2eperlClass_2edigitRanges_240_get())}});
  } else {
    if ((v_c_240 == ((int64_t)68ULL))) {
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_True), heff_dup(g_regex_2eperlClass_2edigitRanges_240_get())}});
    } else {
      if ((v_c_240 == ((int64_t)119ULL))) {
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_False), heff_dup(g_regex_2eperlClass_2ewordRanges_241_get())}});
      } else {
        if ((v_c_240 == ((int64_t)87ULL))) {
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_True), heff_dup(g_regex_2eperlClass_2ewordRanges_241_get())}});
        } else {
          if ((v_c_240 == ((int64_t)115ULL))) {
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_False), heff_dup(g_regex_2eperlClass_2espaceRanges_242_get())}});
          } else {
            if ((v_c_240 == ((int64_t)83ULL))) {
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_True), heff_dup(g_regex_2eperlClass_2espaceRanges_242_get())}});
            } else {
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        }
      }
    }
  }
}
Clo g_regex_2econtrolEscape_clo = {{0x80000000u, K_CLO, 0}, g_regex_2econtrolEscape_entry, 1, 0};

V g_regex_2econtrolEscape(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  if ((v_c_240 == ((int64_t)110ULL))) {
    return MK_INT(10LL);
  } else {
    if ((v_c_240 == ((int64_t)116ULL))) {
      return MK_INT(9LL);
    } else {
      if ((v_c_240 == ((int64_t)114ULL))) {
        return MK_INT(13LL);
      } else {
        if ((v_c_240 == ((int64_t)102ULL))) {
          return MK_INT(12LL);
        } else {
          if ((v_c_240 == ((int64_t)118ULL))) {
            return MK_INT(11LL);
          } else {
            return MK_INT(-1LL);
          }
        }
      }
    }
  }
}
V g_regex_2econtrolEscape_entry(V self, V *a) {
  (void)self;
  return g_regex_2econtrolEscape(a[0]);
}
HEFF_LIT(g_regex_2eclassFrom_24cpr_str0, 17, "a `[` with no `]`");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str1, 42, "classes by name, `[:alpha:]`, are not read");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str2, 2, "`\\");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str3, 24, "` in a class is not read");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str4, 2, "`\\");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str5, 58, "` is not read: escape only what is not a letter or a digit");
HEFF_LIT(g_regex_2eclassFrom_24cpr_str6, 28, "a range of a class backwards");

HeffT3 g_regex_2eclassFrom_24cpr(V v_s_240, V v_i_241, V v_first_242, V v_acc_243) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1)) {
    heff_drop(v_i_241);
    heff_drop(v_acc_243);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str0), MK_INT(0LL)}});
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)93ULL)) && !(heff_dup(v_first_242) == NTAG(TAG_True)))) {
      V v_f_244 = heff_intAdd(v_i_241, MK_INT(1LL));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_acc_243, v_f_244}});
    } else {
      if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)91ULL)) && (heff_intLt_c(heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)58ULL))))) {
        heff_drop(v_i_241);
        heff_drop(v_acc_243);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str1), MK_INT(0LL)}});
      } else {
        if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL)) && (heff_intLt_c(heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), heff_strLength_lent(v_s_240, 0)) && ({ V v_c_245 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2); int c_ = ((((((int64_t)48ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)57ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)122ULL))))) && ({ V v_t_246 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2); int c_ = ({ V v_t_2438 = (g_regex_2econtrolEscape(heff_dup(v_t_246))); int c_ = heff_intLt_c_lent(v_t_2438, MK_INT(0LL), 2); heff_drop(v_t_2438); c_; }); heff_drop(v_t_246); c_; })); heff_drop(v_c_245); c_; })))) {
          V v_t_247 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
          HeffT3 v_t_248 = (g_regex_2eperlClass_24cpr(v_t_247));
          {
            V v_field_2410 = v_t_248.f[1];
            V v_field_2411 = v_t_248.f[2];
            int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
            if ((v_tag_249 == ((int64_t)0ULL))) {
              V v_it11_2412 = v_field_2410;
              V v_rs_2413 = v_field_2411;
              if ((heff_dup(v_it11_2412) == NTAG(TAG_True))) {
                heff_drop(v_acc_243);
                heff_drop(v_it11_2412);
                heff_drop(v_rs_2413);
                V v_i_2414 = heff_intAdd(v_i_241, MK_INT(1LL));
                V v_t_2415 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_2414), heff_intAdd(v_i_2414, MK_INT(1LL)));
                V v_f_2416 = heff_strAppend(heff_strAppend(((V)&g_regex_2eclassFrom_24cpr_str2), v_t_2415), ((V)&g_regex_2eclassFrom_24cpr_str3));
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2416, MK_INT(0LL)}});
              } else {
                heff_drop(v_it11_2412);
                V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rs_2413));
                V v_t_2418 = (g_prelude_2e_2b_2b(v_t_2417, v_acc_243));
                V t_0 = v_s_240;
                V t_1 = heff_intAdd(v_i_241, MK_INT(2LL));
                V t_2 = NTAG(TAG_False);
                V t_3 = v_t_2418;
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_first_242 = t_2;
                v_acc_243 = t_3;
                goto top;
              }
            } else {
              heff_drop(v_acc_243);
              heff_drop(v_field_2410);
              heff_drop(v_field_2411);
              V v_i_2419 = heff_intAdd(v_i_241, MK_INT(1LL));
              V v_t_2420 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_2419), heff_intAdd(v_i_2419, MK_INT(1LL)));
              V v_f_2421 = heff_strAppend(heff_strAppend(((V)&g_regex_2eclassFrom_24cpr_str4), v_t_2420), ((V)&g_regex_2eclassFrom_24cpr_str5));
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2421, MK_INT(0LL)}});
            }
          }
        } else {
          HeffT3 v_t_2422 = (g_regex_2eclassFrom_2eclassRune_240_24cpr(v_s_240, v_i_241));
          {
            V v_field_2424 = v_t_2422.f[1];
            V v_field_2425 = v_t_2422.f[2];
            int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
            if ((v_tag_2423 == ((int64_t)0ULL))) {
              heff_drop(v_acc_243);
              heff_drop(v_field_2425);
              V v_why_2426 = v_field_2424;
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_why_2426, MK_INT(0LL)}});
            } else {
              V v_lo_2427 = v_field_2424;
              V v_j_2428 = v_field_2425;
              if ((heff_intLt_c(heff_intAdd_lent(v_j_2428, MK_INT(1LL), 2), heff_strLength_lent(v_s_240, 0)) && ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2428, 0)) == ((int64_t)45ULL)) && !(heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_2428, MK_INT(1LL), 2), 2)) == ((int64_t)93ULL))))) {
                HeffT3 v_t_2429 = (g_regex_2eclassFrom_2eclassRune_240_24cpr(v_s_240, heff_intAdd(v_j_2428, MK_INT(1LL))));
                {
                  V v_field_2431 = v_t_2429.f[1];
                  V v_field_2432 = v_t_2429.f[2];
                  int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                  if ((v_tag_2430 == ((int64_t)0ULL))) {
                    heff_drop(v_acc_243);
                    heff_drop(v_lo_2427);
                    heff_drop(v_field_2432);
                    V v_why_2433 = v_field_2431;
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_why_2433, MK_INT(0LL)}});
                  } else {
                    V v_hi_2434 = v_field_2431;
                    V v_k_2435 = v_field_2432;
                    if (heff_intLt_c_lent(v_hi_2434, v_lo_2427, 0)) {
                      heff_drop(v_acc_243);
                      heff_drop(v_lo_2427);
                      heff_drop(v_hi_2434);
                      heff_drop(v_k_2435);
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eclassFrom_24cpr_str6), MK_INT(0LL)}});
                    } else {
                      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_lo_2427, v_hi_2434}), v_acc_243});
                      V t_0 = v_s_240;
                      V t_1 = v_k_2435;
                      V t_2 = NTAG(TAG_False);
                      V t_3 = v_t_2436;
                      v_s_240 = t_0;
                      v_i_241 = t_1;
                      v_first_242 = t_2;
                      v_acc_243 = t_3;
                      goto top;
                    }
                  }
                }
              } else {
                V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lo_2427), v_lo_2427}), v_acc_243});
                V t_0 = v_s_240;
                V t_1 = v_j_2428;
                V t_2 = NTAG(TAG_False);
                V t_3 = v_t_2437;
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_first_242 = t_2;
                v_acc_243 = t_3;
                goto top;
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_regex_2eescapeAt_24cpr_str0, 16, "a `\\` at the end");
HEFF_LIT(g_regex_2eescapeAt_24cpr_str1, 2, "`\\");
HEFF_LIT(g_regex_2eescapeAt_24cpr_str2, 58, "` is not read: escape only what is not a letter or a digit");

HeffT3 g_regex_2eescapeAt_24cpr(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd_lent(v_i_241, MK_INT(1LL), 2))) {
    heff_drop(v_i_241);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2eescapeAt_24cpr_str0), MK_INT(0LL)}});
  } else {
    V v_c_242 = heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2);
    if ((heff_peek_word(v_c_242) == ((int64_t)98ULL))) {
      heff_drop(v_c_242);
      V v_f_243 = heff_intAdd(v_i_241, MK_INT(2LL));
      V v_t_244 = heff_tag_n(TAG_Assert, 1, (V[]){NTAG(TAG_AtWordBoundary)});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_244, v_f_243}});
    } else {
      if ((heff_peek_word(v_c_242) == ((int64_t)66ULL))) {
        heff_drop(v_c_242);
        V v_f_245 = heff_intAdd(v_i_241, MK_INT(2LL));
        V v_t_246 = heff_tag_n(TAG_Assert, 1, (V[]){NTAG(TAG_NotAtWordBoundary)});
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_246, v_f_245}});
      } else {
        if ((heff_peek_word(v_c_242) == ((int64_t)65ULL))) {
          heff_drop(v_c_242);
          V v_f_247 = heff_intAdd(v_i_241, MK_INT(2LL));
          V v_t_248 = heff_tag_n(TAG_Assert, 1, (V[]){NTAG(TAG_AtStart)});
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_248, v_f_247}});
        } else {
          if ((heff_peek_word(v_c_242) == ((int64_t)122ULL))) {
            heff_drop(v_c_242);
            V v_f_249 = heff_intAdd(v_i_241, MK_INT(2LL));
            V v_t_2410 = heff_tag_n(TAG_Assert, 1, (V[]){NTAG(TAG_AtEnd)});
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2410, v_f_249}});
          } else {
            HeffT3 v_t_2411 = (g_regex_2eperlClass_24cpr(heff_dup(v_c_242)));
            {
              V v_field_2413 = v_t_2411.f[1];
              V v_field_2414 = v_t_2411.f[2];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                heff_drop(v_c_242);
                V v_neg_2415 = v_field_2413;
                V v_rs_2416 = v_field_2414;
                V v_f_2417 = heff_intAdd(v_i_241, MK_INT(2LL));
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_Runes, 2, (V[]){v_neg_2415, v_rs_2416}), v_f_2417}});
              } else {
                heff_drop(v_field_2413);
                heff_drop(v_field_2414);
                int64_t v_t_2418;
                if ((heff_peek_word(v_c_242) == ((int64_t)110ULL))) {
                  v_t_2418 = ((int64_t)10ULL);
                } else {
                  if ((heff_peek_word(v_c_242) == ((int64_t)116ULL))) {
                    v_t_2418 = ((int64_t)9ULL);
                  } else {
                    if ((heff_peek_word(v_c_242) == ((int64_t)114ULL))) {
                      v_t_2418 = ((int64_t)13ULL);
                    } else {
                      if ((heff_peek_word(v_c_242) == ((int64_t)102ULL))) {
                        v_t_2418 = ((int64_t)12ULL);
                      } else {
                        if ((heff_peek_word(v_c_242) == ((int64_t)118ULL))) {
                          v_t_2418 = ((int64_t)11ULL);
                        } else {
                          v_t_2418 = ((int64_t)-1ULL);
                        }
                      }
                    }
                  }
                }
                if ((((int64_t)0ULL) <= v_t_2418)) {
                  V v_t_2419;
                  if ((heff_peek_word(v_c_242) == ((int64_t)110ULL))) {
                    v_t_2419 = MK_INT(10LL);
                  } else {
                    if ((heff_peek_word(v_c_242) == ((int64_t)116ULL))) {
                      v_t_2419 = MK_INT(9LL);
                    } else {
                      if ((heff_peek_word(v_c_242) == ((int64_t)114ULL))) {
                        v_t_2419 = MK_INT(13LL);
                      } else {
                        if ((heff_peek_word(v_c_242) == ((int64_t)102ULL))) {
                          v_t_2419 = MK_INT(12LL);
                        } else {
                          if ((heff_peek_word(v_c_242) == ((int64_t)118ULL))) {
                            v_t_2419 = MK_INT(11LL);
                          } else {
                            v_t_2419 = MK_INT(-1LL);
                          }
                        }
                      }
                    }
                  }
                  V v_t_2420;
                  if ((heff_peek_word(v_c_242) == ((int64_t)110ULL))) {
                    heff_drop(v_c_242);
                    v_t_2420 = MK_INT(10LL);
                  } else {
                    if ((heff_peek_word(v_c_242) == ((int64_t)116ULL))) {
                      heff_drop(v_c_242);
                      v_t_2420 = MK_INT(9LL);
                    } else {
                      if ((heff_peek_word(v_c_242) == ((int64_t)114ULL))) {
                        heff_drop(v_c_242);
                        v_t_2420 = MK_INT(13LL);
                      } else {
                        if ((heff_peek_word(v_c_242) == ((int64_t)102ULL))) {
                          heff_drop(v_c_242);
                          v_t_2420 = MK_INT(12LL);
                        } else {
                          if ((heff_unbox_word(v_c_242) == ((int64_t)118ULL))) {
                            v_t_2420 = MK_INT(11LL);
                          } else {
                            v_t_2420 = MK_INT(-1LL);
                          }
                        }
                      }
                    }
                  }
                  V v_f_2421 = heff_intAdd(v_i_241, MK_INT(2LL));
                  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_t_2420}), NTAG(TAG_Nil)});
                  V v_t_2423 = heff_tag_n(TAG_Runes, 2, (V[]){NTAG(TAG_False), v_t_2422});
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2423, v_f_2421}});
                } else {
                  if ((((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL)))))) {
                    heff_drop(v_c_242);
                    V v_i_2424 = heff_intAdd(v_i_241, MK_INT(1LL));
                    V v_t_2425 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_2424), heff_intAdd(v_i_2424, MK_INT(1LL)));
                    V v_f_2426 = heff_strAppend(heff_strAppend(((V)&g_regex_2eescapeAt_24cpr_str1), v_t_2425), ((V)&g_regex_2eescapeAt_24cpr_str2));
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2426, MK_INT(0LL)}});
                  } else {
                    heff_drop(v_c_242);
                    V v_i_2427 = heff_intAdd(v_i_241, MK_INT(1LL));
                    HeffT2 v_t_2428 = heff_strRuneDecode_lent(v_s_240, v_i_2427, 0);
                    {
                      V v_rune_2429 = v_t_2428.f[0];
                      V v_width_2430 = v_t_2428.f[1];
                      V v_r_2431 = heff_runeToInt(v_rune_2429);
                      V v_f_2432 = heff_intAdd(v_i_2427, v_width_2430);
                      V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_r_2431), v_r_2431}), NTAG(TAG_Nil)});
                      V v_t_2434 = heff_tag_n(TAG_Runes, 2, (V[]){NTAG(TAG_False), v_t_2433});
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2434, v_f_2432}});
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT4 g_regex_2ecountAt_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_regex_2ecountAt_2enumberAt_240_24cpr(v_s_240, v_i_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_least_245 = v_field_243;
    V v_j_246 = v_field_244;
    if ((heff_intLt_c_lent(v_least_245, MK_INT(0LL), 2) || heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_j_246, 1))) {
      heff_drop(v_least_245);
      heff_drop(v_j_246);
      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_246, 0)) == ((int64_t)125ULL))) {
        V v_f_247 = heff_intAdd(v_j_246, MK_INT(1LL));
        return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_least_245), v_least_245, v_f_247}});
      } else {
        if (!(heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_246, 0)) == ((int64_t)44ULL))) {
          heff_drop(v_least_245);
          heff_drop(v_j_246);
          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
        } else {
          if ((heff_intLt_c(heff_intAdd_lent(v_j_246, MK_INT(1LL), 2), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_j_246, MK_INT(1LL), 2), 2)) == ((int64_t)125ULL)))) {
            V v_f_248 = heff_intAdd(v_j_246, MK_INT(2LL));
            return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), v_least_245, MK_INT(-1LL), v_f_248}});
          } else {
            HeffT2 v_t_249 = (g_regex_2ecountAt_2enumberAt_240_24cpr(v_s_240, heff_intAdd(v_j_246, MK_INT(1LL))));
            {
              V v_field_2410 = v_t_249.f[0];
              V v_field_2411 = v_t_249.f[1];
              V v_most_2412 = v_field_2410;
              V v_k_2413 = v_field_2411;
              if ((heff_intLe_c_lent(MK_INT(0LL), v_most_2412, 1) && (heff_intLt_c_lent(v_k_2413, heff_strLength_lent(v_s_240, 0), 2) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_k_2413, 0)) == ((int64_t)125ULL))))) {
                V v_f_2414 = heff_intAdd(v_k_2413, MK_INT(1LL));
                return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), v_least_245, v_most_2412, v_f_2414}});
              } else {
                heff_drop(v_least_245);
                heff_drop(v_most_2412);
                heff_drop(v_k_2413);
                return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          }
        }
      }
    }
  }
}
Clo g_regex_2eclosed_clo = {{0x80000000u, K_CLO, 0}, g_regex_2eclosed_entry, 1, 0};

V g_regex_2eclosed(V v_f_240) {
top: ;
  V v_current_241 = heff_take_field(v_f_240, 2);
  V v_branches_242 = heff_get_n(v_f_240, 1, 3);
  V v_xs_243 = v_current_241;
  V v_t_2411;
  switch (heff_tag_of(v_xs_243)) {
  case TAG_Nil: {
    v_t_2411 = NTAG(TAG_EmptyMatch);
    break;
  }
  case TAG_Cons: {
    V v_xs2_245 = heff_dup(heff_field(v_xs_243, 1));
    switch (heff_tag_of(v_xs2_245)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_243)) {
      case TAG_Cons: {
        V v_x_246 = heff_field(v_xs_243, 0);
        heff_take_n(v_xs_243, 1ULL, 2);
        v_t_2411 = v_x_246;
        break;
      }
      default: heff_nomatch(v_xs_243);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_245, 0ULL, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
      v_t_2411 = heff_tag_n(TAG_Concat, 1, (V[]){v_t_2410});
      break;
    }
    default: heff_nomatch(v_xs2_245);
    }
    break;
  }
  default: heff_nomatch(v_xs_243);
  }
  V v_xs_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_branches_242});
  V v_it_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
  switch (heff_tag_of(v_it_2413)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Alternate, 1, (V[]){v_it_2413});
  }
  case TAG_Cons: {
    V v_it2_2415 = heff_dup(heff_field(v_it_2413, 1));
    switch (heff_tag_of(v_it2_2415)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_it_2413)) {
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_it_2413, 0);
        heff_take_n(v_it_2413, 1ULL, 2);
        return v_x_2416;
      }
      default: return heff_nomatch(v_it_2413);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2415, 0ULL, 2);
      return heff_tag_n(TAG_Alternate, 1, (V[]){v_it_2413});
    }
    default: return heff_nomatch(v_it2_2415);
    }
  }
  default: return heff_nomatch(v_it_2413);
  }
}
V g_regex_2eclosed_entry(V self, V *a) {
  (void)self;
  return g_regex_2eclosed(a[0]);
}
HEFF_LIT(g_regex_2erepeatedIn_24cpr_str0, 3, "a `");
HEFF_LIT(g_regex_2erepeatedIn_24cpr_str1, 34, "` with nothing before it to repeat");
HEFF_LIT(g_regex_2erepeatedIn_24cpr_str2, 3, "a `");
HEFF_LIT(g_regex_2erepeatedIn_24cpr_str3, 53, "` after a repetition: repeat a group of it, `(\?:...)`");
HEFF_LIT(g_regex_2erepeatedIn_24cpr_str4, 18, "a count above 1000");
HEFF_LIT(g_regex_2erepeatedIn_24cpr_str5, 41, "a count backwards, `{n,m}` with m below n");

HeffT3 g_regex_2erepeatedIn_24cpr(V v_s_240, V v_i_241, V v_least_242, V v_most_243, V v_op_244, V v_f_245) {
top: ;
  V v_t_246 = heff_take_field(v_f_245, 2);
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_least_242);
    heff_drop(v_most_243);
    heff_drop_rec(v_f_245, 3);
    V v_f_247 = heff_strAppend(heff_strAppend(((V)&g_regex_2erepeatedIn_24cpr_str0), v_op_244), ((V)&g_regex_2erepeatedIn_24cpr_str1));
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_247, MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_it1_248 = heff_field(v_t_246, 0);
    V v_it2_249 = heff_field(v_t_246, 1);
    heff_take_n(v_t_246, 3ULL, 2);
    switch (heff_tag_of(v_it1_248)) {
    case TAG_Repeat: {
      heff_take_n(v_it1_248, 0ULL, 4);
      heff_drop(v_i_241);
      heff_drop(v_least_242);
      heff_drop(v_most_243);
      heff_drop_rec(v_f_245, 3);
      heff_drop(v_it2_249);
      V v_f_2414 = heff_strAppend(heff_strAppend(((V)&g_regex_2erepeatedIn_24cpr_str2), v_op_244), ((V)&g_regex_2erepeatedIn_24cpr_str3));
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2414, MK_INT(0LL)}});
    }
    default: {
      heff_drop(v_op_244);
      if ((heff_intLt_c_lent(MK_INT(1000LL), v_least_242, 1) || heff_intLt_c_lent(MK_INT(1000LL), v_most_243, 1))) {
        heff_drop(v_i_241);
        heff_drop(v_least_242);
        heff_drop(v_most_243);
        heff_drop_rec(v_f_245, 3);
        heff_drop(v_it1_248);
        heff_drop(v_it2_249);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2erepeatedIn_24cpr_str4), MK_INT(0LL)}});
      } else {
        if ((heff_intLe_c_lent(MK_INT(0LL), v_most_243, 1) && heff_intLt_c_lent(v_most_243, v_least_242, 0))) {
          heff_drop(v_i_241);
          heff_drop(v_least_242);
          heff_drop(v_most_243);
          heff_drop_rec(v_f_245, 3);
          heff_drop(v_it1_248);
          heff_drop(v_it2_249);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2erepeatedIn_24cpr_str5), MK_INT(0LL)}});
        } else {
          if ((heff_intLt_c_lent(v_i_241, heff_strLength_lent(v_s_240, 0), 2) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)63ULL)))) {
            V v_t_2415 = heff_tag_n(TAG_Repeat, 4, (V[]){v_least_242, v_most_243, NTAG(TAG_False), v_it1_248});
            V v_f_2416 = ({ V rv_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_it2_249}); V rr_ = heff_rec_reuse_nf(v_f_245, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            V v_f_2417 = heff_intAdd(v_i_241, MK_INT(1LL));
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2416, v_f_2417}});
          } else {
            V v_t_2418 = heff_tag_n(TAG_Repeat, 4, (V[]){v_least_242, v_most_243, NTAG(TAG_True), v_it1_248});
            V v_f_2419 = ({ V rv_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_it2_249}); V rr_ = heff_rec_reuse_nf(v_f_245, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2419, v_i_241}});
          }
        }
      }
    }
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_t_246)}});
  }
}
HEFF_LIT(g_regex_2ereadFrom_24cpr_str0, 17, "a `(` with no `)`");
HEFF_LIT(g_regex_2ereadFrom_24cpr_str1, 3, "(\?:");
HEFF_LIT(g_regex_2ereadFrom_24cpr_str2, 46, "flags and named groups, `(\?...)`, are not read");
HEFF_LIT(g_regex_2ereadFrom_24cpr_str3, 17, "a `)` with no `(`");
HEFF_LIT(g_regex_2ereadFrom_24cpr_str4, 1, "{");

HeffT3 g_regex_2ereadFrom_24cpr(V v_s_240, V v_i_241, V v_groups_242, V v_top_243, V v_outer_244) {
top: ;
  if (heff_intLe_c_lent(heff_strLength_lent(v_s_240, 0), v_i_241, 1)) {
    heff_drop(v_i_241);
    switch (heff_tag_of(v_outer_244)) {
    case TAG_Nil: {
      V v_t_245 = (g_regex_2eclosed(v_top_243));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_245, v_groups_242}});
    }
    case TAG_Cons: {
      heff_take_n(v_outer_244, 0ULL, 2);
      heff_drop(v_groups_242);
      heff_drop_rec(v_top_243, 3);
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2ereadFrom_24cpr_str0), MK_INT(0LL)}});
    }
    default: return ((HeffT3){{heff_nomatch(v_outer_244)}});
    }
  } else {
    V v_c_248 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    if ((heff_peek_word(v_c_248) == ((int64_t)40ULL))) {
      heff_drop(v_c_248);
      V v_t_249 = heff_strSlice_lent(v_s_240, v_i_241, heff_intAdd_lent(v_i_241, MK_INT(3LL), 2), 4);
      if (heff_strEq_c(heff_strSlice(v_t_249, MK_INT(0LL), MK_INT(3LL)), ((V)&g_regex_2ereadFrom_24cpr_str1))) {
        V v_t_2410 = heff_rec_n(3, shape_group__branches__current, (V[]){MK_INT(-1LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(3LL));
        V t_2 = v_groups_242;
        V t_3 = v_t_2410;
        V t_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_top_243, v_outer_244});
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_groups_242 = t_2;
        v_top_243 = t_3;
        v_outer_244 = t_4;
        goto top;
      } else {
        if ((heff_intLt_c(heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)63ULL)))) {
          heff_drop(v_i_241);
          heff_drop(v_groups_242);
          heff_drop_rec(v_top_243, 3);
          heff_drop(v_outer_244);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2ereadFrom_24cpr_str2), MK_INT(0LL)}});
        } else {
          V v_t_2411 = heff_rec_n(3, shape_group__branches__current, (V[]){heff_intAdd_lent(v_groups_242, MK_INT(1LL), 2), NTAG(TAG_Nil), NTAG(TAG_Nil)});
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = heff_intAdd(v_groups_242, MK_INT(1LL));
          V t_3 = v_t_2411;
          V t_4 = heff_tag_n(TAG_Cons, 2, (V[]){v_top_243, v_outer_244});
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_groups_242 = t_2;
          v_top_243 = t_3;
          v_outer_244 = t_4;
          goto top;
        }
      }
    } else {
      if ((heff_peek_word(v_c_248) == ((int64_t)41ULL))) {
        heff_drop(v_c_248);
        switch (heff_tag_of(v_outer_244)) {
        case TAG_Nil: {
          heff_drop(v_i_241);
          heff_drop(v_groups_242);
          heff_drop_rec(v_top_243, 3);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_regex_2ereadFrom_24cpr_str3), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_parent_2412 = heff_field(v_outer_244, 0);
          V v_rest_2413 = heff_field(v_outer_244, 1);
          V v_ru_24outer_244_24Cons = heff_take_reuse_n(v_outer_244, 3ULL, 2);
          V v_x_2415;
          if (heff_intLt_c(heff_dup(heff_rfield(v_top_243, 0)), MK_INT(0LL))) {
            v_x_2415 = (g_regex_2eclosed(v_top_243));
          } else {
            V v_t_2414 = (g_regex_2eclosed(heff_dup(v_top_243)));
            v_x_2415 = heff_tag_n(TAG_Group, 2, (V[]){heff_get_n(v_top_243, 0, 3), v_t_2414});
          }
          V v_t_2416 = heff_tag_at_n(v_ru_24outer_244_24Cons, TAG_Cons, 2, (V[]){v_x_2415, heff_dup(heff_rfield(v_parent_2412, 2))});
          V v_t_2417 = ({ V rv_2 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_parent_2412, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_groups_242;
          V t_3 = v_t_2417;
          V t_4 = v_rest_2413;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_groups_242 = t_2;
          v_top_243 = t_3;
          v_outer_244 = t_4;
          goto top;
        }
        default: return ((HeffT3){{heff_nomatch(v_outer_244)}});
        }
      } else {
        if ((heff_peek_word(v_c_248) == ((int64_t)124ULL))) {
          heff_drop(v_c_248);
          V v_xs_2418 = heff_take_field(v_top_243, 2);
          V v_t_2426;
          switch (heff_tag_of(v_xs_2418)) {
          case TAG_Nil: {
            v_t_2426 = NTAG(TAG_EmptyMatch);
            break;
          }
          case TAG_Cons: {
            V v_xs2_2420 = heff_dup(heff_field(v_xs_2418, 1));
            switch (heff_tag_of(v_xs2_2420)) {
            case TAG_Nil: {
              switch (heff_tag_of(v_xs_2418)) {
              case TAG_Cons: {
                V v_x_2421 = heff_field(v_xs_2418, 0);
                heff_take_n(v_xs_2418, 1ULL, 2);
                v_t_2426 = v_x_2421;
                break;
              }
              default: heff_nomatch(v_xs_2418);
              }
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_xs2_2420, 0ULL, 2);
              V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2418));
              v_t_2426 = heff_tag_n(TAG_Concat, 1, (V[]){v_t_2425});
              break;
            }
            default: heff_nomatch(v_xs2_2420);
            }
            break;
          }
          default: heff_nomatch(v_xs_2418);
          }
          V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, heff_take_field(v_top_243, 1)});
          V v_t_2428 = ({ V rv_1 = v_t_2427; V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_top_243, 1ULL, 3, shape_group__branches__current, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_groups_242;
          V t_3 = v_t_2428;
          V t_4 = v_outer_244;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_groups_242 = t_2;
          v_top_243 = t_3;
          v_outer_244 = t_4;
          goto top;
        } else {
          if (((heff_peek_word(v_c_248) == ((int64_t)42ULL)) || ((heff_peek_word(v_c_248) == ((int64_t)43ULL)) || (heff_peek_word(v_c_248) == ((int64_t)63ULL))))) {
            V v_t_2429;
            if ((heff_peek_word(v_c_248) == ((int64_t)43ULL))) {
              v_t_2429 = MK_INT(1LL);
            } else {
              v_t_2429 = MK_INT(0LL);
            }
            V v_t_2430;
            if ((heff_unbox_word(v_c_248) == ((int64_t)63ULL))) {
              v_t_2430 = MK_INT(1LL);
            } else {
              v_t_2430 = MK_INT(-1LL);
            }
            V v_t_2431 = heff_strSlice_lent(v_s_240, v_i_241, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 4);
            HeffT3 v_t_2432 = (g_regex_2erepeatedIn_24cpr(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2429, v_t_2430, v_t_2431, v_top_243));
            {
              V v_field_2434 = v_t_2432.f[1];
              V v_field_2435 = v_t_2432.f[2];
              int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
              if ((v_tag_2433 == ((int64_t)0ULL))) {
                heff_drop(v_groups_242);
                heff_drop(v_outer_244);
                heff_drop(v_field_2435);
                V v_why_2436 = v_field_2434;
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_why_2436, MK_INT(0LL)}});
              } else {
                V v_f_2437 = v_field_2434;
                V v_j_2438 = v_field_2435;
                V t_0 = v_s_240;
                V t_1 = v_j_2438;
                V t_2 = v_groups_242;
                V t_3 = v_f_2437;
                V t_4 = v_outer_244;
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_groups_242 = t_2;
                v_top_243 = t_3;
                v_outer_244 = t_4;
                goto top;
              }
            }
          } else {
            if ((heff_peek_word(v_c_248) == ((int64_t)123ULL))) {
              heff_drop(v_c_248);
              HeffT4 v_t_2439 = (g_regex_2ecountAt_24cpr(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2)));
              {
                V v_field_2441 = v_t_2439.f[1];
                V v_field_2442 = v_t_2439.f[2];
                V v_field_2443 = v_t_2439.f[3];
                int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
                if ((v_tag_2440 == ((int64_t)0ULL))) {
                  heff_drop(v_i_241);
                  V v_j_2444 = v_field_2443;
                  V v_least_2445 = v_field_2441;
                  V v_most_2446 = v_field_2442;
                  HeffT3 v_t_2447 = (g_regex_2erepeatedIn_24cpr(v_s_240, v_j_2444, v_least_2445, v_most_2446, ((V)&g_regex_2ereadFrom_24cpr_str4), v_top_243));
                  {
                    V v_field_2449 = v_t_2447.f[1];
                    V v_field_2450 = v_t_2447.f[2];
                    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                    if ((v_tag_2448 == ((int64_t)0ULL))) {
                      heff_drop(v_groups_242);
                      heff_drop(v_outer_244);
                      heff_drop(v_field_2450);
                      V v_why_2451 = v_field_2449;
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_why_2451, MK_INT(0LL)}});
                    } else {
                      V v_f_2452 = v_field_2449;
                      V v_k_2453 = v_field_2450;
                      V t_0 = v_s_240;
                      V t_1 = v_k_2453;
                      V t_2 = v_groups_242;
                      V t_3 = v_f_2452;
                      V t_4 = v_outer_244;
                      v_s_240 = t_0;
                      v_i_241 = t_1;
                      v_groups_242 = t_2;
                      v_top_243 = t_3;
                      v_outer_244 = t_4;
                      goto top;
                    }
                  }
                } else {
                  heff_drop(v_field_2441);
                  heff_drop(v_field_2442);
                  heff_drop(v_field_2443);
                  V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(123LL), MK_INT(123LL)}), NTAG(TAG_Nil)});
                  V v_t_2455 = heff_tag_n(TAG_Runes, 2, (V[]){NTAG(TAG_False), v_t_2454});
                  V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, heff_take_field(v_top_243, 2)});
                  V v_t_2457 = ({ V rv_2 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_top_243, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                  V t_0 = v_s_240;
                  V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
                  V t_2 = v_groups_242;
                  V t_3 = v_t_2457;
                  V t_4 = v_outer_244;
                  v_s_240 = t_0;
                  v_i_241 = t_1;
                  v_groups_242 = t_2;
                  v_top_243 = t_3;
                  v_outer_244 = t_4;
                  goto top;
                }
              }
            } else {
              if ((heff_peek_word(v_c_248) == ((int64_t)94ULL))) {
                heff_drop(v_c_248);
                V v_t_2458 = heff_tag_n(TAG_Assert, 1, (V[]){NTAG(TAG_AtStart)});
                V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, heff_take_field(v_top_243, 2)});
                V v_t_2460 = ({ V rv_2 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_top_243, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                V t_0 = v_s_240;
                V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
                V t_2 = v_groups_242;
                V t_3 = v_t_2460;
                V t_4 = v_outer_244;
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_groups_242 = t_2;
                v_top_243 = t_3;
                v_outer_244 = t_4;
                goto top;
              } else {
                if ((heff_peek_word(v_c_248) == ((int64_t)36ULL))) {
                  heff_drop(v_c_248);
                  V v_t_2461 = heff_tag_n(TAG_Assert, 1, (V[]){NTAG(TAG_AtEnd)});
                  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, heff_take_field(v_top_243, 2)});
                  V v_t_2463 = ({ V rv_2 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_top_243, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                  V t_0 = v_s_240;
                  V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
                  V t_2 = v_groups_242;
                  V t_3 = v_t_2463;
                  V t_4 = v_outer_244;
                  v_s_240 = t_0;
                  v_i_241 = t_1;
                  v_groups_242 = t_2;
                  v_top_243 = t_3;
                  v_outer_244 = t_4;
                  goto top;
                } else {
                  if ((heff_peek_word(v_c_248) == ((int64_t)46ULL))) {
                    heff_drop(v_c_248);
                    V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(10LL), MK_INT(10LL)}), NTAG(TAG_Nil)});
                    V v_t_2465 = heff_tag_n(TAG_Runes, 2, (V[]){NTAG(TAG_True), v_t_2464});
                    V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, heff_take_field(v_top_243, 2)});
                    V v_t_2467 = ({ V rv_2 = v_t_2466; V rr_ = heff_rec_reuse_nf(v_top_243, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                    V t_0 = v_s_240;
                    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
                    V t_2 = v_groups_242;
                    V t_3 = v_t_2467;
                    V t_4 = v_outer_244;
                    v_s_240 = t_0;
                    v_i_241 = t_1;
                    v_groups_242 = t_2;
                    v_top_243 = t_3;
                    v_outer_244 = t_4;
                    goto top;
                  } else {
                    if ((heff_peek_word(v_c_248) == ((int64_t)91ULL))) {
                      heff_drop(v_c_248);
                      V v_s_2468 = heff_dup(v_s_240);
                      V v_i_2469 = heff_intAdd(v_i_241, MK_INT(1LL));
                      V v_it_2486;
                      if ((heff_intLt_c_lent(v_i_2469, heff_strLength_lent(v_s_2468, 0), 2) && (heff_unbox_word(heff_strByteAt_lent(v_s_2468, v_i_2469, 0)) == ((int64_t)94ULL)))) {
                        HeffT3 v_t_2470 = ({ V a_0 = v_s_2468; V a_1 = heff_intAdd(v_i_2469, MK_INT(1LL)); V a_2 = NTAG(TAG_True); V a_3 = NTAG(TAG_Nil); HeffT3 r_ = (g_regex_2eclassFrom_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_s_2468); r_; });
                        {
                          V v_field_2472 = v_t_2470.f[1];
                          V v_field_2473 = v_t_2470.f[2];
                          int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
                          if ((v_tag_2471 == ((int64_t)0ULL))) {
                            heff_drop(v_field_2473);
                            V v_why_2474 = v_field_2472;
                            v_it_2486 = heff_tag_n(TAG_Left, 1, (V[]){v_why_2474});
                          } else {
                            V v_rs_2475 = v_field_2472;
                            V v_j_2476 = v_field_2473;
                            V v_t_2477 = heff_tag_n(TAG_Runes, 2, (V[]){NTAG(TAG_True), v_rs_2475});
                            v_it_2486 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2477, v_j_2476})});
                          }
                        }
                      } else {
                        HeffT3 v_t_2478 = ({ V a_0 = v_s_2468; V a_1 = v_i_2469; V a_2 = NTAG(TAG_True); V a_3 = NTAG(TAG_Nil); HeffT3 r_ = (g_regex_2eclassFrom_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_s_2468); r_; });
                        {
                          V v_field_2480 = v_t_2478.f[1];
                          V v_field_2481 = v_t_2478.f[2];
                          int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
                          if ((v_tag_2479 == ((int64_t)0ULL))) {
                            heff_drop(v_field_2481);
                            V v_why_2482 = v_field_2480;
                            v_it_2486 = heff_tag_n(TAG_Left, 1, (V[]){v_why_2482});
                          } else {
                            V v_rs_2483 = v_field_2480;
                            V v_j_2484 = v_field_2481;
                            V v_t_2485 = heff_tag_n(TAG_Runes, 2, (V[]){NTAG(TAG_False), v_rs_2483});
                            v_it_2486 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2485, v_j_2484})});
                          }
                        }
                      }
                      switch (heff_tag_of(v_it_2486)) {
                      case TAG_Left: {
                        V v_why_2487 = heff_field(v_it_2486, 0);
                        heff_take_n(v_it_2486, 1ULL, 1);
                        heff_drop(v_groups_242);
                        heff_drop_rec(v_top_243, 3);
                        heff_drop(v_outer_244);
                        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_why_2487, MK_INT(0LL)}});
                      }
                      case TAG_Right: {
                        V v_it1_2488 = heff_field(v_it_2486, 0);
                        heff_take_n(v_it_2486, 1ULL, 1);
                        switch (heff_tag_of(v_it1_2488)) {
                        case TAG_MkPair: {
                          V v_x_2489 = heff_field(v_it1_2488, 0);
                          V v_j_2490 = heff_field(v_it1_2488, 1);
                          V v_ru_24it1_2488_24MkPair = heff_take_reuse_n(v_it1_2488, 3ULL, 2);
                          V v_t_2491 = heff_tag_at_n(v_ru_24it1_2488_24MkPair, TAG_Cons, 2, (V[]){v_x_2489, heff_dup(heff_rfield(v_top_243, 2))});
                          V v_t_2492 = ({ V rv_2 = v_t_2491; V rr_ = heff_rec_reuse_nf(v_top_243, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                          V t_0 = v_s_240;
                          V t_1 = v_j_2490;
                          V t_2 = v_groups_242;
                          V t_3 = v_t_2492;
                          V t_4 = v_outer_244;
                          v_s_240 = t_0;
                          v_i_241 = t_1;
                          v_groups_242 = t_2;
                          v_top_243 = t_3;
                          v_outer_244 = t_4;
                          goto top;
                        }
                        default: return ((HeffT3){{heff_nomatch(v_it1_2488)}});
                        }
                      }
                      default: return ((HeffT3){{heff_nomatch(v_it_2486)}});
                      }
                    } else {
                      if ((heff_unbox_word(v_c_248) == ((int64_t)92ULL))) {
                        HeffT3 v_t_2493 = (g_regex_2eescapeAt_24cpr(v_s_240, v_i_241));
                        {
                          V v_field_2495 = v_t_2493.f[1];
                          V v_field_2496 = v_t_2493.f[2];
                          int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
                          if ((v_tag_2494 == ((int64_t)0ULL))) {
                            heff_drop(v_groups_242);
                            heff_drop_rec(v_top_243, 3);
                            heff_drop(v_outer_244);
                            heff_drop(v_field_2496);
                            V v_why_2497 = v_field_2495;
                            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_why_2497, MK_INT(0LL)}});
                          } else {
                            V v_x_2498 = v_field_2495;
                            V v_j_2499 = v_field_2496;
                            V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2498, heff_take_field(v_top_243, 2)});
                            V v_t_24101 = ({ V rv_2 = v_t_24100; V rr_ = heff_rec_reuse_nf(v_top_243, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                            V t_0 = v_s_240;
                            V t_1 = v_j_2499;
                            V t_2 = v_groups_242;
                            V t_3 = v_t_24101;
                            V t_4 = v_outer_244;
                            v_s_240 = t_0;
                            v_i_241 = t_1;
                            v_groups_242 = t_2;
                            v_top_243 = t_3;
                            v_outer_244 = t_4;
                            goto top;
                          }
                        }
                      } else {
                        HeffT2 v_t_24102 = heff_strRuneDecode_lent(v_s_240, v_i_241, 0);
                        {
                          V v_rune_24103 = v_t_24102.f[0];
                          V v_width_24104 = v_t_24102.f[1];
                          V v_r_24105 = heff_runeToInt(v_rune_24103);
                          V v_j_24106 = heff_intAdd(v_i_241, v_width_24104);
                          V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_r_24105), v_r_24105}), NTAG(TAG_Nil)});
                          V v_t_24108 = heff_tag_n(TAG_Runes, 2, (V[]){NTAG(TAG_False), v_t_24107});
                          V v_t_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, heff_take_field(v_top_243, 2)});
                          V v_t_24110 = ({ V rv_2 = v_t_24109; V rr_ = heff_rec_reuse_nf(v_top_243, 3ULL, 3, shape_group__branches__current, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                          V t_0 = v_s_240;
                          V t_1 = v_j_24106;
                          V t_2 = v_groups_242;
                          V t_3 = v_t_24110;
                          V t_4 = v_outer_244;
                          v_s_240 = t_0;
                          v_i_241 = t_1;
                          v_groups_242 = t_2;
                          v_top_243 = t_3;
                          v_outer_244 = t_4;
                          goto top;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
Clo g_regex_2esizeOf_clo = {{0x80000000u, K_CLO, 0}, g_regex_2esizeOf_entry, 1, 0};

V g_regex_2esizeOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EmptyMatch: {
    return MK_INT(0LL);
  }
  case TAG_Runes: {
    return MK_INT(1LL);
  }
  case TAG_Assert: {
    return MK_INT(1LL);
  }
  case TAG_Group: {
    V v_x_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_regex_2esizeOf(v_x_245));
    return heff_intAdd(v_t_246, MK_INT(2LL));
  }
  case TAG_Concat: {
    V v_xs_247 = heff_field(v_x1_240, 0);
    return ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_regex_2esizeOf_clo); V a_2 = v_xs_247; V r_ = (g_list_2efoldl_24f2005293661x823011722(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  }
  case TAG_Alternate: {
    V v_xs_248 = heff_field(v_x1_240, 0);
    V v_t_249 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_regex_2esizeOf_clo); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24f2005293661x823011722(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
    V v_t_2411 = heff_intMul(MK_INT(2LL), heff_intSub(v_t_2410, MK_INT(1LL)));
    return heff_intAdd(v_t_249, v_t_2411);
  }
  case TAG_Repeat: {
    V v_least_2412 = heff_field(v_x1_240, 0);
    V v_most_2413 = heff_field(v_x1_240, 1);
    V v_x_2415 = heff_field(v_x1_240, 3);
    V v_t_2416 = (g_regex_2esizeOf(v_x_2415));
    V v_t_2419;
    if (heff_intLt_c_lent(v_most_2413, MK_INT(0LL), 2)) {
      V v_t_2417 = (g_regex_2esizeOf(v_x_2415));
      v_t_2419 = heff_intAdd(v_t_2417, MK_INT(2LL));
    } else {
      V v_t_2418 = (g_regex_2esizeOf(v_x_2415));
      v_t_2419 = heff_intMul(heff_intSub_lent(v_most_2413, v_least_2412, 0), heff_intAdd(v_t_2418, MK_INT(1LL)));
    }
    return heff_intAdd(heff_intMul_lent(v_least_2412, v_t_2416, 2), v_t_2419);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_regex_2esizeOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_regex_2esizeOf(a0); heff_drop(a0); return r;
}
Clo g_regex_2eemit_clo = {{0x80000000u, K_CLO, 0}, g_regex_2eemit_entry, 2, 0};

V g_regex_2eemit(V v_x1_240, V v_at_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EmptyMatch: {
    heff_drop(v_at_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Runes: {
    V v_neg_242 = heff_field(v_x1_240, 0);
    V v_rs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Runes = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    heff_drop(v_at_241);
    return heff_tag_at_n(v_ru_24x1_240_24Runes, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Take, 2, (V[]){v_neg_242, v_rs_243}), NTAG(TAG_Nil)});
  }
  case TAG_Assert: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Assert = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_at_241);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Assert, TAG_Hold, 1, (V[]){v_a_244}), NTAG(TAG_Nil)});
  }
  case TAG_Group: {
    V v_n_245 = heff_field(v_x1_240, 0);
    V v_x_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Group = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247 = (g_regex_2eemit(v_x_246, heff_intAdd(v_at_241, MK_INT(1LL))));
    V v_t_248 = heff_intAdd(heff_intMul_lent(MK_INT(2LL), v_n_245, 1), MK_INT(1LL));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24Group, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Keep, 1, (V[]){v_t_248}), NTAG(TAG_Nil)});
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_247, v_t_249));
    V v_t_2411 = heff_tag_n(TAG_Keep, 1, (V[]){heff_intMul(MK_INT(2LL), v_n_245)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2410});
  }
  case TAG_Concat: {
    V v_xs_2412 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){v_at_241, NTAG(TAG_Nil)});
    V v_x1_2414 = (g_list_2efoldl_24s1799718634x73643635(v_t_2413, v_xs_2412));
    V v_t_2417;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_MkPair: {
      V v_y_2416 = heff_field(v_x1_2414, 1);
      heff_take_n(v_x1_2414, 2ULL, 2);
      v_t_2417 = v_y_2416;
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2417));
    return heff_arrayToList(heff_arrayFromList(v_t_2418));
  }
  case TAG_Alternate: {
    V v_x11_2419 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Alternate = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2419)) {
    case TAG_Nil: {
      heff_drop(v_at_241);
      heff_drop_cell(v_ru_24x1_240_24Alternate, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x11_2419, 0);
      V v_x112_2421 = heff_field(v_x11_2419, 1);
      V v_ru_24x11_2419_24Cons = heff_take_reuse_n(v_x11_2419, 3ULL, 2);
      switch (heff_tag_of(v_x112_2421)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Alternate, 1);
        heff_drop_cell(v_ru_24x11_2419_24Cons, 2);
        V t_0 = v_x_2420;
        V t_1 = v_at_241;
        v_x1_240 = t_0;
        v_at_241 = t_1;
        goto top;
      }
      case TAG_Cons: {
        V v_t_2424 = (g_regex_2esizeOf(v_x_2420));
        V v_t_2425 = (g_regex_2eemit(heff_dup(v_x_2420), heff_intAdd_lent(v_at_241, MK_INT(1LL), 2)));
        V v_t_2426 = (g_regex_2esizeOf(v_x_2420));
        V v_t_2427 = (g_list_2emap_24s1041642916x1626051668(heff_dup(v_x112_2421)));
        V v_xs_2428 = heff_tag_at_n(v_ru_24x11_2419_24Cons, TAG_Cons, 2, (V[]){v_t_2426, v_t_2427});
        V v_t_2429 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2428; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop_tag(v_xs_2428, 2); r_; });
        V v_t_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2420), heff_dup(v_x112_2421)}); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_2431 = ({ V a_0 = v_x_2420; V r_ = (g_regex_2esizeOf(a_0)); heff_drop(v_x_2420); r_; });
        V v_t_2432 = heff_intAdd(heff_intAdd_lent(v_at_241, v_t_2431, 2), MK_INT(2LL));
        V v_t_2433 = (g_regex_2eemit(heff_tag_at_n(v_ru_24x1_240_24Alternate, TAG_Alternate, 1, (V[]){v_x112_2421}), v_t_2432));
        V v_t_2434 = heff_intMul(MK_INT(2LL), heff_intSub(v_t_2430, MK_INT(1LL)));
        V v_t_2435 = heff_intAdd(heff_dup(v_at_241), heff_intAdd(v_t_2429, v_t_2434));
        V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Jump, 1, (V[]){v_t_2435}), v_t_2433});
        V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2436));
        V v_t_2438 = heff_intAdd(heff_intAdd_lent(v_at_241, v_t_2424, 2), MK_INT(2LL));
        V v_t_2439 = heff_tag_n(TAG_Fork, 2, (V[]){heff_intAdd(v_at_241, MK_INT(1LL)), v_t_2438});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_t_2437});
      }
      default: return heff_nomatch(v_x112_2421);
      }
    }
    default: return heff_nomatch(v_x11_2419);
    }
  }
  case TAG_Repeat: {
    V v_least_2440 = heff_field(v_x1_240, 0);
    V v_most_2441 = heff_field(v_x1_240, 1);
    V v_greedy_2442 = heff_field(v_x1_240, 2);
    V v_x_2443 = heff_field(v_x1_240, 3);
    V v_ru_24x1_240_24Repeat = heff_take_reuse_n(v_x1_240, 15ULL, 4);
    if (heff_intLt_c_lent(MK_INT(0LL), v_least_2440, 1)) {
      V v_t_2444 = (g_regex_2eemit(heff_dup(v_x_2443), heff_dup(v_at_241)));
      V v_t_2445;
      if (heff_intLt_c_lent(v_most_2441, MK_INT(0LL), 2)) {
        v_t_2445 = v_most_2441;
      } else {
        v_t_2445 = heff_intSub(v_most_2441, MK_INT(1LL));
      }
      V v_t_2446 = (g_regex_2esizeOf(v_x_2443));
      V v_t_2447 = heff_tag_re_n(v_ru_24x1_240_24Repeat, TAG_Repeat, 4, 12ULL, (V[]){heff_intSub(v_least_2440, MK_INT(1LL)), v_t_2445, v_greedy_2442, v_x_2443});
      V v_t_2448 = (g_regex_2eemit(v_t_2447, heff_intAdd(v_at_241, v_t_2446)));
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2444, v_t_2448);
    } else {
      heff_drop(v_least_2440);
      heff_drop_cell(v_ru_24x1_240_24Repeat, 4);
      if (heff_intLt_c_lent(v_most_2441, MK_INT(0LL), 2)) {
        heff_drop(v_most_2441);
        V v_more_2449 = heff_intAdd_lent(v_at_241, MK_INT(1LL), 2);
        V v_t_2450 = (g_regex_2esizeOf(v_x_2443));
        V v_fewer_2451 = heff_intAdd(heff_intAdd_lent(v_at_241, v_t_2450, 2), MK_INT(2LL));
        V v_t_2452;
        if ((heff_dup(v_greedy_2442) == NTAG(TAG_True))) {
          heff_drop(v_greedy_2442);
          v_t_2452 = heff_tag_n(TAG_Fork, 2, (V[]){v_more_2449, v_fewer_2451});
        } else {
          heff_drop(v_greedy_2442);
          v_t_2452 = heff_tag_n(TAG_Fork, 2, (V[]){v_fewer_2451, v_more_2449});
        }
        V v_t_2453 = (g_regex_2eemit(v_x_2443, heff_intAdd_lent(v_at_241, MK_INT(1LL), 2)));
        V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Jump, 1, (V[]){v_at_241}), NTAG(TAG_Nil)});
        V v_t_2455 = (g_prelude_2e_2b_2b(v_t_2453, v_t_2454));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, v_t_2455});
      } else {
        if (heff_intEq_c_lent(v_most_2441, MK_INT(0LL), 2)) {
          heff_drop(v_at_241);
          heff_drop(v_most_2441);
          heff_drop(v_greedy_2442);
          heff_drop(v_x_2443);
          return NTAG(TAG_Nil);
        } else {
          V v_more_2456 = heff_intAdd_lent(v_at_241, MK_INT(1LL), 2);
          V v_t_2457 = (g_regex_2esizeOf(v_x_2443));
          V v_t_2460;
          if (heff_intLt_c_lent(v_most_2441, MK_INT(0LL), 2)) {
            V v_t_2458 = (g_regex_2esizeOf(v_x_2443));
            v_t_2460 = heff_intAdd(v_t_2458, MK_INT(2LL));
          } else {
            V v_t_2459 = (g_regex_2esizeOf(v_x_2443));
            v_t_2460 = heff_intMul(heff_intSub_lent(v_most_2441, MK_INT(0LL), 2), heff_intAdd(v_t_2459, MK_INT(1LL)));
          }
          V v_t_2461 = heff_intAdd(heff_intMul(MK_INT(0LL), v_t_2457), v_t_2460);
          V v_fewer_2462 = heff_intAdd_lent(v_at_241, v_t_2461, 2);
          V v_t_2463;
          if ((heff_dup(v_greedy_2442) == NTAG(TAG_True))) {
            v_t_2463 = heff_tag_n(TAG_Fork, 2, (V[]){v_more_2456, v_fewer_2462});
          } else {
            v_t_2463 = heff_tag_n(TAG_Fork, 2, (V[]){v_fewer_2462, v_more_2456});
          }
          V v_t_2464 = (g_regex_2eemit(heff_dup(v_x_2443), heff_intAdd_lent(v_at_241, MK_INT(1LL), 2)));
          V v_t_2465 = (g_regex_2esizeOf(v_x_2443));
          V v_t_2466 = (g_regex_2esizeOf(v_x_2443));
          V v_t_2469;
          if (heff_intLt_c_lent(v_most_2441, MK_INT(0LL), 2)) {
            V v_t_2467 = (g_regex_2esizeOf(v_x_2443));
            v_t_2469 = heff_intAdd(v_t_2467, MK_INT(2LL));
          } else {
            V v_t_2468 = (g_regex_2esizeOf(v_x_2443));
            v_t_2469 = heff_intMul(heff_intSub_lent(v_most_2441, MK_INT(0LL), 2), heff_intAdd(v_t_2468, MK_INT(1LL)));
          }
          V v_t_2470 = heff_intAdd(heff_intAdd_lent(v_at_241, v_t_2465, 2), MK_INT(1LL));
          V v_t_2471 = heff_intAdd(heff_intMul(MK_INT(0LL), v_t_2466), v_t_2469);
          V v_t_2472 = ({ V a_0 = v_greedy_2442; V a_1 = v_x_2443; V a_2 = heff_intSub(v_most_2441, MK_INT(1LL)); V a_3 = v_t_2470; V b_4 = heff_intAdd(v_at_241, v_t_2471); V r_ = (g_regex_2eemit_2eemitOptional_241(a_0, a_1, a_2, a_3, b_4)); heff_drop(v_greedy_2442); heff_drop(v_x_2443); heff_drop(b_4); r_; });
          V v_t_2473 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2472));
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, v_t_2473});
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_regex_2eemit_entry(V self, V *a) {
  (void)self;
  return g_regex_2eemit(a[0], a[1]);
}

HeffT2 g_regex_2eallRead_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      V v_why_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_243}});
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_x_245 = v_x_244;
      HeffT2 v_t_246 = (g_regex_2eallRead_24cpr(v_rest_242));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_245);
          V v_why_249 = v_field_248;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_249}});
        } else {
          V v_xs_2410 = v_field_248;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_xs_2410})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_regex_2ewordBefore_clo = {{0x80000000u, K_CLO, 0}, g_regex_2ewordBefore_entry, 2, 0};

V g_regex_2ewordBefore(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    if (heff_intLe_c_lent(v_i_241, heff_strLength_lent(v_s_240, 0), 2)) {
      V v_c_242 = heff_strByteAt(heff_dup(v_s_240), heff_box_word((heff_unbox_word(v_i_241) - ((int64_t)1ULL))));
      V v_ret_24bool = heff_bool(((((((int64_t)48ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)57ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_242)) && (heff_peek_word(v_c_242) <= ((int64_t)122ULL))))) || (heff_peek_word(v_c_242) == ((int64_t)95ULL))));
      heff_drop(v_c_242);
      return v_ret_24bool;
    } else {
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_i_241);
    return NTAG(TAG_False);
  }
}
V g_regex_2ewordBefore_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_regex_2ewordBefore(a0, a[1]); heff_drop(a0); return r;
}
Clo g_regex_2eholds_clo = {{0x80000000u, K_CLO, 0}, g_regex_2eholds_entry, 3, 0};

V g_regex_2eholds(V v_x1_240, V v_s_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_AtStart: {
    V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_i_242, MK_INT(0LL), 2));
    heff_drop(v_i_242);
    return v_ret_24bool;
  }
  case TAG_AtEnd: {
    V v_ret_24bool = heff_bool(heff_intEq_c_lent(v_i_242, heff_strLength_lent(v_s_241, 0), 2));
    heff_drop(v_i_242);
    return v_ret_24bool;
  }
  case TAG_AtWordBoundary: {
    V v_x_243 = (g_regex_2ewordBefore(v_s_241, heff_dup(v_i_242)));
    if (heff_intLt_c_lent(v_i_242, heff_strLength_lent(v_s_241, 0), 2)) {
      V v_c_244 = heff_strByteAt_lent(v_s_241, v_i_242, 2);
      V v_y_245 = heff_bool(((((((int64_t)48ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)57ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)122ULL))))) || (heff_peek_word(v_c_244) == ((int64_t)95ULL))));
      heff_drop(v_c_244);
      V v_ret_24bool = heff_bool(((heff_dup(v_x_243) == NTAG(TAG_True)) ? !(heff_dup(v_y_245) == NTAG(TAG_True)) : (heff_dup(v_y_245) == NTAG(TAG_True))));
      heff_drop(v_x_243);
      heff_drop(v_y_245);
      return v_ret_24bool;
    } else {
      heff_drop(v_i_242);
      return v_x_243;
    }
  }
  case TAG_NotAtWordBoundary: {
    V v_a_246 = (g_regex_2ewordBefore(v_s_241, heff_dup(v_i_242)));
    if (heff_intLt_c_lent(v_i_242, heff_strLength_lent(v_s_241, 0), 2)) {
      V v_c_247 = heff_strByteAt_lent(v_s_241, v_i_242, 2);
      V v_b_248 = heff_bool(((((((int64_t)48ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)57ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)90ULL))) || ((((int64_t)97ULL) <= heff_peek_word(v_c_247)) && (heff_peek_word(v_c_247) <= ((int64_t)122ULL))))) || (heff_peek_word(v_c_247) == ((int64_t)95ULL))));
      heff_drop(v_c_247);
      V v_ret_24bool = heff_bool(((heff_dup(v_a_246) == NTAG(TAG_True)) ? (heff_dup(v_b_248) == NTAG(TAG_True)) : !(heff_dup(v_b_248) == NTAG(TAG_True))));
      heff_drop(v_a_246);
      heff_drop(v_b_248);
      return v_ret_24bool;
    } else {
      heff_drop(v_i_242);
      V v_ret_24bool = heff_bool(!(heff_dup(v_a_246) == NTAG(TAG_True)));
      heff_drop(v_a_246);
      return v_ret_24bool;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_regex_2eholds_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_regex_2eholds(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_regex_2egather_clo = {{0x80000000u, K_CLO, 0}, g_regex_2egather_entry, 6, 0};

V g_regex_2egather(V v_prog_240, V v_s_241, V v_i_242, V v_pc_243, V v_slots_244, V v_g_245) {
top: ;
  V v_xs_246 = heff_dup(heff_rfield(v_g_245, 0));
  if ((heff_intLe_c_lent(MK_INT(0LL), v_pc_243, 1) && heff_intLt_c_lent(v_pc_243, heff_arrayLength_lent(v_xs_246, 0), 2))) {
    V v_t_247 = heff_arrayIndex_lent(v_xs_246, v_pc_243, 1);
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_pc_243);
      heff_drop(v_slots_244);
      heff_drop(v_t_247);
      return v_g_245;
    } else {
      heff_drop(v_t_247);
      V v_t_248 = heff_arraySet(heff_take_field(v_g_245, 0), heff_dup(v_pc_243), NTAG(TAG_True));
      V v_h_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_g_245, 2ULL, 2, shape_seen__threads, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      if (((((int64_t)0ULL) <= heff_peek_word(v_pc_243)) && (heff_peek_word(v_pc_243) < heff_unbox_word(heff_arrayLength_lent(v_prog_240, 0))))) {
        V v_t_2410 = heff_arrayPeek(v_prog_240, heff_dup(v_pc_243));
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Take: {
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_step__slots, (V[]){v_pc_243, v_slots_244}), heff_take_field(v_h_249, 1)});
          return ({ V rv_1 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_h_249, 1ULL, 2, shape_seen__threads, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        case TAG_Fork: {
          V v_a_2414 = heff_field(v_t_2410, 0);
          V v_b_2415 = heff_field(v_t_2410, 1);
          heff_drop(v_pc_243);
          V v_t_2416 = (g_regex_2egather(v_prog_240, v_s_241, v_i_242, heff_dup(v_a_2414), heff_dup(v_slots_244), v_h_249));
          V t_0 = v_prog_240;
          V t_1 = v_s_241;
          V t_2 = v_i_242;
          V t_3 = heff_dup(v_b_2415);
          V t_4 = v_slots_244;
          V t_5 = v_t_2416;
          v_prog_240 = t_0;
          v_s_241 = t_1;
          v_i_242 = t_2;
          v_pc_243 = t_3;
          v_slots_244 = t_4;
          v_g_245 = t_5;
          goto top;
        }
        case TAG_Jump: {
          V v_t_2417 = heff_field(v_t_2410, 0);
          heff_drop(v_pc_243);
          V t_0 = v_prog_240;
          V t_1 = v_s_241;
          V t_2 = v_i_242;
          V t_3 = heff_dup(v_t_2417);
          V t_4 = v_slots_244;
          V t_5 = v_h_249;
          v_prog_240 = t_0;
          v_s_241 = t_1;
          v_i_242 = t_2;
          v_pc_243 = t_3;
          v_slots_244 = t_4;
          v_g_245 = t_5;
          goto top;
        }
        case TAG_Keep: {
          V v_n_2418 = heff_field(v_t_2410, 0);
          V t_0 = v_prog_240;
          V t_1 = v_s_241;
          V t_2 = v_i_242;
          V t_3 = heff_box_word((heff_unbox_word(v_pc_243) + ((int64_t)1ULL)));
          V t_4 = heff_arraySet(v_slots_244, heff_dup(v_n_2418), heff_dup(v_i_242));
          V t_5 = v_h_249;
          v_prog_240 = t_0;
          v_s_241 = t_1;
          v_i_242 = t_2;
          v_pc_243 = t_3;
          v_slots_244 = t_4;
          v_g_245 = t_5;
          goto top;
        }
        case TAG_Hold: {
          V v_a_2419 = heff_field(v_t_2410, 0);
          V v_t_2420 = (g_regex_2eholds(v_a_2419, v_s_241, heff_dup(v_i_242)));
          if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
            heff_drop(v_t_2420);
            V t_0 = v_prog_240;
            V t_1 = v_s_241;
            V t_2 = v_i_242;
            V t_3 = heff_box_word((heff_unbox_word(v_pc_243) + ((int64_t)1ULL)));
            V t_4 = v_slots_244;
            V t_5 = v_h_249;
            v_prog_240 = t_0;
            v_s_241 = t_1;
            v_i_242 = t_2;
            v_pc_243 = t_3;
            v_slots_244 = t_4;
            v_g_245 = t_5;
            goto top;
          } else {
            heff_drop(v_pc_243);
            heff_drop(v_slots_244);
            heff_drop(v_t_2420);
            return v_h_249;
          }
        }
        case TAG_Done: {
          V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_step__slots, (V[]){v_pc_243, v_slots_244}), heff_take_field(v_h_249, 1)});
          return ({ V rv_1 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_h_249, 1ULL, 2, shape_seen__threads, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        }
        default: return heff_nomatch(v_t_2410);
        }
      } else {
        V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_step__slots, (V[]){v_pc_243, v_slots_244}), heff_take_field(v_h_249, 1)});
        return ({ V rv_1 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_h_249, 1ULL, 2, shape_seen__threads, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      }
    }
  } else {
    heff_drop(v_pc_243);
    heff_drop(v_slots_244);
    heff_drop(v_xs_246);
    return v_g_245;
  }
}
V g_regex_2egather_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_regex_2egather(a0, a1, a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_regex_2estepThreads_24scalars_24cpr(V v_prog_240, V v_s_241, V v_j_242, V v_c_243, V v_x5_244, V v_next_245, V v_found_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    return ((HeffT2){{v_next_245, heff_dup(v_found_246)}});
  }
  case TAG_Cons: {
    V v_t_247 = heff_field(v_x5_244, 0);
    V v_rest_248 = heff_field(v_x5_244, 1);
    V v_step_249 = heff_dup(heff_rfield(v_t_247, 0));
    V v_slots_2410 = heff_dup(heff_rfield(v_t_247, 1));
    V v_i_2411 = heff_dup(v_step_249);
    if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2411, 1) && heff_intLt_c_lent(v_i_2411, heff_arrayLength_lent(v_prog_240, 0), 2))) {
      V v_t_2412 = heff_arrayPeek(v_prog_240, v_i_2411);
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Take: {
        V v_neg_2413 = heff_field(v_t_2412, 0);
        V v_rs_2414 = heff_field(v_t_2412, 1);
        if (heff_intLe_c_lent(MK_INT(0LL), v_c_243, 1)) {
          V v_x_2415 = heff_tr(heff_call(heff_dup(g_regex_2estepThreads_2einRanges_240_get()), 2, (V[]){heff_dup(v_c_243), heff_dup(v_rs_2414)}));
          if (((heff_dup(v_x_2415) == NTAG(TAG_True)) ? !(heff_dup(v_neg_2413) == NTAG(TAG_True)) : (heff_dup(v_neg_2413) == NTAG(TAG_True)))) {
            heff_drop(v_x_2415);
            V v_t_2416 = (g_regex_2egather(v_prog_240, v_s_241, v_j_242, heff_intAdd(v_step_249, MK_INT(1LL)), v_slots_2410, v_next_245));
            V t_0 = v_prog_240;
            V t_1 = v_s_241;
            V t_2 = v_j_242;
            V t_3 = v_c_243;
            V t_4 = v_rest_248;
            V t_5 = v_t_2416;
            V t_6 = v_found_246;
            v_prog_240 = t_0;
            v_s_241 = t_1;
            v_j_242 = t_2;
            v_c_243 = t_3;
            v_x5_244 = t_4;
            v_next_245 = t_5;
            v_found_246 = t_6;
            goto top;
          } else {
            heff_drop(v_step_249);
            heff_drop(v_slots_2410);
            heff_drop(v_x_2415);
            V t_0 = v_prog_240;
            V t_1 = v_s_241;
            V t_2 = v_j_242;
            V t_3 = v_c_243;
            V t_4 = v_rest_248;
            V t_5 = v_next_245;
            V t_6 = v_found_246;
            v_prog_240 = t_0;
            v_s_241 = t_1;
            v_j_242 = t_2;
            v_c_243 = t_3;
            v_x5_244 = t_4;
            v_next_245 = t_5;
            v_found_246 = t_6;
            goto top;
          }
        } else {
          heff_drop(v_step_249);
          heff_drop(v_slots_2410);
          V t_0 = v_prog_240;
          V t_1 = v_s_241;
          V t_2 = v_j_242;
          V t_3 = v_c_243;
          V t_4 = v_rest_248;
          V t_5 = v_next_245;
          V t_6 = v_found_246;
          v_prog_240 = t_0;
          v_s_241 = t_1;
          v_j_242 = t_2;
          v_c_243 = t_3;
          v_x5_244 = t_4;
          v_next_245 = t_5;
          v_found_246 = t_6;
          goto top;
        }
      }
      case TAG_Fork: {
        heff_drop(v_step_249);
        heff_drop(v_slots_2410);
        V t_0 = v_prog_240;
        V t_1 = v_s_241;
        V t_2 = v_j_242;
        V t_3 = v_c_243;
        V t_4 = v_rest_248;
        V t_5 = v_next_245;
        V t_6 = v_found_246;
        v_prog_240 = t_0;
        v_s_241 = t_1;
        v_j_242 = t_2;
        v_c_243 = t_3;
        v_x5_244 = t_4;
        v_next_245 = t_5;
        v_found_246 = t_6;
        goto top;
      }
      case TAG_Jump: {
        heff_drop(v_step_249);
        heff_drop(v_slots_2410);
        V t_0 = v_prog_240;
        V t_1 = v_s_241;
        V t_2 = v_j_242;
        V t_3 = v_c_243;
        V t_4 = v_rest_248;
        V t_5 = v_next_245;
        V t_6 = v_found_246;
        v_prog_240 = t_0;
        v_s_241 = t_1;
        v_j_242 = t_2;
        v_c_243 = t_3;
        v_x5_244 = t_4;
        v_next_245 = t_5;
        v_found_246 = t_6;
        goto top;
      }
      case TAG_Keep: {
        heff_drop(v_step_249);
        heff_drop(v_slots_2410);
        V t_0 = v_prog_240;
        V t_1 = v_s_241;
        V t_2 = v_j_242;
        V t_3 = v_c_243;
        V t_4 = v_rest_248;
        V t_5 = v_next_245;
        V t_6 = v_found_246;
        v_prog_240 = t_0;
        v_s_241 = t_1;
        v_j_242 = t_2;
        v_c_243 = t_3;
        v_x5_244 = t_4;
        v_next_245 = t_5;
        v_found_246 = t_6;
        goto top;
      }
      case TAG_Hold: {
        heff_drop(v_step_249);
        heff_drop(v_slots_2410);
        V t_0 = v_prog_240;
        V t_1 = v_s_241;
        V t_2 = v_j_242;
        V t_3 = v_c_243;
        V t_4 = v_rest_248;
        V t_5 = v_next_245;
        V t_6 = v_found_246;
        v_prog_240 = t_0;
        v_s_241 = t_1;
        v_j_242 = t_2;
        v_c_243 = t_3;
        v_x5_244 = t_4;
        v_next_245 = t_5;
        v_found_246 = t_6;
        goto top;
      }
      case TAG_Done: {
        heff_drop(v_step_249);
        V v_f_2422 = heff_tag_n(TAG_Just, 1, (V[]){v_slots_2410});
        return ((HeffT2){{v_next_245, v_f_2422}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2412)}});
      }
    } else {
      heff_drop(v_step_249);
      heff_drop(v_slots_2410);
      heff_drop(v_i_2411);
      V t_0 = v_prog_240;
      V t_1 = v_s_241;
      V t_2 = v_j_242;
      V t_3 = v_c_243;
      V t_4 = v_rest_248;
      V t_5 = v_next_245;
      V t_6 = v_found_246;
      v_prog_240 = t_0;
      v_s_241 = t_1;
      v_j_242 = t_2;
      v_c_243 = t_3;
      v_x5_244 = t_4;
      v_next_245 = t_5;
      v_found_246 = t_6;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
  }
}

HeffT2 g_regex_2estepThreads_24cpr(V v_prog_240, V v_s_241, V v_j_242, V v_c_243, V v_x5_244, V v_st_245) {
top: ;
  V v_next_246 = heff_take_field(v_st_245, 0);
  V v_found_247 = heff_get_n(v_st_245, 1, 2);
  return ({ V a_0 = v_prog_240; V a_1 = v_s_241; V a_2 = v_j_242; V a_3 = v_c_243; V a_4 = v_x5_244; V a_5 = v_next_246; V a_6 = v_found_247; HeffT2 r_ = (g_regex_2estepThreads_24scalars_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_found_247); r_; });
}
Clo g_regex_2erunFrom_clo = {{0x80000000u, K_CLO, 0}, g_regex_2erunFrom_entry, 6, 0};

V g_regex_2erunFrom(V v_prog_240, V v_fresh_241, V v_s_242, V v_i_243, V v_threads_244, V v_found_245) {
top: ;
  V v_atEnd_246 = heff_bool(heff_intLe_c_lent(heff_strLength_lent(v_s_242, 0), v_i_243, 1));
  V v_c_247;
  if ((heff_dup(v_atEnd_246) == NTAG(TAG_True))) {
    v_c_247 = MK_INT(-1LL);
  } else {
    v_c_247 = heff_runeToInt(heff_strRuneAt_lent(v_s_242, v_i_243, 0));
  }
  V v_j_248;
  if ((heff_dup(v_atEnd_246) == NTAG(TAG_True))) {
    v_j_248 = v_i_243;
  } else {
    v_j_248 = heff_intAdd(heff_dup(v_i_243), heff_strRuneWidth_lent(v_s_242, v_i_243, 2));
  }
  V v_t_249 = heff_arrayReplicate(heff_arrayLength_lent(v_prog_240, 0), NTAG(TAG_False));
  V v_t_2410 = heff_rec_n(2, shape_seen__threads, (V[]){v_t_249, NTAG(TAG_Nil)});
  HeffT2 v_t_2411 = ({ V a_0 = v_prog_240; V a_1 = v_s_242; V a_2 = v_j_248; V a_3 = v_c_247; V a_4 = v_threads_244; V a_5 = heff_rec_n(2, shape_next__found, (V[]){v_t_2410, v_found_245}); HeffT2 r_ = (g_regex_2estepThreads_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_c_247); heff_drop(v_threads_244); r_; });
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    if ((heff_dup(v_atEnd_246) == NTAG(TAG_True))) {
      heff_drop(v_atEnd_246);
      heff_drop(v_j_248);
      heff_drop(v_field_2412);
      return v_field_2413;
    } else {
      heff_drop(v_atEnd_246);
      V v_t_2414 = heff_dup(v_field_2413);
      V v_next_2416;
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        v_next_2416 = (g_regex_2egather(v_prog_240, v_s_242, v_j_248, MK_INT(0LL), heff_dup(v_fresh_241), v_field_2412));
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2414, 0ULL, 1);
        v_next_2416 = v_field_2412;
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      V v_t_2417 = heff_dup(heff_rfield(v_next_2416, 1));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nil: {
        heff_drop_rec(v_next_2416, 2);
        V v_t_2418 = v_field_2413;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          V t_0 = v_prog_240;
          V t_1 = v_fresh_241;
          V t_2 = v_s_242;
          V t_3 = v_j_248;
          V t_4 = NTAG(TAG_Nil);
          V t_5 = NTAG(TAG_Nothing);
          v_prog_240 = t_0;
          v_fresh_241 = t_1;
          v_s_242 = t_2;
          v_i_243 = t_3;
          v_threads_244 = t_4;
          v_found_245 = t_5;
          goto top;
        }
        case TAG_Just: {
          V v_m_2419 = heff_field(v_t_2418, 0);
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 1ULL, 1);
          heff_drop(v_j_248);
          return heff_tag_re_n(v_ru_24t_2418_24Just, TAG_Just, 1, 1ULL, (V[]){v_m_2419});
        }
        default: return heff_nomatch(v_t_2418);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_t_2417, 0ULL, 2);
        V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_next_2416, 1, 2)));
        V t_0 = v_prog_240;
        V t_1 = v_fresh_241;
        V t_2 = v_s_242;
        V t_3 = v_j_248;
        V t_4 = v_t_2422;
        V t_5 = v_field_2413;
        v_prog_240 = t_0;
        v_fresh_241 = t_1;
        v_s_242 = t_2;
        v_i_243 = t_3;
        v_threads_244 = t_4;
        v_found_245 = t_5;
        goto top;
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
  }
}
V g_regex_2erunFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_regex_2erunFrom(a0, a1, a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}