// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CInf 46723
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CType 17595
#define TAG_CVoid 1823
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EDo 15964
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_EquationCovered 28162
#define TAG_ExplicitParam 63083
#define TAG_Fresh 58834
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_IApp 21275
#define TAG_IPrim 59489
#define TAG_ISts 38700
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_JString 41091
#define TAG_Large 60129
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_OutCall 43778
#define TAG_OutOther 27005
#define TAG_OutRecord 63915
#define TAG_OutTag 45229
#define TAG_SetField 47531
#define TAG_Small 51389
#define TAG_StmtExpr 2862
#define TAG_TopL 65516
#define TAG_Unreached 46435
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define TAG_Within 10658
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_errors 652506774
#define LBL_field 298786068
#define LBL_index 301704428
#define LBL_item 9738202
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_level 304224158
#define LBL_libs 9816917
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_owner 307523277
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_prims 308293287
#define LBL_read 9991773
#define LBL_refs 9991943
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_tested 1069972444
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_version 583465758
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_owner__key__name__item__refs[] = {LBL_owner, LBL_key, LBL_name, LBL_item, LBL_refs};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
V g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224(V, V);
V g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224_clo;
V g_heff_2ecompile_2eborrow_2eloopLent(V, V, V, V);
V g_heff_2ecompile_2eborrow_2eloopLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eloopLent_clo;
V g_heff_2ecompile_2eborrow_2eonlyLent(V, V, V);
V g_heff_2ecompile_2eborrow_2eonlyLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eonlyLent_clo;
V g_heff_2ecompile_2eborrow_2ereusesHere(V, V);
V g_heff_2ecompile_2eborrow_2ereusesHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ereusesHere_clo;
V g_heff_2ecompile_2eborrow_2esteps(V, V);
V g_heff_2ecompile_2eborrow_2esteps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2esteps_clo;
V g_heff_2ecompile_2ebounds_2eelemS(V, V);
V g_heff_2ecompile_2ebounds_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ebounds_2eelemS_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemitc_2eargTypeNames(V);
V g_heff_2ecompile_2eemitc_2eargTypeNames_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargTypeNames_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eall_24s525729714x658270192(V);
V g_list_2eall_24s525729714x658270192_entry(V self, V *a);
extern Clo g_list_2eall_24s525729714x658270192_clo;
V g_list_2eany_24s1419619328x1805745269(V);
V g_list_2eany_24s1419619328x1805745269_entry(V self, V *a);
extern Clo g_list_2eany_24s1419619328x1805745269_clo;
V g_list_2eany_24s1630057461x1822494873(V);
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a);
extern Clo g_list_2eany_24s1630057461x1822494873_clo;
V g_list_2eany_24s2074406606x298866118(V);
V g_list_2eany_24s2074406606x298866118_entry(V self, V *a);
extern Clo g_list_2eany_24s2074406606x298866118_clo;
V g_list_2eany_24s767011289x1972536129(V);
V g_list_2eany_24s767011289x1972536129_entry(V self, V *a);
extern Clo g_list_2eany_24s767011289x1972536129_clo;
V g_list_2eascending_24s1053575971x1138989897(V, V, V);
V g_list_2eascending_24s1053575971x1138989897_entry(V self, V *a);
extern Clo g_list_2eascending_24s1053575971x1138989897_clo;
V g_list_2eascending_24s946492440x1788863194(V, V, V);
V g_list_2eascending_24s946492440x1788863194_entry(V self, V *a);
extern Clo g_list_2eascending_24s946492440x1788863194_clo;
V g_list_2ecollapse_24s880359666x1597741115(V, V);
V g_list_2ecollapse_24s880359666x1597741115_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s880359666x1597741115_clo;
V g_list_2edescending_24s1432586697x321478004(V, V, V);
V g_list_2edescending_24s1432586697x321478004_entry(V self, V *a);
extern Clo g_list_2edescending_24s1432586697x321478004_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s2106830784x1074299306_24cpr(V, V);
HeffT2 g_list_2efind_24s845102114x2128838930_24cpr(V, V);
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24f2082849937x387822498(V, V, V, V);
V g_list_2efoldl_24f2082849937x387822498_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2082849937x387822498_clo;
V g_list_2efoldl_24f2092936166x2062766724(V, V, V);
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2092936166x2062766724_clo;
V g_list_2efoldl_24f380832527x418567417(V, V, V);
V g_list_2efoldl_24f380832527x418567417_entry(V self, V *a);
extern Clo g_list_2efoldl_24f380832527x418567417_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1246062630x1975509602(V, V);
V g_list_2efoldl_24s1246062630x1975509602_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1246062630x1975509602_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1522661722x1369236455(V, V);
V g_list_2efoldl_24s1522661722x1369236455_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1522661722x1369236455_clo;
V g_list_2efoldl_24s1568221543x2050375626(V, V);
V g_list_2efoldl_24s1568221543x2050375626_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1568221543x2050375626_clo;
V g_list_2efoldl_24s1608132097x1207501887(V, V);
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1608132097x1207501887_clo;
V g_list_2efoldl_24s1673889684x228869038(V, V);
V g_list_2efoldl_24s1673889684x228869038_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1673889684x228869038_clo;
V g_list_2efoldl_24s193704652x357697644(V, V);
V g_list_2efoldl_24s193704652x357697644_entry(V self, V *a);
extern Clo g_list_2efoldl_24s193704652x357697644_clo;
V g_list_2efoldl_24s25420611x1990549631(V, V);
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s25420611x1990549631_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2efoldl_24s524770901x1440232311(V, V);
V g_list_2efoldl_24s524770901x1440232311_entry(V self, V *a);
extern Clo g_list_2efoldl_24s524770901x1440232311_clo;
V g_list_2efoldl_24s537755658x300885499(V, V);
V g_list_2efoldl_24s537755658x300885499_entry(V self, V *a);
extern Clo g_list_2efoldl_24s537755658x300885499_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
HeffT5 g_list_2efoldl_24s571074576x1179600767_24cpr(V, V);
V g_list_2efoldl_24s871632021x1241775640(V, V, V, V);
V g_list_2efoldl_24s871632021x1241775640_entry(V self, V *a);
extern Clo g_list_2efoldl_24s871632021x1241775640_clo;
V g_list_2ekeepIf_24s1181715076x1618420649_24dps(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s1181715076x1618420649_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1181715076x1618420649_24dps_clo;
V g_list_2ekeepIf_24s1266148589x1647110933_24dps(V, V);
V g_list_2ekeepIf_24s1266148589x1647110933_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_24dps_clo;
V g_list_2ekeepIf_24s1366776885x1474218589_24dps(V, V, V);
V g_list_2ekeepIf_24s1366776885x1474218589_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1366776885x1474218589_24dps_clo;
V g_list_2ekeepIf_24s25507577x707942422_24dps(V, V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_24dps_clo;
V g_list_2ekeepIf_24s458067099x815639923(V);
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_clo;
V g_list_2ekeepIf_24s458067099x815639923_24dps(V, V);
V g_list_2ekeepIf_24s458067099x815639923_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s458067099x815639923_24dps_clo;
V g_list_2ekeepIf_24s478006518x1380334353(V);
V g_list_2ekeepIf_24s478006518x1380334353_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_clo;
V g_list_2ekeepIf_24s478006518x1380334353_24dps(V, V);
V g_list_2ekeepIf_24s478006518x1380334353_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_24dps_clo;
V g_list_2ekeepIf_24s498754754x815116558_24dps(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s498754754x815116558_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s498754754x815116558_24dps_clo;
V g_list_2emap_24f2124896334x71745266_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_24dps_clo;
V g_list_2emap_24f230958709x841260712_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f230958709x841260712_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f230958709x841260712_24dps_clo;
V g_list_2emap_24f869471183x993026796(V, V, V);
V g_list_2emap_24f869471183x993026796_entry(V self, V *a);
extern Clo g_list_2emap_24f869471183x993026796_clo;
V g_list_2emap_24s1036840854x702708481(V, V);
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_clo;
V g_list_2emap_24s1036840854x702708481_24dps(V, V, V);
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_24dps_clo;
V g_list_2emap_24s1099021180x1702355548_24dps(V, V, V);
V g_list_2emap_24s1099021180x1702355548_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_24dps_clo;
V g_list_2emap_24s1112048172x371485672_24dps(V, V);
V g_list_2emap_24s1112048172x371485672_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_24dps_clo;
V g_list_2emap_24s1325317589x1506218481_24dps(V, V, V, V);
V g_list_2emap_24s1325317589x1506218481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_24dps_clo;
V g_list_2emap_24s1397747289x2145601499_24dps(V, V);
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1397747289x2145601499_24dps_clo;
V g_list_2emap_24s1409451498x400757684(V);
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_clo;
V g_list_2emap_24s1409451498x400757684_24dps(V, V);
V g_list_2emap_24s1409451498x400757684_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_24dps_clo;
V g_list_2emap_24s1462590149x1582455373_24dps(V, V);
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1462590149x1582455373_24dps_clo;
V g_list_2emap_24s1524528409x1420927362_24dps(V, V);
V g_list_2emap_24s1524528409x1420927362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1524528409x1420927362_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s158244903x55062455_24dps(V, V);
V g_list_2emap_24s158244903x55062455_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_24dps_clo;
V g_list_2emap_24s1690674600x556093466_24dps(V, V);
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1690674600x556093466_24dps_clo;
V g_list_2emap_24s2067043448x720245267_24dps(V, V);
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_24dps_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s2073083146x1445066245_24dps(V, V);
V g_list_2emap_24s2073083146x1445066245_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_24dps_clo;
V g_list_2emap_24s2098521682x1221164629(V);
V g_list_2emap_24s2098521682x1221164629_entry(V self, V *a);
extern Clo g_list_2emap_24s2098521682x1221164629_clo;
V g_list_2emap_24s2098521682x1221164629_24dps(V, V);
V g_list_2emap_24s2098521682x1221164629_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2098521682x1221164629_24dps_clo;
V g_list_2emap_24s228910449x1110031924_24dps(V, V, V);
V g_list_2emap_24s228910449x1110031924_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s23414532x1067218554_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s23414532x1067218554_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s23414532x1067218554_24dps_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_list_2emap_24s258116700x992061112_24dps(V, V, V);
V g_list_2emap_24s258116700x992061112_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_24dps_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24s357242026x384251201_24dps(V, V);
V g_list_2emap_24s357242026x384251201_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_24dps_clo;
V g_list_2emap_24s473401207x1960255357(V);
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_clo;
V g_list_2emap_24s473401207x1960255357_24dps(V, V);
V g_list_2emap_24s473401207x1960255357_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_24dps_clo;
V g_list_2emap_24s509077117x607152875_24dps(V, V);
V g_list_2emap_24s509077117x607152875_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s509077117x607152875_24dps_clo;
V g_list_2emap_24s509077117x607152875_24tok1(V, V);
V g_list_2emap_24s509077117x607152875_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s509077117x607152875_24tok1_clo;
V g_list_2emap_24s588468714x1874323009(V);
V g_list_2emap_24s588468714x1874323009_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_clo;
V g_list_2emap_24s588468714x1874323009_24dps(V, V);
V g_list_2emap_24s588468714x1874323009_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588468714x1874323009_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s723912745x1713553694(V);
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_clo;
V g_list_2emap_24s723912745x1713553694_24dps(V, V);
V g_list_2emap_24s723912745x1713553694_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_24dps_clo;
V g_list_2emap_24s831190316x576961335_24dps(V, V);
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_24dps_clo;
V g_list_2emap_24s88069640x1067514236(V);
V g_list_2emap_24s88069640x1067514236_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_clo;
V g_list_2emap_24s88069640x1067514236_24dps(V, V);
V g_list_2emap_24s88069640x1067514236_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s88069640x1067514236_24dps_clo;
V g_list_2emap_24s89148281x951607804_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_24dps_clo;
V g_list_2emergeRuns_24s2052062657x972894659(V, V);
V g_list_2emergeRuns_24s2052062657x972894659_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s2052062657x972894659_clo;
V g_list_2epushRun_24s495990157x1087861527(V, V, V);
V g_list_2epushRun_24s495990157x1087861527_entry(V self, V *a);
extern Clo g_list_2epushRun_24s495990157x1087861527_clo;
V g_list_2ezipWith_24s2130584539x811126895(V, V, V);
V g_list_2ezipWith_24s2130584539x811126895_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2130584539x811126895_clo;
V g_list_2ezipWith_24s2130584539x811126895_24dps(V, V, V, V);
V g_list_2ezipWith_24s2130584539x811126895_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s2130584539x811126895_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_list_2efoldl_24s524770901x1440232311_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s524770901x1440232311_entry, 2, 0};

V g_list_2efoldl_24s524770901x1440232311(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_z_240; V r_ = (g_heff_2ecompile_2eir_2ewaysOnto(a_0, a_1)); heff_drop(v_t_247); heff_drop(v_z_240); r_; });
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s524770901x1440232311_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s524770901x1440232311(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s525729714x658270192_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s525729714x658270192_entry, 1, 0};

V g_list_2eall_24s525729714x658270192(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_r1_243 = heff_field(v_x_241, 0);
      V v_r2_244 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_r1_243)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_lo_245 = heff_field(v_r1_243, 0);
        switch (heff_tag_of(v_r2_244)) {
        case TAG_Nothing: {
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_hi_246 = heff_field(v_r2_244, 0);
          if ((heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_lo_245, 1) && heff_intLe_c_lent(v_hi_246, MK_INT(4611686018427387903LL), 2))) {
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          } else {
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_r2_244);
        }
      }
      default: return heff_nomatch(v_r1_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s525729714x658270192_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s525729714x658270192(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s258116700x992061112_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s258116700x992061112_entry, 2, 0};

V g_list_2emap_24s258116700x992061112(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), heff_hole()});
    V v_u_245 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_244; V r_ = (g_list_2emap_24s258116700x992061112_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s258116700x992061112_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s258116700x992061112(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1409451498x400757684_str0, 0, "");
Clo g_list_2emap_24s1409451498x400757684_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1409451498x400757684_entry, 1, 0};

V g_list_2emap_24s1409451498x400757684(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_dup(heff_rfield(v_x_241, 2)), heff_dup(heff_rfield(v_x_241, 3)), heff_tag_n(TAG_Just, 1, (V[]){v_x_241}), ((V)&g_list_2emap_24s1409451498x400757684_str0), MK_INT(0LL), MK_INT(0LL)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1409451498x400757684_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1409451498x400757684(a[0]);
}
Clo g_list_2eany_24s2074406606x298866118_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2074406606x298866118_entry, 1, 0};

V g_list_2eany_24s2074406606x298866118(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2418;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 1ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkAlt: {
        V v_b_247 = heff_field(v_x21_244, 1);
        heff_take_n(v_x21_244, 2ULL, 2);
        V v_t_2417;
        switch (heff_tag_of(v_b_247)) {
        case TAG_At: {
          V v_e1_248 = heff_dup(heff_field(v_b_247, 0));
          switch (heff_tag_of(v_e1_248)) {
          case TAG_EDo: {
            V v_ss_2410 = heff_field(v_e1_248, 0);
            heff_take_n(v_e1_248, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_cell(v_ru_24x2_243_24At, 2);
            switch (heff_tag_of(v_b_247)) {
            case TAG_At: {
              heff_take_n(v_b_247, 0ULL, 2);
              v_t_2417 = v_ss_2410;
              break;
            }
            default: heff_nomatch(v_b_247);
            }
            break;
          }
          default: {
            heff_drop(v_e1_248);
            V v_t_2415;
            switch (heff_tag_of(v_b_247)) {
            case TAG_At: {
              V v_s_2414 = heff_dup(heff_field(v_b_247, 1));
              v_t_2415 = v_s_2414;
              break;
            }
            default: heff_nomatch(v_b_247);
            }
            V v_t_2416 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_b_247}), v_t_2415});
            v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_b_247);
        }
        v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_list_2eany_24s767011289x1972536129(a_0)); heff_drop(v_t_2417); r_; });
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_xs_242);
      heff_drop(v_t_2418);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2418);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2074406606x298866118_entry(V self, V *a) {
  (void)self;
  return g_list_2eany_24s2074406606x298866118(a[0]);
}
Clo g_list_2emap_24s1036840854x702708481_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1036840854x702708481_entry, 2, 0};

V g_list_2emap_24s1036840854x702708481(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2423;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_sp_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_MkEquation: {
        V v_f_248 = heff_field(v_x21_246, 0);
        V v_fsp_249 = heff_field(v_x21_246, 1);
        V v_ps_2410 = heff_field(v_x21_246, 2);
        V v_rhs_2411 = heff_field(v_x21_246, 3);
        V v_ru_24x21_246_24MkEquation = heff_take_reuse_n(v_x21_246, 15ULL, 4);
        V v_x1_2412 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_rhs_2411}));
        V v_t_2422;
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_IsInferable: {
          V v_i_2413 = heff_field(v_x1_2412, 0);
          V v_ru_24x1_2412_24IsInferable = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
          V v_t_2416;
          switch (heff_tag_of(v_i_2413)) {
          case TAG_At: {
            V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
            v_t_2416 = v_s_2415;
            break;
          }
          default: heff_nomatch(v_i_2413);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2412_24IsInferable, TAG_CInf, 1, (V[]){v_i_2413}), v_t_2416});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2417 = heff_field(v_x1_2412, 0);
          heff_take_n(v_x1_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_245_24At, 2);
          v_t_2422 = v_c_2417;
          break;
        }
        case TAG_IsType: {
          V v_t_2418 = heff_field(v_x1_2412, 0);
          V v_ru_24x1_2412_24IsType = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
          V v_t_2421;
          switch (heff_tag_of(v_t_2418)) {
          case TAG_At: {
            V v_s_2420 = heff_dup(heff_field(v_t_2418, 1));
            v_t_2421 = v_s_2420;
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
          v_t_2422 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2412_24IsType, TAG_CType, 1, (V[]){v_t_2418}), v_t_2421});
          break;
        }
        default: heff_nomatch(v_x1_2412);
        }
        v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_246_24MkEquation, TAG_MkEquation, 4, 7ULL, (V[]){v_f_248, v_fsp_249, v_ps_2410, v_t_2422}), v_sp_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_2424; V r_ = (g_list_2emap_24s1036840854x702708481_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_2425);
    return v_cell_2424;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1036840854x702708481_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1036840854x702708481(a[0], a[1]);
}
Clo g_list_2emap_24s158244903x55062455_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s158244903x55062455_entry, 1, 0};

V g_list_2emap_24s158244903x55062455(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24x_241_24At, v_a_244, v_a_243));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s158244903x55062455_24dps(v_xs_242, v_cell_246));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s158244903x55062455_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s158244903x55062455(a[0]);
}
Clo g_list_2emap_24s1112048172x371485672_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1112048172x371485672_24dps_entry, 2, 0};

V g_list_2emap_24s1112048172x371485672_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2444 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2443, heff_hole()});
    V v_u_2445 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2444);
    V t_0 = v_xs_243;
    V t_1 = v_u_2445;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1112048172x371485672_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1112048172x371485672_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s473401207x1960255357_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s473401207x1960255357_entry, 1, 0};

V g_list_2emap_24s473401207x1960255357(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2espec_2ecallsNothing(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s473401207x1960255357_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s473401207x1960255357_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s473401207x1960255357(a[0]);
}
Clo g_list_2emap_24s2067043448x720245267_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2067043448x720245267_24dps_entry, 2, 0};

V g_list_2emap_24s2067043448x720245267_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2epushable(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2067043448x720245267_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s2067043448x720245267_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1104809983x118204267_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1104809983x118204267_entry, 2, 0};

V g_list_2efoldl_24s1104809983x118204267(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_a_246}), v_z_240});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1104809983x118204267(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s498754754x815116558_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s498754754x815116558_24dps_entry, 7, 0};

V g_list_2ekeepIf_24s498754754x815116558_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_246), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_bor_249 = heff_dup(v_lit_240);
    V v_key_2410 = heff_dup(v_lit_241);
    V v_xs_2411 = heff_dup(v_lit_242);
    V v_b_2412 = heff_dup(v_lit_243);
    V v_ds_2413 = heff_dup(v_lit_244);
    V v_i_2414 = heff_dup(v_x_247);
    HeffT3 v_t_2415 = ({ V a_0 = heff_dup(v_i_2414); V a_1 = v_xs_2411; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_xs_2411); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      V v_field_2418 = v_t_2415.f[2];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      V v_t_2429;
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_p_2419 = v_field_2417;
        V v_x_2420 = v_field_2418;
        heff_drop(v_x_2420);
        V v_t_2421 = ({ V a_0 = v_bor_249; V a_1 = v_p_2419; V a_2 = v_b_2412; V r_ = heff_tr(g_heff_2ecompile_2eborrow_2eonlyLent(a_0, a_1, a_2)); heff_drop(v_bor_249); r_; });
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          V v_t_2422 = (g_heff_2ecompile_2eborrow_2ereusesHere(v_p_2419, v_b_2412));
          if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
            heff_drop(v_key_2410);
            heff_drop(v_b_2412);
            heff_drop(v_ds_2413);
            heff_drop(v_i_2414);
            heff_drop(v_p_2419);
            heff_drop(v_t_2422);
            v_t_2429 = NTAG(TAG_False);
          } else {
            heff_drop(v_t_2422);
            V v_t_2423 = (g_heff_2ecompile_2eir_2epartsOnto(heff_dup(v_b_2412), NTAG(TAG_Nil)));
            V v_x1_2424 = ({ V a_0 = v_p_2419; V a_1 = v_t_2423; V r_ = (g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224(a_0, a_1)); heff_drop(v_p_2419); r_; });
            if (!(heff_dup(v_x1_2424) == NTAG(TAG_True))) {
              heff_drop(v_x1_2424);
              v_t_2429 = ({ V a_0 = v_key_2410; V a_1 = v_i_2414; V a_2 = v_ds_2413; V a_3 = v_b_2412; V r_ = (g_heff_2ecompile_2eborrow_2eloopLent(a_0, a_1, a_2, a_3)); heff_drop(v_key_2410); heff_drop(v_i_2414); heff_drop(v_ds_2413); heff_drop(v_b_2412); r_; });
            } else {
              heff_drop(v_key_2410);
              heff_drop(v_b_2412);
              heff_drop(v_ds_2413);
              heff_drop(v_i_2414);
              heff_drop(v_x1_2424);
              v_t_2429 = NTAG(TAG_False);
            }
          }
        } else {
          heff_drop(v_t_2421);
          V v_t_2425 = (g_heff_2ecompile_2eborrow_2esteps(v_key_2410, v_b_2412));
          if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
            heff_drop(v_t_2425);
            V v_t_2426 = (g_heff_2ecompile_2eborrow_2ereusesHere(v_p_2419, v_b_2412));
            if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
              heff_drop(v_key_2410);
              heff_drop(v_b_2412);
              heff_drop(v_ds_2413);
              heff_drop(v_i_2414);
              heff_drop(v_p_2419);
              heff_drop(v_t_2426);
              v_t_2429 = NTAG(TAG_False);
            } else {
              heff_drop(v_t_2426);
              V v_t_2427 = (g_heff_2ecompile_2eir_2epartsOnto(heff_dup(v_b_2412), NTAG(TAG_Nil)));
              V v_x1_2428 = ({ V a_0 = v_p_2419; V a_1 = v_t_2427; V r_ = (g_heff_2ecompile_2eborrow_2eanyW_24s805886511x1067941224(a_0, a_1)); heff_drop(v_p_2419); r_; });
              if (!(heff_dup(v_x1_2428) == NTAG(TAG_True))) {
                heff_drop(v_x1_2428);
                v_t_2429 = ({ V a_0 = v_key_2410; V a_1 = v_i_2414; V a_2 = v_ds_2413; V a_3 = v_b_2412; V r_ = (g_heff_2ecompile_2eborrow_2eloopLent(a_0, a_1, a_2, a_3)); heff_drop(v_key_2410); heff_drop(v_i_2414); heff_drop(v_ds_2413); heff_drop(v_b_2412); r_; });
              } else {
                heff_drop(v_key_2410);
                heff_drop(v_b_2412);
                heff_drop(v_ds_2413);
                heff_drop(v_i_2414);
                heff_drop(v_x1_2428);
                v_t_2429 = NTAG(TAG_False);
              }
            }
          } else {
            heff_drop(v_key_2410);
            heff_drop(v_b_2412);
            heff_drop(v_ds_2413);
            heff_drop(v_i_2414);
            heff_drop(v_p_2419);
            heff_drop(v_t_2425);
            v_t_2429 = NTAG(TAG_False);
          }
        }
      } else {
        heff_drop(v_bor_249);
        heff_drop(v_key_2410);
        heff_drop(v_b_2412);
        heff_drop(v_ds_2413);
        heff_drop(v_i_2414);
        heff_drop(v_field_2417);
        heff_drop(v_field_2418);
        v_t_2429 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
        heff_drop(v_t_2429);
        V v_cell_2430 = heff_tag_re_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_247, heff_hole()});
        V v_u_2431 = heff_setFieldPeek(v_d_246, MK_INT(1LL), v_cell_2430);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_u_2431;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      } else {
        heff_drop(v_x_247);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        heff_drop(v_t_2429);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_d_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2ekeepIf_24s498754754x815116558_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V r = g_list_2ekeepIf_24s498754754x815116558_24dps(a0, a1, a2, a3, a4, a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a6); return r;
}
Clo g_list_2emap_24s88069640x1067514236_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s88069640x1067514236_entry, 1, 0};

V g_list_2emap_24s88069640x1067514236(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      v_t_248 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_t_248, 1);
      heff_take_n(v_t_248, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_2411}), heff_hole()});
    V v_u_2413 = (g_list_2emap_24s88069640x1067514236_24dps(v_xs_242, v_cell_2412));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s88069640x1067514236_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s88069640x1067514236(a[0]);
}
Clo g_list_2efoldl_24s193704652x357697644_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s193704652x357697644_entry, 2, 0};

V g_list_2efoldl_24s193704652x357697644(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_list_2efoldl_24s490001784x345683100(v_z_240, v_t_2412));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s193704652x357697644_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s193704652x357697644(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1366776885x1474218589_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1366776885x1474218589_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1366776885x1474218589_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1366776885x1474218589_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2ekeepIf_24s1366776885x1474218589_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2eany_24s1630057461x1822494873_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1630057461x1822494873_entry, 1, 0};

V g_list_2eany_24s1630057461x1822494873(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_OutTag: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutRecord: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutCall: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_OutOther: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1630057461x1822494873_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1630057461x1822494873(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_24dps_str0, 1, "\"");
HEFF_LIT(g_list_2emap_24s1397747289x2145601499_24dps_str1, 1, "\"");
Clo g_list_2emap_24s1397747289x2145601499_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1397747289x2145601499_24dps_entry, 2, 0};

V g_list_2emap_24s1397747289x2145601499_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_x_242); r_; });
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1397747289x2145601499_24dps_str0), v_t_244), ((V)&g_list_2emap_24s1397747289x2145601499_24dps_str1));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
    V t_0 = v_xs_243;
    V t_1 = v_u_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1397747289x2145601499_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1397747289x2145601499_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1690674600x556093466_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1690674600x556093466_24dps_entry, 2, 0};

V g_list_2emap_24s1690674600x556093466_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_t_2412}), heff_hole()});
    V v_u_2414 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2413);
    V t_0 = v_xs_243;
    V t_1 = v_u_2414;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1690674600x556093466_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1690674600x556093466_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1524528409x1420927362_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1524528409x1420927362_24dps_entry, 2, 0};

V g_list_2emap_24s1524528409x1420927362_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24Given = heff_take_reuse_n(v_x_242, 1ULL, 1);
      V v_t_245 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_244));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24Given, TAG_Given, 1, (V[]){v_t_245});
      break;
    }
    case TAG_GivenU: {
      V v_a_246 = heff_field(v_x_242, 0);
      V v_a_247 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24GivenU = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_247));
      v_t_2413 = heff_tag_re_n(v_ru_24x_242_24GivenU, TAG_GivenU, 2, 1ULL, (V[]){v_a_246, v_t_248});
      break;
    }
    case TAG_LentVar: {
      v_t_2413 = v_x_242;
      break;
    }
    case TAG_LentValue: {
      V v_a_2411 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24LentValue = heff_take_reuse_n(v_x_242, 1ULL, 1);
      V v_t_2412 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_a_2411));
      v_t_2413 = heff_tag_at_n(v_ru_24x_242_24LentValue, TAG_LentValue, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2414);
    V t_0 = v_xs_243;
    V t_1 = v_u_2415;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1524528409x1420927362_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1524528409x1420927362_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s89148281x951607804_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s89148281x951607804_24dps_entry, 8, 0};

V g_list_2emap_24s89148281x951607804_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_247), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_lit_240; V a_2 = heff_dup(v_lit_241); V a_3 = heff_strFind_lent(v_lit_242, v_x_248, v_lit_243, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_248); r_; });
    V v_a_2411 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2410));
    V v_t_2414;
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nil: {
      v_t_2414 = heff_dup(v_lit_244);
      break;
    }
    case TAG_Cons: {
      V v_a_2412 = heff_field(v_a_2411, 0);
      V v_a_2413 = heff_field(v_a_2411, 1);
      heff_take_n(v_a_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = v_lit_245; V a_1 = v_a_2412; V a_2 = v_a_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2413); r_; });
      break;
    }
    default: heff_nomatch(v_a_2411);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2415);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_u_2416;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s89148281x951607804_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a7 = a[7]; V r = g_list_2emap_24s89148281x951607804_24dps(a0, a1, a2, a3, a4, a5, a[6], a7); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24s1522661722x1369236455_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1522661722x1369236455_entry, 2, 0};

V g_list_2efoldl_24s1522661722x1369236455(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_refs_245 = heff_dup(heff_rfield(v_x_242, 4));
    V v_t_246 = ({ V a_0 = v_z_240; V a_1 = v_key_244; V a_2 = v_refs_245; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_key_244); heff_drop(v_refs_245); r_; });
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1522661722x1369236455_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1522661722x1369236455(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s357242026x384251201_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s357242026x384251201_entry, 1, 0};

V g_list_2emap_24s357242026x384251201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s357242026x384251201_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s357242026x384251201_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s357242026x384251201(a[0]);
}
Clo g_list_2emap_24s1325317589x1506218481_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1325317589x1506218481_24dps_entry, 4, 0};

V g_list_2emap_24s1325317589x1506218481_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_x_244), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_247);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_u_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1325317589x1506218481_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2emap_24s1325317589x1506218481_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2ezipWith_24s2130584539x811126895_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s2130584539x811126895_entry, 3, 0};

V g_list_2ezipWith_24s2130584539x811126895(V v_lit_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_t_247 = heff_strAppend(heff_strAppend(v_x_243, heff_dup(v_lit_240)), v_y_245);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = ({ V a_0 = v_lit_240; V a_1 = v_xs_244; V a_2 = v_ys_246; V a_3 = v_cell_248; V r_ = (g_list_2ezipWith_24s2130584539x811126895_24dps(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); r_; });
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s2130584539x811126895_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s2130584539x811126895(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s25420611x1990549631_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s25420611x1990549631_entry, 2, 0};

V g_list_2efoldl_24s25420611x1990549631(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_prelude_2e_2b_2b(heff_get_n(v_t_246, 4, 5), v_z_240));
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s25420611x1990549631_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s25420611x1990549631(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1568221543x2050375626_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1568221543x2050375626_entry, 2, 0};

V g_list_2efoldl_24s1568221543x2050375626(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2eargTypeNames(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1568221543x2050375626_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1568221543x2050375626(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1419619328x1805745269_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1419619328x1805745269_entry, 1, 0};

V g_list_2eany_24s1419619328x1805745269(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_CInteger: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CDouble: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CBool: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CString: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CText: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_COwnedString: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CBytes: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_COwnedBytes: {
      return NTAG(TAG_True);
    }
    case TAG_CPointer: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_CVoid: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1419619328x1805745269_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1419619328x1805745269(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_str0, 2, "__");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_str1, 2, "__");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_str2, 4, "LBL_");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_str3, 0, "");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_str4, 2, ", ");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_str5, 22, "static uint32_t shape_");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_str6, 6, "[] = {");
HEFF_LIT(g_list_2emap_24s2073083146x1445066245_str7, 2, "};");
Clo g_list_2emap_24s2073083146x1445066245_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2073083146x1445066245_entry, 1, 0};

V g_list_2emap_24s2073083146x1445066245(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = v_x_241;
    V v_t_244 = (g_prelude_2esplit_2esplitFrom_240(v_name_243, ((V)&g_list_2emap_24s2073083146x1445066245_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_list_2emap_24s2073083146x1445066245_str1), v_name_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_x2_245 = (g_list_2emap_24f869471183x993026796(((V)&g_list_2emap_24s2073083146x1445066245_str2), MK_INT(0LL), v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_list_2emap_24s2073083146x1445066245_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_list_2emap_24s2073083146x1445066245_str4); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2073083146x1445066245_str5), v_name_243), ((V)&g_list_2emap_24s2073083146x1445066245_str6));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, v_t_248), ((V)&g_list_2emap_24s2073083146x1445066245_str7));
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s2073083146x1445066245_24dps(v_xs_242, v_cell_2411));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2073083146x1445066245(a[0]);
}
Clo g_list_2ekeepIf_24s478006518x1380334353_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s478006518x1380334353_entry, 1, 0};

V g_list_2ekeepIf_24s478006518x1380334353(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = ({ V a_0 = v_x_241; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if (!(heff_dup(v_a_243) == NTAG(TAG_True))) {
      heff_drop(v_a_243);
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s478006518x1380334353_24dps(v_xs_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s478006518x1380334353_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s478006518x1380334353(a[0]);
}
Clo g_list_2efoldl_24s1246062630x1975509602_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1246062630x1975509602_entry, 2, 0};

V g_list_2efoldl_24s1246062630x1975509602(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s537755658x300885499(v_z_240, heff_rfield(v_x_242, 3)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1246062630x1975509602_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1246062630x1975509602(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s871632021x1241775640_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s871632021x1241775640_entry, 4, 0};

V g_list_2efoldl_24s871632021x1241775640(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){heff_dup(v_lit_240)}), heff_dup(v_lit_241)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_z_242}), heff_dup(v_lit_241)});
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_x_244}), heff_dup(v_lit_241)});
    V v_t_249 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_lit_241)})});
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_lit_241)});
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s871632021x1241775640_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2efoldl_24s871632021x1241775640(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s2098521682x1221164629_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2098521682x1221164629_entry, 1, 0};

V g_list_2emap_24s2098521682x1221164629(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EquationCovered, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s2098521682x1221164629_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2098521682x1221164629_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2098521682x1221164629(a[0]);
}
Clo g_list_2efoldl_24s1608132097x1207501887_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1608132097x1207501887_entry, 2, 0};

V g_list_2efoldl_24s1608132097x1207501887(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 3));
    V v_t_245;
    switch (heff_tag_of(v_z_240)) {
    case TAG_Small: {
      v_t_245 = v_a_244;
      break;
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_a_244;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_244)) {
      case TAG_Small: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_Large: {
        v_t_245 = v_z_240;
        break;
      }
      case TAG_TopL: {
        v_t_245 = v_a_244;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1608132097x1207501887(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str0, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str1, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str2, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str3, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str4, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str5, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str6, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str7, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str8, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str9, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str10, 0, "");
HEFF_LIT(g_list_2emap_24s588468714x1874323009_str11, 0, "");
Clo g_list_2emap_24s588468714x1874323009_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588468714x1874323009_entry, 1, 0};

V g_list_2emap_24s588468714x1874323009(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_v_243 = v_x_241;
    V v_t_2417;
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_247 = heff_dup(heff_field(v_v_243, 1));
      v_t_2417 = v_vs_247;
      break;
    }
    case TAG_VInt: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_243);
    }
    HeffT3 v_t_2418 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2417; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    {
      V v_field_2420 = v_t_2418.f[1];
      V v_field_2421 = v_t_2418.f[2];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      V v_t_2437;
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_x_2422 = v_field_2420;
        V v_x12_2423 = v_field_2421;
        heff_drop(v_x12_2423);
        switch (heff_tag_of(v_x_2422)) {
        case TAG_VFun: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str0);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str1);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2422, 0ULL, 2);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str2);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str3);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str4);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str5);
          break;
        }
        case TAG_VStr: {
          V v_s_2431 = heff_field(v_x_2422, 0);
          heff_take_n(v_x_2422, 1ULL, 1);
          v_t_2437 = v_s_2431;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str6);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str7);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2422, 0ULL, 1);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str8);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2422, 0ULL, 2);
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str9);
          break;
        }
        case TAG_VErased: {
          v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str10);
          break;
        }
        default: heff_nomatch(v_x_2422);
        }
      } else {
        heff_drop(v_field_2420);
        heff_drop(v_field_2421);
        v_t_2437 = ((V)&g_list_2emap_24s588468714x1874323009_str11);
      }
      V v_t_2451;
      switch (heff_tag_of(v_v_243)) {
      case TAG_VFun: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2441 = heff_field(v_v_243, 1);
        heff_take_n(v_v_243, 2ULL, 2);
        v_t_2451 = v_vs_2441;
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take_na(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        heff_take_n(v_v_243, 0ULL, 2);
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2451 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      HeffT3 v_t_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2451; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2451); r_; });
      {
        V v_field_2454 = v_t_2452.f[1];
        V v_field_2455 = v_t_2452.f[2];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        V v_t_2471;
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          V v_x_2456 = v_field_2454;
          V v_x12_2457 = v_field_2455;
          heff_drop(v_x12_2457);
          switch (heff_tag_of(v_x_2456)) {
          case TAG_VFun: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VTag: {
            heff_take_n(v_x_2456, 0ULL, 2);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VInt: {
            V v_i_2462 = heff_field(v_x_2456, 0);
            heff_take_n(v_x_2456, 1ULL, 1);
            v_t_2471 = v_i_2462;
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VStr: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_2456, 0ULL, 1);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_2456, 0ULL, 2);
            v_t_2471 = MK_INT(0LL);
            break;
          }
          case TAG_VErased: {
            v_t_2471 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_x_2456);
          }
        } else {
          heff_drop(v_field_2454);
          heff_drop(v_field_2455);
          v_t_2471 = MK_INT(0LL);
        }
        V v_cell_2472 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_t_2471}), heff_hole()});
        V v_u_2473 = (g_list_2emap_24s588468714x1874323009_24dps(v_xs_242, v_cell_2472));
        heff_drop(v_u_2473);
        return v_cell_2472;
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s588468714x1874323009_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588468714x1874323009(a[0]);
}
Clo g_list_2ekeepIf_24s25507577x707942422_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s25507577x707942422_24dps_entry, 4, 0};

V g_list_2ekeepIf_24s25507577x707942422_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240)) && heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241)))) {
      V v_cell_246 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_u_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s25507577x707942422_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2ekeepIf_24s25507577x707942422_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2emap_24s1462590149x1582455373_24dps_str0, 3, ".hf");
Clo g_list_2emap_24s1462590149x1582455373_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1462590149x1582455373_24dps_entry, 2, 0};

V g_list_2emap_24s1462590149x1582455373_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_x_242, 0)) - ((int64_t)3ULL));
    V v_t_245 = heff_strSlice_lent(v_x_242, heff_box_word(v_t_244), heff_strLength_lent(v_x_242, 0), 6);
    V v_t_247;
    if (heff_strEq_c(v_t_245, ((V)&g_list_2emap_24s1462590149x1582455373_24dps_str0))) {
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_x_242, 0)) - ((int64_t)3ULL));
      v_t_247 = heff_strSlice(v_x_242, MK_INT(0LL), heff_box_word(v_t_246));
    } else {
      v_t_247 = v_x_242;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1462590149x1582455373_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1462590149x1582455373_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1266148589x1647110933_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1266148589x1647110933_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1266148589x1647110933_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (!(heff_dup(heff_rfield(v_x_242, 2)) == NTAG(TAG_True))) {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
      V t_0 = v_xs_243;
      V t_1 = v_u_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1266148589x1647110933_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ekeepIf_24s1266148589x1647110933_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eascending_24s1053575971x1138989897_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s1053575971x1138989897_entry, 3, 0};

V g_list_2eascending_24s1053575971x1138989897(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 2);
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x4_242, 0);
    V v_ys_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_intLe_c(heff_get_n(v_x_240, 0, 2), heff_dup(heff_rfield(v_y_244, 0)))) {
      V t_0 = heff_dup(v_y_244);
      V t_1 = heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_244, v_acc_241});
      V t_2 = v_ys_245;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    } else {
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_244, v_ys_245})});
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2eascending_24s1053575971x1138989897_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending_24s1053575971x1138989897(a[0], a[1], a[2]);
}

HeffT2 g_list_2efind_24s845102114x2128838930_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    if ((heff_intLe_c_lent(v_start_245, v_lit_240, 0) && heff_intLe_c_lent(v_lit_240, v_end_246, 0))) {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_list_2efind_24s2106830784x1074299306_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emergeRuns_24s2052062657x972894659_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s2052062657x972894659_entry, 2, 0};

V g_list_2emergeRuns_24s2052062657x972894659(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkPair = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s880359666x1597741115(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      V v_ru_24x32_243_24Cons = heff_take_reuse_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s495990157x1087861527(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_2412;
      switch (heff_tag_of(v_xs_245)) {
      case TAG_Nil: {
        V v_t_247 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
        v_t_2412 = heff_tag_at_n(v_ru_24x3_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_y_248 = heff_field(v_xs_245, 0);
        V v_ys_249 = heff_field(v_xs_245, 1);
        V v_ru_24xs_245_24Cons = heff_take_reuse_n(v_xs_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
        if (heff_intLe_c(heff_dup(heff_rfield(v_x_244, 2)), heff_dup(heff_rfield(v_y_248, 2)))) {
          V v_t_2410 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2412 = (g_list_2eascending_24s946492440x1788863194(heff_dup(v_y_248), heff_tag_re_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_248, v_t_2410}), v_ys_249));
        } else {
          V v_t_2411 = heff_tag_re_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2412 = (g_list_2edescending_24s1432586697x321478004(heff_dup(v_y_248), heff_tag_re_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_248, v_t_2411}), v_ys_249));
        }
        break;
      }
      default: heff_nomatch(v_xs_245);
      }
      V t_0 = v_t_246;
      V t_1 = v_t_2412;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s2052062657x972894659_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s2052062657x972894659(a[0], a[1]);
}
Clo g_list_2emap_24s23414532x1067218554_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s23414532x1067218554_24dps_entry, 7, 0};

V g_list_2emap_24s23414532x1067218554_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_246), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkFieldPat: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24MkFieldPat = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2esyntax_2eformat_2epatKey(v_a_2410));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_a_2413 = heff_tag_at_n(v_ru_24x_247_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_249, v_t_2412});
      V v_a_2414 = (g_list_2emap_24s231073986x752637537(heff_dup(v_lit_241), v_a_2413));
      V v_t_2417;
      switch (heff_tag_of(v_a_2414)) {
      case TAG_Nil: {
        v_t_2417 = heff_dup(v_lit_242);
        break;
      }
      case TAG_Cons: {
        V v_a_2415 = heff_field(v_a_2414, 0);
        V v_a_2416 = heff_field(v_a_2414, 1);
        heff_take_n(v_a_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = v_lit_243; V a_1 = v_a_2415; V a_2 = v_a_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2416); r_; });
        break;
      }
      default: heff_nomatch(v_a_2414);
      }
      v_t_2418 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2417), heff_dup(v_lit_244));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setFieldPeek(v_d_246, MK_INT(1LL), v_cell_2419);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_xs_248;
    V t_6 = v_u_2420;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_x2_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s23414532x1067218554_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V r = g_list_2emap_24s23414532x1067218554_24dps(a0, a1, a2, a3, a4, a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a6); return r;
}
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str0, 1, " ");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str3, 4, "(set");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str4, 1, ")");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str5, 1, " ");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str8, 4, "(bad");
HEFF_LIT(g_list_2emap_24s1099021180x1702355548_24dps_str9, 1, ")");
Clo g_list_2emap_24s1099021180x1702355548_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1099021180x1702355548_24dps_entry, 3, 0};

V g_list_2emap_24s1099021180x1702355548_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2426;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 1ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_SetField: {
        V v_x_249 = heff_field(v_x21_247, 0);
        V v_e_2411 = heff_field(v_x21_247, 2);
        heff_take_n(v_x21_247, 5ULL, 3);
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2411}));
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_parts_2414 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_Cons, 2, (V[]){v_x_249, v_t_2413});
        V v_x2_2415 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s1099021180x1702355548_24dps_str0), v_parts_2414));
        V v_t_2418;
        switch (heff_tag_of(v_x2_2415)) {
        case TAG_Nil: {
          v_t_2418 = ((V)&g_list_2emap_24s1099021180x1702355548_24dps_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2416 = heff_field(v_x2_2415, 0);
          V v_xs_2417 = heff_field(v_x2_2415, 1);
          heff_take_n(v_x2_2415, 3ULL, 2);
          v_t_2418 = ({ V a_0 = ((V)&g_list_2emap_24s1099021180x1702355548_24dps_str2); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2415);
        }
        v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1099021180x1702355548_24dps_str3), v_t_2418), ((V)&g_list_2emap_24s1099021180x1702355548_24dps_str4));
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2419 = heff_field(v_x21_247, 0);
        heff_take_n(v_x21_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_246_24At, 2);
        V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_e_2419}));
        V v_parts_2421 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
        V v_x2_2422 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s1099021180x1702355548_24dps_str5), v_parts_2421));
        V v_t_2425;
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_Nil: {
          v_t_2425 = ((V)&g_list_2emap_24s1099021180x1702355548_24dps_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2423 = heff_field(v_x2_2422, 0);
          V v_xs_2424 = heff_field(v_x2_2422, 1);
          heff_take_n(v_x2_2422, 3ULL, 2);
          v_t_2425 = ({ V a_0 = ((V)&g_list_2emap_24s1099021180x1702355548_24dps_str7); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2422);
        }
        v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1099021180x1702355548_24dps_str8), v_t_2425), ((V)&g_list_2emap_24s1099021180x1702355548_24dps_str9));
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
    V v_u_2428 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2427);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2428;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1099021180x1702355548_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1099021180x1702355548_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str0, 1, " ");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str3, 9, "(explicit");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str4, 1, ")");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str5, 1, " ");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str8, 9, "(implicit");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_24dps_str9, 1, ")");
Clo g_list_2emap_24s228910449x1110031924_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s228910449x1110031924_24dps_entry, 3, 0};

V g_list_2emap_24s228910449x1110031924_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2429;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 1ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_ExplicitParam: {
        V v_x_249 = heff_field(v_x21_247, 0);
        V v_t_2411 = heff_field(v_x21_247, 2);
        heff_take_n(v_x21_247, 5ULL, 3);
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_t_2411}));
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_parts_2414 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_Cons, 2, (V[]){v_x_249, v_t_2413});
        V v_x2_2415 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s228910449x1110031924_24dps_str0), v_parts_2414));
        V v_t_2418;
        switch (heff_tag_of(v_x2_2415)) {
        case TAG_Nil: {
          v_t_2418 = ((V)&g_list_2emap_24s228910449x1110031924_24dps_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2416 = heff_field(v_x2_2415, 0);
          V v_xs_2417 = heff_field(v_x2_2415, 1);
          heff_take_n(v_x2_2415, 3ULL, 2);
          v_t_2418 = ({ V a_0 = ((V)&g_list_2emap_24s228910449x1110031924_24dps_str2); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2415);
        }
        v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s228910449x1110031924_24dps_str3), v_t_2418), ((V)&g_list_2emap_24s228910449x1110031924_24dps_str4));
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_2419 = heff_field(v_x21_247, 0);
        V v_t_2421 = heff_field(v_x21_247, 2);
        heff_take_n(v_x21_247, 5ULL, 3);
        V v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_t_2421}));
        V v_t_2423 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
        V v_parts_2424 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_Cons, 2, (V[]){v_x_2419, v_t_2423});
        V v_x2_2425 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s228910449x1110031924_24dps_str5), v_parts_2424));
        V v_t_2428;
        switch (heff_tag_of(v_x2_2425)) {
        case TAG_Nil: {
          v_t_2428 = ((V)&g_list_2emap_24s228910449x1110031924_24dps_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2426 = heff_field(v_x2_2425, 0);
          V v_xs_2427 = heff_field(v_x2_2425, 1);
          heff_take_n(v_x2_2425, 3ULL, 2);
          v_t_2428 = ({ V a_0 = ((V)&g_list_2emap_24s228910449x1110031924_24dps_str7); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2425);
        }
        v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s228910449x1110031924_24dps_str8), v_t_2428), ((V)&g_list_2emap_24s228910449x1110031924_24dps_str9));
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, heff_hole()});
    V v_u_2431 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2430);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2431;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s228910449x1110031924_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s228910449x1110031924_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s571074576x1179600767_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s571074576x1179600767_entry, 2, 0};

V g_list_2efoldl_24s571074576x1179600767(V v_z_240, V v_x3_241) {
top: ;
  HeffT5 v_t_242 = (g_list_2efoldl_24s571074576x1179600767_24cpr(v_z_240, v_x3_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_field_246 = v_t_242.f[3];
    V v_field_247 = v_t_242.f[4];
    return heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){v_field_243, v_field_244, v_field_245, v_field_246, v_field_247});
  }
}
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s571074576x1179600767(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1181715076x1618420649_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1181715076x1618420649_24dps_entry, 7, 0};

V g_list_2ekeepIf_24s1181715076x1618420649_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_246), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_249 = heff_dup(heff_rfield(v_x_247, 1));
    V v_t_2410 = ({ V a_0 = v_a_249; V a_1 = v_lit_240; V a_2 = heff_dup(v_lit_241); V a_3 = heff_strFind_lent(v_lit_242, v_a_249, v_lit_243, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_249); r_; });
    V v_t_2411 = (g_list_2emap_24s649333309x1802289391(v_t_2410));
    V v_a_2412 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2411));
    switch (heff_tag_of(v_a_2412)) {
    case TAG_Nil: {
      V v_cell_2413 = heff_tag_re_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_247, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_246, MK_INT(1LL), v_cell_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_u_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    case TAG_Cons: {
      V v_a_2415 = heff_field(v_a_2412, 0);
      heff_take_n(v_a_2412, 1ULL, 2);
      if (heff_strEq_c_lent(v_a_2415, v_lit_244, 1)) {
        V v_cell_2417 = heff_tag_re_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_247, heff_hole()});
        V v_u_2418 = heff_setFieldPeek(v_d_246, MK_INT(1LL), v_cell_2417);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_u_2418;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      } else {
        heff_drop_rec(v_x_247, 2);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_248;
        V t_6 = v_d_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        v_d_246 = t_6;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_2412);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2ekeepIf_24s1181715076x1618420649_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V r = g_list_2ekeepIf_24s1181715076x1618420649_24dps(a0, a1, a2, a3, a4, a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a6); return r;
}
Clo g_list_2efoldl_24s1673889684x228869038_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1673889684x228869038_entry, 2, 0};

V g_list_2efoldl_24s1673889684x228869038(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_x_242, 1)), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1673889684x228869038_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1673889684x228869038(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s458067099x815639923_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s458067099x815639923_entry, 1, 0};

V g_list_2ekeepIf_24s458067099x815639923(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (!(heff_dup(heff_rfield(v_x_241, 1)) == NTAG(TAG_True))) {
      V v_cell_243 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_244 = (g_list_2ekeepIf_24s458067099x815639923_24dps(v_xs_242, v_cell_243));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop_rec(v_x_241, 12);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s458067099x815639923_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s458067099x815639923(a[0]);
}
Clo g_list_2emap_24s723912745x1713553694_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s723912745x1713553694_entry, 1, 0};

V g_list_2emap_24s723912745x1713553694(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_JString, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s723912745x1713553694_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s723912745x1713553694(a[0]);
}
Clo g_list_2emap_24s831190316x576961335_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s831190316x576961335_24dps_entry, 2, 0};

V g_list_2emap_24s831190316x576961335_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s831190316x576961335_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f2082849937x387822498_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2082849937x387822498_entry, 4, 0};

V g_list_2efoldl_24f2082849937x387822498(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c_lent(v_x_244, v_lit_242, 0)) {
      V t_0 = v_lit_240;
      V t_1 = heff_intAdd_lent(v_z_241, v_lit_240, 1);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f2082849937x387822498_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f2082849937x387822498(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24f1419248316x13095286_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1419248316x13095286_entry, 3, 0};

V g_list_2efoldl_24f1419248316x13095286(V v_z_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(v_z_240, heff_dup(v_ys_242)));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V t_0 = heff_tag_re_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, v_z_240});
    V t_1 = v_xs_244;
    V t_2 = v_ys_242;
    v_z_240 = t_0;
    v_x1_241 = t_1;
    v_ys_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1419248316x13095286(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2efoldl_24f380832527x418567417_str0, 1, " ");
HEFF_LIT(g_list_2efoldl_24f380832527x418567417_str1, 1, " ");
Clo g_list_2efoldl_24f380832527x418567417_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f380832527x418567417_entry, 3, 0};

V g_list_2efoldl_24f380832527x418567417(V v_z_240, V v_seen_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_seen_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_n_243 = heff_field(v_x2_242, 0);
    V v_ns_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_n_243, 1)), ((V)&g_list_2efoldl_24f380832527x418567417_str0));
    V v_t_246 = heff_strAppend(v_t_245, heff_dup(heff_rfield(v_n_243, 2)));
    V v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_seen_241; V r_ = (g_heff_2ecompile_2ebounds_2eelemS(a_0, a_1)); heff_drop(v_t_246); r_; });
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop_rec(v_n_243, 4);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = v_z_240;
      V t_1 = v_seen_241;
      V t_2 = v_ns_244;
      v_z_240 = t_0;
      v_seen_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_247);
      V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_n_243, 1)), ((V)&g_list_2efoldl_24f380832527x418567417_str1));
      V v_t_249 = heff_strAppend(v_t_248, heff_dup(heff_rfield(v_n_243, 2)));
      V t_0 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_n_243, v_z_240});
      V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_seen_241});
      V t_2 = v_ns_244;
      v_z_240 = t_0;
      v_seen_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f380832527x418567417_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f380832527x418567417(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f2092936166x2062766724_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2092936166x2062766724_entry, 3, 0};

V g_list_2efoldl_24f2092936166x2062766724(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_y_246 = heff_field(v_x_243, 1);
      v_x_247 = heff_dup(v_y_246);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    heff_drop(v_x_247);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd_lent(v_z_241, v_lit_240, 1);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24f2092936166x2062766724(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24f230958709x841260712_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f230958709x841260712_24dps_entry, 7, 0};

V g_list_2emap_24f230958709x841260712_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_246), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(heff_dup(v_p_244), 1, (V[]){heff_dup(v_x_247)}));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242));
      V v_t_2411 = heff_strAppend(v_t_2410, heff_intShow(v_x_247));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, heff_dup(v_lit_243)), heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_246, MK_INT(1LL), v_cell_2412);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_p_244;
      V t_5 = v_xs_248;
      V t_6 = v_u_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_p_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    } else {
      heff_drop(v_x_247);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_t_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_p_244;
      V t_5 = v_xs_248;
      V t_6 = v_d_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_p_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f230958709x841260712_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V r = g_list_2emap_24f230958709x841260712_24dps(a0, a1, a2, a3, a4, a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a6); return r;
}
Clo g_list_2emap_24f2124896334x71745266_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2124896334x71745266_24dps_entry, 13, 0};

V g_list_2emap_24f2124896334x71745266_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411, V v_d_2412) {
  int64_t v_lit_243 = heff_peek_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_peek_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_peek_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_peek_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_2412), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2411, 0);
    V v_xs_2414 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_a_2415 = heff_dup(heff_rfield(v_x_2413, 0));
    if ((heff_intLe_c_lent(v_lit_240, heff_strFind_lent(v_lit_241, v_a_2415, v_lit_242, 0), 2) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2415, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2415, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2415, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2415, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2415);
      V v_t_2416 = ({ V rr_ = heff_rec_reuse_na(v_x_2413, 3ULL, 2, shape_name__key, 15u, 0u); rr_; });
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = heff_setFieldPeek(v_d_2412, MK_INT(1LL), v_cell_2417);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_u_2418;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    } else {
      heff_drop_rec(v_x_2413, 2);
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_a_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2414;
      V t_12 = v_d_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      v_d_2412 = t_12;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f2124896334x71745266_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V a10 = a[10]; V a12 = a[12]; V r = g_list_2emap_24f2124896334x71745266_24dps(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a[11], a12); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); heff_drop(a8); heff_drop(a9); heff_drop(a10); heff_drop(a12); return r;
}
Clo g_list_2emap_24s509077117x607152875_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s509077117x607152875_24tok1_entry, 2, 0};

V g_list_2emap_24s509077117x607152875_24tok1(V v_tok_240, V v_x2_241) {
top: ;
  heff_drop_cell(v_tok_240, 1);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(heff_rfield(v_x_242, 2))));
    V v_t_245 = (g_heff_2ecompile_2eir_2enubI(v_t_244));
    V v_t_246 = heff_rec_n(5, shape_owner__key__name__item__refs, (V[]){heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_x_242, 1)), heff_tag_n(TAG_Fresh, 1, (V[]){v_x_242}), v_t_245});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s509077117x607152875_24dps(v_xs_243, v_cell_247));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s509077117x607152875_24tok1_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s509077117x607152875_24tok1(a[0], a[1]);
}