// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EQ 8989
#define TAG_GT 9054
#define TAG_LT 9209
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(V, V);
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_clo;
Clo g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_entry, 2, 0};

V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_EQ);
    }
    case TAG_Cons: {
      return NTAG(TAG_LT);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_GT);
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x2_241, 0);
      V v_ys_247 = heff_field(v_x2_241, 1);
      V v_it_248;
      if (heff_intLt_c_lent(v_x_244, v_y_246, 0)) {
        v_it_248 = NTAG(TAG_LT);
      } else {
        if (heff_intEq_c_lent(v_x_244, v_y_246, 0)) {
          v_it_248 = NTAG(TAG_EQ);
        } else {
          v_it_248 = NTAG(TAG_GT);
        }
      }
      switch (heff_tag_of(v_it_248)) {
      case TAG_LT: {
        return v_it_248;
      }
      case TAG_EQ: {
        V t_0 = v_xs_245;
        V t_1 = v_ys_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_GT: {
        return v_it_248;
      }
      default: return heff_nomatch(v_it_248);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_prelude_2einstanceOrderList_2elexically_240_24s1376843417x2112477349(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}