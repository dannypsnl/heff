// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_Left 13886
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_args 9498020
#define LBL_byName 571997869
#define LBL_entries 787768015
#define LBL_frameworks 717666174
#define LBL_fun 311289
#define LBL_libs 9816917
#define LBL_order 307364712
#define LBL_pkgConfig 1797780753
#define LBL_result 1012715336
#define LBL_tag 324116
#define LBL_tySyntax 1405311289
#define LBL_values 1123329101
static uint32_t shape_tag__fun__args__result[] = {LBL_tag, LBL_fun, LBL_args, LBL_result};
V g_heff_2ecompile_2eglue_2eappendF(V, V);
V g_heff_2ecompile_2eglue_2eappendF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eappendF_clo;
V g_heff_2ecompile_2eglue_2eappendF_24dps(V, V, V);
V g_heff_2ecompile_2eglue_2eappendF_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eappendF_24dps_clo;
HeffT2 g_heff_2ecompile_2eglue_2eargBad_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eglue_2eargsBad_24cpr(V, V, V, V);
V g_heff_2ecompile_2eglue_2ebindingOf(V, V);
V g_heff_2ecompile_2eglue_2ebindingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ebindingOf_clo;
HeffT2 g_heff_2ecompile_2eglue_2ebindingsOf_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(V);
V g_heff_2ecompile_2eglue_2edescribedIn(V, V);
V g_heff_2ecompile_2eglue_2edescribedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2edescribedIn_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1899415673x1401347262_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s231942830x1818376205_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2efieldOf_24cpr(V, V);
V g_heff_2ecompile_2eglue_2efits(V, V);
V g_heff_2ecompile_2eglue_2efits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2efits_clo;
V g_heff_2ecompile_2eglue_2eisGlobalTy(V, V);
V g_heff_2ecompile_2eglue_2eisGlobalTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eisGlobalTy_clo;
HeffT2 g_heff_2ecompile_2eglue_2elinksIn_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2elistOf_24cpr(V);
V g_heff_2ecompile_2eglue_2eofType(V, V, V);
V g_heff_2ecompile_2eglue_2eofType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eofType_clo;
HeffT2 g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eglue_2ereadLinks_24cpr(V);
V g_heff_2ecompile_2eglue_2ereadOp(V);
V g_heff_2ecompile_2eglue_2ereadOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ereadOp_clo;
HeffT2 g_heff_2ecompile_2eglue_2eresultBad_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eglue_2erightOf_24cpr(V);
V g_heff_2ecompile_2eglue_2etyOf(V);
V g_heff_2ecompile_2eglue_2etyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2etyOf_clo;
V g_heff_2ecompile_2einterp_2eevalReachedIn(V, V, V);
V g_heff_2ecompile_2einterp_2eevalReachedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalReachedIn_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24f1428084847x1450173891(V, V);
V g_list_2ekeepIf_24f1428084847x1450173891_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1428084847x1450173891_clo;
V g_list_2ekeepIf_24s1190092672x1539603713(V, V);
V g_list_2ekeepIf_24s1190092672x1539603713_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1190092672x1539603713_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eglue_2eappendF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eappendF_entry, 2, 0};

V g_heff_2ecompile_2eglue_2eappendF(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_245 = ({ V a_0 = v_xs_243; V a_1 = v_ys_241; V a_2 = v_cell_244; V r_ = (g_heff_2ecompile_2eglue_2eappendF_24dps(a_0, a_1, a_2)); heff_drop(v_ys_241); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2eappendF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2eappendF(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eglue_2elistOf_24cpr_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2eglue_2elistOf_24cpr_str1, 4, "Cons");

HeffT2 g_heff_2ecompile_2eglue_2elistOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VTag: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2elistOf_24cpr_str0), 2)) {
      heff_drop(v_x11_243);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
      }
      case TAG_Cons: {
        heff_take_n(v_x12_244, 0ULL, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
      }
    } else {
      if (heff_strEq_c(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2elistOf_24cpr_str1))) {
        switch (heff_tag_of(v_x12_244)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_247 = heff_field(v_x12_244, 0);
          V v_x122_248 = heff_field(v_x12_244, 1);
          heff_take_n(v_x12_244, 3ULL, 2);
          switch (heff_tag_of(v_x122_248)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_247);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Cons: {
            V v_rest_249 = heff_field(v_x122_248, 0);
            V v_x1222_2410 = heff_field(v_x122_248, 1);
            heff_take_n(v_x122_248, 3ULL, 2);
            switch (heff_tag_of(v_x1222_2410)) {
            case TAG_Nil: {
              HeffT2 v_t_2411 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_rest_249));
              {
                V v_field_2413 = v_t_2411.f[1];
                int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
                if ((v_tag_2412 == ((int64_t)0ULL))) {
                  V v_xs_2414 = v_field_2413;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_247, v_xs_2414})}});
                } else {
                  heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                  heff_drop(v_x_247);
                  heff_drop(v_field_2413);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            case TAG_Cons: {
              heff_take_n(v_x1222_2410, 0ULL, 2);
              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
              heff_drop(v_x_247);
              heff_drop(v_rest_249);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x1222_2410)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x122_248)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
        }
      } else {
        heff_drop(v_x12_244);
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VErased: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2ecompile_2eglue_2efieldOf_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    V v_byName_244 = heff_dup(heff_rfield(v_fs_243, 1));
    V v_values_245 = heff_dup(heff_rfield(v_fs_243, 2));
    HeffT2 v_t_246 = ({ V a_0 = v_byName_244; V a_1 = v_x_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_244); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_i_249 = v_field_248;
        V v_xs_2410 = v_values_245;
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_249, 1) && heff_intLt_c_lent(v_i_249, heff_arrayLength_lent(v_xs_2410, 0), 2))) {
          V v_t_2411 = heff_arrayIndex(v_xs_2410, v_i_249);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
        } else {
          heff_drop(v_i_249);
          heff_drop(v_xs_2410);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_values_245);
        heff_drop(v_field_248);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_VTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat32: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VStr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VArr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBits: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VErased: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str0, 8, "CInteger");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str1, 7, "CDouble");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str2, 5, "CBool");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str3, 7, "CString");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str4, 5, "CText");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str5, 12, "COwnedString");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str6, 6, "CBytes");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str7, 11, "COwnedBytes");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str8, 8, "CPointer");
HEFF_LIT(g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str9, 5, "CVoid");

HeffT2 g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VTag: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_x12_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str0), 2)) {
      heff_drop(v_x11_243);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x121_245 = heff_field(v_x12_244, 0);
        V v_x122_246 = heff_field(v_x12_244, 1);
        heff_take_n(v_x12_244, 3ULL, 2);
        switch (heff_tag_of(v_x121_245)) {
        case TAG_VFun: {
          heff_take_n(v_x121_245, 0ULL, 1);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VCons: {
          heff_take_n(v_x121_245, 0ULL, 1);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VTag: {
          heff_take_n(v_x121_245, 0ULL, 2);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VInt: {
          heff_take_n(v_x121_245, 0ULL, 1);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VFloat: {
          heff_take_na(v_x121_245, 0ULL, 1);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VFloat32: {
          heff_take_n(v_x121_245, 0ULL, 1);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VStr: {
          V v_t_2414 = heff_field(v_x121_245, 0);
          V v_ru_24x121_245_24VStr = heff_take_reuse_n(v_x121_245, 1ULL, 1);
          switch (heff_tag_of(v_x122_246)) {
          case TAG_Nil: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x121_245_24VStr, TAG_CInteger, 1, (V[]){v_t_2414})}});
          }
          case TAG_Cons: {
            heff_take_n(v_x122_246, 0ULL, 2);
            heff_drop(v_t_2414);
            heff_drop_cell(v_ru_24x121_245_24VStr, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x122_246)}});
          }
        }
        case TAG_VRune: {
          heff_take_n(v_x121_245, 0ULL, 1);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VArr: {
          heff_take_n(v_x121_245, 0ULL, 1);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VBytes: {
          heff_take_n(v_x121_245, 0ULL, 1);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VBits: {
          heff_take_n(v_x121_245, 0ULL, 2);
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_VErased: {
          heff_drop(v_x122_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x121_245)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str1), 2)) {
        heff_drop(v_x11_243);
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        switch (heff_tag_of(v_x12_244)) {
        case TAG_Nil: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CDouble)}});
        }
        case TAG_Cons: {
          heff_take_n(v_x12_244, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str2), 2)) {
          heff_drop(v_x11_243);
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          switch (heff_tag_of(v_x12_244)) {
          case TAG_Nil: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CBool)}});
          }
          case TAG_Cons: {
            heff_take_n(v_x12_244, 0ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str3), 2)) {
            heff_drop(v_x11_243);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            switch (heff_tag_of(v_x12_244)) {
            case TAG_Nil: {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CString)}});
            }
            case TAG_Cons: {
              heff_take_n(v_x12_244, 0ULL, 2);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str4), 2)) {
              heff_drop(v_x11_243);
              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
              switch (heff_tag_of(v_x12_244)) {
              case TAG_Nil: {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CText)}});
              }
              case TAG_Cons: {
                heff_take_n(v_x12_244, 0ULL, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
              }
            } else {
              if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str5), 2)) {
                heff_drop(v_x11_243);
                heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                switch (heff_tag_of(v_x12_244)) {
                case TAG_Nil: {
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_COwnedString)}});
                }
                case TAG_Cons: {
                  heff_take_n(v_x12_244, 0ULL, 2);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                }
              } else {
                if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str6), 2)) {
                  heff_drop(v_x11_243);
                  heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                  switch (heff_tag_of(v_x12_244)) {
                  case TAG_Nil: {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CBytes)}});
                  }
                  case TAG_Cons: {
                    heff_take_n(v_x12_244, 0ULL, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                  }
                } else {
                  if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str7), 2)) {
                    heff_drop(v_x11_243);
                    heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                    switch (heff_tag_of(v_x12_244)) {
                    case TAG_Nil: {
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_COwnedBytes)}});
                    }
                    case TAG_Cons: {
                      heff_take_n(v_x12_244, 0ULL, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str8), 2)) {
                      heff_drop(v_x11_243);
                      switch (heff_tag_of(v_x12_244)) {
                      case TAG_Nil: {
                        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Cons: {
                        V v_x121_2436 = heff_field(v_x12_244, 0);
                        V v_x122_2437 = heff_field(v_x12_244, 1);
                        heff_take_n(v_x12_244, 3ULL, 2);
                        switch (heff_tag_of(v_x121_2436)) {
                        case TAG_VFun: {
                          heff_take_n(v_x121_2436, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VCons: {
                          heff_take_n(v_x121_2436, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VTag: {
                          heff_take_n(v_x121_2436, 0ULL, 2);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VInt: {
                          heff_take_n(v_x121_2436, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VFloat: {
                          heff_take_na(v_x121_2436, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VFloat32: {
                          heff_take_n(v_x121_2436, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VStr: {
                          V v_t_2445 = heff_field(v_x121_2436, 0);
                          heff_take_n(v_x121_2436, 1ULL, 1);
                          switch (heff_tag_of(v_x122_2437)) {
                          case TAG_Nil: {
                            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                            heff_drop(v_t_2445);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Cons: {
                            V v_x1221_2446 = heff_field(v_x122_2437, 0);
                            V v_x1222_2447 = heff_field(v_x122_2437, 1);
                            heff_take_n(v_x122_2437, 3ULL, 2);
                            switch (heff_tag_of(v_x1221_2446)) {
                            case TAG_VFun: {
                              heff_take_n(v_x1221_2446, 0ULL, 1);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VCons: {
                              heff_take_n(v_x1221_2446, 0ULL, 1);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VTag: {
                              heff_take_n(v_x1221_2446, 0ULL, 2);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VInt: {
                              heff_take_n(v_x1221_2446, 0ULL, 1);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VFloat: {
                              heff_take_na(v_x1221_2446, 0ULL, 1);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VFloat32: {
                              heff_take_n(v_x1221_2446, 0ULL, 1);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VStr: {
                              V v_r_2455 = heff_field(v_x1221_2446, 0);
                              heff_take_n(v_x1221_2446, 1ULL, 1);
                              switch (heff_tag_of(v_x1222_2447)) {
                              case TAG_Nil: {
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_CPointer, 2, (V[]){v_t_2445, v_r_2455})}});
                              }
                              case TAG_Cons: {
                                heff_take_n(v_x1222_2447, 0ULL, 2);
                                heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                                heff_drop(v_t_2445);
                                heff_drop(v_r_2455);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x1222_2447)}});
                              }
                            }
                            case TAG_VRune: {
                              heff_take_n(v_x1221_2446, 0ULL, 1);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VArr: {
                              heff_take_n(v_x1221_2446, 0ULL, 1);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VBytes: {
                              heff_take_n(v_x1221_2446, 0ULL, 1);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VBits: {
                              heff_take_n(v_x1221_2446, 0ULL, 2);
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            case TAG_VErased: {
                              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                              heff_drop(v_t_2445);
                              heff_drop(v_x1222_2447);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x1221_2446)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x122_2437)}});
                          }
                        }
                        case TAG_VRune: {
                          heff_take_n(v_x121_2436, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VArr: {
                          heff_take_n(v_x121_2436, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VBytes: {
                          heff_take_n(v_x121_2436, 0ULL, 1);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VBits: {
                          heff_take_n(v_x121_2436, 0ULL, 2);
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_VErased: {
                          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                          heff_drop(v_x122_2437);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x121_2436)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                      }
                    } else {
                      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
                      if (heff_strEq_c(v_x11_243, ((V)&g_heff_2ecompile_2eglue_2ecTypeOf_24cpr_str9))) {
                        switch (heff_tag_of(v_x12_244)) {
                        case TAG_Nil: {
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_CVoid)}});
                        }
                        case TAG_Cons: {
                          heff_take_n(v_x12_244, 0ULL, 2);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x12_244)}});
                        }
                      } else {
                        heff_drop(v_x12_244);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VErased: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_v_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(v_v_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        HeffT2 v_t_247 = (g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(v_rest_242));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_xs_2410 = v_field_249;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_xs_2410})}});
          } else {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_x_246);
            heff_drop(v_field_249);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str0, 2, "op");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str1, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str2, 4, "name");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str3, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str4, 4, "args");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str5, 3, "fun");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str6, 6, "result");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str7, 5, "Gives");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str8, 12, "GivesOrErrno");
HEFF_LIT(g_heff_2ecompile_2eglue_2ereadOp_str9, 11, "DoneOrErrno");
V g_heff_2ecompile_2eglue_2ereadOp_lam0(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam1(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam2(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam3(V self, V *args);
V g_heff_2ecompile_2eglue_2ereadOp_lam4(V self, V *args); static Clo g_heff_2ecompile_2eglue_2ereadOp_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ereadOp_lam4, 4, 0};
Clo g_heff_2ecompile_2eglue_2ereadOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ereadOp_entry, 1, 0};

V g_heff_2ecompile_2eglue_2ereadOp(V v_v_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(v_v_240, ((V)&g_heff_2ecompile_2eglue_2ereadOp_str0)));
  {
    V v_field_243 = v_t_241.f[1];
    V v_tag_242 = heff_box_i64(((int64_t)v_t_241.f[0]));
    HeffT2 v_t_244 = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(v_v_240, ((V)&g_heff_2ecompile_2eglue_2ereadOp_str1)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_x2_2425;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        HeffT2 v_t_248 = ({ V a_0 = v_x_247; V a_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str2); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, a_1)); heff_drop(v_x_247); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x_2411 = v_field_2410;
            switch (heff_tag_of(v_x_2411)) {
            case TAG_VFun: {
              heff_take_n(v_x_2411, 0ULL, 1);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VCons: {
              heff_take_n(v_x_2411, 0ULL, 1);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VTag: {
              heff_take_n(v_x_2411, 0ULL, 2);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VInt: {
              heff_take_n(v_x_2411, 0ULL, 1);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VFloat: {
              heff_take_na(v_x_2411, 0ULL, 1);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VFloat32: {
              heff_take_n(v_x_2411, 0ULL, 1);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VStr: {
              V v_s_2419 = heff_field(v_x_2411, 0);
              V v_ru_24x_2411_24VStr = heff_take_reuse_n(v_x_2411, 1ULL, 1);
              v_x2_2425 = heff_tag_at_n(v_ru_24x_2411_24VStr, TAG_Just, 1, (V[]){v_s_2419});
              break;
            }
            case TAG_VRune: {
              heff_take_n(v_x_2411, 0ULL, 1);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VArr: {
              heff_take_n(v_x_2411, 0ULL, 1);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VBytes: {
              heff_take_n(v_x_2411, 0ULL, 1);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VBits: {
              heff_take_n(v_x_2411, 0ULL, 2);
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_VErased: {
              v_x2_2425 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x_2411);
            }
          } else {
            heff_drop(v_field_2410);
            v_x2_2425 = NTAG(TAG_Nothing);
          }
        }
      } else {
        heff_drop(v_field_246);
        v_x2_2425 = NTAG(TAG_Nothing);
      }
      HeffT2 v_t_2426 = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(v_v_240, ((V)&g_heff_2ecompile_2eglue_2ereadOp_str3)));
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        V v_t_24112;
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_x_2429 = v_field_2428;
          HeffT2 v_t_2430 = ({ V a_0 = v_x_2429; V a_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str4); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, a_1)); heff_drop(v_x_2429); r_; });
          {
            V v_field_2432 = v_t_2430.f[1];
            int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
            if ((v_tag_2431 == ((int64_t)0ULL))) {
              V v_x_2433 = v_field_2432;
              HeffT2 v_t_2434 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_x_2433));
              {
                V v_field_2436 = v_t_2434.f[1];
                int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
                if ((v_tag_2435 == ((int64_t)0ULL))) {
                  V v_x_2437 = v_field_2436;
                  HeffT2 v_t_2438 = (g_heff_2ecompile_2eglue_2eeachOf_24s1262413731x290637868_24cpr(v_x_2437));
                  {
                    V v_field_2440 = v_t_2438.f[1];
                    V v_tag_2439 = heff_box_i64(((int64_t)v_t_2438.f[0]));
                    v_t_24112 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam0, 2, 5, (V[]){v_tag_242, v_field_243, v_x2_2425, v_tag_2439, v_field_2440});
                  }
                } else {
                  heff_drop(v_field_2436);
                  v_t_24112 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam1, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2425});
                }
              }
            } else {
              heff_drop(v_field_2432);
              v_t_24112 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam2, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2425});
            }
          }
        } else {
          heff_drop(v_field_2428);
          v_t_24112 = heff_clo_n(g_heff_2ecompile_2eglue_2ereadOp_lam3, 2, 3, (V[]){v_tag_242, v_field_243, v_x2_2425});
        }
        HeffT2 v_t_24113 = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(v_v_240, ((V)&g_heff_2ecompile_2eglue_2ereadOp_str5)));
        {
          V v_field_24115 = v_t_24113.f[1];
          int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
          V v_t_24153;
          if ((v_tag_24114 == ((int64_t)0ULL))) {
            V v_x_24116 = v_field_24115;
            HeffT2 v_t_24117 = ({ V a_0 = v_x_24116; V a_1 = ((V)&g_heff_2ecompile_2eglue_2ereadOp_str6); HeffT2 r_ = (g_heff_2ecompile_2eglue_2efieldOf_24cpr(a_0, a_1)); heff_drop(v_x_24116); r_; });
            {
              V v_field_24119 = v_t_24117.f[1];
              int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
              if ((v_tag_24118 == ((int64_t)0ULL))) {
                V v_x_24120 = v_field_24119;
                V v_x1_24121 = v_x_24120;
                switch (heff_tag_of(v_x1_24121)) {
                case TAG_VFun: {
                  heff_take_n(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VCons: {
                  heff_take_n(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VTag: {
                  V v_x11_24124 = heff_field(v_x1_24121, 0);
                  V v_x12_24125 = heff_field(v_x1_24121, 1);
                  heff_take_n(v_x1_24121, 3ULL, 2);
                  if (heff_strEq_c_lent(v_x11_24124, ((V)&g_heff_2ecompile_2eglue_2ereadOp_str7), 2)) {
                    heff_drop(v_x11_24124);
                    switch (heff_tag_of(v_x12_24125)) {
                    case TAG_Nil: {
                      v_t_24153 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Cons: {
                      V v_t_24126 = heff_field(v_x12_24125, 0);
                      V v_x122_24127 = heff_field(v_x12_24125, 1);
                      heff_take_n(v_x12_24125, 3ULL, 2);
                      switch (heff_tag_of(v_x122_24127)) {
                      case TAG_Nil: {
                        HeffT2 v_t_24128 = (g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(v_t_24126));
                        {
                          V v_field_24130 = v_t_24128.f[1];
                          int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
                          if ((v_tag_24129 == ((int64_t)0ULL))) {
                            V v_c_24131 = v_field_24130;
                            v_t_24153 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Gives, 1, (V[]){v_c_24131})});
                          } else {
                            heff_drop(v_field_24130);
                            v_t_24153 = NTAG(TAG_Nothing);
                          }
                        }
                        break;
                      }
                      case TAG_Cons: {
                        heff_take_n(v_x122_24127, 0ULL, 2);
                        heff_drop(v_t_24126);
                        v_t_24153 = NTAG(TAG_Nothing);
                        break;
                      }
                      default: heff_nomatch(v_x122_24127);
                      }
                      break;
                    }
                    default: heff_nomatch(v_x12_24125);
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x11_24124, ((V)&g_heff_2ecompile_2eglue_2ereadOp_str8), 2)) {
                      heff_drop(v_x11_24124);
                      switch (heff_tag_of(v_x12_24125)) {
                      case TAG_Nil: {
                        v_t_24153 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Cons: {
                        V v_t_24134 = heff_field(v_x12_24125, 0);
                        V v_x122_24135 = heff_field(v_x12_24125, 1);
                        heff_take_n(v_x12_24125, 3ULL, 2);
                        switch (heff_tag_of(v_x122_24135)) {
                        case TAG_Nil: {
                          HeffT2 v_t_24136 = (g_heff_2ecompile_2eglue_2ecTypeOf_24cpr(v_t_24134));
                          {
                            V v_field_24138 = v_t_24136.f[1];
                            int64_t v_tag_24137 = ((int64_t)v_t_24136.f[0]);
                            if ((v_tag_24137 == ((int64_t)0ULL))) {
                              V v_c_24139 = v_field_24138;
                              v_t_24153 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_GivesOrErrno, 1, (V[]){v_c_24139})});
                            } else {
                              heff_drop(v_field_24138);
                              v_t_24153 = NTAG(TAG_Nothing);
                            }
                          }
                          break;
                        }
                        case TAG_Cons: {
                          heff_take_n(v_x122_24135, 0ULL, 2);
                          heff_drop(v_t_24134);
                          v_t_24153 = NTAG(TAG_Nothing);
                          break;
                        }
                        default: heff_nomatch(v_x122_24135);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x12_24125);
                      }
                    } else {
                      if (heff_strEq_c(v_x11_24124, ((V)&g_heff_2ecompile_2eglue_2ereadOp_str9))) {
                        switch (heff_tag_of(v_x12_24125)) {
                        case TAG_Nil: {
                          v_t_24153 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_DoneOrErrno)});
                          break;
                        }
                        case TAG_Cons: {
                          heff_take_n(v_x12_24125, 0ULL, 2);
                          v_t_24153 = NTAG(TAG_Nothing);
                          break;
                        }
                        default: heff_nomatch(v_x12_24125);
                        }
                      } else {
                        heff_drop(v_x12_24125);
                        v_t_24153 = NTAG(TAG_Nothing);
                      }
                    }
                  }
                  break;
                }
                case TAG_VInt: {
                  heff_take_n(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VFloat: {
                  heff_take_na(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VFloat32: {
                  heff_take_n(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VStr: {
                  heff_take_n(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VRune: {
                  heff_take_n(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VArr: {
                  heff_take_n(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VBytes: {
                  heff_take_n(v_x1_24121, 0ULL, 1);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VBits: {
                  heff_take_n(v_x1_24121, 0ULL, 2);
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_VErased: {
                  v_t_24153 = NTAG(TAG_Nothing);
                  break;
                }
                default: heff_nomatch(v_x1_24121);
                }
              } else {
                heff_drop(v_field_24119);
                v_t_24153 = NTAG(TAG_Nothing);
              }
            }
          } else {
            heff_drop(v_field_24115);
            v_t_24153 = NTAG(TAG_Nothing);
          }
          return heff_tail(v_t_24112, 2, (V[]){v_t_24153, ((V)&g_heff_2ecompile_2eglue_2ereadOp_lam4_clo)});
        }
      }
    }
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eglue_2ereadOp(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eglue_2ereadOp_lam0(V self, V *args) {
  V v_x4_2441 = args[0];
  V v_f_2442 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2425 = heff_env(self)[2];
  V v_tag_2439 = heff_env(self)[3];
  V v_field_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2443 = v_field_243;
    switch (heff_tag_of(v_x_2443)) {
    case TAG_VFun: {
      heff_take_n(v_x_2443, 0ULL, 1);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2443, 0ULL, 1);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2443, 0ULL, 2);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2443, 0ULL, 1);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2443, 0ULL, 1);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2443, 0ULL, 1);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      V v_s_2451 = heff_field(v_x_2443, 0);
      V v_ru_24x_2443_24VStr = heff_take_reuse_n(v_x_2443, 1ULL, 1);
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nothing: {
        heff_drop(v_x4_2441);
        heff_drop(v_f_2442);
        heff_drop(v_tag_2439);
        heff_drop(v_field_2440);
        heff_drop(v_s_2451);
        heff_drop_cell(v_ru_24x_2443_24VStr, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_2452 = heff_field(v_x2_2425, 0);
        heff_take_n(v_x2_2425, 1ULL, 1);
        if ((heff_unbox_i64(v_tag_2439) == ((int64_t)0ULL))) {
          V v_c_2453 = v_field_2440;
          switch (heff_tag_of(v_x4_2441)) {
          case TAG_Nothing: {
            heff_drop(v_f_2442);
            heff_drop(v_s_2451);
            heff_drop_cell(v_ru_24x_2443_24VStr, 1);
            heff_drop(v_b_2452);
            heff_drop(v_c_2453);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_d_2454 = heff_field(v_x4_2441, 0);
            heff_take_n(v_x4_2441, 1ULL, 1);
            V v_t_2455 = heff_tr(heff_call(v_f_2442, 4, (V[]){v_s_2451, v_b_2452, v_c_2453, v_d_2454}));
            return heff_tag_at_n(v_ru_24x_2443_24VStr, TAG_Just, 1, (V[]){v_t_2455});
          }
          default: return heff_nomatch(v_x4_2441);
          }
        } else {
          heff_drop(v_x4_2441);
          heff_drop(v_f_2442);
          heff_drop(v_field_2440);
          heff_drop(v_s_2451);
          heff_drop_cell(v_ru_24x_2443_24VStr, 1);
          heff_drop(v_b_2452);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2443, 0ULL, 1);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2443, 0ULL, 1);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2443, 0ULL, 1);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2443, 0ULL, 2);
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x4_2441);
      heff_drop(v_f_2442);
      heff_drop(v_x2_2425);
      heff_drop(v_tag_2439);
      heff_drop(v_field_2440);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2443);
    }
  } else {
    heff_drop(v_x4_2441);
    heff_drop(v_f_2442);
    heff_drop(v_field_243);
    heff_drop(v_x2_2425);
    heff_drop(v_tag_2439);
    heff_drop(v_field_2440);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam1(V self, V *args) {
  V v_x4_2461 = args[0];
  V v_f_2462 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2425 = heff_env(self)[2];
  heff_drop(v_x4_2461);
  heff_drop(v_f_2462);
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2463 = v_field_243;
    switch (heff_tag_of(v_x_2463)) {
    case TAG_VFun: {
      heff_take_n(v_x_2463, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2463, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2463, 0ULL, 2);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2463, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2463, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2463, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_2463, 0ULL, 1);
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2425, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2463, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2463, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2463, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2463, 0ULL, 2);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2463);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2425);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam2(V self, V *args) {
  V v_x4_2478 = args[0];
  V v_f_2479 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2425 = heff_env(self)[2];
  heff_drop(v_x4_2478);
  heff_drop(v_f_2479);
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2480 = v_field_243;
    switch (heff_tag_of(v_x_2480)) {
    case TAG_VFun: {
      heff_take_n(v_x_2480, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2480, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2480, 0ULL, 2);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2480, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2480, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2480, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_2480, 0ULL, 1);
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2425, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2480, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2480, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2480, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2480, 0ULL, 2);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2480);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2425);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam3(V self, V *args) {
  V v_x4_2495 = args[0];
  V v_f_2496 = args[1];
  V v_tag_242 = heff_env(self)[0];
  V v_field_243 = heff_env(self)[1];
  V v_x2_2425 = heff_env(self)[2];
  heff_drop(v_x4_2495);
  heff_drop(v_f_2496);
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_242) == ((int64_t)0ULL))) {
    V v_x_2497 = v_field_243;
    switch (heff_tag_of(v_x_2497)) {
    case TAG_VFun: {
      heff_take_n(v_x_2497, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_take_n(v_x_2497, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VTag: {
      heff_take_n(v_x_2497, 0ULL, 2);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VInt: {
      heff_take_n(v_x_2497, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat: {
      heff_take_na(v_x_2497, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_2497, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VStr: {
      heff_take_n(v_x_2497, 0ULL, 1);
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x2_2425, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
    case TAG_VRune: {
      heff_take_n(v_x_2497, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VArr: {
      heff_take_n(v_x_2497, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBytes: {
      heff_take_n(v_x_2497, 0ULL, 1);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VBits: {
      heff_take_n(v_x_2497, 0ULL, 2);
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_VErased: {
      heff_drop(v_x2_2425);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x_2497);
    }
  } else {
    heff_drop(v_field_243);
    heff_drop(v_x2_2425);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eglue_2ereadOp_lam4(V self, V *args) {
  V v_tag_24154 = args[0];
  V v_fun_24155 = args[1];
  V v_args_24156 = args[2];
  V v_result_24157 = args[3];
  return heff_rec_n(4, shape_tag__fun__args__result, (V[]){v_tag_24154, v_fun_24155, v_args_24156, v_result_24157});
}

HeffT2 g_heff_2ecompile_2eglue_2eeachOf_24s231942830x1818376205_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_v_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VFun: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VCons: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VTag: {
      heff_take_n(v_v_241, 0ULL, 2);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VInt: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VStr: {
      V v_s_2410 = heff_field(v_v_241, 0);
      heff_take_n(v_v_241, 1ULL, 1);
      HeffT2 v_t_2411 = (g_heff_2ecompile_2eglue_2eeachOf_24s231942830x1818376205_24cpr(v_rest_242));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_xs_2414 = v_field_2413;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_s_2410, v_xs_2414})}});
        } else {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_s_2410);
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_VRune: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VArr: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241, 0ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241, 0ULL, 2);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VErased: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_v_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eofType_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eofType_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2eofType_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2eofType_str3, 1, ".");
V g_heff_2ecompile_2eglue_2eofType_lam0(V self, V *args);
V g_heff_2ecompile_2eglue_2eofType_lam1(V self, V *args);
Clo g_heff_2ecompile_2eglue_2eofType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eofType_entry, 3, 0};

V g_heff_2ecompile_2eglue_2eofType(V v_g_240, V v_m_241, V v_t_242) {
top: ;
  V v_entries_243 = heff_take_field(v_g_240, 1);
  V v_order_244 = heff_get_n(v_g_240, 0, 8);
  V v_t_2411 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eglue_2eofType_lam0, 2, 1, (V[]){v_entries_243}); V a_1 = NTAG(TAG_Nil); V a_2 = v_order_244; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_order_244); r_; });
  V v_t_2424 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eglue_2eofType_lam1, 1, 2, (V[]){heff_dup(v_m_241), heff_dup(v_t_242)}); V a_1 = v_t_2411; V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  return (g_list_2emap_24s1937570095x2110149801(v_t_2424));
}
V g_heff_2ecompile_2eglue_2eofType_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eglue_2eofType(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eglue_2eofType_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_k_246 = args[1];
  V v_entries_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V a_0 = v_entries_243; V a_1 = v_k_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_243); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_e_2410 = v_field_249;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_246, v_e_2410}), v_acc_245});
    } else {
      heff_drop(v_k_246);
      heff_drop(v_field_249);
      return v_acc_245;
    }
  }
}
V g_heff_2ecompile_2eglue_2eofType_lam1(V self, V *args) {
  V v_p_2412 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_k_2415;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_p_2412, 0));
    v_k_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2416 = ({ V a_0 = v_k_2415; V a_1 = ((V)&g_heff_2ecompile_2eglue_2eofType_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2eofType_str1), v_k_2415, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_2415); r_; });
  V v_x2_2417 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eofType_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2eofType_str3); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  heff_clo_take(self, 2);
  if (heff_strEq_c(v_t_2420, v_m_241)) {
    V v_t_2423;
    switch (heff_tag_of(v_p_2412)) {
    case TAG_MkPair: {
      V v_y_2422 = heff_field(v_p_2412, 1);
      heff_take_n(v_p_2412, 2ULL, 2);
      v_t_2423 = v_y_2422;
      break;
    }
    default: heff_nomatch(v_p_2412);
    }
    return ({ V a_0 = v_t_242; V a_1 = heff_get_n(v_t_2423, 1, 4); V r_ = (g_heff_2ecompile_2eglue_2eisGlobalTy(a_0, a_1)); heff_drop(v_t_242); r_; });
  } else {
    heff_drop(v_p_2412);
    heff_drop(v_t_242);
    return NTAG(TAG_False);
  }
}
Clo g_heff_2ecompile_2eglue_2etyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2etyOf_entry, 1, 0};

V g_heff_2ecompile_2eglue_2etyOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SU: {
    return v_x1_240;
  }
  case TAG_SDecode: {
    V v_x11_242 = heff_dup(heff_field(v_x1_240, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLocal: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SGlobal: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SCode: {
      V v_t_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      switch (heff_tag_of(v_x1_240)) {
      case TAG_SDecode: {
        heff_take_n(v_x1_240, 0ULL, 1);
        V t_0 = v_t_245;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x1_240);
      }
    }
    case TAG_SApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SLam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SProj: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_STag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x11_242, 0ULL, 3);
      return v_x1_240;
    }
    case TAG_SIs: {
      V v_e_2421 = heff_field(v_x11_242, 0);
      V v_ru_24x11_242_24SIs = heff_take_reuse_n(v_x11_242, 1ULL, 1);
      switch (heff_tag_of(v_x1_240)) {
      case TAG_SDecode: {
        heff_take_n(v_x1_240, 0ULL, 1);
        V t_0 = heff_tag_at_n(v_ru_24x11_242_24SIs, TAG_SDecode, 1, (V[]){v_e_2421});
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_x1_240);
      }
    }
    case TAG_SOpaque: {
      return v_x1_240;
    }
    case TAG_SAbandon: {
      return v_x1_240;
    }
    case TAG_SRec: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SFix: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SImplicit: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SPrim: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x11_242, 0ULL, 3);
      return v_x1_240;
    }
    case TAG_SLitInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      return v_x1_240;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x11_242, 0ULL, 1);
      return v_x1_240;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_SFunction: {
    return v_x1_240;
  }
  case TAG_SRecord: {
    return v_x1_240;
  }
  case TAG_SSum: {
    return v_x1_240;
  }
  case TAG_SIsTy: {
    V v_t_2449 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_t_2449;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_x1_240;
  }
  case TAG_SPrimFloat: {
    return v_x1_240;
  }
  case TAG_SPrimString: {
    return v_x1_240;
  }
  case TAG_SPrimRune: {
    return v_x1_240;
  }
  case TAG_SPrimArray: {
    return v_x1_240;
  }
  case TAG_SFixed: {
    return v_x1_240;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2etyOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2etyOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str0, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str1, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str2, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str3, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str4, 13, "prelude.Bytes");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str5, 12, "builtin.Bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2efits_str6, 12, "builtin.Unit");
Clo g_heff_2ecompile_2eglue_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2efits_entry, 2, 0};

V g_heff_2ecompile_2eglue_2efits(V v_x1_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CInteger: {
    V v_it_243 = (g_heff_2ecompile_2eglue_2etyOf(heff_dup(v_t_241)));
    switch (heff_tag_of(v_it_243)) {
    case TAG_SU: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_245 = heff_field(v_it_243, 0);
      heff_take_n(v_it_243, 1ULL, 1);
      switch (heff_tag_of(v_it1_245)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_247 = heff_field(v_it1_245, 0);
        heff_take_n(v_it1_245, 1ULL, 1);
        V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_g_247, ((V)&g_heff_2ecompile_2eglue_2efits_str0), 2));
        heff_drop(v_g_247);
        return v_ret_24bool;
      }
      case TAG_SCode: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_245, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_245, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_245);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_243, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_243, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_True);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_243, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_243);
    }
  }
  case TAG_CDouble: {
    V v_it_2453 = (g_heff_2ecompile_2eglue_2etyOf(heff_dup(v_t_241)));
    switch (heff_tag_of(v_it_2453)) {
    case TAG_SU: {
      heff_take_n(v_it_2453, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_2455 = heff_field(v_it_2453, 0);
      heff_take_n(v_it_2453, 1ULL, 1);
      switch (heff_tag_of(v_it1_2455)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_2457 = heff_field(v_it1_2455, 0);
        heff_take_n(v_it1_2455, 1ULL, 1);
        V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_g_2457, ((V)&g_heff_2ecompile_2eglue_2efits_str1), 2));
        heff_drop(v_g_2457);
        return v_ret_24bool;
      }
      case TAG_SCode: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_2455, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_2455, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_2455, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_2455, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_2455, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_2455, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_2455, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_2455, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_2455, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_2455, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_2455, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_2455);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_2453, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_2453, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_2453, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_2453, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_True);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_2453, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_2453, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_2453);
    }
  }
  case TAG_CBool: {
    V v_it_24103 = (g_heff_2ecompile_2eglue_2etyOf(heff_dup(v_t_241)));
    switch (heff_tag_of(v_it_24103)) {
    case TAG_SU: {
      heff_take_n(v_it_24103, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24105 = heff_field(v_it_24103, 0);
      heff_take_n(v_it_24103, 1ULL, 1);
      switch (heff_tag_of(v_it1_24105)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24107 = heff_field(v_it1_24105, 0);
        heff_take_n(v_it1_24105, 1ULL, 1);
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_g_24107, ((V)&g_heff_2ecompile_2eglue_2efits_str2), 2));
        heff_drop(v_g_24107);
        return v_ret_24bool;
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24105, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24105, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24105, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24105, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24105, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24105, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24105, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24105, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24105, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24105, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24105, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24105);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24103, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24103, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24103, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24103, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24103, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24103, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24103);
    }
  }
  case TAG_CString: {
    top_TAG_CString: ;
    V v_it_24153 = (g_heff_2ecompile_2eglue_2etyOf(heff_dup(v_t_241)));
    switch (heff_tag_of(v_it_24153)) {
    case TAG_SU: {
      heff_take_n(v_it_24153, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24155 = heff_field(v_it_24153, 0);
      heff_take_n(v_it_24153, 1ULL, 1);
      switch (heff_tag_of(v_it1_24155)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24157 = heff_field(v_it1_24155, 0);
        heff_take_n(v_it1_24155, 1ULL, 1);
        V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_g_24157, ((V)&g_heff_2ecompile_2eglue_2efits_str3), 2));
        heff_drop(v_g_24157);
        return v_ret_24bool;
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24155, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24155, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24155, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24155, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24155, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24155, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24155, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24155, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24155, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24155, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24155, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24155);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24153, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24153, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24153, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24153, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_True);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24153, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24153, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24153);
    }
  }
  case TAG_CText: {
    V t_0 = NTAG(TAG_CString);
    V t_1 = v_t_241;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    goto top_TAG_CString;
  }
  case TAG_COwnedString: {
    V t_0 = NTAG(TAG_CString);
    V t_1 = v_t_241;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    goto top_TAG_CString;
  }
  case TAG_CBytes: {
    top_TAG_CBytes: ;
    V v_it_24203 = (g_heff_2ecompile_2eglue_2etyOf(heff_dup(v_t_241)));
    switch (heff_tag_of(v_it_24203)) {
    case TAG_SU: {
      heff_take_n(v_it_24203, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24205 = heff_field(v_it_24203, 0);
      heff_take_n(v_it_24203, 1ULL, 1);
      switch (heff_tag_of(v_it1_24205)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24207 = heff_field(v_it1_24205, 0);
        heff_take_n(v_it1_24205, 1ULL, 1);
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_g_24207, ((V)&g_heff_2ecompile_2eglue_2efits_str4), 2));
        heff_drop(v_g_24207);
        return v_ret_24bool;
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24205, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24205, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24205, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24205, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24205, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24205, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24205, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24205, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24205, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24205, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24205, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24205);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24203, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24203, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24203, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24203, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24203, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24203, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24203);
    }
  }
  case TAG_COwnedBytes: {
    V t_0 = NTAG(TAG_CBytes);
    V t_1 = v_t_241;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    goto top_TAG_CBytes;
  }
  case TAG_CPointer: {
    V v_it_24255 = (g_heff_2ecompile_2eglue_2etyOf(heff_dup(v_t_241)));
    switch (heff_tag_of(v_it_24255)) {
    case TAG_SU: {
      heff_take_n(v_it_24255, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24257 = heff_field(v_it_24255, 0);
      heff_take_n(v_it_24255, 1ULL, 1);
      switch (heff_tag_of(v_it1_24257)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24259 = heff_field(v_it1_24257, 0);
        heff_take_n(v_it1_24257, 1ULL, 1);
        V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_g_24259, ((V)&g_heff_2ecompile_2eglue_2efits_str5), 2));
        heff_drop(v_g_24259);
        return v_ret_24bool;
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24257, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24257, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24257, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24257, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24257, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24257, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24257, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24257, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24257, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24257, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24257, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24257);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24255, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24255, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24255, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24255, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24255, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24255, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24255);
    }
  }
  case TAG_CVoid: {
    V v_it_24305 = (g_heff_2ecompile_2eglue_2etyOf(heff_dup(v_t_241)));
    switch (heff_tag_of(v_it_24305)) {
    case TAG_SU: {
      heff_take_n(v_it_24305, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SDecode: {
      V v_it1_24307 = heff_field(v_it_24305, 0);
      heff_take_n(v_it_24305, 1ULL, 1);
      switch (heff_tag_of(v_it1_24307)) {
      case TAG_SLocal: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SGlobal: {
        V v_g_24309 = heff_field(v_it1_24307, 0);
        heff_take_n(v_it1_24307, 1ULL, 1);
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_g_24309, ((V)&g_heff_2ecompile_2eglue_2efits_str6), 2));
        heff_drop(v_g_24309);
        return v_ret_24bool;
      }
      case TAG_SCode: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SApp: {
        heff_take_n(v_it1_24307, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLam: {
        heff_take_n(v_it1_24307, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SCons: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SProj: {
        heff_take_n(v_it1_24307, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_STag: {
        heff_take_n(v_it1_24307, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SMatch: {
        heff_take_n(v_it1_24307, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it1_24307, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SIs: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SOpaque: {
        return NTAG(TAG_True);
      }
      case TAG_SAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_SRec: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SFix: {
        heff_take_n(v_it1_24307, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it1_24307, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SPrim: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it1_24307, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitString: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitRune: {
        heff_take_n(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_it1_24307, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_it1_24307, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_it1_24307);
      }
    }
    case TAG_SFunction: {
      heff_take_n(v_it_24305, 0ULL, 5);
      return NTAG(TAG_True);
    }
    case TAG_SRecord: {
      heff_take_n(v_it_24305, 0ULL, 3);
      return NTAG(TAG_True);
    }
    case TAG_SSum: {
      heff_take_n(v_it_24305, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SIsTy: {
      heff_take_n(v_it_24305, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it_24305, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_SFixed: {
      heff_take_n(v_it_24305, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_it_24305);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2efits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eglue_2efits(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str3, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str4, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str5, 29, "const unsigned char * (bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str6, 32, "unsigned char * (malloc'd bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str7, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str8, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str9, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str10, 13, "`'s argument ");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str11, 18, " is described as `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str12, 18, "`, a result's type");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str13, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str14, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str15, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str16, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str17, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str18, 29, "const unsigned char * (bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str19, 32, "unsigned char * (malloc'd bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str20, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str21, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str22, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str23, 10, "`'s field ");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str24, 26, " cannot be given to C as `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eargBad_24cpr_str25, 1, "`");

HeffT2 g_heff_2ecompile_2eglue_2eargBad_24cpr(V v_tag_240, V v_i_241, V v_c_242, V v_t_243) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_c_242)) {
  case TAG_CInteger: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_CDouble: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_CBool: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_CString: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_CText: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_COwnedString: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_CBytes: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_COwnedBytes: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_CPointer: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_CVoid: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_2411;
    switch (heff_tag_of(v_c_242)) {
    case TAG_CInteger: {
      V v_t_248 = heff_field(v_c_242, 0);
      v_t_2411 = heff_dup(v_t_248);
      break;
    }
    case TAG_CDouble: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str0);
      break;
    }
    case TAG_CBool: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str1);
      break;
    }
    case TAG_CString: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str2);
      break;
    }
    case TAG_CText: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str4);
      break;
    }
    case TAG_CBytes: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str5);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str6);
      break;
    }
    case TAG_CPointer: {
      V v_t_249 = heff_field(v_c_242, 0);
      v_t_2411 = heff_strAppend(heff_dup(v_t_249), ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str7));
      break;
    }
    case TAG_CVoid: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str8);
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str9), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str10));
    V v_t_2413 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2413), ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str11));
    V v_f_2415 = heff_strAppend(heff_strAppend(v_t_2414, v_t_2411), ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str12));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
  } else {
    heff_drop(v_t_247);
    V v_t_2416 = (g_heff_2ecompile_2eglue_2efits(v_c_242, v_t_243));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_tag_240);
      heff_drop(v_i_241);
      heff_drop(v_t_2416);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      heff_drop(v_t_2416);
      V v_t_2420;
      switch (heff_tag_of(v_c_242)) {
      case TAG_CInteger: {
        V v_t_2417 = heff_field(v_c_242, 0);
        v_t_2420 = heff_dup(v_t_2417);
        break;
      }
      case TAG_CDouble: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str13);
        break;
      }
      case TAG_CBool: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str14);
        break;
      }
      case TAG_CString: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str15);
        break;
      }
      case TAG_CText: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str16);
        break;
      }
      case TAG_COwnedString: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str17);
        break;
      }
      case TAG_CBytes: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str18);
        break;
      }
      case TAG_COwnedBytes: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str19);
        break;
      }
      case TAG_CPointer: {
        V v_t_2418 = heff_field(v_c_242, 0);
        v_t_2420 = heff_strAppend(heff_dup(v_t_2418), ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str20));
        break;
      }
      case TAG_CVoid: {
        v_t_2420 = ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str21);
        break;
      }
      default: heff_nomatch(v_c_242);
      }
      V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str22), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str23));
      V v_t_2422 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
      V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2421, v_t_2422), ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str24));
      V v_f_2424 = heff_strAppend(heff_strAppend(v_t_2423, v_t_2420), ((V)&g_heff_2ecompile_2eglue_2eargBad_24cpr_str25));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
    }
  }
}

HeffT2 g_heff_2ecompile_2eglue_2eargsBad_24cpr(V v_tag_240, V v_i_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_242, 0);
    V v_cs_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_t_246 = heff_field(v_x4_243, 0);
      V v_ts_247 = heff_field(v_x4_243, 1);
      HeffT2 v_t_248 = (g_heff_2ecompile_2eglue_2eargBad_24cpr(heff_dup(v_tag_240), heff_dup(v_i_241), v_c_244, v_t_246));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          heff_drop(v_i_241);
          V v_m_2411 = v_field_2410;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_m_2411}});
        } else {
          heff_drop(v_field_2410);
          V t_0 = v_tag_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_cs_245;
          V t_3 = v_ts_247;
          v_tag_240 = t_0;
          v_i_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str3, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str4, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str5, 29, "const unsigned char * (bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str6, 32, "unsigned char * (malloc'd bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str7, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str8, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str9, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str10, 32, "`'s answer cannot be made of a `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str11, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str12, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str13, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str14, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str15, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str16, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str17, 29, "const unsigned char * (bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str18, 32, "unsigned char * (malloc'd bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str19, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str20, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str21, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str22, 72, "` answers with its last field as it is: its function gives `void`, not `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str23, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str24, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str25, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str26, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str27, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str28, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str29, 29, "const unsigned char * (bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str30, 32, "unsigned char * (malloc'd bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str31, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str32, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str33, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str34, 13, "`'s result, `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str35, 32, "`, cannot fail as `-1` or `NULL`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str36, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str37, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str38, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str39, 19, "const char * (text)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str40, 17, "char * (malloc'd)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str41, 29, "const unsigned char * (bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str42, 32, "unsigned char * (malloc'd bytes)");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str43, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str44, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str45, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str46, 33, "`'s `Right` cannot be made of a `");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str47, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str48, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str49, 65, "`'s answer is not an `Either Errno a`, as its result is described");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str50, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str51, 67, "` answers with its last field as it is: no `Either Errno a` to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str52, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str53, 68, "`'s answer is not an `Either Errno Unit`, as its result is described");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str54, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2eresultBad_24cpr_str55, 70, "` answers with its last field as it is: no `Either Errno Unit` to give");

HeffT2 g_heff_2ecompile_2eglue_2eresultBad_24cpr(V v_tag_240, V v_x2_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Gives: {
    V v_c_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SFunction: {
      V v_dom_245 = heff_field(v_t_242, 1);
      V v_t_249 = (g_heff_2ecompile_2eglue_2efits(v_c_243, v_dom_245));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_tag_240);
        heff_drop(v_c_243);
        heff_drop(v_t_249);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_249);
        V v_t_2413;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2410 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2413 = v_t_2410;
          break;
        }
        case TAG_CDouble: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str0);
          break;
        }
        case TAG_CBool: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str1);
          break;
        }
        case TAG_CString: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str2);
          break;
        }
        case TAG_CText: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str3);
          break;
        }
        case TAG_COwnedString: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str4);
          break;
        }
        case TAG_CBytes: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str5);
          break;
        }
        case TAG_COwnedBytes: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str6);
          break;
        }
        case TAG_CPointer: {
          V v_t_2411 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2413 = heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str7));
          break;
        }
        case TAG_CVoid: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str8);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str9), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str10));
        V v_f_2415 = heff_strAppend(heff_strAppend(v_t_2414, v_t_2413), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str11));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
      }
    }
    default: {
      switch (heff_tag_of(v_c_243)) {
      case TAG_CVoid: {
        heff_drop(v_tag_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: {
        V v_t_2419;
        switch (heff_tag_of(v_c_243)) {
        case TAG_CInteger: {
          V v_t_2416 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 1);
          v_t_2419 = v_t_2416;
          break;
        }
        case TAG_CDouble: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str12);
          break;
        }
        case TAG_CBool: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str13);
          break;
        }
        case TAG_CString: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str14);
          break;
        }
        case TAG_CText: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str15);
          break;
        }
        case TAG_COwnedString: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str16);
          break;
        }
        case TAG_CBytes: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str17);
          break;
        }
        case TAG_COwnedBytes: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str18);
          break;
        }
        case TAG_CPointer: {
          V v_t_2417 = heff_field(v_c_243, 0);
          heff_take_n(v_c_243, 1ULL, 2);
          v_t_2419 = heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str19));
          break;
        }
        case TAG_CVoid: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str20);
          break;
        }
        default: heff_nomatch(v_c_243);
        }
        V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str21), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str22));
        V v_f_2421 = heff_strAppend(heff_strAppend(v_t_2420, v_t_2419), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str23));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
      }
      }
    }
    }
  }
  case TAG_GivesOrErrno: {
    V v_c_2422 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24GivesOrErrno = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_SFunction: {
      V v_dom_2424 = heff_field(v_t_242, 1);
      V v_t_2431;
      switch (heff_tag_of(v_c_2422)) {
      case TAG_CInteger: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CDouble: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CBool: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      case TAG_CString: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CText: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_COwnedString: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CBytes: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_COwnedBytes: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CPointer: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_CVoid: {
        v_t_2431 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_c_2422);
      }
      if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_241_24GivesOrErrno, 1);
        heff_drop(v_t_2431);
        V v_t_2435;
        switch (heff_tag_of(v_c_2422)) {
        case TAG_CInteger: {
          V v_t_2432 = heff_field(v_c_2422, 0);
          heff_take_n(v_c_2422, 1ULL, 1);
          v_t_2435 = v_t_2432;
          break;
        }
        case TAG_CDouble: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str24);
          break;
        }
        case TAG_CBool: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str25);
          break;
        }
        case TAG_CString: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str26);
          break;
        }
        case TAG_CText: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str27);
          break;
        }
        case TAG_COwnedString: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str28);
          break;
        }
        case TAG_CBytes: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str29);
          break;
        }
        case TAG_COwnedBytes: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str30);
          break;
        }
        case TAG_CPointer: {
          V v_t_2433 = heff_field(v_c_2422, 0);
          heff_take_n(v_c_2422, 1ULL, 2);
          v_t_2435 = heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str31));
          break;
        }
        case TAG_CVoid: {
          v_t_2435 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str32);
          break;
        }
        default: heff_nomatch(v_c_2422);
        }
        V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str33), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str34));
        V v_f_2437 = heff_strAppend(heff_strAppend(v_t_2436, v_t_2435), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str35));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
      } else {
        heff_drop(v_t_2431);
        HeffT2 v_t_2438 = (g_heff_2ecompile_2eglue_2erightOf_24cpr(heff_dup(v_dom_2424)));
        {
          V v_field_2440 = v_t_2438.f[1];
          int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
          if ((v_tag_2439 == ((int64_t)0ULL))) {
            V v_r_2441 = heff_tag_at_n(v_ru_24x2_241_24GivesOrErrno, TAG_SDecode, 1, (V[]){v_field_2440});
            V v_t_2442 = ({ V a_0 = v_c_2422; V a_1 = v_r_2441; V r_ = (g_heff_2ecompile_2eglue_2efits(a_0, a_1)); heff_drop_tag(v_r_2441, 1); r_; });
            if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
              heff_drop(v_tag_240);
              heff_drop(v_c_2422);
              heff_drop(v_t_2442);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            } else {
              heff_drop(v_t_2442);
              V v_t_2446;
              switch (heff_tag_of(v_c_2422)) {
              case TAG_CInteger: {
                V v_t_2443 = heff_field(v_c_2422, 0);
                heff_take_n(v_c_2422, 1ULL, 1);
                v_t_2446 = v_t_2443;
                break;
              }
              case TAG_CDouble: {
                v_t_2446 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str36);
                break;
              }
              case TAG_CBool: {
                v_t_2446 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str37);
                break;
              }
              case TAG_CString: {
                v_t_2446 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str38);
                break;
              }
              case TAG_CText: {
                v_t_2446 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str39);
                break;
              }
              case TAG_COwnedString: {
                v_t_2446 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str40);
                break;
              }
              case TAG_CBytes: {
                v_t_2446 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str41);
                break;
              }
              case TAG_COwnedBytes: {
                v_t_2446 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str42);
                break;
              }
              case TAG_CPointer: {
                V v_t_2444 = heff_field(v_c_2422, 0);
                heff_take_n(v_c_2422, 1ULL, 2);
                v_t_2446 = heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str43));
                break;
              }
              case TAG_CVoid: {
                v_t_2446 = ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str44);
                break;
              }
              default: heff_nomatch(v_c_2422);
              }
              V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str45), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str46));
              V v_f_2448 = heff_strAppend(heff_strAppend(v_t_2447, v_t_2446), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str47));
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2448}});
            }
          } else {
            heff_drop(v_c_2422);
            heff_drop_cell(v_ru_24x2_241_24GivesOrErrno, 1);
            heff_drop(v_field_2440);
            V v_f_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str48), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str49));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2449}});
          }
        }
      }
    }
    default: {
      heff_drop(v_c_2422);
      heff_drop_cell(v_ru_24x2_241_24GivesOrErrno, 1);
      V v_f_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str50), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str51));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2450}});
    }
    }
  }
  case TAG_DoneOrErrno: {
    switch (heff_tag_of(v_t_242)) {
    case TAG_SFunction: {
      V v_dom_2452 = heff_field(v_t_242, 1);
      HeffT2 v_t_2456 = (g_heff_2ecompile_2eglue_2erightOf_24cpr(heff_dup(v_dom_2452)));
      {
        V v_field_2458 = v_t_2456.f[1];
        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
        if ((v_tag_2457 == ((int64_t)0ULL))) {
          heff_drop(v_tag_240);
          V v_r_2459 = heff_tag_n(TAG_SDecode, 1, (V[]){v_field_2458});
          heff_drop_tag(v_r_2459, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          heff_drop(v_field_2458);
          V v_f_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str52), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str53));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2460}});
        }
      }
    }
    default: {
      V v_f_2461 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str54), v_tag_240), ((V)&g_heff_2ecompile_2eglue_2eresultBad_24cpr_str55));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2461}});
    }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str0, 13, "ffi.Described");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str1, 8, "Describe");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str2, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str4, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str5, 36, "` is not a description heff can read");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str7, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str8, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str9, 24, "` could not be evaluated");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str10, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str11, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str12, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str13, 24, "` could not be evaluated");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str14, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str15, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str16, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2edescribedIn_str17, 24, "` could not be evaluated");
V g_heff_2ecompile_2eglue_2edescribedIn_lam0(V self, V *args); static Clo g_heff_2ecompile_2eglue_2edescribedIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2edescribedIn_lam0, 2, 0};
Clo g_heff_2ecompile_2eglue_2edescribedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2edescribedIn_entry, 2, 0};

V g_heff_2ecompile_2eglue_2edescribedIn(V v_g_240, V v_m_241) {
top: ;
  V v_it_242 = (g_heff_2ecompile_2eglue_2eofType(heff_dup(v_g_240), v_m_241, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str0)));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_243});
  }
  case TAG_Cons: {
    V v_t_246 = (g_heff_2ecompile_2einterp_2ereachGlobals(v_g_240, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_it_242)));
    V v_t_247 = ({ V a_0 = v_it_242; V a_1 = v_t_246; V a_2 = v_g_240; V r_ = (g_heff_2ecompile_2einterp_2eevalReachedIn(a_0, a_1, a_2)); heff_drop_tag(v_it_242, 2); heff_drop(v_t_246); r_; });
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return ({ V b_0 = ((V)&g_heff_2ecompile_2eglue_2edescribedIn_lam0_clo); V a_1 = heff_tag_n(TAG_Right, 1, (V[]){v_t_248}); V a_2 = v_t_247; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2ecompile_2eglue_2edescribedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eglue_2edescribedIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eglue_2edescribedIn_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_p_2410 = args[1];
  switch (heff_tag_of(v_acc_249)) {
  case TAG_Left: {
    V v_why_2411 = heff_field(v_acc_249, 0);
    V v_ru_24acc_249_24Left = heff_take_reuse_n(v_acc_249, 1ULL, 1);
    heff_drop(v_p_2410);
    return heff_tag_re_n(v_ru_24acc_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_why_2411});
  }
  case TAG_Right: {
    V v_it1_2412 = heff_field(v_acc_249, 0);
    V v_ru_24acc_249_24Right = heff_take_reuse_n(v_acc_249, 1ULL, 1);
    switch (heff_tag_of(v_it1_2412)) {
    case TAG_MkPair: {
      V v_incs_2413 = heff_field(v_it1_2412, 0);
      V v_ops_2414 = heff_field(v_it1_2412, 1);
      V v_ru_24it1_2412_24MkPair = heff_take_reuse_n(v_it1_2412, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_p_2410)) {
      case TAG_MkPair: {
        V v_y_2416 = heff_dup(heff_field(v_p_2410, 1));
        v_t_2417 = v_y_2416;
        break;
      }
      default: heff_nomatch(v_p_2410);
      }
      switch (heff_tag_of(v_t_2417)) {
      case TAG_RSucceeded: {
        V v_v_2418 = heff_field(v_t_2417, 0);
        V v_ru_24t_2417_24RSucceeded = heff_take_reuse_n(v_t_2417, 1ULL, 1);
        V v_x1_2419 = v_v_2418;
        V v_it_2455;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_VFun: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VTag: {
          V v_x11_2422 = heff_field(v_x1_2419, 0);
          V v_x12_2423 = heff_field(v_x1_2419, 1);
          heff_take_n(v_x1_2419, 3ULL, 2);
          if (heff_strEq_c(v_x11_2422, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str1))) {
            switch (heff_tag_of(v_x12_2423)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
              heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
              v_it_2455 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Cons: {
              V v_incs_2424 = heff_field(v_x12_2423, 0);
              V v_x122_2425 = heff_field(v_x12_2423, 1);
              heff_take_n(v_x12_2423, 3ULL, 2);
              switch (heff_tag_of(v_x122_2425)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
                heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
                heff_drop(v_incs_2424);
                v_it_2455 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Cons: {
                V v_ops_2426 = heff_field(v_x122_2425, 0);
                V v_x1222_2427 = heff_field(v_x122_2425, 1);
                heff_take_n(v_x122_2425, 3ULL, 2);
                switch (heff_tag_of(v_x1222_2427)) {
                case TAG_Nil: {
                  HeffT2 v_t_2428 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_incs_2424));
                  {
                    V v_field_2430 = v_t_2428.f[1];
                    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
                    if ((v_tag_2429 == ((int64_t)0ULL))) {
                      V v_x_2431 = v_field_2430;
                      HeffT2 v_t_2432 = (g_heff_2ecompile_2eglue_2eeachOf_24s231942830x1818376205_24cpr(v_x_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_is_2435 = v_field_2434;
                          HeffT2 v_t_2436 = (g_heff_2ecompile_2eglue_2elistOf_24cpr(v_ops_2426));
                          {
                            V v_field_2438 = v_t_2436.f[1];
                            int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
                            if ((v_tag_2437 == ((int64_t)0ULL))) {
                              V v_x_2439 = v_field_2438;
                              HeffT2 v_t_2440 = (g_heff_2ecompile_2eglue_2eeachOf_24s1899415673x1401347262_24cpr(v_x_2439));
                              {
                                V v_field_2442 = v_t_2440.f[1];
                                int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                                if ((v_tag_2441 == ((int64_t)0ULL))) {
                                  V v_os_2443 = v_field_2442;
                                  v_it_2455 = heff_tag_at_n(v_ru_24t_2417_24RSucceeded, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24it1_2412_24MkPair, TAG_MkPair, 2, (V[]){v_is_2435, v_os_2443})});
                                } else {
                                  heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
                                  heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
                                  heff_drop(v_is_2435);
                                  heff_drop(v_field_2442);
                                  v_it_2455 = NTAG(TAG_Nothing);
                                }
                              }
                            } else {
                              heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
                              heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
                              heff_drop(v_is_2435);
                              heff_drop(v_field_2438);
                              v_it_2455 = NTAG(TAG_Nothing);
                            }
                          }
                        } else {
                          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
                          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
                          heff_drop(v_ops_2426);
                          heff_drop(v_field_2434);
                          v_it_2455 = NTAG(TAG_Nothing);
                        }
                      }
                    } else {
                      heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
                      heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
                      heff_drop(v_ops_2426);
                      heff_drop(v_field_2430);
                      v_it_2455 = NTAG(TAG_Nothing);
                    }
                  }
                  break;
                }
                case TAG_Cons: {
                  heff_take_n(v_x1222_2427, 0ULL, 2);
                  heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
                  heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
                  heff_drop(v_incs_2424);
                  heff_drop(v_ops_2426);
                  v_it_2455 = NTAG(TAG_Nothing);
                  break;
                }
                default: heff_nomatch(v_x1222_2427);
                }
                break;
              }
              default: heff_nomatch(v_x122_2425);
              }
              break;
            }
            default: heff_nomatch(v_x12_2423);
            }
          } else {
            heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
            heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
            heff_drop(v_x12_2423);
            v_it_2455 = NTAG(TAG_Nothing);
          }
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VStr: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x1_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x1_2419, 0ULL, 2);
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
          heff_drop_cell(v_ru_24t_2417_24RSucceeded, 1);
          v_it_2455 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        switch (heff_tag_of(v_it_2455)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24acc_249_24Right, 1);
          heff_drop(v_incs_2413);
          heff_drop(v_ops_2414);
          V v_k_2458;
          switch (heff_tag_of(v_p_2410)) {
          case TAG_MkPair: {
            V v_x_2456 = heff_field(v_p_2410, 0);
            heff_take_n(v_p_2410, 1ULL, 2);
            v_k_2458 = v_x_2456;
            break;
          }
          default: heff_nomatch(v_p_2410);
          }
          V v_t_2459 = (g_prelude_2esplit_2esplitFrom_240(v_k_2458, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str2), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str3), v_k_2458, MK_INT(0LL), 5), NTAG(TAG_Nil)));
          V v_t_2460 = ({ V a_0 = v_k_2458; V a_1 = v_t_2459; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2458); heff_drop(v_t_2459); r_; });
          V v_t_2461 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str4), v_t_2460), ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str5));
          return heff_tag_n(TAG_Left, 1, (V[]){v_t_2461});
        }
        case TAG_Just: {
          V v_it1_2462 = heff_field(v_it_2455, 0);
          heff_take_n(v_it_2455, 1ULL, 1);
          heff_drop(v_p_2410);
          switch (heff_tag_of(v_it1_2462)) {
          case TAG_MkPair: {
            V v_is_2463 = heff_field(v_it1_2462, 0);
            V v_os_2464 = heff_field(v_it1_2462, 1);
            V v_ru_24it1_2462_24MkPair = heff_take_reuse_n(v_it1_2462, 3ULL, 2);
            V v_t_2465 = (g_heff_2ecompile_2eglue_2eappendF(v_incs_2413, v_is_2463));
            V v_t_2466 = (g_heff_2ecompile_2eglue_2eappendF(v_ops_2414, v_os_2464));
            return heff_tag_at_n(v_ru_24acc_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24it1_2462_24MkPair, TAG_MkPair, 2, (V[]){v_t_2465, v_t_2466})});
          }
          default: return heff_nomatch(v_it1_2462);
          }
        }
        default: return heff_nomatch(v_it_2455);
        }
      }
      case TAG_RAbandoned: {
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
        V v_k_2469;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2467 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2469 = v_x_2467;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2470 = (g_prelude_2esplit_2esplitFrom_240(v_k_2469, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str6), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str7), v_k_2469, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2471 = ({ V a_0 = v_k_2469; V a_1 = v_t_2470; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2469); heff_drop(v_t_2470); r_; });
        V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str8), v_t_2471), ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str9));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2472});
      }
      case TAG_RDiverged: {
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
        V v_k_2475;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2473 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2475 = v_x_2473;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2476 = (g_prelude_2esplit_2esplitFrom_240(v_k_2475, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str10), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str11), v_k_2475, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2477 = ({ V a_0 = v_k_2475; V a_1 = v_t_2476; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2475); heff_drop(v_t_2476); r_; });
        V v_t_2478 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str12), v_t_2477), ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str13));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2478});
      }
      case TAG_RBug: {
        V v_ru_24t_2417_24RBug = heff_take_reuse_n(v_t_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24acc_249_24Right, 1);
        heff_drop(v_incs_2413);
        heff_drop(v_ops_2414);
        heff_drop_cell(v_ru_24it1_2412_24MkPair, 2);
        V v_k_2482;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_x_2480 = heff_field(v_p_2410, 0);
          heff_take_n(v_p_2410, 1ULL, 2);
          v_k_2482 = v_x_2480;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        V v_t_2483 = (g_prelude_2esplit_2esplitFrom_240(v_k_2482, ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str14), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str15), v_k_2482, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2484 = ({ V a_0 = v_k_2482; V a_1 = v_t_2483; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2482); heff_drop(v_t_2483); r_; });
        V v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2edescribedIn_str16), v_t_2484), ((V)&g_heff_2ecompile_2eglue_2edescribedIn_str17));
        return heff_tag_at_n(v_ru_24t_2417_24RBug, TAG_Left, 1, (V[]){v_t_2485});
      }
      default: return heff_nomatch(v_t_2417);
      }
    }
    default: return heff_nomatch(v_it1_2412);
    }
  }
  default: return heff_nomatch(v_acc_249);
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str3, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str4, 11, "co.HFunctor");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str5, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str8, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str9, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str10, 38, "` is not an operation of an effect of ");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str11, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str12, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str13, 19, "the operations of `");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str14, 46, "` cannot be read: not an effect of a data type");
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2eglue_2ebindingsOf_24cpr(V v_g_240, V v_k_241, V v_ops_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(heff_dup(v_g_240), v_k_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_vs_246 = v_field_245;
      V v_byName_247 = heff_take_field(v_vs_246, 1);
      V v_values_248 = heff_get_n(v_vs_246, 2, 3);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ops_242));
      V v_t_2445 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0, 2, 4, (V[]){v_byName_247, v_values_248, heff_dup(v_k_241), v_g_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_249); r_; });
      return (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2445));
    } else {
      heff_drop(v_g_240);
      heff_drop(v_ops_242);
      heff_drop(v_field_245);
      V v_t_2446 = (g_prelude_2esplit_2esplitFrom_240(v_k_241, ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str11), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str12), v_k_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
      V v_t_2447 = ({ V a_0 = v_k_241; V a_1 = v_t_2446; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2446); r_; });
      V v_f_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str13), v_t_2447), ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str14));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2448}});
    }
  }
}
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1(V self, V *args) {
  V v_k_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2426 = ({ V a_0 = v_g_240; V a_1 = v_k_2425; HeffT2 r_ = (g_heff_2ecompile_2eglue_2eoperationsOf_24cpr(a_0, a_1)); heff_drop(v_k_2425); r_; });
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    if ((v_tag_2427 == ((int64_t)0ULL))) {
      V v_vs_2429 = v_field_2428;
      HeffT2 v_t_2430 = ({ V b_0 = heff_get_n(v_vs_2429, 1, 3); V b_1 = heff_get_n(v_x_2411, 0, 4); HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        V v_ret_24bool = heff_bool(((v_tag_2431 == ((int64_t)0ULL)) && ({ V v_x_2433 = heff_dup(v_field_2432); int c_ = 1; heff_drop(v_x_2433); c_; })));
        heff_drop(v_field_2432);
        return v_ret_24bool;
      }
    } else {
      heff_drop_rec(v_x_2411, 4);
      heff_drop(v_field_2428);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_byName_247 = heff_env(self)[0];
  V v_values_248 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2412 = ({ V a_0 = v_byName_247; V a_1 = heff_rfield(v_x_2411, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_247); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    V v_t_2418;
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_i_2415 = v_field_2414;
      V v_xs_2416 = v_values_248;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2415, 1) && heff_intLt_c_lent(v_i_2415, heff_arrayLength_lent(v_xs_2416, 0), 2))) {
        V v_t_2417 = heff_arrayIndex(v_xs_2416, v_i_2415);
        v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
      } else {
        heff_drop(v_i_2415);
        heff_drop(v_xs_2416);
        v_t_2418 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_values_248);
      heff_drop(v_field_2414);
      v_t_2418 = NTAG(TAG_Nothing);
    }
    V v_t_2444;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      V v_t_2419 = (g_prelude_2esplit_2esplitFrom_240(v_k_241, ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str1), v_k_241, MK_INT(0LL), 5), NTAG(TAG_Nil)));
      V v_x2_2420 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2419));
      V v_m_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_m_2423 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_m_2423 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str3); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_t_2424 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_m_2423; V a_2 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str4); V r_ = (g_heff_2ecompile_2eglue_2eofType(a_0, a_1, a_2)); heff_drop(v_m_2423); r_; });
      V v_t_2434 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_lam1, 1, 2, (V[]){v_g_240, heff_dup(v_x_2411)}); V a_1 = v_t_2424; V r_ = (g_list_2eany(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2424); r_; });
      if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2411, 4);
        heff_drop(v_k_241);
        heff_drop(v_t_2434);
        v_t_2444 = NTAG(TAG_Nil);
      } else {
        heff_drop(v_t_2434);
        V v_t_2435 = ({ V a_0 = v_k_241; V a_1 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str5); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str6), v_k_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_241); r_; });
        V v_x2_2436 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2435));
        V v_t_2439;
        switch (heff_tag_of(v_x2_2436)) {
        case TAG_Nil: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2437 = heff_field(v_x2_2436, 0);
          V v_xs_2438 = heff_field(v_x2_2436, 1);
          heff_take_n(v_x2_2436, 3ULL, 2);
          v_t_2439 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str8); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2436);
        }
        V v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str9), heff_get_n(v_x_2411, 0, 4));
        V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eglue_2ebindingsOf_24cpr_str10)), v_t_2439);
        v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2441}), NTAG(TAG_Nil)});
      }
      break;
    }
    case TAG_Just: {
      V v_fields_2442 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      heff_drop(v_k_241);
      heff_drop(v_g_240);
      V v_t_2443 = (g_heff_2ecompile_2eglue_2ebindingOf(v_x_2411, v_fields_2442));
      v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    return (g_prelude_2e_2b_2b(v_t_2444, v_acc_2410));
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str0, 9, "ffi.Links");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str1, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str2, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str4, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str5, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str6, 50, "` is not a name of a package, library or framework");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str7, 2, ": ");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str8, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str9, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str11, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str12, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str13, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str14, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str15, 36, "` is not a description heff can read");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str16, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str17, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str19, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str20, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str21, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str22, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str23, 24, "` could not be evaluated");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str24, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str25, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str27, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str28, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str29, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str30, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str31, 24, "` could not be evaluated");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str32, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str33, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str35, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str36, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str37, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str38, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eglue_2elinksIn_24cpr_str39, 24, "` could not be evaluated");
V g_heff_2ecompile_2eglue_2elinksIn_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eglue_2elinksIn_24cpr_lam1(V self, V *args); static Clo g_heff_2ecompile_2eglue_2elinksIn_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2elinksIn_24cpr_lam1, 1, 0};

HeffT2 g_heff_2ecompile_2eglue_2elinksIn_24cpr(V v_g_240) {
top: ;
  V v_t_247 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2eglue_2elinksIn_24cpr_lam0, 2, 1, (V[]){heff_dup(v_g_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = heff_rfield(v_g_240, 0); V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_248 = (g_list_2ekeepIf_24s1190092672x1539603713(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str0), v_t_247));
  V v_it_249 = (g_list_2emap_24s1937570095x2110149801(v_t_248));
  switch (heff_tag_of(v_it_249)) {
  case TAG_Nil: {
    heff_drop_rec(v_g_240, 8);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_t_2412 = (g_heff_2ecompile_2einterp_2ereachGlobals(v_g_240, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_it_249)));
    V v_t_2413 = ({ V a_0 = v_it_249; V a_1 = v_t_2412; V a_2 = v_g_240; V r_ = (g_heff_2ecompile_2einterp_2eevalReachedIn(a_0, a_1, a_2)); heff_drop_tag(v_it_249, 2); heff_drop(v_t_2412); r_; });
    V v_t_2494 = (g_list_2emap(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_lam1_clo), v_t_2413));
    HEFF_LAST return g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2494);
  }
  default: return ((HeffT2){{heff_nomatch(v_it_249)}});
  }
}
V g_heff_2ecompile_2eglue_2elinksIn_24cpr_lam0(V self, V *args) {
  V v_acc_241 = args[0];
  V v_k_242 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_e_246 = v_field_245;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_e_246}), v_acc_241});
    } else {
      heff_drop(v_k_242);
      heff_drop(v_field_245);
      return v_acc_241;
    }
  }
}
V g_heff_2ecompile_2eglue_2elinksIn_24cpr_lam1(V self, V *args) {
  V v_p_2414 = args[0];
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_dup(heff_field(v_p_2414, 1));
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_RSucceeded: {
    V v_v_2418 = heff_field(v_t_2417, 0);
    V v_ru_24t_2417_24RSucceeded = heff_take_reuse_n(v_t_2417, 1ULL, 1);
    HeffT2 v_t_2419 = ({ V a_0 = v_v_2418; HeffT2 r_ = (g_heff_2ecompile_2eglue_2ereadLinks_24cpr(a_0)); heff_drop(v_v_2418); r_; });
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_l_2422 = v_field_2421;
        V v_t_2423 = (g_heff_2ecompile_2eglue_2eappendF(heff_dup(heff_rfield(v_l_2422, 1)), heff_dup(heff_rfield(v_l_2422, 2))));
        V v_t_2424 = ({ V a_0 = heff_dup(heff_rfield(v_l_2422, 0)); V a_1 = v_t_2423; V r_ = (g_list_2ekeepIf_24f1428084847x1450173891(a_0, a_1)); heff_drop(v_t_2423); r_; });
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nil: {
          heff_drop(v_p_2414);
          return heff_tag_at_n(v_ru_24t_2417_24RSucceeded, TAG_Right, 1, (V[]){v_l_2422});
        }
        case TAG_Cons: {
          V v_n_2425 = heff_field(v_t_2424, 0);
          heff_take_n(v_t_2424, 1ULL, 2);
          heff_drop_rec(v_l_2422, 3);
          V v_k_2429;
          switch (heff_tag_of(v_p_2414)) {
          case TAG_MkPair: {
            V v_x_2427 = heff_field(v_p_2414, 0);
            heff_take_n(v_p_2414, 1ULL, 2);
            v_k_2429 = v_x_2427;
            break;
          }
          default: heff_nomatch(v_p_2414);
          }
          V v_t_2430 = ({ V a_0 = v_k_2429; V a_1 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str2), v_k_2429, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_2429); r_; });
          V v_x2_2431 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2430));
          V v_t_2434;
          switch (heff_tag_of(v_x2_2431)) {
          case TAG_Nil: {
            v_t_2434 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str3);
            break;
          }
          case TAG_Cons: {
            V v_x_2432 = heff_field(v_x2_2431, 0);
            V v_xs_2433 = heff_field(v_x2_2431, 1);
            heff_take_n(v_x2_2431, 3ULL, 2);
            v_t_2434 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str4); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2431);
          }
          V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str5), v_n_2425), ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str6));
          V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str7)), v_t_2435);
          return heff_tag_at_n(v_ru_24t_2417_24RSucceeded, TAG_Left, 1, (V[]){v_t_2436});
        }
        default: return heff_nomatch(v_t_2424);
        }
      } else {
        heff_drop(v_field_2421);
        V v_k_2439;
        switch (heff_tag_of(v_p_2414)) {
        case TAG_MkPair: {
          V v_x_2437 = heff_dup(heff_field(v_p_2414, 0));
          v_k_2439 = v_x_2437;
          break;
        }
        default: heff_nomatch(v_p_2414);
        }
        V v_t_2440 = ({ V a_0 = v_k_2439; V a_1 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str8); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str9), v_k_2439, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_2439); r_; });
        V v_x2_2441 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2440));
        V v_t_2444;
        switch (heff_tag_of(v_x2_2441)) {
        case TAG_Nil: {
          v_t_2444 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str10);
          break;
        }
        case TAG_Cons: {
          V v_x_2442 = heff_field(v_x2_2441, 0);
          V v_xs_2443 = heff_field(v_x2_2441, 1);
          heff_take_n(v_x2_2441, 3ULL, 2);
          v_t_2444 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str11); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2441);
        }
        V v_k_2447;
        switch (heff_tag_of(v_p_2414)) {
        case TAG_MkPair: {
          V v_x_2445 = heff_field(v_p_2414, 0);
          heff_take_n(v_p_2414, 1ULL, 2);
          v_k_2447 = v_x_2445;
          break;
        }
        default: heff_nomatch(v_p_2414);
        }
        V v_t_2448 = (g_prelude_2esplit_2esplitFrom_240(v_k_2447, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str12), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str13), v_k_2447, MK_INT(0LL), 5), NTAG(TAG_Nil)));
        V v_t_2449 = ({ V a_0 = v_k_2447; V a_1 = v_t_2448; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2447); heff_drop(v_t_2448); r_; });
        V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str14)), v_t_2449);
        return heff_tag_at_n(v_ru_24t_2417_24RSucceeded, TAG_Left, 1, (V[]){heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str15))});
      }
    }
  }
  case TAG_RAbandoned: {
    V v_k_2453;
    switch (heff_tag_of(v_p_2414)) {
    case TAG_MkPair: {
      V v_x_2451 = heff_dup(heff_field(v_p_2414, 0));
      v_k_2453 = v_x_2451;
      break;
    }
    default: heff_nomatch(v_p_2414);
    }
    V v_t_2454 = ({ V a_0 = v_k_2453; V a_1 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str16); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str17), v_k_2453, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_2453); r_; });
    V v_x2_2455 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2454));
    V v_t_2458;
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_Nil: {
      v_t_2458 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_xs_2457 = heff_field(v_x2_2455, 1);
      heff_take_n(v_x2_2455, 3ULL, 2);
      v_t_2458 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str19); V a_1 = v_x_2456; V a_2 = v_xs_2457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2457); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2455);
    }
    V v_k_2461;
    switch (heff_tag_of(v_p_2414)) {
    case TAG_MkPair: {
      V v_x_2459 = heff_field(v_p_2414, 0);
      heff_take_n(v_p_2414, 1ULL, 2);
      v_k_2461 = v_x_2459;
      break;
    }
    default: heff_nomatch(v_p_2414);
    }
    V v_t_2462 = (g_prelude_2esplit_2esplitFrom_240(v_k_2461, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str20), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str21), v_k_2461, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_t_2463 = ({ V a_0 = v_k_2461; V a_1 = v_t_2462; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2461); heff_drop(v_t_2462); r_; });
    V v_t_2464 = heff_strAppend(heff_strAppend(v_t_2458, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str22)), v_t_2463);
    return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str23))});
  }
  case TAG_RDiverged: {
    V v_k_2467;
    switch (heff_tag_of(v_p_2414)) {
    case TAG_MkPair: {
      V v_x_2465 = heff_dup(heff_field(v_p_2414, 0));
      v_k_2467 = v_x_2465;
      break;
    }
    default: heff_nomatch(v_p_2414);
    }
    V v_t_2468 = ({ V a_0 = v_k_2467; V a_1 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str24); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str25), v_k_2467, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_2467); r_; });
    V v_x2_2469 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2468));
    V v_t_2472;
    switch (heff_tag_of(v_x2_2469)) {
    case TAG_Nil: {
      v_t_2472 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str26);
      break;
    }
    case TAG_Cons: {
      V v_x_2470 = heff_field(v_x2_2469, 0);
      V v_xs_2471 = heff_field(v_x2_2469, 1);
      heff_take_n(v_x2_2469, 3ULL, 2);
      v_t_2472 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str27); V a_1 = v_x_2470; V a_2 = v_xs_2471; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2471); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2469);
    }
    V v_k_2475;
    switch (heff_tag_of(v_p_2414)) {
    case TAG_MkPair: {
      V v_x_2473 = heff_field(v_p_2414, 0);
      heff_take_n(v_p_2414, 1ULL, 2);
      v_k_2475 = v_x_2473;
      break;
    }
    default: heff_nomatch(v_p_2414);
    }
    V v_t_2476 = (g_prelude_2esplit_2esplitFrom_240(v_k_2475, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str28), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str29), v_k_2475, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_t_2477 = ({ V a_0 = v_k_2475; V a_1 = v_t_2476; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2475); heff_drop(v_t_2476); r_; });
    V v_t_2478 = heff_strAppend(heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str30)), v_t_2477);
    return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_t_2478, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str31))});
  }
  case TAG_RBug: {
    V v_ru_24t_2417_24RBug = heff_take_reuse_n(v_t_2417, 0ULL, 1);
    V v_k_2482;
    switch (heff_tag_of(v_p_2414)) {
    case TAG_MkPair: {
      V v_x_2480 = heff_dup(heff_field(v_p_2414, 0));
      v_k_2482 = v_x_2480;
      break;
    }
    default: heff_nomatch(v_p_2414);
    }
    V v_t_2483 = ({ V a_0 = v_k_2482; V a_1 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str32); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str33), v_k_2482, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_k_2482); r_; });
    V v_x2_2484 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_2483));
    V v_t_2487;
    switch (heff_tag_of(v_x2_2484)) {
    case TAG_Nil: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str34);
      break;
    }
    case TAG_Cons: {
      V v_x_2485 = heff_field(v_x2_2484, 0);
      V v_xs_2486 = heff_field(v_x2_2484, 1);
      heff_take_n(v_x2_2484, 3ULL, 2);
      v_t_2487 = ({ V a_0 = ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str35); V a_1 = v_x_2485; V a_2 = v_xs_2486; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2486); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2484);
    }
    V v_k_2490;
    switch (heff_tag_of(v_p_2414)) {
    case TAG_MkPair: {
      V v_x_2488 = heff_field(v_p_2414, 0);
      heff_take_n(v_p_2414, 1ULL, 2);
      v_k_2490 = v_x_2488;
      break;
    }
    default: heff_nomatch(v_p_2414);
    }
    V v_t_2491 = (g_prelude_2esplit_2esplitFrom_240(v_k_2490, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str36), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str37), v_k_2490, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_t_2492 = ({ V a_0 = v_k_2490; V a_1 = v_t_2491; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_k_2490); heff_drop(v_t_2491); r_; });
    V v_t_2493 = heff_strAppend(heff_strAppend(v_t_2487, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str38)), v_t_2492);
    return heff_tag_at_n(v_ru_24t_2417_24RBug, TAG_Left, 1, (V[]){heff_strAppend(v_t_2493, ((V)&g_heff_2ecompile_2eglue_2elinksIn_24cpr_str39))});
  }
  default: return heff_nomatch(v_t_2417);
  }
}