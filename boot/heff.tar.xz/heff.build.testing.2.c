// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Close 2276
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_GetEnv 43934
#define TAG_Holds 53574
#define TAG_Inherited 58190
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_NotRun 12703
#define TAG_Open 48267
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Processors 11008
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_fuel 9649789
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_jobs 9763101
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_outcome 1272833429
#define LBL_output 941629484
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_pattern 1588251091
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_update 1108295668
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__launch__place__top__path__limit[] = {LBL_owner, LBL_launch, LBL_place, LBL_top, LBL_path, LBL_limit};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_seed__pattern__jobs__update__fuel[] = {LBL_seed, LBL_pattern, LBL_jobs, LBL_update, LBL_fuel};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo;
V g_heff_2ebuild_2etesting_2ebrokenJob(V, V);
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo;
HeffT3 g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_clo;
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1_clo;
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_clo;
V g_heff_2ebuild_2etesting_2egoldenPath(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenPath_clo;
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652(V, V, V);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_clo;
V g_heff_2ebuild_2etesting_2eintegrationMainName_get(void);
V g_heff_2ebuild_2etesting_2ejsonFailure(V);
V g_heff_2ebuild_2etesting_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_clo;
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1(V, V);
V g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ejsonFailure_24tok1_clo;
V g_heff_2ebuild_2etesting_2elevelsSelected(V, V);
V g_heff_2ebuild_2etesting_2elevelsSelected_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elevelsSelected_clo;
V g_heff_2ebuild_2etesting_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2etesting_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2etesting_2ereportReady_24s1724891461x265292388(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2ereportReady_24s1724891461x265292388_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ereportReady_24s1724891461x265292388_clo;
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689_clo;
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_clo;
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo;
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_clo;
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_2ek_24l0_clo;
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_clo;
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_clo;
V g_heff_2ebuild_2etesting_2etestsHeld(V, V, V);
V g_heff_2ebuild_2etesting_2etestsHeld_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestsHeld_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eall_24s1461376987x321850093(V);
V g_list_2eall_24s1461376987x321850093_entry(V self, V *a);
extern Clo g_list_2eall_24s1461376987x321850093_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s344878118x1065108086(V, V, V);
V g_list_2efoldl_24s344878118x1065108086_entry(V self, V *a);
extern Clo g_list_2efoldl_24s344878118x1065108086_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1113395621x248103432(V);
V g_list_2emap_24s1113395621x248103432_entry(V self, V *a);
extern Clo g_list_2emap_24s1113395621x248103432_clo;
V g_list_2emap_24s2029356170x1054793697(V);
V g_list_2emap_24s2029356170x1054793697_entry(V self, V *a);
extern Clo g_list_2emap_24s2029356170x1054793697_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2einstanceDebugString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceDebugString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceDebugString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2elevelsOf_2ecut_240(V, V, V, V, V, V);
V g_regex_2elevelsOf_2ecut_240_entry(V self, V *a);
extern Clo g_regex_2elevelsOf_2ecut_240_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s647691963x1626449320(V, V, V);
V g_std_2eprocess_2ewithProcess_24s647691963x1626449320_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s647691963x1626449320_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str3, 0, "");

HeffT3 g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(V v_n_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_245;
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_l_243 = heff_field(v_x2_241, 0);
      v_t_245 = heff_dup(v_l_243);
      break;
    }
    default: heff_nomatch(v_x2_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str1);
      break;
    }
    case TAG_Cons: {
      V v_l_246 = heff_field(v_x3_242, 0);
      v_t_248 = heff_dup(v_l_246);
      break;
    }
    default: heff_nomatch(v_x3_242);
    }
    return ((HeffT3){{v_n_240, v_t_245, v_t_248}});
  }
  case TAG_Cons: {
    V v_a_249 = heff_field(v_x2_241, 0);
    V v_argv_2410 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      V v_t_2413;
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str2);
        break;
      }
      case TAG_Cons: {
        V v_l_2411 = heff_field(v_x2_241, 0);
        v_t_2413 = heff_dup(v_l_2411);
        break;
      }
      default: heff_nomatch(v_x2_241);
      }
      V v_t_2416;
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        v_t_2416 = ((V)&g_heff_2ebuild_2etesting_2efirstDiffering_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_l_2414 = heff_field(v_x3_242, 0);
        v_t_2416 = heff_dup(v_l_2414);
        break;
      }
      default: heff_nomatch(v_x3_242);
      }
      return ((HeffT3){{v_n_240, v_t_2413, v_t_2416}});
    }
    case TAG_Cons: {
      V v_b_2417 = heff_field(v_x3_242, 0);
      V v_bs_2418 = heff_field(v_x3_242, 1);
      if (heff_strEq_c_lent(v_a_249, v_b_2417, 0)) {
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_argv_2410;
        V t_2 = v_bs_2418;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        return ((HeffT3){{v_n_240, heff_dup(v_a_249), heff_dup(v_b_2417)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eintegrationMainName_str0, 20, "heffTestIntegrations");

static V g_heff_2ebuild_2etesting_2eintegrationMainName_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eintegrationMainName_st;
static V g_heff_2ebuild_2etesting_2eintegrationMainName_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eintegrationMainName_str0);
}
V g_heff_2ebuild_2etesting_2eintegrationMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eintegrationMainName_st)) return g_heff_2ebuild_2etesting_2eintegrationMainName_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eintegrationMainName_val, &g_heff_2ebuild_2etesting_2eintegrationMainName_st, g_heff_2ebuild_2etesting_2eintegrationMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2ejsonFailure_str13, 0, "");
Clo g_heff_2ebuild_2etesting_2ejsonFailure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ejsonFailure_entry, 1, 0};

V g_heff_2ebuild_2etesting_2ejsonFailure(V v_j_240) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_j_240)) {
  case TAG_JNull: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_246 = heff_dup(heff_field(v_j_240, 0));
    HeffT2 v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str0); V a_1 = v_fs_246; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_246); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_p_2410 = v_field_249;
        V v_t_2413;
        switch (heff_tag_of(v_p_2410)) {
        case TAG_MkPair: {
          V v_y_2412 = heff_field(v_p_2410, 1);
          heff_take_n(v_p_2410, 2ULL, 2);
          v_t_2413 = v_y_2412;
          break;
        }
        default: heff_nomatch(v_p_2410);
        }
        switch (heff_tag_of(v_t_2413)) {
        case TAG_JNull: {
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2417 = heff_field(v_t_2413, 0);
          V v_ru_24t_2413_24JString = heff_take_reuse_n(v_t_2413, 1ULL, 1);
          v_t_2420 = heff_tag_at_n(v_ru_24t_2413_24JString, TAG_Just, 1, (V[]){v_s_2417});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2413, 0ULL, 1);
          v_t_2420 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2420 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_j_240)) {
    case TAG_JNull: {
      return NTAG(TAG_Nothing);
    }
    case TAG_JBool: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JInt: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JFloat: {
      heff_take_na(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JString: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JArray: {
      heff_take_n(v_j_240, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_JObject: {
      V v_fs_2426 = heff_field(v_j_240, 0);
      V v_ru_24j_240_24JObject = heff_take_reuse_n(v_j_240, 1ULL, 1);
      HeffT2 v_t_2427 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str1); V a_1 = v_fs_2426; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2426); r_; });
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_p_2430 = v_field_2429;
          V v_t_2433;
          switch (heff_tag_of(v_p_2430)) {
          case TAG_MkPair: {
            V v_y_2432 = heff_field(v_p_2430, 1);
            heff_take_n(v_p_2430, 2ULL, 2);
            v_t_2433 = v_y_2432;
            break;
          }
          default: heff_nomatch(v_p_2430);
          }
          switch (heff_tag_of(v_t_2433)) {
          case TAG_JNull: {
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2438 = heff_field(v_t_2433, 0);
            heff_take_n(v_t_2433, 1ULL, 1);
            switch (heff_tag_of(v_xs_2438)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24j_240_24JObject, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2439 = heff_field(v_xs_2438, 0);
              V v_it12_2440 = heff_field(v_xs_2438, 1);
              V v_ru_24xs_2438_24Cons = heff_take_reuse_n(v_xs_2438, 3ULL, 2);
              switch (heff_tag_of(v_it12_2440)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24j_240_24JObject, 1);
                heff_drop(v_expected_2439);
                heff_drop_cell(v_ru_24xs_2438_24Cons, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2441 = heff_field(v_it12_2440, 0);
                heff_take_n(v_it12_2440, 1ULL, 2);
                V v_t_2449;
                switch (heff_tag_of(v_expected_2439)) {
                case TAG_JNull: {
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2446 = heff_field(v_expected_2439, 0);
                  heff_take_n(v_expected_2439, 1ULL, 1);
                  v_t_2449 = v_t_2446;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2439, 0ULL, 1);
                  v_t_2449 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2439);
                }
                V v_t_2456;
                switch (heff_tag_of(v_got_2441)) {
                case TAG_JNull: {
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2453 = heff_field(v_got_2441, 0);
                  heff_take_n(v_got_2441, 1ULL, 1);
                  v_t_2456 = v_t_2453;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2441, 0ULL, 1);
                  v_t_2456 = ((V)&g_heff_2ebuild_2etesting_2ejsonFailure_str13);
                  break;
                }
                default: heff_nomatch(v_got_2441);
                }
                return heff_tag_at_n(v_ru_24j_240_24JObject, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24xs_2438_24Cons, TAG_FailDiffer, 2, (V[]){v_t_2449, v_t_2456})});
              }
              default: return heff_nomatch(v_it12_2440);
              }
            }
            default: return heff_nomatch(v_xs_2438);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_t_2433, 0ULL, 1);
            heff_drop_cell(v_ru_24j_240_24JObject, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2433);
          }
        } else {
          heff_drop_cell(v_ru_24j_240_24JObject, 1);
          heff_drop(v_field_2429);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_j_240);
    }
  }
  case TAG_Just: {
    V v_why_2458 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Just = heff_take_reuse_n(v_t_2420, 1ULL, 1);
    heff_drop(v_j_240);
    return heff_tag_at_n(v_ru_24t_2420_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2458})});
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ebuild_2etesting_2ejsonFailure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ejsonFailure(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str0, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str2, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str3, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeOfJson_str4, 7, "goldens");
Clo g_heff_2ebuild_2etesting_2eoutcomeOfJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry, 2, 0};

V g_heff_2ebuild_2etesting_2eoutcomeOfJson(V v_name_240, V v_j_241) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JBool: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JInt: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JFloat: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JString: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JArray: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_JObject: {
    V v_fs_247 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str0); V a_1 = v_fs_247; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_247); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2411 = v_field_2410;
        V v_t_2414;
        switch (heff_tag_of(v_p_2411)) {
        case TAG_MkPair: {
          V v_y_2413 = heff_field(v_p_2411, 1);
          heff_take_n(v_p_2411, 2ULL, 2);
          v_t_2414 = v_y_2413;
          break;
        }
        default: heff_nomatch(v_p_2411);
        }
        switch (heff_tag_of(v_t_2414)) {
        case TAG_JNull: {
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JBool: {
          V v_b_2415 = heff_field(v_t_2414, 0);
          heff_take_n(v_t_2414, 1ULL, 1);
          v_t_2421 = v_b_2415;
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2414, 0ULL, 1);
          v_t_2421 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
      } else {
        heff_drop(v_field_2410);
        v_t_2421 = NTAG(TAG_False);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2441;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2427 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2428 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str1); V a_1 = v_fs_2427; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2427); r_; });
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_p_2431 = v_field_2430;
        V v_t_2434;
        switch (heff_tag_of(v_p_2431)) {
        case TAG_MkPair: {
          V v_y_2433 = heff_field(v_p_2431, 1);
          heff_take_n(v_p_2431, 2ULL, 2);
          v_t_2434 = v_y_2433;
          break;
        }
        default: heff_nomatch(v_p_2431);
        }
        switch (heff_tag_of(v_t_2434)) {
        case TAG_JNull: {
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2438 = heff_field(v_t_2434, 0);
          V v_ru_24t_2434_24JString = heff_take_reuse_n(v_t_2434, 1ULL, 1);
          v_t_2441 = heff_tag_at_n(v_ru_24t_2434_24JString, TAG_Just, 1, (V[]){v_s_2438});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2434, 0ULL, 1);
          v_t_2441 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2434);
        }
      } else {
        heff_drop(v_field_2430);
        v_t_2441 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2461;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JBool: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JInt: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JFloat: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JString: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JArray: {
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_JObject: {
    V v_fs_2447 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2448 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str2); V a_1 = v_fs_2447; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2447); r_; });
    {
      V v_field_2450 = v_t_2448.f[1];
      int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
      if ((v_tag_2449 == ((int64_t)0ULL))) {
        V v_p_2451 = v_field_2450;
        V v_t_2454;
        switch (heff_tag_of(v_p_2451)) {
        case TAG_MkPair: {
          V v_y_2453 = heff_field(v_p_2451, 1);
          heff_take_n(v_p_2451, 2ULL, 2);
          v_t_2454 = v_y_2453;
          break;
        }
        default: heff_nomatch(v_p_2451);
        }
        switch (heff_tag_of(v_t_2454)) {
        case TAG_JNull: {
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        case TAG_JArray: {
          V v_xs_2459 = heff_field(v_t_2454, 0);
          heff_take_n(v_t_2454, 1ULL, 1);
          v_t_2461 = v_xs_2459;
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2454, 0ULL, 1);
          v_t_2461 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_t_2454);
        }
      } else {
        heff_drop(v_field_2450);
        v_t_2461 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2462 = (g_list_2emap_24s1113395621x248103432(v_t_2461));
  V v_t_2476;
  switch (heff_tag_of(v_j_241)) {
  case TAG_JNull: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2476 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_2468 = heff_dup(heff_field(v_j_241, 0));
    HeffT2 v_t_2469 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str3); V a_1 = v_fs_2468; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_fs_2468); r_; });
    {
      V v_field_2471 = v_t_2469.f[1];
      int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
      if ((v_tag_2470 == ((int64_t)0ULL))) {
        V v_p_2472 = v_field_2471;
        V v_t_2475;
        switch (heff_tag_of(v_p_2472)) {
        case TAG_MkPair: {
          V v_y_2474 = heff_field(v_p_2472, 1);
          heff_take_n(v_p_2472, 2ULL, 2);
          v_t_2475 = v_y_2474;
          break;
        }
        default: heff_nomatch(v_p_2472);
        }
        v_t_2476 = (g_heff_2ebuild_2etesting_2ejsonFailure(v_t_2475));
      } else {
        heff_drop(v_field_2471);
        v_t_2476 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_j_241);
  }
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2eoutcomeOfJson_str4), NTAG(TAG_Nil)});
  HeffT2 v_t_2478 = ({ V a_0 = v_t_2477; V a_1 = v_j_241; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2477, 2); r_; });
  {
    V v_field_2480 = v_t_2478.f[1];
    int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
    V v_t_2488;
    if ((v_tag_2479 == ((int64_t)0ULL))) {
      V v_it1_2481 = v_field_2480;
      switch (heff_tag_of(v_it1_2481)) {
      case TAG_JNull: {
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      case TAG_JArray: {
        V v_xs_2486 = heff_field(v_it1_2481, 0);
        heff_take_n(v_it1_2481, 1ULL, 1);
        v_t_2488 = v_xs_2486;
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2481, 0ULL, 1);
        v_t_2488 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_it1_2481);
      }
    } else {
      heff_drop(v_field_2480);
      v_t_2488 = NTAG(TAG_Nil);
    }
    V v_t_2489 = (g_list_2emap_24s2029356170x1054793697(v_t_2488));
    return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, v_t_2421, v_t_2441, NTAG(TAG_False), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2462, v_t_2476, MK_INT(0LL), v_t_2489});
  }
}
V g_heff_2ebuild_2etesting_2eoutcomeOfJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2eoutcomeOfJson(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2eoutcomeVariable_str0, 17, "HEFF_TEST_OUTCOME");

static V g_heff_2ebuild_2etesting_2eoutcomeVariable_val;
static HEFF_ONCE g_heff_2ebuild_2etesting_2eoutcomeVariable_st;
static V g_heff_2ebuild_2etesting_2eoutcomeVariable_init(void) {
  return ((V)&g_heff_2ebuild_2etesting_2eoutcomeVariable_str0);
}
V g_heff_2ebuild_2etesting_2eoutcomeVariable_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2etesting_2eoutcomeVariable_st)) return g_heff_2ebuild_2etesting_2eoutcomeVariable_val;
  return heff_global(&g_heff_2ebuild_2etesting_2eoutcomeVariable_val, &g_heff_2ebuild_2etesting_2eoutcomeVariable_st, g_heff_2ebuild_2etesting_2eoutcomeVariable_init);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str1, 3, " / ");
Clo g_heff_2ebuild_2etesting_2esubtestJobs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry, 5, 0};

V g_heff_2ebuild_2etesting_2esubtestJobs_24dps(V v_sel_240, V v_j_241, V v_k_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_k_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_s_247 = heff_dup(heff_rfield(v_j_241, 3));
    V v_t_248 = ({ V a_0 = v_s_247; V a_1 = ((V)&g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2esubtestJobs_24dps_str1), v_s_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_247); r_; });
    V v_t_249 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_n_245), NTAG(TAG_Nil)});
    V v_t_2410 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_t_249, v_t_248, heff_dup(heff_rfield(v_j_241, 4))));
    V v_t_2411 = ({ V a_0 = v_sel_240; V a_1 = v_t_2410; V r_ = (g_heff_2ebuild_2etesting_2elevelsSelected(a_0, a_1)); heff_drop(v_t_2410); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_k_242), NTAG(TAG_Nil)});
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 2)), v_t_2412));
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, NTAG(TAG_Nil)});
      V v_t_2415 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_j_241, 4)), v_t_2414));
      V v_t_2416 = heff_rec_n(6, shape_owner__launch__place__top__path__limit, (V[]){heff_dup(heff_rfield(v_j_241, 0)), heff_dup(heff_rfield(v_j_241, 1)), v_t_2413, heff_dup(heff_rfield(v_j_241, 3)), v_t_2415, heff_dup(heff_rfield(v_j_241, 5))});
      V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2417);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_u_2418;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_n_245);
      heff_drop(v_t_2411);
      V t_0 = v_sel_240;
      V t_1 = v_j_241;
      V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_d_244;
      v_sel_240 = t_0;
      v_j_241 = t_1;
      v_k_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2etesting_2esubtestJobs_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ebuild_2etesting_2esubtestJobs_24dps(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2etesting_2ebrokenJob_str0, 3, " / ");
Clo g_heff_2ebuild_2etesting_2ebrokenJob_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2ebrokenJob_entry, 2, 0};

V g_heff_2ebuild_2etesting_2ebrokenJob(V v_j_240, V v_why_241) {
top: ;
  V v_top_242 = heff_take_field(v_j_240, 3);
  V v_path_243 = heff_take_field(v_j_240, 4);
  V v_owner_244 = heff_take_field(v_j_240, 0);
  V v_place_245 = heff_get_n(v_j_240, 2, 6);
  V v_name_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2etesting_2ebrokenJob_str0); V a_1 = v_top_242; V a_2 = v_path_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_path_243); r_; });
  V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_241})});
  V v_t_248 = heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_246, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_247, MK_INT(0LL), NTAG(TAG_Nil)});
  return heff_rec_n(4, shape_owner__place__outcome__next, (V[]){v_owner_244, v_place_245, v_t_248, NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2etesting_2ebrokenJob_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2ebrokenJob(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsHeld_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsHeld_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsHeld_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsHeld_str3, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsHeld_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsHeld_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestsHeld_str6, 11, " tests hold");
Clo g_heff_2ebuild_2etesting_2etestsHeld_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestsHeld_entry, 3, 0};

V g_heff_2ebuild_2etesting_2etestsHeld(V v_tests_240, V v_failed_241, V v_skipped_242) {
top: ;
  if (heff_intEq_c_lent(v_tests_240, MK_INT(0LL), 2)) {
    heff_drop(v_tests_240);
    heff_drop(v_failed_241);
    heff_drop(v_skipped_242);
    return ((V)&g_heff_2ebuild_2etesting_2etestsHeld_str0);
  } else {
    V v_t_244;
    if (heff_intEq_c_lent(v_skipped_242, MK_INT(0LL), 2)) {
      v_t_244 = ((V)&g_heff_2ebuild_2etesting_2etestsHeld_str1);
    } else {
      V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestsHeld_str2), heff_intShow(heff_dup(v_skipped_242)));
      v_t_244 = heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2etesting_2etestsHeld_str3));
    }
    V v_t_245 = heff_intSub(heff_intSub_lent(v_tests_240, v_failed_241, 2), v_skipped_242);
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestsHeld_str4), heff_intShow(v_t_245));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2etesting_2etestsHeld_str5)), heff_intShow(v_tests_240));
    return heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2etesting_2etestsHeld_str6)), v_t_244);
  }
}
V g_heff_2ebuild_2etesting_2etestsHeld_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestsHeld(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str2, 17, "heff test: --run ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str5, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str6, 0, "");
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam2, 2, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam5(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam5, 1, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam7(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam7, 1, 0};
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam3(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_entry, 5, 0};

V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_update_243, V v_fuel_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str0);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_pattern_241, 0);
    v_t_246 = heff_dup(v_x_245);
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_False); V a_4 = MK_INT(0LL); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2elevelsOf_2ecut_240(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1007499915x73800978(v_t_247));
  HeffT2 v_t_249 = (g_regex_2eallRead_24cpr(v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_c_2435;
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_why_2412 = v_field_2411;
      v_c_2435 = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam0, 2, 2, (V[]){heff_dup(v_pattern_241), v_why_2412});
    } else {
      V v_x_2432 = v_field_2411;
      heff_drop(v_x_2432);
      v_c_2435 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam2_clo);
    }
    return heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam3, 2, 6, (V[]){v_c_2435, heff_dup(v_seed_240), heff_dup(v_pattern_241), heff_dup(v_jobs_242), v_update_243, v_fuel_244});
  }
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_pattern_241 = heff_env(self)[0];
  V v_why_2412 = heff_env(self)[1];
  V v_t_2416;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str2), v_t_2416), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str3));
  V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_why_2412), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str4));
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam1, 1, 2, (V[]){v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam2(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam5(V self, V *args) {
  V v_n_2439 = args[0];
  return v_n_2439;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam7(V self, V *args) {
  V v_v_2447 = args[0];
  return v_v_2447;
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_pattern_241 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_fuel_244 = heff_env(self)[5];
  V v_k_2437 = heff_env(self)[6];
  V v_t_2460;
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_2460 = MK_INT(2026LL);
    break;
  }
  case TAG_Just: {
    V v_s_2455 = heff_field(v_seed_240, 0);
    heff_take_n(v_seed_240, 1ULL, 1);
    HeffT2 v_t_2456 = ({ V a_0 = v_s_2455; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2455); r_; });
    {
      V v_field_2458 = v_t_2456.f[1];
      int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
      if ((v_tag_2457 == ((int64_t)0ULL))) {
        V v_x_2459 = v_field_2458;
        v_t_2460 = v_x_2459;
      } else {
        heff_drop(v_field_2458);
        v_t_2460 = MK_INT(2026LL);
      }
    }
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_2462;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_2462 = ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2461 = heff_field(v_pattern_241, 0);
    heff_take_n(v_pattern_241, 1ULL, 1);
    v_t_2462 = v_x_2461;
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_fallback_2463;
  if (heff_intLt_c(heff_intDiv_lent(v_x_2446, MK_INT(2LL), 2), MK_INT(1LL))) {
    heff_drop(v_x_2446);
    v_fallback_2463 = MK_INT(1LL);
  } else {
    v_fallback_2463 = heff_intDiv(v_x_2446, MK_INT(2LL));
  }
  V v_fallback_2469;
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Nothing: {
    v_fallback_2469 = v_fallback_2463;
    break;
  }
  case TAG_Just: {
    V v_n_2464 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    HeffT2 v_t_2465 = ({ V a_0 = v_n_2464; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2464); r_; });
    {
      V v_field_2467 = v_t_2465.f[1];
      int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
      if ((v_tag_2466 == ((int64_t)0ULL))) {
        V v_k_2468 = v_field_2467;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2468, 1)) {
          heff_drop(v_fallback_2463);
          v_fallback_2469 = v_k_2468;
        } else {
          heff_drop(v_k_2468);
          v_fallback_2469 = v_fallback_2463;
        }
      } else {
        heff_drop(v_field_2467);
        v_fallback_2469 = v_fallback_2463;
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2454);
  }
  V v_t_2475;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2475 = v_fallback_2469;
    break;
  }
  case TAG_Just: {
    V v_n_2470 = heff_field(v_jobs_242, 0);
    heff_take_n(v_jobs_242, 1ULL, 1);
    HeffT2 v_t_2471 = ({ V a_0 = v_n_2470; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_n_2470); r_; });
    {
      V v_field_2473 = v_t_2471.f[1];
      int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
      if ((v_tag_2472 == ((int64_t)0ULL))) {
        V v_k_2474 = v_field_2473;
        if (heff_intLt_c_lent(MK_INT(0LL), v_k_2474, 1)) {
          heff_drop(v_fallback_2469);
          v_t_2475 = v_k_2474;
        } else {
          heff_drop(v_k_2474);
          v_t_2475 = v_fallback_2469;
        }
      } else {
        heff_drop(v_field_2473);
        v_t_2475 = v_fallback_2469;
      }
    }
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_x_2476 = heff_rec_n(5, shape_seed__pattern__jobs__update__fuel, (V[]){v_t_2460, v_t_2462, v_t_2475, v_update_243, v_fuel_244});
  V f_ = v_k_2437;
  args[0] = v_x_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_fuel_244 = heff_env(self)[5];
  V v_k_2437 = heff_env(self)[6];
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_str5), ((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam7_clo)})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s535099379x685970669(v_t_2453, v_hd_2436, heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam8, 1, 7, (V[]){v_seed_240, v_pattern_241, v_x_2446, v_jobs_242, v_update_243, v_fuel_244, v_k_2437})));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_fuel_244 = heff_env(self)[5];
  V v_k_2437 = heff_env(self)[6];
  heff_drop(v_x_2438);
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Processors, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam5_clo)})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s535099379x685970669(v_t_2445, heff_dup(v_hd_2436), heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam6, 1, 7, (V[]){v_hd_2436, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_fuel_244, v_k_2437})));
}
V g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam3(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_seed_240 = heff_env(self)[1];
  V v_pattern_241 = heff_env(self)[2];
  V v_jobs_242 = heff_env(self)[3];
  V v_update_243 = heff_env(self)[4];
  V v_fuel_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestOptions_24s80738999x1757137263_lam4, 1, 7, (V[]){v_hd_2436, v_seed_240, v_pattern_241, v_jobs_242, v_update_243, v_fuel_244, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str0, 36, "\012heff test: a change; tested again\012\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str1, 8, "all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str2, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str3, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str4, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str5, 12, "not all held");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str6, 19, "heff test: tested (");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str7, 3, "), ");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str8, 33, "; tested again at the next change");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str10, 60, "heff test: cannot run heff; tested again at the next change\012");
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam0, 2, 0};
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam9(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam8(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam10(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam2(V self, V *args);
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_entry, 6, 0};

V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501(V v_ex_240, V v_cu_241, V v_argv_242, V v_n_243, V v_p_244, V v_p_245) {
top: ;
  V v_t_2414;
  if (heff_intEq_c_lent(v_n_243, MK_INT(0LL), 2)) {
    v_t_2414 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam0_clo);
  } else {
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str0), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    v_t_2414 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})}));
  }
  return heff_tail(v_t_2414, 2, (V[]){heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam1, 1, 6, (V[]){v_p_244, v_argv_242, v_cu_241, v_ex_240, v_n_243, v_p_245})});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2438 = args[1];
  V v_k_2439 = args[2];
  V v_n_243 = heff_env(self)[0];
  heff_drop(v_x_2437);
  heff_drop(v_hd_2438);
  heff_clo_take(self, 1);
  V f_ = v_k_2439;
  args[0] = heff_intAdd(v_n_243, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_n_243 = heff_env(self)[1];
  heff_drop(v_x_2436);
  heff_clo_take(self, 2);
  V f_ = v_k_2420;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam6, 3, 1, (V[]){v_n_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_n_243 = heff_env(self)[0];
  V v_hd_2419 = heff_env(self)[1];
  V v_k_2420 = heff_env(self)[2];
  V v_t_2422 = heff_get_n(v_x_2421, 0, 3);
  V v_t_2426;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Exited: {
    V v_n_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 1);
    if (heff_intEq_c(v_n_2423, MK_INT(0LL))) {
      v_t_2426 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str1);
    } else {
      v_t_2426 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str2);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2422, 0ULL, 1);
    v_t_2426 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str3);
    break;
  }
  case TAG_TimedOut: {
    v_t_2426 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str4);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2422, 0ULL, 1);
    v_t_2426 = ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str5);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  V v_t_2427 = heff_intShow(heff_intAdd_lent(v_n_243, MK_INT(1LL), 2));
  V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str6), v_t_2427), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str7));
  V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, v_t_2426), ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str8));
  V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str9)), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_2419, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam5, 1, 2, (V[]){v_k_2420, v_n_243})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_n_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam4, 1, 3, (V[]){v_n_243, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam9(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2451 = args[1];
  V v_k_2452 = args[2];
  V v_n_243 = heff_env(self)[0];
  heff_drop(v_x_2450);
  heff_drop(v_hd_2451);
  heff_clo_take(self, 1);
  V f_ = v_k_2452;
  args[0] = heff_intAdd(v_n_243, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2442 = heff_env(self)[0];
  V v_n_243 = heff_env(self)[1];
  heff_drop(v_x_2449);
  heff_clo_take(self, 2);
  V f_ = v_k_2442;
  args[0] = heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam9, 3, 1, (V[]){v_n_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam7(V self, V *args) {
  V v_err_2440 = args[0];
  V v_hd_2441 = args[1];
  V v_k_2442 = args[2];
  V v_n_243 = heff_env(self)[0];
  heff_drop(v_err_2440);
  V v_t_2443 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_str10), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  heff_clo_take(self, 1);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_hd_2441, heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam8, 1, 2, (V[]){v_k_2442, v_n_243})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2454;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_p_244;
  heff_room[2] = v_p_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_argv_242 = heff_env(self)[0];
  V v_cu_241 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_n_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_x_2416, v_argv_242, heff_dup(g_std_2epath_2ecurrent_get()), NTAG(TAG_Nil), NTAG(TAG_Inherited), NTAG(TAG_Inherited), NTAG(TAG_Inherited), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_c_2418 = (g_std_2eprocess_2ewithProcess_24s647691963x1626449320(v_cu_241, heff_dup(v_ex_240), v_t_2417));
  V v_t_2453 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam3, 2, 2, (V[]){v_c_2418, heff_dup(v_n_243)}), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam7, 3, 1, (V[]){v_n_243})})}));
  return (g_co_2eop_24s535099379x685970669(v_t_2453, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam10, 1, 2, (V[]){v_p_244, v_p_245})));
}
V g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_argv_242 = heff_env(self)[1];
  V v_cu_241 = heff_env(self)[2];
  V v_ex_240 = heff_env(self)[3];
  V v_n_243 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_drop(v_x_2415);
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2etesting_2etestedAgain_24s619537708x612056501_lam2, 1, 6, (V[]){v_argv_242, v_cu_241, v_ex_240, v_n_243, v_p_244, v_p_245})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str0, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str1, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str2, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str3, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str4, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str5, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str6, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str7, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str8, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str9, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str10, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str11, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str12, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str13, 44, "not kept yet: `heff test --update` writes it");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str14, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str15, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str16, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str17, 20, "could not be written");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str19, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str20, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str21, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str24, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str25, 7, ", line ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str26, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str27, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str28, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str29, 1, "\"");
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam6(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam6, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam7(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam1(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam8(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam8, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam9(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_entry, 7, 0};

V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383(V v_update_240, V v_dir_241, V v_path_242, V v_text_243, V v_x5_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
      V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_241));
      V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
      V v_a_2410 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam0_clo)});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2415, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam1, 1, 4, (V[]){v_path_242, v_text_243, v_z_245, v_z_246})));
    } else {
      heff_drop(v_dir_241);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      V v_t_2469 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str12), v_path_242), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str13)})});
      return heff_tail(v_z_246, 1, (V[]){v_t_2469});
    }
  }
  case TAG_Just: {
    V v_kept_2470 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24Just = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_dir_241);
    if (heff_strEq_c_lent(v_kept_2470, v_text_243, 0)) {
      heff_drop(v_path_242);
      heff_drop(v_text_243);
      heff_drop(v_z_245);
      heff_drop(v_kept_2470);
      heff_drop_cell(v_ru_24x5_244_24Just, 1);
      return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_Holds)});
    } else {
      if ((heff_dup(v_update_240) == NTAG(TAG_True))) {
        heff_drop(v_kept_2470);
        V v_path_2471 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_242)));
        V v_t_2472 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2471; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2471); r_; });
        V v_a_2474 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2472, v_text_243, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam8_clo)});
        V v_t_2475 = heff_tag_at_n(v_ru_24x5_244_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2474})});
        V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
        V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
        return (g_co_2eop_24s1896221640x2141527803(v_t_2479, v_z_245, heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam9, 1, 2, (V[]){v_path_242, v_z_246})));
      } else {
        heff_drop(v_z_245);
        heff_drop_cell(v_ru_24x5_244_24Just, 1);
        V v_t_2487 = ({ V a_0 = v_kept_2470; V a_1 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str18); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str19), v_kept_2470, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_kept_2470); r_; });
        V v_t_2488 = ({ V a_0 = v_text_243; V a_1 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str20); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str21), v_text_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_243); r_; });
        HeffT3 v_t_2489 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2487; V a_2 = v_t_2488; HeffT3 r_ = (g_heff_2ebuild_2etesting_2efirstDiffering_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2487); heff_drop(v_t_2488); r_; });
        {
          V v_field_2490 = v_t_2489.f[0];
          V v_field_2491 = v_t_2489.f[1];
          V v_field_2492 = v_t_2489.f[2];
          V v_n_2493 = v_field_2490;
          V v_kept_2494 = v_field_2491;
          V v_text_2495 = v_field_2492;
          V v_t_2496 = ({ V a_0 = v_kept_2494; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str22); V r_ = (g_prelude_2einstanceDebugString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_kept_2494); r_; });
          V v_t_2497 = ({ V a_0 = v_text_2495; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str23); V r_ = (g_prelude_2einstanceDebugString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_text_2495); r_; });
          V v_t_2498 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str24), v_path_242), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str25));
          V v_t_2499 = heff_strAppend(v_t_2498, heff_intShow(v_n_2493));
          V v_t_24100 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str26), v_t_2496), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str27));
          V v_t_24101 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str28), v_t_2497), ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str29));
          V v_x_24102 = heff_tag_n(TAG_Wrong, 2, (V[]){v_t_2499, heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_24100, v_t_24101})});
          return heff_tail(v_z_246, 1, (V[]){v_x_24102});
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam2(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_ru_24x_2427_24Left = heff_take_reuse_n(v_x_2427, 0ULL, 1);
    heff_clo_take(self, 2);
    V v_t_2429 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str0), v_path_242), heff_tag_at_n(v_ru_24x_2427_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str1)})});
    V f_ = v_z_246;
    args[0] = v_t_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    switch (heff_tag_of(v_y_2430)) {
    case TAG_Left: {
      heff_take_n(v_y_2430, 0ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2432 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str2), v_path_242), heff_tag_at_n(v_ru_24x_2427_24Right, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str3)})});
      V f_ = v_z_246;
      args[0] = v_t_2432;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2430, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2427_24Right, 1);
      heff_clo_take(self, 2);
      V f_ = v_z_246;
      args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2430);
    }
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam4(V self, V *args) {
  V v_r_2438 = args[0];
  return v_r_2438;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam5(V self, V *args) {
  V v_x_2445 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Left: {
    V v_ru_24x_2445_24Left = heff_take_reuse_n(v_x_2445, 0ULL, 1);
    heff_clo_take(self, 2);
    V v_t_2447 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str4), v_path_242), heff_tag_at_n(v_ru_24x_2445_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str5)})});
    V f_ = v_z_246;
    args[0] = v_t_2447;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2448 = heff_field(v_x_2445, 0);
    V v_ru_24x_2445_24Right = heff_take_reuse_n(v_x_2445, 1ULL, 1);
    switch (heff_tag_of(v_y_2448)) {
    case TAG_Left: {
      heff_take_n(v_y_2448, 0ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2450 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str6), v_path_242), heff_tag_at_n(v_ru_24x_2445_24Right, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str7)})});
      V f_ = v_z_246;
      args[0] = v_t_2450;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2448, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2445_24Right, 1);
      heff_clo_take(self, 2);
      V f_ = v_z_246;
      args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2448);
    }
  }
  default: return heff_nomatch(v_x_2445);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam6(V self, V *args) {
  V v_r_2455 = args[0];
  return v_r_2455;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam7(V self, V *args) {
  V v_x_2462 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Left: {
    V v_ru_24x_2462_24Left = heff_take_reuse_n(v_x_2462, 0ULL, 1);
    heff_clo_take(self, 2);
    V v_t_2464 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str8), v_path_242), heff_tag_at_n(v_ru_24x_2462_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str9)})});
    V f_ = v_z_246;
    args[0] = v_t_2464;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2465 = heff_field(v_x_2462, 0);
    V v_ru_24x_2462_24Right = heff_take_reuse_n(v_x_2462, 1ULL, 1);
    switch (heff_tag_of(v_y_2465)) {
    case TAG_Left: {
      heff_take_n(v_y_2465, 0ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2467 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str10), v_path_242), heff_tag_at_n(v_ru_24x_2462_24Right, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str11)})});
      V f_ = v_z_246;
      args[0] = v_t_2467;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2465, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2462_24Right, 1);
      heff_clo_take(self, 2);
      V f_ = v_z_246;
      args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2465);
    }
  }
  default: return heff_nomatch(v_x_2462);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_text_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 0ULL, 1);
    V v_path_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_242)));
    V v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2418; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2418); r_; });
    heff_clo_take(self, 4);
    V v_a_2421 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2419, v_text_243, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam2_clo)});
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2426, v_z_245, heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam3, 1, 2, (V[]){v_path_242, v_z_246})));
  }
  case TAG_Right: {
    V v_y_2434 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Right = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2434)) {
    case TAG_Left: {
      V v_ru_24y_2434_24Left = heff_take_reuse_n(v_y_2434, 0ULL, 1);
      V v_path_2436 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_242)));
      V v_t_2437 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2436; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2436); r_; });
      heff_clo_take(self, 4);
      V v_a_2439 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2437, v_text_243, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam4_clo)});
      V v_t_2440 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2434_24Left, TAG_InR, 1, (V[]){v_a_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2444, v_z_245, heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam5, 1, 2, (V[]){v_path_242, v_z_246})));
    }
    case TAG_Right: {
      V v_ru_24y_2434_24Right = heff_take_reuse_n(v_y_2434, 0ULL, 1);
      V v_path_2453 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_242)));
      V v_t_2454 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2453; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2453); r_; });
      heff_clo_take(self, 4);
      V v_a_2456 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2454, v_text_243, ((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam6_clo)});
      V v_t_2457 = heff_tag_at_n(v_ru_24x_2416_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2434_24Right, TAG_InR, 1, (V[]){v_a_2456})});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})});
      return (g_co_2eop_24s1896221640x2141527803(v_t_2461, v_z_245, heff_clo_n(g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam7, 1, 2, (V[]){v_path_242, v_z_246})));
    }
    default: return heff_nomatch(v_y_2434);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam8(V self, V *args) {
  V v_r_2473 = args[0];
  return v_r_2473;
}
V g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_lam9(V self, V *args) {
  V v_x_2480 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2480)) {
  case TAG_Left: {
    V v_ru_24x_2480_24Left = heff_take_reuse_n(v_x_2480, 0ULL, 1);
    heff_clo_take(self, 2);
    V v_t_2482 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str14), v_path_242), heff_tag_at_n(v_ru_24x_2480_24Left, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str15)})});
    V f_ = v_z_246;
    args[0] = v_t_2482;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2483 = heff_field(v_x_2480, 0);
    V v_ru_24x_2480_24Right = heff_take_reuse_n(v_x_2480, 1ULL, 1);
    switch (heff_tag_of(v_y_2483)) {
    case TAG_Left: {
      heff_take_n(v_y_2483, 0ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2485 = heff_tag_n(TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str16), v_path_242), heff_tag_at_n(v_ru_24x_2480_24Right, TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383_str17)})});
      V f_ = v_z_246;
      args[0] = v_t_2485;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2483, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2480_24Right, 1);
      heff_clo_take(self, 2);
      V f_ = v_z_246;
      args[0] = heff_tag_n(TAG_Wrote, 1, (V[]){v_path_242});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2483);
    }
  }
  default: return heff_nomatch(v_x_2480);
  }
}
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str3, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str4, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str5, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str6, 112, "a golden text's name is a file's under the directory: letters, digits, `-`, `_` and `.`, not first, between `/`s");
HEFF_LIT(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str7, 5, "win32");
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam0(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam4(V self, V *args); static Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam4, 1, 0};
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_entry, 3, 0};

V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_name_243 = heff_field(v_x3_242, 0);
    V v_text_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_prelude_2esplit_2esplitFrom_240(v_name_243, ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str0), MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str1), v_name_243, MK_INT(0LL), 5), NTAG(TAG_Nil)));
    V v_x1_246 = ({ V a_0 = v_t_245; V r_ = (g_list_2eall_24s1461376987x321850093(a_0)); heff_drop(v_t_245); r_; });
    if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
      heff_drop(v_f_241);
      heff_drop(v_text_244);
      heff_drop(v_x1_246);
      V v_t_247 = ({ V a_0 = v_name_243; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str2); V r_ = (g_prelude_2einstanceDebugString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_name_243); r_; });
      V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str3), v_t_247), ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str4));
      V v_x_249 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str5), v_t_248), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str6)})});
      return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam0, 2, 1, (V[]){v_x_249});
    } else {
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      heff_drop(v_x1_246);
      return heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam1, 2, 4, (V[]){v_f_241, v_name_243, heff_dup(v_update_240), v_text_244});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_drop(v_hd_2410);
  heff_clo_take(self, 1);
  V f_ = v_k_2411;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam4(V self, V *args) {
  V v_r_2426 = args[0];
  return v_r_2426;
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_2422 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    heff_take_n(v_x_2433, 0ULL, 1);
    V v_s_2435 = (g_heff_2ebuild_2etesting_2egoldenPath(heff_dup(v_st_2422), heff_dup(v_f_241), heff_dup(v_name_243)));
    HeffT3 v_t_2436 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2422), v_s_2435));
    {
      V v_field_2437 = v_t_2436.f[0];
      V v_field_2438 = v_t_2436.f[1];
      V v_field_2439 = v_t_2436.f[2];
      V v_d_2440 = v_field_2437;
      V v_a_2441 = v_field_2438;
      V v_xs_2442 = v_field_2439;
      V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2442));
      V v_xs_2444 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2443; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2443); r_; });
      V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2444));
      V v_t_2446 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2440, v_a_2441, v_t_2445});
      V v_t_2447 = ({ V a_0 = v_st_2422; V a_1 = v_t_2446; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2446, 3); r_; });
      heff_clo_take(self, 7);
      V v_t_2448 = (g_heff_2ebuild_2etesting_2egoldenPath(v_st_2422, v_f_241, v_name_243));
      return ({ V a_0 = v_update_240; V a_1 = v_t_2447; V a_2 = v_t_2448; V a_3 = v_text_244; V a_4 = NTAG(TAG_Nothing); V a_5 = v_hd_2412; V a_6 = v_k_2413; V r_ = (g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_update_240); r_; });
    }
  }
  case TAG_Right: {
    V v_y_2449 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Right = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    switch (heff_tag_of(v_y_2449)) {
    case TAG_Left: {
      heff_take_n(v_y_2449, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2433_24Right, 1);
      V v_s_2451 = (g_heff_2ebuild_2etesting_2egoldenPath(heff_dup(v_st_2422), heff_dup(v_f_241), heff_dup(v_name_243)));
      HeffT3 v_t_2452 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2422), v_s_2451));
      {
        V v_field_2453 = v_t_2452.f[0];
        V v_field_2454 = v_t_2452.f[1];
        V v_field_2455 = v_t_2452.f[2];
        V v_d_2456 = v_field_2453;
        V v_a_2457 = v_field_2454;
        V v_xs_2458 = v_field_2455;
        V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2458));
        V v_xs_2460 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2459; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2459); r_; });
        V v_t_2461 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2460));
        V v_t_2462 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2456, v_a_2457, v_t_2461});
        V v_t_2463 = ({ V a_0 = v_st_2422; V a_1 = v_t_2462; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2462, 3); r_; });
        heff_clo_take(self, 7);
        V v_t_2464 = (g_heff_2ebuild_2etesting_2egoldenPath(v_st_2422, v_f_241, v_name_243));
        return ({ V a_0 = v_update_240; V a_1 = v_t_2463; V a_2 = v_t_2464; V a_3 = v_text_244; V a_4 = NTAG(TAG_Nothing); V a_5 = v_hd_2412; V a_6 = v_k_2413; V r_ = (g_heff_2ebuild_2etesting_2egoldenAgainst_24s63508499x1308153383(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_update_240); r_; });
      }
    }
    case TAG_Right: {
      V v_x_2465 = heff_field(v_y_2449, 0);
      heff_take_n(v_y_2449, 1ULL, 1);
      V v_s_2466 = (g_heff_2ebuild_2etesting_2egoldenPath(heff_dup(v_st_2422), heff_dup(v_f_241), heff_dup(v_name_243)));
      HeffT3 v_t_2467 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2422), v_s_2466));
      {
        V v_field_2468 = v_t_2467.f[0];
        V v_field_2469 = v_t_2467.f[1];
        V v_field_2470 = v_t_2467.f[2];
        V v_d_2471 = v_field_2468;
        V v_a_2472 = v_field_2469;
        V v_xs_2473 = v_field_2470;
        V v_t_2474 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2473));
        V v_xs_2475 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2474; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2474); r_; });
        V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2475));
        V v_t_2477 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2471, v_a_2472, v_t_2476});
        V v_t_2478 = ({ V a_0 = v_st_2422; V a_1 = v_t_2477; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop_tag(v_t_2477, 3); r_; });
        heff_clo_take(self, 7);
        V v_t_2479 = (g_heff_2ebuild_2etesting_2egoldenPath(v_st_2422, v_f_241, v_name_243));
        return ({ V a_0 = v_ru_24x_2433_24Right; V a_1 = v_x_2465; V a_2 = v_update_240; V a_3 = v_t_2478; V a_4 = v_t_2479; V a_5 = v_text_244; V a_6 = v_hd_2412; V a_7 = v_k_2413; V r_ = (g_heff_2ebuild_2etesting_2egoldenAgainst_24s494075341x1147040487_24tok1(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2465); heff_drop(v_update_240); heff_drop(v_t_2478); r_; });
      }
    }
    default: return heff_nomatch(v_y_2449);
    }
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  V v_st_2422;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_str7))) {
    v_st_2422 = NTAG(TAG_Windows);
  } else {
    v_st_2422 = NTAG(TAG_Posix);
  }
  V v_s_2423 = (g_heff_2ebuild_2etesting_2egoldenPath(heff_dup(v_st_2422), heff_dup(v_f_241), heff_dup(v_name_243)));
  V v_path_2424 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2423));
  V v_t_2425 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2424; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2424); r_; });
  V v_a_2427 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2425, ((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam4_clo)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  heff_clo_take(self, 6);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2432, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam5, 1, 7, (V[]){v_st_2422, v_f_241, v_name_243, v_update_240, v_text_244, v_hd_2412, v_k_2413})));
}
V g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_update_240 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2420, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2etesting_2egoldenSaid_24s482839843x1634027652_lam3, 1, 6, (V[]){v_f_241, v_name_243, v_hd_2412, v_update_240, v_text_244, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_str0, 17, "integration tests");
HEFF_LIT(g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_str1, 0, "");
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam2(V self, V *args); static Clo g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam2, 1, 0};
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam6(V self, V *args);
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam5(V self, V *args);
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam4(V self, V *args);
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam3(V self, V *args);
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_entry, 8, 0};

V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041(V v_rx_240, V v_ex_241, V v_cu_242, V v_opts_243, V v_ready_244, V v_acc_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_ready_244)) {
  case TAG_Nil: {
    heff_drop(v_rx_240);
    heff_drop(v_ex_241);
    heff_drop(v_cu_242);
    heff_drop_rec(v_opts_243, 5);
    heff_drop(v_p_246);
    return heff_tail(v_p_247, 1, (V[]){v_acc_245});
  }
  case TAG_Cons: {
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam0_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return (g_co_2eop_24s535099379x685970669(v_t_2412, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam1, 1, 8, (V[]){v_rx_240, v_p_246, v_opts_243, v_ready_244, v_ex_241, v_cu_242, v_acc_245, v_p_247})));
  }
  default: return heff_nomatch(v_ready_244);
  }
}
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam2(V self, V *args) {
  V v_i_2414 = args[0];
  return v_i_2414;
}
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_opts_243 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_ready_244 = heff_env(self)[2];
  V v_acc_245 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  heff_drop(v_x_2435);
  heff_clo_take(self, 6);
  return ({ V a_0 = v_opts_243; V a_1 = v_x_2429; V a_2 = v_ready_244; V a_3 = v_acc_245; V a_4 = v_p_246; V a_5 = v_p_247; V r_ = (g_heff_2ebuild_2etesting_2ereportReady_24s1724891461x265292388(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_tag(v_ready_244, 2); r_; });
}
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_opts_243 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_ready_244 = heff_env(self)[4];
  V v_acc_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_drop(v_x_2432);
  heff_clo_take(self, 7);
  V v_t_2433 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam6, 1, 6, (V[]){v_opts_243, v_x_2429, v_ready_244, v_acc_245, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_rx_240 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_opts_243 = heff_env(self)[4];
  V v_ready_244 = heff_env(self)[5];
  V v_acc_245 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2430 = heff_tag_n(TAG_Close, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_call(v_rx_240, 1, (V[]){v_t_2430}));
  return (g_co_2eop_24s535099379x685970669(v_t_2431, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam5, 1, 7, (V[]){v_x_2413, v_p_246, v_opts_243, v_x_2429, v_ready_244, v_acc_245, v_p_247})));
}
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_opts_243 = heff_env(self)[0];
  V v_ready_244 = heff_env(self)[1];
  V v_ex_241 = heff_env(self)[2];
  V v_rx_240 = heff_env(self)[3];
  V v_cu_242 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_acc_245 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  V v_p_2418 = heff_dup(heff_rfield(v_opts_243, 1));
  V v_t_2426;
  if (heff_strEq_c_lent(v_p_2418, ((V)&g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_str1), 2)) {
    heff_drop(v_p_2418);
    v_t_2426 = NTAG(TAG_Nil);
  } else {
    V v_t_2419 = ({ V a_0 = v_p_2418; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_False); V a_4 = MK_INT(0LL); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2elevelsOf_2ecut_240(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_2418); r_; });
    V v_t_2420 = (g_list_2emap_24s1007499915x73800978(v_t_2419));
    HeffT2 v_t_2421 = (g_regex_2eallRead_24cpr(v_t_2420));
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_why_2424 = v_field_2423;
        heff_drop(v_why_2424);
        v_t_2426 = NTAG(TAG_Nil);
      } else {
        V v_sel_2425 = v_field_2423;
        v_t_2426 = v_sel_2425;
      }
    }
  }
  V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ready_244)));
  V v_t_2428 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2427; V r_ = (g_list_2efoldl_24s344878118x1065108086(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2etesting_2erunJobs_24s1300657772x1273858689(heff_dup(v_x_2417), v_ex_241, heff_dup(v_rx_240), v_cu_242, v_t_2426, heff_dup(heff_rfield(v_opts_243, 2)), v_t_2428, MK_INT(0LL), NTAG(TAG_Nil), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam4, 1, 8, (V[]){v_x_2417, v_rx_240, v_p_246, v_x_2413, v_opts_243, v_ready_244, v_acc_245, v_p_247})));
}
V g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rx_240 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_opts_243 = heff_env(self)[2];
  V v_ready_244 = heff_env(self)[3];
  V v_ex_241 = heff_env(self)[4];
  V v_cu_242 = heff_env(self)[5];
  V v_acc_245 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_t_2415 = heff_tag_n(TAG_Open, 2, (V[]){NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam2_clo)});
  V v_t_2416 = heff_tr(heff_call(heff_dup(v_rx_240), 1, (V[]){v_t_2415}));
  heff_clo_take(self, 8);
  return (g_co_2eop_24s535099379x685970669(v_t_2416, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2etesting_2erunReady_24s1496359888x1554248041_lam3, 1, 9, (V[]){v_opts_243, v_ready_244, v_ex_241, v_rx_240, v_cu_242, v_p_246, v_x_2413, v_acc_245, v_p_247})));
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_lam0(V self, V *args); static Clo g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_lam0, 1, 0};
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_lam1(V self, V *args);
Clo g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_entry, 4, 0};

V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958(V v_opts_240, V v_f_241, V v_z_242, V v_z_243) {
top: ;
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_241)));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2412, heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_lam1, 1, 4, (V[]){v_z_242, v_f_241, v_opts_240, v_z_243})));
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Left = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_z_242; V a_1 = v_f_241; V a_2 = v_opts_240; V a_3 = v_z_243; V b_4 = heff_tag_re_n(v_ru_24x_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2414}); V r_ = (g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  }
  case TAG_Right: {
    V v_y_2415 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    switch (heff_tag_of(v_y_2415)) {
    case TAG_Left: {
      V v_err_2416 = heff_field(v_y_2415, 0);
      V v_ru_24y_2415_24Left = heff_take_reuse_n(v_y_2415, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2413_24Right, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_z_242; V a_1 = v_f_241; V a_2 = v_opts_240; V a_3 = v_z_243; V b_4 = heff_tag_re_n(v_ru_24y_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2416}); V r_ = (g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_y_2415, 0);
      heff_take_n(v_y_2415, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_z_242; V a_1 = v_f_241; V a_2 = v_opts_240; V a_3 = v_z_243; V b_4 = heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Right, 1, (V[]){v_x_2417}); V r_ = (g_heff_2ebuild_2etesting_2etestOneF_24s1075667793x952826958_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    }
    default: return heff_nomatch(v_y_2415);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}