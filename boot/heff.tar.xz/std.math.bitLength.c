// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2emath_2ebitLength_2ebitsOfSize_240(V, V);
V g_std_2emath_2ebitLength_2ebitsOfSize_240_entry(V self, V *a);
extern Clo g_std_2emath_2ebitLength_2ebitsOfSize_240_clo;
V g_std_2emath_2ebitsBelow(V, V, V);
V g_std_2emath_2ebitsBelow_entry(V self, V *a);
extern Clo g_std_2emath_2ebitsBelow_clo;
Clo g_std_2emath_2ebitLength_2ebitsOfSize_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2emath_2ebitLength_2ebitsOfSize_240_entry, 2, 0};

V g_std_2emath_2ebitLength_2ebitsOfSize_240(V v_m_240, V v_acc_241) {
top: ;
  V v_y_242 = heff_intShl(MK_INT(1LL), MK_INT(64LL));
  if (heff_intLe_c_lent(v_y_242, v_m_240, 1)) {
    V v_t_243 = heff_intShr(v_m_240, MK_INT(64LL));
    V t_0 = v_t_243;
    V t_1 = heff_intAdd(v_acc_241, MK_INT(64LL));
    v_m_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  } else {
    return (g_std_2emath_2ebitsBelow(v_m_240, v_acc_241, MK_INT(32LL)));
  }
}
V g_std_2emath_2ebitLength_2ebitsOfSize_240_entry(V self, V *a) {
  (void)self;
  return g_std_2emath_2ebitLength_2ebitsOfSize_240(a[0], a[1]);
}