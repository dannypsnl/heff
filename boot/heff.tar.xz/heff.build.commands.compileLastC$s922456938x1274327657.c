// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define LBL_c 317
#define LBL_globals 352931696
#define LBL_own 320000
#define LBL_top 324559
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2elower_2ecKept(V, V, V, V, V, V);
V g_heff_2ecompile_2elower_2ecKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecKept_clo;
V g_heff_2ecompile_2elower_2eerasedWith(V, V, V);
V g_heff_2ecompile_2elower_2eerasedWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eerasedWith_clo;
V g_list_2emap_24f1176765648x1638512070(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1176765648x1638512070_entry(V self, V *a);
extern Clo g_list_2emap_24f1176765648x1638512070_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str1, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str2, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str4, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str5, 1, "#");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0(V v_outPath_240, V v_hd_241, V v_c_242, V v_x_243, V v_k_244, V v_x_245) {
top: ;
  V v_own_246 = heff_take_field(v_c_242, 7);
  V v_top_247 = heff_get_n(v_c_242, 5, 14);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_ru_24x_245_24Left = heff_take_reuse_n(v_x_245, 0ULL, 1);
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_2410 = heff_strSlice_lent(v_outPath_240, heff_box_word(v_t_249), heff_strLength_lent(v_outPath_240, 0), 6);
    V v_t_2412;
    if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str0))) {
      int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_2412 = heff_strSlice_lent(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_2411), 6);
    } else {
      v_t_2412 = heff_dup(v_outPath_240);
    }
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str1), heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str2)));
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str3)), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_at_n(v_ru_24x_245_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_lam0, 1, 6, (V[]){v_own_246, v_top_247, v_x_243, v_outPath_240, v_hd_241, v_k_244})));
  }
  case TAG_Right: {
    V v_ru_24x_245_24Right = heff_take_reuse_n(v_x_245, 0ULL, 1);
    V v_exports_2428 = (g_list_2emap_24f1176765648x1638512070(MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str5), MK_INT(0LL), MK_INT(97LL), MK_INT(0LL), MK_INT(0LL), MK_INT(122LL), MK_INT(65LL), MK_INT(0LL), MK_INT(0LL), MK_INT(90LL), v_own_246));
    V v_roots_2429 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2428)));
    V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elower_2ecKept_clo), 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)}));
    V v_t_2431 = (g_heff_2ecompile_2eerase_2eeraseProgram(heff_get_n(v_top_247, 0, 10)));
    V v_t_2432 = heff_tr(g_heff_2ecompile_2elower_2eerasedWith(v_t_2430, v_roots_2429, v_t_2431));
    V v_t_2433 = (g_heff_2ecompile_2eemitc_2echeckOut(heff_get_n(v_x_243, 0, 4), v_exports_2428, v_t_2432));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1(v_ru_24x_245_24Right, v_outPath_240, NTAG(TAG_False), v_t_2433, v_hd_241, v_k_244);
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_own_246 = heff_env(self)[0];
  V v_top_247 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_drop(v_x_2420);
  heff_clo_take(self, 6);
  V v_exports_2421 = (g_list_2emap_24f1176765648x1638512070(MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s922456938x1274327657_2ek_24l0_str4), MK_INT(0LL), MK_INT(97LL), MK_INT(0LL), MK_INT(0LL), MK_INT(122LL), MK_INT(65LL), MK_INT(0LL), MK_INT(0LL), MK_INT(90LL), v_own_246));
  V v_roots_2422 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2421)));
  V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2elower_2ecKept_clo), 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)}));
  V v_t_2424 = (g_heff_2ecompile_2eerase_2eeraseProgram(heff_get_n(v_top_247, 0, 10)));
  V v_t_2425 = heff_tr(g_heff_2ecompile_2elower_2eerasedWith(v_t_2423, v_roots_2422, v_t_2424));
  V v_t_2426 = (g_heff_2ecompile_2eemitc_2echeckOut(heff_get_n(v_x_243, 0, 4), v_exports_2421, v_t_2425));
  return (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300(v_outPath_240, NTAG(TAG_True), v_t_2426, v_hd_241, v_k_244));
}